﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace VShips.Framework.Resource.Model
{
    /// <summary>
    /// <para>
    /// This is a special resource dictionary that solves the problem
    /// where mutliple resource dictionaries of the same type are held in memory.
    /// It holds a static collection of dictionaries to ensure that when a 
    /// resourcedictionary is loaded it is only done once.
    /// </para>
    /// <para>
    /// If you are in debug mode the resource dictionary will act as normal allowing for a nicer design time experience.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example shows how to create a SharedResourceDictionary and add it to a UserControl resources.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <UserControl.Resources>
    ///     <ResourceDictionary>
    ///         <ResourceDictionary.MergedDictionaries>
    ///             <model:SharedResourceDictionary Source="/VShips.Framework.Resource;component/Themes/Common.xaml" />
    ///         </ResourceDictionary.MergedDictionaries>
    ///     </ResourceDictionary>
    /// </UserControl.Resources>]]>
    /// </code>
    /// </example>
    public class SharedResourceDictionary : ResourceDictionary
    {

#if !DEBUG
        
        //private static readonly Dictionary<Uri, ResourceDictionary> SharedDictionaries = new Dictionary<Uri, ResourceDictionary>();

        //private Uri _sourceUri;
        ///// <summary>
        ///// Overrides the current source to add the resources into a static shared dictionary.
        ///// This ensures that whenever a resource dictionary is referenced it uses only
        ///// one instance of it. 
        ///// </summary>
        //public new Uri Source
        //{
        //    get
        //    {
        //        return _sourceUri;
        //    }
        //    set
        //    {
        //        _sourceUri = value;
        //        if (!SharedDictionaries.ContainsKey(value))
        //        {
        //            base.Source = value;
        //            SharedDictionaries.Add(value, this);
        //        }
        //        else
        //        {
        //            MergedDictionaries.Add(SharedDictionaries[value]);
        //        }
        //    }
        //}
#endif



    }
}
