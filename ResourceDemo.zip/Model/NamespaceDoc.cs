﻿namespace VShips.Framework.Resource.Model
{
    /// <summary>
    /// A set of common models used throughout the apps modules.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
