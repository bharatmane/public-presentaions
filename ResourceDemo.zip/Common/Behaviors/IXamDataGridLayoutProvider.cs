﻿using Infragistics.Windows.DataPresenter;
using System;
using System.Collections.Generic;

namespace VShips.Framework.Resource.Common.Behaviors
{
    /// <summary>
    /// The interface for XamDataGridLayoutProvider.
    /// </summary>
    public interface IXamDataGridLayoutProvider
    {
        /// <summary>
        /// Handleses the type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        bool HandlesType(Type type);

        /// <summary>
        /// Creates the layouts.
        /// </summary>
        /// <returns></returns>
        List<FieldLayout> CreateLayouts();
    }
}
