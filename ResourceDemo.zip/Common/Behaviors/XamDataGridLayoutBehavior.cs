﻿using Infragistics.Windows.DataPresenter;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Interactivity;

namespace VShips.Framework.Resource.Common.Behaviors
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="System.Windows.Interactivity.Behavior{Infragistics.Windows.DataPresenter.XamDataGrid}" />
    public class XamDataGridLayoutBehavior : Behavior<XamDataGrid>
    {
        #region Properties

        /// <summary>
        /// The data source property
        /// </summary>
        public static readonly DependencyProperty DataSourceProperty =
            DependencyProperty.Register("DataSource", typeof(IEnumerable), typeof(XamDataGridLayoutBehavior), new PropertyMetadata(null, OnDataSourceChanged));

        /// <summary>
        /// Called when [data source changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDataSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var behavior = d as XamDataGridLayoutBehavior;
            if(behavior != null)
            {
                behavior.ChangeDataSource(e.NewValue as IEnumerable);
            }
        }

        /// <summary>
        /// Gets or sets the data source.
        /// </summary>
        /// <value>
        /// The data source.
        /// </value>
        public IEnumerable DataSource
        {
            get { return (IEnumerable)GetValue(DataSourceProperty); }
            set { SetValue(DataSourceProperty, value); }
        }

        /// <summary>
        /// The layout providers property
        /// </summary>
        public static readonly DependencyProperty LayoutProvidersProperty =
            DependencyProperty.Register("LayoutProviders", typeof(List<IXamDataGridLayoutProvider>), typeof(XamDataGridLayoutBehavior), new PropertyMetadata(new List<IXamDataGridLayoutProvider>()));

        /// <summary>
        /// Gets or sets the layout providers.
        /// </summary>
        /// <value>
        /// The layout providers.
        /// </value>
        public List<IXamDataGridLayoutProvider> LayoutProviders
        {
            get { return (List<IXamDataGridLayoutProvider>)GetValue(LayoutProvidersProperty); }
            set { SetValue(LayoutProvidersProperty, value); }
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Called after the behavior is attached to an AssociatedObject.
        /// </summary>
        /// <remarks>
        /// Override this to hook up functionality to the AssociatedObject.
        /// </remarks>
        protected override void OnAttached()
        {
            base.OnAttached();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Changes the data source.
        /// </summary>
        /// <param name="dataSource">The data source.</param>
        private void ChangeDataSource(IEnumerable dataSource)
        {
            ClearGrid();

            if(dataSource != null)
            {
                var layouts = CreateLayouts(dataSource);
                foreach(var layout in layouts)
                {
                    AssociatedObject.FieldLayouts.Add(layout);
                }

                AssociatedObject.DataSource = dataSource;
            }
        }

        /// <summary>
        /// Clears the grid.
        /// </summary>
        private void ClearGrid()
        {
            AssociatedObject.DataSource = null;

            if (AssociatedObject.FieldLayouts != null && AssociatedObject.FieldLayouts.Count > 0)
            {
                foreach (var layout in AssociatedObject.FieldLayouts)
                {
                    layout.SortedFields.Clear();
                    layout.RecordFilters.Clear();
                }

                AssociatedObject.FieldLayouts.Clear();
            }
        }

        /// <summary>
        /// Creates the layouts.
        /// </summary>
        /// <param name="dataSource">The data source.</param>
        /// <returns></returns>
        private IList<FieldLayout> CreateLayouts(IEnumerable dataSource)
        {
            var layouts = new List<FieldLayout>();
            if(dataSource != null)
            {
                var provider = GetProvider(dataSource);
                if(provider != null)
                {
                    layouts = provider.CreateLayouts();
                }
            }

            return layouts;
        }

        /// <summary>
        /// Gets the provider.
        /// </summary>
        /// <param name="dataSource">The data source.</param>
        /// <returns></returns>
        private IXamDataGridLayoutProvider GetProvider(IEnumerable dataSource)
        {
            if (dataSource.Cast<object>().Count() > 0)
            {
                var firstItem = dataSource.Cast<object>().First();
                var matchingProvider = LayoutProviders.FirstOrDefault(provider => provider.HandlesType(firstItem.GetType()));

                return matchingProvider;
            }
            return null;
        }

        #endregion
    }
}
