﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace VShips.Framework.Resource.Common.Controls.Dashboard
{
    public class DashboardTile :ContentControl
    {
        #region Fields

        private const string MaximizeButtonPartName = "MaximizeButtonPart";
        private const string TemplatePartErrorMessage = " is missing from the control template.";

        #endregion

        #region Events

        public event EventHandler TileMaximize;
        public event EventHandler TileMinimize;

        #endregion

        #region Constructor

        static DashboardTile()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DashboardTile), new FrameworkPropertyMetadata(typeof(DashboardTile)));
        }

        #endregion

        #region Properties

        public static readonly DependencyProperty IsMaximizedProperty =
            DependencyProperty.Register("IsMaximized", typeof(bool), typeof(DashboardTile), new PropertyMetadata(false));

        public bool IsMaximized
        {
            get { return (bool)GetValue(IsMaximizedProperty); }
            internal set { SetValue(IsMaximizedProperty, value); }
        }

        public static readonly DependencyProperty HideMaximizeButtonProperty =
            DependencyProperty.Register("HideMaximizeButton", typeof(bool), typeof(DashboardTile), new PropertyMetadata(false));

        public bool HideMaximizeButton
        {
            get { return (bool)GetValue(HideMaximizeButtonProperty); }
            set { SetValue(HideMaximizeButtonProperty, value); }
        }

        public string Key { get; set; }

        #endregion

        #region Public Methods

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            var button = Template.FindName(MaximizeButtonPartName, this) as ButtonBase;
            if (button == null)
            {
                throw new InvalidOperationException(string.Format("{0}{1}", MaximizeButtonPartName, TemplatePartErrorMessage));
            }

            var dashboard = this.GetDashboard();
            if (dashboard != null)
            {
                dashboard.RegisterTile(this);
            }

            button.Click += MaximizeButton_Click;
        }

        #endregion

        #region Event Handlers

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (IsMaximized)
            {
                OnTileMinimize();
            }
            else
            {
                OnTileMaximize();
            }
        }

        #endregion

        #region Private Methods

        private void OnTileMaximize()
        {
            var tileMaximize = TileMaximize;
            if (tileMaximize != null)
            {
                tileMaximize.Invoke(this, new EventArgs());
            }
        }

        private void OnTileMinimize()
        {
            var tileMinimize = TileMinimize;
            if (tileMinimize != null)
            {
                tileMinimize.Invoke(this, new EventArgs());
            }
        }

        #endregion
    }
}