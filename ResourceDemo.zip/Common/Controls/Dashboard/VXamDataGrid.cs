﻿using Infragistics.Windows.DataPresenter;
using Infragistics.Windows.DataPresenter.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Common.Controls.Dashboard
{
    public class VXamDataGrid : XamDataGrid
    {
        #region Dependency Properties

        /// <summary>
        /// Command that is run when the mouse is double clicked. The viewmodel of the clicked item is passed to the command.
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
            DependencyProperty.Register("DoubleClickCommand", typeof(ICommand), typeof(VXamDataGrid), new PropertyMetadata(null));

        /// <summary>
        /// Exposes the <see cref="DoubleClickCommand" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The double click command.
        /// </value>
        public ICommand DoubleClickCommand
        {
            get { return (ICommand)GetValue(DoubleClickCommandProperty); }
            set { SetValue(DoubleClickCommandProperty, value); }
        }

        /// <summary>
        /// Command that is run when the mouse is double clicked. The viewmodel of the clicked item is passed to the command.
        /// </summary>
        public static readonly DependencyProperty RecordExpandedCommandProperty =
            DependencyProperty.Register("RecordExpandedCommand", typeof(ICommand), typeof(VXamDataGrid), new PropertyMetadata(null));

        /// <summary>
        /// Exposes the <see cref="RecordExpandedCommand" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The double click command.
        /// </value>
        public ICommand RecordExpandedCommand
        {
            get { return (ICommand)GetValue(RecordExpandedCommandProperty); }
            set { SetValue(RecordExpandedCommandProperty, value); }
        }
        #endregion

        /// <summary>
        /// Executes the <see cref="DoubleClickCommand" /> if double clicked on an item.
        /// </summary>
        /// <param name="eventArguments">The <see cref="MouseButtonEventArgs" /> instance containing the event data.</param>
        protected override void OnMouseDoubleClick(MouseButtonEventArgs eventArguments)
        {
            if (eventArguments != null && eventArguments.ChangedButton == MouseButton.Left)
            {
                if (DoubleClickCommand != null)
                {
                    var source = eventArguments.OriginalSource as DependencyObject;
                    if (source != null)
                    {
                        var item = UIHelper.FindVisualParent<XamDataGrid>(source, this);
                        if (item != null)
                        {
                            var vm = item.DataContext;
                            if (DoubleClickCommand.CanExecute(vm))
                            {
                                DoubleClickCommand.Execute(vm);
                            }
                        }
                    }
                }
            }
            base.OnMouseDoubleClick(eventArguments);
        }

        protected override void OnRecordExpanded(RecordExpandedEventArgs eventArguments)
        {

            if (eventArguments != null )
            {
                if (RecordExpandedCommand != null)
                {
                    VXamDataGrid source = eventArguments.OriginalSource as VXamDataGrid;
                    if (source != null)
                    {
                        DataRecord dataRecord = eventArguments.Record as DataRecord;
                        if (dataRecord != null)
                        {
                            if (RecordExpandedCommand.CanExecute(dataRecord.DataItem))
                            {
                                RecordExpandedCommand.Execute(dataRecord.DataItem);
                            }
                        }
                    }
                }
            }
            
            base.OnRecordExpanded(eventArguments);
        }

    }
}
