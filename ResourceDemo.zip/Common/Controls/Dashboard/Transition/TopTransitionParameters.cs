﻿using System.Windows.Controls;

namespace VShips.Framework.Resource.Common.Controls.Dashboard.Transition
{
    public class TopTransitionParameters
    {
        #region Properties

        public TopTransitionType TransitionType { get; set; }

        public Grid TopModalBackground { get; set; }

        public ContentControl TopContent { get; set; }

        public double TransitionToHeight { get; set; }

        #endregion
    }
}
