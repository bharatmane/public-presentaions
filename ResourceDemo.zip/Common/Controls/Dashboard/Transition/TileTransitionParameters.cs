﻿using System;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Common.Controls.Dashboard.Transition
{
    public class TileTransitionParameters
    {
        #region Properties

        public TileTransitionType TransitionType { get; set; }

        public DashboardTile Tile { get; set; }

        public Grid TileContentContainer { get; set; }

        public Action<string> MaximizingCallback { get; set; }

        public Action<string> MinimizingCallback { get; set; }

        #endregion
    }
}
