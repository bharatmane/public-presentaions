﻿using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace VShips.Framework.Resource.Common.Controls.Dashboard.Transition
{
    public class TopTransitionManager
    {
        #region Fields

        private const string InvalidParametersError = "Invalid parameters.";

        private readonly Storyboard _expandTop, _collapseTop,
            _showTopModalBackground, _hideTopModalBackground;

        #endregion

        #region Constructor

        public TopTransitionManager()
        {
            _expandTop = CreateExpandTopStoryboard();
            _collapseTop = CreateCollapseTopStoryboard();
            _showTopModalBackground = CreateShowTopModalBackgroundStoryboard();
            _hideTopModalBackground = CreateHideTopModalBackgroundStoryboard();
        }

        #endregion

        #region Public Methods

        public void DoTransition(TopTransitionParameters parameters)
        {
            if (ParametersAreValid(parameters))
            {
                switch (parameters.TransitionType)
                {
                    case TopTransitionType.Expand:
                        ExpandTop(parameters);
                        break;
                    case TopTransitionType.Collapse:
                        CollapseTop(parameters);
                        break;
                }
            }
            else
            {
                throw new InvalidOperationException(InvalidParametersError);
            }
        }

        #endregion

        #region Private Methods

        private Storyboard CreateExpandTopStoryboard()
        {
            var storyboard = new Storyboard();
            var animation = new DoubleAnimation(0, TimeSpan.FromSeconds(.1))
            {
                EasingFunction = new CubicEase()
            };

            Storyboard.SetTargetProperty(storyboard, new PropertyPath("(FrameworkElement.Height)"));
            storyboard.Children.Add(animation);

            return storyboard;
        }

        private Storyboard CreateCollapseTopStoryboard()
        {
            var storyboard = new Storyboard();
            var animation = new DoubleAnimation(0, TimeSpan.FromSeconds(.1))
            {
                EasingFunction = new CubicEase()
            };

            Storyboard.SetTargetProperty(storyboard, new PropertyPath("(FrameworkElement.Height)"));
            storyboard.Children.Add(animation);

            return storyboard;
        }

        private Storyboard CreateShowTopModalBackgroundStoryboard()
        {
            var storyboard = new Storyboard();
            var visibilityAnimation = new ObjectAnimationUsingKeyFrames();
            visibilityAnimation.Duration = TimeSpan.FromSeconds(0);
            visibilityAnimation.KeyFrames.Add(new DiscreteObjectKeyFrame(Visibility.Visible, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0))));
            Storyboard.SetTargetProperty(visibilityAnimation, new PropertyPath("(UIElement.Visibility)"));

            var opacityAnimation = new DoubleAnimation(.3, TimeSpan.FromSeconds(.1))
            {
                EasingFunction = new CubicEase()
            };
            Storyboard.SetTargetProperty(opacityAnimation, new PropertyPath("(UIElement.Opacity)"));

            storyboard.Children.Add(visibilityAnimation);
            storyboard.Children.Add(opacityAnimation);

            return storyboard;
        }

        private Storyboard CreateHideTopModalBackgroundStoryboard()
        {
            var storyboard = new Storyboard();
            var visibilityAnimation = new ObjectAnimationUsingKeyFrames();
            visibilityAnimation.Duration = TimeSpan.FromSeconds(.1);
            visibilityAnimation.KeyFrames.Add(new DiscreteObjectKeyFrame(Visibility.Collapsed, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(.1))));
            Storyboard.SetTargetProperty(visibilityAnimation, new PropertyPath("(UIElement.Visibility)"));

            var opacityAnimation = new DoubleAnimation(0, TimeSpan.FromSeconds(.1))
            {
                EasingFunction = new CubicEase()
            };
            Storyboard.SetTargetProperty(opacityAnimation, new PropertyPath("(UIElement.Opacity)"));

            storyboard.Children.Add(visibilityAnimation);
            storyboard.Children.Add(opacityAnimation);

            return storyboard;
        }

        private bool ParametersAreValid(TopTransitionParameters parameters)
        {
            return parameters != null
                && parameters.TopContent != null
                && parameters.TopModalBackground != null;
        }

        private void ExpandTop(TopTransitionParameters parameters)
        {
            parameters.TopModalBackground.BeginStoryboard(_showTopModalBackground);

            ((DoubleAnimation)_expandTop.Children[0]).To = parameters.TransitionToHeight;
            parameters.TopContent.BeginStoryboard(_expandTop);
        }

        private void CollapseTop(TopTransitionParameters parameters)
        {
            ((DoubleAnimation)_collapseTop.Children[0]).To = parameters.TransitionToHeight;
            parameters.TopContent.BeginStoryboard(_collapseTop);

            parameters.TopModalBackground.BeginStoryboard(_hideTopModalBackground);
        }

        #endregion
    }
}
