﻿namespace VShips.Framework.Resource.Common.Controls.Dashboard.Transition
{
    public enum TopTransitionType
    {
        Expand, Collapse
    }
}
