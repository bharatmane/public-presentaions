﻿namespace VShips.Framework.Resource.Common.Controls.Dashboard.Transition
{
    public class TileState
    {
        #region Properties

        public int ZIndex { get; set; }

        public int Row { get; set; }

        public int Column { get; set; }

        public int RowSpan { get; set; }

        public int ColumnSpan { get; set; }

        #endregion
    }
}
