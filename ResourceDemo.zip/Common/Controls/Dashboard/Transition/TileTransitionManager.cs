﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using VShips.Framework.Resource.Common.Controls.Dashboard.Transition;

namespace VShips.Framework.Resource.Common.Controls.Dashboard.Transition
{
    public class TileTransitionManager
    {
        #region Fields

        private const string InvalidParametersError = "Invalid parameters object";
        private const int MaximizedZIndex = 100;

        private readonly Dictionary<string, TileState> _tileStates;
        private readonly Storyboard _hideTileContent, _showTileContent;

        private TileTransitionParameters _currentParameters;

        #endregion

        #region Constructor

        public TileTransitionManager()
        {
            _tileStates = new Dictionary<string, TileState>();

            _hideTileContent = CreateHideTileContentStoryboard();
            _showTileContent = CreateShowTileContentStoryboard();

            _hideTileContent.Completed += HideTileContent_Completed;
        }

        #endregion

        #region Public Methods

        public void DoTransition(TileTransitionParameters parameters)
        {
            if (ParametersAreValid(parameters))
            {
                _currentParameters = parameters;
                HideTileContent();
            }
            else
            {
                throw new InvalidOperationException(InvalidParametersError);
            }
        }

        #endregion

        #region Event Handlers

        private void HideTileContent_Completed(object sender, EventArgs e)
        {
            switch (_currentParameters.TransitionType)
            {
                case TileTransitionType.Maximize:
                    //If there's already a maximized tile we need to put it back to its minimized state.
                    var existingMaximized = GetExistingMaximizedTile();
                    if (existingMaximized != null)
                    {
                        var existingState = GetTileState(existingMaximized.Key);
                        if (existingState != null)
                        {
                            MinimizeTile(existingMaximized, existingState);
                        }
                    }

                    StoreCurrentTileState();
                    MaximizeCurrentTile();
                    ShowTileContent();
                    break;
                case TileTransitionType.Minimize:
                    var state = GetCurrentTileState();
                    if (state != null)
                    {
                        MinimizeCurrentTile(state);
                        ShowTileContent();
                    }
                    break;
            }
        }

        #endregion

        #region Private Methods

        private Storyboard CreateHideTileContentStoryboard()
        {
            var storyboard = new Storyboard();
            var animation = new DoubleAnimation(0, TimeSpan.FromSeconds(.1))
            {
                EasingFunction = new CubicEase()
            };

            Storyboard.SetTargetProperty(storyboard, new PropertyPath("(FrameworkElement.Opacity)"));
            storyboard.Children.Add(animation);

            return storyboard;
        }

        private Storyboard CreateShowTileContentStoryboard()
        {
            var storyboard = new Storyboard();
            var animation = new DoubleAnimation(1, TimeSpan.FromSeconds(.2))
            {
                EasingFunction = new CubicEase()
            };

            Storyboard.SetTargetProperty(storyboard, new PropertyPath("(FrameworkElement.Opacity)"));
            storyboard.Children.Add(animation);

            return storyboard;
        }

        private bool ParametersAreValid(TileTransitionParameters parameters)
        {
            return parameters != null
                && parameters.Tile != null
                && !string.IsNullOrWhiteSpace(parameters.Tile.Key)
                && parameters.TileContentContainer != null;
        }

        private void HideTileContent()
        {
            _currentParameters.TileContentContainer.BeginStoryboard(_hideTileContent);
        }

        private void ShowTileContent()
        {
            _currentParameters.TileContentContainer.BeginStoryboard(_showTileContent);
        }

        private void StoreCurrentTileState()
        {
            var tileState = new TileState
            {
                ZIndex = Panel.GetZIndex(_currentParameters.Tile),
                Row = Grid.GetRow(_currentParameters.Tile),
                Column = Grid.GetColumn(_currentParameters.Tile),
                RowSpan = Grid.GetRowSpan(_currentParameters.Tile),
                ColumnSpan = Grid.GetColumnSpan(_currentParameters.Tile)
            };

            if (_tileStates.ContainsKey(_currentParameters.Tile.Key))
            {
                _tileStates.Remove(_currentParameters.Tile.Key);
            }

            _tileStates.Add(_currentParameters.Tile.Key, tileState);
        }

        private TileState GetCurrentTileState()
        {
            return GetTileState(_currentParameters.Tile.Key);
        }

        private TileState GetTileState(string tileKey)
        {
            TileState state = null;
            if (_tileStates.ContainsKey(tileKey))
            {
                state = _tileStates[tileKey];
            }

            return state;
        }

        private void MaximizeCurrentTile()
        {
            //Give users a chance to swap out tile content.
            if (_currentParameters.MaximizingCallback != null)
            {
                _currentParameters.MaximizingCallback.Invoke(_currentParameters.Tile.Key);
            }

            Panel.SetZIndex(_currentParameters.Tile, MaximizedZIndex);
            Grid.SetRow(_currentParameters.Tile, 0);
            Grid.SetColumn(_currentParameters.Tile, 0);
            if (_currentParameters.TileContentContainer.RowDefinitions.Count > 0)
            {
                Grid.SetRowSpan(_currentParameters.Tile, _currentParameters.TileContentContainer.RowDefinitions.Count);
            }
            if(_currentParameters.TileContentContainer.ColumnDefinitions.Count>0)
            {
                Grid.SetColumnSpan(_currentParameters.Tile, _currentParameters.TileContentContainer.ColumnDefinitions.Count);
            }
            _currentParameters.Tile.IsMaximized = true;
        }

        private void MinimizeCurrentTile(TileState state)
        {
            MinimizeTile(_currentParameters.Tile, state);
        }

        private void MinimizeTile(DashboardTile tile, TileState state)
        {
            //Give users a chance to swap out tile content.
            if (_currentParameters.MinimizingCallback != null)
            {
                _currentParameters.MinimizingCallback.Invoke(tile.Key);
            }

            Panel.SetZIndex(tile, state.ZIndex);
            Grid.SetRow(tile, state.Row);
            Grid.SetColumn(tile, state.Column);
            Grid.SetRowSpan(tile, state.RowSpan);
            Grid.SetColumnSpan(tile, state.ColumnSpan);
            tile.IsMaximized = false;
        }

        private DashboardTile GetExistingMaximizedTile()
        {
            var tiles = new DashboardTile[_currentParameters.TileContentContainer.Children.Count];
            _currentParameters.TileContentContainer.Children.CopyTo(tiles, 0);

            return tiles.FirstOrDefault(tile => tile.IsMaximized);
        }

        #endregion
    }
}
