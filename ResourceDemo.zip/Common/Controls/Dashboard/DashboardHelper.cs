﻿using System.Windows;
using System.Windows.Media;

namespace VShips.Framework.Resource.Common.Controls.Dashboard
{
    public static class DashboardHelper
    {
        public static Dashboard GetDashboard(this DependencyObject child)
        {
            if (child == null)
            {
                return null;
            }

            var parent = VisualTreeHelper.GetParent(child);
            Dashboard result = null;
            var found = false;
            while (parent != null && !found)
            {
                result = parent as Dashboard;
                found = result != null;
                if (!found)
                {
                    parent = VisualTreeHelper.GetParent(parent);
                }
            }

            return result;
        }
    }
}
