﻿using System.Windows.Controls;
using System.Windows.Media;

namespace VShips.Framework.Resource.Common.Controls.Dashboard
{
    public class DashboardGrid : Grid
    {
        #region Protected Methods

        protected override void OnRender(DrawingContext dc)
        {
            base.OnRender(dc);

            var dashboard = this.GetDashboard();
            if (dashboard != null)
            {
                dashboard.RegisterGrid(this);
            }
        }

        #endregion
    }
}
