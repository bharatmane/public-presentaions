﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using VShips.Framework.Resource.Common.Controls.Dashboard.Transition;

namespace VShips.Framework.Resource.Common.Controls.Dashboard
{
    public class Dashboard: ContentControl
    {
        #region Fields

        private const string TileContainerPartName = "TileContainerPart";
        private const string TopContainerPartName = "TopContainerPart";
        private const string TopModalBackgroundPartName = "TopModalBackgroundPart";
        private const string TemplatePartErrorMessage = " is missing from the control template.";

        private readonly Dictionary<string, DashboardTile> _tiles;
        private readonly TileTransitionManager _tileTransitionManager;
        private readonly TopTransitionManager _topTransitionManager;

        private ContentControl _topContainerPart;
        private Grid _topModalBackgroundPart;
        private ContentPresenter _tileContainerPart;

        private DashboardGrid _tileGrid;
        private bool _initialSizeSet, _isInternalTransition;

        #endregion

        #region Constructor

        static Dashboard()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Dashboard), new FrameworkPropertyMetadata(typeof(Dashboard)));
        }

        public Dashboard()
        {
            _tiles = new Dictionary<string, DashboardTile>();
            _tileTransitionManager = new TileTransitionManager();
            _topTransitionManager = new TopTransitionManager();
        }

        #endregion

        #region Properties

        #region Attached

        #endregion

        #region Dependency

        public static readonly DependencyProperty HeaderProperty =
           DependencyProperty.Register("Header", typeof(object), typeof(Dashboard), new PropertyMetadata(null));

        public object Header
        {
            get { return (object)GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        public static readonly DependencyProperty TopProperty =
            DependencyProperty.Register("Top", typeof(object), typeof(Dashboard), new PropertyMetadata(null));

        public object Top
        {
            get { return (object)GetValue(TopProperty); }
            set { SetValue(TopProperty, value); }
        }

        public static readonly DependencyProperty LeftProperty =
            DependencyProperty.Register("Left", typeof(object), typeof(Dashboard), new PropertyMetadata(null));

        public object Left
        {
            get { return (object)GetValue(LeftProperty); }
            set { SetValue(LeftProperty, value); }
        }

        public static readonly DependencyProperty IsTopExpandedProperty =
            DependencyProperty.Register("IsTopExpanded", typeof(bool), typeof(Dashboard),
                new FrameworkPropertyMetadata(false, OnIsTopExpandedChanged) { BindsTwoWayByDefault = true });

        private static void OnIsTopExpandedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as Dashboard;
            if (control != null)
            {
                var expand = (bool)e.NewValue;
                if (expand)
                {
                    control.ExpandTop();
                }
                else
                {
                    control.CollapseTop();
                }
            }
        }

        public bool IsTopExpanded
        {
            get { return (bool)GetValue(IsTopExpandedProperty); }
            set { SetValue(IsTopExpandedProperty, value); }
        }

        public static readonly DependencyProperty TopCollapsedHeightProperty =
            DependencyProperty.Register("TopCollapsedHeight", typeof(double), typeof(Dashboard), new PropertyMetadata(0d));

        public double TopCollapsedHeight
        {
            get { return (double)GetValue(TopCollapsedHeightProperty); }
            set { SetValue(TopCollapsedHeightProperty, value); }
        }

        public static readonly DependencyProperty TopExpandedHeightProperty =
            DependencyProperty.Register("TopExpandedHeight", typeof(double), typeof(Dashboard), new PropertyMetadata(0d));

        public double TopExpandedHeight
        {
            get { return (double)GetValue(TopExpandedHeightProperty); }
            set { SetValue(TopExpandedHeightProperty, value); }
        }

        public static readonly DependencyProperty MaximizedTileKeyProperty =
            DependencyProperty.Register("MaximizedTileKey", typeof(string), typeof(Dashboard),
                new FrameworkPropertyMetadata(null, OnMaximizedTileKeyChanged) { BindsTwoWayByDefault = true });

        private static void OnMaximizedTileKeyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as Dashboard;
            if (control != null && !control._isInternalTransition)
            {
                var newKey = e.NewValue as string;
                if (newKey != null)
                {
                    var tile = control.GetTileByKey(newKey);
                    control.MaximizeTile(tile);
                }
                else
                {
                    var oldKey = e.NewValue as string;
                    var tile = control.GetTileByKey(oldKey);
                    control.MinimizeTile(tile);
                }
            }
        }

        public string MaximizedTileKey
        {
            get { return (string)GetValue(MaximizedTileKeyProperty); }
            set { SetValue(MaximizedTileKeyProperty, value); }
        }

        public static readonly DependencyProperty MaximizingTileCommandProperty =
           DependencyProperty.Register("MaximizingTileCommand", typeof(ICommand), typeof(Dashboard), new PropertyMetadata(null));

        public ICommand MaximizingTileCommand
        {
            get { return (ICommand)GetValue(MaximizingTileCommandProperty); }
            set { SetValue(MaximizingTileCommandProperty, value); }
        }

        public static readonly DependencyProperty MinimizingTileCommandProperty =
            DependencyProperty.Register("MinimizingTileCommand", typeof(ICommand), typeof(Dashboard), new PropertyMetadata(null));

        public ICommand MinimizingTileCommand
        {
            get { return (ICommand)GetValue(MinimizingTileCommandProperty); }
            set { SetValue(MinimizingTileCommandProperty, value); }
        }

        #endregion

        public Thickness ContentMargin { get; set; }

        #endregion

        #region Public Methods

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            _tileContainerPart = Template.FindName(TileContainerPartName, this) as ContentPresenter;
            if (_tileContainerPart == null)
            {
                throw new InvalidOperationException(string.Format("{0}{1}", TileContainerPartName, TemplatePartErrorMessage));
            }

            _topContainerPart = Template.FindName(TopContainerPartName, this) as ContentControl;
            if (_topContainerPart == null)
            {
                throw new InvalidOperationException(string.Format("{0}{1}", TileContainerPartName, TemplatePartErrorMessage));
            }

            _topModalBackgroundPart = Template.FindName(TopModalBackgroundPartName, this) as Grid;
            if (_topModalBackgroundPart == null)
            {
                throw new InvalidOperationException(string.Format("{0}{1}", TileContainerPartName, TemplatePartErrorMessage));
            }

            _topContainerPart.SizeChanged += TopContainerPart_SizeChanged;
        }

        public void RegisterGrid(DashboardGrid grid)
        {
            if (grid != null)
            {
                _tileGrid = grid;
            }
        }

        public void RegisterTile(DashboardTile tile)
        {
            if (tile != null && !string.IsNullOrWhiteSpace(tile.Key))
            {
                if (_tiles.ContainsKey(tile.Key))
                {
                    _tiles.Remove(tile.Key);
                }

                _tiles.Add(tile.Key, tile);

                tile.TileMaximize += Tile_Maximize;
                tile.TileMinimize += Tile_Minimize;
            }
        }

        #endregion

        #region Event Handlers

        private void TopContainerPart_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (!_initialSizeSet)
            {
                _tileContainerPart.Margin = new Thickness(ContentMargin.Left, ContentMargin.Top + e.NewSize.Height, ContentMargin.Right, ContentMargin.Bottom);

                _initialSizeSet = true;
            }
        }

        private void Tile_Maximize(object sender, EventArgs e)
        {
            var tile = (DashboardTile)sender;
            MaximizeTile(tile);

            _isInternalTransition = true;
            MaximizedTileKey = tile.Key;
            _isInternalTransition = false;
        }

        private void Tile_Minimize(object sender, EventArgs e)
        {
            var tile = (DashboardTile)sender;
            MinimizeTile(tile);

            _isInternalTransition = true;
            MaximizedTileKey = null;
            _isInternalTransition = false;
        }

        #endregion

        #region Private Methods

        private DashboardTile GetTileByKey(string tileKey)
        {
            var matchingTile = _tiles.FirstOrDefault(tile => tile.Key == tileKey);
            return matchingTile.Key != default(string) ? matchingTile.Value : null;
        }

        private void MaximizeTileByKey(string tileKey)
        {
            var matchingTile = _tiles.FirstOrDefault(tile => tile.Key == tileKey);
            if (matchingTile.Key != default(string))
            {
                MaximizeTile(matchingTile.Value);
            }
        }

        private void MaximizeTile(DashboardTile tile)
        {
            if (tile != null && !tile.IsMaximized)
            {
                var parameters = new TileTransitionParameters
                {
                    Tile = tile,
                    TileContentContainer = _tileGrid,
                    TransitionType = TileTransitionType.Maximize,
                    MaximizingCallback = OnMaximizingTile,
                    MinimizingCallback = OnMinimizingTile
                };

                _tileTransitionManager.DoTransition(parameters);
            }
        }

        private void MinimizeTile(DashboardTile tile)
        {
            if (tile != null && tile.IsMaximized)
            {
                var parameters = new TileTransitionParameters
                {
                    Tile = tile,
                    TileContentContainer = _tileGrid,
                    TransitionType = TileTransitionType.Minimize,
                    MaximizingCallback = OnMaximizingTile,
                    MinimizingCallback = OnMinimizingTile
                };

                _tileTransitionManager.DoTransition(parameters);
            }
        }

        private void OnMaximizingTile(string tileKey)
        {
            if (MaximizingTileCommand != null && MaximizingTileCommand.CanExecute(tileKey))
            {
                MaximizingTileCommand.Execute(tileKey);
            }
        }

        private void OnMinimizingTile(string tileKey)
        {
            if (MinimizingTileCommand != null && MinimizingTileCommand.CanExecute(tileKey))
            {
                MinimizingTileCommand.Execute(tileKey);
            }
        }

        private void ExpandTop()
        {
            _topTransitionManager.DoTransition(new TopTransitionParameters
            {
                TransitionType = TopTransitionType.Expand,
                TopContent = _topContainerPart,
                TopModalBackground = _topModalBackgroundPart,
                TransitionToHeight = TopExpandedHeight
            });
        }

        private void CollapseTop()
        {
            _topTransitionManager.DoTransition(new TopTransitionParameters
            {
                TransitionType = TopTransitionType.Collapse,
                TopContent = _topContainerPart,
                TopModalBackground = _topModalBackgroundPart,
                TransitionToHeight = TopCollapsedHeight
            });
        }

        #endregion


    }
}
