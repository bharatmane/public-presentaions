﻿namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    public enum CalendarViewType
    {
        Daily, Weekly, BiWeekly, Monthly
    }
}
