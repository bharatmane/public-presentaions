﻿using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Resource.Common.Extensions;

namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    internal class CalendarItemTemplateSelector : DataTemplateSelector
    {
        #region Public Methods

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            DataTemplate template = null;
            var dashboard = container.GetAncestorByType<DashboardCalendar>();
            if(dashboard != null)
            {
                switch(dashboard.ViewType)
                {
                    case CalendarViewType.Daily:
                        template = dashboard.DailyContentTemplate;
                        break;
                    case CalendarViewType.Weekly:
                        template = dashboard.WeeklyContentTemplate;
                        break;
                    case CalendarViewType.BiWeekly:
                        template = dashboard.BiWeeklyContentTemplate;
                        break;
                    case CalendarViewType.Monthly:
                        template = dashboard.MonthlyContentTemplate;
                        break;
                }
            }

            return template ?? base.SelectTemplate(item, container);
        }

        #endregion
    }
}
