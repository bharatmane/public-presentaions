﻿using System;
using System.Collections;
using System.Collections.ObjectModel;

namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    public class CalendarConfigurationInfo
    {
        #region Properties

        public DateTime StartDate { get; set; }

        public int DayCount { get; set; }

        public ObservableCollection<DashboardCalendarItem> InternalCollection { get; set; }

        public IEnumerable ExternalCollection { get; set; }

        #endregion
    }
}
