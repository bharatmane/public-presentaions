﻿using GalaSoft.MvvmLight.Command;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;

namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    public class DashboardCalendar : Control
    {
        #region Fields

        private const string CalendarContentPartName = @"CalendarContentPart";
        private const string ScrollLeftButtonPartName = @"ScrollLeftButtonPart";
        private const string ScrollRightButtonPartName = @"ScrollRightButtonPart";
        private const string TemplatePartMissingError = "is missing from the template.";

        private ContentControl _calendarContentPart;

        #endregion

        #region Constructor

        static DashboardCalendar()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DashboardCalendar), new FrameworkPropertyMetadata(typeof(DashboardCalendar)));
        }

        public DashboardCalendar()
        {

        }

        #endregion

        #region Properties

        public static readonly DependencyProperty ViewTypeProperty =
            DependencyProperty.Register("ViewType", typeof(CalendarViewType), typeof(DashboardCalendar), new PropertyMetadata(CalendarViewType.Daily, OnCalendarViewTypeChanged));

        private static void OnCalendarViewTypeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if (control != null)
            {
                control.ChangeViewType((CalendarViewType)e.OldValue, (CalendarViewType)e.NewValue);
            }
        }

        public CalendarViewType ViewType
        {
            get { return (CalendarViewType)GetValue(ViewTypeProperty); }
            set { SetValue(ViewTypeProperty, value); }
        }

        public static readonly DependencyProperty NavigateToDateProperty = 
            DependencyProperty.Register("NavigateToDate", typeof(DateTime?), typeof(DashboardCalendar), 
                new FrameworkPropertyMetadata(null, OnNavigateToDateChanged) { BindsTwoWayByDefault = true, DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });

        private static void OnNavigateToDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if (control != null)
            {
                var newValue = (DateTime?)e.NewValue;
                if(newValue.HasValue)
                {
                    control.NavigateToDay(newValue.Value);
                }
            }
        }

        public DateTime? NavigateToDate
        {
            get { return (DateTime?)GetValue(NavigateToDateProperty); }
            set { SetValue(NavigateToDateProperty, value); }
        }

        public static readonly DependencyProperty CurrentDateProperty =
            DependencyProperty.Register("CurrentDate", typeof(DateTime?), typeof(DashboardCalendar),
                new FrameworkPropertyMetadata(DateTime.Today, OnCurrentDateChanged) { BindsTwoWayByDefault = true, DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });

        private static void OnCurrentDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if (control != null)
            {
                var newValue = (DateTime?)e.NewValue;
                if (newValue.HasValue)
                {
                    control.NavigateToDay(newValue.Value);

                    
                }
            }
        }

        public DateTime? CurrentDate
        {
            get { return (DateTime?)GetValue(CurrentDateProperty); }
            set { SetValue(CurrentDateProperty, value); }
        }


        public static readonly DependencyProperty DateMemberPathProperty = 
            DependencyProperty.Register("DateMemberPath", typeof(string), typeof(DashboardCalendar), new PropertyMetadata(null));

        public string DateMemberPath
        {
            get { return ( string)GetValue(DateMemberPathProperty); }
            set { SetValue(DateMemberPathProperty, value); }
        }

        public static readonly DependencyProperty CommandProperty =
        DependencyProperty.Register(
        "Command",
        typeof(RelayCommand),
        typeof(DashboardCalendar));

        public RelayCommand Command
        {
            get
            {
                return (RelayCommand)GetValue(CommandProperty);
            }

            set
            {
                SetValue(CommandProperty, value);
            }
        }

        #region Internal Collections

        public static readonly DependencyPropertyKey DailyCalendarItemsPropertyKey =
            DependencyProperty.RegisterReadOnly("DailyCalendarItems", typeof(ObservableCollection<DashboardCalendarItem>),
                typeof(DashboardCalendar), new PropertyMetadata(new ObservableCollection<DashboardCalendarItem>()));

        public static readonly DependencyProperty DailyCalendarItemsProperty = DailyCalendarItemsPropertyKey.DependencyProperty;

        public ObservableCollection<DashboardCalendarItem> DailyCalendarItems
        {
            get { return (ObservableCollection<DashboardCalendarItem>)GetValue(DailyCalendarItemsProperty); }
            protected set { SetValue(DailyCalendarItemsPropertyKey, value); }
        }

        public static readonly DependencyPropertyKey WeeklyCalendarItemsPropertyKey =
            DependencyProperty.RegisterReadOnly("WeeklyCalendarItems", typeof(ObservableCollection<DashboardCalendarItem>),
                typeof(DashboardCalendar), new PropertyMetadata(new ObservableCollection<DashboardCalendarItem>()));

        public static readonly DependencyProperty WeeklyCalendarItemsProperty = WeeklyCalendarItemsPropertyKey.DependencyProperty;

        public ObservableCollection<DashboardCalendarItem> WeeklyCalendarItems
        {
            get { return (ObservableCollection<DashboardCalendarItem>)GetValue(WeeklyCalendarItemsProperty); }
            protected set { SetValue(WeeklyCalendarItemsPropertyKey, value); }
        }

        public static readonly DependencyPropertyKey BiWeeklyCalendarItemsPropertyKey =
            DependencyProperty.RegisterReadOnly("BiWeeklyCalendarItems", typeof(ObservableCollection<DashboardCalendarItem>),
                typeof(DashboardCalendar), new PropertyMetadata(new ObservableCollection<DashboardCalendarItem>()));

        public static readonly DependencyProperty BiWeeklyCalendarItemsProperty = BiWeeklyCalendarItemsPropertyKey.DependencyProperty;

        public ObservableCollection<DashboardCalendarItem> BiWeeklyCalendarItems
        {
            get { return (ObservableCollection<DashboardCalendarItem>)GetValue(BiWeeklyCalendarItemsProperty); }
            protected set { SetValue(BiWeeklyCalendarItemsPropertyKey, value); }
        }

        public static readonly DependencyPropertyKey MonthlyCalendarItemsPropertyKey =
            DependencyProperty.RegisterReadOnly("MonthlyCalendarItems", typeof(ObservableCollection<DashboardCalendarItem>),
                typeof(DashboardCalendar), new PropertyMetadata(new ObservableCollection<DashboardCalendarItem>()));

        public static readonly DependencyProperty MonthlyCalendarItemsProperty = MonthlyCalendarItemsPropertyKey.DependencyProperty;

        public ObservableCollection<DashboardCalendarItem> MonthlyCalendarItems
        {
            get { return (ObservableCollection<DashboardCalendarItem>)GetValue(MonthlyCalendarItemsProperty); }
            protected set { SetValue(MonthlyCalendarItemsPropertyKey, value); }
        }

        #endregion

        #region External Collections

        public static readonly DependencyProperty DailyItemsSourceProperty =
            DependencyProperty.Register("DailyItemsSource", typeof(IEnumerable), typeof(DashboardCalendar), new PropertyMetadata(null, OnDailyItemsSourceChanged));

        private static void OnDailyItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if (control != null)
            {
                control.UpdateDataSource(CalendarViewType.Daily);
            }
        }

        public IEnumerable DailyItemsSource
        {
            get { return (IEnumerable)GetValue(DailyItemsSourceProperty); }
            set { SetValue(DailyItemsSourceProperty, value); }
        }

        public static readonly DependencyProperty WeekyItemsSourceProperty =
            DependencyProperty.Register("WeeklyItemsSource", typeof(IEnumerable), typeof(DashboardCalendar), new PropertyMetadata(null, OnWeeklyItemsSourceChanged));

        private static void OnWeeklyItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if(control != null)
            {
                control.UpdateDataSource(CalendarViewType.Weekly);
            }
        }

        public IEnumerable WeeklyItemsSource
        {
            get { return (IEnumerable)GetValue(WeekyItemsSourceProperty); }
            set { SetValue(WeekyItemsSourceProperty, value); }
        }

        public static readonly DependencyProperty BiWeeklyItemsSourceProperty =
            DependencyProperty.Register("BiWeeklyItemsSource", typeof(IEnumerable), typeof(DashboardCalendar), new PropertyMetadata(null, OnBiWeeklyItemsSourceChanged));

        private static void OnBiWeeklyItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if (control != null)
            {
                control.UpdateDataSource(CalendarViewType.BiWeekly);
            }
        }

        public IEnumerable BiWeeklyItemsSource
        {
            get { return (IEnumerable)GetValue(BiWeeklyItemsSourceProperty); }
            set { SetValue(BiWeeklyItemsSourceProperty, value); }
        }

        public static readonly DependencyProperty MonthlyItemsSourceProperty =
            DependencyProperty.Register("MonthlyItemsSource", typeof(IEnumerable), typeof(DashboardCalendar), new PropertyMetadata(null, OnMonthlyItemsSourceChanged));

        private static void OnMonthlyItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendar;
            if (control != null)
            {
                control.UpdateDataSource(CalendarViewType.Monthly);
            }
        }

        public IEnumerable MonthlyItemsSource
        {
            get { return (IEnumerable)GetValue(MonthlyItemsSourceProperty); }
            set { SetValue(MonthlyItemsSourceProperty, value); }
        }

        #endregion

        #region Content Templates

        public static readonly DependencyProperty DailyContentTemplateProperty =
            DependencyProperty.Register("DailyContentTemplate", typeof(DataTemplate), typeof(DashboardCalendar), new PropertyMetadata(null));

        public DataTemplate DailyContentTemplate
        {
            get { return (DataTemplate)GetValue(DailyContentTemplateProperty); }
            set { SetValue(DailyContentTemplateProperty, value); }
        }

        public static readonly DependencyProperty WeeklyContentTemplateProperty =
            DependencyProperty.Register("WeeklyContentTemplate", typeof(DataTemplate), typeof(DashboardCalendar), new PropertyMetadata(null));

        public DataTemplate WeeklyContentTemplate
        {
            get { return (DataTemplate)GetValue(WeeklyContentTemplateProperty); }
            set { SetValue(WeeklyContentTemplateProperty, value); }
        }

        public static readonly DependencyProperty BiWeeklyContentTemplateProperty =
            DependencyProperty.Register("BiWeeklyContentTemplate", typeof(DataTemplate), typeof(DashboardCalendar), new PropertyMetadata(null));

        public DataTemplate BiWeeklyContentTemplate
        {
            get { return (DataTemplate)GetValue(BiWeeklyContentTemplateProperty); }
            set { SetValue(BiWeeklyContentTemplateProperty, value); }
        }

        public static readonly DependencyProperty MonthlyContentTemplateProperty =
            DependencyProperty.Register("MonthlyContentTemplate", typeof(DataTemplate), typeof(DashboardCalendar), new PropertyMetadata(null));

        public DataTemplate MonthlyContentTemplate
        {
            get { return (DataTemplate)GetValue(MonthlyContentTemplateProperty); }
            set { SetValue(MonthlyContentTemplateProperty, value); }
        }

        #endregion

        #endregion

        #region Public Methods

        public override void OnApplyTemplate()
        {
            _calendarContentPart = Template.FindName(CalendarContentPartName, this) as ContentControl;
            if (_calendarContentPart == null)
            {
                throw new InvalidOperationException(string.Format("{0} {1}",CalendarContentPartName, TemplatePartMissingError));
            }

            var scrollLeftButtonPart = Template.FindName(ScrollLeftButtonPartName, this) as ButtonBase;
            if (scrollLeftButtonPart == null)
            {
                throw new InvalidOperationException(string.Format("{0} {1}",ScrollLeftButtonPartName, TemplatePartMissingError));
            }

            var scrollRightButtonPart = Template.FindName(ScrollRightButtonPartName, this) as ButtonBase;
            if (scrollRightButtonPart == null)
            {
                throw new InvalidOperationException(string.Format("{0} {1}",ScrollRightButtonPartName, TemplatePartMissingError));
            }

            scrollLeftButtonPart.Click += ScrollLeftButtonPart_Click;
            scrollRightButtonPart.Click += ScrollRightButtonPart_Click;

            ChangeViewType(CalendarViewType.Monthly, CalendarViewType.Daily);
        }

        #endregion

        #region Event Handlers

        private void ScrollLeftButtonPart_Click(object sender, RoutedEventArgs e)
        {
            var previousDate = GetPreviousDateByViewType(ViewType);

            ChangeViewDate(previousDate);
        }

        private void ScrollRightButtonPart_Click(object sender, RoutedEventArgs e)
        {
            var nextDate = GetNextDateByViewType(ViewType);
            
            ChangeViewDate(nextDate);
        }

        #endregion

        #region Private Methods

        private void ChangeViewType(CalendarViewType oldViewType, CalendarViewType newViewType)
        {
            if (oldViewType != newViewType)
            {
                var currentItemStartDate = GetStartDateByViewType(oldViewType);
                if (currentItemStartDate == DateTime.MinValue)
                {
                    currentItemStartDate = DateTime.Now.Date;
                }
                else
                {
                    var oldInternalCollection = GetInternalCollectionByViewType(oldViewType);
                    if (oldInternalCollection.Any(item => item.Date == DateTime.Now.Date))
                    {
                        currentItemStartDate = DateTime.Now.Date;
                    }
                    else if (oldViewType == CalendarViewType.Monthly && currentItemStartDate.Day != 1)
                    {
                        //First of the next month (should be month displayed)
                        currentItemStartDate = currentItemStartDate.AddDays(-(currentItemStartDate.Day - 1)).AddMonths(1);
                    }
                }

                var newItemStartDate = GetItemStartDate(newViewType, currentItemStartDate);
                var internalCollection = GetInternalCollectionByViewType(newViewType);
                var itemCount = GetItemCount(newViewType, newItemStartDate);
                if (internalCollection.Count != itemCount)
                {
                    InitializeInternalCollection(internalCollection, itemCount);
                }

                PopulateInternalCollection(internalCollection, newItemStartDate, newViewType);
                PopulateCalendarItemContent(internalCollection, newViewType);

                _calendarContentPart.Content = newViewType;
            }
        }

        private void ChangeViewDate(DateTime date)
        {
            if (date != DateTime.MinValue)
            {
                var internalCollection = GetInternalCollectionByViewType(ViewType);
                var itemCount = GetItemCount(ViewType, date);
                if (internalCollection.Count != itemCount)
                {
                    InitializeInternalCollection(internalCollection, itemCount);
                }

                PopulateInternalCollection(internalCollection, date, ViewType);
                PopulateCalendarItemContent(internalCollection, ViewType);
            }
        }

        private void PopulateInternalCollection(IList<DashboardCalendarItem> collection, DateTime startDate, CalendarViewType viewType)
        {
            var inCurrentMonth = false;
            var count = collection.Count;
            for(var i = 0; i < count; i++)
            {
                var calendarItem = collection[i];
                calendarItem.Date = startDate.Date;
                startDate = startDate.AddDays(1);

                if(calendarItem.Date.Day == 1)
                {
                    inCurrentMonth = !inCurrentMonth;
                }

                calendarItem.IsCurrentMonth = inCurrentMonth;

                if (viewType != CalendarViewType.Daily && viewType != CalendarViewType.Weekly)
                {
                    calendarItem.IsLeftEdge = i % 7 == 0;
                    calendarItem.IsRightEdge = (i - 6) % 7 == 0;
                    calendarItem.IsTopEdge = i < 7;
                    calendarItem.IsBottomEdge = i >= count - 7;
                }
            }
        }

        private void PopulateCalendarItemContent(IList<DashboardCalendarItem> collection, CalendarViewType viewType)
        {
            List<object> contentCollection = null;
            switch (viewType)
            {
                case CalendarViewType.Daily:
                    if (DailyItemsSource != null)
                    {
                        contentCollection = DailyItemsSource.OfType<object>().ToList();
                    }
                    break;
                case CalendarViewType.Weekly:
                    if (WeeklyItemsSource != null)
                    {
                        contentCollection = WeeklyItemsSource.OfType<object>().ToList();
                    }
                    break;
                case CalendarViewType.BiWeekly:
                    if (BiWeeklyItemsSource != null)
                    {
                        contentCollection = BiWeeklyItemsSource.OfType<object>().ToList();
                    }
                    break;
                case CalendarViewType.Monthly:
                    if (MonthlyItemsSource != null)
                    {
                        contentCollection = MonthlyItemsSource.OfType<object>().ToList();
                    }
                    break;
            }

            var dateProperty = contentCollection != null && contentCollection.Count > 0
                ? contentCollection[0].GetType().GetProperty(DateMemberPath)
                : null;

            var count = collection.Count;
            foreach (var calendarItem in collection)
            {
                if (dateProperty != null && contentCollection != null)
                {
                    calendarItem.Content = contentCollection.Where(
                        contentMember => (DateTime)dateProperty.GetValue(contentMember) == calendarItem.Date);
                }
            }
        }

        private void InitializeInternalCollection(IList<DashboardCalendarItem> collection, int count)
        {
            if (collection == null)
            {
                collection = new ObservableCollection<DashboardCalendarItem>();
            }

            collection.Clear();

            for (var i = 0; i < count; i++)
            {
                collection.Add(new DashboardCalendarItem());
            }
        }

        private DateTime GetStartDateByViewType(CalendarViewType viewType)
        {
            var collection = GetInternalCollectionByViewType(viewType);
            return collection != null && collection.Count > 0
                ? collection.First().Date.Date
                : DateTime.MinValue;
        }

        private DateTime GetItemStartDate(CalendarViewType viewType, DateTime date)
        {
            var returnDate = date;
            switch (viewType)
            {
                case CalendarViewType.Weekly:
                case CalendarViewType.BiWeekly:
                    returnDate = GetFirstDayOfWeek(date);
                    CurrentDate = returnDate;
                    break;
                case CalendarViewType.Monthly:
                    var firstDayOfMonth = GetFirstDayOfMonth(date);
                    CurrentDate = firstDayOfMonth;
                    returnDate = GetFirstDayOfWeek(firstDayOfMonth);
                    break;
            }

            return returnDate;
        }

        private ObservableCollection<DashboardCalendarItem> GetInternalCollectionByViewType(CalendarViewType viewType)
        {
            ObservableCollection<DashboardCalendarItem> collection = null;
            switch (viewType)
            {
                case CalendarViewType.Daily:
                    collection = DailyCalendarItems;
                    break;
                case CalendarViewType.Weekly:
                    collection = WeeklyCalendarItems;
                    break;
                case CalendarViewType.BiWeekly:
                    collection = BiWeeklyCalendarItems;
                    break;
                case CalendarViewType.Monthly:
                    collection = MonthlyCalendarItems;
                    break;
            }

            return collection;
        }

        private int GetItemCount(CalendarViewType viewType, DateTime date)
        {
            var count = 0;
            switch (viewType)
            {
                case CalendarViewType.Daily:
                    count = 1;
                    break;
                case CalendarViewType.Weekly:
                    count = 7;
                    break;
                case CalendarViewType.BiWeekly:
                    count = 14;
                    break;
                case CalendarViewType.Monthly:
                    count = GetItemCountForMonth(date);
                    break;
            }

            return count;
        }

        private DateTime GetFirstDayOfWeek(DateTime date)
        {
            return date.AddDays(-(int)date.DayOfWeek);
        }

        private DateTime GetFirstDayOfMonth(DateTime date)
        {
            return date.AddDays(-(date.Day - 1));
        }

        private int GetItemCountForMonth(DateTime date)
        {
            //double checking to make sure, if date is already the first day of the week (generally it will be), no harm done.
            var startDate = GetFirstDayOfWeek(date);

            var multiplier = 1;
            var trackDate = startDate.AddDays(7); //should always get us to the first saturday of the month
            var month = trackDate.Month;
            do
            {
                trackDate = trackDate.AddDays(7);
                multiplier++;
            }
            while (trackDate.Month == month);

            return 7 * multiplier;
        }

        private DateTime GetNextDateByViewType(CalendarViewType viewType)
        {
            var nextDate = DateTime.MinValue;
            var collection = GetInternalCollectionByViewType(viewType);
            if (collection != null)
            {
                nextDate = collection.Last().Date.AddDays(1);

                if (viewType == CalendarViewType.Monthly)
                {
                    nextDate = GetItemStartDate(ViewType, nextDate);
                }
                else
                {
                    CurrentDate = nextDate;
                }
            }

            return nextDate;
        }

        private DateTime GetPreviousDateByViewType(CalendarViewType viewType)
        {
            DateTime previousDate = DateTime.MinValue;
            var collection = GetInternalCollectionByViewType(viewType);
            var currentDate = collection.First().Date;
            switch (viewType)
            {
                case CalendarViewType.Daily:
                    previousDate = currentDate.AddDays(-1);
                    CurrentDate = previousDate;
                    break;
                case CalendarViewType.Weekly:
                    previousDate = currentDate.AddDays(-7);
                    CurrentDate = previousDate;
                    break;
                case CalendarViewType.BiWeekly:
                    previousDate = currentDate.AddDays(-14);
                    CurrentDate = previousDate;
                    break;
                case CalendarViewType.Monthly:
                    previousDate = currentDate.AddDays(-1);
                    CurrentDate = previousDate;
                    previousDate = GetItemStartDate(viewType, previousDate);
                    break;
            }

            return previousDate;
        }

        private void NavigateToDay(DateTime date)
        {
            var collection = GetInternalCollectionByViewType(ViewType);
            var exists = collection.Any(item => item.Date.Date == date.Date);
            if (!exists)
            {
                var startDate = GetItemStartDate(ViewType, date);
                ChangeViewDate(startDate);
            }

            if (Command != null && Command.CanExecute(null))
                Command.Execute(null);
        }

        private void UpdateDataSource(CalendarViewType viewType)
        {
            if(viewType == ViewType) //if the current view type is not this one, then we don't need to update because they aren't in view
            {
                var collection = GetInternalCollectionByViewType(viewType);
                PopulateCalendarItemContent(collection, viewType);
            }
        }      

        #endregion
    }
}
