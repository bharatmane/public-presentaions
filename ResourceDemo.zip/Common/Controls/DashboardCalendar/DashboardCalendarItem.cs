﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    public class DashboardCalendarItem : ContentControl
    {
        #region Constructor

        static DashboardCalendarItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DashboardCalendarItem), new FrameworkPropertyMetadata(typeof(DashboardCalendarItem)));
        }

        #endregion

        #region Properties

        public static readonly DependencyProperty DateProperty =
            DependencyProperty.Register("Date", typeof(DateTime), typeof(DashboardCalendarItem), new PropertyMetadata(DateTime.MinValue, OnDateChanged));

        private static void OnDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as DashboardCalendarItem;
            if (control != null)
            {
                control.DateText = control.CreateDateText();
                control.IsCurrentDay = ((DateTime)e.NewValue).Date == DateTime.Now.Date;
            }
        }

        public DateTime Date
        {
            get { return (DateTime)GetValue(DateProperty); }
            set { SetValue(DateProperty, value); }
        }

        public static readonly DependencyProperty DateTextProperty =
            DependencyProperty.Register("DateText", typeof(string), typeof(DashboardCalendarItem), new PropertyMetadata(null));

        public string DateText
        {
            get { return (string)GetValue(DateTextProperty); }
            set { SetValue(DateTextProperty, value); }
        }

        public static readonly DependencyProperty IsCurrentDayProperty =
            DependencyProperty.Register("IsCurrentDay", typeof(bool), typeof(DashboardCalendarItem), new PropertyMetadata(false));

        public bool IsCurrentDay
        {
            get { return (bool)GetValue(IsCurrentDayProperty); }
            set { SetValue(IsCurrentDayProperty, value); }
        }

        public static readonly DependencyProperty IsCurrentMonthProperty =
            DependencyProperty.Register("IsCurrentMonth", typeof(bool), typeof(DashboardCalendarItem), new PropertyMetadata(false));

        public bool IsCurrentMonth
        {
            get { return (bool)GetValue(IsCurrentMonthProperty); }
            set { SetValue(IsCurrentMonthProperty, value); }
        }

        #region Orientation

        public static readonly DependencyProperty IsLeftEdgeProperty = 
            DependencyProperty.Register("IsLeftEdge", typeof(bool), typeof(DashboardCalendarItem), new PropertyMetadata(false));

        public bool IsLeftEdge
        {
            get { return (bool)GetValue(IsLeftEdgeProperty); }
            set { SetValue(IsLeftEdgeProperty, value); }
        }

        public static readonly DependencyProperty IsRightEdgeProperty =
            DependencyProperty.Register("IsRightEdge", typeof(bool), typeof(DashboardCalendarItem), new PropertyMetadata(false));

        public bool IsRightEdge
        {
            get { return (bool)GetValue(IsRightEdgeProperty); }
            set { SetValue(IsRightEdgeProperty, value); }
        }

        public static readonly DependencyProperty IsTopEdgeProperty =
            DependencyProperty.Register("IsTopEdge", typeof(bool), typeof(DashboardCalendarItem), new PropertyMetadata(false));

        public bool IsTopEdge
        {
            get { return (bool)GetValue(IsTopEdgeProperty); }
            set { SetValue(IsTopEdgeProperty, value); }
        }

        public static readonly DependencyProperty IsBottomEdgeProperty =
            DependencyProperty.Register("IsBottomEdge", typeof(bool), typeof(DashboardCalendarItem), new PropertyMetadata(false));

        public bool IsBottomEdge
        {
            get { return (bool)GetValue(IsBottomEdgeProperty); }
            set { SetValue(IsBottomEdgeProperty, value); }
        }

        #endregion

        #endregion

        #region Protected Methods

        protected virtual string CreateDateText()
        {
            var dateText = GetDateText("MMM d");
            if (dateText != null)
            {
                dateText = dateText.ToUpper();
            }

            return dateText;
        }

        protected string GetDateText(string formatString)
        {
            string text = null;
            if (Date != null)
            {
                text = Date.ToString(formatString);
            }

            return text;
        }

        #endregion
    }
}
