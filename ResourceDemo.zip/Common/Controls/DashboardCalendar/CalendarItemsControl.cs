﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    public class CalendarItemsControl : ItemsControl
    {
        #region Protected Methods

        protected override DependencyObject GetContainerForItemOverride()
        {
            return new DashboardCalendarItem();
        }

        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is DashboardCalendarItem;
        }

        #endregion
    }
}
