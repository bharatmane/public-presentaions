﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Common.Controls.DashboardCalendar
{
    public class CalendarViewTypeTemplateSelector : DataTemplateSelector
    {
        #region Properties

        public DataTemplate DailyTemplate { get; set; }

        public DataTemplate WeeklyTemplate { get; set; }

        public DataTemplate BiWeeklyTemplate { get; set; }

        public DataTemplate MonthlyTemplate { get; set; }

        #endregion

        #region Public Methods

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            DataTemplate dataTemplate = null;
            if (item is CalendarViewType)
            {
                var viewType = (CalendarViewType)item;
                switch (viewType)
                {
                    case CalendarViewType.Daily:
                        dataTemplate = DailyTemplate;
                        break;
                    case CalendarViewType.Weekly:
                        dataTemplate = WeeklyTemplate;
                        break;
                    case CalendarViewType.BiWeekly:
                        dataTemplate = BiWeeklyTemplate;
                        break;
                    case CalendarViewType.Monthly:
                        dataTemplate = MonthlyTemplate;
                        break;
                }

            }

            return dataTemplate ?? base.SelectTemplate(item, container);
        }

        #endregion
    }
}
