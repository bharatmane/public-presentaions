﻿using System.Windows;
using System.Windows.Media;

namespace VShips.Framework.Resource.Common.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class VisualTreeExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TAncestor"></typeparam>
        /// <param name="dObj"></param>
        /// <returns></returns>
        public static TAncestor GetAncestorByType<TAncestor>(this DependencyObject dObj)
            where TAncestor : DependencyObject
        {
            if (dObj == null)
            {
                return null;
            }

            var parent = VisualTreeHelper.GetParent(dObj);
            TAncestor result = null;
            var found = false;
            while (parent != null && !found)
            {
                result = parent as TAncestor;
                found = result != null;
                if (!found)
                {
                    parent = VisualTreeHelper.GetParent(parent);
                }
            }

            return result;
        }
    }
}
