﻿using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VShips.Contracts.DtoClasses.ReportGroupLightTypes;
using VShips.Framework.Common.DataServices;
using VShips.Framework.Common.Model.Reports;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel.Menu;
using VShips.Framework.Resource.Controls;

namespace VShips.Framework.Resource.Common.Extensions
{
    /// <summary>
    /// This class is for Dynamic VRibbon Groups
    /// </summary>    
    public class DynamicVRibbonGroups
    {
        #region Methods

        /// <summary>
        /// Gets all groups.
        /// </summary>
        /// <returns>
        /// List of VRibbonGroup.
        /// </returns>
        public async Task<List<VRibbonGroup>> GetAllGroups()
        {
            List<VRibbonGroup> groupList = new List<VRibbonGroup>();
            var reportGroup = await GetReportRibbonGroup();

            if (reportGroup != null)
            {
                groupList.Add(reportGroup);
            }
            return groupList;
        }

        /// <summary>
        /// Gets the report ribbon group.
        /// </summary>
        /// <returns>
        /// An instance of VRibbonGroup.
        /// </returns>
        private async Task<VRibbonGroup> GetReportRibbonGroup()
        {
            VRibbonGroup ribbonGroup = new VRibbonGroup() { Header = "Report" };
            var menuItem = new MenuItem();
            var reportList = await InitialiseReportsListAsync();

            var items = new List<VRibbonReportViewModel>();
            if (reportList != null && reportList.Any())
            {
                foreach (var item in reportList)
                {
                    items.Add(new VRibbonReportViewModel() { Label = item.ReportName, Entity = item });
                }

                menuItem.Items.Add(new MenuItemDropDownButton("Reports", "ManifestGeometry", items.ToArray())
                {
                    DisplaySize = DisplaySize.Large
                });

                ribbonGroup.ItemsSource = menuItem.Items;
                return ribbonGroup;
            }

            return null;
        }

        /// <summary>
        /// Initialises the reports list asynchronous.
        /// </summary>
        /// <returns>
        /// List of Reports
        /// </returns>
        public async Task<List<Report>> InitialiseReportsListAsync()
        {
            var token = new CancellationToken();
            var service = ServiceLocator.Current.GetInstance<IDataService>();
            string module = ServiceLocator.Current.GetInstance<INavigationService>().ActiveContext.ModuleName;
            List<Report> reportList = new List<Report>();
            try
            {
                if (!string.IsNullOrEmpty(module))
                {                    
                    reportList = ServiceLocator.Current.GetInstance<IModuleService>().GetReports(module);
                }
            }
            catch (OperationCanceledException)
            {
            }
            return reportList;
        }

        #endregion
    }
}
