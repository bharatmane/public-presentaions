﻿using System.Windows;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// This class is used to store common constants
    /// </summary>
    public static class Constants
    {
        #region TargetNullValue
        /// <summary>
        /// The common target null value
        /// </summary>
        public static string CommonTargetNullValue = "";
        /// <summary>
        /// The numeric target null value
        /// </summary>
        public static string NumericTargetNullValue = "0";
        /// <summary>
        /// The common fallback value
        /// </summary>
        public static string ZeroTargetNullValue = "0";
        /// <summary>
        /// The false target null value
        /// </summary>
        public static string FalseTargetNullValue = "False";
        /// <summary>
        /// The true target null value
        /// </summary>
        public static string TrueTargetNullValue = "True";
        /// <summary>
        /// The collapsed target null value
        /// </summary>
        public static string CollapsedTargetNullValue = "Collapsed";
        /// <summary>
        /// The visible target null value
        /// </summary>
        public static string VisibleTargetNullValue = "Visible";
        /// <summary>
        /// The default currency target null value
        /// </summary>
        public static string DefaultCurrencyTargetNullValue = "USD";
        /// <summary>
        /// The decimal target null value
        /// </summary>
        public static string DecimalTargetNullValue = "0.00";
        /// <summary>
        /// The identifier target null value
        /// </summary>
        public static string IdTargetNullValue = "0000";
        /// <summary>
        /// The blank target null value
        /// </summary>
        public static string BlankTargetNullValue = "";       
        /// <summary>
        /// The missing target null value
        /// </summary>
        public static string MissingTargetNullValue = "Missing";
        /// <summary>
        /// The hidden target null value
        /// </summary>
        public static string HiddenTargetNullValue = "Hidden";
        /// <summary>
        /// The unknown target null value. Only used in maps as of now.
        /// </summary>
        public static string UnknownTargetNullValue = "Unknown";
        /// <summary>
        /// The date target null value
        /// </summary>
        public static string DateTargetNullValue = "";
        #endregion

        #region FallbackValue
        /// <summary>
        /// The common fallback value
        /// </summary>
        public static string CommonFallbackValue = "";
        /// <summary>
        /// The numeric fallback value
        /// </summary>
        public static string NumericFallbackValue = "0";
        /// <summary>
        /// The zero fallback value
        /// </summary>
        public static string ZeroFallbackValue = "0";
        /// <summary>
        /// The date fallback value
        /// </summary>
        public static string DateFallbackValue = "";
        /// <summary>
        /// The false fallback value
        /// </summary>
        public static bool FalseFallbackValue = false;
        /// <summary>
        /// The true fallback value
        /// </summary>
        public static bool TrueFallbackValue = true;
        /// <summary>
        /// The collapsed fallback value
        /// </summary>
        public static Visibility CollapsedFallbackValue = Visibility.Collapsed;
        /// <summary>
        /// The visible fallback value
        /// </summary>
        public static Visibility VisibleFallbackValue = Visibility.Visible;
        /// <summary>
        /// The default currency fallback value
        /// </summary>
        public static string DefaultCurrencyFallbackValue = "USD";
        /// <summary>
        /// The decimal fallback value
        /// </summary>
        public static string DecimalFallbackValue = "0.00";
        /// <summary>
        /// The identifier fallback value
        /// </summary>
        public static string IdFallbackValue = "0000";
        /// <summary>
        /// The blank fallback value
        /// </summary>
        public static string BlankFallbackValue = "";
        /// <summary>
        /// The missing fallback value
        /// </summary>
        public static string MissingFallbackValue = "Missing";
        /// <summary>
        /// The hidden fallback value
        /// </summary>
        public static string HiddenFallbackValue = "Hidden";
        /// <summary>
        /// The unknown fallback value. Only used in maps as of now.
        /// </summary>
        public static string UnknownFallbackValue = "Unknown";
        #endregion

        #region Common Application-wide Data Formats

        /// <summary>
        /// The application short date format
        /// If changing this date format, changes need to be made to ApplicationDateFormat in Common.xaml
        /// </summary>
        public static string ApplicationDateFormat = "dd MMM yyyy";

        /// <summary>
        /// The application long date format
        /// If changing this date format, changes need to be made to ApplicationLongDateTimeFormat in Common.xaml
        /// </summary>
        public static string ApplicationLongDateTimeFormat = "dd MMM yyyy HH:mm";

        /// <summary>
        /// The application long date time format
        /// If changing this date format, changes need to be made to ApplicationShortDateTimeFormat in Common.xaml
        /// </summary>
        public static string ApplicationShortDateTimeFormat = "dd MMM yyyy hh:mm tt";

        /// <summary>
        /// The application short time format
        /// If changing this date format, changes need to be made to ApplicationShortTimeFormat in Common.xaml
        /// </summary>
        public static string ApplicationShortTimeFormat = "hh:mm tt";

        /// <summary>
        /// The application month year date format
        /// If changing this date format, changes need to be made to ApplicationMonthYearDateFormat in Common.xaml
        /// </summary>
        public static string ApplicationMonthYearDateFormat = "MMM yyyy";

        #endregion

        #region TimeLine constants

        /// <summary>
        /// The time line start month value, specifies from which month will timeline interval start.
        /// </summary>
        public static int TimeLineStartMonthValue = -3;

        /// <summary>
        /// The time line interval in months, used to specify time line interval.
        /// </summary>
        public static int TimeLineIntervalInMonths = 12;

        /// <summary>
        /// The time line minium period length, for the custom interval.
        /// </summary>
        public static int TimeLineMiniumPeriodLength = 365;

        #endregion

        #region Character Constant
        /// <summary>
        /// The regular expression for restricting special characters.
        /// </summary>
        public static string RestrictSpecialCharacterRegularExpression = "";
        #endregion
    }
}
