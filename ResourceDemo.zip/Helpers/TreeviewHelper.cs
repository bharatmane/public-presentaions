﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods relating to the TreeView control and items.
    /// </summary>
    public static class TreeviewHelper
    {
        /// <summary>
        /// The double click command property
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
           DependencyProperty.RegisterAttached("DoubleClickCommand", typeof(System.Windows.Input.ICommand), typeof(TreeviewHelper),
               new PropertyMetadata(null, OnDoubleClickCommandChanged));

        /// <summary>
        /// Gets the depth of the TreeViewItem which is automatically set if
        /// the <see cref="UsesDepthProperty"/> is set to true.
        /// </summary>
        public static readonly DependencyProperty DepthProperty = 
            DependencyProperty.RegisterAttached("Depth", typeof(double), typeof(TreeviewHelper), new PropertyMetadata(0d));
        [AttachedPropertyBrowsableForType(typeof(TreeViewItem))]
        private static void SetDepth(UIElement element, double value)
        {
            element.SetValue(DepthProperty, value);
        }
        /// <summary> 
        /// Exposes the <see cref="DepthProperty"/> AttachedProperty.
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <returns>The value of the property</returns>
        public static double GetDepth(UIElement element)
        {
            return (double)element.GetValue(DepthProperty);
        }

        /// <summary>
        /// If set to true it will use the visual tree to determine 
        /// which level the specific TreeViewItem is in relation to 
        /// its parent items and set its <see cref="DepthProperty"/> attached
        /// property. This can be used to provide a margin to the content of
        /// the item which allows it to display a full width selection background. 
        /// </summary>
        public static readonly DependencyProperty UsesDepthProperty = 
            DependencyProperty.RegisterAttached("UsesDepth", typeof(bool), typeof(TreeviewHelper), new PropertyMetadata(false, OnUsesDepthChanged));
        /// <summary>
        /// Exposes the <see cref="UsesDepthProperty"/> AttachedProperty. 
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <param name="value">The value of the property</param>
        [AttachedPropertyBrowsableForType(typeof(TreeViewItem))]
        public static void SetUsesDepth(UIElement element, bool value)
        {
            element.SetValue(UsesDepthProperty, value);
        }
        /// <summary> 
        /// Exposes the <see cref="UsesDepthProperty"/> AttachedProperty.
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <returns>The value of the property</returns>
        public static bool GetUsesDepth(UIElement element)
        {
            return (bool)element.GetValue(UsesDepthProperty);
        }

        private static void OnUsesDepthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var item = (TreeViewItem)d;
            if ((bool) e.NewValue)
            {
                if (item.IsLoaded)
                {
                    SetItemDepth(item);
                }
                else
                {
                    item.Loaded += ItemOnLoaded;
                }
            }
        }

        private static void ItemOnLoaded(object sender, RoutedEventArgs e)
        {
            var item = (TreeViewItem)sender;
            item.Loaded -= ItemOnLoaded;
            SetItemDepth(item);
        }

        private static void SetItemDepth(TreeViewItem item)
        {
            var parent = GetParent(item);
            if (parent != null)
            {
                SetDepth(item, GetDepth(parent) + 1);
            }
        }

        private static TreeViewItem GetParent(TreeViewItem item)
        {
            var parent = VisualTreeHelper.GetParent(item);
            while (!(parent is TreeViewItem || parent is TreeView))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }
            return parent as TreeViewItem;
        }

        /// <summary>
        /// Called when [double click command changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDoubleClickCommandChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            if ((System.Windows.Input.ICommand)eventArgs.NewValue != null)
            {
                var treeView = dependencyObject as RadTreeView;
                if (treeView != null)
                {
                    treeView.PreviewMouseDoubleClick += (sender, args) =>
                    {
                        var row = UIHelper.FindVisualParent<RadTreeViewItem>((DependencyObject)args.OriginalSource);
                        if (row != null)
                        {
                            ((System.Windows.Input.ICommand)eventArgs.NewValue).Execute(row.DataContext);
                        }
                    };
                }
            }
        }

        /// <summary>
        /// Sets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetDoubleClickCommand(UIElement element, System.Windows.Input.ICommand value)
        {
            element.SetValue(DoubleClickCommandProperty, value);
        }

        /// <summary>
        /// Gets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static System.Windows.Input.ICommand GetDoubleClickCommand(UIElement element)
        {
            return (System.Windows.Input.ICommand)element.GetValue(DoubleClickCommandProperty);
        }

    }
}
