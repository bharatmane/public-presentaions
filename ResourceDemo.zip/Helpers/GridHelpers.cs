﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// This is the helper for the grid
    /// </summary>
    public static class GridHelpers
    {
        #region Property

        /// <summary>
        /// The chart series label template property.
        /// </summary>
        public static readonly DependencyProperty DynamicColumnItemSourceProperty =
            DependencyProperty.RegisterAttached("DynamicColumnItemSource",
                                                typeof(IEnumerable),
                                                typeof(GridHelpers),
                                                new PropertyMetadata(null, OnDynamicColumnItemSourceChanged));

        #endregion

        #region Methods

        /// <summary>
        /// Gets the chart series label template.
        /// </summary>
        /// <param name="dependencyObj">The dependency object.</param>
        /// <returns>Data Template.</returns>
        public static IEnumerable GetDynamicColumnItemSource(DependencyObject dependencyObj)
        {
            return (IEnumerable)dependencyObj.GetValue(DynamicColumnItemSourceProperty);
        }

        /// <summary>
        /// Sets the chart series label template.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetDynamicColumnItemSource(DependencyObject obj, IEnumerable value)
        {
            obj.SetValue(DynamicColumnItemSourceProperty, value);
        }

        /// <summary>
        /// Called when [chart series label template changed].
        /// </summary>
        /// <param name="target">The target.</param>
        /// <param name="eventsArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDynamicColumnItemSourceChanged(DependencyObject target, DependencyPropertyChangedEventArgs eventsArgs)
        {
            var result = eventsArgs.NewValue as IEnumerable;
            var columns = result != null ? result.OfType<ColumnDefinition>().ToList() : new List<ColumnDefinition>();

            Grid grid = target as Grid;
            if (grid.IsLoaded)
            {
                var childCount = grid.Children.Count;

                if (grid.ColumnDefinitions != null && grid.ColumnDefinitions.Any())
                {
                    grid.ColumnDefinitions.Clear();
                }

                if (columns.Count != 0)
                {
                    for (int index = 0; index < columns.Count; index++)
                    {
                        if (!grid.ColumnDefinitions.Contains(columns[index]))
                        {
                            grid.ColumnDefinitions.Add(columns[index]);
                        }
                    }

                    for (int i = 0; i < childCount; i++)
                    {
                        var child = grid.Children[i] as FrameworkElement;
                        Grid.SetColumn(child, i);
                    }
                }
            }
            else
            {
                grid.Loaded += (s, e2) =>
                {
                    var childCount = grid.Children.Count;
                    if (grid.ColumnDefinitions != null && grid.ColumnDefinitions.Any())
                    {
                        grid.ColumnDefinitions.Clear();
                    }
                    if (columns.Count != 0)
                    {
                        for (int index = 0; index < columns.Count; index++)
                        {
                            if (!grid.ColumnDefinitions.Contains(columns[index]))
                            {
                                grid.ColumnDefinitions.Add(columns[index]);
                            }
                        }

                        for (int i = 0; i < childCount; i++)
                        {
                            var child = grid.Children[i] as FrameworkElement;
                            Grid.SetColumn(child, i);
                        }
                    }
                };
            }

        }

        #endregion
    }
}
