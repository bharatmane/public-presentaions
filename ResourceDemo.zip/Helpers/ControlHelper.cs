﻿using Microsoft.Practices.ServiceLocation;
using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Controls.TreeListView;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;
using VShips.Framework.Resource.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Class containing common helpers for controls.
    /// </summary>
    public static class ControlHelper
    {
        /// <summary>
        /// An Atached property allowing the controls style to be updated
        /// if it is required.
        /// </summary>
        public static readonly DependencyProperty IsRequiredProperty =
            DependencyProperty.RegisterAttached("IsRequired", typeof(bool), typeof(ControlHelper), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsRequiredProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element to set the value.</param>
        /// <param name="value">The new value of the property.</param>
        public static void SetIsRequired(UIElement element, bool value)
        {
            element.SetValue(IsRequiredProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="IsRequiredProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the value.</param>
        /// <returns>The value of the attached property.</returns>
        public static bool GetIsRequired(UIElement element)
        {
            return (bool)element.GetValue(IsRequiredProperty);
        }

        /// <summary>
        /// An attached property that allows controls like the combobox to act as readonly.
        /// </summary>
        public static readonly DependencyProperty IsDisplayOnlyProperty =
            DependencyProperty.RegisterAttached("IsDisplayOnly", typeof(bool), typeof(ControlHelper), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsDisplayOnlyProperty"/> attached property.  
        /// </summary>
        public static void SetIsDisplayOnly(UIElement element, bool value)
        {
            element.SetValue(IsDisplayOnlyProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="IsDisplayOnlyProperty"/> attached property.  
        /// </summary>
        public static bool GetIsDisplayOnly(UIElement element)
        {
            return (bool)element.GetValue(IsDisplayOnlyProperty);
        }

        /// <summary>
        /// When set to true focus is set on the attached control.
        /// </summary>
        public static readonly DependencyProperty FocusOnLoadProperty =
            DependencyProperty.RegisterAttached("FocusOnLoad", typeof(bool), typeof(ControlHelper), new PropertyMetadata(false, OnFocusOnLoadChanged));
        /// <summary>
        /// Exposes the <see cref="FocusOnLoadProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element to set the value.</param>
        /// <param name="value">The new value of the property.</param>
        public static void SetFocusOnLoad(UIElement element, bool value)
        {
            element.SetValue(FocusOnLoadProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="FocusOnLoadProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the value.</param>
        /// <returns>The value of the attached property.</returns>
        public static bool GetFocusOnLoad(UIElement element)
        {
            return (bool)element.GetValue(FocusOnLoadProperty);
        }

        /// <summary>
        /// Attached property to set the permissions for a control.
        /// </summary>
        public static readonly DependencyProperty ControlPermissionProperty =
            DependencyProperty.RegisterAttached("ControlPermission", typeof(ModuleControlPermission), typeof(ControlHelper), new PropertyMetadata(null, OnControlPermissionChanged));
        /// <summary>
        /// Exposes the <see cref="ControlPermissionProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element to set the value.</param>
        /// <param name="value">The new value of the property.</param>
        public static void SetControlPermission(UIElement element, ModuleControlPermission value)
        {
            element.SetValue(ControlPermissionProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="ControlPermissionProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the value.</param>
        /// <returns>The value of the attached property.</returns>
        public static ModuleControlPermission GetControlPermission(UIElement element)
        {
            return (ModuleControlPermission)element.GetValue(ControlPermissionProperty);
        }

        /// <summary>
        /// The report permission property.
        /// </summary>
        public static readonly DependencyProperty ReportPermissionProperty =
           DependencyProperty.RegisterAttached("ReportPermission", typeof(string), typeof(ControlHelper), new PropertyMetadata(null, OnReportPermissionChanged));

        /// <summary>
        /// Sets the report permission.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetReportPermission(UIElement element, string value)
        {
            element.SetValue(ReportPermissionProperty, value);
        }

        /// <summary>
        /// Gets the report permission.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// A string value.
        /// </returns>
        public static string GetReportPermission(UIElement element)
        {
            return (string)element.GetValue(ReportPermissionProperty);
        }

        /// <summary>
        /// Called when [report permission changed].
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="eventArg">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnReportPermissionChanged(DependencyObject source, DependencyPropertyChangedEventArgs eventArg)
        {
            if (!GalaSoft.MvvmLight.ViewModelBase.IsInDesignModeStatic)
            {
                FrameworkElement control = (FrameworkElement)source;
                control.Visibility = Visibility.Collapsed;
                string reportName = eventArg != null ? (string)eventArg.NewValue : null;

                if (!string.IsNullOrWhiteSpace(reportName))
                {
                    bool isValid = ServiceLocator.Current.GetInstance<IModuleService>().GetReportSecurityByFileName(reportName);
                    control.Visibility = isValid ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        /// <summary>
        /// Called when [control permission changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnControlPermissionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (!GalaSoft.MvvmLight.ViewModelBase.IsInDesignModeStatic)
            {
                var control = (FrameworkElement)d;
                control.Visibility = Visibility.Collapsed;
                var p = GetControlPermission(control);

                if (p != null && !string.IsNullOrWhiteSpace(p.ControlId))
                {
                    var permission = ServiceLocator.Current.GetInstance<IModuleService>().GetSecurityKey(p.ModuleName, p.ControlId);
                    var isValid = permission != null && permission.Permission;
                    control.Visibility = isValid ? Visibility.Visible : Visibility.Collapsed;
                    control.IsEnabled = isValid; //TODO: PUNIT - THIS MAY NOT BE REQURIED. CHANGE AND TEST.
                }
            }
        }

        /// <summary>
        /// Called when [focus on load changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnFocusOnLoadChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool) e.NewValue)
            {
                var control = d as FrameworkElement;
                if (control != null)
                {
                    if (control.IsLoaded)
                    {
                        FocusControl(control);
                    }
                    else
                    {
                        control.Loaded += ControlOnLoaded;
                    }

                }
            }
        }

        /// <summary>
        /// Controls the on loaded.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void ControlOnLoaded(object sender, RoutedEventArgs e)
        {
            var control = (FrameworkElement) sender;
            control.Loaded -= ControlOnLoaded;
            FocusControl(control);
        }

        /// <summary>
        /// Focuses the control.
        /// </summary>
        /// <param name="control">The control.</param>
        private static void FocusControl(FrameworkElement control)
        {
            control.Dispatcher.BeginInvoke(new Action(() =>
            {
                control.Focus();
            }));
        }

        /// <summary>
        /// The disable double click property
        /// </summary>
        public static readonly DependencyProperty DisableDoubleClickProperty =
            DependencyProperty.RegisterAttached("DisableDoubleClick", typeof(bool), typeof(ControlHelper), new FrameworkPropertyMetadata(false, OnDisableDoubleClickChanged));

        /// <summary>
        /// Sets the disable double click.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetDisableDoubleClick(UIElement element, bool value)
        {
            element.SetValue(DisableDoubleClickProperty, value);
        }

        /// <summary>
        /// Gets the disable double click.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static bool GetDisableDoubleClick(UIElement element)
        {
            return (bool)element.GetValue(DisableDoubleClickProperty);
        }

        /// <summary>
        /// Called when [disable double click changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDisableDoubleClickChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (Control)d;
            if ((bool)e.NewValue)
            {
                control.PreviewMouseDown += (sender, args) =>
                {
                    if (args.ClickCount > 1)
                    {
                        args.Handled = true;
                    }
                };
            }
        }

        /// <summary>
        /// The close callout on click property
        /// </summary>
        public static readonly DependencyProperty CloseCallOutOnClickProperty =
            DependencyProperty.RegisterAttached("CloseCallOutOnClick", typeof(bool), typeof(ControlHelper), new PropertyMetadata(false));
        /// <summary>
        /// Sets the close call out on click.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetCloseCallOutOnClick(UIElement element, bool value)
        {
            element.SetValue(CloseCallOutOnClickProperty, value);
        }
        /// <summary>
        /// Gets the close call out on click.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>Single Bool value</returns>
        public static bool GetCloseCallOutOnClick(UIElement element)
        {
            return (bool)element.GetValue(CloseCallOutOnClickProperty);
        }

        /// <summary>
        /// Gets the custom date format.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static string GetCustomDateFormat(DependencyObject obj)
        {
            return (string)obj.GetValue(CustomDateFormatProperty);
        }

        /// <summary>
        /// Sets the custom date format.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetCustomDateFormat(DependencyObject obj, string value)
        {
            obj.SetValue(CustomDateFormatProperty, value);
        }

        /// <summary>
        /// The custom date format property
        /// </summary>
        public static readonly DependencyProperty CustomDateFormatProperty =
            DependencyProperty.RegisterAttached("CustomDateFormat", typeof(string), typeof(ControlHelper), new PropertyMetadata(null,CustomDateFormatProvided));

        /// <summary>
        /// Customs the date format provided.
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void CustomDateFormatProvided(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var dateTimePicker = d as RadDateTimePicker;
            CultureInfo cultureInfo = new CultureInfo("en-US");
            DateTimeFormatInfo dateInfo = new DateTimeFormatInfo();
            dateInfo.ShortDatePattern = e.NewValue.ToString();
            cultureInfo.DateTimeFormat = dateInfo;
            dateTimePicker.Culture = cultureInfo;
        }

        // Using a DependencyProperty as the backing store for AllowSpecialCharacters.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The allow special characters property
        /// </summary>
        public static readonly DependencyProperty AllowSpecialCharactersProperty =
            DependencyProperty.RegisterAttached("AllowSpecialCharacters", typeof(bool), typeof(ControlHelper), new PropertyMetadata(true, OnAllowSpecialCharacterChanged));

        /// <summary>
        /// Sets the allow special characters.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetAllowSpecialCharacters(UIElement element, bool value)
        {
            element.SetValue(AllowSpecialCharactersProperty, value);
        }
        /// <summary>
        /// Gets the allow special characters.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static bool GetAllowSpecialCharacters(UIElement element)
        {
            return (bool)element.GetValue(AllowSpecialCharactersProperty);
        }

        /// <summary>
        /// Called when [allow special character changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnAllowSpecialCharacterChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (!(bool)e.NewValue)
            {
                FrameworkElement control = d as FrameworkElement;
                string expression = Constants.RestrictSpecialCharacterRegularExpression;
                //This is to handle when anything is pasted in the textbox. 
                DataObject.AddPastingHandler(d, (sender, eventArgs) =>
                {
                    string text = eventArgs.DataObject.GetData(DataFormats.UnicodeText) as string;
                    if (!string.IsNullOrWhiteSpace(expression) && Regex.IsMatch(text, expression))
                    {
                        eventArgs.CancelCommand();
                    }
                });

                //This is to handle when anything is typed in the textbox.
                control.PreviewTextInput += (sender, eventArgs) =>
                {
                    if (!string.IsNullOrWhiteSpace(expression))
                    {
                        eventArgs.Handled = Regex.IsMatch(eventArgs.Text, expression);
                    }
                };
            }

        }

        /// <summary>
        /// Gets the close ribbon on click.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetCloseRibbonOnClick(DependencyObject obj)
        {
            return (bool)obj.GetValue(CloseRibbonOnClickProperty);
        }

        /// <summary>
        /// Sets the close ribbon on click.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetCloseRibbonOnClick(DependencyObject obj, bool value)
        {
            obj.SetValue(CloseRibbonOnClickProperty, value);
        }

        // Using a DependencyProperty as the backing store for CloseRibbonOnClick.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The close ribbon on click property
        /// </summary>
        public static readonly DependencyProperty CloseRibbonOnClickProperty =
            DependencyProperty.RegisterAttached("CloseRibbonOnClick", typeof(bool), typeof(ControlHelper), new PropertyMetadata(false, collapseRibbon));

        /// <summary>
        /// Collapses the ribbon.
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void collapseRibbon(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var button = d as FrameworkElement;
            button.PreviewMouseLeftButtonUp += (sender, eventargs) =>
            {
                var element = sender as FrameworkElement;
                var ribbon = UIHelper.FindVisualParent<VRibbon>(element) as VRibbon;
                if (ribbon != null)
                {
                    if (GetCloseRibbonOnClick(element) && ribbon.IsRibbonCollapsible)
                    {
                        ribbon.IsHidden = true;
                    }
                }
            };
        }        
        #region Clicks

        /// <summary>
        /// The command to run when an item on the gridview is double clicked.
        /// The datacontext of the item will be passed as a parameter to the command.
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
            DependencyProperty.RegisterAttached("DoubleClickCommand", typeof(ICommand), typeof(ControlHelper),
                new PropertyMetadata(null, OnDoubleClickCommandChanged));

        /// <summary>
        /// Exposes the <see cref="DoubleClickCommandProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadGridView))]
        [AttachedPropertyBrowsableForType(typeof(RadTreeListView))]
        [AttachedPropertyBrowsableForType(typeof(RadListBox))]
        [AttachedPropertyBrowsableForType(typeof(ListBox))]
        public static void SetDoubleClickCommand(UIElement element, ICommand value)
        {
            element.SetValue(DoubleClickCommandProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="DoubleClickCommandProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static ICommand GetDoubleClickCommand(UIElement element)
        {
            return (ICommand)element.GetValue(DoubleClickCommandProperty);
        }

        /// <summary>
        /// Called when [double click command changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDoubleClickCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var command = (ICommand)e.NewValue;
            var gridView = d as RadGridView;
            if (gridView != null)
            {
                GridViewDoubleClick(gridView, command);
            }
            var radListBox = d as RadListBox;
            if (radListBox != null)
            {
                RadListBoxDoubleClick(radListBox, command);
            }
            var listBox = d as ListBox;
            if (listBox != null)
            {
                ListBoxDoubleClick(listBox, command);
            }
            var treeListView = d as RadTreeListView;
            if (treeListView != null)
            {
                TreeListViewDoubleClick(treeListView, command);
            }
        }

        /// <summary>
        /// Trees the ListView double click.
        /// </summary>
        /// <param name="treeListView">The tree ListView.</param>
        /// <param name="command">The command.</param>
        private static void TreeListViewDoubleClick(RadTreeListView treeListView, ICommand command)
        {
            if (command != null)
            {
                treeListView.MouseDoubleClick += TreeListViewOnMouseDoubleClick;
            }
            else
            {
                treeListView.MouseDoubleClick -= TreeListViewOnMouseDoubleClick;
            }
        }

        /// <summary>
        /// ListBoxes the double click.
        /// </summary>
        /// <param name="listBox">The list box.</param>
        /// <param name="command">The command.</param>
        private static void ListBoxDoubleClick(ListBox listBox, ICommand command)
        {
            if (command != null)
            {
                listBox.MouseDoubleClick += ListBoxOnMouseDoubleClick;
            }
            else
            {
                listBox.MouseDoubleClick -= ListBoxOnMouseDoubleClick;
            }
        }

        /// <summary>
        /// Grids the view double click.
        /// </summary>
        /// <param name="gridView">The grid view.</param>
        /// <param name="command">The command.</param>
        private static void GridViewDoubleClick(RadGridView gridView, ICommand command)
        {
            if (command != null)
            {
                gridView.MouseDoubleClick += GridViewOnMouseDoubleClick;
            }
            else
            {
                gridView.MouseDoubleClick -= GridViewOnMouseDoubleClick;
            }
        }

        /// <summary>
        /// RADs the ListBox double click.
        /// </summary>
        /// <param name="listBox">The list box.</param>
        /// <param name="command">The command.</param>
        private static void RadListBoxDoubleClick(RadListBox listBox, ICommand command)
        {
            if (command != null)
            {
                listBox.MouseDoubleClick += RadListBoxOnMouseDoubleClick;
            }
            else
            {
                listBox.MouseDoubleClick -= RadListBoxOnMouseDoubleClick;
            }
        }

        /// <summary>
        /// ListBoxes the on mouse double click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        private static void ListBoxOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var listBox = (ListBox)sender;
                var command = GetDoubleClickCommand(listBox);
                var item = UIHelper.FindVisualParent<ListBoxItem>((DependencyObject)e.OriginalSource, listBox);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        /// <summary>
        /// RADs the ListBox on mouse double click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        private static void RadListBoxOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var listBox = (RadListBox)sender;
                var command = GetDoubleClickCommand(listBox);
                var item = UIHelper.FindVisualParent<RadListBoxItem>((DependencyObject)e.OriginalSource, listBox);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        /// <summary>
        /// Grids the view on mouse double click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        private static void GridViewOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var gridView = (RadGridView)sender;
                var command = GetDoubleClickCommand(gridView);
                var item = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)e.OriginalSource, gridView);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        /// <summary>
        /// Trees the ListView on mouse double click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        private static void TreeListViewOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var gridView = (RadTreeListView)sender;
                var command = GetDoubleClickCommand(gridView);
                var item = UIHelper.FindVisualParent<TreeListViewRow>((DependencyObject)e.OriginalSource, gridView);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        #endregion
    }
}
