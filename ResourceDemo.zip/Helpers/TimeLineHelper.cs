﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.TimeBar;
using VShips.DataServices.Shared.Enumerations;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// This class is used as the helper class for RadTimeLine 
    /// </summary>
    public static class TimeLineHelper
    {
        #region Dependency Properties

        /// <summary>
        /// The time line control name property
        /// </summary>
        public static readonly DependencyProperty TimeLineControlNameProperty =
            DependencyProperty.RegisterAttached("TimeLineControlName", typeof(string), typeof(TimeLineHelper), new PropertyMetadata(null, TimeLineControlNameChanged));

        #endregion

        #region Methods

        /// <summary>
        /// Sets the name of the time line control.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetTimeLineControlName(UIElement element, string value)
        {
            element.SetValue(TimeLineControlNameProperty, value);
        }

        /// <summary>
        /// Gets the name of the time line control.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static string GetTimeLineControlName(UIElement element)
        {
            return (string)element.GetValue(TimeLineControlNameProperty);
        }

        /// <summary>
        /// The time line control name changed.
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        public static void TimeLineControlNameChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var radioButton = d as RadioButton;
            if (radioButton != null)
            {
                radioButton.Checked += radioButton_Checked;
            }
        }

        /// <summary>
        /// Handles the Checked event of the radioButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        static void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                var userControl = FindParent<UserControl>(radioButton);

                var child = userControl.FindName(radioButton.GetValue(TimeLineControlNameProperty).ToString());

                if (child != null)
                {
                    var timeLineControl = child as RadTimeline;
                    if (timeLineControl != null)
                    {
                        timeLineControl.Intervals.Clear();

                        if (radioButton.Content.ToString().Equals(EnumsHelper.GetDescription(TimeLineControlIntervals.Week)))
                        {
                            timeLineControl.Intervals.Add(new WeekInterval());
                            timeLineControl.Intervals.Add(new TimeLineTodayInterval());
                            timeLineControl.VisiblePeriod = new SelectionRange<DateTime>(DateTime.Now.AddDays(-25),
                                DateTime.Now.AddDays(45));

                        }
                        else if (radioButton.Content.ToString().Equals(EnumsHelper.GetDescription(TimeLineControlIntervals.Quarter)))
                        {
                            timeLineControl.Intervals.Add(new QuarterInterval());
                            timeLineControl.Intervals.Add(new TimeLineTodayInterval());
                            timeLineControl.VisiblePeriod = new SelectionRange<DateTime>(DateTime.Now.AddMonths(-3),
                                DateTime.Now.AddMonths(9));
                        }
                        else if (radioButton.Content.ToString().Equals(EnumsHelper.GetDescription(TimeLineControlIntervals.Month)))
                        {
                            timeLineControl.Intervals.Add(new MonthInterval());
                            timeLineControl.Intervals.Add(new TimeLineTodayInterval());
                            timeLineControl.VisiblePeriod = new SelectionRange<DateTime>(DateTime.Now.AddDays(-60),
                                DateTime.Now.AddDays(180));
                        }

                    }
                }
            }
        }

        /// <summary>
        /// Finds the parent.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="child">The child.</param>
        /// <returns>Parent object</returns>
        public static T FindParent<T>(DependencyObject child) where T : DependencyObject
        {
            //get parent item
            var parentObject = VisualTreeHelper.GetParent(child);

            //has reached the end of the tree
            if (parentObject == null) return null;

            //check if the parent matches the type we're looking for
            var parent = parentObject as T;
            if (parent != null)
                return parent;
            return FindParent<T>(parentObject);
        }

        #endregion

    }
}
