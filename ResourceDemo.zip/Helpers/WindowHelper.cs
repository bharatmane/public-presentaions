﻿using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods relating to the RadWindow control.
    /// </summary>
    public static class WindowHelper
    {
        /// <summary>
        /// An attached property for the <see cref="RadWindow"/>. 
        /// If true a border will be drawn over the owner window when the new window is displayed.
        /// Its brush is set to the ModalBackground property of the new window.
        /// This gives a fade out appearance to the owner window.
        /// </summary>
        public static readonly DependencyProperty UsesFadeProperty = 
            DependencyProperty.RegisterAttached("UsesFade", typeof(bool), typeof(WindowHelper), new PropertyMetadata(false, OnUsesFadeChanged));
        
        /// <summary>
        /// Exposes a setter for the attached property <see cref="UsesFadeProperty"/>.
        /// </summary>
        /// <param name="element">The element containing the attached property.</param>
        /// <param name="value">The value of the property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadWindow))]
        public static void SetUsesFade(UIElement element, bool value)
        {
            element.SetValue(UsesFadeProperty, value);
        }

        /// <summary>
        /// Exposes a getter for the attached property <see cref="UsesFadeProperty"/>.
        /// </summary>
        /// <param name="element">The element containing the attached property.</param>
        /// <returns>The value of the property.</returns>
        public static bool GetUsesFade(UIElement element)
        {
            return (bool)element.GetValue(UsesFadeProperty);
        }

        private static void OnUsesFadeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var window = (RadWindow)d;
            if ((bool)e.NewValue)
            {
                window.Loaded += WindowOnLoaded;
            }
            else
            {
                window.Loaded -= WindowOnLoaded;
            }
        }

        private static void WindowOnLoaded(object sender, RoutedEventArgs e)
        {
            var window = (RadWindow)sender;
            window.Loaded -= WindowOnLoaded;
            var owner = window.Owner as FrameworkElement;
            if (owner != null)
            {
                var ownerWindow = owner as Window ?? UIHelper.FindVisualParent<Window>(owner);
                if (ownerWindow != null)
                {
                    ownerWindow.Effect = new BlurEffect{ Radius = 2 };
                    var layer = UIHelper.FindVisualChildren<AdornerLayer>(ownerWindow).Last();
                    if (layer != null)
                    {
                        var adorner = new WindowFadeAdorner((FrameworkElement) ownerWindow.Content, window.ModalBackground);
                        layer.Add(adorner);
                        window.PreviewClosed += delegate
                        {
                            layer.Remove(adorner);
                            ownerWindow.Effect = null;
                        };
                    }

                }
            }
        }
    }

    /// <summary>
    /// An adorner that is used to draw the fade for the UsesFade attached property.
    /// A border is drawn on the adorner layer of the owner window. 
    /// </summary>
    public class WindowFadeAdorner : Adorner
    {
        private readonly VisualCollection _visuals;
        private readonly Rectangle _readonlyBorder;
        private readonly FrameworkElement _adornerElement;

        /// <summary>
        /// Overrides the visual children count and returns 1 representing the border overlay.
        /// This is neccesery step in order to allow the WPF framework to render the adorner. 
        /// </summary>
        protected override int VisualChildrenCount
        {
            get { return _visuals.Count; } 
        }

        /// <summary>
        /// The default contructor for the WindowFadeAdorner.
        /// </summary>
        /// <param name="adornedElement">The border to draw on top of the owner window.</param>
        /// <param name="modalBrush">The background brush of the modal display.</param>
        public WindowFadeAdorner(FrameworkElement adornedElement, Brush modalBrush)
            : base(adornedElement)
        {
            _readonlyBorder = new Rectangle { Fill = modalBrush };
            _visuals = new VisualCollection(this) { _readonlyBorder };
            _adornerElement = adornedElement;
        }
        
        /// <summary>
        /// Overrides the MeasureOverride method to return the desired size of the border overlay.
        /// </summary>
        /// <param name="constraint">The size available in relation to the owned window.</param>
        /// <returns>The desired size of the overlay border.</returns>
        protected override Size MeasureOverride(Size constraint)
        {
            Size _adornerSize = _adornerElement.RenderSize;
            _readonlyBorder.Width = _adornerSize.Width;
            _readonlyBorder.Height = _adornerSize.Height;
            _readonlyBorder.Measure(_adornerSize);
            return _readonlyBorder.DesiredSize;
        }

        /// <summary>
        /// Overrides the ArrangeOverride method to place the overlay border over the exact space of the owned window.
        /// </summary>
        /// <param name="finalSize">The size of the owned window.</param>
        /// <returns>The final size.</returns>
        protected override Size ArrangeOverride(Size finalSize)
        {
            Size _adornerSize = _adornerElement.RenderSize;
            _readonlyBorder.Arrange(new Rect(0, 0, _adornerSize.Width, _adornerSize.Height));
            return _adornerSize;
        }

        /// <summary>
        /// Overrides the GetVisualChild to return the overlay border.
        /// This is neccesery step in order to allow the WPF framework to render the adorner.
        /// </summary>
        /// <param name="index">The index of the child which never exceeds the <see cref="VisualChildrenCount"/>.</param>
        /// <returns>The visual relating to the index. In this case the overlay border.</returns>
        protected override Visual GetVisualChild(int index)
        {
            return _visuals[index];
        }
    }
}
