﻿using System.Windows;
using Telerik.Windows.Controls.ChartView;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// 
    /// </summary>
    public static class ChartSeriesLabelDefinitionHelper
    {
        #region Property

        /// <summary>
        /// The chart series label template property.
        /// </summary>
        public static readonly DependencyProperty ChartSeriesLabelTemplateProperty = DependencyProperty.RegisterAttached("ChartSeriesLabelTemplate",
                                                                                                                         typeof(DataTemplate),
                                                                                                                         typeof(ChartSeriesLabelDefinitionHelper),
                                                                                                                         new PropertyMetadata(null, OnChartSeriesLabelTemplateChanged));

        #endregion

        #region Methods

        /// <summary>
        /// Gets the chart series label template.
        /// </summary>
        /// <param name="dependencyObj">The dependency object.</param>
        /// <returns>Data Template.</returns>
        public static DataTemplate GetChartSeriesLabelTemplate(DependencyObject dependencyObj)
        {
            return (DataTemplate)dependencyObj.GetValue(ChartSeriesLabelTemplateProperty);
        }

        /// <summary>
        /// Sets the chart series label template.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetChartSeriesLabelTemplate(DependencyObject obj, DataTemplate value)
        {
            obj.SetValue(ChartSeriesLabelTemplateProperty, value);
        }

        /// <summary>
        /// Called when [chart series label template changed].
        /// </summary>
        /// <param name="target">The target.</param>
        /// <param name="eventsArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnChartSeriesLabelTemplateChanged(DependencyObject target, DependencyPropertyChangedEventArgs eventsArgs)
        {
            BarSeries barSeries = (BarSeries)target;
            barSeries.LabelDefinitions.Clear();
            DataTemplate template = (DataTemplate)eventsArgs.NewValue;
            if (template != null)
            {
                barSeries.LabelDefinitions.Add(new ChartSeriesLabelDefinition() { Template = template });
            }
        }

        #endregion
    }
}
