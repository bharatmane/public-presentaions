﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Resources;
using Telerik.Windows.Controls;
using Telerik.Windows.Documents.Spreadsheet.Model;
using Telerik.Windows.Documents.Spreadsheet.Model.Shapes;
using Telerik.Windows.Documents.Spreadsheet.PropertySystem;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// SpreadsheetHelper for designing
    /// </summary>
    public static class SpreadsheetHelper
    {
        /// <summary>
        /// The border white
        /// </summary>
        private static CellBorder borderWhite;

        /// <summary>
        /// The border black
        /// </summary>
        private static CellBorder borderBlack;

        /// <summary>
        /// Adds the image header.
        /// </summary>
        /// <param name="worksheet">The worksheet.</param>
        /// <param name="columnCount">Specifies the total number of columns to be merged.</param>
        /// <returns>worksheet</returns>
        public static Worksheet AddImageHeader(Worksheet worksheet, int columnCount)
        {
            worksheet.Cells[new CellIndex(0, 0), new CellIndex(2, columnCount - 1)].Merge();
         

            FloatingImage image = new FloatingImage(worksheet, new CellIndex(0, 0), 0, 0);

            //Uri uriFilePath = new Uri("pack://application:,,,/VShips.Framework.Resource;component/Images/Flags/AAH.png", UriKind.RelativeOrAbsolute);

            string imagePath = "pack://application:,,,/VShips.Framework.Resource;component/Images/Logos/ShipsureLogoExcel.jpg";
            StreamResourceInfo imageInfo = System.Windows.Application.GetResourceStream(new Uri(imagePath));

            image.ImageSource = new Telerik.Windows.Documents.Media.ImageSource(imageInfo.Stream, "jpg");
            image.Width = PointToPixelConverter(183);
            image.Height = PointToPixelConverter(33);
            worksheet.Shapes.Add(image);

            return worksheet;
        }

        /// <summary>
        /// Sets the width of columns.
        /// </summary>
        /// <param name="worksheet">The worksheet.</param>
        /// <param name="numberOfIndentColumns">The number of indent columns.</param>
        /// <param name="columns">The columns.</param>
        /// <returns></returns>
        public static Worksheet SetWidthOfColumns(Worksheet worksheet, int numberOfIndentColumns, IList<GridViewBoundColumnBase> columns)
        {
            for (int i = 0; i < numberOfIndentColumns; i++)
            {
                worksheet.Columns[i].SetWidth(new ColumnWidth(PointToPixelConverter(columns[i].ActualWidth), false));
            }

            for (int i = 0; i < columns.Count; i++)
            {
                worksheet.Columns[numberOfIndentColumns + i].SetWidth(new ColumnWidth(PointToPixelConverter(columns[i].ActualWidth), false));
            }

            return worksheet;
        }

        /// <summary>
        /// Sets the format for column.
        /// </summary>
        /// <param name="worksheet">The worksheet.</param>
        /// <param name="columns">The columns.</param>
        /// <returns></returns>
        public static Worksheet SetFormatForColumn(Worksheet worksheet, IList<GridViewBoundColumnBase> columns)
        {
            ThemableFontFamily family = new ThemableFontFamily(new FontFamily("Arial"));

            for (int columnIndex = 0; columnIndex < columns.Count; columnIndex++)
            {
                worksheet.Columns[columnIndex].SetFontFamily(family);

                worksheet.Columns[columnIndex].SetFormat(new CellValueFormat("@"));

                worksheet.Columns[columnIndex].SetIsWrapped(true);

                worksheet.Columns[columnIndex].SetFontSize(PointToPixelConverter(8));

                //Setting Visibility of Column
                worksheet.Columns[columnIndex].SetHidden(!columns[columnIndex].IsVisible);

                //Setting Alignment
                var horizontalAlignment = columns[columnIndex].TextAlignment;

                if (horizontalAlignment == TextAlignment.Left)
                {
                    worksheet.Columns[columnIndex].SetHorizontalAlignment(RadHorizontalAlignment.Left);
                }
                else if (horizontalAlignment == TextAlignment.Right)
                {
                    worksheet.Columns[columnIndex].SetHorizontalAlignment(RadHorizontalAlignment.Right);
                }
                else
                {
                    worksheet.Columns[columnIndex].SetHorizontalAlignment(RadHorizontalAlignment.Center);
                }
            }

            return worksheet;
        }

        /// <summary>
        /// Sets the grid header row style.
        /// </summary>
        /// <param name="cellStyle">The cell style.</param>
        /// <returns></returns>
        public static CellStyle SetGridHeaderRowStyle(CellStyle cellStyle)
        {
            IFill fill = new PatternFill(PatternType.Gray75Percent, new ThemableColor(Color.FromArgb(255, 208, 211, 216)), new ThemableColor(Color.FromArgb(255, 208, 211, 216)));

            borderWhite = new CellBorder(CellBorderStyle.Thin, new ThemableColor(Color.FromArgb(255, 255, 255, 255)));
            borderBlack = new CellBorder(CellBorderStyle.Thin, new ThemableColor(Color.FromArgb(255, 0, 0, 0)));

            cellStyle.BeginUpdate();
            cellStyle.IsWrapped = true;
            cellStyle.IsBold = true;
            cellStyle.FontSize = PointToPixelConverter(9);
            cellStyle.Fill = fill;
            cellStyle.HorizontalAlignment = RadHorizontalAlignment.Center;
            cellStyle.VerticalAlignment = RadVerticalAlignment.Center;
            cellStyle.LeftBorder = borderWhite;
            cellStyle.TopBorder = borderBlack;
            cellStyle.RightBorder = borderWhite;

            cellStyle.EndUpdate();

            return cellStyle;
        }

        /// <summary>
        /// Sets the grid data row style.
        /// </summary>
        /// <param name="cellStyle">The cell style.</param>
        /// <returns></returns>
        public static CellStyle SetGridDataRowStyle(CellStyle cellStyle)
        {
            
            cellStyle.BeginUpdate();            
            cellStyle.FontSize = PointToPixelConverter(8); 
            cellStyle.EndUpdate();

            return cellStyle;
        }

        public static CellStyle SetFooterStyle(CellStyle cellStyle)
        {
            borderWhite = new CellBorder(CellBorderStyle.Thin, new ThemableColor(Color.FromArgb(255, 255, 255, 255)));
            borderBlack = new CellBorder(CellBorderStyle.Thick, new ThemableColor(Color.FromArgb(255, 0, 0, 0)));
            cellStyle.BeginUpdate();
            cellStyle.TopBorder=borderBlack;
            cellStyle.BottomBorder= borderWhite;
            cellStyle.FontSize=12;
            cellStyle.IsBold=true;
            cellStyle.VerticalAlignment= RadVerticalAlignment.Center;
            cellStyle.HorizontalAlignment= RadHorizontalAlignment.Left;
            cellStyle.EndUpdate();

            return cellStyle;
        }

        /// <summary>
        /// Points to pixel converter.
        /// </summary>
        /// <param name="point">The point.</param>
        /// <returns>
        /// A double value.
        /// </returns>
        public static double PointToPixelConverter(double point)
        {
            return (point / 0.75);
        }
    }
}
