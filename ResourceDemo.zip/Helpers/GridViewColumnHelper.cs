﻿using System.Windows;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Helper for Grid View Column
    /// </summary>
    public static class GridViewColumnHelper
    {
        #region Dependency Properties

        /// <summary>
        /// The dynamic column group name property
        /// </summary>
        public static readonly DependencyProperty DynamicColumnGroupNameProperty =
            DependencyProperty.RegisterAttached("DynamicColumnGroupName", typeof(string), typeof(GridViewColumnHelper), new PropertyMetadata(null, DynamicColumnGroupNameChanged));

        #endregion

        #region Properties

        /// <summary>
        /// Gets the name of the dynamic column group.
        /// </summary>
        /// <param name="dependencyObj">The dependency object.</param>
        /// <returns></returns>
        public static string GetDynamicColumnGroupName(DependencyObject dependencyObj)
        {
            return (string)dependencyObj.GetValue(DynamicColumnGroupNameProperty);
        }

        /// <summary>
        /// Sets the name of the dynamic column group.
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="value">The value.</param>
        public static void SetDynamicColumnGroupName(DependencyObject dependencyObject, string value)
        {
            dependencyObject.SetValue(DynamicColumnGroupNameProperty, value);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Dynamics the column group name changed.
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void DynamicColumnGroupNameChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            GridViewColumn column = dependencyObject as GridViewColumn;
            if (dependencyObject != null && eventArgs != null)
            {
                column.ColumnGroupName = eventArgs.NewValue as string;
            }
        }

        #endregion
    }
}