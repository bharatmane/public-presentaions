﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods relating to the TextBlock control.
    /// </summary>
    public static class TextBlockHelper
    {
        /// <summary>
        /// When set to true all children of type TextBlock in the controls visual tree will be underlined.
        /// </summary>
        public static readonly DependencyProperty UnderlineProperty = 
            DependencyProperty.RegisterAttached("Underline", typeof(bool), typeof(TextBlockHelper), new PropertyMetadata(false, OnUnderlineChanged));
        /// <summary>
        /// Exposes the <see cref="UnderlineProperty"/> AttachedProperty. 
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <param name="value">The value of the property</param>
        public static void SetUnderline(UIElement element, bool value)
        {
            element.SetValue(UnderlineProperty, value);
        }
        /// <summary> 
        /// Exposes the <see cref="UnderlineProperty"/> AttachedProperty.
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <returns>The value of the property</returns>
        public static bool GetUnderline(UIElement element)
        {
            return (bool)element.GetValue(UnderlineProperty);
        }

        private static void OnUnderlineChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as FrameworkElement;
            if (control != null)
            {
                var textblocks = UIHelper.FindVisualChildren<TextBlock>(control).ToList();
                if ((bool) e.NewValue)
                {
                    foreach (var textblock in textblocks)
                    {
                        textblock.TextDecorations = TextDecorations.Underline;
                    }
                }
                else
                {
                    foreach (var textblock in textblocks)
                    {
                        textblock.TextDecorations = null;
                    }
                }
            }
        }
    }
}
