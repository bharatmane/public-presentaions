﻿using GalaSoft.MvvmLight.CommandWpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using VShips.Framework.Resource.Controls;

namespace VShips.Framework.Resource.Helpers
{
    public static class PopupHelper
    {
        private static ICommand _OpenPopupCommand;
        /// <summary>
        /// Command to reposition a Popup control to vertically allign to the bottom of the target control
        /// </summary>
        public static ICommand OpenPopupCommand
        {
            get
            {
                return _OpenPopupCommand ?? (_OpenPopupCommand = new RelayCommand<object>(param =>
                {
                    if (param != null && param is Popup)
                    {
                        Popup popup = param as Popup;

                        popup.IsOpen = true;
                    }
                }));
            }
        }

        private static ICommand _RepositionPopupCommand;
        /// <summary>
        /// Command to reposition a Popup control to vertically allign to the bottom of the target control
        /// </summary>
        public static ICommand RepositionPopupCommand
        {
            get
            {
                return _RepositionPopupCommand ?? (_RepositionPopupCommand = new RelayCommand<object>(param =>
                {
                    try
                    {
                        if (param != null && param is Popup)
                        {
                            Popup popup = param as Popup;

                            Grid grid = popup.Child as Grid;

                            dynamic templatedParent = null;

                            if (popup.TemplatedParent != null)
                                templatedParent = popup.TemplatedParent;
                            else if (popup.PlacementTarget != null)
                                templatedParent = popup.PlacementTarget;

                            double height = (templatedParent != null) ? templatedParent.ActualHeight : 0;

                            foreach (RowDefinition rd in grid.RowDefinitions)
                            {
                                height += rd.ActualHeight;
                            }

                            popup.VerticalOffset = height / 2;
                        }
                    }
                    catch (Exception)
                    {

                    }
                }));
            }
        }
    }
}
