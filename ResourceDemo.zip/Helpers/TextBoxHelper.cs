﻿using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods relating to the TextBox control.
    /// </summary>
    public static class TextBoxHelper
    {
        /// <summary>
        /// Gets the is real number.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetIsRealNumber(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsRealNumberProperty);
        }

        /// <summary>
        /// Sets the is real number.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetIsRealNumber(DependencyObject obj, bool value)
        {
            obj.SetValue(IsRealNumberProperty, value);
        }

        // Using a DependencyProperty as the backing store for Is.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The is real number property
        /// </summary>
        public static readonly DependencyProperty IsRealNumberProperty =
            DependencyProperty.RegisterAttached("IsRealNumber", typeof(bool), typeof(TextBoxHelper), new PropertyMetadata(false, OnIsRealNumberChanged));

        /// <summary>
        /// Called when [is real number changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsRealNumberChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                var textBox = d as TextBox;
                textBox.PreviewTextInput += (sender, eventArgs) =>
                {
                    decimal temp = 0;
                    if (!decimal.TryParse(textBox.Text, out temp))
                    {
                        textBox.Text = string.Empty;
                    }
                    eventArgs.Handled = !Regex.IsMatch(textBox.Text + eventArgs.Text, @"^-?\d*(\.\d*)?$");
                };
            }
        }


        /// <summary>
        /// Gets the is alphabet only.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns>bool value</returns>
        public static bool GetIsAlphabetOnly(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsAlphabetOnlyProperty);
        }

        /// <summary>
        /// Sets the is alphabet only.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetIsAlphabetOnly(DependencyObject obj, bool value)
        {
            obj.SetValue(IsAlphabetOnlyProperty, value);
        }

        // Using a DependencyProperty as the backing store for Is.  This enables animation, styling, binding, etc...

        /// <summary>
        /// The is alphabet only property
        /// </summary>
        public static readonly DependencyProperty IsAlphabetOnlyProperty =
            DependencyProperty.RegisterAttached("IsAlphabetOnly", typeof(bool), typeof(TextBoxHelper), new PropertyMetadata(false, IsAlphabetOnlyChanged));

        /// <summary>
        /// Determines whether [is alphabet only changed] [the specified d].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void IsAlphabetOnlyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                var textBox = d as TextBox;
                textBox.PreviewTextInput += (sender, eventArgs) =>
                {
                    eventArgs.Handled = !Regex.IsMatch(textBox.Text + eventArgs.Text, "^[a-zA-Z]+$");
                };
            }
        }
    }
}
