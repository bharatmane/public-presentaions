﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.ChartView;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// This is a helper class for RadCatesian Chart to generate mutiple Splines dynamically.
    /// </summary>
    public class CartesianChartHelper
    {
        #region Properties

        /// <summary>
        /// The fixed series count
        /// </summary>
        private static int _fixedSeriesCount;

        /// <summary>
        /// The is initial load
        /// </summary>
        private static bool _isInitialLoad = true;

        #endregion

        #region Dependency Properties

        // Using a DependencyProperty as the backing store for MultiLinesItemSource.  This enables animation, styling, binding, etc...  
        /// <summary>
        /// The multi lines item source property
        /// </summary>
        public static readonly DependencyProperty MultiLinesItemSourceProperty =
        DependencyProperty.RegisterAttached("MultiLinesItemSource", typeof(IEnumerable), typeof(CartesianChartHelper), new PropertyMetadata(null, OnMultiLinesItemSourceChanged));

        #endregion

        #region Methods

        /// <summary>
        /// Sets the multi lines item source.
        /// </summary>
        /// <param name="element">The element of type<see cref="UIElement"/>.</param>
        /// <param name="value">The value of type<see cref="IEnumerable"/>.</param>
        public static void SetMultiLinesItemSource(UIElement element, IEnumerable value)
        {
            element.SetValue(MultiLinesItemSourceProperty, value);
        }

        /// <summary>
        /// Gets the multi lines item source.
        /// </summary>
        /// <param name="element">The elementof type <see cref="UIElement"/>.</param>
        /// <returns>Single object of type <see cref="IEnumerable"/></returns>
        public static IEnumerable GetMultiLinesItemSource(UIElement element)
        {
            return (IEnumerable)element.GetValue(MultiLinesItemSourceProperty);
        }

        /// <summary>
        /// Called when [multi lines item source changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type<see cref="DependencyObject"/>.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnMultiLinesItemSourceChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            var control = (RadCartesianChart)dependencyObject;
            var result = eventArgs.NewValue as IEnumerable;
            var itemSources = result != null ? result.OfType<IEnumerable>().ToList() : new List<IEnumerable>();

            if (control.IsLoaded)
            {
                if (_isInitialLoad)
                {
                    _fixedSeriesCount = control.Series.Count;
                    _isInitialLoad = false;
                }
                GenerateSubCharts(control, itemSources);
            }
            else
            {
                control.Loaded += ControlOnLoaded;
            }
        }

        /// <summary>
        /// Controls the on loaded.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArgs">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void ControlOnLoaded(object sender, RoutedEventArgs eventArgs)
        {
            var control = (RadCartesianChart)sender;
            control.Loaded -= ControlOnLoaded;
            var result = GetMultiLinesItemSource(control);
            var itemSources = result != null ? result.OfType<IEnumerable>().ToList() : new List<IEnumerable>();
            GenerateSubCharts(control, itemSources);
        }

        /// <summary>
        /// Generates the sub charts.
        /// </summary>
        /// <param name="cartesianChart">The cartesian chart of type <see cref="RadCartesianChart"/>.</param>
        /// <param name="itemSources">The item sources list of type <see cref="IEnumerable"/>.</param>
        private static void GenerateSubCharts(RadCartesianChart cartesianChart, List<IEnumerable> itemSources)
        {
            if (cartesianChart.Series != null)
            {
                int count = cartesianChart.Series.Count;
                for (int i = count - 1; i >= 0; i--)
                {
                    cartesianChart.Series.Remove(cartesianChart.Series[i]);
                }
            }

            foreach (var itemSource in itemSources)
            {
                var singleItem = itemSource.OfType<Object>().ToList().FirstOrDefault();

                string categoryBindingName = singleItem.GetType().GetProperty("CategoryBindingName").GetValue(singleItem) as string;
                string valueBindingName = singleItem.GetType().GetProperty("ValueBindingName").GetValue(singleItem) as string;
                string linePointTemplateName = singleItem.GetType().GetProperty("LinePointTemplateName").GetValue(singleItem) as string;
                string legendTitle = singleItem.GetType().GetProperty("LegendTitle").GetValue(singleItem) as string;
                string StrokeColourName = singleItem.GetType().GetProperty("StrokeColourName").GetValue(singleItem) as string;

                ScatterSplineSeries scatterLineSeries = new ScatterSplineSeries();
                scatterLineSeries.MouseEnter += lineSeries_MouseEnter;
                scatterLineSeries.MouseLeave += lineSeries_MouseLeave;
                scatterLineSeries.StrokeThickness = 1;
                cartesianChart.Series.Add(scatterLineSeries);
                scatterLineSeries.ItemsSource = itemSource;

                if (!string.IsNullOrWhiteSpace(categoryBindingName))
                {
                    scatterLineSeries.XValueBinding = new PropertyNameDataPointBinding(categoryBindingName);
                }

                if (!string.IsNullOrWhiteSpace(valueBindingName))
                {
                    scatterLineSeries.YValueBinding = new PropertyNameDataPointBinding(valueBindingName);
                }

                if (!string.IsNullOrWhiteSpace(linePointTemplateName))
                {
                    scatterLineSeries.PointTemplate = cartesianChart.FindResource(linePointTemplateName) as DataTemplate;
                }

                if (!string.IsNullOrWhiteSpace(StrokeColourName))
                {
                    scatterLineSeries.Stroke = cartesianChart.FindResource(StrokeColourName) as SolidColorBrush;
                }

                if (!string.IsNullOrWhiteSpace(legendTitle))
                {
                    SeriesLegendSettings seriesLegendSettings = new SeriesLegendSettings() { Title = legendTitle };
                    scatterLineSeries.LegendSettings = seriesLegendSettings;
                }
            }
        }

        /// <summary>
        /// Handles the MouseLeave event of the lineSeries control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="System.Windows.Input.MouseEventArgs"/> instance containing the event data.</param>
        private static void lineSeries_MouseLeave(object sender, System.Windows.Input.MouseEventArgs eventArgs)
        {
            ScatterSplineSeries axis = (ScatterSplineSeries)sender;
            if (axis != null)
            {
                axis.StrokeThickness -= 1;
            }
        }

        /// <summary>
        /// Handles the MouseEnter event of the lineSeries control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="System.Windows.Input.MouseEventArgs"/> instance containing the event data.</param>
        private static void lineSeries_MouseEnter(object sender, System.Windows.Input.MouseEventArgs eventArgs)
        {
            ScatterSplineSeries axis = (ScatterSplineSeries)sender;
            if (axis != null)
            {
                axis.StrokeThickness += 1;
            }
        }

        #endregion
    }
}
