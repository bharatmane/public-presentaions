﻿using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using VShips.Contracts.Custom.Common;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared;
using VShips.DataServices.Shared.Contracts;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Helper class to allow the fetching, saving and deleting of dynamically populated Xaml forms and GridViews
    /// </summary>
    public static class GeneratedFormsHelper
    {
        #region Get

        #region New Get Methods

        /// <summary>
        /// Get all form light records.
        /// </summary>
        /// <returns>A list of items of type FormLight.</returns>
        public static async Task<List<FormLight>> GetAllForms()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetForms(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form light records.
        /// </summary>
        /// <returns>A list of items of type FormLight.</returns>
        public static async Task<PagedResponse<List<FormLight>>> GetAllFormsPaged(PagedRequest pageRequest)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormsPaged(pageRequest, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form overview records.
        /// </summary>
        /// <returns>A list of items of type FormLight.</returns>
        public static async Task<List<FormOverview>> GetAllFormOverviews()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormOverviews(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }


        /// <summary>
        /// Get list of forms by group Id.
        /// </summary>
        /// <param name="group">The group table.</param>
        /// <returns>A List of Type FormLight.</returns>
        public static async Task<List<FormLight>> GetFormsByGroup(FormGroupTable group)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormsByGroup(group, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form group records.
        /// </summary>
        /// <returns>A list of items of type FormGroupLight.</returns>
        public static async Task<List<FormGroupLight>> GetAllFormGroups()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormGroups(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form group table records.
        /// </summary>
        /// <returns>A list of items of type FormGroupLight.</returns>
        public static async Task<List<FormGroupTableLight>> GetAllFormGroupTables()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormGroupTables(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form category records.
        /// </summary>
        /// <returns>A list of items of type FormGroupLight.</returns>
        public static async Task<List<FormCategoryLight>> GetAllFormCategories()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormCategories(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form category records.
        /// </summary>
        /// <returns>A list of items of type FormGroupLight.</returns>
        public static async Task<List<FormParentTableLight>> GetAllFormAssignemntParents()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormAssignemntParents(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get list of form group light records by grouping Id and group type.
        /// </summary>
        /// <param name="id">The grouping Id.</param>
        /// <param name="groupTable">The group Table.</param>
        /// <returns>A list of items of type FormGroupLight.</returns>
        public static async Task<List<FormGroupLight>> GetFormGroupByGroupingId(string id, FormGroupTable groupTable)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormGroupsLightByGroupingId(id, groupTable, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get a single form group record with all form data and grid layout information records attached by its group id.
        /// </summary>
        /// <param name="id">The group id.</param>
        /// <returns>A single instance of type FormGroup.</returns>
        public static async Task<FormGroup> GetFormGroupById(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormGroupById(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get list of form assignment light records by parent Id and parent type.
        /// </summary>
        /// <param name="id">The parent Id.</param>
        /// <param name="parent">The prarent Table.</param>
        /// <returns>A list of items of type FormAssignmentLight.</returns>
        public static async Task<List<FormAssignmentLight>> GetFormAssignmentsByParent(string id, FormParentTable parent)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormAssignmentsLightByParent(id, parent, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get a single form assignemnt record with all form data and grid layout information records attached by its assignment id.
        /// </summary>
        /// <param name="id">The assignment id.</param>
        /// <returns>A single instance of type FormAssignment.</returns>
        public static async Task<FormAssignment> GetFormAssignmentById(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormAssignmentById(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all available form templates
        /// </summary>
        /// <returns>List of Form Templates of Type FormTemplateLight</returns>
        public static async Task<List<FormTemplateLight>> GetAllFormTemplates()
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormTemplates(token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form template light records that contain the supplied name.
        /// </summary>
        /// <param name="name">the name of the form to search for.</param>
        /// <returns>A list of items of type FormTemplateLight.</returns>
        public static async Task<List<FormTemplateLight>> GetFormTemplatesByName(string name)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormTemplatesByName(name, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get a single instance of form template
        /// </summary>
        /// <param name="templateId">the template Id.</param>
        /// <returns>Single instance of FormTemplate</returns>
        public static async Task<FormTemplate> GetFormTemplate(string templateId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormTemplate(templateId,token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get a List of all FormTemplateOverview records.
        /// </summary>
        /// <returns>Single instance of FormTemplate</returns>
        public static async Task<List<FormTemplateOverview>> GetAllFormTemplateOverviews(string templateName)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormTemplateOverviews(templateName, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form templates associated with a specific form
        /// </summary>
        /// <returns>List of Form Templates of Type FormTemplateArrangementLight</returns>
        public static async Task<List<FormTemplateArrangementLight>> GetFormTemplateArrangementByFormId(string formId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormTemplateArrangementByFormId(formId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get a List of all FormVesselAllocation records.
        /// </summary>
        /// <param name="request">the form allocation request</param>
        /// <returns>List of records of type FormVesselAllocation</returns>
        public static async Task<List<FormVesselAllocation>> GetFormVesselAllocations(FormAllocationRequest request)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetFormAllocations(request, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get all form records allocated to a specific vessel.
        /// </summary>
        /// <param name="vesselId">the vesselId</param>
        /// <returns>A list of items of type FormLight.</returns>
        public static async Task<List<FormLight>> GetAllocatedFormsForVessel(string vesselId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                //return await VMService.DataService.Shared.GetAllocatedFormsForVessel(vesselId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        #endregion

        #region Old Methods
        /*
        
        /// <summary>
        /// Get all templates for the supplied category Id
        /// </summary>
        /// <param name="categoryId">Id value for the selected category</param>
        /// <returns>List of Form Templates of Type DynamicFormTemplateLight</returns>
        public static async Task<List<DynamicFormTemplateLight>> GetDynamicFormTemplatesByCategory(string categoryId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetDynamicFormTemplatesByCategory(categoryId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get a list of Template assignment records for the supplied parentId
        /// </summary>
        /// <param name="id">Id of the parent object of the form</param>
        /// <returns>List of Form Template assignments of Type DynamicFormAssignment</returns>
        public static async Task<List<DynamicFormAssignment>> GetDynamicFormAssignmentsByParent(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetDynamicFormAssignmentsByParent(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Get single Template Light record for the supplied template Id
        /// </summary>
        /// <param name="id">Id of the template to be retrieved</param>
        /// <returns>A single instance of DynamicForm</returns>
        public static async Task<DynamicForm> GetDynamicFormAssignmentsById(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.GetDynamicFormByAssignmentId(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }
        */
        #endregion

        #endregion

        #region Save

        #region New methods

        /// <summary>
        /// Save a form group.
        /// </summary>
        /// <param name="group">The form group.</param>
        /// <returns>Update repsonse with entity of type FormGroupLight.</returns>
        public static async Task<UpdateResponse<FormGroupLight>> SaveFormGroup(FormGroupLight group)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormGroup(group, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save the form group table
        /// </summary>
        /// <param name="group">The form group of type FormGroupTableLight.</param>
        /// <returns>An update response with entity of type FormGroupTableLight.</returns>
        public static async Task<UpdateResponse<FormGroupTableLight>> SaveFormGroupTable(FormGroupTableLight group)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormGroupTable(group, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save the form parent table
        /// </summary>
        /// <param name="parent">The form parent of type FormParentTableLight.</param>
        /// <returns>An update response with entity of type FormParentTableLight.</returns>
        public static async Task<UpdateResponse<FormParentTableLight>> SaveFormParentTable(FormParentTableLight parent)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormParentTable(parent, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save tje form template arrangement.
        /// </summary>
        /// <param name="arrangement">The form template arangement entity of type FormTemplateArrangementLight.</param>
        /// <returns>An update response with entity of type FormTemplateArrangementLight.</returns>
        public static async Task<UpdateResponse<FormTemplateArrangementLight>> SaveFormTemplateArrangement(FormTemplateArrangementLight arrangement)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormTemplateArrangement(arrangement, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save the form template.
        /// </summary>
        /// <param name="item">The form template of type FormTemplate.</param>
        /// <returns>An update response with entity of type FormTemplate.</returns>
        public static async Task<UpdateResponse<FormTemplate>> SaveFormTemplate(FormTemplate item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormTemplate(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save the form assignemnt.
        /// </summary>
        /// <param name="item">The form assignment of type FormAssignment.</param>
        /// <returns>An update response of type FormAssignment.</returns>
        public static async Task<UpdateResponse<FormAssignment>> SaveFormAssignment(FormAssignment item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormAssignment(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save the form.
        /// </summary>
        /// <param name="item">the form of type FormLight.</param>
        /// <returns>An update response of type FormLight.</returns>
        public static async Task<UpdateResponse<FormLight>> SaveForm(FormLight item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveForm(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save the form vessel allocation.
        /// </summary>
        /// <param name="item">the form of type FormVesselAllocation.</param>
        /// <returns>An update response of type FormVesselAllocation.</returns>
        public static async Task<UpdateResponse<FormVesselAllocation>> SaveFormVesselAllocation(FormVesselAllocation item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveFormAllocation(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        #endregion

        #region Old methods
        /*
        /// <summary>
        /// Save Changes to an instance of DynamicFormTemplateLight.
        /// </summary>
        /// <param name="item">Instance of type DynamicFormTemplateLight to be saved</param>
        /// <returns>Update repsonse of type DynamicFormTemplateLight</returns>
        public static async Task<UpdateResponse<DynamicFormTemplateLight>> SaveDynamicFormTemplate(DynamicFormTemplateLight item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveDynamicFormTemplate(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save Changes to an instance of DynamicFormTemplateLight.
        /// </summary>
        /// <param name="item">Instance of type DynamicFormTemplateLight to be saved</param>
        /// <returns>Update repsonse of type DynamicFormTemplateLight</returns>
        public static async Task<UpdateResponse<DynamicForm>> SaveDynamicForm(DynamicForm item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                item.Template = null;
                return await VMService.DataService.Shared.SaveDynamicForm(item, true, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }


        /// <summary>
        /// Save Changes to an instance of DynamicFormAssignment.
        /// </summary>
        /// <param name="item">Instance of type DynamicFormAssignment to be saved</param>
        /// <returns>Update repsonse of type DynamicFormAssignment</returns>
        public static async Task<UpdateResponse<DynamicFormAssignment>> SaveDynamicFormAssignment(DynamicFormAssignment item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveDynamicFormAssignment(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save Changes to an instance of DynamicFormCategory.
        /// </summary>
        /// <param name="item">Instance of type DynamicFormCategory to be saved</param>
        /// <returns>Update repsonse of type DynamicFormCategory</returns>
        public static async Task<UpdateResponse<DynamicFormCategory>> SaveDynamicFormCategory(DynamicFormCategory item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveDynamicFormCategory(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save Changes to an instance of DynamicFormGridLayout.
        /// </summary>
        /// <param name="item">Instance of type DynamicFormGridLayout to be saved</param>
        /// <returns>Update repsonse of type DynamicFormGridLayout</returns>
        public static async Task<UpdateResponse<DynamicFormGridLayout>> SaveDynamicFormGridLayout(DynamicFormGridLayout item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveDynamicFormLayout(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Save Changes to an instance of DynamicFormData.
        /// </summary>
        /// <param name="item">Instance of type DynamicFormData to be saved</param>
        /// <returns>Update repsonse of type DynamicFormData</returns>
        public static async Task<UpdateResponse<DynamicFormData>> SaveDynamicFormData(DynamicFormData item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.SaveDynamicFormData(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }
        */
        #endregion

        #endregion  

        #region Delete

        #region New methods

        /// <summary>
        /// Delete a form.
        /// </summary>
        /// <param name="formId">the form Id.</param>
        /// <returns>An update response of type FormLight.</returns>
        public static async Task<UpdateResponse<bool>> DeleteForm(string formId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteForm(formId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form Template.
        /// </summary>
        /// <param name="formTemplateId">the form Template Id.</param>
        /// <returns>An update response of type FormTemplateOverview.</returns>
        public static async Task<UpdateResponse<bool>> DeleteFormTemplate(string formTemplateId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteFormTemplate(formTemplateId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form Template column.
        /// </summary>
        /// <param name="formTemplateControlId">the form Template control Id.</param>
        /// <returns>An update response of type FormTemplateOverview.</returns>
        public static async Task<UpdateResponse<bool>> DeleteFormTemplateControl(string formTemplateControlId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteFormTemplateControl(formTemplateControlId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form Assignment.
        /// </summary>
        /// <param name="item">the form Assignment of type FormAssignmentLight.</param>
        /// <returns>An update response of type FormAssignmentLight.</returns>
        public static async Task<UpdateResponse<FormAssignment>> DeleteFormAssignment(FormAssignment item)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteFormAssignment(item, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form Arrangement.
        /// </summary>
        /// <param name="arrangementId">the form arrangement Id.</param>
        /// <returns>An update response of type bool.</returns>
        public static async Task<UpdateResponse<bool>> DeleteFormArrangement(string arrangementId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return  await VMService.DataService.Shared.DeleteFormTemplateArrangement(arrangementId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form category.
        /// </summary>
        /// <param name="categoryId">the categoryId.</param>
        /// <returns>An update response of type bool.</returns>
        public static async Task<UpdateResponse<bool>> DeleteFormCategory(string categoryId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return new UpdateResponse<bool>();// VMService.DataService.Shared.DeleteFormTemplate(formTemplateId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form group table.
        /// </summary>
        /// <param name="formGroupId">the formGroupId.</param>
        /// <returns>An update response of type bool.</returns>
        public static async Task<UpdateResponse<bool>> DeleteFormGroupTable(string formGroupId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return new UpdateResponse<bool>();// VMService.DataService.Shared.DeleteFormTemplate(formTemplateId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form parent table.
        /// </summary>
        /// <param name="formParentId">the formParentId.</param>
        /// <returns>An update response of type bool.</returns>
        public static async Task<UpdateResponse<bool>> DeleteFormParentTable(string formParentId)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return new UpdateResponse<bool>();// VMService.DataService.Shared.DeleteFormTemplate(formTemplateId, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete a form vessel allocation.
        /// </summary>
        /// <param name="vesselAllocation">the vesselAllocation.</param>
        /// <returns>An update response of type FormVesselAllocation.</returns>
        public static async Task<UpdateResponse<FormVesselAllocation>> DeleteFormAllocation(FormVesselAllocation vesselAllocation)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteFormAllocation(vesselAllocation, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        #endregion

        #region Old methods
        /*
        /// <summary>
        /// Delete an instance of DynamicFormAssignment.
        /// </summary>
        /// <param name="id">Id of DynamicFormAssignment instance to be deleted</param>
        /// <returns>Update repsonse of type DynamicFormAssignment</returns>
        public static async Task<UpdateResponse<DynamicFormAssignment>> DeleteDynamicFormAssignment(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteDynamicFormAssignment(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete an instance of DynamicFormData.
        /// </summary>
        /// <param name="item">Id of DynamicFormData instance to be deleted</param>
        /// <returns>Update repsonse of type DynamicFormData</returns>
        public static async Task<UpdateResponse<DynamicFormData>> DeleteDynamicFormData(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteDynamicFormData(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete an instance of DynamicFormGridLayout.
        /// </summary>
        /// <param name="item">Id of DynamicFormGridLayout instance to be deleted</param>
        /// <returns>Update repsonse of type DynamicFormGridLayout</returns>
        public static async Task<UpdateResponse<DynamicFormGridLayout>> DeleteDynamicFormGridLayout(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteDynamicFormLayout(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }

        /// <summary>
        /// Delete an instance of DynamicFormCategory.
        /// </summary>
        /// <param name="item">Id of DynamicFormCategory instance to be deleted</param>
        /// <returns>Update repsonse of type DynamicFormCategory</returns>
        public static async Task<UpdateResponse<DynamicFormCategory>> DeleteDynamicFormCategory(string id)
        {
            CancellationToken token = new CancellationToken();
            try
            {
                var VMService = ServiceLocator.Current.GetInstance<IViewModelService>();

                return await VMService.DataService.Shared.DeleteDynamicFormCategory(id, token);
            }
            catch (OperationCanceledException)
            { }

            return null;
        }
        */
        #endregion

        #endregion
    }
}
