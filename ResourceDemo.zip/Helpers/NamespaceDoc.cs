﻿namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods and attached properties commonly used in 
    /// the user interface.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
