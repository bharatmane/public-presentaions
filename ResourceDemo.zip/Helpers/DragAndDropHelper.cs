﻿using System.Collections;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.DragDrop;
using Telerik.Windows.DragDrop.Behaviors;
using VShips.Framework.Common.ViewModel;
using DragEventArgs = Telerik.Windows.DragDrop.DragEventArgs;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of attached properties that attempts to simplify telerik drag and drop.
    /// </summary>
    public static class DragAndDropHelper
    {
        /// <summary>
        /// The drag data name
        /// </summary>
        internal const string DragDataName = "DragAndDropHelperData";
        /// <summary>
        /// The drag data success name
        /// </summary>
        internal const string DragDataSuccessName = "DragAndDropHelperSuccess";

        /// <summary>
        /// When set to true on a gridviewrow this enables the multirow ddrag and drop.
        /// </summary>
        public static readonly DependencyProperty IsDragEnabledProperty =
            DependencyProperty.RegisterAttached("IsDragEnabled", typeof(bool), typeof(DragAndDropHelper), new PropertyMetadata(false, OnIsDragEnabledChanged));
        /// <summary>
        /// Setter for the attached property <see cref="IsDragEnabledProperty" />.
        /// </summary>
        /// <param name="element">The gridview row to attach to.</param>
        /// <param name="value">If true drag and drop was enabled.</param>
        public static void SetIsDragEnabled(UIElement element, bool value)
        {
            element.SetValue(IsDragEnabledProperty, value);
        }
        /// <summary>
        /// Gets the value of the attached property <see cref="IsDragEnabledProperty" />.
        /// </summary>
        /// <param name="element">The gridview row it is attached to.</param>
        /// <returns>
        /// True if drag is enabled.
        /// </returns>
        public static bool GetIsDragEnabled(UIElement element)
        {
            return (bool)element.GetValue(IsDragEnabledProperty);
        }

        /// <summary>
        /// Sets up a drop target allowing you to respond to drag requests on the viewmodel.
        /// </summary>
        public static readonly DependencyProperty DropTargetProperty =
            DependencyProperty.RegisterAttached("DropTarget", typeof(IDropTarget), typeof(DragAndDropHelper), new PropertyMetadata(null, OnDropHandlerChanged));
        /// <summary>
        /// Setter for the attached property <see cref="DropTargetProperty" />.
        /// </summary>
        /// <param name="element">The UIElement to attach.</param>
        /// <param name="value">A class that implements <see cref="IDropTarget" />.</param>
        public static void SetDropTarget(UIElement element, IDropTarget value)
        {
            element.SetValue(DropTargetProperty, value);
        }
        /// <summary>
        /// Gets the value of the attached property <see cref="DropTargetProperty" />.
        /// </summary>
        /// <param name="element">The element it is attached to.</param>
        /// <returns>
        /// The <see cref="IDropTarget" /> implementation.
        /// </returns>
        public static IDropTarget GetDropTarget(UIElement element)
        {
            return (IDropTarget)element.GetValue(DropTargetProperty);
        }

        /// <summary>
        /// Use to notify the source of the drag and drop operation
        /// that the operation was succesful.
        /// </summary>
        public static readonly DependencyProperty DragSourceProperty =
            DependencyProperty.RegisterAttached("DragSource", typeof(IDragSource), typeof(DragAndDropHelper), new PropertyMetadata(null));
        /// <summary>
        /// Setter for the attached property <see cref="DragSourceProperty" />.
        /// </summary>
        /// <param name="element">The UIElement to attach.</param>
        /// <param name="value">A class that implements <see cref="IDragSource" />.</param>
        public static void SetDragSource(UIElement element, IDragSource value)
        {
            element.SetValue(DragSourceProperty, value);
        }
        /// <summary>
        /// Gets the value of the attached property <see cref="DragSourceProperty" />.
        /// </summary>
        /// <param name="element">The element it is attached to.</param>
        /// <returns>
        /// The <see cref="IDragSource" /> implementation.
        /// </returns>
        public static IDragSource GetDragSource(UIElement element)
        {
            return (IDragSource)element.GetValue(DragSourceProperty);
        }

        /// <summary>
        /// Called when [drop handler changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDropHandlerChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var target = e.NewValue as IDropTarget;
            if (target != null)
            {
                var uiElement = d as UIElement;
                if (uiElement != null) uiElement.AllowDrop = true;
                DragDropManager.AddDropHandler(d, DropHandler);
            }
            else
            {
                DragDropManager.RemoveDropHandler(d, DropHandler);
            }
        }

        /// <summary>
        /// Called when [is drag enabled changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsDragEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var gridView = (GridViewRow)d;
            if ((bool)e.NewValue)
            {
                DragDropManager.AddDragInitializeHandler(gridView, OnGridDragInitialise);
                DragDropManager.AddDragDropCompletedHandler(gridView, OnGridDropComplete);
                DragDropManager.SetAllowDrag(gridView, true);
                DragDropManager.SetAllowCapturedDrag(gridView, true);
                DragDropManager.SetTouchDragTrigger(gridView, TouchDragTrigger.TapAndHold);
            }
            else
            {
                DragDropManager.RemoveDragInitializeHandler(gridView, OnGridDragInitialise);
                DragDropManager.RemoveDragDropCompletedHandler(gridView, OnGridDropComplete);
            }
        }

        /// <summary>
        /// Drops the handler.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragEventArgs"/> instance containing the event data.</param>
        private static void DropHandler(object sender, DragEventArgs e)
        {
            var control = e.Source as UIElement;
            if (control != null)
            {
                var dropTarget = GetDropTarget(control);
                if (dropTarget != null)
                {

                    var dataObject = e.Data.GetType() == typeof(DataObject) ? (DataObject)e.Data : null;
                    var datat = e.Data.ToEnumerable<object>();
                    if (dataObject != null)
                    {
                        //This is for drag and drop of files
                        var hasFiles = dataObject.GetDataPresent(DataFormats.FileDrop);
                        if (hasFiles)
                        {
                            var files = (string[])dataObject.GetData(DataFormats.FileDrop);
                            var items = files.Select(x => new FileDragData(x)).ToList();

                            if (dropTarget.CanDrop(items))
                            {
                                dropTarget.Drop(items);
                            }
                        }
                        else
                        {
                            var data = ((IEnumerable)((DataObject)e.Data).GetData(DragDataName)).OfType<IDragData>().ToList();
                            if (dropTarget.CanDrop(data))
                            {
                                dropTarget.Drop(data);
                                DragDropPayloadManager.SetData(e.Data, DragDataSuccessName, true);
                            }
                        }

                    }
                    //else
                    //{
                    //    //This is for drag and drop of data
                    //    var payloadObject = (IDragPayload)e.Data;

                    //    var hasFramework = payloadObject.GetDataPresent(DragDataName);
                    //    if (hasFramework)
                    //    {
                    //        var items = ((IEnumerable)payloadObject.GetData(DragAndDropHelper.DragDataName)).OfType<IDragData>().ToList();

                    //        if (dropTarget.CanDrop(items))
                    //        {
                    //            dropTarget.Drop(items);
                    //            DragDropPayloadManager.SetData(e.Data, DragDataSuccessName, true);
                    //        }
                    //    }
                    //}
                }
            }
        }

        /// <summary>
        /// Called when [grid drop complete].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragDropCompletedEventArgs"/> instance containing the event data.</param>
        private static void OnGridDropComplete(object sender, DragDropCompletedEventArgs e)
        {
            var isDropSuccessful = DragDropPayloadManager.GetDataFromObject(e.Data, DragDataSuccessName);
            if (isDropSuccessful != null && (bool)isDropSuccessful)
            {
                var gridViewRow = (GridViewRow)e.OriginalSource;
                var dragSource = GetDragSource(gridViewRow);
                if (dragSource != null)
                {
                    var items = ((IEnumerable)((DataObject)e.Data).GetData(DragDataName)).OfType<IDragData>().ToList();
                    dragSource.DragComplete(items);
                }
            }
        }

        /// <summary>
        /// Called when [grid drag initialise].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragInitializeEventArgs"/> instance containing the event data.</param>
        private static void OnGridDragInitialise(object sender, DragInitializeEventArgs e)
        {
            var gridViewRow = (GridViewRow)e.OriginalSource;
            var gridView = UIHelper.FindVisualParent<RadGridView>(gridViewRow);
            if (gridView != null)
            {
                var payload = DragDropPayloadManager.GeneratePayload(null);
                var data = gridView.SelectedItems.Where(x => x != null).OfType<IDragData>().ToList();
                payload.SetData(DragDataName, data);
                e.Data = payload;
                e.DragVisual = new ContentControl
                {
                    Content = DragAndDropItems.GetDragItems(data)
                };
                e.AllowedEffects = DragDropEffects.Move;
            }
        }


    }
}
