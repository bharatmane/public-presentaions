﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of common user interface helper methods.
    /// </summary>
    public static class UIHelper
    {
        /// <summary>
        /// Finds the first parent matching a specific type on the logical tree.
        /// </summary>
        /// <typeparam name="T">The type of the parent to find</typeparam>
        /// <param name="child">The child within the parents visual tree</param>
        /// <returns>The a element matching the specified type or null if one cant be found</returns>
        /// <example>
        /// The following example uses the FindLogicalParent method to find the Popup control
        /// that contains the MenuItem.
        /// <code lang="C#" title="C#">
        /// <![CDATA[
        /// var menuItem = (MenuItem)e.OriginalSource;
        /// var popup = UIHelper.FindLogicalParent<Popup>(menuItem);]]>
        /// </code>
        /// </example>
        public static T FindLogicalParent<T>(DependencyObject child) where T : DependencyObject
        {
            var parentObject = LogicalTreeHelper.GetParent(child);
            var parent = parentObject as T;
            return parent ?? FindLogicalParent<T>(parentObject);
        }

        /// <summary>
        /// Finds the first parent matching a specific type on the visual tree.
        /// </summary>
        /// <typeparam name="T">The type of the parent to find</typeparam>
        /// <param name="child">The child within the parents visual tree</param>
        /// <param name="maxSearchElement">The maximum element on the visual tree for the search.</param>
        /// <returns>The a element matching the specified type or null if one cant be found</returns>
        /// <example>
        /// The following example uses the FindVisualParent method to find the RadGridView control
        /// that contains the GridViewRow.
        /// <code lang="C#" title="C#">
        /// <![CDATA[
        /// var gridViewRow = (GridViewRow)e.OriginalSource;
        /// var gridView = UIHelper.FindVisualParent<RadGridView>(gridViewRow);]]>
        /// </code>
        /// </example>
        public static T FindVisualParent<T>(DependencyObject child, DependencyObject maxSearchElement = null) where T : DependencyObject
        {
            if (!(child is Visual)) return null;
            var parentObject = VisualTreeHelper.GetParent(child);
            if (parentObject == null || Equals(parentObject, maxSearchElement)) return null;
            var parent = parentObject as T;
            return parent ?? FindVisualParent<T>(parentObject);
        }
        

        /// <summary>
        /// Finds the first child matching a specific type on the visual tree
        /// </summary>
        /// <typeparam name="T">The type of the child to find</typeparam>
        /// <param name="parent">The parent element</param>
        /// <returns>The first child on the visual tree matching the supplied type</returns>
        /// <example>
        /// The following example uses the FindVisualChild method to find the first child
        /// of type RadGridView from its parent RadTileViewItem.
        /// <code lang="C#" title="C#">
        /// <![CDATA[
        /// var item = e.Source as RadTileViewItem;
        /// var grid = UIHelper.FindVisualChild<RadGridView>(item)]]>  
        /// </code>
        /// </example>
        public static T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            if (parent != null)
            {
                for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
                {
                    var child = VisualTreeHelper.GetChild(parent, i);
                    if (child is T)
                    {
                        return (T)child;
                    }

                    var childItem = FindVisualChild<T>(child);
                    if (childItem != null) return childItem;
                }
            }
            return null;
        }

        /// <summary>
        /// Finds all children matching the specific type
        /// </summary>
        /// <param name="parent">The parent element</param>
        /// <typeparam name="T">The type of the children to find</typeparam>
        /// <returns>A collection of items under the parents visual tree who matches the specified type.</returns>
        /// /// <example>
        /// The following example uses the FindVisualChildren method to find all the children
        /// of type RadGridView from its parent RadTileViewItem.
        /// <code lang="C#" title="C#">
        /// <![CDATA[
        /// var item = e.Source as RadTileViewItem;
        /// var grid = UIHelper.FindVisualChildren<RadGridView>(item)]]>  
        /// </code>
        /// </example>
        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject parent) where T : DependencyObject
        {
            if (parent != null)
            {
                for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
                {
                    var child = VisualTreeHelper.GetChild(parent, i);
                    var item = child as T;
                    if (item != null)
                    {
                        yield return item;
                    }

                    foreach (var childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        /// <summary>
        /// Determines if the item is in the parents visual tree
        /// </summary>
        /// <param name="item">The item in the tree</param>
        /// <param name="parent">The parent of the item</param>
        /// <param name="maxSearchElement">The maximum element on the visual tree for the search.</param>
        /// <returns>True if the item is a descendant of the parent</returns>
        public static bool HasVisualParent(DependencyObject item, DependencyObject parent, DependencyObject maxSearchElement = null)
        {
            while (item != null)
            {
                if (Equals(item, parent))
                {
                    return true;
                }
                if (Equals(item, maxSearchElement))
                {
                    return false;
                }
                item = item is Visual ? VisualTreeHelper.GetParent(item) : LogicalTreeHelper.GetParent(item);
            }
            return false;
        }

        /// <summary>
        /// Test if the current relative postion of the mouse is over a visual element
        /// </summary>
        /// <typeparam name="T">The type of the visual element</typeparam>
        /// <param name="relativeControl">The visual element to hit test</param>
        /// <returns>If the mouse is over the control</returns>
        public static bool IsHitTestWithin<T>(T relativeControl) where T : Visual, IInputElement
        {
            var pos = Mouse.GetPosition(relativeControl);
            var ht = VisualTreeHelper.HitTest(relativeControl, pos);
            if (ht != null && ht.VisualHit != null)
            {
                return HasVisualParent(ht.VisualHit, relativeControl);
            }
            return false;
        }
    }
}
