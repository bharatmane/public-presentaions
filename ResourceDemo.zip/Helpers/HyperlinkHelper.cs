﻿using System.Diagnostics;
using System.Windows.Documents;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods relating to the Hyperlink control.
    /// </summary>
    public static class HyperlinkHelper
    {
        /// <summary>
        /// Processes the press of a hyperlink by
        /// taking the uri and determining if it is an 
        /// EMail or web address.
        /// </summary>
        /// <param name="hyperlink">The hyperlink to process.</param>
        public static void ProcessHyperlink(Hyperlink hyperlink)
        {
            if (hyperlink != null)
            {
                try
                {
                    var uri = hyperlink.NavigateUri;

                    if (uri != null)
                    {
                        if (uri.IsAbsoluteUri) // Process as website
                        {
                            Process.Start(uri.AbsolutePath);
                        }
                        else if (uri.OriginalString.Contains("@")) //Process as Email
                        {
                            var address = string.Concat("mailto:", uri.OriginalString);
                            Process.Start(address);
                        }
                        else
                        {
                            Process.Start(uri.OriginalString);
                        }
                    }
                }
                catch 
                {
                }
            }
        }
    }
}
