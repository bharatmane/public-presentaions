﻿using VShips.DataServices.Shared.DataAttributes;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// The TimeLinecontrol intervals
    /// </summary>
    public enum TimeLineControlIntervals
    {
        /// <summary>
        /// The month interval
        /// </summary>
        [EnumValueData(Name = "Months", KeyValue = "M")]
        Month,

        /// <summary>
        /// The quarter interval
        /// </summary>
        [EnumValueData(Name = "Quarter", KeyValue = "Q")]
        Quarter,

        /// <summary>
        /// The week interval
        /// </summary>
        [EnumValueData(Name = "Weeks", KeyValue = "W")]
        Week,
    }

    /// <summary>
    /// The Berth types.
    /// </summary>
    public enum BerthType
    {
        /// <summary>
        /// The budgeted berth
        /// </summary>
        [EnumValueData(Name = "Budgeted Berth", KeyValue = "BG")]
        BudgetedBerth,

        /// <summary>
        /// The extra berth tech
        /// </summary>
        [EnumValueData(Name = "Extra Berth Tech", KeyValue = "ET")]
        ExtraBerthTech,

        /// <summary>
        /// The extra berth owner
        /// </summary>
        [EnumValueData(Name = "Extra Berth Owner", KeyValue = "EO")]
        ExtraBerthOwner,

        /// <summary>
        /// The training berth
        /// </summary>
        [EnumValueData(Name = "Training Berth", KeyValue = "TG")]
        TrainingBerth,

        /// <summary>
        /// The expired berth
        /// </summary>
        [EnumValueData(Name = "Expired Berth", KeyValue = "EX")]
        ExpiredBerth,

        /// <summary>
        /// The overlap berth
        /// </summary>
        [EnumValueData(Name = "Overlap Berth", KeyValue = "OV")]
        OverlapBerth,
    }
    /// <summary>
    /// LookupShowDetailsType
    /// </summary>

    public enum LookupShowDetailsType
    {
        /// <summary>
        /// The no details
        /// </summary>
        [EnumValueData(Name = "NoDetails", KeyValue = "NoDetails")]
        NoDetails,

        /// <summary>
        /// The allow details
        /// </summary>
        [EnumValueData(Name = "AllowDetails", KeyValue = "AllowDetails")]
        AllowDetails,

        /// <summary>
        /// The show details in popup
        /// </summary>
        [EnumValueData(Name = "ShowDetailsInPopup", KeyValue = "ShowDetailsInPopup")]
        ShowDetailsInPopup,

        /// <summary>
        /// The load information on click
        /// </summary>
        [EnumValueData(Name = "LoadInfoOnClick", KeyValue = "LoadInfoOnClick")]
        LoadInfoOnClick,
    }
}
