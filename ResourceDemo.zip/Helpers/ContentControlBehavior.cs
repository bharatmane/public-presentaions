﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A behaviour that animates the change of a content control.
    /// </summary>
    public static class ContentControlBehavior
    {
        /// <summary>
        /// The animation to apply when the content changes.
        /// </summary>
        public static readonly DependencyProperty ContentChangedAnimationProperty = 
            DependencyProperty.RegisterAttached("ContentChangedAnimation", typeof(Storyboard), typeof(ContentControlBehavior), new PropertyMetadata(default(Storyboard), ContentChangedAnimationPropertyChangedCallback));
        /// <summary>
        /// Sets the animation attached property.
        /// </summary>
        public static void SetContentChangedAnimation(DependencyObject element, Storyboard value)
        {
            element.SetValue(ContentChangedAnimationProperty, value);
        }
        /// <summary>
        /// Gets the animation attached property.
        /// </summary>
        public static Storyboard GetContentChangedAnimation(DependencyObject element)
        {
            return (Storyboard)element.GetValue(ContentChangedAnimationProperty);
        }

        private static void ContentChangedAnimationPropertyChangedCallback(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var contentControl = dependencyObject as ContentControl;
            if (contentControl != null)
            {
                var propertyDescriptor = DependencyPropertyDescriptor.FromProperty(ContentControl.ContentProperty, typeof(ContentControl));
                propertyDescriptor.RemoveValueChanged(contentControl, ContentChangedHandler);
                propertyDescriptor.AddValueChanged(contentControl, ContentChangedHandler);
            }

            var contentPresenter = dependencyObject as ContentPresenter;
            if (contentPresenter != null)
            {
                var propertyDescriptor = DependencyPropertyDescriptor.FromProperty(ContentPresenter.ContentProperty, typeof(ContentPresenter));
                propertyDescriptor.RemoveValueChanged(contentPresenter, ContentChangedHandler);
                propertyDescriptor.AddValueChanged(contentPresenter, ContentChangedHandler);
            }

            if (contentPresenter == null && contentControl == null)
            {
                throw new Exception("The ContentControlBehavior can only be applied to a ContentControl or ContentPresenter.");
            }
        }

        private static void ContentChangedHandler(object sender, EventArgs eventArgs)
        {
            var animateObject = (FrameworkElement)sender;
            var storyboard = GetContentChangedAnimation(animateObject);
            storyboard.Begin(animateObject);
        }
    }
}
