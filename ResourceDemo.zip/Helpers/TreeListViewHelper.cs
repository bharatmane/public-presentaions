﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using VShips.Framework.Resource.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Helper class for <see cref="RadTreeListView"/>
    /// </summary>
    public class TreeListViewHelper
    {
        #region Dependency Properties

        /// <summary>
        /// The additional columns property
        /// </summary>
        public static readonly DependencyProperty AdditionalColumnsProperty =
            DependencyProperty.RegisterAttached("AdditionalColumns", typeof(IEnumerable), typeof(TreeListViewHelper), new PropertyMetadata(null, OnAdditionalColumnsChanged));

        /// <summary>
        /// The right click fix property
        /// </summary>
        public static readonly DependencyProperty RightClickFixProperty =
            DependencyProperty.RegisterAttached("RightClickFix", typeof(bool), typeof(TreeListViewHelper),
                new PropertyMetadata(false, OnRightClickFixChanged));

        /// <summary>
        /// The double click command property
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
           DependencyProperty.RegisterAttached("DoubleClickCommand", typeof(System.Windows.Input.ICommand), typeof(TreeListViewHelper),
               new PropertyMetadata(null, OnDoubleClickCommandChanged));

        /// <summary>
        /// The fix left column count property
        /// </summary>
        public static readonly DependencyProperty FixLeftColumnCountProperty =
            DependencyProperty.RegisterAttached("FixLeftColumnCount", typeof(int), typeof(TreeListViewHelper), new PropertyMetadata(0));


        /// <summary>
        /// The fix right column count property
        /// </summary>
        public static readonly DependencyProperty FixRightColumnCountProperty =
            DependencyProperty.RegisterAttached("FixRightColumnCount", typeof(int), typeof(TreeListViewHelper), new PropertyMetadata(0));

        /// <summary>
        /// The column data loaded property
        /// ColumnDataLoaded property is created to check if the data required for dynamic (additional) columns is loaded i.e. received from service 
        /// as we need to generate the columns once the data is avaliable (OnAdditionalColumnsProperty) change do the same thing but it is called once the column list binded is initalised 
        /// and if we add the items after initilisation it do not fire and dynamic (additional) columns are not generated. 
        /// </summary>
        public static readonly DependencyProperty ColumnDataLoadedProperty =
            DependencyProperty.RegisterAttached("ColumnDataLoaded", typeof(bool), typeof(TreeListViewHelper),
                new PropertyMetadata(true, OnColumnDataLoadedChanged));

        #endregion

        #region Methods

        /// <summary>
        /// Called when [right click fix changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type <see cref="DependencyObject"/>.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnRightClickFixChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            if ((bool)eventArgs.NewValue)
            {
                var treeListView = (RadTreeListView)dependencyObject;

                treeListView.PreviewMouseRightButtonDown += (sender, args) =>
                {
                    var row = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)args.OriginalSource);
                    if (row != null)
                    {
                        row.IsSelected = true;
                    }
                };
            }
        }

        /// <summary>
        /// Called when [column data loaded changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        /// <exception cref="System.NotImplementedException"></exception>
        private static void OnColumnDataLoadedChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            if ((bool)eventArgs.NewValue)
            {
                var control = (RadTreeListView)dependencyObject;
                var result = GetAdditionalColumns(control);
                var columns = result != null ? result.OfType<object>().ToList() : new List<object>();
                GenerateColumns(control, columns);
            }
        }

        /// <summary>
        /// Called when [double click command changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDoubleClickCommandChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            if ((System.Windows.Input.ICommand)eventArgs.NewValue != null)
            {
                var treeListView = (RadTreeListView)dependencyObject;

                treeListView.MouseDoubleClick += (sender, args) =>
                {
                    var row = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)args.OriginalSource);
                    if (row != null)
                    {
                        ((System.Windows.Input.ICommand)eventArgs.NewValue).Execute(null);
                    }
                };
            }
        }

        /// <summary>
        /// Exposes the <see cref="ColumnDataLoadedProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadTreeListView))]
        public static void SetColumnDataLoaded(UIElement element, bool value)
        {
            element.SetValue(ColumnDataLoadedProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="ColumnDataLoadedProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value of type <see cref="UIElement"/>.</param>
        /// <returns>Single bool value.</returns>
        public static bool GetColumnDataLoaded(UIElement element)
        {
            return (bool)element.GetValue(ColumnDataLoadedProperty);
        }

        /// <summary>
        /// Exposes the <see cref="RightClickFixProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadTreeListView))]
        public static void SetRightClickFix(UIElement element, bool value)
        {
            element.SetValue(RightClickFixProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="RightClickFixProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value of type <see cref="UIElement"/>.</param>
        /// <returns>Single bool value.</returns>
        public static bool GetRightClickFix(UIElement element)
        {
            return (bool)element.GetValue(RightClickFixProperty);
        }

        /// <summary>
        /// Sets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetDoubleClickCommand(UIElement element, System.Windows.Input.ICommand value)
        {
            element.SetValue(DoubleClickCommandProperty, value);
        }

        /// <summary>
        /// Gets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static System.Windows.Input.ICommand GetDoubleClickCommand(UIElement element)
        {
            return (System.Windows.Input.ICommand)element.GetValue(DoubleClickCommandProperty);
        }

        /// <summary>
        /// Sets the additional columns.
        /// </summary>
        /// <param name="element">The element of type <see cref="UIElement"/>.</param>
        /// <param name="value">The value of type <see cref="IEnumerable"/>.</param>
        public static void SetAdditionalColumns(UIElement element, IEnumerable value)
        {
            element.SetValue(AdditionalColumnsProperty, value);
        }

        /// <summary>
        /// Gets the additional columns.
        /// </summary>
        /// <param name="element">The element of type <see cref="UIElement"/>.</param>
        /// <returns>Single object of type <see cref="IEnumerable"/>.</returns>
        public static IEnumerable GetAdditionalColumns(UIElement element)
        {
            return (IEnumerable)element.GetValue(AdditionalColumnsProperty);
        }

        /// <summary>
        /// Exposes the <see cref="FixLeftColumnCountProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadTreeListView))]
        public static void SetFixLeftColumnCount(UIElement element, int value)
        {
            element.SetValue(FixLeftColumnCountProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="FixLeftColumnCountProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value of type <see cref="UIElement"/>.</param>
        /// <returns>Single int value.</returns>
        public static int GetFixLeftColumnCount(UIElement element)
        {
            return (int)element.GetValue(FixLeftColumnCountProperty);
        }

        /// <summary>
        /// Exposes the <see cref="FixRightColumnCountProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadTreeListView))]
        public static void SetFixRightColumnCount(UIElement element, int value)
        {
            element.SetValue(FixRightColumnCountProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="FixRightColumnCountProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value of type <see cref="UIElement"/>.</param>
        /// <returns>Single int value.</returns>
        public static int GetFixRightColumnCount(UIElement element)
        {
            return (int)element.GetValue(FixRightColumnCountProperty);
        }

        /// <summary>
        /// Called when [additional columns changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type <see cref="DependencyObject"/>.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnAdditionalColumnsChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            var control = (RadTreeListView)dependencyObject;
            var result = eventArgs.NewValue as IEnumerable;
            var columns = result != null ? result.OfType<object>().ToList() : new List<object>();
            bool dataLoaded = GetColumnDataLoaded(control);
            if (dataLoaded)
            {
                if (control.IsLoaded)
                {
                    GenerateColumns(control, columns);
                }
                else
                {
                    control.Loaded += ControlOnLoaded;
                }
            }
        }

        /// <summary>
        /// Controls the on loaded.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArgs">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void ControlOnLoaded(object sender, RoutedEventArgs eventArgs)
        {
            var control = (RadTreeListView)sender;
            control.Loaded -= ControlOnLoaded;
            var result = GetAdditionalColumns(control);
            var columns = result != null ? result.OfType<object>().ToList() : new List<object>();
            GenerateColumns(control, columns);
        }

        /// <summary>
        /// Generates the columns.
        /// </summary>
        /// <param name="treeList">The tree list of type <see cref="RadTreeListView"/>.</param>
        /// <param name="columns">The columns.</param>
        private static void GenerateColumns(RadTreeListView treeList, List<object> columns)
        {
            int FixLeftColumnCount = GetFixLeftColumnCount(treeList);
            int FixRightColumnCount = GetFixRightColumnCount(treeList);

            if (FixLeftColumnCount > 0 || FixRightColumnCount > 0)
            {
                if (treeList.Columns != null)
                {
                    //Remove Columns if already added.
                    int count = treeList.Columns.Count;
                    for (int i = count - 1 - FixRightColumnCount; i >= FixLeftColumnCount; i--)
                    {
                        treeList.Columns.Remove(treeList.Columns[i]);
                    }
                }
            }

            var groupHeaderNameList = new List<Tuple<string, string>>();
            var groupHeaderTemplateTextList = new List<Tuple<string, string>>();

            for (var columnIndex = 0; columnIndex < columns.Count; columnIndex++)
            {
                var column = columns[columnIndex];
                var data = new VGridViewGenericColumn();

                var headerGroupName = column.GetType().GetProperty("HeaderGroupName").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerGroupName))
                {
                    data.ColumnGroupName = headerGroupName;
                }

                var headerGroupText = column.GetType().GetProperty("HeaderGroupText").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerGroupText) && !groupHeaderNameList.Any(x => x.Item1 == headerGroupName))
                {
                    groupHeaderNameList.Add(Tuple.Create(headerGroupName, headerGroupText));
                }

                // If Column group header Contains DataTemplate
                var headerGroupTemplateText = column.GetType().GetProperty("HeaderGroupTemplate").GetValue(column) as string;
                if (!string.IsNullOrEmpty(headerGroupTemplateText)
                    && !string.IsNullOrWhiteSpace(headerGroupName)
                    && !groupHeaderTemplateTextList.Any(x => x.Item1 == headerGroupName))
                {
                    if (!groupHeaderNameList.Any(x => x.Item1 == headerGroupName))
                    {
                        groupHeaderNameList.Add(Tuple.Create(headerGroupName, string.Empty));
                    }
                    groupHeaderTemplateTextList.Add(Tuple.Create(headerGroupName, headerGroupTemplateText));
                }

                bool? columnVisibility = null;
                if (column.GetType().GetProperty("IsColumnVisible") != null)
                {
                    columnVisibility = column.GetType().GetProperty("IsColumnVisible").GetValue(column) as bool?;
                }
                if (columnVisibility != null)
                {
                    var binding = new Binding("IsColumnVisible") { Source = column, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged };
                    data.SetBinding(VGridViewGenericColumn.IsVisibleProperty, binding);
                }

                var headerStyleName = column.GetType().GetProperty("HeaderStyle").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerStyleName))
                {
                    TextBlock header = new TextBlock();
                    header.Text = column.GetType().GetProperty("Header").GetValue(column) as string;
                    header.Style = treeList.FindResource(headerStyleName) as Style;
                    data.Header = header;
                }
                else
                {
                    data.SetBinding(VGridViewGenericColumn.HeaderProperty, new Binding("Header") { Source = column });
                }

                var columnTemplateName = column.GetType().GetProperty("ContentTemplate").GetValue(column) as string;

                if (!string.IsNullOrWhiteSpace(columnTemplateName))
                {
                    data.DataMemberBinding = new Binding(string.Format("Columns[{0}]", columnIndex));
                    data.CellTemplate = treeList.FindResource(columnTemplateName) as DataTemplate;
                }
                else
                {
                    data.DataMemberBinding = new Binding(string.Format("Columns[{0}].Value", columnIndex));
                }

                var columnEditTemplateName = column.GetType().GetProperty("ContentEditTemplate").GetValue(column) as string;

                if (!string.IsNullOrWhiteSpace(columnEditTemplateName))
                {
                    data.IsReadOnly = false;
                    data.CellEditTemplate = treeList.FindResource(columnEditTemplateName) as DataTemplate;
                }
                else
                {
                    data.IsReadOnly = true;
                }

                string columnFooterValue = null, columnFooterStyle = null;
                if (column.GetType().GetProperty("FooterValue") != null)
                {
                    columnFooterValue = column.GetType().GetProperty("FooterValue").GetValue(column) as string;
                }
                if (columnFooterValue != null)
                {
                    var binding = new Binding("FooterValue") { Source = column, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged };
                    data.SetBinding(VGridViewGenericColumn.FooterProperty, binding);
                }

                if (column.GetType().GetProperty("FooterStyle") != null)
                {
                    columnFooterStyle = column.GetType().GetProperty("FooterStyle").GetValue(column) as string;
                }
                if (!string.IsNullOrWhiteSpace(columnFooterStyle))
                {
                    data.FooterCellStyle = treeList.FindResource(columnFooterStyle) as Style;
                }

                string columnCellStyle = null;

                if (column.GetType().GetProperty("CellStyle") != null)
                {
                    columnCellStyle = column.GetType().GetProperty("CellStyle").GetValue(column) as string;
                }
                if (!string.IsNullOrWhiteSpace(columnCellStyle))
                {
                    data.CellStyle = treeList.FindResource(columnCellStyle) as Style;
                }

                if (column.GetType().GetProperty("TabStopMode") != null && Equals(column.GetType().GetProperty("TabStopMode").PropertyType, typeof(GridViewTabStop)))
                {
                    data.SetBinding(VGridViewGenericColumn.TabStopModeProperty, new Binding("TabStopMode")
                    {
                        Source = column,
                        FallbackValue = GridViewTabStop.Stop,
                        TargetNullValue = GridViewTabStop.Stop
                    });
                }

                treeList.Columns.Insert(treeList.Columns.Count - FixRightColumnCount, data);
            }
            groupHeaderNameList.ForEach(x =>
            {
                if (!groupHeaderTemplateTextList.Any(z => z.Item1 == x.Item1))
                {
                    GridViewColumnGroup newColumngroup = new GridViewColumnGroup();
                    newColumngroup.Name = x.Item1;
                    var newTextBlock = new FrameworkElementFactory(typeof(TextBlock));
                    newTextBlock.SetValue(TextBlock.TextProperty, x.Item2);
                    newTextBlock.SetValue(TextBlock.TextAlignmentProperty, TextAlignment.Left);
                    newTextBlock.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
                    DataTemplate newDataTemplate = new DataTemplate() { VisualTree = newTextBlock };
                    newColumngroup.HeaderTemplate = newDataTemplate;
                    if (treeList.ColumnGroups.All(y => !Convert.ToString(y.Name).Equals(newColumngroup.Name)))
                    {
                        treeList.ColumnGroups.Add(newColumngroup);
                    }
                }
                else
                {
                    for (int countIndex = 0; countIndex < groupHeaderTemplateTextList.Count; countIndex++)
                    {
                        GridViewColumnGroup newColumngroup = new GridViewColumnGroup();
                        newColumngroup.Name = groupHeaderTemplateTextList[countIndex].Item1;
                        newColumngroup.HeaderTemplate = treeList.FindResource(groupHeaderTemplateTextList[countIndex].Item2) as DataTemplate;
                        if (treeList.ColumnGroups.All(a => !Convert.ToString(a.Name).Equals(newColumngroup.Name)))
                        {
                            treeList.ColumnGroups.Add(newColumngroup);
                        }
                    }
                }
            });
        }
        #endregion
    }
}