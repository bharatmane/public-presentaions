﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Helper class for AutoCompleteBox
    /// </summary>
    public static class AutoCompleteBoxHelper
    {
        /// <summary>
        /// The email regex
        /// </summary>
        private static readonly Regex _emailRegex = new Regex(@"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\Z", RegexOptions.IgnoreCase);
       
        /// <summary>
        /// Gets the is email box.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetIsEmailBox(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsEmailBoxProperty);
        }

        /// <summary>
        /// Sets the is email box.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetIsEmailBox(DependencyObject obj, bool value)
        {
            obj.SetValue(IsEmailBoxProperty, value);
        }

        /// <summary>
        /// The is email box property
        /// </summary>
        public static readonly DependencyProperty IsEmailBoxProperty =
            DependencyProperty.RegisterAttached("IsEmailBox", typeof(bool), typeof(AutoCompleteBoxHelper), new PropertyMetadata(false, OnIsEmailBoxChanged));

        /// <summary>
        /// Gets the selected email identifier.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static string GetSelectedEmailId(DependencyObject obj)
        {
            return (string)obj.GetValue(SelectedEmailIdProperty);
        }

        /// <summary>
        /// Sets the selected email identifier.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetSelectedEmailId(DependencyObject obj, string value)
        {
            obj.SetValue(SelectedEmailIdProperty, value);
        }

        /// <summary>
        /// The selected email identifier property
        /// </summary>
        /// This property is made to temporarily store the Selected value of the AutoCompleteBox for email when Selection Mode is Single
        public static readonly DependencyProperty SelectedEmailIdProperty =
            DependencyProperty.RegisterAttached("SelectedEmailId", typeof(string), typeof(AutoCompleteBoxHelper), new PropertyMetadata(""));
                      
        /// <summary>
        /// Called when [is email box changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsEmailBoxChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var autoCompleteBox = d as RadAutoCompleteBox;
            autoCompleteBox.AddHandler(CommandManager.ExecutedEvent, new RoutedEventHandler(SetSelectedItems), true);
            autoCompleteBox.AddHandler(Keyboard.KeyUpEvent, new KeyEventHandler(SetSelectedItems), false);
        }

        /// <summary>
        /// Sets the selected items.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void SetSelectedItems(object sender, RoutedEventArgs e)
        {
            var autoCompleteBox = sender as RadAutoCompleteBox;
            string content = autoCompleteBox.SearchText;
            var items = new ObservableCollection<string>();
            if (autoCompleteBox.SelectionMode == Telerik.Windows.Controls.Primitives.AutoCompleteSelectionMode.Multiple)
                items.AddRange(autoCompleteBox.SelectedItems);
            var eventArgs = (e as ExecutedRoutedEventArgs);

            //This event is attached when selection of text with mouse is done
            var textBox = autoCompleteBox.FindChildByType<TextBox>();
            textBox.SelectionChanged += (textbox, textboxArgs) =>
            {
                var _textBox = textbox as TextBox;
                var autoComplete = UIHelper.FindVisualParent<RadAutoCompleteBox>(_textBox);

                if (autoComplete != null && AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox) != null && _textBox != null && _textBox.SelectedText == AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox))
                {
                    AutoCompleteBoxHelper.SetSelectedEmailId(autoComplete, null);
                }
            };


            if (e is ExecutedRoutedEventArgs && (e as ExecutedRoutedEventArgs).Command == ApplicationCommands.Paste)
            {
                if (!string.IsNullOrWhiteSpace(content) && (content.Contains("\r\n") || content.Contains(";") || content.Contains(",") || content.Contains("<") || content.Contains(">")))
                {
                    content = content.Replace("\r", "");
                    content = content.Replace("\n", ",");
                    content = content.Replace(";", ",");
                    content = content.Replace("<", ",");
                    content = content.Replace(">", ",");
                    var data = content.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var item in data)
                    {
                        if (!string.IsNullOrWhiteSpace(item) && _emailRegex.IsMatch(item.Trim()))
                        {
                            items.Add(item.Trim());
                        }
                    }                    
                    content = null;
                }
            }
            else if (e is KeyEventArgs && (e as KeyEventArgs).Key == Key.Enter)
            {
                if (!string.IsNullOrWhiteSpace(content) && _emailRegex.IsMatch(content.Trim()))
                {
                    items.Add(content.Trim());
                    content = null;
                }
            }
            else if (eventArgs != null && AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox) != null && textBox.SelectedText == AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox)
                && (eventArgs.Command == EditingCommands.SelectLeftByCharacter || eventArgs.Command == EditingCommands.SelectLeftByWord
                || eventArgs.Command == EditingCommands.SelectRightByCharacter || eventArgs.Command == EditingCommands.SelectRightByWord 
                || eventArgs.Command == EditingCommands.SelectToLineEnd || eventArgs.Command == EditingCommands.SelectToLineStart))
            {
                AutoCompleteBoxHelper.SetSelectedEmailId(autoCompleteBox, null);
            }
            else if (eventArgs != null && eventArgs.Command == ApplicationCommands.SelectAll)
            {
                AutoCompleteBoxHelper.SetSelectedEmailId(autoCompleteBox, null);
            }


            if (items != null && items.Any() && autoCompleteBox.SelectionMode == Telerik.Windows.Controls.Primitives.AutoCompleteSelectionMode.Multiple)
            {
                autoCompleteBox.SelectedItems = items;
                autoCompleteBox.SearchText = content;
            }
            else if (items != null && items.Any() && autoCompleteBox.SelectionMode == Telerik.Windows.Controls.Primitives.AutoCompleteSelectionMode.Single)
            {
                if (AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox) == null && e is ExecutedRoutedEventArgs && (e as ExecutedRoutedEventArgs).Command == ApplicationCommands.Paste)
                {
                    autoCompleteBox.SelectedItem = items.FirstOrDefault();
                    AutoCompleteBoxHelper.SetSelectedEmailId(autoCompleteBox, autoCompleteBox.SelectedItem.ToString());
                }
                else if (string.IsNullOrEmpty(autoCompleteBox.SearchText))
                {
                    AutoCompleteBoxHelper.SetSelectedEmailId(autoCompleteBox, null);
                }
                else if (AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox) != null)
                {
                    autoCompleteBox.SelectedItem = AutoCompleteBoxHelper.GetSelectedEmailId(autoCompleteBox);
                }
            }
        }
    }
}
