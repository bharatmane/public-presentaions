﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using Telerik.Windows.Controls;
using VShips.Contracts.DtoClasses.FormAssignmentTypes;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Helper class to build a dynamic type class from a collection of field names types and data.
    /// </summary>
    public static class DynamicTypeBuilderHelper
    {
        #region Static Methods

        /// <summary>
        /// Method to return a collection of dynamic types built from a collection of field names types and data
        /// </summary>
        /// <param name="layout">A collection of type FormGridLayout that describe the field names and types for the desired dynamic type.</param>
        /// <param name="data">A collection of type FormData that contains the field data for the desired dynamic type.</param>
        /// <returns>An observable collection of dynamic types</returns>
        public static ObservableCollection<dynamic> CreateNewObject(IEnumerable<GridViewDataColumn> layout, IEnumerable<FormData> data)
        {
            var list = new ObservableCollection<dynamic>();

            var myType = CompileResultType(layout);

            for (int i = 0; i < data.Where(x => x.RowIndex != null).GroupBy(x => x.RowIndex).Count(); i++)
            {
                var myObject = Activator.CreateInstance(myType);

                foreach (var p in myType.GetProperties())
                {
                    FormData d = data.Where(x => x.RowIndex == i && x.FieldName == p.Name).FirstOrDefault();

                    if (d != null)
                    {
                        p.SetValue(myObject, d.FieldValue);
                    }
                }
                list.Add(myObject);
            }

            if (list.Count == 0)
            {
                var myObject = Activator.CreateInstance(myType);
                list.Add(myObject);
            }

            return list;
        }

        /// <summary>
        /// Creates the new index of the object with row.
        /// </summary>
        /// <param name="layout">The layout.</param>
        /// <param name="data">The data.</param>
        /// <returns>Observable collection of type ynamic.</returns>
        public static ObservableCollection<dynamic> CreateNewObjectWithRowIndex(IEnumerable<GridViewDataColumn> layout, IEnumerable<FormData> data)
        {
            var list = new ObservableCollection<dynamic>();

            var myType = CompileResultType(layout);

            int[] rowIndexes = data.Where(x => x.RowIndex != null).Select(x => x.RowIndex.Value).Distinct().ToArray();
            foreach (int rowIndex in rowIndexes)
            {
                var myObject = Activator.CreateInstance(myType);

                foreach (var p in myType.GetProperties())
                {
                    if (!string.IsNullOrWhiteSpace(p.Name) && p.Name.Equals("RowIndex"))
                    {
                        p.SetValue(myObject, rowIndex);
                    }
                    else
                    {
                        FormData d = data.Where(x => x.RowIndex == rowIndex && x.FieldName == p.Name).FirstOrDefault();

                        if (d != null)
                        {
                            p.SetValue(myObject, d.FieldValue);
                        }
                    }
                }
                list.Add(myObject);
            }

            if (list.Count == 0)
            {
                var myObject = Activator.CreateInstance(myType);
                list.Add(myObject);
            }

            return list;
        }

        /// <summary>
        /// Creates a Type based on a colllection of field names and field types.
        /// </summary>
        /// <param name="data">A collection of type FormGridLayout that contains the field data for the desired type.</param>
        /// <returns>A Type generated from the suplised field names and field types</returns>
        public static Type CompileResultType(IEnumerable<VShips.Contracts.DtoClasses.FormAssignmentTypes.FormGridLayout> data)
        {
            TypeBuilder tb = GetTypeBuilder();
            ConstructorBuilder constructor = tb.DefineDefaultConstructor(MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.RTSpecialName);

            // NOTE: assuming your list contains Field objects with fields FieldName(string) and FieldType(Type)
            foreach (var field in data)
            {
                CreateProperty(tb, field.ColumnName, Type.GetType(field.ColumnType));
            }

            Type objectType = tb.CreateType();
            return objectType;
        }

        /// <summary>
        /// Compiles the type of the result.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns>Single object of type<see cref="Type"/>.</returns>
        public static Type CompileResultType(IEnumerable<GridViewDataColumn> data)
        {
            TypeBuilder tb = GetTypeBuilder();
            ConstructorBuilder constructor = tb.DefineDefaultConstructor(MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.RTSpecialName);

            // NOTE: assuming your list contains Field objects with fields FieldName(string) and FieldType(Type)
            foreach (var field in data)
            {
                CreateProperty(tb, field.Name, field.DataType != null ? field.DataType : typeof(String));
            }

            Type objectType = tb.CreateType();
            return objectType;
        }

        /// <summary>
        /// Gets the type builder.
        /// </summary>
        /// <returns>Single object of type<see cref="TypeBuilder"/>.</returns>
        private static TypeBuilder GetTypeBuilder()
        {
            var typeSignature = "MyDynamicType";
            var an = new AssemblyName(typeSignature);
            AssemblyBuilder assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(an, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule("MainModule");
            TypeBuilder tb = moduleBuilder.DefineType(typeSignature,
                    TypeAttributes.Public |
                    TypeAttributes.Class |
                    TypeAttributes.AutoClass |
                    TypeAttributes.AnsiClass |
                    TypeAttributes.BeforeFieldInit |
                    TypeAttributes.AutoLayout,
                    null);
            return tb;
        }

        /// <summary>
        /// Creates the property.
        /// </summary>
        /// <param name="tb">The tb.</param>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="propertyType">Type of the property.</param>
        private static void CreateProperty(TypeBuilder tb, string propertyName, Type propertyType)
        {
            FieldBuilder fieldBuilder = tb.DefineField("_" + propertyName, propertyType, FieldAttributes.Private);

            PropertyBuilder propertyBuilder = tb.DefineProperty(propertyName, System.Reflection.PropertyAttributes.HasDefault, propertyType, null);
            MethodBuilder getPropMthdBldr = tb.DefineMethod("get_" + propertyName, MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig, propertyType, Type.EmptyTypes);
            ILGenerator getIl = getPropMthdBldr.GetILGenerator();

            getIl.Emit(OpCodes.Ldarg_0);
            getIl.Emit(OpCodes.Ldfld, fieldBuilder);
            getIl.Emit(OpCodes.Ret);

            MethodBuilder setPropMthdBldr =
                tb.DefineMethod("set_" + propertyName,
                  MethodAttributes.Public |
                  MethodAttributes.SpecialName |
                  MethodAttributes.HideBySig,
                  null, new[] { propertyType });

            ILGenerator setIl = setPropMthdBldr.GetILGenerator();
            System.Reflection.Emit.Label modifyProperty = setIl.DefineLabel();
            System.Reflection.Emit.Label exitSet = setIl.DefineLabel();

            setIl.MarkLabel(modifyProperty);
            setIl.Emit(OpCodes.Ldarg_0);
            setIl.Emit(OpCodes.Ldarg_1);
            setIl.Emit(OpCodes.Stfld, fieldBuilder);

            setIl.Emit(OpCodes.Nop);
            setIl.MarkLabel(exitSet);
            setIl.Emit(OpCodes.Ret);

            propertyBuilder.SetGetMethod(getPropMthdBldr);
            propertyBuilder.SetSetMethod(setPropMthdBldr);
        }

        #endregion
    }
}