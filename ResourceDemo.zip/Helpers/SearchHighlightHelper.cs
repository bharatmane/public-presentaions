﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Data;
using VShips.Framework.Resource.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// To highlight the search text in the control
    /// </summary>
    public static class SearchHighlightHelper
    {
        #region Private Properties
        /// <summary>
        /// The regex
        /// </summary>
        private static Regex _regex;

        /// <summary>
        /// The text search text
        /// </summary>
        private static string _searchText = "";

        /// <summary>
        /// The color
        /// </summary>
        private static Brush _backgroundHighlightColor = (SolidColorBrush)Application.Current.TryFindResource("BrushSearchHighlight");
        #endregion

        #region Attached Properties
        /// <summary>
        /// Gets the is search highlighted.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetEnableTreeListSearchHighlight(DependencyObject obj)
        {
            return (bool)obj.GetValue(EnableTreeListSearchHighlightProperty);
        }

        /// <summary>
        /// Sets the is search highlighted.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetEnableTreeListSearchHighlight(DependencyObject obj, bool value)
        {
            obj.SetValue(EnableTreeListSearchHighlightProperty, value);
        }

        /// <summary>
        /// The is search highlighted property
        /// </summary>
        public static readonly DependencyProperty EnableTreeListSearchHighlightProperty =
            DependencyProperty.RegisterAttached("EnableTreeListSearchHighlight", typeof(bool), typeof(SearchHighlightHelper), new PropertyMetadata(false, OnEnableTreeListSearchHighlightChanged));


        /// <summary>
        /// Gets the is grid view search highlighted.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetEnableGridViewSearchHighlight(DependencyObject obj)
        {
            return (bool)obj.GetValue(EnableGridViewSearchHighlightProperty);
        }

        /// <summary>
        /// Sets the is grid view search highlighted.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetEnableGridViewSearchHighlight(DependencyObject obj, bool value)
        {
            obj.SetValue(EnableGridViewSearchHighlightProperty, value);
        }

        /// <summary>
        /// The is grid view search highlighted property
        /// </summary>
        public static readonly DependencyProperty EnableGridViewSearchHighlightProperty =
            DependencyProperty.RegisterAttached("EnableGridViewSearchHighlight", typeof(bool), typeof(SearchHighlightHelper), new PropertyMetadata(false, OnEnableGridViewSearchHighlightChanged));



        /// <summary>
        /// Gets the is TreeView search highlighted.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetEnableTreeViewSearchHighlight(DependencyObject obj)
        {
            return (bool)obj.GetValue(EnableTreeViewSearchHighlightProperty);
        }

        /// <summary>
        /// Sets the is TreeView search highlighted.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetEnableTreeViewSearchHighlight(DependencyObject obj, bool value)
        {
            obj.SetValue(EnableTreeViewSearchHighlightProperty, value);
        }

        /// <summary>
        /// The is TreeView search highlighted property
        /// </summary>
        public static readonly DependencyProperty EnableTreeViewSearchHighlightProperty =
            DependencyProperty.RegisterAttached("EnableTreeViewSearchHighlight", typeof(bool), typeof(SearchHighlightHelper), new PropertyMetadata(false, OnEnableTreeViewSearchHighlightChanged));



        /// <summary>
        /// Gets the search text.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static string GetSearchText(DependencyObject obj)
        {
            return (string)obj.GetValue(SearchTextProperty);
        }

        /// <summary>
        /// Sets the search text.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetSearchText(DependencyObject obj, string value)
        {
            obj.SetValue(SearchTextProperty, value);
        }

        /// <summary>
        /// The search text property
        /// </summary>
        public static readonly DependencyProperty SearchTextProperty =
            DependencyProperty.RegisterAttached("SearchText", typeof(string), typeof(SearchHighlightHelper), new PropertyMetadata(OnSearchTextChanged));



        /// <summary>
        /// Gets the search highlight brush.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static SolidColorBrush GetSearchHighlightBackgroundBrush(DependencyObject obj)
        {
            return (SolidColorBrush)obj.GetValue(SearchHighlightBackgroundBrushProperty);
        }

        /// <summary>
        /// Sets the search highlight brush.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetSearchHighlightBackgroundBrush(DependencyObject obj, SolidColorBrush value)
        {
            obj.SetValue(SearchHighlightBackgroundBrushProperty, value);
        }

        /// <summary>
        /// The search highlight brush property
        /// </summary>
        public static readonly DependencyProperty SearchHighlightBackgroundBrushProperty =
            DependencyProperty.RegisterAttached("SearchHighlightBackgroundBrush", typeof(SolidColorBrush), typeof(SearchHighlightHelper), new PropertyMetadata(_backgroundHighlightColor, OnSearchHighlightBackgroundBrushChanged));

        #endregion

        #region Methods
        /// <summary>
        /// Called when [is TreeView search highlighted changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnEnableTreeViewSearchHighlightChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var treeView = dependencyObject as RadTreeView;
            if ((bool)(e.NewValue))
            {
                treeView.ItemPrepared += OnTreeViewItemPrepared;
                treeView.Unloaded += OnTreeViewUnloaded;
            }
        }

        /// <summary>
        /// Called when [is grid view search highlighted changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnEnableGridViewSearchHighlightChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var gridView = dependencyObject as VGridView;
            if ((bool)(e.NewValue))
            {
                gridView.Filtering += OnGridViewFiltering;
                gridView.Unloaded += OnGridViewUnloaded;
            }
        }

        /// <summary>
        /// Called when [is tree list search highlighted changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnEnableTreeListSearchHighlightChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var treeListView = dependencyObject as VTreeListView;
            if ((bool)(e.NewValue))
            {
                treeListView.Filtering += OnTreeListFiltering;
                treeListView.Unloaded += OnTreeListUnloaded;
            }
        }

        /// <summary>
        /// Called when [TreeView item prepared].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RadTreeViewItemPreparedEventArgs"/> instance containing the event data.</param>
        private static void OnTreeViewItemPrepared(object sender, RadTreeViewItemPreparedEventArgs e)
        {
            RadTreeView treeView = sender as RadTreeView;
            FindControlItem(treeView);
        }

        /// <summary>
        /// Called when [tree list filtering].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="GridViewFilteringEventArgs"/> instance containing the event data.</param>
        private static void OnTreeListFiltering(object sender, GridViewFilteringEventArgs e)
        {
            if (e.Added.Count() > 0)
            {
                foreach (OperatorValueFilterDescriptorBase filterData in e.Added)
                {
                    (e.Source as VTreeListView).CellLoaded += (s, ex) =>
                    {
                        var columnName = e != null ? e.ColumnFilterDescriptor.Column : null;
                        if (columnName == ex.Cell.Column)
                        {
                            string searchedText = "";
                            foreach (Telerik.Windows.Controls.GridViewColumn column in (ex.Source as VTreeListView).Columns)
                            {
                                if (e.ColumnFilterDescriptor.Column == column)
                                {
                                    string columnSearchText1 = column.ColumnFilterDescriptor.FieldFilter.Filter1.Value.ToString();
                                    string columnSearchText2 = column.ColumnFilterDescriptor.FieldFilter.Filter2.Value.ToString();
                                    string filterSearchText = filterData.Value.ToString();
                                    searchedText = columnSearchText1.Equals(filterSearchText, StringComparison.CurrentCultureIgnoreCase) ? columnSearchText1 : searchedText;
                                    searchedText = columnSearchText2.Equals(filterSearchText, StringComparison.CurrentCultureIgnoreCase) ? columnSearchText2 : searchedText;
                                }
                            }
                            TextBlock contentText = ex.Cell.ChildrenOfType<TextBlock>().ToList().FirstOrDefault();
                            string textBlockText = contentText == null || string.IsNullOrWhiteSpace(contentText.Text) ? "" : contentText.Text.ToString();
                            textBlockText = string.IsNullOrWhiteSpace(textBlockText) || contentText.ToolTip == null ? textBlockText : contentText.ToolTip.ToString();

                            if (string.IsNullOrEmpty(textBlockText))
                            {
                                return;
                            }
                            contentText.Inlines.Clear();

                            string searchstring = searchedText;
                            string compareText = textBlockText;
                            string displayText = textBlockText;
                            while (!string.IsNullOrEmpty(searchstring) && compareText.IndexOf(searchstring, StringComparison.CurrentCultureIgnoreCase) >= 0)
                            {
                                int position = compareText.IndexOf(searchstring, StringComparison.CurrentCultureIgnoreCase);
                                contentText.Inlines.Add(displayText.Substring(0, position));

                                contentText.Inlines.Add(
                                    new Run(displayText.Substring(position, searchstring.Length))
                                    {
                                        Background = _backgroundHighlightColor
                                    });
                                compareText = compareText.Substring(position + searchstring.Length);
                                displayText = displayText.Substring(position + searchstring.Length);
                            }
                            contentText.Inlines.Add(displayText);
                        }
                    };
                }
            }
            else
            {
                (e.Source as VTreeListView).CellLoaded -= (s, ex) => { };
            }
        }

        /// <summary>
        /// Called when [grid view filtering].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="GridViewFilteringEventArgs"/> instance containing the event data.</param>
        private static void OnGridViewFiltering(object sender, GridViewFilteringEventArgs e)
        {
            if (e.Added.Count() > 0)
            {
                foreach (OperatorValueFilterDescriptorBase filterData in e.Added)
                {
                    (e.Source as VGridView).CellLoaded += (s, ex) =>
                    {
                        var columnName = e != null ? e.ColumnFilterDescriptor.Column : null;
                        if (columnName == ex.Cell.Column)
                        {
                            string searchedText = "";
                            foreach (Telerik.Windows.Controls.GridViewColumn column in (ex.Source as VGridView).Columns)
                            {
                                if (e.ColumnFilterDescriptor.Column == column)
                                {
                                    string columnSearchText1 = column.ColumnFilterDescriptor.FieldFilter.Filter1.Value.ToString();
                                    string columnSearchText2 = column.ColumnFilterDescriptor.FieldFilter.Filter2.Value.ToString();
                                    string filterSearchText = filterData.Value.ToString();
                                    searchedText = columnSearchText1.Equals(filterSearchText, StringComparison.CurrentCultureIgnoreCase) ? columnSearchText1 : searchedText;
                                    searchedText = columnSearchText2.Equals(filterSearchText, StringComparison.CurrentCultureIgnoreCase) ? columnSearchText2 : searchedText;
                                }
                            }
                            TextBlock contentText = ex.Cell.ChildrenOfType<TextBlock>().ToList().FirstOrDefault();
                            string textBlockText = contentText == null || string.IsNullOrWhiteSpace(contentText.Text) ? "" : contentText.Text.ToString();
                            textBlockText = string.IsNullOrWhiteSpace(textBlockText) || contentText.ToolTip == null ? textBlockText : contentText.ToolTip.ToString();

                            if (string.IsNullOrEmpty(textBlockText))
                            {
                                return;
                            }
                            contentText.Inlines.Clear();

                            string searchstring = searchedText;
                            string compareText = textBlockText;
                            string displayText = textBlockText;
                            while (!string.IsNullOrEmpty(searchstring) && compareText.IndexOf(searchstring, StringComparison.CurrentCultureIgnoreCase) >= 0)
                            {
                                int position = compareText.IndexOf(searchstring, StringComparison.CurrentCultureIgnoreCase);
                                contentText.Inlines.Add(displayText.Substring(0, position));

                                contentText.Inlines.Add(
                                    new Run(displayText.Substring(position, searchstring.Length))
                                    {
                                        Background = _backgroundHighlightColor
                                    });
                                compareText = compareText.Substring(position + searchstring.Length);
                                displayText = displayText.Substring(position + searchstring.Length);
                            }
                            contentText.Inlines.Add(displayText);
                        }
                    };
                }
            }
            else
            {
                (e.Source as VGridView).CellLoaded -= (s, ex) => { };
            }
        }

        /// <summary>
        /// Called when [search text changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSearchTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            _searchText = e.NewValue.ToString();
            FindControlItem(d);
        }

        /// <summary>
        /// Called when [search highlight brush changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSearchHighlightBackgroundBrushChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((Brush)e.NewValue != null)
            {
                _backgroundHighlightColor = (Brush)e.NewValue;
            }
        }

        /// <summary>
        /// Finds the control item.
        /// </summary>
        /// <param name="treeView">The tree view.</param>
        public static void FindControlItem(DependencyObject treeView)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(treeView); i++)
            {
                RadTreeViewItem tree = treeView as RadTreeViewItem;
                if (tree != null)
                {
                    HighlightText(tree);
                }
                FindControlItem(VisualTreeHelper.GetChild(treeView as DependencyObject, i));
            }
        }

        /// <summary>
        /// Highlights the text.
        /// </summary>
        /// <param name="itx">The itx.</param>
        private static void HighlightText(object itx)
        {
            if (itx != null)
            {
                if (itx is TextBlock)
                {
                    _regex = new Regex("(" + _searchText + ")", RegexOptions.IgnoreCase);
                    TextBlock tb = itx as TextBlock;
                    if (_searchText.Length == 0)
                    {
                        string str = tb.Text;
                        tb.Inlines.Clear();
                        tb.Inlines.Add(str);
                        return;
                    }
                    string[] substrings = _regex.Split(tb.Text);
                    tb.Inlines.Clear();
                    foreach (var item in substrings)
                    {
                        if (_regex.Match(item).Success)
                        {
                            Run runx = new Run(item)
                            {
                                Background = _backgroundHighlightColor
                            };
                            tb.Inlines.Add(runx);
                        }
                        else
                        {
                            tb.Inlines.Add(item);
                        }
                    }
                    return;
                }
                else
                {
                    for (int i = 0; i < VisualTreeHelper.GetChildrenCount(itx as DependencyObject); i++)
                    {
                        HighlightText(VisualTreeHelper.GetChild(itx as DependencyObject, i));
                    }
                }
            }
        }

        /// <summary>
        /// Called when [grid view unloaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void OnGridViewUnloaded(object sender, RoutedEventArgs e)
        {
            var gridView = sender as VGridView;
            gridView.Filtering -= OnGridViewFiltering;
            gridView.Unloaded -= OnGridViewUnloaded;
        }

        /// <summary>
        /// Called when [tree list unloaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void OnTreeListUnloaded(object sender, RoutedEventArgs e)
        {
            var treeListView = sender as VTreeListView;
            treeListView.Filtering -= OnTreeListFiltering;
            treeListView.Unloaded -= OnTreeListUnloaded;
        }

        /// <summary>
        /// Called when [TreeView unloaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void OnTreeViewUnloaded(object sender, RoutedEventArgs e)
        {
            var treeView = sender as RadTreeView;
            treeView.ItemPrepared -= OnTreeViewItemPrepared;
            treeView.Unloaded -= OnTreeListUnloaded;
        }
        #endregion
    }
}