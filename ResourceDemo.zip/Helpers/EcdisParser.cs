﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Microsoft.VisualBasic.FileIO;
using Telerik.Windows.Controls.Map;
using VShips.Framework.Common.Model;
#pragma warning disable 1591

namespace VShips.Framework.Resource.Helpers
{
    public class EcdisParser
    {
        private const double Tolerance = 0.001;
        private const string EcdisParseDistanceError = "Error when trying to extract distance from ECDIS File. Distance cell: {0}";


        public static List<EcdisWaypoint> LoadEcdis(string posId, double charterSpeed)
        {
            var openFileDialog = new OpenFileDialog();
            var dialogResult = openFileDialog.ShowDialog();
            if (dialogResult != DialogResult.OK || !openFileDialog.CheckFileExists)
            {
                return null;
            }

            var fileName = openFileDialog.FileName;

            //Open XLS file
            var xlApp = new Microsoft.Office.Interop.Excel.Application();
            var xlWorkbook = xlApp.Workbooks.Open(fileName);

            if (xlWorkbook.Sheets.Count > 10)
            {
                return ParseMultiSheetEcdis(posId, charterSpeed, xlWorkbook, xlApp);
            }
            
            return ParseSingleSheetEcdis(posId, charterSpeed, fileName);
        }


        private static List<EcdisWaypoint> ParseMultiSheetEcdis(string posId, double charterSpeed, Workbook xlWorkbook, Microsoft.Office.Interop.Excel.Application xlApp)
        {
            var ecdisWaypoints = new List<EcdisWaypoint>();

            var waypointsWorksheet = xlWorkbook.Sheets[8];
            var waypointsRange = waypointsWorksheet.UsedRange;
            var scheduleWorksheet = xlWorkbook.Sheets[11];
            var scheduleRange = scheduleWorksheet.UsedRange;
            int rowCount = waypointsRange.Rows.Count;

            //Parse XLS file
            for (var x = 2; x < rowCount; x++)
            {
                if (waypointsRange.Cells[x, 3] == null || waypointsRange.Cells[x, 3].Value2 == null) continue;
                var waypointNumber = ParseWaypoint(waypointsRange.Cells[x, 1].Value2.ToString());
                var location = ParseCoordinate(waypointsRange.Cells[x, 3].Value2.ToString());
                if (location == null) continue;
                //vvv   if x is 2 this is the first line of the excel file and the speed/distance will be 0   vvv
                var speed = x == 2 ? 0.0 : ParseSpeed(scheduleRange.Cells[x, 8].Value2, charterSpeed);
                var distance = x == 2 ? 0.0 : ParseDistance(waypointsRange.Cells[x, 4].Value2);
                var waypointTimeHours = Math.Abs(speed) < Tolerance || Math.Abs(distance) < Tolerance ? 0.0 : Math.Round(distance / speed, 2);

                ecdisWaypoints.Add(new EcdisWaypoint
                {
                    PosId = posId,
                    WaypointNumber = waypointNumber,
                    Latitude = location.Latitude,
                    Longitude = location.Longitude,
                    Speed = Math.Round(speed, 1),
                    WaypointDistance = Math.Round(distance, 2),
                    WaypointTimeHours = Math.Round(waypointTimeHours, 2)
                });
            }

            ecdisWaypoints = AddIntermediateWaypoints(ecdisWaypoints);

            //Close XLS file and release all resources
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Marshal.ReleaseComObject(waypointsRange);
            Marshal.ReleaseComObject(waypointsWorksheet);
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

            return ecdisWaypoints;
        }


        private static List<EcdisWaypoint> ParseSingleSheetEcdis(string posId, double charterSpeed, string filename)
        {
            var ecdisWaypoints = new List<EcdisWaypoint>();

            var parser = new TextFieldParser(filename)
            {
                TextFieldType = FieldType.Delimited
            };
            parser.SetDelimiters(",");

            double thisLat = 0.0;
            double thisLon = 0.0;
            var waypointNo = 0;

            while (!parser.EndOfData)
            {
                var fields = parser.ReadFields();

                //if (fields == null || fields.Length < 11) continue;
                if (fields == null) continue;

                if (fields.Length >= 11)
                {
                    if (!int.TryParse(fields[0], out waypointNo)) continue;
                }

                var previousLat = thisLat;
                var previousLon = thisLon;
                thisLat = fields.Length < 11 ? double.Parse(fields[0]) : DegreeMinToLatLon(fields[1], fields[2], fields[3]);
                thisLon = fields.Length < 11 ? double.Parse(fields[1]) : DegreeMinToLatLon(fields[4], fields[5], fields[6]);
                var speed = fields.Length < 11 ? charterSpeed : Math.Round(ParseSpeed(fields[10], charterSpeed), 1);
                var distance = CalculateDistance(previousLat, previousLon, thisLat, thisLon);
                var waypointTimeHours = Math.Abs(speed) < Tolerance || Math.Abs(distance) < Tolerance ? 0.0 : Math.Round(distance / speed, 2);

                ecdisWaypoints.Add(new EcdisWaypoint
                {
                    PosId = posId,
                    WaypointNumber = waypointNo,
                    Latitude = thisLat,
                    Longitude = thisLon,
                    Speed = speed,
                    WaypointDistance = Math.Round(distance, 2),
                    WaypointTimeHours = Math.Round(waypointTimeHours, 2)
                });

                waypointNo++;
            }

            ecdisWaypoints = AddIntermediateWaypoints(ecdisWaypoints);

            return ecdisWaypoints;
        }


        private static double DegreeMinToLatLon(string degree, string minute, string orientation)
        {
            try
            {
                var degreeFraction = int.Parse(degree) + (double.Parse(minute) / 60);
                return orientation == "S" || orientation == "W" ? 0 - degreeFraction : degreeFraction;
            }
            catch(Exception)
            {
                return 0.0;
            }
        }


        private static double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
        {
            if (Math.Abs(lat1) < Tolerance && Math.Abs(lon1) < Tolerance) return 0.0;

            var coord1 = new GeoCoordinate(lat1, lon1);
            var coord2 = new GeoCoordinate(lat2, lon2);

            return coord1.GetDistanceTo(coord2) / 1852;
        }


        private static Location? ParseCoordinate(string coordinate)
        {
            var coordinateComponents = coordinate.Split(' ');

            try
            {
                var latitude = double.Parse(Regex.Match(coordinateComponents[0], @"\d+").Value) +
                               double.Parse(coordinateComponents[1]) / 60;
                if (coordinateComponents[2] == "S")
                {
                    latitude = 0 - latitude;
                }

                var longitude = double.Parse(Regex.Match(coordinateComponents[5], @"\d+").Value) +
                                double.Parse(coordinateComponents[6]) / 60;
                if (coordinateComponents[7] == "W")
                {
                    longitude = 0 - longitude;
                }

                return new Location(latitude, longitude);
            }
            catch (Exception)
            {
                return null;
            }
        }


        private static int ParseWaypoint(string waypoint)
        {
            try
            {
                return int.Parse(waypoint);
            }
            catch (Exception)
            {
                return 0;
            }
        }


        private static double ParseSpeed(string speed, double charterSpeed)
        {
            try
            {
                var speedComponents = speed.Split(' ');
                return double.Parse(speedComponents[0]);
            }
            catch (Exception)
            {
                return charterSpeed;
            }
        }


        private static double ParseDistance(string distance)
        {
            try
            {
                var distanceComponents = distance.Split(' ');
                return double.Parse(distanceComponents[3]);
            }
            catch (Exception)
            {
                throw new Exception(string.Format(EcdisParseDistanceError, distance));
            }
        }

        private static List<EcdisWaypoint> AddIntermediateWaypoints(List<EcdisWaypoint> ecdisWaypoints)
        {
            var formattedEcdisWaypoints = new List<EcdisWaypoint>();
            var formattedWaypointNumber = 0;
            var cumulativeDistance = 0.0;
            var cumulativeTimeHours = 0.0;
            var cumulativeIntermediateWaypointDistance = 0.0;
            var cumulativeIntermediateWaypointHours = 0.0;

            for (var x = 0; x < ecdisWaypoints.Count - 1; x++)
            {
                var thisEcdisWaypoint = ecdisWaypoints[x];
                var nextEcdisWaypoint = ecdisWaypoints[x + 1];

                cumulativeDistance += thisEcdisWaypoint.WaypointDistance;
                cumulativeTimeHours += (thisEcdisWaypoint.WaypointDistance > 0 && thisEcdisWaypoint.Speed > 0) ? thisEcdisWaypoint.WaypointDistance / thisEcdisWaypoint.Speed : 0;

                thisEcdisWaypoint.WaypointNumber = formattedWaypointNumber++;
                thisEcdisWaypoint.IntermediateWaypoint = false;
                thisEcdisWaypoint.CumulativeDistance = Math.Round(cumulativeDistance, 2);
                thisEcdisWaypoint.CumulativeTimeHours = Math.Round(cumulativeTimeHours, 2);
                thisEcdisWaypoint.WaypointDistance -= Math.Round(cumulativeIntermediateWaypointDistance, 2);
                thisEcdisWaypoint.WaypointTimeHours -= Math.Round(cumulativeIntermediateWaypointHours, 2);

                formattedEcdisWaypoints.Add(thisEcdisWaypoint);

                cumulativeIntermediateWaypointDistance = 0.0;
                cumulativeIntermediateWaypointHours = 0.0;

                var intermediateWaypoints = (int)(nextEcdisWaypoint.WaypointDistance / (nextEcdisWaypoint.Speed * 3));

                var thisLat = thisEcdisWaypoint.Latitude;
                var thisLon = thisEcdisWaypoint.Longitude < 0 ? 360 + thisEcdisWaypoint.Longitude : thisEcdisWaypoint.Longitude;
                var nextLat = nextEcdisWaypoint.Latitude;
                var nextLon = nextEcdisWaypoint.Longitude < 0 ? 360 + nextEcdisWaypoint.Longitude : nextEcdisWaypoint.Longitude;

                for (var y = 1; y <= intermediateWaypoints; y++)
                {
                    var intermediateFraction = (y * nextEcdisWaypoint.Speed * 3) / nextEcdisWaypoint.WaypointDistance;
                    var fractionLatitude = ((nextLat - thisLat) * intermediateFraction) + thisLat;
                    var fractionLongitude = ((nextLon - thisLon) * intermediateFraction) + thisLon;
                    fractionLongitude = fractionLongitude > 180 ? fractionLongitude - 360 : fractionLongitude;
                    var fractionDistance = (nextEcdisWaypoint.WaypointDistance * intermediateFraction) / y;
                    var waypointTimeHours = fractionDistance / nextEcdisWaypoint.Speed;

                    cumulativeIntermediateWaypointDistance += fractionDistance;
                    cumulativeIntermediateWaypointHours += waypointTimeHours;

                    var lastIntermediateWaypoint = new EcdisWaypoint
                    {
                        PosId = nextEcdisWaypoint.PosId,
                        WaypointNumber = formattedWaypointNumber++,
                        IntermediateWaypoint = true,
                        Latitude = fractionLatitude,
                        Longitude = fractionLongitude,
                        WaypointDistance = Math.Round(fractionDistance, 2),
                        CumulativeDistance = Math.Round(cumulativeDistance + cumulativeIntermediateWaypointDistance, 2),
                        Speed = nextEcdisWaypoint.Speed,
                        WaypointTimeHours = Math.Round(waypointTimeHours, 2),
                        CumulativeTimeHours = Math.Round(cumulativeTimeHours + cumulativeIntermediateWaypointHours, 2)
                    };
                    formattedEcdisWaypoints.Add(lastIntermediateWaypoint);
                }
            }

            return formattedEcdisWaypoints;
        }
    }
}
