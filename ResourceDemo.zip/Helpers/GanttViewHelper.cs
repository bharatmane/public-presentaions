﻿using System.Windows;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GanttView;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Controls.Scheduling;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// Helper class for the <see cref="GanttViewHelper"/>
    /// </summary>
    public class GanttViewHelper
    {

        #region Dependency Properties

        /// <summary>
        /// The double click command property
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
           DependencyProperty.RegisterAttached("DoubleClickCommand", typeof(System.Windows.Input.ICommand), typeof(GanttViewHelper),
               new PropertyMetadata(null, OnDoubleClickCommandChanged));

        #endregion


        #region Properties Get And Set

        /// <summary>
        /// Sets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetDoubleClickCommand(UIElement element, System.Windows.Input.ICommand value)
        {
            element.SetValue(DoubleClickCommandProperty, value);
        }

        /// <summary>
        /// Gets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static System.Windows.Input.ICommand GetDoubleClickCommand(UIElement element)
        {
            return (System.Windows.Input.ICommand)element.GetValue(DoubleClickCommandProperty);
        }

        #endregion


        #region Methods

        /// <summary>
        /// Called when [double click command changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDoubleClickCommandChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            if ((System.Windows.Input.ICommand)eventArgs.NewValue != null)
            {
                var GanttView = (RadGanttView)dependencyObject;

                GanttView.MouseDoubleClick += (sender, args) =>
                {
                    var row = UIHelper.FindVisualParent<CellContainer>((DependencyObject)args.OriginalSource);
                    if (row != null)
                    {
                        ((System.Windows.Input.ICommand)eventArgs.NewValue).Execute(null);
                    }
                };
            }
        }


        #endregion

    }
}
