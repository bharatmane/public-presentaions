﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods for the button control
    /// </summary>
    public static class ButtonHelper
    {
        /// <summary>
        /// An atached property for a button which will close its containing
        /// window when clicked. 
        /// </summary>
        /// <example>
        /// When the button is clicked it will walk the visual tree finding a 
        /// parent which derives from <see cref="WindowBase"/>. Close is called 
        /// if a window is found.
        /// <code lang="XAML" title="XAML">
        /// <![CDATA[
        /// <telerik:RadButton Content="{Binding Content}" 
        ///                    Command="{Binding}" 
        ///                    IsDefault="{Binding IsDefault}"
        ///                    IsCancel="{Binding IsCancel}"
        ///                    helpers:ButtonHelper.CloseOnClick="True"
        ///                    MinWidth="80"
        ///                    Margin="4,0,0,0"/>]]>
        /// </code>
        /// </example>
        public static readonly DependencyProperty CloseOnClickProperty =
            DependencyProperty.RegisterAttached("CloseOnClick", typeof(bool), typeof(ButtonHelper), new FrameworkPropertyMetadata(false, OnCloseOnClickChanged));
        /// <summary>
        /// Exposes the <see cref="CloseOnClickProperty"/> AttachedProperty.
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <param name="value">The value of the property</param>
        [AttachedPropertyBrowsableForType(typeof(Button))]
        public static void SetCloseOnClick(UIElement element, bool value)
        {
            element.SetValue(CloseOnClickProperty, value);
        }
        /// <summary> 
        /// Exposes the <see cref="CloseOnClickProperty"/> AttachedProperty.
        /// </summary>
        /// <param name="element">The element containing the attached property</param>
        /// <returns>The value of the property</returns>
        public static bool GetCloseOnClick(UIElement element)
        {
            return (bool)element.GetValue(CloseOnClickProperty);
        }

        /// <summary>
        /// Called when [close on click changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnCloseOnClickChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var button = (Button)d;
            if ((bool)e.NewValue)
            {
                button.Click += (sender, args) =>
                {
                    var window = UIHelper.FindVisualParent<WindowBase>(button);
                    if (window != null)
                    {
                        window.Dispatcher.BeginInvoke(new Action(() => window.Close()), DispatcherPriority.Background);
                    }
                };
            }
        }
    }

}
