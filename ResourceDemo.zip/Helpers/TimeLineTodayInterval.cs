﻿using System;
using Telerik.Windows.Controls.TimeBar;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// This class is used to include a custom interval in timeline control to show today's date.
    /// </summary>
    public class TimeLineTodayInterval:IntervalBase
    {
         /// <summary>
        /// The formatters
        /// </summary>
        private static readonly Func<DateTime, string>[] _formatters;

        /// <summary>
        /// Initializes the <see cref="TimeLineTodayInterval"/> class.
        /// </summary>
        static TimeLineTodayInterval()
        {
            _formatters = new Func<DateTime, string>[]
            {
                date => "",
            };
        }

        /// <summary>
        /// Extracts the interval start.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns>DateTime value</returns>
        public override DateTime ExtractIntervalStart(DateTime date)
        {
            return DateTime.Now.AddMonths(Constants.TimeLineStartMonthValue);
        }

        /// <summary>
        /// Increments the by interval.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <param name="intervalSpan">The interval span.</param>
        /// <returns>DateTime value</returns>
        public override DateTime IncrementByInterval(DateTime date, int intervalSpan)
        {
            return date.AddMonths(Constants.TimeLineIntervalInMonths);
        }

        /// <summary>
        /// Gets the formatters.
        /// </summary>
        /// <value>
        /// The formatters.
        /// </value>
        public override Func<DateTime, string>[] Formatters
        {
            get
            {
                return _formatters;
            }
        }

        /// <summary>
        /// Gets the minimum length of the period.
        /// </summary>
        /// <value>
        /// The minimum length of the period.
        /// </value>
        public override TimeSpan MinimumPeriodLength
        {
            get
            {
                return TimeSpan.FromDays(Constants.TimeLineMiniumPeriodLength);
            }
        }

    }
}
