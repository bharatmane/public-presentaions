﻿using System.Windows;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods for the combo box control
    /// </summary>
    public static class ComboBoxHelper 
    {

        /// <summary>
        /// Gets the disable back space.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns>Single bool value</returns>
        public static bool GetDisableBackSpace(DependencyObject obj)
        {
            return (bool)obj.GetValue(DisableBackSpaceProperty);
        }

        /// <summary>
        /// Sets the disable back space.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetDisableBackSpace(DependencyObject obj, bool value)
        {
            obj.SetValue(DisableBackSpaceProperty, value);
        }

       
        /// <summary>
        /// The disable back space property
        /// </summary>
        public static readonly DependencyProperty DisableBackSpaceProperty =
            DependencyProperty.RegisterAttached("DisableBackSpace", typeof(bool), typeof(ComboBoxHelper), new PropertyMetadata(false, OnDisableBackSpaceChanged));


        /// <summary>
        /// Called when [disable back space changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDisableBackSpaceChanged(DependencyObject d, DependencyPropertyChangedEventArgs eventArgs)
        {
            ((RadComboBox)d).PreviewKeyDown += ComboBoxHelper_KeyDown;
        }

        /// <summary>
        /// Handles the KeyDown event of the ComboBoxHelper control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="KeyEventArgs"/> instance containing the event data.</param>
        private static void ComboBoxHelper_KeyDown(object sender, KeyEventArgs eventArgs)
        {
            if (eventArgs.Key == Key.Back)
            {
                eventArgs.Handled = true;
            }
        }
    }
}
