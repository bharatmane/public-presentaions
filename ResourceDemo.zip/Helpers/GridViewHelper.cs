﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Controls.TreeListView;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Helpers
{
    /// <summary>
    /// A set of helper methods relating to the RadGridView control.
    /// </summary>
    [Obsolete("The VGridView control should contain everything here.")]
    public static class GridViewHelper
    {

        #region Clicks

        /// <summary>
        /// The command to run when an item on the gridview is double clicked.
        /// The datacontext of the item will be passed as a parameter to the command.
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
            DependencyProperty.RegisterAttached("DoubleClickCommand", typeof (ICommand), typeof (GridViewHelper),
                new PropertyMetadata(null, OnDoubleClickCommandChanged));

        /// <summary>
        /// Exposes the <see cref="DoubleClickCommandProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof (RadGridView))]
        [AttachedPropertyBrowsableForType(typeof(RadTreeListView))]
        [AttachedPropertyBrowsableForType(typeof(RadListBox))]
        [AttachedPropertyBrowsableForType(typeof(ListBox))]
        public static void SetDoubleClickCommand(UIElement element, ICommand value)
        {
            element.SetValue(DoubleClickCommandProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="DoubleClickCommandProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static ICommand GetDoubleClickCommand(UIElement element)
        {
            return (ICommand) element.GetValue(DoubleClickCommandProperty);
        }

        private static void OnDoubleClickCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var command = (ICommand)e.NewValue;
            var gridView = d as RadGridView;
            if (gridView != null)
            {
                GridViewDoubleClick(gridView, command);
            }
            var radListBox = d as RadListBox;
            if (radListBox != null)
            {
                RadListBoxDoubleClick(radListBox, command);
            }
            var listBox = d as ListBox;
            if (listBox != null)
            {
                ListBoxDoubleClick(listBox, command);
            }
            var treeListView = d as RadTreeListView;
            if (treeListView != null)
            {
                TreeListViewDoubleClick(treeListView, command);
            }
        }

        private static void TreeListViewDoubleClick(RadTreeListView treeListView, ICommand command)
        {
            if (command != null)
            {
                treeListView.MouseDoubleClick += TreeListViewOnMouseDoubleClick;
            }
            else
            {
                treeListView.MouseDoubleClick -= TreeListViewOnMouseDoubleClick;
            }
        }

        private static void ListBoxDoubleClick(ListBox listBox, ICommand command)
        {
            if (command != null)
            {
                listBox.MouseDoubleClick += ListBoxOnMouseDoubleClick;
            }
            else
            {
                listBox.MouseDoubleClick -= ListBoxOnMouseDoubleClick;
            }
        }

        private static void GridViewDoubleClick(RadGridView gridView, ICommand command)
        {
            if (command != null)
            {
                gridView.MouseDoubleClick += GridViewOnMouseDoubleClick;
            }
            else
            {
                gridView.MouseDoubleClick -= GridViewOnMouseDoubleClick;
            }
        }

        private static void RadListBoxDoubleClick(RadListBox listBox, ICommand command)
        {
            if (command != null)
            {
                listBox.MouseDoubleClick += RadListBoxOnMouseDoubleClick;
            }
            else
            {
                listBox.MouseDoubleClick -= RadListBoxOnMouseDoubleClick;
            }
        }

        private static void ListBoxOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var listBox = (ListBox)sender;
                var command = GetDoubleClickCommand(listBox);
                var item = UIHelper.FindVisualParent<ListBoxItem>((DependencyObject)e.OriginalSource, listBox);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        private static void RadListBoxOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var listBox = (RadListBox)sender;
                var command = GetDoubleClickCommand(listBox);
                var item = UIHelper.FindVisualParent<RadListBoxItem>((DependencyObject)e.OriginalSource, listBox);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        private static void GridViewOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var gridView = (RadGridView)sender;
                var command = GetDoubleClickCommand(gridView);
                var item = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)e.OriginalSource, gridView);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        private static void TreeListViewOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled)
            {
                var gridView = (RadTreeListView)sender;
                var command = GetDoubleClickCommand(gridView);
                var item = UIHelper.FindVisualParent<TreeListViewRow>((DependencyObject)e.OriginalSource, gridView);
                if (item != null)
                {
                    command.Execute(item.DataContext);
                    e.Handled = true;
                }
            }
        }

        #endregion

        #region Sizing

        /// <summary>
        /// <para>
        /// When the <see cref="CompressStyleProperty"/> is set on a RadGridView and it's size
        /// falls below this value then the compressed row style will be applied.
        /// </para>
        /// <para>The default is 400.</para>
        /// </summary>
        public static readonly DependencyProperty CompressWidthProperty =
            DependencyProperty.RegisterAttached("CompressWidth", typeof(double), typeof(GridViewHelper), new PropertyMetadata(460d));
        /// <summary>
        /// Exposes the <see cref="CompressWidthProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof (RadGridView))]
        public static void SetCompressWidth(UIElement element, double value)
        {
            element.SetValue(CompressWidthProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="CompressWidthProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static double GetCompressWidth(UIElement element)
        {
            return (double)element.GetValue(CompressWidthProperty);
        }

        /// <summary>
        /// A readonly property that is used internally to track if the RadGridView is using its compressed RowStyle.
        /// </summary>
        public static readonly DependencyProperty IsCompressedProperty =
            DependencyProperty.RegisterAttached("IsCompressed", typeof(bool), typeof(GridViewHelper), new PropertyMetadata(false, OnIsCompressedChanged));
        /// <summary>
        /// Exposes the <see cref="IsCompressedProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadGridView))]
        public static void SetIsCompressed(UIElement element, bool value)
        {
            element.SetValue(IsCompressedProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="IsCompressedProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static bool GetIsCompressed(UIElement element)
        {
            return (bool)element.GetValue(IsCompressedProperty);
        }

        /// <summary>
        /// The RowStyle to use on the atached RadGridView when its width falls below the value
        /// of the <see cref="CompressWidthProperty"/> attached property.
        /// </summary>
        public static readonly DependencyProperty CompressStyleProperty =
            DependencyProperty.RegisterAttached("CompressStyle", typeof(Style), typeof(GridViewHelper), new PropertyMetadata(null, OnCompressStyle));
        /// <summary>
        /// Exposes the <see cref="CompressStyleProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(RadGridView))]
        public static void SetCompressStyle(UIElement element, Style value)
        {
            element.SetValue(CompressStyleProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="CompressStyleProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static Style GetCompressStyle(UIElement element)
        {
            return (Style)element.GetValue(CompressStyleProperty);
        }

        /// <summary>
        /// A style used to alognside the <see cref="CompressStyleProperty"/> that allows it track its changes.
        /// </summary>
        public static readonly DependencyProperty UnCompressStyleProperty = 
            DependencyProperty.RegisterAttached("UnCompressStyle", typeof(Style), typeof(GridViewHelper), new PropertyMetadata(null));
        [AttachedPropertyBrowsableForType(typeof(RadGridView))]
        private static void SetUnCompressStyle(UIElement element, Style value)
        {
            element.SetValue(UnCompressStyleProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="UnCompressStyleProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static Style GetUnCompressStyle(UIElement element)
        {
            return (Style)element.GetValue(UnCompressStyleProperty);
        }

        /// <summary>
        /// Used alongside the <see cref="CompressStyleProperty"/> property allowing the template to
        /// be set on the style.
        /// </summary>
        public static readonly DependencyProperty CompressedTemplateProperty =
            DependencyProperty.RegisterAttached("CompressedTemplate", typeof(DataTemplate), typeof(GridViewHelper), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="CompressedTemplateProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(GridViewRow))]
        public static void SetCompressedTemplate(UIElement element, DataTemplate value)
        {
            element.SetValue(CompressedTemplateProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="CompressedTemplateProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static DataTemplate GetCompressedTemplate(UIElement element)
        {
            return (DataTemplate)element.GetValue(CompressedTemplateProperty);
        }

        private static void OnCompressStyle(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var grid = (RadGridView)d;
            if (e.NewValue != null)
            {
                grid.AlternationCount = 0;
                grid.SizeChanged += GridOnSizeChanged;
            }
            else
            {
                grid.SizeChanged -= GridOnSizeChanged;
            }
        }


        private static void GridOnSizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (e.WidthChanged)
            {
                UpdateCompressed((RadGridView)sender);
            }
        }

        private static void OnIsCompressedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UpdateGrid((RadGridView)d);
        }

        private static void UpdateCompressed(RadGridView gridView)
        {
            var resizeWidth = GetCompressWidth(gridView);

            SetIsCompressed(gridView, gridView.ActualWidth <= resizeWidth);
        }

        private static void UpdateGrid(RadGridView gridView)
        {
            var compressStyle = GetCompressStyle(gridView);
            var unCompressStyle = GetUnCompressStyle(gridView);
            var isCompressed = GetIsCompressed(gridView);

            if (isCompressed)
            {
                SetUnCompressStyle(gridView, gridView.RowStyle);
                gridView.RowStyle = compressStyle;
            }
            else
            {
                SetUnCompressStyle(gridView, null);
                gridView.RowStyle = unCompressStyle;
            }
        }

        #endregion

        #region Data

        /// <summary>
        /// An atached property used to force selection on a datagrid which has a contextmenu.
        /// </summary>
        public static readonly DependencyProperty RightClickFixProperty =
            DependencyProperty.RegisterAttached("RightClickFix", typeof (bool), typeof (GridViewHelper),
                new PropertyMetadata(false, OnRightClickFixChanged));

        /// <summary>
        /// Exposes the <see cref="RightClickFixProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof (RadGridView))]
        public static void SetRightClickFix(UIElement element, bool value)
        {
            element.SetValue(RightClickFixProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="RightClickFixProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static bool GetRightClickFix(UIElement element)
        {
            return (bool) element.GetValue(RightClickFixProperty);
        }

        /// <summary>
        /// Attached property that communicates edits, creates and deletes of the RadGridView to the viewmodel.
        /// </summary>
        public static readonly DependencyProperty EditableCollectionProperty =
            DependencyProperty.RegisterAttached("EditableCollection", typeof (IEditableCollection),
                typeof (GridViewHelper), new PropertyMetadata(null, OnEditableCollectionChanged));
        /// <summary>
        /// Exposes the <see cref="EditableCollectionProperty"/> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof (RadGridView))]
        public static void SetEditableCollection(UIElement element, IEditableCollection value)
        {
            element.SetValue(EditableCollectionProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="EditableCollectionProperty"/> attached property. 
        /// </summary>
        /// <param name="element">The element to get the property value.</param>
        /// <returns>The attached command.</returns>
        public static IEditableCollection GetEditableCollection(UIElement element)
        {
            return (IEditableCollection) element.GetValue(EditableCollectionProperty);
        }

        private static void OnEditableCollectionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var dg = d as RadGridView;
            if (dg != null)
            {
                var coll = e.NewValue as IEditableCollection;
                if (coll != null)
                {
                    dg.Deleting += DgOnDeleting;
                    dg.BeginningEdit += DgOnBeginningEdit;
                    dg.RowEditEnded += DgOnRowEditEnded;
                    dg.AddingNewDataItem += DgOnAddingNewDataItem;
                    dg.RowValidating += DgOnRowValidating;
                    dg.SelectionChanged += DgOnSelectionChanged;
                    SetRightClickFix(dg, true);
                }
                else
                {
                    dg.Deleting -= DgOnDeleting;
                    dg.BeginningEdit -= DgOnBeginningEdit;
                    dg.RowEditEnded -= DgOnRowEditEnded;
                    dg.AddingNewDataItem -= DgOnAddingNewDataItem;
                    dg.RowValidating -= DgOnRowValidating;
                    dg.SelectionChanged -= DgOnSelectionChanged;
                    SetRightClickFix(dg, false);
                }
            }
        }

        private static void OnRightClickFixChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool) e.NewValue)
            {
                var dg = (RadGridView) d;

                dg.PreviewMouseRightButtonDown += (sender, args) =>
                {
                    var row = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)args.OriginalSource);
                    if (row != null)
                    {
                        row.IsSelected = true;
                    }
                };
            }
        }

        private static void DgOnSelectionChanged(object sender, SelectionChangeEventArgs e)
        {
            var dg = (RadGridView)sender;
            var coll = GetEditableCollection(dg);
            coll.SelectedItemsChanged(dg.SelectedItems);
        }

        private static void DgOnRowValidating(object sender, GridViewRowValidatingEventArgs e)
        {
            var dg = (RadGridView)sender;
            var coll = GetEditableCollection(dg);
            e.IsValid = coll.Validate(e.Row.DataContext);
        }

        private static void DgOnAddingNewDataItem(object sender, GridViewAddingNewEventArgs e)
        {
            var dg = (RadGridView)sender;
            var coll = GetEditableCollection(dg);
            e.NewObject = coll.Create();
        }

        private static void DgOnBeginningEdit(object sender, GridViewBeginningEditRoutedEventArgs e)
        {
            var dg = (RadGridView)sender;
            var coll = GetEditableCollection(dg);
            var item = e.Row;
            if (item != null && item.DataContext != null)
            {
                var cancel = false;
                coll.BeginEdit(item.DataContext, ref cancel);
                e.Cancel = cancel;
            }
        }

        private static void DgOnRowEditEnded(object sender, GridViewRowEditEndedEventArgs e)
        {
            var dg = (RadGridView)sender;
            var coll = GetEditableCollection(dg);
            var item = e.Row.DataContext;
            if (item != null)
            {
                if (e.EditAction == GridViewEditAction.Commit)
                {
                    coll.Update(item);
                }
                coll.EndEdit(item);
            }
        }

        private static void DgOnDeleting(object sender, GridViewDeletingEventArgs e)
        {
            e.Cancel = true;
            var dg = (RadGridView)sender;
            var coll = GetEditableCollection(dg);
            var item = e.Items.FirstOrDefault();
            if (item != null)
            {
                coll.Delete(item);
            }
        }

        #endregion


    }
}
