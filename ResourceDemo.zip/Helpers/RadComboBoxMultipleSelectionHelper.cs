﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Helpers
{
    public static class RadComboBoxMultipleSelectionHelper
    {
        public static readonly DependencyProperty SelectedItemsProperty =
        DependencyProperty.RegisterAttached("SelectedItems", typeof(IList), typeof(RadComboBoxMultipleSelectionHelper), new FrameworkPropertyMetadata((IList)null, new PropertyChangedCallback(OnSelectedItemsChanged)));

        public static IList GetSelectedItems(DependencyObject d)
        {
            return (IList)d.GetValue(SelectedItemsProperty);
        }

        public static void SetSelectedItems(DependencyObject d, IList value)
        {
            d.SetValue(SelectedItemsProperty, value);
        }

        private static void OnSelectedItemsChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var comboBox = sender as RadComboBox;
            if (comboBox != null)
            {
                var itemsToSelect = e.NewValue as IList;
                foreach (var item in itemsToSelect)
                {
                    comboBox.SelectedItems.Add(item);
                }
            }
        }
    }
}
