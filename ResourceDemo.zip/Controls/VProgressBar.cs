﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// VProgressBar Class
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ItemsControl"/>
    [TemplatePart(Name = "RootElement", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_TotalValue", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_Value", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_ThresholdValue", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_ActualValue", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_Icon", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_ValueLabel", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "PART_RemainingValueLabel", Type = typeof(FrameworkElement))]
    public class VProgressBar : ItemsControl
    {
        #region TemplatePart Name Constants

        /// <summary>
        /// The root element template part name
        /// </summary>
        private const string RootElementTemplatePartName = "RootElement";

        /// <summary>
        /// The total value template part name
        /// </summary>
        private const string TotalValueTemplatePartName = "PART_TotalValue";

        /// <summary>
        /// The value template part name
        /// </summary>
        private const string ValueTemplatePartName = "PART_Value";

        /// <summary>
        /// The threshold value template part name
        /// </summary>
        private const string ThresholdValueTemplatePartName = "PART_ThresholdValue";

        /// <summary>
        /// The actual value template part name
        /// </summary>
        private const string ActualValueTemplatePartName = "PART_ActualValue";

        /// <summary>
        /// The icon template part name
        /// </summary>
        private const string IconTemplatePartName = "PART_Icon";

        /// <summary>
        /// The value label template part name
        /// </summary>
        private const string ValueLabelTemplatePartName = "PART_ValueLabel";

        /// <summary>
        /// The remaining value label template part name
        /// </summary>
        private const string RemainingValueLabelTemplatePartName = "PART_RemainingValueLabel";

        #endregion

        #region Private Properties

        /// <summary>
        /// The root element
        /// </summary>
        private FrameworkElement _rootElement;

        /// <summary>
        /// The part threshold value
        /// </summary>
        private FrameworkElement _partThresholdValue;

        /// <summary>
        /// The part value
        /// </summary>
        private FrameworkElement _partValue;

        /// <summary>
        /// The part actual value
        /// </summary>
        private FrameworkElement _partActualValue;

        /// <summary>
        /// The part total value
        /// </summary>
        private FrameworkElement _partTotalValue;

        /// <summary>
        /// The part icon
        /// </summary>
        private FrameworkElement _partIcon;

        /// <summary>
        /// The part value label
        /// </summary>
        private FrameworkElement _partValueLabel;

        /// <summary>
        /// The part remaining value label
        /// </summary>
        private FrameworkElement _partRemainingValueLabel;

        #endregion

        #region Staic Properties

        /// <summary>
        /// The total value property
        /// </summary>
        public static readonly DependencyProperty TotalValueProperty =
            DependencyProperty.Register("TotalValue", typeof(double), typeof(VProgressBar), new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnTotalValueChanged));

        /// <summary>
        /// The value property
        /// </summary>
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(double), typeof(VProgressBar), new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnValueChanged));

        /// <summary>
        /// The remaining value property
        /// </summary>
        public static readonly DependencyProperty RemainingValueProperty =
            DependencyProperty.Register("RemainingValue", typeof(double), typeof(VProgressBar), new PropertyMetadata(0.0));

        /// <summary>
        /// The threshold value property
        /// </summary>
        public static readonly DependencyProperty ThresholdValueProperty =
            DependencyProperty.Register("ThresholdValue", typeof(double?), typeof(VProgressBar), new FrameworkPropertyMetadata(default(double?), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnThresholdValueChanged));

        /// <summary>
        /// The item placement property path property
        /// </summary>
        public static readonly DependencyProperty ItemPlacementPropertyPathProperty =
            DependencyProperty.Register("ItemPlacementPropertyPath", typeof(string), typeof(VProgressBar), new PropertyMetadata(null));

        /// <summary>
        /// The threshold content property
        /// </summary>
        public static readonly DependencyProperty ThresholdContentProperty =
            DependencyProperty.Register("ThresholdContent", typeof(object), typeof(VProgressBar), new PropertyMetadata(default(object)));

        /// <summary>
        /// The threshold content template property
        /// </summary>
        public static readonly DependencyProperty ThresholdContentTemplateProperty =
            DependencyProperty.Register("ThresholdContentTemplate", typeof(DataTemplate), typeof(VProgressBar), new PropertyMetadata(default(DataTemplate)));

        /// <summary>
        /// The threshold content style property
        /// </summary>
        public static readonly DependencyProperty ThresholdContentStyleProperty =
            DependencyProperty.Register("ThresholdContentStyle", typeof(Style), typeof(VProgressBar), new PropertyMetadata(default(Style)));

        /// <summary>
        /// The value content property
        /// </summary>
        public static readonly DependencyProperty ValueContentProperty =
            DependencyProperty.Register("ValueContent", typeof(object), typeof(VProgressBar), new PropertyMetadata(default(object)));

        /// <summary>
        /// The value content template property
        /// </summary>
        public static readonly DependencyProperty ValueContentTemplateProperty =
            DependencyProperty.Register("ValueContentTemplate", typeof(DataTemplate), typeof(VProgressBar), new PropertyMetadata(default(DataTemplate)));

        /// <summary>
        /// The foreground threshold brush property
        /// </summary>
        public static readonly DependencyProperty ForegroundThresholdBrushProperty =
            DependencyProperty.Register("ForegroundThresholdBrush", typeof(Brush), typeof(VProgressBar), new PropertyMetadata(Brushes.Transparent));

        /// <summary>
        /// The is in threshold range property
        /// </summary>
        public static readonly DependencyProperty IsInThresholdRangeProperty =
            DependencyProperty.Register("IsInThresholdRange", typeof(bool?), typeof(VProgressBar), new PropertyMetadata((default(bool?))));

        /// <summary>
        /// The is icon clipped property
        /// </summary>
        public static readonly DependencyProperty IsIconClippedProperty =
            DependencyProperty.Register("IsIconClipped", typeof(bool), typeof(VProgressBar), new PropertyMetadata(false));

        /// <summary>
        /// The icon height property
        /// </summary>
        public static readonly DependencyProperty IconHeightProperty =
            DependencyProperty.Register("IconHeight", typeof(double), typeof(VProgressBar), new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnIconHeightChanged));

        /// <summary>
        /// The icon property
        /// </summary>
        public static readonly DependencyProperty IconProperty =
            DependencyProperty.Register("Icon", typeof(Geometry), typeof(VProgressBar), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnIconChanged));

        /// <summary>
        /// The is value label clipped property
        /// </summary>
        public static readonly DependencyProperty IsValueLabelClippedProperty =
            DependencyProperty.Register("IsValueLabelClipped", typeof(bool), typeof(VProgressBar), new PropertyMetadata(false));

        /// <summary>
        /// The show value label property
        /// </summary>
        public static readonly DependencyProperty ShowValueLabelProperty =
            DependencyProperty.Register("ShowValueLabel", typeof(bool), typeof(VProgressBar), new PropertyMetadata(false));

        /// <summary>
        /// The is remaining value label clipped property
        /// </summary>
        public static readonly DependencyProperty IsRemainingValueLabelClippedProperty =
            DependencyProperty.Register("IsRemainingValueLabelClipped", typeof(bool), typeof(VProgressBar), new PropertyMetadata(false));

        /// <summary>
        /// The show remaining value label property
        /// </summary>
        public static readonly DependencyProperty ShowRemainingValueLabelProperty =
            DependencyProperty.Register("ShowRemainingValueLabel", typeof(bool), typeof(VProgressBar), new PropertyMetadata(false));

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the total value.
        /// </summary>
        /// <value>
        /// The total value.
        /// </value>
        public double TotalValue
        {
            get { return (double)GetValue(TotalValueProperty); }
            set { SetValue(TotalValueProperty, value); }
        }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value.
        /// </value>
        public double Value
        {
            get { return (double)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        /// <summary>
        /// Gets the remaining value.
        /// </summary>
        /// <value>
        /// The remaining value.
        /// </value>
        public double RemainingValue
        {
            get { return (double)GetValue(RemainingValueProperty); }
            private set { SetValue(RemainingValueProperty, value); }
        }

        /// <summary>
        /// Gets or sets the threshold value.
        /// </summary>
        /// <value>
        /// The threshold value.
        /// </value>
        public double? ThresholdValue
        {
            get { return (double?)GetValue(ThresholdValueProperty); }
            set { SetValue(ThresholdValueProperty, value); }
        }

        /// <summary>
        /// Gets or sets the item placement property path.
        /// </summary>
        /// <value>
        /// The item placement property path.
        /// </value>
        public string ItemPlacementPropertyPath
        {
            get { return (string)GetValue(ItemPlacementPropertyPathProperty); }
            set { SetValue(ItemPlacementPropertyPathProperty, value); }
        }

        /// <summary>
        /// Gets or sets the foreground threshold brush.
        /// </summary>
        /// <value>
        /// The foreground threshold brush.
        /// </value>
        public Brush ForegroundThresholdBrush
        {
            get { return (Brush)GetValue(ForegroundThresholdBrushProperty); }
            set { SetValue(ForegroundThresholdBrushProperty, value); }
        }

        /// <summary>
        /// Gets or sets the height of the icon.
        /// </summary>
        /// <value>
        /// The height of the icon.
        /// </value>
        public double IconHeight
        {
            get { return (double)GetValue(IconHeightProperty); }
            set { SetValue(IconHeightProperty, value); }
        }

        /// <summary>
        /// Gets or sets the icon.
        /// </summary>
        /// <value>
        /// The icon.
        /// </value>
        public Geometry Icon
        {
            get { return (Geometry)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }

        /// <summary>
        /// Gets or sets the content of the threshold.
        /// </summary>
        /// <value>
        /// The content of the threshold.
        /// </value>
        public object ThresholdContent
        {
            get { return (object)GetValue(ThresholdContentProperty); }
            set { SetValue(ThresholdContentProperty, value); }
        }

        /// <summary>
        /// Gets or sets the threshold content template.
        /// </summary>
        /// <value>
        /// The threshold content template.
        /// </value>
        public DataTemplate ThresholdContentTemplate
        {
            get { return (DataTemplate)GetValue(ThresholdContentTemplateProperty); }
            set { SetValue(ThresholdContentTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the threshold content style.
        /// </summary>
        /// <value>
        /// The threshold content style.
        /// </value>
        public Style ThresholdContentStyle
        {
            get { return (Style)GetValue(ThresholdContentStyleProperty); }
            set { SetValue(ThresholdContentStyleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the content of the value.
        /// </summary>
        /// <value>
        /// The content of the value.
        /// </value>
        public object ValueContent
        {
            get { return (object)GetValue(ValueContentProperty); }
            set { SetValue(ValueContentProperty, value); }
        }

        /// <summary>
        /// Gets or sets the value content template.
        /// </summary>
        /// <value>
        /// The value content template.
        /// </value>
        public DataTemplate ValueContentTemplate
        {
            get { return (DataTemplate)GetValue(ValueContentTemplateProperty); }
            set { SetValue(ValueContentTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the is in threshold range.
        /// </summary>
        /// <value>
        /// The is in threshold range.
        /// </value>
        public bool? IsInThresholdRange
        {
            get { return (bool?)GetValue(IsInThresholdRangeProperty); }
            set { SetValue(IsInThresholdRangeProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is icon clipped.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is icon clipped; otherwise, <c>false</c>.
        /// </value>
        public bool IsIconClipped
        {
            get { return (bool)GetValue(IsIconClippedProperty); }
            set { SetValue(IsIconClippedProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value label clipped.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is value label clipped; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueLabelClipped
        {
            get { return (bool)GetValue(IsValueLabelClippedProperty); }
            set { SetValue(IsValueLabelClippedProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [show value label].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show value label]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowValueLabel
        {
            get { return (bool)GetValue(ShowValueLabelProperty); }
            set { SetValue(ShowValueLabelProperty, value); }
        }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is remaining value label clipped.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is remaining value label clipped; otherwise, <c>false</c>.
        /// </value>
        public bool IsRemainingValueLabelClipped
        {
            get { return (bool)GetValue(IsRemainingValueLabelClippedProperty); }
            set { SetValue(IsRemainingValueLabelClippedProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [show remaining value label].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show remaining value label]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowRemainingValueLabel
        {
            get { return (bool)GetValue(ShowRemainingValueLabelProperty); }
            set { SetValue(ShowRemainingValueLabelProperty, value); }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes the <see cref="VProgressBar"/> class.
        /// </summary>
        static VProgressBar()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VProgressBar), new FrameworkPropertyMetadata(typeof(VProgressBar)));
        }

        #endregion

        #region Static Methods

        /// <summary>
        /// Called when [value changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VProgressBar control = d as VProgressBar;
            if (control != null)
            {
                control.UpdateRemainingValue();
                control.UpdateValueProgress();
            }
        }

        /// <summary>
        /// Called when [total distance changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnTotalValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VProgressBar control = d as VProgressBar;
            if (control != null)
            {
                control.UpdateRemainingValue();
                control.UpdateThresholdIndicatorPosition();
                control.UpdateValueProgress();
                control.RefreshItemSource();
            }
        }

        /// <summary>
        /// Called when [threshold value changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnThresholdValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VProgressBar control = d as VProgressBar;
            if (control != null)
            {
                control.UpdateThresholdIndicatorPosition();
                control.UpdateValueProgress();
            }
        }

        /// <summary>
        /// Called when geometry changed.
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIconChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VProgressBar control = d as VProgressBar;
            if (control != null && control._partIcon != null)
            {
                control._partIcon.Width = double.NaN;
            }
        }

        /// <summary>
        /// Called when [geometry height changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIconHeightChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VProgressBar control = d as VProgressBar;
            if (control != null && control._partIcon != null)
            {
                control._partIcon.Width = double.NaN;
            }
        }

        #endregion

        #region Overriden Method

        /// <summary>
        /// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            DettachEvents();

            _rootElement = GetTemplateChild(RootElementTemplatePartName) as FrameworkElement;

            _partThresholdValue = GetTemplateChild(ThresholdValueTemplatePartName) as FrameworkElement;

            _partValue = GetTemplateChild(ValueTemplatePartName) as FrameworkElement;

            _partActualValue = GetTemplateChild(ActualValueTemplatePartName) as FrameworkElement;

            _partTotalValue = GetTemplateChild(TotalValueTemplatePartName) as FrameworkElement;

            _partIcon = GetTemplateChild(IconTemplatePartName) as FrameworkElement;

            _partValueLabel = GetTemplateChild(ValueLabelTemplatePartName) as FrameworkElement;

            _partRemainingValueLabel = GetTemplateChild(RemainingValueLabelTemplatePartName) as FrameworkElement;

            AttachEvents();
        }

        /// <summary>
        /// Determines if the specified item is (or is eligible to be) its own container.
        /// </summary>
        /// <param name="item">The item to check.</param>
        /// <returns>
        /// true if the item is (or is eligible to be) its own container; otherwise, false.
        /// </returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is ContentControl;
        }

        /// <summary>
        /// Creates or identifies the element that is used to display the given item.
        /// </summary>
        /// <returns>
        /// The element that is used to display the given item.
        /// </returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new ContentControl();
        }

        /// <summary>
        /// Prepares the specified element to display the specified item.
        /// </summary>
        /// <param name="element">Element used to display the specified item.</param>
        /// <param name="item">Specified item.</param>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            base.PrepareContainerForItemOverride(element, item);
            ContentControl container = element as ContentControl;
            if (container != null && item != null && _rootElement != null && _rootElement.IsLoaded)
            {
                UpdateItemPosition(container, item);
            }
            else if (container != null)
            {
                container.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Called when [root element size changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void OnRootElementSizeChanged(object sender, SizeChangedEventArgs e)
        {
            Grid rootElement = sender as Grid;
            if (rootElement != null && rootElement.IsLoaded)
            {
                UpdateThresholdIndicatorPosition();
                UpdateValueProgress();
                UpdateRemainingValue();
                RefreshItemSource();    
            }
        }

        /// <summary>
        /// Called when [root element loaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void OnRootElementLoaded(object sender, RoutedEventArgs e)
        {
            UpdateIconWidth();
            UpdateThresholdIndicatorPosition();
            UpdateValueProgress();
            CheckIsIconClipped();
            CheckIsValueLabelClipped();
            CheckIsRemainingValueLabelClipped();
            UpdateRemainingValue();
            RefreshItemSource();
        }

        /// <summary>
        /// Called when [part value size changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void OnPartValueSizeChanged(object sender, SizeChangedEventArgs e)
        {
            CheckIsIconClipped();
            CheckIsValueLabelClipped();
            CheckIsValueLabelClipped();
        }

        /// <summary>
        /// Called when [remaining value text size changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void OnRemainingValueTextSizeChanged(object sender, SizeChangedEventArgs e)
        {
            CheckIsValueLabelClipped();
        }

        /// <summary>
        /// Called when [value text size changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void OnValueTextSizeChanged(object sender, SizeChangedEventArgs e)
        {
            CheckIsValueLabelClipped();
        }

        /// <summary>
        /// Called when [icon size changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void OnIconSizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdateIconWidth();
            CheckIsIconClipped();
        }

        /// <summary>
        /// Gets the property value.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public object GetPropertyValue(string propertyName, object item)
        {
            if (item != null)
            {
                PropertyInfo propinfo = item.GetType().GetProperty(propertyName);
                if (propinfo != null)
                {
                    return propinfo.GetValue(item, null);
                }
                else
                {
                    System.Console.WriteLine(propertyName + " Property not found on " + item.GetType().AssemblyQualifiedName);
                }
            }
            return null;
        }

        /// <summary>
        /// Gets the pixel value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="maxValue">The maximum value.</param>
        /// <param name="maxPixelValue">The maximum pixel value.</param>
        /// <returns> pixel value </returns>
        private double GetPixelValue(double value, double maxValue, double maxPixelValue)
        {
            return maxValue > 0 && value >= 0 && maxPixelValue > 0 ? (value / maxValue) * maxPixelValue : 0.0;
        }

        /// <summary>
        /// Updates the value progress.
        /// </summary>
        private void UpdateValueProgress()
        {
            if (_partValue != null && _partTotalValue != null && _partActualValue != null && _partThresholdValue != null)
            {
                IsInThresholdRange = !ThresholdValue.HasValue ? default(bool?) : Value < ThresholdValue;

                double sailedPixelValue = GetPixelValue(Value <= TotalValue ? (Value > 0 ? Value : 0) : TotalValue, TotalValue, _partTotalValue.ActualWidth);
                _partValue.Width = _partThresholdValue != null && IsInThresholdRange == false ? Canvas.GetLeft(_partThresholdValue) + (_partThresholdValue.ActualWidth / 2) : sailedPixelValue;
                _partActualValue.Width = sailedPixelValue;
            }
        }

        /// <summary>
        /// Updates the threshold indicator position.
        /// </summary>
        private void UpdateThresholdIndicatorPosition()
        {
            if (_partTotalValue != null && _partThresholdValue != null)
            {
                Canvas.SetLeft(_partThresholdValue, !ThresholdValue.HasValue ? double.NaN : GetPixelValue(ThresholdValue <= TotalValue ? (ThresholdValue.Value > 0 ? ThresholdValue.Value : 0) : TotalValue, TotalValue, _partTotalValue.ActualWidth) - _partThresholdValue.ActualWidth / 2);
            }
        }

        /// <summary>
        /// Checks the is icon clipped.
        /// </summary>
        private void CheckIsIconClipped()
        {
            if (_partValue != null && _partTotalValue != null && _partIcon != null)
            {
                IsIconClipped = (_partTotalValue.ActualWidth - _partValue.ActualWidth) < (_partIcon.ActualWidth + _partIcon.Margin.Left + _partIcon.Margin.Right);
            }
        }

        /// <summary>
        /// Checks the is value label clipped.
        /// </summary>
        private void CheckIsValueLabelClipped()
        {
            if (_partValue != null && _partValueLabel != null)
            {
                IsValueLabelClipped = _partValue.ActualWidth < _partValueLabel.ActualWidth;
            }
        }

        /// <summary>
        /// Checks the is remaining value label clipped.
        /// </summary>
        private void CheckIsRemainingValueLabelClipped()
        {
            if (_partValue != null && _partTotalValue != null && _partRemainingValueLabel != null)
            {
                IsRemainingValueLabelClipped = (_partTotalValue.ActualWidth - _partValue.ActualWidth) < _partRemainingValueLabel.ActualWidth;
            }
        }

        /// <summary>
        /// Updates the width of the icon.
        /// </summary>
        private void UpdateIconWidth() 
        {
            if (_partIcon != null && _partIcon.ActualWidth != 0)
            {
                _partIcon.Width = _partIcon.ActualWidth;
            }
        }

        /// <summary>
        /// Updates the remaining value.
        /// </summary>
        private void UpdateRemainingValue() 
        {
            RemainingValue = TotalValue - Value;
        }

        /// <summary>
        /// Updates the item position.
        /// </summary>
        /// <param name="container">The container.</param>
        /// <param name="item">The item.</param>
        private void UpdateItemPosition(ContentControl container, object item)
        {
            object propValue = !string.IsNullOrWhiteSpace(ItemPlacementPropertyPath) ? GetPropertyValue(ItemPlacementPropertyPath, item) : item;
            double value = propValue != null ? Convert.ToDouble(propValue) : -1.0;
            if (value <= TotalValue && value >= 0.0)
            {
                container.Visibility = System.Windows.Visibility.Visible;
                double leftPosition = GetPixelValue(_partTotalValue.ActualWidth, TotalValue, value);
                Canvas.SetLeft(container, leftPosition - container.ActualWidth / 2);
            }
            else if (container != null)
            {
                container.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Refreshes the item source.
        /// </summary>
        private void RefreshItemSource()
        {
            if (_rootElement != null && _rootElement.IsLoaded && Items != null)
            {
                foreach (var item in Items)
                {
                    ContentControl container = (ContentControl)ItemContainerGenerator.ContainerFromItem(item);
                    if (container != null)
                    {
                        UpdateItemPosition(container, item);   
                    }
                }
            }
        }

        /// <summary>
        /// Attaches the events.
        /// </summary>
        private void AttachEvents()
        {
            if (_rootElement != null)
            {
                _rootElement.Loaded += OnRootElementLoaded;
                _rootElement.SizeChanged += OnRootElementSizeChanged;
            }
            if (_partRemainingValueLabel != null)
            {
                _partRemainingValueLabel.SizeChanged += OnRemainingValueTextSizeChanged;
            }
            if (_partValueLabel != null)
            {
                _partValueLabel.SizeChanged += OnValueTextSizeChanged;
            }
            if (_partIcon != null)
            {
                _partIcon.SizeChanged += OnIconSizeChanged;
            }
            if (_partValue != null)
            {
                _partValue.SizeChanged += OnPartValueSizeChanged;
            }
        }

        /// <summary>
        /// Dettaches the events.
        /// </summary>
        private void DettachEvents()
        {
            if (_rootElement != null)
            {
                _rootElement.Loaded -= OnRootElementLoaded;
                _rootElement.SizeChanged -= OnRootElementSizeChanged;
            }
            if (_partRemainingValueLabel != null)
            {
                _partRemainingValueLabel.SizeChanged -= OnRemainingValueTextSizeChanged;
            }
            if (_partValueLabel != null)
            {
                _partValueLabel.SizeChanged -= OnValueTextSizeChanged;
            }
            if (_partIcon != null)
            {
                _partIcon.SizeChanged -= OnIconSizeChanged;
            }
            if (_partValue != null)
            {
                _partValue.SizeChanged -= OnPartValueSizeChanged;
            }
        }

        #endregion
    }
}
