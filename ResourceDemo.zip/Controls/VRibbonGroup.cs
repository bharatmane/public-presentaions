﻿using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Represents a group of buttons or actions in the <see cref="VRibbon"/> control.
    /// </summary>
    public class VRibbonGroup : HeaderedItemsControl
    {
        /// <summary>
        /// True if the group is collapsed determined by the space on the ribbon panel.
        /// </summary>
        public static readonly DependencyProperty IsCollapsedProperty =
            DependencyProperty.Register("IsCollapsed", typeof(bool), typeof(VRibbonGroup), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsCollapsedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsCollapsed
        {
            get { return (bool)GetValue(IsCollapsedProperty); }
            set { SetValue(IsCollapsedProperty, value); }
        }

        /// <summary>
        /// The is hidden property
        /// </summary>
        public static readonly DependencyProperty IsHiddenProperty =
            DependencyProperty.Register("IsHidden", typeof(bool), typeof(VRibbonGroup), new PropertyMetadata(false));

        /// <summary>
        /// Exposes the <see cref="IsCollapsedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsHidden
        {
            get { return (bool)GetValue(IsHiddenProperty); }
            set { SetValue(IsHiddenProperty, value); }
        }

        /// <summary>
        /// The is single property
        /// </summary>
        public static readonly DependencyProperty IsSingleProperty =
            DependencyProperty.Register("IsSingle", typeof(bool), typeof(VRibbonGroup), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets a value indicating whether this instance is single.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is single; otherwise, <c>false</c>.
        /// </value>
        public bool IsSingle
        {
            get { return (bool)GetValue(IsSingleProperty); }
            set { SetValue(IsSingleProperty, value); }
        }

        static VRibbonGroup()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VRibbonGroup), new FrameworkPropertyMetadata(typeof(VRibbonGroup)));
        }

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            UpdateVisibility();
            base.OnApplyTemplate();
        }

        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e)
        {
            base.OnItemsChanged(e);
            UpdateVisibility();
            IsSingle = Items != null && Items.Count == 1 && Items.GetItemAt(0) is VShips.Framework.Common.ViewModel.Menu.MenuItemDropDownButton;
        }

        private void UpdateVisibility()
        {
            Visibility = !DesignerProperties.GetIsInDesignMode(this) && !HasItems
                ? Visibility.Collapsed
                : Visibility.Visible;
        }
        
        /// <summary>
        /// Checks the container for the control.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is UIElement;
        }
        
    }
}
