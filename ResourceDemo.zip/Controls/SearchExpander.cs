﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An expander to control to use in the advanced search scenario
    /// </summary>
    public class SearchExpander : RadExpander
    {
        #region Dependency Properties
        /// <summary>
        /// The basic content property
        /// </summary>
        public static readonly DependencyProperty BasicContentProperty =
            DependencyProperty.Register("BasicContent", typeof(object), typeof(SearchExpander), new PropertyMetadata(null));
        /// <summary>
        /// Gets or sets the content of the basic.
        /// </summary>
        /// <value>
        /// The content of the basic.
        /// </value>
        public object BasicContent
        {
            get { return (object)GetValue(BasicContentProperty); }
            set { SetValue(BasicContentProperty, value); }
        }

        /// <summary>
        /// The advance content property
        /// </summary>
        public static readonly DependencyProperty AdvanceContentProperty =
            DependencyProperty.Register("AdvanceContent", typeof(object), typeof(SearchExpander), new PropertyMetadata(null));
        /// <summary>
        /// Gets or sets the content of the advance.
        /// </summary>
        /// <value>
        /// The content of the advance.
        /// </value>
        public object AdvanceContent
        {
            get { return (object)GetValue(AdvanceContentProperty); }
            set { SetValue(AdvanceContentProperty, value); }
        }

        /// <summary>
        /// The command that binds to the search button.
        /// </summary>
        public static readonly DependencyProperty SearchCommandProperty =
            DependencyProperty.Register("SearchCommand", typeof(ICommand), typeof(SearchExpander), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SearchCommandProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The search command.
        /// </value>
        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        /// <summary>
        /// The command that binds to the clear search button.
        /// </summary>
        public static readonly DependencyProperty ClearCommandProperty =
            DependencyProperty.Register("ClearCommand", typeof(ICommand), typeof(SearchExpander), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="ClearCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand ClearCommand
        {
            get { return (ICommand)GetValue(ClearCommandProperty); }
            set { SetValue(ClearCommandProperty, value); }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Initializes the <see cref="SearchExpander"/> class.
        /// </summary>
        static SearchExpander()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SearchExpander), new FrameworkPropertyMetadata(typeof(SearchExpander)));
        }
        #endregion

        #region Overriden Methods
        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            var basic = Template.FindName("PART_Basic", this) as Button;
            var advanced = Template.FindName("PART_Advanced", this) as Button;
            if (basic != null)
            {
                basic.Click += (sender, args) => IsExpanded = false;
            }
            if (advanced != null)
            {
                advanced.Click += (sender, args) => IsExpanded = true;
            }
            base.OnApplyTemplate();
        }
        #endregion
    }
}
