﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A simple control for providing items in a wrapped style. Typically used in a home page.
    /// </summary>
    public class WrappedItemsControl : ItemsControl
    {
        static WrappedItemsControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(WrappedItemsControl), new FrameworkPropertyMetadata(typeof(WrappedItemsControl)));
        }

        /// <summary>
        /// Checks if the item is of type WrappedItemsTile
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is WrappedItemsTile;
        }

        /// <summary>
        /// Gets the container of type WrappedItemsTile.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new WrappedItemsTile();
        }
    }
}
