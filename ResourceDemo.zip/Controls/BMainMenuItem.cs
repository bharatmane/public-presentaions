﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An item for the main menu.
    /// </summary>
    public class VMainMenuItem : MenuItem
    {
        /// <summary>
        /// The selected item
        /// </summary>
        private VMainMenuItem _selectedItem;
        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public VMainMenuItem SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                if (_selectedItem != null && _selectedItem != value)
                {
                    _selectedItem.IsSelected = false;
                }
                _selectedItem = value;
            }
        }

        /// <summary>
        /// The is item clickable property
        /// </summary>
        public static readonly DependencyProperty IsItemClickableProperty =
            DependencyProperty.Register("IsItemClickable", typeof(bool), typeof(VMainMenuItem), new PropertyMetadata(true));

        /// <summary>
        /// Gets or sets a value indicating whether this instance is item clickable.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is item clickable; otherwise, <c>false</c>.
        /// </value>
        public bool IsItemClickable
        {
            get { return (bool)GetValue(IsItemClickableProperty); }
            set { SetValue(IsItemClickableProperty, value); }
        }

        /// <summary>
        /// Raised whenever the <see cref="IsSelected"/> changes.
        /// </summary>
        public static readonly RoutedEvent SelectedEvent =
            EventManager.RegisterRoutedEvent("Selected", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(VMainMenuItem));
        /// <summary>
        /// Exposes the <see cref="SelectedEvent"/> RoutedEvent.
        /// </summary>
        public event RoutedEventHandler Selected
        {
            add { AddHandler(SelectedEvent, value); }
            remove { RemoveHandler(SelectedEvent, value); }
        }

        /// <summary>
        /// The is selected property
        /// </summary>
        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(VMainMenuItem), new PropertyMetadata(false, OnIsSelectedChanged));
        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }

        /// <summary>
        /// Initializes the <see cref="VMainMenuItem"/> class.
        /// </summary>
        static VMainMenuItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VMainMenuItem), new FrameworkPropertyMetadata(typeof(VMainMenuItem)));
        }

        /// <summary>
        /// Called when a <see cref="T:System.Windows.Controls.MenuItem" /> is clicked and raises a <see cref="E:System.Windows.Controls.Primitives.ButtonBase.Click" /> event.
        /// </summary>
        protected override void OnClick()
        {
            if (IsItemClickable)
            {
                base.OnClick();
            }
        }

        /// <summary>
        /// Checks if the item is of type <see cref="VMainMenuItem"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VMainMenuItem;
        }

        /// <summary>
        /// Creates a new instance of <see cref="VMainMenuItem"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VMainMenuItem();
        }

        /// <summary>
        /// Called when the mouse enters.
        /// </summary>
        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            IsSubmenuOpen = true;
        }

        /// <summary>
        /// Prepares the specified element to display the specified item.
        /// </summary>
        /// <param name="element">Element used to display the specified item.</param>
        /// <param name="item">Specified item.</param>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (VMainMenuItem)element;
            control.Selected += ControlOnSelected;
            if (control.IsSelected)
            {
                SelectedItem = control;
            }
            base.PrepareContainerForItemOverride(element, item);
        }

        /// <summary>
        /// Controls the on selected.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void ControlOnSelected(object sender, RoutedEventArgs e)
        {
            SelectedItem = (VMainMenuItem)sender;
        }
        /// <summary>
        /// Called when [is selected changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VMainMenuItem)d;
            if ((bool)e.NewValue)
            {
                control.RaiseSelected();
            }
        }

        /// <summary>
        /// Raises the selected.
        /// </summary>
        private void RaiseSelected()
        {
            var newEventArgs = new RoutedEventArgs(SelectedEvent);
            RaiseEvent(newEventArgs);
        }

    }
}
