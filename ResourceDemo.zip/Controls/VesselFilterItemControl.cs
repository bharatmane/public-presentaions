﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using Telerik.Windows.Controls;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A selectable component in the tree.
    /// </summary>
    public class VesselFilterItemControl : RadTreeViewItem
    {
        /// <summary>
        /// Returns an integer indicating how deep within the tree the item is.
        /// </summary>
        public static readonly DependencyProperty DepthProperty =
            DependencyProperty.Register("Depth", typeof(double), typeof(VesselFilterItemControl), new PropertyMetadata(0d));
        /// <summary>
        /// Exposes the <see cref="DepthProperty"/> DependencyProperty.
        /// </summary>
        public double Depth
        {
            get { return (double)GetValue(DepthProperty); }
            set { SetValue(DepthProperty, value); }
        }

        /// <summary>
        /// If the tree item is currently busy or loading its sub items.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(VesselFilterItemControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsBusyProperty"/> DependencyProperty.
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        /// <summary>
        /// A bindable property for lazy loading items.
        /// If true the togglebutton will be visible.
        /// </summary>
        public static readonly DependencyProperty HasSubItemsProperty = 
            DependencyProperty.Register("HasSubItems", typeof(bool), typeof(VesselFilterItemControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="HasSubItemsProperty"/> DependencyProperty.
        /// </summary>
        public bool HasSubItems
        {
            get { return (bool)GetValue(HasSubItemsProperty); }
            set { SetValue(HasSubItemsProperty, value); }
        }

        /// <summary>
        /// Gets a value that determines if the current item is a vessel.
        /// </summary>
        public static readonly DependencyProperty IsVesselProperty = 
            DependencyProperty.Register("IsVessel", typeof(bool), typeof(VesselFilterItemControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsVesselProperty"/> DependencyProperty.
        /// </summary>
        public bool IsVessel
        {
            get { return (bool)GetValue(IsVesselProperty); }
            set { SetValue(IsVesselProperty, value); }
        }

        /// <summary>
        /// Determines if this item is used in lazy loading.
        /// </summary>
        public static readonly DependencyProperty IsDummyItemProperty = 
            DependencyProperty.Register("IsDummyItem", typeof(bool), typeof(VesselFilterItemControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsDummyItemProperty"/> DependencyProperty.
        /// </summary>
        public bool IsDummyItem
        {
            get { return (bool)GetValue(IsDummyItemProperty); }
            set { SetValue(IsDummyItemProperty, value); }
        }

        static VesselFilterItemControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VesselFilterItemControl), new FrameworkPropertyMetadata(typeof(VesselFilterItemControl)));
        }

        /// <summary>
        /// Called after the controls template is applied.
        /// </summary>
        public override void OnApplyTemplate()
        {
            var header = Template.FindName("HeaderRow", this) as Grid;
            if (header != null)
            {
                header.PreviewMouseDown += (sender, e) =>
                {
                    if (!IsExpanded)
                    {
                        var toggle = UIHelper.FindVisualParent<ToggleButton>((DependencyObject)e.OriginalSource, this);

                        IsExpanded = (toggle == null);
                    }
                };
            }
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Checks if the item is its own container
        /// </summary>
        /// <param name="item">The item of the items control</param>
        /// <returns>True if the item is of type <see cref="VesselFilterItemControl"/></returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VesselFilterItemControl;
        }

        /// <summary>
        /// Returns the correct item container.
        /// </summary>
        /// <returns>Returns a <see cref="VesselFilterItemControl"/> control.</returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VesselFilterItemControl();
        }

        /// <summary>
        /// Prepares the item by setting up its depth.
        /// </summary>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (VesselFilterItemControl) element;
            control.Depth = Depth + 1;
            base.PrepareContainerForItemOverride(element, item);
        }
        
    }
}
