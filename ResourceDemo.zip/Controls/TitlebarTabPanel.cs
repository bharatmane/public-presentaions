﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A panel that display the tabs for the <see cref="TitlebarTabControl"/>.
    /// </summary>
    public class TitlebarTabPanel : Panel
    {
        private double _childWidth;

        /// <summary>
        /// The default width of a tab item.
        /// </summary>
        public static readonly DependencyProperty DefaultItemWidthProperty =
            DependencyProperty.Register("DefaultItemWidth", typeof(double), typeof(TitlebarTabPanel), new PropertyMetadata(120d));
        /// <summary>
        /// Exposes the DefaultItemWidthProperty DependencyProperty.
        /// </summary>
        public double DefaultItemWidth
        {
            get { return (double)GetValue(DefaultItemWidthProperty); }
            set { SetValue(DefaultItemWidthProperty, value); }
        }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public TitlebarTabPanel()
        {
            ClipToBounds = true;
            HorizontalAlignment = HorizontalAlignment.Left;
        }

        /// <summary>
        /// Measures the children in the layout pass.
        /// </summary>
        protected override Size MeasureOverride(Size availableSize)
        {
            if (!double.IsInfinity(availableSize.Width))
            {
                var currentX = 0d;
                var currentY = 0d;
                var count = Children.Count;
                var childrenWidth = DefaultItemWidth*count;
                var availableWidth = availableSize.Width;
                _childWidth = childrenWidth > availableWidth
                    ? DefaultItemWidth - ((childrenWidth - availableWidth)/count) 
                    : DefaultItemWidth;
                var measure = new Size(_childWidth, double.PositiveInfinity);
                foreach (UIElement child in Children)
                {
                    child.Measure(measure);
                    currentX = currentX + _childWidth;
                    currentY = Math.Max(currentY, child.DesiredSize.Height);
                }
                return new Size(availableSize.Width, currentY);
            }
            return base.MeasureOverride(availableSize);
        }

        /// <summary>
        /// Arranges the children in the layout pass.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var currentX = 0d;
            foreach (var child in Children.OfType<UIElement>())
            {
                var newX = currentX + _childWidth;

                child.Arrange(new Rect(currentX, 0, _childWidth, finalSize.Height));

                currentX = newX;
            }

            return base.ArrangeOverride(finalSize);
        }
    }
}
