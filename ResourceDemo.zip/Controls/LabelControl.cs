﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// <para>
    /// A control used as an easy way to add a label and postion it
    /// to another control or content.
    /// </para>
    /// <para>
    /// Additionaly the sizes of the labels can be automatically synced within a given view
    /// to ensure consistant output.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example labels a RadComboBox with Status: and sets its <see cref="SharedSizeScope"/> to
    /// Label. Any labels within a container with the attached property Grid.IsSharedSizeScope set to 
    /// true and with the same <see cref="SharedSizeScope"/> will have the same width for there label.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <controls:LabelControl SharedSizeScope="Label" Label="Status:">
    ///     <telerik:RadComboBox ItemsSource="{Binding Urgencies}" SelectedItem="{Binding Urgency}" />
    /// </controls:LabelControl>]]>
    /// </code>
    /// </example>
    public class LabelControl : ContentControl
    {
        /// <summary>
        /// The content of the label
        /// </summary>
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(object), typeof(LabelControl), new PropertyMetadata(""));
        /// <summary>
        /// Exposes the <see cref="LabelProperty"/> DependencyProperty.
        /// </summary>
        public object Label
        {
            get { return GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        /// <summary>
        /// <para>
        /// This uses the grids SharedSizeScope method which if set
        /// will ensure all labels with same SharedSizeScope within the same scope
        /// will be allocated the same width. 
        /// </para>
        /// <para>
        /// The attached property Grid.IsSharedSizeScope must be set 
        /// to true on a parent of all LabelControls with the same 
        /// SharedSizeScope for this to work. 
        /// </para>
        /// <para>
        /// It is common to add Grid.IsSharedSizeScope="True" on the 
        /// containing view.
        /// </para>
        /// </summary>
        public static readonly DependencyProperty SharedSizeScopeProperty =
            DependencyProperty.Register("SharedSizeScope", typeof(string), typeof(LabelControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SharedSizeScopeProperty"/> DependencyProperty.
        /// </summary>
        public string SharedSizeScope
        {
            get { return (string)GetValue(SharedSizeScopeProperty); }
            set { SetValue(SharedSizeScopeProperty, value); }
        }

        /// <summary>
        /// The postion of the label relative to the control or content.
        /// See <see cref="LabelPostion"/> for more information.
        /// </summary>
        public static readonly DependencyProperty LabelPostionProperty =
            DependencyProperty.Register("LabelPostion", typeof(LabelPostion), typeof(LabelControl), new PropertyMetadata(LabelPostion.Left));
        /// <summary>
        /// Exposes the <see cref="LabelPostionProperty"/> DependencyProperty.
        /// </summary>
        public LabelPostion LabelPostion
        {
            get { return (LabelPostion)GetValue(LabelPostionProperty); }
            set { SetValue(LabelPostionProperty, value); }
        }

        /// <summary>
        /// Gets or sets the style of the displayed label
        /// </summary>
        public static readonly DependencyProperty LabelStyleProperty =
            DependencyProperty.Register("LabelStyle", typeof(Style), typeof(LabelControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="LabelStyle"/> DependencyProperty.
        /// </summary>
        public Style LabelStyle
        {
            get { return (Style)GetValue(LabelStyleProperty); }
            set { SetValue(LabelStyleProperty, value); }
        }

        /// <summary>
        /// True if the content is a required input.
        /// </summary>
        public static readonly DependencyProperty IsRequiredProperty = 
            DependencyProperty.Register("IsRequired", typeof(bool), typeof(LabelControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsRequiredProperty"/> DependencyProperty.
        /// </summary>
        public bool IsRequired
        {
            get { return (bool)GetValue(IsRequiredProperty); }
            set { SetValue(IsRequiredProperty, value); }
        }

        /// <summary>
        /// Gets or sets the width of the label.
        /// </summary>
        /// <value>
        /// The width of the label.
        /// This needs to be set only when we have dynamic labels to avoid label shifting
        /// </value>
        public GridLength LabelWidth
        {
            get { return (GridLength)GetValue(LabelWidthProperty); }
            set { SetValue(LabelWidthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LabelWidth.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelWidthProperty =
            DependencyProperty.Register("LabelWidth", typeof(GridLength), typeof(LabelControl), new PropertyMetadata(GridLength.Auto));

        /// <summary>
        /// Initializes the <see cref="LabelControl"/> class.
        /// </summary>
        static LabelControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(LabelControl), new FrameworkPropertyMetadata(typeof(LabelControl)));
        }

    }

    /// <summary>
    /// Used to provide the postion of the label relative to the control or content
    /// of a <see cref="LabelControl"/>
    /// </summary>
    public enum LabelPostion
    {
        /// <summary>
        /// Postions the label to the left of the content
        /// </summary>
        Left,
        /// <summary>
        /// Postions the label above the content
        /// </summary>
        Top
    }
}
