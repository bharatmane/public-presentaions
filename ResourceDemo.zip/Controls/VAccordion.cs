﻿using GalaSoft.MvvmLight;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An accordian control for step/wizard based selections.
    /// </summary>
    public class VAccordion : ItemsControl
    {
        /// <summary>
        /// The _expanded item
        /// </summary>
        private VAccordionItem _expandedItem;

        /// <summary>
        /// Initializes the <see cref="VAccordion"/> class.
        /// </summary>
        static VAccordion()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VAccordion), new FrameworkPropertyMetadata(typeof(VAccordion)));
        }

        /// <summary>
        /// Checks if the item is of type <see cref="VAccordionItem" />.
        /// </summary>
        /// <param name="item">The item to check.</param>
        /// <returns>
        /// true if the item is (or is eligible to be) its own container; otherwise, false.
        /// </returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VAccordionItem;
        }

        /// <summary>
        /// Creates a new <see cref="VAccordionItem" />.
        /// </summary>
        /// <returns>
        /// The element that is used to display the given item.
        /// </returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VAccordionItem();
        }

        /// <summary>
        /// Controls the expanded state of items.
        /// </summary>
        /// <param name="item">The item.</param>
        internal void OnItemExpandedChanged(VAccordionItem item)
        {
            if (item.IsExpanded)
            {
                var current = _expandedItem;
                if (current != null)
                {
                    current.IsExpanded = false;
                }
                _expandedItem = item;
            }
            else
            {
                if (Equals(item, _expandedItem))
                {
                    //var cleanupItem = _expandedItem.SelectedContent as ICleanup;
                    //if (cleanupItem != null)
                    //{
                    //    cleanupItem.Cleanup();
                    //}
                    _expandedItem = null;
                }
            }
        }

        /// <summary>
        /// Moves to the next item.
        /// </summary>
        /// <param name="item">The item.</param>
        internal void MoveNext(VAccordionItem item)
        {
            var next = GetNextItem(item);
            if (next != null)
            {
                next.IsExpanded = true;
            }
        }

        /// <summary>
        /// Gets the next item.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        private VAccordionItem GetNextItem(VAccordionItem item)
        {
            var current = item;
            if (current != null)
            {
                var currentIndex = ItemContainerGenerator.IndexFromContainer(current);
                var next = currentIndex + 1;
                var total = Items.OfType<object>().Count();
                if (next < total)
                {
                    var nextItem = ItemContainerGenerator.ContainerFromIndex(next) as VAccordionItem;
                    return nextItem;
                }
            }
            return null;
        }
    }
}
