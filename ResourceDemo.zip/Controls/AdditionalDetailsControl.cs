﻿using System.Windows;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that displays addtional details.
    /// </summary>
    public class AdditionalDetailsControl : SlidePanel
    {
        /// <summary>
        /// A bindable command for closing the details panel.
        /// </summary>
        public static readonly DependencyProperty CloseCommandProperty =
            DependencyProperty.Register("CloseCommand", typeof(ICommand), typeof(AdditionalDetailsControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="CloseCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand CloseCommand
        {
            get { return (ICommand)GetValue(CloseCommandProperty); }
            set { SetValue(CloseCommandProperty, value); }
        }

        static AdditionalDetailsControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AdditionalDetailsControl), new FrameworkPropertyMetadata(typeof(AdditionalDetailsControl)));
        }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public AdditionalDetailsControl()
        {
            CloseCommand = new RelayCommand(Close);
        }

        private void Close()
        {
            IsOpen = false;
        }
        
    }
}
