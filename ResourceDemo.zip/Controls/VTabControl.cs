﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A tab control used to display the details of an entity in
    /// a master details scenario of a module start view.
    /// </summary>
    /// <example>
    /// The following example shows a deatils tab control with a title, sub title and tab items..
    /// <code lang="XAML" title="XAML"><![CDATA[
    /// <controls:VTabControl>
    /// <controls:VTabControl.Title>
    /// <StackPanel Orientation="Horizontal"
    /// VerticalAlignment="Center">
    /// <Path Data="{StaticResource PinnedGeometry}"
    /// Width="14"
    /// Height="14"
    /// Stroke="{StaticResource BrushBackground}"
    /// StrokeThickness="1"
    /// Fill="{StaticResource BrushHighlight}"
    /// Stretch="Uniform"
    /// Margin="{StaticResource MarginR}"
    /// Visibility="{Binding SelectedItem.IsPinned, Converter={StaticResource BooleanToVisibilityConverter}, FallbackValue=Collapsed, TargetNullValue=Collapsed}"/>
    /// <TextBlock Style="{StaticResource TextBlockHeaderStyle}"
    /// TextTrimming="CharacterEllipsis"
    /// Foreground="{Binding SelectedItem.KPI, Converter={StaticResource KPIConverter}}" >
    /// <Run Text="{Binding SelectedItem.Entity.AccountingCompanyId, TargetNullValue=XXXX, FallbackValue=XXXX}" /><Run Text=" - " /><Run Text="{Binding SelectedItem.Entity.OrderNumber, FallbackValue=XXXXX, TargetNullValue=XXXXX}" />
    /// </TextBlock>
    /// <TextBlock Text="{Binding SelectedItem.Entity.OrderTitle, FallbackValue=UNKNOWN, TargetNullValue=UNKNOWN}"
    /// Style="{StaticResource TextBlockHeaderStyle}"
    /// Foreground="{Binding SelectedItem.KPI, Converter={StaticResource KPIConverter}}"
    /// VerticalAlignment="Center"
    /// Margin="{StaticResource MarginLargeL}"/>
    /// </StackPanel>
    /// </controls:VTabControl.Title>
    /// <controls:VTabControl.SubTitle>
    /// <StackPanel Orientation="Horizontal">
    /// <TextBlock Text="{Binding SelectedItem.Entity.VesselName, FallbackValue=UNKNOWN, TargetNullValue=UNKNOWN}"
    /// VerticalAlignment="Center"/>
    /// <Rectangle Width="1" Fill="{StaticResource BrushSeperator}" Margin="{StaticResource MarginLR}" />
    /// <TextBlock VerticalAlignment="Center">
    /// <Run Text="{Binding SelectedItem.OrderStatusName, FallbackValue=XX, TargetNullValue=XX, Mode=OneWay}" /><Run Text=" - " /><Run Text="{Binding SelectedItem.OrderStatus, FallbackValue=UNKNOWN, TargetNullValue=UNKNOWN}" />
    /// </TextBlock>
    /// <Rectangle Width="1" Fill="{StaticResource BrushSeperator}" Margin="{StaticResource MarginLR}" />
    /// <TextBlock Text="{Binding SelectedItem.Entity.OrderDate, StringFormat=dd-MMM-yyyy, FallbackValue=00-JAN-1900, TargetNullValue=00-JAN-1900}"
    /// VerticalAlignment="Center"/>
    /// <Rectangle Width="1" Fill="{StaticResource BrushSeperator}" Margin="{StaticResource MarginLR}" />
    /// <TextBlock Text="{Binding SelectedItem.Entity.OrderType, FallbackValue=UNKNOWN, TargetNullValue=UNKNOWN}"
    /// VerticalAlignment="Center"/>
    /// </StackPanel>
    /// </controls:VTabControl.SubTitle>
    /// <TabItem Header="SUMMARY">
    /// <views:SummaryView />
    /// </TabItem>
    /// <TabItem Header="ORDER LINES">
    /// <views:OrderLinesView />
    /// </TabItem>
    /// <TabItem Header="NOTES">
    /// <views:NotesView />
    /// </TabItem>
    /// </controls:VTabControl>]]></code></example>
    public class VTabControl : RadTabControl
    {
        #region Dependency Properties

        /// <summary>
        /// The title of the entity or record.
        /// </summary>
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(object), typeof(VTabControl), new PropertyMetadata(null));

        /// <summary>
        /// The sub title of the entity or record. This can be a mixture of data such as date created and vessel.
        /// </summary>
        public static readonly DependencyProperty SubTitleProperty =
            DependencyProperty.Register("SubTitle", typeof(object), typeof(VTabControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets the visibility of the overflow panel.
        /// </summary>
        public static readonly DependencyProperty OverflowVisibilityProperty =
            DependencyProperty.Register("OverflowVisibility", typeof(Visibility), typeof(VTabControl), new PropertyMetadata(Visibility.Hidden));

        /// <summary>
        /// The template used to display addtional content.
        /// </summary>
        public static readonly DependencyProperty AdditionalContentTemplateProperty =
            DependencyProperty.Register("AdditionalContentTemplate", typeof(DataTemplate), typeof(VTabControl), new PropertyMetadata(null));

        /// <summary>
        /// The custom margin property
        /// </summary>
        public static readonly DependencyProperty CustomMarginProperty =
            DependencyProperty.Register("CustomMargin", typeof(Thickness), typeof(VTabControl), new PropertyMetadata(default(Thickness)));

        /// <summary>
        /// The Image of the entity or record.
        /// </summary>
        public static readonly DependencyProperty ImageProperty =
            DependencyProperty.Register("Image", typeof(object), typeof(VTabControl), new PropertyMetadata(null));

        #endregion

        #region Properties

        /// <summary>
        /// Exposes the <see cref="TitleProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public object Title
        {
            get { return GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }
        /// <summary>
        /// Exposes the <see cref="SubTitleProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The sub title.
        /// </value>
        public object SubTitle
        {
            get { return GetValue(SubTitleProperty); }
            set { SetValue(SubTitleProperty, value); }
        }
        /// <summary>
        /// Exposes the <see cref="OverflowVisibilityProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The overflow visibility.
        /// </value>
        public Visibility OverflowVisibility
        {
            get { return (Visibility)GetValue(OverflowVisibilityProperty); }
            set { SetValue(OverflowVisibilityProperty, value); }
        }
        /// <summary>
        /// Exposes the <see cref="AdditionalContentTemplateProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The additional content template.
        /// </value>
        public DataTemplate AdditionalContentTemplate
        {
            get { return (DataTemplate)GetValue(AdditionalContentTemplateProperty); }
            set { SetValue(AdditionalContentTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the custom margin.
        /// </summary>
        /// <value>
        /// The custom margin.
        /// </value>
        public Thickness CustomMargin
        {
            get { return (Thickness)GetValue(CustomMarginProperty); }
            set { SetValue(CustomMarginProperty, value); }
        }
        /// <summary>
        /// Exposes the <see cref="ImageProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The image.
        /// </value>
        public object Image
        {
            get { return GetValue(ImageProperty); }
            set { SetValue(ImageProperty, value); }
        }

        /// <summary>
        /// The _overflow panel
        /// </summary>
        private StackPanel _overflowPanel;
        /// <summary>
        /// Gets the overflow panel.
        /// </summary>
        /// <value>
        /// The overflow panel.
        /// </value>
        private StackPanel OverflowPanel
        {
            get { return _overflowPanel; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initializes the <see cref="VTabControl"/> class.
        /// </summary>
        static VTabControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VTabControl), new FrameworkPropertyMetadata(typeof(VTabControl)));
        }

        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            _overflowPanel = Template.FindName("PART_OverflowPanel", this) as StackPanel;
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Called whenever tab selection changes.
        /// </summary>
        /// <param name="e">The <see cref="RadSelectionChangedEventArgs"/> instance containing the event data.</param>
        protected override void OnSelectionChanged(RadSelectionChangedEventArgs e)
        {
            base.OnSelectionChanged(e);
            if (OverflowPanel != null)
            {
                var overflowItems = OverflowPanel.Children.OfType<VTabOverlowItem>().ToList();
                foreach (var item in overflowItems)
                {
                    item.UpdateSelected();
                }
            }
        }

        /// <summary>
        /// Clears the overflow.
        /// </summary>
        internal void ClearOverflow()
        {
            if (OverflowPanel != null)
            {
                var overflowItems = OverflowPanel.Children.OfType<VTabOverlowItem>().ToList();
                foreach (var item in overflowItems)
                {
                    item.Cleanup();
                }
                OverflowPanel.Children.Clear();
            }
            UpdateOverflowVisibility();
        }

        /// <summary>
        /// Adds to over flow.
        /// </summary>
        /// <param name="item">The item.</param>
        internal void AddToOverFlow(RadTabItem item)
        {
            if (OverflowPanel != null)
            {
                OverflowPanel.Children.Add(new VTabOverlowItem(item));
            }
            UpdateOverflowVisibility();
        }

        /// <summary>
        /// Updates the overflow visibility.
        /// </summary>
        private void UpdateOverflowVisibility()
        {
            OverflowVisibility = OverflowPanel != null && OverflowPanel.Children.OfType<VTabOverlowItem>().Any()
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        #endregion
    }

    /// <summary>
    /// An item used to display an item in the tab controls overflow, where the item wont fit.
    /// </summary>
    public class VTabOverlowItem : ContentControl
    {
        /// <summary>
        /// The _item
        /// </summary>
        private RadTabItem _item;

        /// <summary>
        /// If the item is currently selected.
        /// </summary>
        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(VTabOverlowItem), new PropertyMetadata(false, OnIsSelectedChanged));
        /// <summary>
        /// Exposes the <see cref="IsSelectedProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }

        /// <summary>
        /// Initializes the <see cref="VTabOverlowItem"/> class.
        /// </summary>
        static VTabOverlowItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VTabOverlowItem), new FrameworkPropertyMetadata(typeof(VTabOverlowItem)));
        }

        /// <summary>
        /// The default contructor.
        /// </summary>
        /// <param name="item">The item.</param>
        public VTabOverlowItem(RadTabItem item)
        {
            _item = item;
            Content = item.Header;
            ContentTemplate = item.HeaderTemplate;
            UpdateSelected();
        }

        /// <summary>
        /// Called when the mouse is pressed down.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Windows.Input.MouseButtonEventArgs" /> that contains the event data. The event data reports that one or more mouse buttons were pressed.</param>
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            IsSelected = true;
            base.OnPreviewMouseDown(e);
        }

        /// <summary>
        /// Called when [is selected changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VTabOverlowItem) d;
            control.OnIsSelectedChanged();
        }

        /// <summary>
        /// Called when [is selected changed].
        /// </summary>
        private void OnIsSelectedChanged()
        {
            if (_item != null)
            {
                _item.IsSelected = IsSelected;
            }
        }

        /// <summary>
        /// Cleanups this instance.
        /// </summary>
        internal void Cleanup()
        {
            _item = null;
        }

        /// <summary>
        /// Updates the selected.
        /// </summary>
        internal void UpdateSelected()
        {
            if (_item != null)
            {
                IsSelected = _item.IsSelected;
            }
        }
    }

}
