﻿using System.Windows;
using System.Windows.Data;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Binding = System.Windows.Data.Binding;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A numeric column for the gridview.
    /// </summary>
    public class VGridViewNumericColumn : GridViewBoundColumnBase
    {
        #region Dependency Properties

        /// <summary>
        /// The maximum property
        /// </summary>
        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(double), typeof(VGridViewNumericColumn), new PropertyMetadata(default(double)));

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="VGridViewNumericColumn"/> class.
        /// </summary>
        public VGridViewNumericColumn()
        {
            Minimum = double.MinValue;
            Maximum = double.MaxValue;
            SmallChange = 1;
            NumberDecimalDigits = 2;
            ShowButtons = false;
        }
        #endregion

        #region Properties

        /// <summary>
        /// The minimum allowed number.
        /// </summary>
        public double Minimum { get; set; }

        /// <summary>
        /// Gets or sets the maximum.
        /// </summary>
        /// <value>
        /// The maximum.
        /// </value>
        public double Maximum
        {
            get { return (double)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        /// <summary>
        /// Gets or sets the small change.
        /// </summary>
        /// <value>
        /// The small change.
        /// </value>
        public double SmallChange { get; set; }

        /// <summary>
        /// Gets or sets the number decimal digits.
        /// </summary>
        /// <value>
        /// The number decimal digits.
        /// </value>
        public int NumberDecimalDigits { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is integer.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is integer; otherwise, <c>false</c>.
        /// </value>
        public bool IsInteger{ get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to show buttons.
        /// </summary>
        /// <value>
        ///   <c>true</c> if need to show buttons; otherwise, <c>false</c>.
        /// </value>
        public bool ShowButtons { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Creates the cell for the column.
        /// </summary>
        /// <param name="cell">The cell.</param>
        /// <param name="dataItem">The data item.</param>
        /// <returns>Single object fo type <seealso cref="FrameworkElement"/></returns>
        public override FrameworkElement CreateCellEditElement(GridViewCell cell, object dataItem)
        {
            var control = new RadNumericUpDown();           
            SetupValueBinding(control);
            SetupProperties(control);
            //control.LostFocus += (sender, args) =>
            //{
            //    var numbox = (RadNumericUpDown)sender;
            //    double value;
            //    double.TryParse(numbox.ContentText, out value);
            //    numbox.Value = Math.Min(Math.Max(value, Minimum), Maximum);
            //};
            return control;
        }

        /// <summary>
        /// Setups the properties.
        /// </summary>
        /// <param name="control">The control.</param>
        private void SetupProperties(RadNumericUpDown control)
        {
            control.Minimum = Minimum;
            control.Maximum = Maximum;
            control.SmallChange = SmallChange;
            control.NumberDecimalDigits = NumberDecimalDigits;
            control.ShowButtons = ShowButtons;
            control.IsInteger = IsInteger;
        }

        /// <summary>
        /// Setups the value binding.
        /// </summary>
        /// <param name="control">The control.</param>
        private void SetupValueBinding(RadNumericUpDown control)
        {
            var valueBinding = new Binding
            {
                Mode = BindingMode.TwoWay,
                NotifyOnValidationError = true,
                ValidatesOnExceptions = true,
                ValidatesOnDataErrors = true,
                Path = new PropertyPath(DataMemberBinding.Path.Path)
            };
            control.UpdateValueEvent = UpdateValueEvent.PropertyChanged;
            control.SetBinding(RadRangeBase.ValueProperty, valueBinding);
        }
        #endregion

    }
}