﻿using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.Map;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A pin point for a map which also shows path data for an icon.
    /// </summary>
    public class PathPinPointVessel : PathToggleButton
    {
        /// <summary>
        /// If this is true then the additional details content will be displayed when the pinpoint is clicked.
        /// </summary>
        public static readonly DependencyProperty UsesAdditionalDetailsProperty =
            DependencyProperty.Register("UsesAdditionalDetails", typeof(bool), typeof(PathPinPointVessel), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="UsesAdditionalDetailsProperty"/> DependencyProperty. 
        /// </summary>
        public bool UsesAdditionalDetails
        {
            get { return (bool)GetValue(UsesAdditionalDetailsProperty); }
            set { SetValue(UsesAdditionalDetailsProperty, value); }
        }

        /// <summary>
        /// The data shown when the pinpoint is clicked.
        /// </summary>
        public static readonly DependencyProperty AdditionalDetailsProperty =
            DependencyProperty.Register("AdditionalDetails", typeof(PathPinPointDetails), typeof(PathPinPointVessel), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="AdditionalDetailsProperty"/> DependencyProperty. 
        /// </summary>
        public PathPinPointDetails AdditionalDetails
        {
            get { return (PathPinPointDetails)GetValue(AdditionalDetailsProperty); }
            set { SetValue(AdditionalDetailsProperty, value); }
        }

        /// <summary>
        /// Gets or sets the brush used behind the background.
        /// </summary>
        public static readonly DependencyProperty IconBackgroundProperty =
            DependencyProperty.Register("IconBackground", typeof(Brush), typeof(PathPinPointVessel), new PropertyMetadata(Brushes.Transparent));
        /// <summary>
        /// Exposes the <see cref="IconBackgroundProperty"/> DependencyProperty.
        /// </summary>
        public Brush IconBackground
        {
            get { return (Brush)GetValue(IconBackgroundProperty); }
            set { SetValue(IconBackgroundProperty, value); }
        }

        /// <summary>
        /// Sets the width and height for the icon.
        /// </summary>
        public static readonly DependencyProperty IconSizeProperty =
            DependencyProperty.Register("IconSize", typeof(double), typeof(PathPinPointVessel), new PropertyMetadata(20d));
        /// <summary>
        /// Exposes the <see cref="IconSizeProperty"/> DependencyProperty.
        /// </summary>
        public double IconSize
        {
            get { return (double)GetValue(IconSizeProperty); }
            set { SetValue(IconSizeProperty, value); }
        }

        /// <summary>
        /// Sets the angle to display the icon. This is used in the vessel style.
        /// </summary>
        public static readonly DependencyProperty AngleProperty =
            DependencyProperty.Register("Angle", typeof(double), typeof(PathPinPointVessel), new PropertyMetadata(0d));
        /// <summary>
        /// Exposes the <see cref="AngleProperty"/> DependencyProperty.
        /// </summary>
        public double Angle
        {
            get { return (double)GetValue(AngleProperty); }
            set { SetValue(AngleProperty, value); }
        }

        /// <summary>
        /// True if there is valid coordinates.
        /// </summary>
        public static readonly DependencyProperty IsValidProperty =
            DependencyProperty.Register("IsValid", typeof(bool), typeof(PathPinPointVessel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="IsValidProperty"/> DependencyProperty.
        /// </summary>
        public bool IsValid
        {
            get { return (bool)GetValue(IsValidProperty); }
            set { SetValue(IsValidProperty, value); }
        }

        /// <summary>
        /// True if Has Replication Issue.
        /// </summary>
        public static readonly DependencyProperty HasReplicationIssueProperty =
            DependencyProperty.Register("HasReplicationIssue", typeof(bool), typeof(PathPinPointVessel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="HasReplicationIssueProperty"/> DependencyProperty.
        /// </summary>
        public bool HasReplicationIssue
        {
            get { return (bool)GetValue(HasReplicationIssueProperty); }
            set { SetValue(HasReplicationIssueProperty, value); }
        }

        /// <summary>
        /// True if Is Outwith Charter.
        /// </summary>
        public static readonly DependencyProperty IsOutwithCharterProperty =
            DependencyProperty.Register("IsOutwithCharter", typeof(bool), typeof(PathPinPointVessel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="IsOutwithCharterProperty"/> DependencyProperty.
        /// </summary>
        public bool IsOutwithCharter
        {
            get { return (bool)GetValue(IsOutwithCharterProperty); }
            set { SetValue(IsOutwithCharterProperty, value); }
        }

        /// <summary>
        /// True if there Is Severe Weather.
        /// </summary>
        public static readonly DependencyProperty IsSevereWeatherProperty =
            DependencyProperty.Register("IsSevereWeather", typeof(bool), typeof(PathPinPointVessel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="IsSevereWeatherProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSevereWeather
        {
            get { return (bool)GetValue(IsSevereWeatherProperty); }
            set { SetValue(IsSevereWeatherProperty, value); }
        }

        static PathPinPointVessel()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PathPinPointVessel), new FrameworkPropertyMetadata(typeof(PathPinPointVessel)));
        }

        public override void OnApplyTemplate()
        {
            Unloaded += (sender, args) => IsChecked = false;
            base.OnApplyTemplate();
        }

        protected override void OnChecked(RoutedEventArgs e)
        {
            var location = MapLayer.GetLocation(this);
            var map = UIHelper.FindVisualParent<RadMap>(this);
            if (map != null)
            {
                var layer = GetInfoLayer(map);
                var details = AdditionalDetails;
                if (details != null && layer != null)
                {
                    details.DataContext = DataContext;
                    MapLayer.SetLocation(details, location);
                    layer.Items.Add(details);
                    details.SetBinding(PathPinPointDetails.IsOpenProperty, new Binding("IsChecked")
                    {
                        Mode = BindingMode.TwoWay,
                        Source = this
                    });
                    details.IsOpen = true;
                }
            }
            base.OnChecked(e);
        }
        
        private static InformationLayer GetInfoLayer(RadMap map)
        {
            var layerName = "VPinPointInformationLayer";
            var layer = map.Items.OfType<InformationLayer>().FirstOrDefault(x => Equals(x.Tag, layerName));
            if (layer == null)
            {
                layer = new InformationLayer {Tag = layerName};
                map.Items.Add(layer);
            }
            else
            {
                var items = layer.Items.OfType<PathPinPointDetails>().ToList();
                foreach (var item in items)
                {
                    item.Close();
                }
                layer.Items.Clear();
            }
            return layer;
        }

        
    }
}
