﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Represents an item in the <see cref="SortItemControl"/> allowing the item to be sorted.
    /// </summary>
    public class SortItemControl : ListBoxItem
    {
        /// <summary>
        /// The event raised when the item <see cref="ListSortDirectionProperty"/> changes.
        /// </summary>
        public static readonly RoutedEvent ListSortDirectionChangedEvent =
            EventManager.RegisterRoutedEvent("ListSortDirectionChanged", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(SortItemControl));
        /// <summary>
        /// Exposes the <see cref="ListSortDirectionChangedEvent"/> RoutedEvent.
        /// </summary>
        public event RoutedEventHandler ListSortDirectionChanged
        {
            add { AddHandler(ListSortDirectionChangedEvent, value); }
            remove { RemoveHandler(ListSortDirectionChangedEvent, value); }
        }

        /// <summary>
        /// Determines the direction that the item is sorted on.
        /// </summary>
        public static readonly DependencyProperty ListSortDirectionProperty =
            DependencyProperty.Register("ListSortDirection", typeof(ListSortDirection?), typeof(SortItemControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnListSortDirectionChanged));
        /// <summary>
        /// Exposes the <see cref="ListSortDirectionProperty"/> DependencyProperty.
        /// </summary>
        public ListSortDirection? ListSortDirection
        {
            get { return (ListSortDirection?)GetValue(ListSortDirectionProperty); }
            set { SetValue(ListSortDirectionProperty, value); }
        }

        static SortItemControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SortItemControl), new FrameworkPropertyMetadata(typeof(SortItemControl)));
        }

        /// <summary>
        /// Changes the sort direction.
        /// </summary>
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            UpdateSort();
            e.Handled = true;
            base.OnPreviewMouseDown(e);
        }

        private static void OnListSortDirectionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SortItemControl) d;
            control.RaiseListSortDirectionChangedEvent();
        }

        private void RaiseListSortDirectionChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(ListSortDirectionChangedEvent));
        }

        private void UpdateSort()
        {
            switch (ListSortDirection)
            {
                case System.ComponentModel.ListSortDirection.Ascending:
                    ListSortDirection = System.ComponentModel.ListSortDirection.Descending;
                    break;
                case System.ComponentModel.ListSortDirection.Descending:
                    ListSortDirection = null;
                    break;
                case null:
                    ListSortDirection = System.ComponentModel.ListSortDirection.Ascending;
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
