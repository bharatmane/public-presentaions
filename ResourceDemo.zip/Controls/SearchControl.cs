﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that displays a search box.
    /// </summary>
    public class SearchControl : RadWatermarkTextBox
    {
        /// <summary>
        /// The command executed when search button is pressed.
        /// </summary>
        public static readonly DependencyProperty SearchCommandProperty =
            DependencyProperty.Register("SearchCommand", typeof(ICommand), typeof(SearchControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SearchCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        /// <summary>
        /// The command executed when the clear button is pressed.
        /// </summary>
        public static readonly DependencyProperty ClearCommandProperty =
            DependencyProperty.Register("ClearCommand", typeof(ICommand), typeof(SearchControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="ClearCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand ClearCommand
        {
            get { return (ICommand)GetValue(ClearCommandProperty); }
            set { SetValue(ClearCommandProperty, value); }
        }

        /// <summary>
        /// Set this to true if search is complete.
        /// </summary>
        public static readonly DependencyProperty IsSearchCompleteProperty =
            DependencyProperty.Register("IsSearchComplete", typeof(bool), typeof(SearchControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsSearchCompleteProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSearchComplete
        {
            get { return (bool)GetValue(IsSearchCompleteProperty); }
            set { SetValue(IsSearchCompleteProperty, value); }
        }

        static SearchControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SearchControl), new FrameworkPropertyMetadata(typeof(SearchControl)));
        }

        public override void OnApplyTemplate()
        {
            var searchButton = Template.FindName("PART_SearchButton", this) as Button;
            if (searchButton != null)
            {
                searchButton.Click += (sender, args) => ExecuteSearch();
            }
            var clearButton = Template.FindName("PART_ClearButton", this) as Button;
            if (clearButton != null)
            {
                clearButton.Click += (sender, args) => ExecuteClear();
            }
            base.OnApplyTemplate();
        }


        /// <summary>
        /// Called when a key is pressed.
        /// </summary>
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ExecuteSearchCommand();
            }
            if (e.Key == Key.Escape)
            {
                ExecuteClearCommand();
            }
            base.OnKeyDown(e);
        }

        protected override void OnTextChanged(TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Text))
            {
                ExecuteClearCommand();
            }
            base.OnTextChanged(e);
        }

        private void ExecuteSearchCommand()
        {
            if (SearchCommand != null && SearchCommand.CanExecute(Text))
            {
                SearchCommand.Execute(Text);
                ExecuteSearch();
            }
        }

        private void ExecuteClearCommand()
        {
            if (ClearCommand != null)
            {
                if (ClearCommand.CanExecute(null))
                {
                    ClearCommand.Execute(null);
                    ExecuteClear();
                }
            }
        }

        private void ExecuteSearch()
        {
            if (SearchCommand == null || (SearchCommand != null && SearchCommand.CanExecute(Text)))
            {
                IsSearchComplete = true;
            }
            
        }

        private void ExecuteClear()
        {
            if (ClearCommand == null || (ClearCommand != null && ClearCommand.CanExecute(Text)))
            {
                Text = "";
                IsSearchComplete = false;
            }
        }

        
    }
}
