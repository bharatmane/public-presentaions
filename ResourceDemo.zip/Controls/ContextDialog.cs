﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Telerik.Windows.Controls;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.ViewModel;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Used to display a dialog linked to a given context.
    /// </summary>
    public class ContextDialog : RadWindow, IContextDialog
    {

        /// <summary>
        /// Opens the current view on the context.
        /// </summary>
        /// <param name="parent">The parent to overlay.</param>
        /// <param name="view">The view to open.</param>
        public void Show(FrameworkElement parent, FrameworkElement view)
        {
            bool ShowTransparentBackground = false;
            if (view.DataContext != null && view.DataContext is BaseNavigationViewModel)
            {
                ShowTransparentBackground = (view.DataContext as BaseNavigationViewModel).ShowTransparentBackground;
            }
            Content = view;
            ResizeMode = ResizeMode.NoResize;
            SizeToContent = true;

            var radWindow = parent as RadWindow ?? UIHelper.FindVisualParent<RadWindow>(parent);
            Owner = radWindow != null ? (ContentControl)radWindow : Application.Current.MainWindow;

            if (parent != null)
            {
                var layer = AdornerLayer.GetAdornerLayer(parent);
                if (layer != null)
                {
                    //parent.Effect = new BlurEffect { Radius = 2 }; 
                    parent.IsEnabled = false;
                    IsRestricted = true;

                    parent.PreviewKeyDown += Parent_PreviewKeyDown;

                    Brush background = ModalBackground;
                    if (ShowTransparentBackground)
                    {
                        parent.IsEnabled = true;
                        background = new SolidColorBrush(Colors.Transparent);
                    }
                    var adorner = new WindowFadeAdorner(parent, background);
                    adorner.IsEnabled = false;

                    adorner.PreviewKeyDown += Adorner_PreviewKeyDown;
                    layer.Add(adorner);

                    PreviewClosed += delegate
                    {
                        adorner.PreviewKeyDown -= Adorner_PreviewKeyDown;
                        parent.PreviewKeyDown -= Parent_PreviewKeyDown;

                        layer.Remove(adorner);
                        parent.Effect = null;
                        parent.IsEnabled = true;
                    };
                    Closed += delegate
                    {
                        adorner.PreviewKeyDown -= Adorner_PreviewKeyDown;
                        parent.PreviewKeyDown -= Parent_PreviewKeyDown;

                        layer.Remove(adorner);
                        parent.Effect = null;
                        parent.IsEnabled = true;
                    };
                }
            }

            Loaded += OnLoaded;
            Show();
        }

        /// <summary>
        /// Handles the PreviewKeyDown event of the Adorner control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="KeyEventArgs"/> instance containing the event data.</param>
        private void Adorner_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
        }

        /// <summary>
        /// Handles the PreviewKeyDown event of the Parent control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Input.KeyEventArgs"/> instance containing the event data.</param>
        private void Parent_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            Loaded -= OnLoaded;
            var o = Owner as Window;
            if (o != null)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    var screenWidth = o.Width;
                    var screenHeight = o.Height;
                    var windowWidth = Width;
                    var windowHeight = Height;
                    Left = (screenWidth / 2) - (windowWidth / 2);
                    Top = (screenHeight / 2) - (windowHeight / 2);
                }), DispatcherPriority.Background);
            }
        }

        /// <summary>
        /// Called when the dialog is closing.
        /// </summary>
        protected override bool OnClosing()
        {
            var view = Content as FrameworkElement;
            if (view != null)
            {
                var vm = view.DataContext as IDialogAware;
                if (vm != null)
                {
                    return vm.CanClose() && base.OnClosing();
                }
            }
            return base.OnClosing();
        }
    }
}
