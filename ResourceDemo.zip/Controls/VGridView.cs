﻿using GalaSoft.MvvmLight.Command;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Data;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;
using VShips.Framework.Resource.Controls.Export;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A gridview extending the radgridview control in order to support
    /// the additional framework requirements such as server side sorting and paging.
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.RadGridView" />
    public class VGridView : RadGridView
    {
        #region Service

        /// <summary>
        /// The vm service
        /// </summary>
        private static IViewModelService _vmService;

        /// <summary>
        /// Retrieves the main view model service which gives access to common services.
        /// See the <see cref="IViewModelService" /> for more information.
        /// </summary>
        /// <value>
        /// The vm service.
        /// </value>
        protected static IViewModelService VMService
        {
            get { return _vmService ?? (_vmService = ServiceLocator.Current.GetInstance<IViewModelService>()); }
        }

        #endregion

        #region Dependency Properties

        /// <summary>
        /// The export file name
        /// </summary>
        public static readonly DependencyProperty ExportFileNameProperty =
            DependencyProperty.Register("ExportFileName", typeof(string), typeof(VGridView), new PropertyMetadata(string.Empty));

        /// <summary>
        /// The is export multi format property
        /// </summary>
        public static readonly DependencyProperty IsExportMultiFormatProperty =
            DependencyProperty.Register("IsExportMultiFormat", typeof(bool), typeof(VGridView), new PropertyMetadata(true));

        /// <summary>
        /// The additional columns property
        /// </summary>
        public static readonly DependencyProperty AdditionalColumnsProperty =
            DependencyProperty.Register("AdditionalColumns", typeof(IEnumerable), typeof(VGridView), new PropertyMetadata(null, OnAdditionalColumnsChanged));

        /// <summary>
        /// A mechanism that allows data to be retreived on demand. Items must implement IScrollItem for this to work.
        /// </summary>
        public static readonly DependencyProperty UsesDataScrollingProperty =
            DependencyProperty.Register("UsesDataScrolling", typeof(bool), typeof(VGridView), new PropertyMetadata(false));

        /// <summary>
        /// If this is true then sorting is done server side and is triggered by updating the SortDefinitions of the IScrollCollection.
        /// </summary>
        public static readonly DependencyProperty UsesServerSideSortingProperty =
            DependencyProperty.Register("UsesServerSideSortingProperty", typeof(bool), typeof(VGridView), new PropertyMetadata(false));

        /// <summary>
        /// The uses editable collection property
        /// </summary>
        public static readonly DependencyProperty UsesEditableCollectionProperty =
            DependencyProperty.Register("UsesEditableCollection", typeof(bool), typeof(VGridView), new PropertyMetadata(false, OnEditableCollectionChanged));


        /// <summary>
        /// The uses multi select collection property
        /// </summary>
        public static readonly DependencyProperty UsesMultiSelectCollectionProperty =
            DependencyProperty.Register("UsesMultiSelectCollection", typeof(bool), typeof(VGridView), new PropertyMetadata(false, OnMultiSelectCollectionChanged));

        /// <summary>
        /// Command that is run when the mouse is double clicked. The viewmodel of the clicked item is passed to the command.
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
            DependencyProperty.Register("DoubleClickCommand", typeof(ICommand), typeof(VGridView), new PropertyMetadata(null));

        /// <summary>
        /// If this is true and the grid has a contextmenu then the right click action will be used to select a row before the menu opens.
        /// </summary>
        public static readonly DependencyProperty UsesRightClickFixProperty =
            DependencyProperty.Register("UsesRightClickFix", typeof(bool), typeof(VGridView), new PropertyMetadata(false, OnRightClickFixChanged));

        /// <summary>
        /// Shows a no items label if the grid is empty and not busy.
        /// </summary>
        public static readonly DependencyProperty ShowNoItemsLabelProperty =
            DependencyProperty.Register("ShowNoItemsLabel", typeof(bool), typeof(VGridView), new PropertyMetadata(false));

        /// <summary>
        /// The copy only focused cell property
        /// </summary>
        public static readonly DependencyProperty CopyOnlyFocusedCellProperty =
            DependencyProperty.Register("CopyOnlyFocusedCell", typeof(bool), typeof(VGridView), new PropertyMetadata(false));

        /// <summary>
        /// Used to pass the data from a drop event to the viewmodel for parsing.
        /// </summary>
        public static readonly DependencyProperty DropTargetProperty =
            DependencyProperty.Register("DropTarget", typeof(IDropTarget), typeof(VGridView), new PropertyMetadata(null));

        /// <summary>
        /// The index of the cell to focus after an insert. If this is -1 then the default behaviour will be used.
        /// </summary>
        public static readonly DependencyProperty FocusOnInsertIndexProperty =
            DependencyProperty.Register("FocusOnInsertIndex", typeof(int), typeof(VGridView), new PropertyMetadata(-1));

        /// <summary>
        /// The label to apply when there are no item to show.
        /// </summary>
        public static readonly DependencyProperty NoItemsLabelProperty =
            DependencyProperty.Register("NoItemsLabel", typeof(string), typeof(VGridView), new PropertyMetadata("No items found."));

        /// <summary>
        /// A bindable command that runs the export from the grid.
        /// </summary>
        public static readonly DependencyProperty ExportCommandProperty =
            DependencyProperty.Register("ExportCommand", typeof(ICommand), typeof(VGridView), new PropertyMetadata(null));

        /// <summary>
        /// An attached property that determines if the rows data is loaded or not. Used in the lazy loading scrolling scenario.
        /// </summary>
        public static readonly DependencyProperty IsDummyItemProperty =
            DependencyProperty.RegisterAttached("IsDummyItem", typeof(bool), typeof(VGridView), new PropertyMetadata(false));

        /// <summary>
        /// The limit record count property
        /// </summary>
        public static readonly DependencyProperty LimitRecordCountProperty =
            DependencyProperty.Register("LimitRecordCount", typeof(int), typeof(VGridView), new PropertyMetadata(0));

        /// <summary>
        /// The is filtering enabled property
        /// </summary>
        public static readonly DependencyProperty IsFilteringEnabledProperty =
            DependencyProperty.Register("IsFilteringEnabled", typeof(bool), typeof(VGridView), new PropertyMetadata(false));


        /// <summary>
        /// The fix left column count property
        /// </summary>
        public static readonly DependencyProperty FixLeftColumnCountProperty =
            DependencyProperty.Register("FixLeftColumnCount", typeof(int), typeof(VGridView), new PropertyMetadata(0));


        /// <summary>
        /// The fix right column count property
        /// </summary>
        public static readonly DependencyProperty FixRightColumnCountProperty =
            DependencyProperty.Register("FixRightColumnCount", typeof(int), typeof(VGridView), new PropertyMetadata(0));


        /// <summary>
        /// The is header selected property
        /// </summary>
        public static readonly DependencyProperty IsHeaderSelectedProperty =
            DependencyProperty.RegisterAttached("IsHeaderSelected", typeof(bool), typeof(VGridView), new PropertyMetadata(false, OnIsHeaderSelectedChanged));


        /// <summary>
        /// The column data loaded property
        /// ColumnDataLoaded property is created to check if the data required for dynamic (additional) columns is loaded i.e. received from service
        /// as we need to generate the columns once the data is avaliable (OnAdditionalColumnsProperty) change do the same thing but it is called once the column list binded is initalised
        /// and if we add the items after initilisation it do not fire and dynamic (additional) columns are not generated.
        /// </summary>
        public static readonly DependencyProperty ColumnDataLoadedProperty =
            DependencyProperty.RegisterAttached("ColumnDataLoaded", typeof(bool), typeof(VGridView),
                new PropertyMetadata(true, OnColumnDataLoadedChanged));

        /// <summary>
        /// Attempts to scroll the selected item in view if this is true and the selecteditem changes.
        /// </summary>
        public static readonly DependencyProperty ScrollToSelectionProperty =
            DependencyProperty.Register("ScrollToSelection", typeof(bool), typeof(VGridView), new PropertyMetadata(false));

        /// <summary>
        /// The filtering dropdown state property
        /// </summary>
        public static readonly DependencyProperty FilteringDropdownStateProperty =
            DependencyProperty.Register("FilteringDropdownState", typeof(WindowState), typeof(VGridView), new PropertyMetadata(WindowState.Maximized));

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the initial group descriptor collection.
        /// </summary>
        /// <value>
        /// The initial group descriptor collection.
        /// </value>
        public GroupDescriptorCollection InitialGroupDescriptorCollection
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is export multi format.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is export multi format; otherwise, <c>false</c>.
        /// </value>
        public bool IsExportMultiFormat
        {
            get { return (bool)GetValue(IsExportMultiFormatProperty); }
            set { SetValue(IsExportMultiFormatProperty, value); }
        }

        /// <summary>
        /// Gets or sets the name of the export file.
        /// </summary>
        /// <value>
        /// The name of the export file.
        /// </value>
        public string ExportFileName
        {
            get { return (string)GetValue(ExportFileNameProperty); }
            set { SetValue(ExportFileNameProperty, value); }
        }

        /// <summary>
        /// Gets or sets the additional columns.
        /// </summary>
        /// <value>
        /// The additional columns.
        /// </value>
        public IEnumerable AdditionalColumns
        {
            get { return (IEnumerable)GetValue(AdditionalColumnsProperty); }
            set { SetValue(AdditionalColumnsProperty, value); }
        }

        /// <summary>
        /// The export dialog
        /// </summary>
        private ExportDialog _exportDialog;

        /// <summary>
        /// Exposes the <see cref="UsesDataScrollingProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [uses data scrolling]; otherwise, <c>false</c>.
        /// </value>
        public bool UsesDataScrolling
        {
            get { return (bool)GetValue(UsesDataScrollingProperty); }
            set { SetValue(UsesDataScrollingProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="UsesDataScrollingProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// <c>true</c> if [uses server side sorting]; otherwise, <c>false</c>.
        /// </value>
        public bool UsesServerSideSorting
        {
            get { return (bool)GetValue(UsesServerSideSortingProperty); }
            set { SetValue(UsesServerSideSortingProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="UsesEditableCollectionProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// <c>true</c> if [uses editable collection]; otherwise, <c>false</c>.
        /// </value>
        public bool UsesEditableCollection
        {
            get { return (bool)GetValue(UsesEditableCollectionProperty); }
            set { SetValue(UsesEditableCollectionProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [uses multi select collection].
        /// </summary>
        /// <value>
        /// <c>true</c> if [uses multi select collection]; otherwise, <c>false</c>.
        /// </value>
        public bool UsesMultiSelectCollection
        {
            get { return (bool)GetValue(UsesMultiSelectCollectionProperty); }
            set { SetValue(UsesMultiSelectCollectionProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="DoubleClickCommand" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The double click command.
        /// </value>
        public ICommand DoubleClickCommand
        {
            get { return (ICommand)GetValue(DoubleClickCommandProperty); }
            set { SetValue(DoubleClickCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="UsesRightClickFixProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [uses right click fix]; otherwise, <c>false</c>.
        /// </value>
        public bool UsesRightClickFix
        {
            get { return (bool)GetValue(UsesRightClickFixProperty); }
            set { SetValue(UsesRightClickFixProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="ShowNoItemsLabelProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show no items label]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowNoItemsLabel
        {
            get { return (bool)GetValue(ShowNoItemsLabelProperty); }
            set { SetValue(ShowNoItemsLabelProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [copy only focused cell].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [copy only focused cell]; otherwise, <c>false</c>.
        /// </value>
        public bool CopyOnlyFocusedCell
        {
            get { return (bool)GetValue(CopyOnlyFocusedCellProperty); }
            set { SetValue(CopyOnlyFocusedCellProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="NoItemsLabelProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The no items label.
        /// </value>
        public string NoItemsLabel
        {
            get { return (string)GetValue(NoItemsLabelProperty); }
            set { SetValue(NoItemsLabelProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is filtering enabled.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is filtering enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsFilteringEnabled
        {
            get { return (bool)GetValue(IsFilteringEnabledProperty); }
            set { SetValue(IsFilteringEnabledProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="DropTargetProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The drop target.
        /// </value>
        public IDropTarget DropTarget
        {
            get { return (IDropTarget)GetValue(DropTargetProperty); }
            set { SetValue(DropTargetProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="FocusOnInsertIndexProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The index of the focus on insert.
        /// </value>
        public int FocusOnInsertIndex
        {
            get { return (int)GetValue(FocusOnInsertIndexProperty); }
            set { SetValue(FocusOnInsertIndexProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="ExportCommandProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The export command.
        /// </value>
        public ICommand ExportCommand
        {
            get { return (ICommand)GetValue(ExportCommandProperty); }
            set { SetValue(ExportCommandProperty, value); }
        }

        /// <summary>
        /// Sets the <see cref="IsDummyItemProperty" /> DependencyProperty.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetIsDummyItem(UIElement element, bool value)
        {
            element.SetValue(IsDummyItemProperty, value);
        }

        /// <summary>
        /// Gets the <see cref="IsDummyItemProperty" /> DependencyProperty.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static bool GetIsDummyItem(UIElement element)
        {
            return (bool)element.GetValue(IsDummyItemProperty);
        }

        /// <summary>
        /// Gets or sets the limit record count.
        /// </summary>
        /// <value>
        /// The limit record count.
        /// </value>
        public int LimitRecordCount
        {
            get { return (int)GetValue(LimitRecordCountProperty); }
            set { SetValue(LimitRecordCountProperty, value); }
        }


        /// <summary>
        /// Gets or sets the fix left column count.
        /// </summary>
        /// <value>
        /// The fix left column count.
        /// </value>
        public int FixLeftColumnCount
        {
            get { return (int)GetValue(FixLeftColumnCountProperty); }
            set { SetValue(FixLeftColumnCountProperty, value); }
        }

        /// <summary>
        /// Gets or sets the fix right column count.
        /// </summary>
        /// <value>
        /// The fix right column count.
        /// </value>
        public int FixRightColumnCount
        {
            get { return (int)GetValue(FixRightColumnCountProperty); }
            set { SetValue(FixRightColumnCountProperty, value); }
        }

        /// <summary>
        /// Gets the is header selected.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public static bool GetIsHeaderSelected(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsHeaderSelectedProperty);
        }

        /// <summary>
        /// Sets the is header selected.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public static void SetIsHeaderSelected(DependencyObject obj, bool value)
        {
            obj.SetValue(IsHeaderSelectedProperty, value);
        }


        /// <summary>
        /// Exposes the <see cref="ColumnDataLoadedProperty" /> attached property.
        /// </summary>
        /// <param name="element">The element the property is attached to.</param>
        /// <param name="value">The value for the attached property.</param>
        [AttachedPropertyBrowsableForType(typeof(VGridView))]
        public static void SetColumnDataLoaded(UIElement element, bool value)
        {
            element.SetValue(ColumnDataLoadedProperty, value);
        }

        /// <summary>
        /// Exposes the <see cref="ColumnDataLoadedProperty" /> attached property.
        /// </summary>
        /// <param name="element">The element to get the property value of type <see cref="UIElement" />.</param>
        /// <returns>
        /// Single bool value.
        /// </returns>
        public static bool GetColumnDataLoaded(UIElement element)
        {
            return (bool)element.GetValue(ColumnDataLoadedProperty);
        }

        /// <summary>
        /// Exposes the <see cref="ScrollToSelectionProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [scroll to selection]; otherwise, <c>false</c>.
        /// </value>
        public bool ScrollToSelection
        {
            get { return (bool)GetValue(ScrollToSelectionProperty); }
            set { SetValue(ScrollToSelectionProperty, value); }
        }

        /// <summary>
        /// Gets or sets the state of the filtering dropdown.
        /// </summary>
        /// <value>
        /// The state of the filtering dropdown.
        /// </value>
        public WindowState FilteringDropdownState
        {
            get { return (WindowState)GetValue(FilteringDropdownStateProperty); }
            set { SetValue(FilteringDropdownStateProperty, value); }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes the <see cref="VGridView" /> class.
        /// </summary>
        static VGridView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VGridView), new FrameworkPropertyMetadata(typeof(VGridView)));
        }

        #endregion              

        #region Override Methods

        /// <summary>
        /// Applies the template to the control.
        /// </summary>
        public override void OnApplyTemplate()
        {
            MouseDoubleClick += DgOnMouseDoubleClick;
            Unloaded += gridView_Unloaded;
            DataLoading += VGridView_DataLoading;
            ClipboardCopyMode = GridViewClipboardCopyMode.Cells;

            if (CopyOnlyFocusedCell)
            {
                CopyingCellClipboardContent += VGridView_CopyingCellClipboardContent;
            }
            ExportCommand = new RelayCommand(Export, CanExport);
            DataLoaded += VGridView_DataLoaded;

            Sorting += OnSorting;
            AddingNewDataItem += (sender, e) =>
            {
                var grid = e.OwnerGridViewItemsControl;
                var columns = grid.Columns.Count;
                if (FocusOnInsertIndex >= 0 && FocusOnInsertIndex < columns)
                {
                    grid.CurrentColumn = grid.Columns[FocusOnInsertIndex];
                }
            };
            if (this.IsFilteringAllowed)
            {
                FilterOperatorsLoading += VGridView_FilterOperatorsLoading;
                Application.Current.MainWindow.SizeChanged += OnVGridViewWindowSizeChanged;
                Loaded += OnVGridViewWindowSizeChanged;
            }

            InitialGroupDescriptorCollection = new GroupDescriptorCollection();
            InitialGroupDescriptorCollection.AddRange(this.GroupDescriptors);
            base.OnApplyTemplate();

        }

        /// <summary>
        /// Handles the DataLoaded event of the VGridView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void VGridView_DataLoaded(object sender, EventArgs e)
        {
            var command = (ExportCommand as RelayCommand);
            if (ItemsSource != null && command != null)
            {
                command.RaiseCanExecuteChanged();
            }
            SetGroupOnDataLoad(sender);
        }

        /// <summary>
        /// Called when [v grid view window size changed].
        /// </summary>
        private void OnVGridViewWindowSizeChanged(object sender, EventArgs args)
        {
            FilteringDropdownState = Application.Current.MainWindow.WindowState;
            if (Application.Current.MainWindow.ActualHeight <= 768)
            {
                FilteringDropdownState = WindowState.Normal;
            }
        }

        /// <summary>
        /// Handles the CopyingCellClipboardContent event of the VGridView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="GridViewCellClipboardEventArgs"/> instance containing the event data.</param>
        private static void VGridView_CopyingCellClipboardContent(object sender, GridViewCellClipboardEventArgs eventArgs)
        {
            VGridView gridView = (VGridView)eventArgs.OriginalSource;
            if (gridView != null && gridView.CurrentCell != null && gridView.CurrentCell.Column != null
                && eventArgs != null && eventArgs.Cell != null && eventArgs.Cell.Column != null
                && gridView.CurrentCell.Column.DisplayIndex != eventArgs.Cell.Column.DisplayIndex)
            {
                //If Current cell display index != cell.DisplayIndex then cancel the copy action for current cell.
                eventArgs.Cancel = true;
            }
        }

        /// <summary>
        /// Called when [items source changed].
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        protected override void OnItemsSourceChanged(object oldValue, object newValue)
        {
            if (ItemsSource is IEditableCollection)
            {
                var collection = GetEditableCollection(this);
                if (collection != null)
                {
                    collection.AddMethodAction += AddDataItem;
                }
            }
            base.OnItemsSourceChanged(oldValue, newValue);
        }

        /// <summary>
        /// Handles the FilterOperatorsLoading event of the VGridView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="argument">The <see cref="FilterOperatorsLoadingEventArgs"/> instance containing the event data.</param>
        private static void VGridView_FilterOperatorsLoading(object sender, FilterOperatorsLoadingEventArgs argument)
        {
            if (argument.AvailableOperators != null && argument.AvailableOperators.Any(x => x == FilterOperator.Contains))
            {
                argument.DefaultOperator1 = Telerik.Windows.Data.FilterOperator.Contains;
                argument.DefaultOperator2 = Telerik.Windows.Data.FilterOperator.Contains;
            }
        }

        /// <summary>
        /// Handles the DataLoading event of the VGridView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        static void VGridView_DataLoading(object sender, EventArgs e)
        {
            var gridView = sender as VGridView;
            if (gridView != null && gridView.IsFilteringAllowed)
            {
                gridView.FilterDescriptors.SuspendNotifications();

                foreach (var column in gridView.Columns)
                {
                    column.ClearFilters();
                }

                gridView.FilterDescriptors.ResumeNotifications();
            }
        }

        /// <summary>
        /// Raises the <see cref="E:ColumnReordered" /> event.
        /// </summary>
        /// <param name="eventArguments">The <see cref="GridViewColumnEventArgs" /> instance containing the event data.</param>
        protected override void OnColumnReordered(GridViewColumnEventArgs eventArguments)
        {
            if (!eventArguments.Column.IsResizable)
            {
                //Following code helps fix the issue where after re-ordering a non-resizable column, we still get the left gripper for resizing, although the column does not  resize on using the gripper.
                //This code ensures if column is non-resizable, the left gripper should not be visible even after re-ordering.
                //Reference Link: http://www.telerik.com/forums/radgridview-able-to-resize-after-reordering-columns
                //This was a telerik issue raised by Naved and is being investigated by telerik team.
                //Meanwhile, they have offered this quick fix till they find a resolution.
                //Refer to https://feedback.telerik.com/Project/143/Feedback/Details/214142-gridview-reordering-a-non-resizable-column-to-the-right-results-in-the-column-be for further details.
                Dispatcher.BeginInvoke((Action)(() =>
                {
                    var radGridView = eventArguments.Column.Parent;
                    foreach (var header in radGridView.ChildrenOfType<GridViewHeaderCell>())
                    {
                        if (header.Column.DisplayIndex == (eventArguments.Column.DisplayIndex + 1))
                        {
                            var leftGripper = header.ChildrenOfType<Thumb>().Where(x => x.Name == "PART_LeftHeaderGripper").First();
                            {
                                leftGripper.Visibility = Visibility.Collapsed;
                            }
                        }
                    }
                }), DispatcherPriority.Render);
            }
            base.OnColumnReordered(eventArguments);
        }

        /// <summary>
        /// Determines whether this instance can export.
        /// </summary>
        /// <returns>
        ///   <c>true</c> if this instance can export; otherwise, <c>false</c>.
        /// </returns>
        public bool CanExport()
        {
            return ItemsSource != null && (ItemsSource is ICollection) && (ItemsSource as ICollection).Count != 0;
        }

        /// <summary>
        /// Exports the current gridview collection.
        /// </summary>
        public void Export()
        {
            var totalPages = 1;
            var collection = ItemsSource as IScrollCollection;
            if (collection != null)
            {
                totalPages = collection.TotalPages;
            }
            if (IsExportMultiFormat)
            {
                _exportDialog = new ExportDialog { DataContext = new ExportViewModel(DoExport) { TotalPages = totalPages, FileName = ExportFileName } };
                _exportDialog.ShowDialog();
            }
            else
            {
                ExportViewModel export = new ExportViewModel(DoExport) { TotalPages = totalPages, FileName = ExportFileName };
                export.IsExcel = true;
                export.ExportCommand.Execute(null);
            }
        }

        /// <summary>
        /// Does the export.
        /// </summary>
        /// <param name="export">The export of type <see cref="ExportViewModel" />.</param>
        private async void DoExport(ExportViewModel export)
        {
            IsBusy = true;
            try
            {
                if (_exportDialog != null)
                {
                    _exportDialog.Close();
                    _exportDialog = null;
                }
                await LoadPages(export.StartPage, export.EndPage);
                var f = File.Create(export.FileName);
                ExportAsync(f, () => ExportComplete(export.FileName), new GridViewExportOptions
                {
                    Format = export.ExportFormat,
                    ShowColumnHeaders = true,
                    ShowColumnFooters = true,
                    ShowGroupFooters = true
                }, true);
            }
            catch (Exception ex)
            {
                ServiceLocator.Current.GetInstance<ILoggerService>().Error("An error occurred exporting.", ex.Message, ex);
            }
            IsBusy = false;
        }

        /// <summary>
        /// Loads the pages.
        /// </summary>
        /// <param name="startPage">The start page.</param>
        /// <param name="endPage">The end page.</param>
        /// <returns>
        /// Single Task Object.
        /// </returns>
        private async Task LoadPages(int startPage, int endPage)
        {
            var collection = ItemsSource as IScrollCollection;
            if (collection != null)
            {
                for (var x = startPage; x <= endPage; x++)
                {
                    await collection.RetreivePage(x);
                }
            }
        }

        /// <summary>
        /// Exports the complete.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        private void ExportComplete(string fileName)
        {
            try
            {
                Process.Start(fileName);
            }
            catch (Exception ex)
            {
                ServiceLocator.Current.GetInstance<ILoggerService>().Error("An error occurred opening the file " + fileName + ".", ex.Message, ex);
            }
        }

        /// <summary>
        /// Executes the <see cref="DoubleClickCommand" /> if double clicked on an item.
        /// </summary>
        /// <param name="eventArguments">The <see cref="MouseButtonEventArgs" /> instance containing the event data.</param>
        protected override void OnMouseDoubleClick(MouseButtonEventArgs eventArguments)
        {
            if (eventArguments != null && eventArguments.ChangedButton == MouseButton.Left)
            {
                if (DoubleClickCommand != null)
                {
                    var source = eventArguments.OriginalSource as DependencyObject;
                    if (source != null)
                    {
                        var item = UIHelper.FindVisualParent<GridViewRow>(source, this);
                        if (item != null)
                        {
                            var vm = item.DataContext;
                            if (DoubleClickCommand.CanExecute(vm))
                            {
                                DoubleClickCommand.Execute(vm);
                            }
                        }
                    }
                }
            }
            base.OnMouseDoubleClick(eventArguments);
        }

        /// <summary>
        /// Prepares the container for the item.
        /// </summary>
        /// <param name="element">The element of type <see cref="DependencyObject" />.</param>
        /// <param name="item">The item.</param>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            if (UsesDataScrolling)
            {
                var gridViewRow = element as GridViewRow;
                var vm = item as IScrollItem;
                Debug.Assert(item != null, "Item must implement the interface IScrollItem.");
                if (gridViewRow != null && vm != null)
                {
                    var binding = new Binding("IsDummy");
                    gridViewRow.SetBinding(IsDummyItemProperty, binding);
                    vm.OnViewLoaded();
                }
            }
            base.PrepareContainerForItemOverride(element, item);
        }

        #endregion

        #region Methods

        /// <summary>
        /// On selected item changed.
        /// </summary>
        /// <param name="oldItem">The old item.</param>
        /// <param name="newItem">The new item.</param>
        protected override void OnSelectedItemChanged(object oldItem, object newItem)
        {
            base.OnSelectedItemChanged(oldItem, newItem);
            if (ScrollToSelection)
            {
                ScrollToSelectedItem();
            }
        }


        /// <summary>
        /// Attempts to scroll the selected item into view.
        /// </summary>
        public void ScrollToSelectedItem()
        {
            if (SelectedItem != null)
            {
                Dispatcher.BeginInvoke((Action)(() =>
                {
                    UpdateLayout();
                    if (SelectedItem != null)
                    {
                        ScrollIntoView(SelectedItem);
                    }
                }));
            }
        }

        /// <summary>
        /// Adds the data item.
        /// </summary>
        private void AddDataItem()
        {
            PendingCommands.Add(RadGridViewCommands.BeginInsert);
            ExecutePendingCommand();
        }

        /// <summary>
        /// Called when [column data loaded changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        /// <exception cref="System.NotImplementedException"></exception>
        private static void OnColumnDataLoadedChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            if ((bool)eventArgs.NewValue)
            {
                var control = (VGridView)dependencyObject;
                var result = GetAdditionalColumns(control);
                var columns = result != null ? result.OfType<object>().ToList() : new List<object>();
                GenerateColumns(control, columns);
            }
        }


        /// <summary>
        /// Called when [additional columns changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type <see cref="DependencyObject" />.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnAdditionalColumnsChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            var control = (VGridView)dependencyObject;
            var result = eventArgs.NewValue as IEnumerable;
            var columns = result != null ? result.OfType<object>().ToList() : new List<object>();
            bool dataLoaded = GetColumnDataLoaded(control);
            if (dataLoaded)
            {
                if (control.IsLoaded)
                {
                    GenerateColumns(control, columns);
                }
                else
                {
                    control.Loaded += ControlOnLoaded;
                }
            }

        }

        /// <summary>
        /// Controls the on loaded.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArgs">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private static void ControlOnLoaded(object sender, RoutedEventArgs eventArgs)
        {
            var control = (VGridView)sender;
            control.Loaded -= ControlOnLoaded;
            var result = GetAdditionalColumns(control);
            var columns = result != null ? result.OfType<object>().ToList() : new List<object>();

            GenerateColumns(control, columns);
        }

        /// <summary>
        /// Gets the additional columns.
        /// </summary>
        /// <param name="element">The element of type <see cref="UIElement" />.</param>
        /// <returns>
        /// Single object of type <see cref="IEnumerable" />.
        /// </returns>
        public static IEnumerable GetAdditionalColumns(UIElement element)
        {
            return (IEnumerable)element.GetValue(AdditionalColumnsProperty);
        }
        /// <summary>
        /// Sets the additional columns.
        /// </summary>
        /// <param name="element">The element of type <see cref="UIElement" />.</param>
        /// <param name="value">The value of type <see cref="IEnumerable" />.</param>
        public static void SetAdditionalColumns(UIElement element, IEnumerable value)
        {
            element.SetValue(AdditionalColumnsProperty, value);
        }

        /// <summary>
        /// Generates the columns.
        /// </summary>
        /// <param name="gridView">The grid view of type <see cref="VGridView" />.</param>
        /// <param name="columns">The columns.</param>
        private static void GenerateColumns(VGridView gridView, List<object> columns)
        {
            if (gridView.FixLeftColumnCount > 0 || gridView.FixRightColumnCount > 0)
            {
                if (gridView.Columns != null)
                {
                    //Remove Columns if already added.
                    int count = gridView.Columns.Count;
                    for (int i = count - 1 - gridView.FixRightColumnCount; i >= gridView.FixLeftColumnCount; i--)
                    {
                        gridView.Columns.Remove(gridView.Columns[i]);
                    }
                }
            }

            List<string> groupHeaderNameList = new List<string>();
            List<string> groupHeaderTextList = new List<string>();
            List<string> groupHeaderTemplateList = new List<string>();

            TextWrapping HeaderTextWrapping = TextWrapping.Wrap;
            //Add Columns to the grid.
            for (var columnIndex = 0; columnIndex < columns.Count; columnIndex++)
            {
                var column = columns[columnIndex];
                var data = new VGridViewGenericColumn();

                var headerStyleName = column.GetType().GetProperty("HeaderStyle").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerStyleName))
                {
                    TextBlock header = new TextBlock();
                    header.Text = column.GetType().GetProperty("Header").GetValue(column) as string;
                    header.Style = gridView.FindResource(headerStyleName) as Style;
                    data.Header = header;
                }
                else
                {
                    data.SetBinding(VGridViewGenericColumn.HeaderProperty, new Binding("Header") { Source = column });
                }

                var headerGroupName = column.GetType().GetProperty("HeaderGroupName").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerGroupName))
                {
                    data.ColumnGroupName = headerGroupName;
                    groupHeaderNameList.Add(headerGroupName);
                }

                var headerGroupText = column.GetType().GetProperty("HeaderGroupText").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerGroupText))
                {
                    groupHeaderTextList.Add(headerGroupText);
                }

                var headerGroupTemplate = column.GetType().GetProperty("HeaderGroupTemplate").GetValue(column) as string;
                if (!string.IsNullOrWhiteSpace(headerGroupTemplate))
                {
                    groupHeaderTemplateList.Add(headerGroupTemplate);
                }

                var columnTemplateName = column.GetType().GetProperty("ContentTemplate").GetValue(column) as string;
                var dataMemberBinding = column.GetType().GetProperty("DataMemberBinding").GetValue(column) as string;

                if (!string.IsNullOrWhiteSpace(columnTemplateName))
                {
                    if (!string.IsNullOrWhiteSpace(dataMemberBinding))
                    {
                        data.DataMemberBinding = new Binding(string.Format(dataMemberBinding, columnIndex));
                        data.CustomValueBinding = new Binding(string.Format("Columns[{0}]", columnIndex));
                    }
                    else
                    {
                        data.DataMemberBinding = new Binding(string.Format("Columns[{0}]", columnIndex));
                    }
                    data.CellTemplate = gridView.FindResource(columnTemplateName) as DataTemplate;
                }
                else
                {
                    data.DataMemberBinding = new Binding(string.Format("Columns[{0}].Value", columnIndex));
                }

                //Set IsReadOnlyBinding.
                if (column.GetType().GetProperty("IsReadOnlyBinding") != null)
                {
                    var isReadOnlyBinding = column.GetType().GetProperty("IsReadOnlyBinding").GetValue(column) as string;
                    if (!string.IsNullOrWhiteSpace(isReadOnlyBinding))
                    {
                        data.IsReadOnlyBinding = new Binding(isReadOnlyBinding)
                        {
                            Converter = new InvertedBooleanConverter()
                        };
                    }
                    else
                    {
                        data.IsReadOnlyBinding = new Binding(string.Format("Columns[{0}]", columnIndex));
                    }
                }

                var columnEditTemplateName = column.GetType().GetProperty("ContentEditTemplate").GetValue(column) as string;

                if (!string.IsNullOrWhiteSpace(columnEditTemplateName))
                {
                    data.IsReadOnly = false;
                    data.CellEditTemplate = gridView.FindResource(columnEditTemplateName) as DataTemplate;
                }
                else
                {
                    data.IsReadOnly = true;
                }

                //Added by suraj
                string columnFooterValue = null, columnFooterStyle = null;
                if (column.GetType().GetProperty("FooterValue") != null)
                {
                    columnFooterValue = column.GetType().GetProperty("FooterValue").GetValue(column) as string;
                }
                if (column.GetType().GetProperty("FooterStyle") != null)
                {
                    columnFooterStyle = column.GetType().GetProperty("FooterStyle").GetValue(column) as string;
                }
                if (!string.IsNullOrWhiteSpace(columnFooterValue))
                {
                    var binding = new Binding("FooterValue") { Source = column, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged };
                    data.SetBinding(VGridViewGenericColumn.FooterProperty, binding);
                }
                if (!string.IsNullOrWhiteSpace(columnFooterStyle))
                {
                    data.FooterCellStyle = gridView.FindResource(columnFooterStyle) as Style;
                }

                bool? columnVisibility = null;

                if (column.GetType().GetProperty("IsColumnVisible") != null)
                {
                    columnVisibility = column.GetType().GetProperty("IsColumnVisible").GetValue(column) as bool?;
                }
                if (columnVisibility != null)
                {
                    var binding = new Binding("IsColumnVisible") { Source = column, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged };
                    data.SetBinding(VGridViewGenericColumn.IsVisibleProperty, binding);
                }

                if (column.GetType().GetProperty("CellStyle") != null)
                {
                    var cellStyle = column.GetType().GetProperty("CellStyle").GetValue(column) as string;
                    if (!string.IsNullOrWhiteSpace(cellStyle))
                    {
                        data.CellStyle = gridView.FindResource(cellStyle) as Style;
                    }
                }

                if (column.GetType().GetProperty("HeaderGroupNameWrapping") != null && column.GetType().GetProperty("HeaderGroupNameWrapping").GetValue(column) != null)
                {
                    HeaderTextWrapping = (TextWrapping)column.GetType().GetProperty("HeaderGroupNameWrapping").GetValue(column);
                }

                if (column.GetType().GetProperty("TabStopMode") != null && Equals(column.GetType().GetProperty("TabStopMode").PropertyType, typeof(GridViewTabStop)))
                {
                    data.SetBinding(VGridViewGenericColumn.TabStopModeProperty, new Binding("TabStopMode")
                    {
                        Source = column,
                        FallbackValue = GridViewTabStop.Stop,
                        TargetNullValue = GridViewTabStop.Stop
                    });
                }

                var minWidthValue = column.GetType().GetProperty("MinWidth").GetValue(column) as double?;
                if (minWidthValue != null)
                {
                    data.MinWidth = minWidthValue.Value;
                }

                var maxWidthValue = column.GetType().GetProperty("MaxWidth").GetValue(column) as double?;
                if (maxWidthValue != null)
                {
                    data.MaxWidth = maxWidthValue.Value;
                }

                var textAlignment = column.GetType().GetProperty("TextAlignment").GetValue(column) as TextAlignment?;
                if (textAlignment != null)
                {
                    data.TextAlignment = (TextAlignment)textAlignment;
                }

                gridView.Columns.Insert(gridView.Columns.Count - gridView.FixRightColumnCount, data);
            }

            var distinctGroupHeaderNameList = new List<string>();
            var distinctGroupHeaderTextList = new List<string>();
            var distinctGroupHeaderTemplateList = new List<string>();

            //Set the Column header group. leaving the static ones defined in the xaml
            if (gridView.ColumnGroups != null && gridView.ColumnGroups.Any())
            {
                if (groupHeaderNameList != null && groupHeaderNameList.Any() && gridView.ColumnGroups.Any(x => groupHeaderNameList.Contains(x.Name)))
                {
                    gridView.ColumnGroups.RemoveAll(x => groupHeaderNameList.Contains(x.Name));
                }
            }

            if (groupHeaderNameList != null && groupHeaderNameList.Any())
            {
                distinctGroupHeaderNameList = groupHeaderNameList.Distinct().ToList();
            }

            if (groupHeaderTextList != null && groupHeaderTextList.Any())
            {
                distinctGroupHeaderTextList = groupHeaderTextList.Distinct().ToList();
            }

            if (groupHeaderTemplateList != null && groupHeaderTemplateList.Any())
            {
                distinctGroupHeaderTemplateList = groupHeaderTemplateList.Distinct().ToList();
            }

            if (distinctGroupHeaderNameList.Count == distinctGroupHeaderTextList.Count)
            {
                for (int countIndex = 0; countIndex < distinctGroupHeaderNameList.Count; countIndex++)
                {
                    GridViewColumnGroup newColumngroup = new GridViewColumnGroup();

                    newColumngroup.Name = distinctGroupHeaderNameList[countIndex];

                    if (distinctGroupHeaderTemplateList == null || (distinctGroupHeaderTemplateList != null && !distinctGroupHeaderTemplateList.Any()))
                    {
                        var newTextBlock = new FrameworkElementFactory(typeof(TextBlock));
                        newTextBlock.SetValue(TextBlock.TextProperty, distinctGroupHeaderTextList[countIndex]);
                        newTextBlock.SetValue(TextBlock.TextAlignmentProperty, TextAlignment.Left);
                        newTextBlock.SetValue(TextBlock.TextWrappingProperty, HeaderTextWrapping);
                        DataTemplate newDataTemplate = new DataTemplate() { VisualTree = newTextBlock };

                        newColumngroup.HeaderTemplate = newDataTemplate;
                    }
                    else
                    {
                        newColumngroup.HeaderTemplate = gridView.FindResource(distinctGroupHeaderTemplateList[countIndex]) as DataTemplate;
                    }

                    gridView.ColumnGroups.Add(newColumngroup);
                }
            }
        }

        /// <summary>
        /// Sets the group on data load.
        /// </summary>
        /// <param name="sender">The sender.</param>
        private void SetGroupOnDataLoad(object sender)
        {
            var gridView = sender as VGridView;
            if (gridView != null)
            {
                var collection = GetResetGroupCollection(gridView);

                if (collection != null && collection.IsResetGroup && gridView.InitialGroupDescriptorCollection != null && gridView.InitialGroupDescriptorCollection.Any())
                {

                    gridView.GroupDescriptors.SuspendNotifications();
                    if (gridView.GroupDescriptors.NotificationsSuspended)
                    {
                        if (gridView.GroupDescriptors != null && gridView.GroupDescriptors.Any())
                        {
                            gridView.GroupDescriptors.Clear();
                        }
                    }

                    int i = -1;
                    foreach (var group in gridView.InitialGroupDescriptorCollection)
                    {
                        i += 1;
                        if (!(gridView.GroupDescriptors.Any(x => x.Equals(group))))
                        {
                            gridView.GroupDescriptors.Insert(i, group);
                        }

                    }
                    collection.IsResetGroup = false;
                    gridView.GroupDescriptors.ResumeNotifications();

                }
            }
        }


        /// <summary>
        /// Called when [sorting].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="GridViewSortingEventArgs" /> instance containing the event data.</param>
        private void OnSorting(object sender, GridViewSortingEventArgs eventArguments)
        {
            if (UsesServerSideSorting && ItemsSource != null)
            {
                var scroller = ItemsSource as IScrollCollection;
                Debug.Assert(scroller != null && scroller.SortDefinitions != null, "Bound collection must implement IScrollCollection and define a SortDefinitions collection!");

                if (eventArguments.NewSortingState == SortingState.None)
                {
                    scroller.SortDefinitions.SelectedSort = null;
                }
                else
                {
                    var columnName = eventArguments.Column.Header.ToString();
                    var sort = scroller.SortDefinitions.FirstOrDefault(x => string.Equals(x.DisplayName, columnName, StringComparison.InvariantCultureIgnoreCase));
                    Debug.Assert(sort != null, "Sort definition not found! The grid header name must match the display name of the sort definition.");
                    sort.ListSortDirection = eventArguments.NewSortingState == SortingState.Ascending ? ListSortDirection.Ascending : ListSortDirection.Descending;
                }
            }
        }

        /// <summary>
        /// Called when [right click fix changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type <see cref="DependencyObject" />.</param>
        /// <param name="eventArguments">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnRightClickFixChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArguments)
        {
            if ((bool)eventArguments.NewValue)
            {
                var gridView = (RadGridView)dependencyObject;

                gridView.PreviewMouseRightButtonDown += (sender, args) =>
                {
                    var row = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)args.OriginalSource);
                    if (row != null && !row.IsSelected)
                    {
                        VGridView vGridView = sender as VGridView;
                        if (vGridView != null && !Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
                        {
                            vGridView.SelectedItems.Clear();
                            row.IsSelected = true;
                        }
                    }
                };
            }
        }

        /// <summary>
        /// Called when [editable collection changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type <see cref="DependencyObject" />.</param>
        /// <param name="eventArguments">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnEditableCollectionChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArguments)
        {
            var gridView = dependencyObject as RadGridView;
            if (gridView != null)
            {
                if ((bool)eventArguments.NewValue)
                {
                    gridView.Deleting += DgOnDeleting;
                    gridView.BeginningEdit += DgOnBeginningEdit;
                    gridView.RowEditEnded += DgOnRowEditEnded;
                    gridView.AddingNewDataItem += DgOnAddingNewDataItem;
                    gridView.RowValidating += DgOnRowValidating;
                }
            }
        }

        /// <summary>
        /// Called when [multi select collection changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArguments">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnMultiSelectCollectionChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArguments)
        {
            var gridView = dependencyObject as RadGridView;
            if (gridView != null)
            {
                if ((bool)eventArguments.NewValue)
                {
                    gridView.SelectionChanged += DsgOnSelectionChanged;
                }
            }
        }

        /// <summary>
        /// DSGs the on selection changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="SelectionChangeEventArgs" /> instance containing the event data.</param>
        private static void DsgOnSelectionChanged(object sender, SelectionChangeEventArgs eventArguments)
        {
            var gridView = (VGridView)sender;
            var scrollCollection = GetMultiSelectCollection(gridView);
            if (scrollCollection != null)
            {
                scrollCollection.TypeCastSelectedItems(gridView.SelectedItems);
            }
        }

        /// <summary>
        /// Gets the multi select collection.
        /// </summary>
        /// <param name="gridView">The grid view.</param>
        /// <returns></returns>
        private static IConvertibleCollection GetMultiSelectCollection(VGridView gridView)
        {
            if (gridView.ItemsSource != null)
            {
                var multiSelectCollection = gridView.ItemsSource as IConvertibleCollection;
                Debug.Assert(multiSelectCollection != null, "The Itemssource must implement IConvertibleCollection");
                return multiSelectCollection;
            }
            return null;
        }

        /// <summary>
        /// Handles the Unloaded event of the gridView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        static void gridView_Unloaded(object sender, RoutedEventArgs e)
        {
            var gridView = sender as VGridView;
            if (gridView != null)
            {
                gridView.DataLoading -= VGridView_DataLoading;
                gridView.MouseDoubleClick -= DgOnMouseDoubleClick;
                gridView.Deleting -= DgOnDeleting;
                gridView.BeginningEdit -= DgOnBeginningEdit;
                gridView.RowEditEnded -= DgOnRowEditEnded;
                gridView.AddingNewDataItem -= DgOnAddingNewDataItem;
                gridView.RowValidating -= DgOnRowValidating;
                if (gridView.CopyOnlyFocusedCell)
                {
                    gridView.CopyingCellClipboardContent -= VGridView_CopyingCellClipboardContent;
                }
                gridView.SelectionChanged -= DsgOnSelectionChanged;
                gridView.Unloaded -= gridView_Unloaded;

                if (gridView.InitialGroupDescriptorCollection != null)
                {
                    gridView.InitialGroupDescriptorCollection.Clear();
                    gridView.InitialGroupDescriptorCollection = null;
                }
                if (gridView.IsFilteringAllowed)
                {
                    gridView.FilterOperatorsLoading -= VGridView_FilterOperatorsLoading;
                    //Cannot do -= OnVGridViewwindowSizeChanged since method is not static and cannot assign null value to a Event Handler.
                    //Cannnot make method static since static method will not work with because the property used in the method is not static.
                    if (Application.Current != null && Application.Current.MainWindow != null)
                    {
                        Application.Current.MainWindow.SizeChanged -= (obj, args) => { };
                    }
                    gridView.Loaded -= (obj, args) => { };
                }
                if (gridView.ItemsSource is IEditableCollection)
                {
                    var collection = GetEditableCollection(gridView);
                    if (collection != null)
                    {
                        collection.AddMethodAction = null; //Cannot do -= AddDataItem since method is not static. Cannot make method static since static method will not work with PendingCommands of grid.
                    }
                }
            }
        }

        /// <summary>
        /// Dgs the on row validating.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="GridViewRowValidatingEventArgs" /> instance containing the event data.</param>
        private static void DgOnRowValidating(object sender, GridViewRowValidatingEventArgs eventArguments)
        {
            if (eventArguments.EditOperationType != GridViewEditOperationType.None)
            {
                var type = eventArguments.EditOperationType;
                var gridView = (VGridView)sender;
                var editableCollection = GetEditableCollection(gridView);
                if (editableCollection != null)
                {
                    eventArguments.IsValid = editableCollection.Validate(eventArguments.Row.DataContext, eventArguments.OldValues);
                }
            }
        }

        /// <summary>
        /// Dgs the on adding new data item.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="GridViewAddingNewEventArgs" /> instance containing the event data.</param>
        private static void DgOnAddingNewDataItem(object sender, GridViewAddingNewEventArgs eventArguments)
        {
            var gridView = (VGridView)sender;
            var editableCollection = GetEditableCollection(gridView);

            var count = gridView.ChildrenOfType<GridViewRow>().Where(x => x.Visibility == Visibility.Visible).Count();

            if (editableCollection != null)
            {
                if (gridView.LimitRecordCount > 0)
                {
                    if (gridView.LimitRecordCount >= count)
                    {
                        eventArguments.NewObject = editableCollection.Create();
                    }
                    else
                    {
                        VMService.DialogService.AlertOnUI(MessageType.Failure, string.Format("Cannot add more than {0} record.", gridView.LimitRecordCount));
                        eventArguments.Cancel = true;
                    }
                }
                else
                {
                    eventArguments.NewObject = editableCollection.Create();
                    gridView.ScrollIndexIntoView(gridView.Items.Count);
                }
            }
        }

        /// <summary>
        /// Dgs the on beginning edit.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="GridViewBeginningEditRoutedEventArgs" /> instance containing the event data.</param>
        private static void DgOnBeginningEdit(object sender, GridViewBeginningEditRoutedEventArgs eventArguments)
        {
            var gridView = (VGridView)sender;
            var editableCollection = GetEditableCollection(gridView);
            if (editableCollection != null)
            {
                var item = eventArguments.Row;
                if (item != null && item.DataContext != null)
                {
                    var cancel = false;
                    editableCollection.BeginEdit(item.DataContext, ref cancel);
                    eventArguments.Cancel = cancel;
                }
            }
        }

        /// <summary>
        /// Dgs the on row edit ended.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="GridViewRowEditEndedEventArgs" /> instance containing the event data.</param>
        private static void DgOnRowEditEnded(object sender, GridViewRowEditEndedEventArgs eventArguments)
        {
            var gridView = (VGridView)sender;
            var editableCollection = GetEditableCollection(gridView);
            if (editableCollection != null)
            {
                var item = eventArguments.Row.DataContext;
                if (item != null)
                {
                    if (eventArguments.EditAction == GridViewEditAction.Commit)
                    {
                        editableCollection.Update(item);
                    }
                    else
                    {
                        editableCollection.CancelEdit(item, eventArguments.OldValues);
                    }
                    editableCollection.EndEdit(item);
                }
            }
        }

        /// <summary>
        /// Dgs the on deleting.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArguments">The <see cref="GridViewDeletingEventArgs" /> instance containing the event data.</param>
        private static void DgOnDeleting(object sender, GridViewDeletingEventArgs eventArguments)
        {
            eventArguments.Cancel = true;
            var gridView = (VGridView)sender;
            var editableCollection = GetEditableCollection(gridView);
            if (editableCollection != null)
            {
                var item = eventArguments.Items.FirstOrDefault();
                if (item != null)
                {
                    editableCollection.Delete(item);
                }
            }
        }

        /// <summary>
        /// Dgs the on mouse double click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs" /> instance containing the event data.</param>
        private static void DgOnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount > 2)
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Gets the editable collection.
        /// </summary>
        /// <param name="gridView">The grid view of type <see cref="VGridView" />.</param>
        /// <returns>
        /// Single object of type <see cref="IEditableCollection" />
        /// </returns>
        private static IEditableCollection GetEditableCollection(VGridView gridView)
        {
            if (gridView.ItemsSource != null && gridView.UsesEditableCollection)
            {
                var editableCollection = gridView.ItemsSource as IEditableCollection;
                Debug.Assert(editableCollection != null, "If UsesEditableCollection is true the Itemssource must implement IEditableCollection");
                return editableCollection;
            }
            return null;
        }

        /// <summary>
        /// Gets the reset group collection.
        /// </summary>
        /// <param name="gridView">The grid view.</param>
        /// <returns></returns>
        private static IResetGroup GetResetGroupCollection(VGridView gridView)
        {
            if (gridView.ItemsSource != null)
            {
                var collection = gridView.ItemsSource as IResetGroup;
                return collection;
            }
            return null;
        }

        /// <summary>
        /// Called when [is header selected changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnIsHeaderSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            DependencyObject cell = d;
            do
            {
                cell = VisualTreeHelper.GetParent(cell);
            } while ((cell != null) && !(cell is GridViewCell));

            if (cell is GridViewCell)
            {
                var gridCell = cell as GridViewCell;
                var gridView = gridCell.Column.Parent as Controls.VGridView;
                if ((bool)e.NewValue)
                {
                    gridView.Columns.ToList<Telerik.Windows.Controls.GridViewColumn>().ForEach(x =>
                    {
                        x.IsSelected = false;
                    });
                    gridCell.Column.IsSelected = true;
                    gridCell.IsCurrent = true;
                }
                else
                {
                    if (gridCell.IsCurrent)
                    {
                        gridCell.Column.IsSelected = false;
                    }
                }
                var commonColumnGroups = gridView.ChildrenOfType<CommonColumnHeader>();
                var gridColumnGroups = gridView.ColumnGroups;
                if (commonColumnGroups != null)
                {
                    gridColumnGroups.Where(x => !String.IsNullOrWhiteSpace(x.Name) && x.Name.Equals(gridCell.Column.ColumnGroupName)).ToList().ForEach(x =>
                    {
                        commonColumnGroups.ToList().ForEach(y =>
                        {
                            var a = y.FindChildByType<TextBlock>();
                            if (a != null && a == x.Header as TextBlock)
                            {
                                y.Tag = gridCell.Column.IsSelected;
                            }
                        });
                    });
                }
            }
        }

        /// <summary>
        /// Detaches the selection for mark selected items.
        /// </summary>
        public void DetachSelectionForMarkSelectedItems()
        {
            SelectionChanged -= DsgOnSelectionChanged;
        }

        /// <summary>
        /// Attaches the selection for mark selected items.
        /// </summary>
        public void AttachSelectionForMarkSelectedItems()
        {
            SelectionChanged += DsgOnSelectionChanged;
        }

        #endregion

        ///// <summary>
        ///// Used alongside the <see cref="CompressStyleProperty"/> property allowing the template to
        ///// be set on the style.
        ///// </summary>
        //public static readonly DependencyProperty CompressedTemplateProperty =
        //    DependencyProperty.RegisterAttached("CompressedTemplate", typeof(DataTemplate), typeof(VGridView), new PropertyMetadata(null));

        ///// <summary>
        ///// Exposes the <see cref="CompressedTemplateProperty"/> attached property.
        ///// </summary>
        ///// <param name="element">The element the property is attached to.</param>
        ///// <param name="value">The value for the attached property.</param>
        //[AttachedPropertyBrowsableForType(typeof(GridViewRow))]
        //public static void SetCompressedTemplate(UIElement element, DataTemplate value)
        //{
        //    element.SetValue(CompressedTemplateProperty, value);
        //}

        ///// <summary>
        ///// Exposes the <see cref="CompressedTemplateProperty"/> attached property. 
        ///// </summary>
        ///// <param name="element">The element to get the property value.</param>
        ///// <returns>The attached command.</returns>
        //public static DataTemplate GetCompressedTemplate(UIElement element)
        //{
        //    return (DataTemplate)element.GetValue(CompressedTemplateProperty);
        //}                        
    }
}
