﻿using GalaSoft.MvvmLight.Command;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control representing a wizard.
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.RadTabControl" />
    public class VWizardControl : RadTabControl
    {
        /// <summary>
        /// A bindable command that can be used to cancel wizard.
        /// </summary>
        public static readonly DependencyProperty CancelCommandProperty =
            DependencyProperty.Register("CancelCommand", typeof(ICommand), typeof(VWizardControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="CancelCommandProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The cancel command.
        /// </value>
        public ICommand CancelCommand
        {
            get { return (ICommand)GetValue(CancelCommandProperty); }
            set { SetValue(CancelCommandProperty, value); }
        }

        /// <summary>
        /// A bindable command that can be used to move to the next step.
        /// </summary>
        public static readonly DependencyProperty NextCommandProperty =
            DependencyProperty.Register("NextCommand", typeof(ICommand), typeof(VWizardControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="NextCommandProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The next command.
        /// </value>
        public ICommand NextCommand
        {
            get { return (ICommand)GetValue(NextCommandProperty); }
            set { SetValue(NextCommandProperty, value); }
        }

        /// <summary>
        /// A bindable command that can be used to move to the previous step.
        /// </summary>
        public static readonly DependencyProperty BackCommandProperty =
            DependencyProperty.Register("BackCommand", typeof(ICommand), typeof(VWizardControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="BackCommandProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The back command.
        /// </value>
        public ICommand BackCommand
        {
            get { return (ICommand)GetValue(BackCommandProperty); }
            set { SetValue(BackCommandProperty, value); }
        }

        /// <summary>
        /// The additional buttons property
        /// </summary>
        public static readonly DependencyProperty AdditionalButtonsProperty =
            DependencyProperty.Register("AdditionalButtons", typeof(object), typeof(VWizardControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the additional buttons.
        /// </summary>
        /// <value>
        /// The additional buttons.
        /// </value>
        public object AdditionalButtons
        {
            get { return GetValue(AdditionalButtonsProperty); }
            set { SetValue(AdditionalButtonsProperty, value); }
        }

        /// <summary>
        /// The content of the summary panel.
        /// </summary>
        public static readonly DependencyProperty SummaryContentProperty =
            DependencyProperty.Register("SummaryContent", typeof(object), typeof(VWizardControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SummaryContentProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The content of the summary.
        /// </value>
        public object SummaryContent
        {
            get { return GetValue(SummaryContentProperty); }
            set { SetValue(SummaryContentProperty, value); }
        }

        /// <summary>
        /// The datatemplate for the content panel.
        /// </summary>
        public static readonly DependencyProperty SummaryContentTemplateProperty =
            DependencyProperty.Register("SummaryContentTemplate", typeof(object), typeof(VWizardControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SummaryContentTemplateProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The summary content template.
        /// </value>
        public object SummaryContentTemplate
        {
            get { return GetValue(SummaryContentTemplateProperty); }
            set { SetValue(SummaryContentTemplateProperty, value); }
        }

        /// <summary>
        /// If the summary panel is currently open.
        /// </summary>
        public static readonly DependencyProperty IsSummaryOpenProperty =
            DependencyProperty.Register("IsSummaryOpen", typeof(bool), typeof(VWizardControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsSummaryOpenProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is summary open; otherwise, <c>false</c>.
        /// </value>
        public bool IsSummaryOpen
        {
            get { return (bool)GetValue(IsSummaryOpenProperty); }
            set { SetValue(IsSummaryOpenProperty, value); }
        }

        /// <summary>
        /// Sets the default width of the summary panel.
        /// </summary>
        public static readonly DependencyProperty SummaryWidthProperty =
            DependencyProperty.Register("SummaryWidth", typeof(double), typeof(VWizardControl), new PropertyMetadata(300d));
        /// <summary>
        /// Exposes the <see cref="SummaryWidthProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The width of the summary.
        /// </value>
        public double SummaryWidth
        {
            get { return (double)GetValue(SummaryWidthProperty); }
            set { SetValue(SummaryWidthProperty, value); }
        }

        /// <summary>
        /// If the summary panel should be visible.
        /// </summary>
        public static readonly DependencyProperty SummaryVisibilityProperty =
            DependencyProperty.Register("SummaryVisibility", typeof(Visibility), typeof(VWizardControl), new PropertyMetadata(Visibility.Collapsed));
        /// <summary>
        /// Exposes the <see cref="SummaryVisibilityProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The summary visibility.
        /// </value>
        public Visibility SummaryVisibility
        {
            get { return (Visibility)GetValue(SummaryVisibilityProperty); }
            set { SetValue(SummaryVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets the content of the button on the last step. The default is Finish.
        /// </summary>
        public static readonly DependencyProperty FinishContentProperty =
            DependencyProperty.Register("FinishContent", typeof(object), typeof(VWizardControl), new PropertyMetadata("Finish"));
        /// <summary>
        /// Exposes the <see cref="FinishContentProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The content of the finish.
        /// </value>
        public object FinishContent
        {
            get { return GetValue(FinishContentProperty); }
            set { SetValue(FinishContentProperty, value); }
        }

        /// <summary>
        /// Sets the unique Id of the wizard. Used for saving user defined size of the summary panel and preferences.
        /// </summary>
        public static readonly DependencyProperty IdProperty =
            DependencyProperty.Register("Id", typeof(string), typeof(VWizardControl), new PropertyMetadata(""));
        /// <summary>
        /// Exposes the <see cref="IdProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Id
        {
            get { return (string)GetValue(IdProperty); }
            set { SetValue(IdProperty, value); }
        }

        /// <summary>
        /// Initializes the <see cref="VWizardControl"/> class.
        /// </summary>
        static VWizardControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VWizardControl), new FrameworkPropertyMetadata(typeof(VWizardControl)));
        }

        /// <summary>
        /// The default constructor for the wizard.
        /// </summary>
        public VWizardControl()
        {
            NextCommand = new RelayCommand(Next);
            BackCommand = new RelayCommand(Back, CanBack);
            CancelCommand = new RelayCommand(Cancel);
        }

        /// <summary>
        /// Cancels this instance.
        /// </summary>
        private void Cancel()
        {
        }

        /// <summary>
        /// Determines whether this instance can back.
        /// </summary>
        /// <returns>
        ///   <c>true</c> if this instance can back; otherwise, <c>false</c>.
        /// </returns>
        private bool CanBack()
        {
            return SelectedIndex > 0;
        }

        /// <summary>
        /// Backs this instance.
        /// </summary>
        private void Back()
        {
            SelectedIndex = SelectedIndex - 1;
        }

        /// <summary>
        /// Nexts this instance.
        /// </summary>
        private void Next()
        {
            SelectedIndex = SelectedIndex + 1;
        }

        /// <summary>
        /// Updates the container status.
        /// </summary>
        /// <param name="index">The index.</param>
        private void UpdateContainerStatus(int index)
        {
            for (var x = 0; x < ItemsCount(); x++)
            {
                var currentView = ItemContainerGenerator.ContainerFromIndex(x) as VWizardItem;
                if (currentView != null)
                {
                    if (x < index)
                    {
                        currentView.Status = WizardStatus.Complete;
                    }
                    else if(x == index)
                    {
                        currentView.Status = WizardStatus.InProgress;
                    }
                    else
                    {
                        currentView.Status = WizardStatus.NotStarted;
                    }
                }
            }
        }

        /// <summary>
        /// Itemses the count.
        /// </summary>
        /// <returns></returns>
        private int ItemsCount()
        {
            if (ItemsSource != null)
            {
                return ItemsSource.OfType<object>().Count();
            }
            if (Items != null)
            {
                return Items.Count;
            }
            return 0;
        }

        /// <summary>
        /// Checks if the item is of type <see cref="VMainMenuItem" />.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns>
        ///   <c>true</c> if [is item its own container override] [the specified item]; otherwise, <c>false</c>.
        /// </returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VWizardItem;
        }

        /// <summary>
        /// Creates a new instance of <see cref="VMainMenuItem" />.
        /// </summary>
        /// <returns></returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VWizardItem();
        }

        /// <summary>
        /// Raises any command changes when the selected wizard item changes.
        /// </summary>
        /// <param name="e">The event data.</param>
        protected override void OnSelectionChanged(SelectionChangedEventArgs e)
        {
            base.OnSelectionChanged(e);
            RaiseCommandChanges();
            UpdateContainerStatus(SelectedIndex);
            var nextButton = Template.FindName("PART_NextButton", this) as Button;
            if (nextButton != null)
            {
                nextButton.Content = (SelectedIndex == ItemsCount() - 1) ? FinishContent : "Next";
            }
        }

        /// <summary>
        /// Raises the command changes.
        /// </summary>
        private void RaiseCommandChanges()
        {
            Dispatcher.Invoke(() =>
            {
                var back = BackCommand as RelayCommand;
                if (back != null)
                {
                    back.RaiseCanExecuteChanged();
                }
                var next = NextCommand as RelayCommand;
                if (next != null)
                {
                    next.RaiseCanExecuteChanged();
                }
                var cancel = CancelCommand as RelayCommand;
                if (cancel != null)
                {
                    cancel.RaiseCanExecuteChanged();
                }
            });
        }
    }
}
