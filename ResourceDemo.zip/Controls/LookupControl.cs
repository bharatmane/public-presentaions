﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using VShips.Framework.Resource.Helpers;
using GridViewColumn = Telerik.Windows.Controls.GridViewColumn;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// <para>
    /// Used as an alternative to the combobox where preloading
    /// an itemssource will be too much of a performance hit. 
    /// </para>
    /// <para>
    /// Allows both quick and advanced searching for objects. 
    /// </para>
    /// <para>
    /// Using this control allows more control over the retrieval 
    /// of the collection.
    /// </para>
    /// </summary>
    public class LookupControl : ItemsControl
    {
        #region Dependency Properties

        /// <summary>
        /// A command that is executed when the quick search button is
        /// pressed. Allowing the items to be retreived based on the 
        /// search text string.
        /// </summary>
        public static readonly DependencyProperty SearchCommandProperty =
            DependencyProperty.Register("SearchCommand", typeof(ICommand), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// Called whenever the lookup button is pressed.
        /// </summary>
        public static readonly DependencyProperty LookupCommandProperty =
            DependencyProperty.Register("LookupCommand", typeof(ICommand), typeof(LookupControl), new PropertyMetadata(null));

        ///ToDo: This is temperory Solution. Need to combine Show Details Functinality into one.
        /// <summary>
        /// The show details command property
        /// </summary>
        public static readonly DependencyProperty ShowDetailsCommandProperty =
            DependencyProperty.Register("ShowDetailsCommand", typeof(ICommand), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// The text used to retrieve the itemssource.
        /// </summary>
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(LookupControl), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnTextChaged));

        /// <summary>
        /// The error member binding property
        /// </summary>
        public static readonly DependencyProperty ErrorMemberBindingProperty =
            DependencyProperty.Register("ErrorMemberBinding", typeof(string), typeof(LookupControl), new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        /// <summary>
        /// The maximum length allowed in the text input.
        /// </summary>
        public static readonly DependencyProperty MaxLengthProperty =
            DependencyProperty.Register("MaxLength", typeof(int), typeof(LookupControl), new PropertyMetadata(0));

        /// <summary>
        /// Gets or sets a value if the search dropdown is open.
        /// </summary>
        public static readonly DependencyProperty IsDropDownOpenProperty =
            DependencyProperty.Register("IsDropDownOpen", typeof(bool), typeof(LookupControl), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnDropDownOpenChanged));

        /// <summary>
        /// Gets or sets the maximum height of the opened dropdown.
        /// </summary>
        public static readonly DependencyProperty MaxDropDownHeightProperty =
            DependencyProperty.Register("MaxDropDownHeight", typeof(double), typeof(LookupControl), new PropertyMetadata(300d));

        /// <summary>
        /// Gets or sets the selected or displayed item.
        /// </summary>
        public static readonly DependencyProperty SelectedItemProperty =
            DependencyProperty.Register("SelectedItem", typeof(object), typeof(LookupControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnSelectedItemChanged));

        /// <summary>
        /// Gets or sets a value that determines if the quick search is currently searching.
        /// This can be used when the calls to retrieve the itemssource are async.
        /// </summary>
        public static readonly DependencyProperty IsSearchingProperty =
            DependencyProperty.Register("IsSearching", typeof(bool), typeof(LookupControl), new FrameworkPropertyMetadata(false, OnIsSearchingChanged));

        /// <summary>
        /// The show column headers property
        /// </summary>
        public static readonly DependencyProperty ShowColumnHeadersProperty =
           DependencyProperty.Register("ShowColumnHeaders", typeof(bool), typeof(LookupControl), new FrameworkPropertyMetadata(true));

        /// <summary>
        /// Gets or sets a value that determines if the lookups are allowed.
        /// </summary>
        public static readonly DependencyProperty AllowLookupProperty =
            DependencyProperty.Register("AllowLookup", typeof(bool), typeof(LookupControl), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets a value that determines if the searches are allowed.
        /// </summary>
        public static readonly DependencyProperty AllowSearchProperty =
            DependencyProperty.Register("AllowSearch", typeof(bool), typeof(LookupControl), new PropertyMetadata(true));

        /// <summary>
        /// Gets or sets a flag that determines if the control is ReadOnly 
        /// and can't be changed.
        /// </summary>
        public static readonly DependencyProperty IsReadOnlyProperty =
            DependencyProperty.Register("IsReadOnly", typeof(bool), typeof(LookupControl), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets the template used to display the details popup.
        /// </summary>
        public static readonly DependencyProperty DetailsTemplateProperty =
            DependencyProperty.Register("DetailsTemplate", typeof(DataTemplate), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// The information command property
        /// </summary>
        public static readonly DependencyProperty InfoCommandProperty =
            DependencyProperty.Register("InfoCommand", typeof(ICommand), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// The information template property
        /// </summary>
        public static readonly DependencyProperty InfoTemplateProperty =
            DependencyProperty.Register("InfoTemplate", typeof(DataTemplate), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// The information command parameter property
        /// </summary>
        public static readonly DependencyProperty InfoCommandParameterProperty =
            DependencyProperty.Register("InfoCommandParameter", typeof(object), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// The information content property
        /// </summary>
        public static readonly DependencyProperty InfoContentProperty =
            DependencyProperty.Register("InfoContent", typeof(object), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets and sets the style for the lookup button.
        /// </summary>
        public static readonly DependencyProperty LookupButtonStyleProperty =
            DependencyProperty.Register("LookupButtonStyle", typeof(Style), typeof(LookupControl), new PropertyMetadata(null));

        /// <summary>
        /// Sets a minimum width for the popup containing the results of the quick search.
        /// </summary>
        public static readonly DependencyProperty MinPopupWidthProperty =
            DependencyProperty.Register("MinPopupWidth", typeof(double), typeof(LookupControl), new PropertyMetadata(200d));

        /// <summary>
        /// Sets a watermark on the lookup control.
        /// </summary>
        public static readonly DependencyProperty WatermarkProperty =
            DependencyProperty.Register("Watermark", typeof(string), typeof(LookupControl), new PropertyMetadata("Enter Keyword"));

        /// <summary>
        /// The set selected item on enter property
        /// </summary>
        public static readonly DependencyProperty SetSelectedItemOnEnterProperty =
            DependencyProperty.Register("SetSelectedItemOnEnter", typeof(bool), typeof(LookupControl), new PropertyMetadata(true));

        /// <summary>
        /// The set show details property
        /// </summary>
        public static readonly DependencyProperty SetShowDetailsProperty =
         DependencyProperty.Register("SetShowDetails", typeof(LookupShowDetailsType), typeof(LookupControl), new PropertyMetadata(LookupShowDetailsType.NoDetails));

        /// <summary>
        /// The set first item selection by default property
        /// </summary>
        public static readonly DependencyProperty SetFirstItemSelectionByDefaultProperty =
            DependencyProperty.Register("SetFirstItemSelectionByDefault ", typeof(bool), typeof(LookupControl), new PropertyMetadata(false, OnSetFirstItemSelectionByDefaultChanged));

        #endregion

        #region private Properties

        /// <summary>
        /// The text update
        /// </summary>
        private string _textUpdate;

        /// <summary>
        /// The mouse clicked
        /// </summary>
        private bool _mouseClicked = false;

        #endregion

        #region Properties

        /// <summary>
        /// Exposes the <see cref="SearchCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="LookupCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand LookupCommand
        {
            get { return (ICommand)GetValue(LookupCommandProperty); }
            set { SetValue(LookupCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="TextProperty"/> DependencyProperty.
        /// </summary>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// Gets or sets the error member binding.
        /// </summary>
        /// <value>
        /// The error member binding.
        /// </value>
        public string ErrorMemberBinding
        {
            get { return (string)GetValue(ErrorMemberBindingProperty); }
            set { SetValue(ErrorMemberBindingProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="MaxLengthProperty"/> DependencyProperty.
        /// </summary>
        public int MaxLength
        {
            get { return (int)GetValue(MaxLengthProperty); }
            set { SetValue(MaxLengthProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="IsDropDownOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool IsDropDownOpen
        {
            get { return (bool)GetValue(IsDropDownOpenProperty); }
            set { SetValue(IsDropDownOpenProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="MaxDropDownHeightProperty"/> DependencyProperty.
        /// </summary>
        public double MaxDropDownHeight
        {
            get { return (double)GetValue(MaxDropDownHeightProperty); }
            set { SetValue(MaxDropDownHeightProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="SelectedItemProperty"/> DependencyProperty.
        /// </summary>
        public object SelectedItem
        {
            get { return GetValue(SelectedItemProperty); }
            set { SetValue(SelectedItemProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="IsSearchingProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSearching
        {
            get { return (bool)GetValue(IsSearchingProperty); }
            set { SetValue(IsSearchingProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="IsSearchingProperty"/> DependencyProperty.
        /// </summary>
        public bool ShowColumnHeaders
        {
            get { return (bool)GetValue(ShowColumnHeadersProperty); }
            set { SetValue(ShowColumnHeadersProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="IsReadOnlyProperty"/> DependencyProperty.
        /// </summary>
        public bool IsReadOnly
        {
            get { return (bool)GetValue(IsReadOnlyProperty); }
            set { SetValue(IsReadOnlyProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="AllowLookupProperty"/> DependencyProperty.
        /// </summary>
        public bool AllowLookup
        {
            get { return (bool)GetValue(AllowLookupProperty); }
            set { SetValue(AllowLookupProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="AllowSearchProperty"/> DependencyProperty.
        /// </summary>
        public bool AllowSearch
        {
            get { return (bool)GetValue(AllowSearchProperty); }
            set { SetValue(AllowSearchProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="DetailsTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate DetailsTemplate
        {
            get { return (DataTemplate)GetValue(DetailsTemplateProperty); }
            set { SetValue(DetailsTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the information template.
        /// </summary>
        /// <value>
        /// The information template.
        /// </value>
        public DataTemplate InfoTemplate
        {
            get { return (DataTemplate)GetValue(InfoTemplateProperty); }
            set { SetValue(InfoTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the information command.
        /// </summary>
        /// <value>
        /// The information command.
        /// </value>
        public ICommand InfoCommand
        {
            get { return (ICommand)GetValue(InfoCommandProperty); }
            set { SetValue(InfoCommandProperty, value); }
        }

        /// <summary>
        /// Gets or sets the information command parameter.
        /// </summary>
        /// <value>
        /// The information command parameter.
        /// </value>
        public object InfoCommandParameter
        {
            get { return (object)GetValue(InfoCommandParameterProperty); }
            set { SetValue(InfoCommandParameterProperty, value); }
        }

        /// <summary>
        /// Gets or sets the content of the information.
        /// </summary>
        /// <value>
        /// The content of the information.
        /// </value>
        public object InfoContent
        {
            get { return (object)GetValue(InfoContentProperty); }
            set { SetValue(InfoContentProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="LookupButtonStyle"/> DependencyProperty.
        /// </summary>
        public Style LookupButtonStyle
        {
            get { return (Style)GetValue(LookupButtonStyleProperty); }
            set { SetValue(LookupButtonStyleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the show details command.
        /// </summary>
        /// <value>
        /// The show details command.
        /// </value>
        public ICommand ShowDetailsCommand
        {
            get { return (ICommand)GetValue(ShowDetailsCommandProperty); }
            set { SetValue(ShowDetailsCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="MinPopupWidthProperty"/> DependencyProperty.
        /// </summary>
        public double MinPopupWidth
        {
            get { return (double)GetValue(MinPopupWidthProperty); }
            set { SetValue(MinPopupWidthProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="WatermarkProperty"/> DependencyProperty.
        /// </summary>
        public string Watermark
        {
            get { return (string)GetValue(WatermarkProperty); }
            set { SetValue(WatermarkProperty, value); }
        }

        /// <summary>
        /// The columns
        /// </summary>
        private readonly ObservableCollection<GridViewColumn> _columns = new ObservableCollection<GridViewColumn>();

        /// <summary>
        /// Gets the columns used in the rad grid view.
        /// </summary>
        public ObservableCollection<GridViewColumn> Columns
        {
            get { return _columns; }
        }

        /// <summary>
        /// The text box
        /// </summary>
        private TextBox _textBox;

        /// <summary>
        /// Gets the text box.
        /// </summary>
        /// <value>
        /// The text box.
        /// </value>
        private TextBox TextBox
        {
            get { return _textBox ?? (_textBox = (TextBox)Template.FindName("PART_EditableTextBox", this)); }
        }

        /// <summary>
        /// The grid view
        /// </summary>
        private VGridView _gridView;

        /// <summary>
        /// Gets the grid view.
        /// </summary>
        /// <value>
        /// The grid view.
        /// </value>
        private VGridView GridView
        {
            get { return _gridView ?? (_gridView = Template != null ? Template.FindName("PART_RadGridView", this) as VGridView : null); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [set selected item on enter].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [set selected item on enter]; otherwise, <c>false</c>.
        /// </value>
        public bool SetSelectedItemOnEnter
        {
            get { return (bool)GetValue(SetSelectedItemOnEnterProperty); }
            set { SetValue(SetSelectedItemOnEnterProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="SetShowDetailsProperty"/> DependencyProperty.
        /// </summary>
        public LookupShowDetailsType SetShowDetails
        {
            get { return (LookupShowDetailsType)GetValue(SetShowDetailsProperty); }
            set { SetValue(SetShowDetailsProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [set first item selection by default].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [set first item selection by default]; otherwise, <c>false</c>.
        /// </value>
        public bool SetFirstItemSelectionByDefault
        {
            get { return (bool)GetValue(SetFirstItemSelectionByDefaultProperty); }
            set { SetValue(SetFirstItemSelectionByDefaultProperty, value); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initializes the <see cref="LookupControl"/> class.
        /// </summary>
        static LookupControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(LookupControl), new FrameworkPropertyMetadata(typeof(LookupControl)));
        }

        /// <summary>
        /// Overrides the on apply template to add hooks to the search button.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            var searchButton = Template.FindName("PART_SearchButton", this) as PathButton;
            if (searchButton != null)
            {
                searchButton.Click += (sender, args) =>
                {
                    Search();
                };
            }
            var lookupButton = Template.FindName("PART_LookupButton", this) as PathButton;
            if (lookupButton != null)
            {
                lookupButton.MouseDoubleClick += (sender, args) =>
                {
                    args.Handled = true;
                };
            }
            if (TextBox != null)
            {
                TextBox.GotFocus += (sender, args) => Dispatcher.BeginInvoke(new Action(() =>
                {
                    TextBox.SelectAll();
                    UpdateWatermark();
                }));
                TextBox.LostFocus += (sender, args) => Dispatcher.BeginInvoke(new Action(() =>
                {
                    TextBox.ScrollToHome();
                    UpdateWatermark();
                }));
                TextBox.TextChanged += (sender, args) =>
                {
                    UpdateWatermark();
                };
                TextBox.AddHandler(TextInputEvent, new TextCompositionEventHandler(TextBoxOnTextInput), true);
                DataObject.AddPastingHandler(TextBox, OnPaste);
            }
            UpdateWatermark();
            UpdateGridView();
        }

        /// <summary>
        /// Updates the watermark.
        /// </summary>
        private void UpdateWatermark()
        {
            var watermark = Template.FindName("WatermarkVisualElement", this) as ContentControl;
            if (TextBox != null && watermark != null)
            {
                watermark.Visibility = string.IsNullOrWhiteSpace(TextBox.Text) && !TextBox.IsFocused
                        ? Visibility.Visible
                        : Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Called when [paste].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DataObjectPastingEventArgs"/> instance containing the event data.</param>
        private void OnPaste(object sender, DataObjectPastingEventArgs e)
        {
            //ToDo:Pi - Need to improve Paste logic.
            string searchText = "";
            if (e.DataObject.GetDataPresent(typeof(string)))
            {
                searchText = e.DataObject.GetData(typeof(string)) as string;
                Text = null;
                //This is done for checking whether the pasted value contains any restricted character.
                //If the pasted text contains any restricted character the search will not happen.
                searchText = (!ControlHelper.GetAllowSpecialCharacters(this)
                            && !Regex.IsMatch(searchText, Constants.RestrictSpecialCharacterRegularExpression)) || ControlHelper.GetAllowSpecialCharacters(this) || string.IsNullOrWhiteSpace(Constants.RestrictSpecialCharacterRegularExpression) ?
                            searchText : "";
                Search(searchText);
            }
        }

        /// <summary>
        /// Updates the grid view.
        /// </summary>
        private void UpdateGridView()
        {
            var gridView = GridView;
            if (gridView != null)
            {
                gridView.Columns.Clear();
                gridView.ShowColumnHeaders = ShowColumnHeaders;
                if (Columns.Any())
                {
                    gridView.Columns.AddRange(Columns);
                }
                else
                {
                    gridView.Columns.Add(new GridViewDataColumn
                    {
                        Header = "Name",
                        DataMemberBinding = new Binding(DisplayMemberPath),
                        Width = new GridViewLength(1, GridViewLengthUnitType.Star),
                        IsReadOnly = true,
                    });
                }

                //Workaround for a problem that is clearing the gridview selection.
                gridView.SelectionChanged += (sender, args) =>
                {
                    if (IsDropDownOpen && (!SetSelectedItemOnEnter || _mouseClicked))
                    {
                        SelectedItem = gridView.SelectedItem;
                        _mouseClicked = false;
                    }
                };

                gridView.DataLoaded += (sender, args) =>
                {
                    SelectFirstItemByDefault();
                };
            }
        }

        /// <summary>
        /// Texts the box on text input.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs"/> instance containing the event data.</param>
        private void TextBoxOnTextInput(object sender, TextCompositionEventArgs e)
        {
            if (e != null && e.Text != null && e.Text != "\u001b")
            {
                Search();
            }
        }

        /// <summary>
        /// Overrides on preview key up in order to manage the dropdown and selections.
        /// </summary>
        /// <param name="e">The keyboard event arguments.</param>
        protected override void OnPreviewKeyUp(KeyEventArgs e)
        {
            base.OnPreviewKeyUp(e);
            if (e.Key == Key.Delete || e.Key == Key.Back || e.Key == Key.Space)
            {
                Search();
            }
        }

        /// <summary>
        /// Overrides on preview key down in order to manage the dropdown and selections.
        /// </summary>
        /// <param name="e">The keyboard event arguments.</param>
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (AllowSearch && !IsReadOnly)
            {
                switch (e.Key)
                {
                    case Key.Down:
                        if (GridView != null && SetSelectedItemOnEnter)
                        {
                            GridView.SelectedItem = GetGridViewNextItem();
                            if (GridView.SelectedItem != null)
                            {
                                GridView.ScrollIntoView(GridView.SelectedItem);
                            }
                            e.Handled = true;
                            break;
                        }
                        SelectedItem = GetNextItem();
                        e.Handled = true;
                        break;
                    case Key.Up:
                        if (GridView != null && SetSelectedItemOnEnter)
                        {
                            GridView.SelectedItem = GetGridViewPreviousItem();
                            if (GridView.SelectedItem != null)
                            {
                                GridView.ScrollIntoView(GridView.SelectedItem);
                            }
                            e.Handled = true;
                            break;
                        }
                        SelectedItem = GetPreviousItem();
                        e.Handled = true;
                        break;
                    case Key.Enter:
                        if (GridView != null && SetSelectedItemOnEnter)
                        {
                            if (IsDropDownOpen)
                            {
                                SelectedItem = GridView.SelectedItem;
                                CloseDropDown();
                                e.Handled = true;
                            }
                            break;
                        }
                        if (IsDropDownOpen)
                        {
                            CloseDropDown();
                            e.Handled = true;
                        }
                        break;
                    case Key.Escape:
                    case Key.Tab:
                        if (IsDropDownOpen)
                        {
                            CloseDropDown();
                            e.Handled = true;
                        }
                        break;
                }
            }
        }

        /// <summary>
        /// Gets the grid view previous item.
        /// </summary>
        /// <returns>Single object.</returns>
        private object GetGridViewPreviousItem()
        {
            object previousItem = null;

            if (ItemsSource != null)
            {
                var items = ItemsSource.OfType<object>().ToList();
                if (GridView != null && GridView.SelectedItem != null && items.Contains(GridView.SelectedItem))
                {
                    var index = items.IndexOf(GridView.SelectedItem);
                    var nextIndex = index - 1;
                    previousItem = nextIndex >= 0 ? items[nextIndex] : GridView.SelectedItem;
                }
                else
                {
                    previousItem = items.FirstOrDefault();
                }
            }
            return previousItem;
        }

        /// <summary>
        /// Gets the next item.
        /// </summary>
        /// <returns>Single object</returns>
        private object GetGridViewNextItem()
        {
            object nextItem = null;

            if (ItemsSource != null)
            {
                var items = ItemsSource.OfType<object>().ToList();
                if (GridView != null && GridView.SelectedItem != null && items.Contains(GridView.SelectedItem))
                {
                    var index = items.IndexOf(GridView.SelectedItem);
                    var nextIndex = index + 1;
                    nextItem = nextIndex < items.Count ? items[nextIndex] : GridView.SelectedItem;
                }
                else
                {
                    nextItem = items.FirstOrDefault();
                }
            }
            return nextItem;
        }

        /// <summary>
        /// Closes the drop down.
        /// </summary>
        private void CloseDropDown()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                IsDropDownOpen = false;
            }), DispatcherPriority.Render);
        }

        /// <summary>
        /// Opens the drop down.
        /// </summary>
        private void OpenDropDown()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                IsDropDownOpen = true;
            }), DispatcherPriority.Render);
        }


        /// <summary>
        /// Overrides the mouse down to close the drop down.
        /// </summary>
        /// <param name="e">The mouse events.</param>
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            if (IsDropDownOpen && AllowSearch)
            {
                var item = UIHelper.FindVisualParent<GridViewRow>((DependencyObject)e.OriginalSource, this);

                if (item != null)
                {
                    if (item.IsSelected)
                    {
                        if (IsDropDownOpen && GridView != null)
                        {
                            SelectedItem = GridView.SelectedItem;
                        }
                    }
                    else
                    {
                        _mouseClicked = true;
                    }

                    item.IsSelected = true;
                    CloseDropDown();
                }
            }
            base.OnPreviewMouseDown(e);
        }

        /// <summary>
        /// Makes sure the textbox is focused on focus. 
        /// </summary>
        /// <param name="e">The RoutedEventArgs.</param>
        protected override void OnGotFocus(RoutedEventArgs e)
        {
            base.OnGotFocus(e);
            FocusTextBox();
        }

        /// <summary>
        /// Gets the previous item.
        /// </summary>
        /// <returns>Single object</returns>
        private object GetPreviousItem()
        {
            object nextItem = null;

            if (ItemsSource != null)
            {
                var items = ItemsSource.OfType<object>().ToList();
                if (SelectedItem != null && items.Contains(SelectedItem))
                {
                    var index = items.IndexOf(SelectedItem);
                    var nextIndex = index - 1;
                    nextItem = nextIndex >= 0 ? items[nextIndex] : SelectedItem;
                }
                else
                {
                    nextItem = items.FirstOrDefault();
                }
            }

            return nextItem;
        }

        /// <summary>
        /// Gets the next item.
        /// </summary>
        /// <returns>Single object</returns>
        private object GetNextItem()
        {
            object nextItem = null;

            if (ItemsSource != null)
            {
                var items = ItemsSource.OfType<object>().ToList();
                if (SelectedItem != null && items.Contains(SelectedItem))
                {
                    var index = items.IndexOf(SelectedItem);
                    var nextIndex = index + 1;
                    nextItem = nextIndex < items.Count ? items[nextIndex] : SelectedItem;
                }
                else
                {
                    nextItem = items.FirstOrDefault();
                }
            }

            return nextItem;
        }

        /// <summary>
        /// Called when [is searching changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsSearchingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (LookupControl)d;
            control.OnIsSearchingChanged();
        }

        /// <summary>
        /// Called whenever is searching changes.
        /// </summary>
        protected virtual void OnIsSearchingChanged()
        {
        }

        /// <summary>
        /// Called when [drop down open changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnDropDownOpenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (LookupControl)d;
            control.OnDropDownOpenChanged();
        }

        /// <summary>
        /// Called whenever the dropdown opens or closes.
        /// </summary>
        protected virtual void OnDropDownOpenChanged()
        {
            if (!IsDropDownOpen)
            {
                FocusTextBox();
            }
        }

        /// <summary>
        /// Focuses the text box.
        /// </summary>
        private void FocusTextBox()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                TextBox.Focus();
                Keyboard.Focus(TextBox);
                TextBox.SelectAll();
            }), DispatcherPriority.Input);
        }

        /// <summary>
        /// Called when [text chaged].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnTextChaged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (LookupControl)d;
            control.OnTextChaged();
        }

        /// <summary>
        /// Called when [text chaged].
        /// </summary>
        private void OnTextChaged()
        {
            var selectedText = GetSelectedText();
            if (!Equals(selectedText, Text))
            {
                if (SelectedItem != null)
                {
                    _textUpdate = Text;
                    SelectedItem = null;
                }
            }
        }

        /// <summary>
        /// Called when [selected item changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSelectedItemChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (LookupControl)d;
            control.OnSelectedItemChanged();
        }

        /// <summary>
        /// Called whenever the <see cref="SelectedItem" /> changes.
        /// </summary>
        protected virtual void OnSelectedItemChanged()
        {
            Text = GetSelectedText();
            if (SelectedItem != null && IsDropDownOpen)
            {
                var gridView = GridView;
                if (gridView != null)
                {
                    gridView.SelectedItem = SelectedItem;
                    gridView.ScrollIntoView(SelectedItem);
                    var item = gridView.ItemContainerGenerator.ContainerFromItem(SelectedItem) as GridViewRow;
                    if (item != null)
                    {
                        item.BringIntoView();
                    }
                    CloseDropDown();
                }
            }
            if (!String.IsNullOrWhiteSpace(_textUpdate))
            {
                Text = _textUpdate;
                _textUpdate = String.Empty;
            }
            else
            {
                if (IsDropDownOpen)
                {
                    FocusTextBox();
                }
            }
        }

        /// <summary>
        /// Searches this instance.
        /// </summary>
        /// <param name="searchText">The search text.</param>
        private void Search(string searchText = "")
        {
            if (string.IsNullOrWhiteSpace(searchText))
            {
                searchText = Text;
            }
            if (!IsReadOnly)
            {
                if (string.IsNullOrWhiteSpace(searchText))
                {
                    CloseDropDown();
                }
                else
                {
                    OpenDropDown();
                }
                if (SearchCommand != null && SearchCommand.CanExecute(searchText))
                {
                    SearchCommand.Execute(searchText);
                }
            }
        }

        /// <summary>
        /// Gets the selected text.
        /// </summary>
        /// <returns>Single string value</returns>
        private string GetSelectedText()
        {
            if (SelectedItem != null)
            {
                var value = GetPropValue(SelectedItem, DisplayMemberPath);
                if (value != null)
                {
                    return value.ToString();
                }
            }
            return "";
        }

        /// <summary>
        /// Gets the property value.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="name">The name.</param>
        /// <returns>Single Object</returns>
        private static Object GetPropValue(Object obj, String name)
        {
            foreach (var part in name.Split('.'))
            {
                if (obj == null)
                {
                    return null;
                }

                var type = obj.GetType();
                var info = type.GetProperty(part);

                if (info == null)
                {
                    return null;
                }

                obj = info.GetValue(obj, null);
            }
            return obj;
        }

        /// <summary>
        /// Selects the first item by default.
        /// </summary>
        private void SelectFirstItemByDefault()
        {
            if (GridView != null && SetSelectedItemOnEnter && SetFirstItemSelectionByDefault)
            {
                GridView.SelectedItem = GetGridViewNextItem();
                if (GridView.SelectedItem != null)
                {
                    GridView.ScrollIntoView(GridView.SelectedItem);
                }
            }
        }

        /// <summary>
        /// Called when [set first item selection by default changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSetFirstItemSelectionByDefaultChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            LookupControl control = d as LookupControl;
            if (control != null)
            {
                control.SelectFirstItemByDefault();
            }
        }

        #endregion
    }
}