﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control to display a clock.
    /// </summary>
    public class ClockControl : Control
    {
        /// <summary>
        /// The date and time of the clock.
        /// </summary>
        public static readonly DependencyProperty DateTimeProperty = 
            DependencyProperty.Register("DateTime", typeof(DateTime), typeof(ClockControl), new FrameworkPropertyMetadata(DateTime.MinValue));
        /// <summary>
        /// Exposes the <see cref="DateTimeProperty"/> DependencyProperty.
        /// </summary>
        public DateTime DateTime
        {
            get { return (DateTime)GetValue(DateTimeProperty); }
            set { SetValue(DateTimeProperty, value); }
        }

        /// <summary>
        /// The location of the clock.
        /// </summary>
        public static readonly DependencyProperty LocationProperty =
            DependencyProperty.Register("Location", typeof(string), typeof(ClockControl), new PropertyMetadata(""));
        /// <summary>
        /// Exposes the <see cref="LocationProperty"/> DependencyProperty.
        /// </summary>
        public string Location
        {
            get { return (string)GetValue(LocationProperty); }
            set { SetValue(LocationProperty, value); }
        }

        /// <summary>
        /// True if the clock is retreiving the time.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(ClockControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsBusyProperty"/> DependencyProperty.
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }
        
        static ClockControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ClockControl), new FrameworkPropertyMetadata(typeof(ClockControl)));
        }
        
    }
}
