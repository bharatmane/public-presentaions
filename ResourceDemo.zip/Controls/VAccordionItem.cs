﻿using GalaSoft.MvvmLight;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An item in the <see cref="VAccordion"/> control.
    /// </summary>
    public class VAccordionItem : HeaderedContentControl
    {
        /// <summary>
        /// The _previous content
        /// </summary>
        private object _previousContent;

        /// <summary>
        /// If the item is expanded.
        /// </summary>
        public static readonly DependencyProperty IsExpandedProperty =
            DependencyProperty.Register("IsExpanded", typeof(bool), typeof(VAccordionItem), new PropertyMetadata(false, OnIsExpandedChanged));
        /// <summary>
        /// Exposes the <see cref="IsExpandedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsExpanded
        {
            get { return (bool)GetValue(IsExpandedProperty); }
            set { SetValue(IsExpandedProperty, value); }
        }

        /// <summary>
        /// If the panel is in a selection state where the <see cref="SelectedContentProperty"/> has a value and the <see cref="IsExpandedProperty"/> is false.
        /// </summary>
        public static readonly DependencyProperty IsSelectedExpandedProperty =
            DependencyProperty.Register("IsSelectedExpanded", typeof(bool), typeof(VAccordionItem), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsSelectedExpandedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSelectedExpanded
        {
            get { return (bool)GetValue(IsSelectedExpandedProperty); }
            set { SetValue(IsSelectedExpandedProperty, value); }
        }

        /// <summary>
        /// The content to display when selection occurs.
        /// </summary>
        public static readonly DependencyProperty SelectedContentProperty =
            DependencyProperty.Register("SelectedContent", typeof(object), typeof(VAccordionItem), new PropertyMetadata(null, OnSelectedContentChanged));
        /// <summary>
        /// Exposes the <see cref="SelectedContentProperty"/> DependencyProperty.
        /// </summary>
        public object SelectedContent
        {
            get { return GetValue(SelectedContentProperty); }
            set { SetValue(SelectedContentProperty, value); }
        }

        /// <summary>
        /// The template to display when selection occurs.
        /// </summary>
        public static readonly DependencyProperty SelectedTemplateProperty =
            DependencyProperty.Register("SelectedTemplate", typeof(DataTemplate), typeof(VAccordionItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SelectedTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate SelectedTemplate
        {
            get { return (DataTemplate)GetValue(SelectedTemplateProperty); }
            set { SetValue(SelectedTemplateProperty, value); }
        }

        /// <summary>
        /// Initializes the <see cref="VAccordionItem"/> class.
        /// </summary>
        static VAccordionItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VAccordionItem), new FrameworkPropertyMetadata(typeof(VAccordionItem)));
        }

        /// <summary>
        /// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
        /// </summary>
        public override void OnApplyTemplate()
        {
            var button = Template.FindName("PART_EditButton", this) as Button;
            if (button != null)
            {
                button.Click += (sender, args) =>
                {
                    IsExpanded = true;
                };
            }
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Called when [selected content changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSelectedContentChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VAccordionItem)d;
            control.OnSelectedContentChanged();
        }

        /// <summary>
        /// Called when [selected content changed].
        /// </summary>
        private void OnSelectedContentChanged()
        {
            if (SelectedContent != null)
            {
                _previousContent = SelectedContent;
                IsExpanded = false;
                var parent = UIHelper.FindVisualParent<VAccordion>(this);
                if (parent != null)
                {
                    parent.MoveNext(this);
                }
            }
            UpdateSelectedExpanded();
        }

        /// <summary>
        /// Called when [is expanded changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsExpandedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VAccordionItem)d;
            control.OnIsExpandedChanged();
        }

        /// <summary>
        /// Called when [is expanded changed].
        /// </summary>
        private void OnIsExpandedChanged()
        {
            var parent = UIHelper.FindVisualParent<VAccordion>(this);
            if (parent != null)
            {
                parent.OnItemExpandedChanged(this);
            }
            if (IsExpanded)
            {
                var cleanupItem = SelectedContent as ICleanup;
                if (cleanupItem != null)
                {
                    cleanupItem.Cleanup();
                }
                SelectedContent = null;
            }
            else
            {
                if (SelectedContent == null && _previousContent != null)
                {
                    SelectedContent = _previousContent;
                }
            }
            UpdateSelectedExpanded();
            VAccordionPanel.SetIsItemExpanded(this, IsExpanded);
        }

        /// <summary>
        /// Updates the selected expanded.
        /// </summary>
        private void UpdateSelectedExpanded()
        {
            IsSelectedExpanded = !IsExpanded && SelectedContent != null;

        }
    }
}
