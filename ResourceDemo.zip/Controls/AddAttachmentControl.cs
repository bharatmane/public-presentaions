﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Add attachment control
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ContentControl" />
    public class AddAttachmentControl : ContentControl
    {
        #region Command

        /// <summary>
        /// The add attachment command property
        /// </summary>
        public static readonly DependencyProperty AddAttachmentCommandProperty =
            DependencyProperty.Register("AddAttachmentCommand", typeof(ICommand), typeof(AddAttachmentControl), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the add attachment command.
        /// </summary>
        /// <value>
        /// The add attachment command.
        /// </value>
        public ICommand AddAttachmentCommand
        {
            get { return (ICommand)GetValue(AddAttachmentCommandProperty); }
            set { SetValue(AddAttachmentCommandProperty, value); }
        }

        /// <summary>
        /// Gets or sets the save command.
        /// </summary>
        /// <value>
        /// The save command.
        /// </value>
        public ICommand SaveCommand
        {
            get { return (ICommand)GetValue(SaveCommandProperty); }
            set { SetValue(SaveCommandProperty, value); }
        }

        /// <summary>
        /// The save command property
        /// </summary>
        public static readonly DependencyProperty SaveCommandProperty =
            DependencyProperty.Register("SaveCommand", typeof(ICommand), typeof(AddAttachmentControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the cancel command.
        /// </summary>
        /// <value>
        /// The cancel command.
        /// </value>
        public ICommand CancelCommand
        {
            get { return (ICommand)GetValue(CancelCommandProperty); }
            set { SetValue(CancelCommandProperty, value); }
        }

        /// <summary>
        /// The cancel command property
        /// </summary>
        public static readonly DependencyProperty CancelCommandProperty =
            DependencyProperty.Register("CancelCommand", typeof(ICommand), typeof(AddAttachmentControl), new PropertyMetadata(null));

        #endregion

        #region properties

        /// <summary>
        /// The document list property
        /// </summary>
        public static readonly DependencyProperty DocumentListProperty =
            DependencyProperty.Register("DocumentList", typeof(IEnumerable<IDocumentUpload>), typeof(AddAttachmentControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        /// <summary>
        /// Gets or sets the document list.
        /// </summary>
        /// <value>
        /// The document list.
        /// </value>
        public IEnumerable<IDocumentUpload> DocumentList
        {
            get { return (IEnumerable<IDocumentUpload>)GetValue(DocumentListProperty); }
            set { SetValue(DocumentListProperty, value); }
        }

        /// <summary>
        /// The selected item property
        /// </summary>
        public static readonly DependencyProperty SelectedItemProperty =
            DependencyProperty.Register("SelectedItem", typeof(IDocumentUpload), typeof(AddAttachmentControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public IDocumentUpload SelectedItem
        {
            get { return (IDocumentUpload)GetValue(SelectedItemProperty); }
            set { SetValue(SelectedItemProperty, value); }
        }

        /// <summary>
        /// The is add mode document property
        /// </summary>
        public static readonly DependencyProperty IsAddModeProperty =
            DependencyProperty.Register("IsAddMode", typeof(bool), typeof(AddAttachmentControl), new FrameworkPropertyMetadata(false));


        /// <summary>
        /// Gets or sets a value indicating whether this instance is in add mode document.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is add document; otherwise, <c>false</c>.
        /// </value>
        public bool IsAddMode
        {
            get { return (bool)GetValue(IsAddModeProperty); }
            set { SetValue(IsAddModeProperty, value); }
        }

        /// <summary>
        /// The is busy mode property
        /// </summary>
        public static readonly DependencyProperty IsBusyModeProperty =
            DependencyProperty.Register("IsBusyMode", typeof(bool), typeof(AddAttachmentControl), new FrameworkPropertyMetadata(false));

        /// <summary>
        /// Gets or sets a value indicating whether this instance is busy mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is busy mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsBusyMode
        {
            get { return (bool)GetValue(IsBusyModeProperty); }
            set { SetValue(IsBusyModeProperty, value); }
        }

        /// <summary>
        /// The details template property
        /// </summary>
        public static readonly DependencyProperty DetailsTemplateProperty =
            DependencyProperty.Register("DetailsTemplate", typeof(DataTemplate), typeof(AddAttachmentControl), new FrameworkPropertyMetadata(null));


        /// <summary>
        /// Gets or sets the details template.
        /// </summary>
        /// <value>
        /// The details template.
        /// </value>
        public DataTemplate DetailsTemplate
        {
            get { return (DataTemplate)GetValue(DetailsTemplateProperty); }
            set { SetValue(DetailsTemplateProperty, value); }
        }

        /// <summary>
        /// The save button label property
        /// </summary>
        public static readonly DependencyProperty SaveButtonLabelProperty =
            DependencyProperty.Register("SaveButtonLabel", typeof(string), typeof(AddAttachmentControl), new FrameworkPropertyMetadata(null));

        /// <summary>
        /// Gets or sets the save button label.
        /// </summary>
        /// <value>
        /// The save button label.
        /// </value>
        public string SaveButtonLabel
        {
            get { return (string)GetValue(SaveButtonLabelProperty); }
            set { SetValue(SaveButtonLabelProperty, value); }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes the <see cref="AddAttachmentControl"/> class.
        /// </summary>
        static AddAttachmentControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AddAttachmentControl), new FrameworkPropertyMetadata(typeof(AddAttachmentControl)));
        }

        #endregion
    }
}
