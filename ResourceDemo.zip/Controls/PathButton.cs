﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control for displaying a path within a button.
    /// </summary>
    /// <example>
    /// The following example will display a path with a plus symbol with the text Add New Line on the left.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[<controls:PathButton Data="{StaticResource PlusGeometry}" Content="Add New Line" DockPanel.Dock="Right" />]]>
    /// </code>
    /// </example>
    public class PathButton : Button
    {
        /// <summary>
        /// The geometry data of the path
        /// </summary>
        public static readonly DependencyProperty DataProperty = 
            DependencyProperty.Register("Data", typeof(Geometry), typeof(PathButton), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="DataProperty"/> DependencyProperty.
        /// </summary>
        public Geometry Data
        {
            get { return (Geometry)GetValue(DataProperty); }
            set { SetValue(DataProperty, value); }
        }

        /// <summary>
        /// The count property
        /// </summary>
        public static readonly DependencyProperty CountProperty =
            DependencyProperty.Register("Count", typeof(int), typeof(PathButton), new PropertyMetadata(0));

        /// <summary>
        /// Gets or sets the count.
        /// </summary>
        /// <value>
        /// The count.
        /// </value>
        public int Count
        {
            get { return (int)GetValue(CountProperty); }
            set { SetValue(CountProperty, value); }
        }


        /// <summary>
        /// The show count property
        /// </summary>
        public static readonly DependencyProperty ShowCountProperty =
            DependencyProperty.Register("ShowCount", typeof(bool), typeof(PathButton), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets a value indicating whether [show count].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show count]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowCount
        {
            get { return (bool)GetValue(ShowCountProperty); }
            set { SetValue(ShowCountProperty, value); }
        }

        /// <summary>
        /// If set to true an ellipse will surrond the displayed path. The default value is true.
        /// </summary>
        public static readonly DependencyProperty ShowEllipseProperty = 
            DependencyProperty.Register("ShowEllipse", typeof(bool), typeof(PathButton), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="ShowEllipseProperty"/> DependencyProperty.
        /// </summary>
        public bool ShowEllipse
        {
            get { return (bool)GetValue(ShowEllipseProperty); }
            set { SetValue(ShowEllipseProperty, value); }
        }

        /// <summary>
        /// The thickness applied to the ellipse.
        /// </summary>
        public static readonly DependencyProperty EllipseStrokeThicknessProperty = 
            DependencyProperty.Register("EllipseStrokeThickness", typeof(double), typeof(PathButton), new PropertyMetadata(1d));
        /// <summary>
        /// Exposes the <see cref="EllipseStrokeThickness"/> DependencyProperty.
        /// </summary>
        public double EllipseStrokeThickness
        {
            get { return (double)GetValue(EllipseStrokeThicknessProperty); }
            set { SetValue(EllipseStrokeThicknessProperty, value); }
        }

        /// <summary>
        /// The Brush used in the fill of the path.
        /// </summary>
        public static readonly DependencyProperty PathBrushProperty = 
            DependencyProperty.Register("PathBrush", typeof(Brush), typeof(PathButton), new PropertyMetadata(Brushes.White));
        /// <summary>
        /// Exposes the <see cref="PathBrushProperty"/> DependencyProperty.
        /// </summary>
        public Brush PathBrush
        {
            get { return (Brush)GetValue(PathBrushProperty); }
            set { SetValue(PathBrushProperty, value); }
        }

        /// <summary>
        /// The thickness applied to the paths stroke. The deafult is 0.
        /// </summary>
        public static readonly DependencyProperty PathStrokeThicknessProperty = 
            DependencyProperty.Register("PathStrokeThickness", typeof(double), typeof(PathButton), new PropertyMetadata(0d));
        /// <summary>
        /// Exposes the <see cref="PathStrokeThicknessProperty"/> DependencyProperty.
        /// </summary>
        public double PathStrokeThickness
        {
            get { return (double)GetValue(PathStrokeThicknessProperty); }
            set { SetValue(PathStrokeThicknessProperty, value); }
        }

        /// <summary>
        /// The margin of the content. The default value is a thickness with values 0,0,4,0.
        /// </summary>
        public static readonly DependencyProperty ContentMarginProperty = 
            DependencyProperty.Register("ContentMargin", typeof(Thickness), typeof(PathButton), new PropertyMetadata(new Thickness(0,0,4,0)));
        /// <summary>
        /// Exposes the <see cref="ContentMarginProperty"/> DependencyProperty.
        /// </summary>
        public Thickness ContentMargin
        {
            get { return (Thickness)GetValue(ContentMarginProperty); }
            set { SetValue(ContentMarginProperty, value); }
        }

        /// <summary>
        /// The Dock location of the content. The default value is <see cref="Dock.Left"/>
        /// </summary>
        public static readonly DependencyProperty ContentLocationProperty =
            DependencyProperty.Register("ContentLocation", typeof(Dock), typeof(PathButton), new PropertyMetadata(Dock.Left));
        /// <summary>
        /// Exposes the <see cref="ContentLocationProperty"/> DependencyProperty.
        /// </summary>
        public Dock ContentLocation
        {
            get { return (Dock)GetValue(ContentLocationProperty); }
            set { SetValue(ContentLocationProperty, value); }
        }

        /// <summary>
        /// If the content should be displayed or not. The default value is <see cref="Visibility.Visible"/>
        /// </summary>
        public static readonly DependencyProperty ContentVisibilityProperty =
            DependencyProperty.Register("ContentVisibility", typeof(Visibility), typeof(PathButton), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="ContentVisibilityProperty"/> DependencyProperty. 
        /// </summary>
        public Visibility ContentVisibility
        {
            get { return (Visibility)GetValue(ContentVisibilityProperty); }
            set { SetValue(ContentVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets or sets the stretch applied to the icon.
        /// </summary>
        public static readonly DependencyProperty IconStretchProperty = 
            DependencyProperty.Register("IconStretch", typeof(Stretch), typeof(PathButton), new PropertyMetadata(Stretch.Uniform));
        /// <summary>
        /// Exposes the <see cref="IconStretchProperty"/> DependencyProperty. 
        /// </summary>
        public Stretch IconStretch
        {
            get { return (Stretch)GetValue(IconStretchProperty); }
            set { SetValue(IconStretchProperty, value); }
        }

        /// <summary>
        /// Gets or sets the size of the ellipse.
        /// </summary>
        public static readonly DependencyProperty EllipseSizeProperty = 
            DependencyProperty.Register("EllipseSize", typeof(double), typeof(PathButton), new PropertyMetadata(18d));
        /// <summary>
        /// Exposes the <see cref="EllipseSizeProperty"/> DependencyProperty.  
        /// </summary>
        public double EllipseSize
        {
            get { return (double)GetValue(EllipseSizeProperty); }
            set { SetValue(EllipseSizeProperty, value); }
        }

        static PathButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PathButton), new FrameworkPropertyMetadata(typeof(PathButton)));
        }

    }

    
}
