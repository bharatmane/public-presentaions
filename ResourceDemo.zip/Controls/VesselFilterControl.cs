﻿using System.Windows;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control for selecting and filtering on vessels.
    /// </summary>
    public class VesselFilterControl : RadTreeView
    {
        /// <summary>
        /// Default construtor for VesselFilterControl.
        /// </summary>
        public VesselFilterControl()
        {
            IsVirtualizing = true;
        }

        static VesselFilterControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VesselFilterControl), new FrameworkPropertyMetadata(typeof(VesselFilterControl)));
        }

        /// <summary>
        /// Checks if the item is its own container
        /// </summary>
        /// <param name="item">The item of the items control</param>
        /// <returns>True if the item is of type <see cref="VesselFilterItemControl"/></returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VesselFilterItemControl;
        }

        /// <summary>
        /// Returns the correct item container.
        /// </summary>
        /// <returns>Returns a <see cref="VesselFilterItemControl"/> control.</returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VesselFilterItemControl();
        }
    }
}
