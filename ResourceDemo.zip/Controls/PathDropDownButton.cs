﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control for displaying a path within a drop down button.
    /// </summary>
    /// <example>
    /// The following example will display a path with a plus symbol with the text Add New Line on the left.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[<controls:PathDropDownButton Data="{StaticResource PlusGeometry}" Content="Add New Line" DockPanel.Dock="Right" />]]>
    /// </code>
    /// </example>
    public class PathDropDownButton : RadDropDownButton
    {
        /// <summary>
        /// The geometry data of the path
        /// </summary>
        public static readonly DependencyProperty DataProperty =
            DependencyProperty.Register("Data", typeof(Geometry), typeof(PathDropDownButton), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="DataProperty"/> DependencyProperty.
        /// </summary>
        public Geometry Data
        {
            get { return (Geometry)GetValue(DataProperty); }
            set { SetValue(DataProperty, value); }
        }

        /// <summary>
        /// If set to true an ellipse will surrond the displayed path. The default value is true.
        /// </summary>
        public static readonly DependencyProperty ShowEllipseProperty =
            DependencyProperty.Register("ShowEllipse", typeof(bool), typeof(PathDropDownButton), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="ShowEllipseProperty"/> DependencyProperty.
        /// </summary>
        public bool ShowEllipse
        {
            get { return (bool)GetValue(ShowEllipseProperty); }
            set { SetValue(ShowEllipseProperty, value); }
        }

        /// <summary>
        /// The thickness applied to the ellipse.
        /// </summary>
        public static readonly DependencyProperty EllipseStrokeThicknessProperty =
            DependencyProperty.Register("EllipseStrokeThickness", typeof(double), typeof(PathDropDownButton), new PropertyMetadata(1d));
        /// <summary>
        /// Exposes the <see cref="EllipseStrokeThickness"/> DependencyProperty.
        /// </summary>
        public double EllipseStrokeThickness
        {
            get { return (double)GetValue(EllipseStrokeThicknessProperty); }
            set { SetValue(EllipseStrokeThicknessProperty, value); }
        }

        /// <summary>
        /// The Brush used in the fill of the path.
        /// </summary>
        public static readonly DependencyProperty PathBrushProperty =
            DependencyProperty.Register("PathBrush", typeof(Brush), typeof(PathDropDownButton), new PropertyMetadata(Brushes.White));
        /// <summary>
        /// Exposes the <see cref="PathBrushProperty"/> DependencyProperty.
        /// </summary>
        public Brush PathBrush
        {
            get { return (Brush)GetValue(PathBrushProperty); }
            set { SetValue(PathBrushProperty, value); }
        }

        /// <summary>
        /// The thickness applied to the paths stroke. The deafult is 0.
        /// </summary>
        public static readonly DependencyProperty PathStrokeThicknessProperty =
            DependencyProperty.Register("PathStrokeThickness", typeof(double), typeof(PathDropDownButton), new PropertyMetadata(0d));
        /// <summary>
        /// Exposes the <see cref="PathStrokeThicknessProperty"/> DependencyProperty.
        /// </summary>
        public double PathStrokeThickness
        {
            get { return (double)GetValue(PathStrokeThicknessProperty); }
            set { SetValue(PathStrokeThicknessProperty, value); }
        }

        /// <summary>
        /// The margin of the content. The default value is a thickness with values 0,0,4,0.
        /// </summary>
        public static readonly DependencyProperty ContentMarginProperty =
            DependencyProperty.Register("ContentMargin", typeof(Thickness), typeof(PathDropDownButton), new PropertyMetadata(new Thickness(0, 0, 4, 0)));
        /// <summary>
        /// Exposes the <see cref="ContentMarginProperty"/> DependencyProperty.
        /// </summary>
        public Thickness ContentMargin
        {
            get { return (Thickness)GetValue(ContentMarginProperty); }
            set { SetValue(ContentMarginProperty, value); }
        }

        /// <summary>
        /// The Dock location of the content. The default value is <see cref="Dock.Left"/>
        /// </summary>
        public static readonly DependencyProperty ContentLocationProperty =
            DependencyProperty.Register("ContentLocation", typeof(Dock), typeof(PathDropDownButton), new PropertyMetadata(Dock.Left));
        /// <summary>
        /// Exposes the <see cref="ContentLocationProperty"/> DependencyProperty.
        /// </summary>
        public Dock ContentLocation
        {
            get { return (Dock)GetValue(ContentLocationProperty); }
            set { SetValue(ContentLocationProperty, value); }
        }

        /// <summary>
        /// If the content should be displayed or not. The default value is <see cref="Visibility.Visible"/>
        /// </summary>
        public static readonly DependencyProperty ContentVisibilityProperty =
            DependencyProperty.Register("ContentVisibility", typeof(Visibility), typeof(PathDropDownButton), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="ContentVisibilityProperty"/> DependencyProperty. 
        /// </summary>
        public Visibility ContentVisibility
        {
            get { return (Visibility)GetValue(ContentVisibilityProperty); }
            set { SetValue(ContentVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets or sets the stretch applied to the icon.
        /// </summary>
        public static readonly DependencyProperty IconStretchProperty =
            DependencyProperty.Register("IconStretch", typeof(Stretch), typeof(PathDropDownButton), new PropertyMetadata(Stretch.Uniform));
        /// <summary>
        /// Exposes the <see cref="IconStretchProperty"/> DependencyProperty. 
        /// </summary>
        public Stretch IconStretch
        {
            get { return (Stretch)GetValue(IconStretchProperty); }
            set { SetValue(IconStretchProperty, value); }
        }

        /// <summary>
        /// Gets or sets the size of the ellipse.
        /// </summary>
        public static readonly DependencyProperty EllipseSizeProperty =
            DependencyProperty.Register("EllipseSize", typeof(double), typeof(PathDropDownButton), new PropertyMetadata(18d));
        /// <summary>
        /// Exposes the <see cref="EllipseSizeProperty"/> DependencyProperty.  
        /// </summary>
        public double EllipseSize
        {
            get { return (double)GetValue(EllipseSizeProperty); }
            set { SetValue(EllipseSizeProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value that determines if the dropdown should close if its content is cliecked.
        /// </summary>
        public static readonly DependencyProperty ClosesOnClickProperty = 
            DependencyProperty.Register("ClosesOnClick", typeof(bool), typeof(PathDropDownButton), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="ClosesOnClickProperty"/> DependencyProperty. 
        /// </summary>
        public bool ClosesOnClick
        {
            get { return (bool)GetValue(ClosesOnClickProperty); }
            set { SetValue(ClosesOnClickProperty, value); }
        }

        static PathDropDownButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PathDropDownButton), new FrameworkPropertyMetadata(typeof(PathDropDownButton)));
        }

        /// <summary>
        /// Override that closes the popup if closes on click is true.
        /// </summary>
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);
            if (IsOpen && ClosesOnClick)
            {
                if (e.OriginalSource != null && 
                    !((e.OriginalSource is RadDropDownButton) || (e.OriginalSource is ToggleButton) || (e.OriginalSource is CheckBox)))
                {
                    IsOpen = false;
                }
            }
        }

    }
}
