﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A way to set a content inside path.
    /// </summary>
    /// <seealso cref="System.Windows.Controls.Control" />
    public class PathContentControl : Control
    {
        #region Dependency Properties
        
        /// <summary>
        /// The path content to be displayed inside Path.
        /// </summary>
        public static readonly DependencyProperty PathContentProperty =
            DependencyProperty.Register("PathContent", typeof(object), typeof(PathContentControl), new PropertyMetadata(""));

        /// <summary>
        /// Gets or sets the content of the path.
        /// </summary>
        /// <value>
        /// The content of the path.
        /// </value>
        public object PathContent
        {
            get { return (object)GetValue(PathContentProperty); }
            set { SetValue(PathContentProperty, value); }
        }

        /// <summary>
        /// The data property.
        /// </summary>
        public static readonly DependencyProperty DataProperty =
            DependencyProperty.Register("Data", typeof(Geometry), typeof(PathContentControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        public Geometry Data
        {
            get { return (Geometry)GetValue(DataProperty); }
            set { SetValue(DataProperty, value); }
        }

        /// <summary>
        /// The margin of the content. The default value is a thickness with values 0,0,4,0.
        /// </summary>
        public static readonly DependencyProperty ContentMarginProperty =
            DependencyProperty.Register("ContentMargin", typeof(Thickness), typeof(PathContentControl), new PropertyMetadata(new Thickness(0, 0, 4, 0)));
        
        /// <summary>
        /// Exposes the <see cref="ContentMarginProperty"/> DependencyProperty.
        /// </summary>
        public Thickness ContentMargin
        {
            get { return (Thickness)GetValue(ContentMarginProperty); }
            set { SetValue(ContentMarginProperty, value); }
        }

        #endregion

        /// <summary>
        /// Initializes the <see cref="PathContentControl"/> class.
        /// </summary>
        static PathContentControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PathContentControl), new FrameworkPropertyMetadata(typeof(PathContentControl)));
        }
    }
}
