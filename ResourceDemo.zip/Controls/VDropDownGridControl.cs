﻿using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using Telerik.Windows.Controls;
using GridViewColumn = Telerik.Windows.Controls.GridViewColumn;
namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Interaction logic for DropDownGridControl
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ComboBox" />
    public class VDropDownGridControl : ComboBox
    {
        #region Properties
        /// <summary>
        /// The show clear button property
        /// </summary>
        public static readonly DependencyProperty ShowClearButtonProperty =
         DependencyProperty.Register("ShowClearButton", typeof(bool), typeof(VDropDownGridControl), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets a value indicating whether [show clear button].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show clear button]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowClearButton
        {
            get { return (bool)GetValue(ShowClearButtonProperty); }
            set { SetValue(ShowClearButtonProperty, value); }
        }

        /// <summary>
        /// Sets a minimum width for the popup containing the results of the quick search.
        /// </summary>
        public static readonly DependencyProperty MinPopupWidthProperty =
            DependencyProperty.Register("MinPopupWidth", typeof(double), typeof(VDropDownGridControl), new PropertyMetadata(200d));
        /// <summary>
        /// Exposes the <see cref="MinPopupWidthProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The minimum width of the popup.
        /// </value>
        public double MinPopupWidth
        {
            get { return (double)GetValue(MinPopupWidthProperty); }
            set { SetValue(MinPopupWidthProperty, value); }
        }

        /// <summary>
        /// The columns
        /// </summary>
        private readonly ObservableCollection<GridViewColumn> _columns = new ObservableCollection<GridViewColumn>();
        /// <summary>
        /// Gets the columns used in the rad grid view.
        /// </summary>
        public ObservableCollection<GridViewColumn> Columns
        {
            get { return _columns; }
        }

        /// <summary>
        /// The grid view
        /// </summary>
        private VGridView _gridView;
        /// <summary>
        /// Gets the grid view.
        /// </summary>
        /// <value>
        /// The grid view.
        /// </value>
        private VGridView GridView
        {
            get { return _gridView ?? (_gridView = Template.FindName("PART_DropDownGrid", this) as VGridView); }
        }
        #endregion


        /// <summary>
        /// The clear command
        /// </summary>
        private RelayCommand _clearCommand;
        /// <summary>
        /// Gets the clear command.
        /// </summary>
        /// <value>
        /// The clear command.
        /// </value>
        public RelayCommand ClearCommand
        {
            get { return _clearCommand ?? (_clearCommand = new RelayCommand(Clear)); }
        }

        #region Constructor

        /// <summary>
        /// Initializes the <see cref="VDropDownGridControl"/> class.
        /// </summary>
        static VDropDownGridControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VDropDownGridControl), new FrameworkPropertyMetadata(typeof(VDropDownGridControl)));
            SelectedItemProperty.OverrideMetadata(typeof(VDropDownGridControl), new FrameworkPropertyMetadata(OnSelectedItemChanged));
        }
        #endregion

        #region Method
        /// <summary>
        /// Clears all property associations.
        /// </summary>
        public void Clear()
        {
            if (GridView != null)
            {
                SelectedItem = null;
                GridView.SelectedItem = null;
            }
                       
        }

        /// <summary>
        /// Adds the grid columns.
        /// </summary>
        private void AddGridColumns()
        {
            var gridView = GridView;
            if (gridView != null)
            {
                gridView.Columns.Clear();

                if (_columns.Any())
                {
                    gridView.Columns.AddRange(_columns);
                }
                else
                {
                    gridView.Columns.Add(new GridViewDataColumn
                    {
                        Header = DisplayMemberPath,
                        DataMemberBinding = new Binding(DisplayMemberPath),
                        IsReadOnly = true
                    });
                }

                gridView.SelectionChanged += (sender, args) =>
                {
                    if (IsDropDownOpen)
                    {
                        SelectedItem = gridView.SelectedItem;
                        IsDropDownOpen = false;
                    }
                };
            }
        }

        /// <summary>
        /// Called when [selected item changed].
        /// This is required to set the PART_DropDownGrid GridView selectedItem to the dropdowns selected item
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSelectedItemChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VDropDownGridControl control = (VDropDownGridControl)d;
            if (control != null)
            {
                if (!control.IsDropDownOpen)
                {
                    VGridView dropDownGrid = (control.Template.FindName("PART_DropDownGrid", control) as VGridView);
                    if (dropDownGrid != null)
                    {
                        dropDownGrid.SelectedItem = e.NewValue;
                    }
                }
            }
        }

        #endregion

        #region Override
        /// <summary>
        /// Called when <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" /> is called.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            AddGridColumns();
        }

        #endregion
    }
}
