﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Telerik.Windows.Shapes;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that displays progress in the donught form.
    /// </summary>
    public class ProgressControl : Control
    {
        private Arc _arc;
        //private readonly Duration _duration = new Duration(new TimeSpan(0, 0, 0, 0, 200));

        /// <summary>
        /// The size of the arc.
        /// </summary>
        public static readonly DependencyProperty ArcSizeProperty = 
            DependencyProperty.Register("ArcSize", typeof(double), typeof(ProgressControl), new PropertyMetadata(80d));
        /// <summary> 
        /// Exposes the <see cref="ArcSizeProperty"/> DependencyProperty.
        /// </summary>
        public double ArcSize
        {
            get { return (double)GetValue(ArcSizeProperty); }
            set { SetValue(ArcSizeProperty, value); }
        }

        /// <summary>
        /// The thickness of the arc.
        /// </summary>
        public static readonly DependencyProperty ArcThicknessProperty =
            DependencyProperty.Register("ArcThickness", typeof(double), typeof(ProgressControl), new PropertyMetadata(16d));
        /// <summary> 
        /// Exposes the <see cref="ArcThicknessProperty"/> DependencyProperty.
        /// </summary>
        public double ArcThickness
        {
            get { return (double)GetValue(ArcThicknessProperty); }
            set { SetValue(ArcThicknessProperty, value); }
        }

        /// <summary>
        /// The total.
        /// </summary>
        public static readonly DependencyProperty TotalProperty = 
            DependencyProperty.Register("Total", typeof(double), typeof(ProgressControl), new PropertyMetadata(100d, OnValuesChanged));
        /// <summary> 
        /// Exposes the <see cref="TotalProperty"/> DependencyProperty.
        /// </summary>
        public double Total
        {
            get { return (double)GetValue(TotalProperty); }
            set { SetValue(TotalProperty, value); }
        }

        /// <summary>
        /// The value.
        /// </summary>
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(double), typeof(ProgressControl), new PropertyMetadata(0d, OnValuesChanged));
        /// <summary> 
        /// Exposes the <see cref="ValueProperty"/> DependencyProperty.
        /// </summary>
        public double Value
        {
            get { return (double)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        /// <summary>
        /// The precentage.
        /// </summary>
        public static readonly DependencyProperty PercentageProperty = 
            DependencyProperty.Register("Percentage", typeof(double), typeof(ProgressControl), new PropertyMetadata(0d));
        /// <summary> 
        /// Exposes the <see cref="PercentageProperty"/> DependencyProperty.
        /// </summary>
        public double Percentage
        {
            get { return (double)GetValue(PercentageProperty); }
            set { SetValue(PercentageProperty, value); }
        }

        /// <summary>
        /// The foreground of the arc.
        /// </summary>
        public static readonly DependencyProperty ProgressForegroundProperty = 
            DependencyProperty.Register("ProgressForeground", typeof(Brush), typeof(ProgressControl), new PropertyMetadata(Brushes.DeepSkyBlue));
        /// <summary> 
        /// Exposes the <see cref="ProgressForegroundProperty"/> DependencyProperty.
        /// </summary>
        public Brush ProgressForeground
        {
            get { return (Brush)GetValue(ProgressForegroundProperty); }
            set { SetValue(ProgressForegroundProperty, value); }
        }

        static ProgressControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ProgressControl), new FrameworkPropertyMetadata(typeof(ProgressControl)));
        }

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            _arc = Template.FindName("PART_Arc", this) as Arc;
            OnValuesChanged();
            base.OnApplyTemplate();
        }

        private static void OnValuesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (ProgressControl) d;
            control.OnValuesChanged();
        }

        private void OnValuesChanged()
        {
            if (_arc != null)
            {
                var perc = Math.Max(0, Total > 0 ? Value / Total : Equals(Total, Value) ? 1 :  0);
                var end = perc < 1 ? 360*perc : 359.99;
                _arc.EndAngle = end;
                SetValue(PercentageProperty, perc * 100);
            }
        }
    }
}
