﻿using GalaSoft.MvvmLight.Command;
using Microsoft.Practices.ServiceLocation;
using System;
using Telerik.Windows.Controls;
using VShips.Framework.Common.Model;
using IDialogService = VShips.Framework.Common.Services.IDialogService;
using ViewModelBase = GalaSoft.MvvmLight.ViewModelBase;

namespace VShips.Framework.Resource.Controls.Export
{
    /// <summary>
    /// A view model for exporting.
    /// </summary>
    public class ExportViewModel : ViewModelBase
    {
        /// <summary>
        /// The export action
        /// </summary>
        private readonly Action<ExportViewModel> _exportAction;

        /// <summary>
        /// The is excel
        /// </summary>
        private bool _isExcel;

        /// <summary>
        /// True if the export format is of type pdf.
        /// </summary>
        public bool IsExcel
        {
            get { return _isExcel; }
            set { Set(() => IsExcel, ref _isExcel, value); }
        }

        /// <summary>
        /// The total pages
        /// </summary>
        private int _totalPages;

        /// <summary>
        /// The total amount of pages that can be exported.
        /// </summary>
        /// <value>
        /// The total pages.
        /// </value>
        public int TotalPages
        {
            get { return _totalPages; }
            set { Set(() => TotalPages, ref _totalPages, value); }
        }

        /// <summary>
        /// The start page
        /// </summary>
        private int _startPage;

        /// <summary>
        /// The first page to export.
        /// </summary>
        public int StartPage
        {
            get { return _startPage; }
            set { Set(() => StartPage, ref _startPage, value); }
        }

        /// <summary>
        /// The end page
        /// </summary>
        private int _endPage;

        /// <summary>
        /// The last page to export.
        /// </summary>
        public int EndPage
        {
            get { return _endPage; }
            set { Set(() => EndPage, ref _endPage, value); }
        }

        /// <summary>
        /// The filename
        /// </summary>
        private string _filename;

        /// <summary>
        /// The filename to export.
        /// </summary>
        public string FileName
        {
            get { return _filename; }
            set { Set(() => FileName, ref _filename, value); }
        }

        /// <summary>
        /// If there are pages to export.
        /// </summary>
        public bool HasPages
        {
            get { return TotalPages > 1; }
        }

        /// <summary>
        /// The export format
        /// </summary>
        private ExportFormat _exportFormat;

        /// <summary>
        /// The export format.
        /// </summary>
        public ExportFormat ExportFormat
        {
            get { return _exportFormat; }
            set { Set(() => ExportFormat, ref _exportFormat, value); }
        }

        /// <summary>
        /// The export command
        /// </summary>
        private RelayCommand _exportCommand;

        /// <summary>
        /// The command to execute on export.
        /// </summary>
        public RelayCommand ExportCommand
        {
            get { return _exportCommand ?? (_exportCommand = new RelayCommand(Export)); }
        }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public ExportViewModel(Action<ExportViewModel> exportAction)
        {
            _exportAction = exportAction;
            _isExcel = true;
            _totalPages = 1;
            _startPage = 1;
            _endPage = 1;
        }

        /// <summary>
        /// Design time constructor.
        /// </summary>
        public ExportViewModel()
        {
            _totalPages = 5;
            _startPage = 2;
            _endPage = 4;
            _isExcel = true;
        }

        /// <summary>
        /// Exports this instance.
        /// </summary>
        private void Export()
        {
            var dialogService = ServiceLocator.Current.GetInstance<IDialogService>();
            var extName = IsExcel ? "Excel" : "CSV";
            var ext = IsExcel ? "xls" : "csv";
            ExportFormat = IsExcel ? ExportFormat.ExcelML : ExportFormat.Csv;
            var dialogParameters = new FileDialogParameters
            {
                Filter = string.Format("{0} Files (*.{1})|*.{1}", extName, ext),
                Title = "Open",
                FileName = FileName,
            };
            dialogService.SaveFileDialog(dialogParameters, DoExport);
        }

        /// <summary>
        /// Does the export.
        /// </summary>
        /// <param name="result">The result.</param>
        /// <param name="dialogParameters">The dialog parameters.</param>
        private void DoExport(bool? result, FileDialogParameters dialogParameters)
        {
            if (result == true && _exportAction != null)
            {
                _filename = dialogParameters.FileName;
                _exportAction(this);
            }
        }
    }
}
