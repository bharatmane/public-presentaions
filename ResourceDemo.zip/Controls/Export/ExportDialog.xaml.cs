﻿namespace VShips.Framework.Resource.Controls.Export
{
    /// <summary>
    /// Interaction logic for ExportDialog.xaml
    /// </summary>
    public partial class ExportDialog 
    {
        /// <summary>
        /// The default constructor for the export dialog.
        /// </summary>
        public ExportDialog()
        {
            InitializeComponent();
        }
    }
}
