﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A listbox control commonly used in the side list.
    /// Features include preventing selection during up and down arrows down and support for data scrolling.
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ListBox" />
    public class VListBox : ListBox
    {
        /// <summary>
        /// A mechanism that allows data to be retreived on demand. Items must implement IScrollItem for this to work.
        /// </summary>
        public static readonly DependencyProperty UsesDataScrollingProperty =
            DependencyProperty.Register("UsesDataScrolling", typeof(bool), typeof(VListBox), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="UsesDataScrollingProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [uses data scrolling]; otherwise, <c>false</c>.
        /// </value>
        public bool UsesDataScrolling
        {
            get { return (bool)GetValue(UsesDataScrollingProperty); }
            set { SetValue(UsesDataScrollingProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="UsesRightClickFixProperty" /> DependencyProperty.
        /// </summary>
        public bool UsesRightClickFix
        {
            get { return (bool)GetValue(UsesRightClickFixProperty); }
            set { SetValue(UsesRightClickFixProperty, value); }
        }

        /// <summary>
        /// If this is true and the list box has a contextmenu then the right click action will be used to select a single item for the selected items before the menu opens.
        /// </summary>
        public static readonly DependencyProperty UsesRightClickFixProperty =
            DependencyProperty.Register("UsesRightClickFix", typeof(bool), typeof(VListBox), new PropertyMetadata(false, OnRightClickFixChanged));


        /// <summary>
        /// Use this binding instead of SelectedItem to prevent the SelectedItem changing when the up and down keys are pressed.
        /// </summary>
        public static readonly DependencyProperty SelectedItemBindingProperty =
            DependencyProperty.Register("SelectedItemBinding", typeof(object), typeof(VListBox), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnSelectedItemBindingChanged));
        /// <summary>
        /// Exposes the <see cref="SelectedItemBindingProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The selected item binding.
        /// </value>
        public object SelectedItemBinding
        {
            get { return GetValue(SelectedItemBindingProperty); }
            set { SetValue(SelectedItemBindingProperty, value); }
        }

        /// <summary>
        /// Sets the template to use if the item is a dummy item. This should be a skeleton template in order to display data before it is loaded.
        /// </summary>
        public static readonly DependencyProperty DummyItemTemplateProperty =
            DependencyProperty.Register("DummyItemTemplate", typeof(DataTemplate), typeof(VListBox), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="DummyItemTemplateProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The dummy item template.
        /// </value>
        public DataTemplate DummyItemTemplate
        {
            get { return (DataTemplate)GetValue(DummyItemTemplateProperty); }
            set { SetValue(DummyItemTemplateProperty, value); }
        }

        /// <summary>
        /// Command that is run when the mouse is double clicked. The viewmodel of the clicked item is passed to the command.
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty =
            DependencyProperty.Register("DoubleClickCommand", typeof(ICommand), typeof(VListBox), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="DoubleClickCommand" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The double click command.
        /// </value>
        public ICommand DoubleClickCommand
        {
            get { return (ICommand)GetValue(DoubleClickCommandProperty); }
            set { SetValue(DoubleClickCommandProperty, value); }
        }

        /// <summary>
        /// Attempts to scroll the selected item in view if this is true and the selecteditem changes.
        /// </summary>
        public static readonly DependencyProperty ScrollToSelectionProperty =
            DependencyProperty.Register("ScrollToSelection", typeof(bool), typeof(VListBox), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="ScrollToSelectionProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [scroll to selection]; otherwise, <c>false</c>.
        /// </value>
        public bool ScrollToSelection
        {
            get { return (bool)GetValue(ScrollToSelectionProperty); }
            set { SetValue(ScrollToSelectionProperty, value); }
        }

        /// <summary>
        /// Shows a no items label if the grid is empty and not busy.
        /// </summary>
        public static readonly DependencyProperty ShowNoItemsLabelProperty =
            DependencyProperty.Register("ShowNoItemsLabel", typeof(bool), typeof(VListBox), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="ShowNoItemsLabelProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show no items label]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowNoItemsLabel
        {
            get { return (bool)GetValue(ShowNoItemsLabelProperty); }
            set { SetValue(ShowNoItemsLabelProperty, value); }
        }

        /// <summary>
        /// The label to apply when there are no item to show.
        /// </summary>
        public static readonly DependencyProperty NoItemsLabelProperty =
            DependencyProperty.Register("NoItemsLabel", typeof(string), typeof(VListBox), new PropertyMetadata("No Items Found"));
        /// <summary>
        /// Exposes the <see cref="NoItemsLabelProperty" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// The no items label.
        /// </value>
        public string NoItemsLabel
        {
            get { return (string)GetValue(NoItemsLabelProperty); }
            set { SetValue(NoItemsLabelProperty, value); }
        }

        /// <summary>
        /// Initializes the <see cref="VListBox"/> class.
        /// </summary>
        static VListBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VListBox), new FrameworkPropertyMetadata(typeof(VListBox)));   
        }

        /// <summary>
        /// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
        /// </summary>
        public override void OnApplyTemplate()
        {
            OnSelectedItemBindingChanged();
            base.OnApplyTemplate();
        }

        /// <summary>
        /// True if the item is a <see cref="VListBoxItem" />.
        /// </summary>
        /// <param name="item">Specified item.</param>
        /// <returns>
        /// true if the item is its own ItemContainer; otherwise, false.
        /// </returns>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VListBoxItem;
        }

        /// <summary>
        /// Returns a <see cref="VListBoxItem" />.
        /// </summary>
        /// <returns>
        /// The element used to display a specified item.
        /// </returns>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VListBoxItem();
        }

        /// <summary>
        /// Prepares the container for the item.
        /// </summary>
        /// <param name="element">Element used to display the specified item.</param>
        /// <param name="item">Specified item.</param>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (VListBoxItem)element;
            if (control != null)
            {
                control.DummyItemTemplate = DummyItemTemplate;
                control.UsesDataScrolling = UsesDataScrolling;
                if (UsesDataScrolling)
                {
                    control.SetBinding(VListBoxItem.IsDummyItemProperty, new Binding("IsDummy"));
                }
            }
            base.PrepareContainerForItemOverride(element, item);
        }

        /// <summary>
        /// Executes the <see cref="DoubleClickCommand" /> if double clicked on an item.
        /// </summary>
        /// <param name="eventArgs">The event data.</param>
        protected override void OnMouseDoubleClick(MouseButtonEventArgs eventArgs)
        {
            if (eventArgs != null && eventArgs.ChangedButton == MouseButton.Left)
            {
                if (DoubleClickCommand != null)
                {
                    var source = eventArgs.OriginalSource as DependencyObject;
                    if (source != null)
                    {
                        var item = UIHelper.FindVisualParent<VListBoxItem>(source, this);
                        if (item != null)
                        {
                            var vm = item.DataContext;
                            if (DoubleClickCommand.CanExecute(vm))
                            {
                                DoubleClickCommand.Execute(vm);
                            }
                        }
                    }
                }
            }
            base.OnMouseDoubleClick(eventArgs);
        }

        /// <summary>
        /// Called when [selected item binding changed].
        /// </summary>
        /// <param name="dependencyObject">The dependencyObject.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSelectedItemBindingChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            var control = (VListBox)dependencyObject;
            control.OnSelectedItemBindingChanged();
        }

        /// <summary>
        /// Called when [right click fix changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object of type <see cref="DependencyObject"/>.</param>
        /// <param name="eventArguments">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnRightClickFixChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArguments)
        {
            if ((bool)eventArguments.NewValue)
            {
                var listView = (ListBox)dependencyObject;

                listView.PreviewMouseRightButtonDown += (sender, args) =>
                {
                    var item = UIHelper.FindVisualParent<VListBoxItem>((DependencyObject)args.OriginalSource);
                    if (item != null)
                    {
                        VListBox vListBox = sender as VListBox;
                        if (vListBox != null && !Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
                        {
                            vListBox.SelectedItems.Clear();
                            item.IsSelected = true;
                        }
                    }
                };
            }
        }

        /// <summary>
        /// Called when [selected item binding changed].
        /// </summary>
        private void OnSelectedItemBindingChanged()
        {
            SelectedItem = SelectedItemBinding;
        }

        /// <summary>
        /// Updates the <see cref="SelectedItemBinding" /> property.
        /// </summary>
        /// <param name="eventArgs">Provides data for <see cref="T:System.Windows.Controls.SelectionChangedEventArgs" />.</param>
        protected override void OnSelectionChanged(SelectionChangedEventArgs eventArgs)
        {
            base.OnSelectionChanged(eventArgs);
            UpdateSelectedItemBinding();
            if (ScrollToSelection)
            {
                ScrollToSelectedItem();
            }
        }


        /// <summary>
        /// Attempts to scroll the selected item into view.
        /// </summary>
        public void ScrollToSelectedItem()
        {
            if (SelectedItem != null)
            {
                Dispatcher.BeginInvoke((Action)(() =>
                {
                    UpdateLayout();
                    if (SelectedItem != null)
                    {
                        ScrollIntoView(SelectedItem);
                    }
                }));
            }
        }

        /// <summary>
        /// Updates the <see cref="SelectedItemBinding" /> property.
        /// </summary>
        /// <param name="eventArgs">The <see cref="T:System.Windows.Input.KeyEventArgs" /> that contains the event data.</param>
        protected override void OnKeyUp(KeyEventArgs eventArgs)
        {
            base.OnKeyUp(eventArgs);
            UpdateSelectedItemBinding();
        }

        /// <summary>
        /// Updates the selected item binding.
        /// </summary>
        private void UpdateSelectedItemBinding()
        {
            if (!IsMoveKeyPressed())
            {
                SelectedItemBinding = SelectedItem;
            }
        }

        /// <summary>
        /// Determines whether [is move key pressed].
        /// </summary>
        /// <returns>
        ///   <c>true</c> if [is move key pressed]; otherwise, <c>false</c>.
        /// </returns>
        private static bool IsMoveKeyPressed()
        {
            return Keyboard.IsKeyDown(Key.Down) || Keyboard.IsKeyDown(Key.Up) || Keyboard.IsKeyDown(Key.PageDown) || Keyboard.IsKeyDown(Key.PageUp);
        }

        #region MultiSelection Behaviour
        
        #region Dependency Property

        /// <summary>
        /// The selected items bindable property
        /// </summary>
        public static readonly DependencyProperty SelectedItemsBindableProperty =
            DependencyProperty.Register("SelectedItemsBindable", typeof(IList), typeof(VListBox), new PropertyMetadata(null, OnSelectedItemsBindableChanged));

        /// <summary>
        /// The selected items updated command property
        /// </summary>
        public static readonly DependencyProperty SelectedItemsUpdatedCommandProperty =
            DependencyProperty.Register("SelectedItemsUpdatedCommand", typeof(ICommand), typeof(VListBox), new PropertyMetadata(null));

        #endregion

        #region Properties
        
        /// <summary>
        /// Gets or sets the selected items bindable.
        /// </summary>
        /// <value>
        /// The selected items bindable.
        /// </value>
        public IList SelectedItemsBindable
        {
            get { return (IList)GetValue(SelectedItemsBindableProperty); }
            set { SetValue(SelectedItemsBindableProperty, value); }
        }
        
        /// <summary>
        /// Gets or sets the selected items updated command.
        /// </summary>
        /// <value>
        /// The selected items updated command.
        /// </value>
        public ICommand SelectedItemsUpdatedCommand
        {
            get { return (ICommand)GetValue(SelectedItemsUpdatedCommandProperty); }
            set { SetValue(SelectedItemsUpdatedCommandProperty, value); }
        }

        #endregion

        #region Constructor
        
        /// <summary>
        /// Initializes a new instance of the <see cref="VListBox"/> class.
        /// </summary>
        public VListBox()
        {
            Unloaded += OnVListBoxUnloaded;
        }

        #endregion

        #region Static Methods

        /// <summary>
        /// Called when selected items bindable changed.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="eventArg">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSelectedItemsBindableChanged(DependencyObject source, DependencyPropertyChangedEventArgs eventArg)
        {
            VListBox vlistbox = source as VListBox;
            if (vlistbox != null)
            {
                // detach old source items change 
                vlistbox.DetachSourceSelectionChanged(eventArg.OldValue as INotifyCollectionChanged);

                // if source containes items then Synchronize and hook events
                vlistbox.InvalidateListBoxSelection();
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Called when v ListBox unloaded.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void OnVListBoxUnloaded(object sender, RoutedEventArgs e)
        {
            Unloaded -= OnVListBoxUnloaded;
            UnHookEvents();
        }

        /// <summary>
        /// Attaches the source selection changed.
        /// </summary>
        /// <param name="source">The source.</param>
        private void AttachSourceSelectionChanged(INotifyCollectionChanged source)
        {
            if (source != null)
            {
                source.CollectionChanged += OnSelectedItemsUpdated;
            }
        }

        /// <summary>
        /// Detaches the source selection changed.
        /// </summary>
        /// <param name="source">The source.</param>
        private void DetachSourceSelectionChanged(INotifyCollectionChanged source)
        {
            if (source != null)
            {
                source.CollectionChanged -= OnSelectedItemsUpdated;
            }
        }

        /// <summary>
        /// Attaches the ListBox selection changed.
        /// </summary>
        private void AttachListBoxSelectionChanged()
        {
            SelectionChanged += OnListBoxSelectionChanged;
        }

        /// <summary>
        /// Detaches the ListBox selection changed.
        /// </summary>
        private void DetachListBoxSelectionChanged()
        {
            SelectionChanged -= OnListBoxSelectionChanged;
        }

        /// <summary>
        /// Invalidates the ListBox selection.
        /// </summary>
        private void InvalidateListBoxSelection()
        {
            SynchronizeSafelyWithNotify(SelectedItemsBindable, SelectedItems);
        }

        /// <summary>
        /// Called when source collection changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="NotifyCollectionChangedEventArgs"/> instance containing the event data.</param>
        private void OnSelectedItemsUpdated(object sender, NotifyCollectionChangedEventArgs e)
        {
            SynchronizeSafelyWithNotify(SelectedItemsBindable, SelectedItems);
        }

        /// <summary>
        /// Called when associated object selection changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.Windows.Controls.SelectionChangedEventArgs"/> instance containing the event data.</param>
        private void OnListBoxSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            SynchronizeSafelyWithNotify(SelectedItems, SelectedItemsBindable);
        }

        /// <summary>
        /// Synchronizes the safely with notify.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        private void SynchronizeSafelyWithNotify(IList source, IList target)
        {
            EnsureSyncInOneDirection(() =>
            {
                SyncSourceToTarget(source, target);
            });

            RaiseSelectedItemsUpdatedCommand();
        }

        /// <summary>
        /// Synchronizes the source to target.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        private void SyncSourceToTarget(IList source, IList target)
        {
            if (source == null || target == null)
                return;
            target.Clear();

            foreach (var item in source)
            {
                target.Add(item);
            }
        }

        /// <summary>
        /// Ensures the synchronize in one direction.
        /// </summary>
        /// <param name="execute">The execute.</param>
        private void EnsureSyncInOneDirection(Action execute)
        {
            //BEGIN SYNCHRONIZATION
            UnHookEvents();

            if (execute != null)
            {
                execute();
            }

            //END SYNCHRONIZATION
            HookEvents();
        }

        /// <summary>
        /// Uns the hook events.
        /// </summary>
        private void UnHookEvents()
        {
            DetachListBoxSelectionChanged();
            DetachSourceSelectionChanged(SelectedItemsBindable as INotifyCollectionChanged);
        }

        /// <summary>
        /// Hooks the events.
        /// </summary>
        private void HookEvents()
        {
            AttachListBoxSelectionChanged();
            AttachSourceSelectionChanged(SelectedItemsBindable as INotifyCollectionChanged);
        }

        /// <summary>
        /// Raises the selected items updated command.
        /// </summary>
        private void RaiseSelectedItemsUpdatedCommand()
        {
            if (SelectedItemsUpdatedCommand != null)
            {
                SelectedItemsUpdatedCommand.Execute(null);
            }
        }
        #endregion

        #endregion
    }
}
