﻿using System;
using System.Windows.Threading;

namespace VShips.Framework.Resource.Controls.Model
{
    /// <summary>
    /// A class used to delay the execution of an action on the UI.
    /// This is used to prevent each action creating a server lookup for example.
    /// </summary>
    internal class DelayedExection
    {
        private Action _action;
        private readonly DispatcherTimer _timer;
        private bool _isStarted;

        internal DelayedExection(TimeSpan delay, Dispatcher dispatcher)
        {
            _timer = new DispatcherTimer(delay, DispatcherPriority.Background, InternalExecute, dispatcher);
        }

        internal void Execute(Action action)
        {
            _action = action;
            if (_isStarted)
            {
                _timer.Stop();
            }
            _timer.Start();
            _isStarted = true;
        }

        private void InternalExecute(object sender, EventArgs e)
        {
            _timer.Stop();
            if (_action != null)
            {
                _action();
                _action = null;
            }
        }
    }
}
