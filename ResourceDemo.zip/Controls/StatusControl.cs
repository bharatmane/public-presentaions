﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An easy way to set a status on a control. By default its viewed as a circle with a string value inside.
    /// </summary>
    public class StatusControl : Control
    {
        /// <summary>
        /// The status that appears inside the circle.
        /// </summary>
        public static readonly DependencyProperty StatusProperty =
            DependencyProperty.Register("Status", typeof(object), typeof(StatusControl), new PropertyMetadata(""));
        /// <summary>
        /// Exposes the <see cref="StatusProperty"/> DependencyProperty.
        /// </summary>
        public object Status
        {
            get { return GetValue(StatusProperty); }
            set { SetValue(StatusProperty, value); }
        }

        static StatusControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(StatusControl), new FrameworkPropertyMetadata(typeof(StatusControl)));
        }
    }
}
