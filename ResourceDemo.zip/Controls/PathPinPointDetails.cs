﻿using System.Windows;
using System.Windows.Controls;
using Telerik.Windows.Controls.Map;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that shows the details of a <see cref="PathPinPoint"/>.
    /// </summary>
    public class PathPinPointDetails : HeaderedContentControl
    {
        /// <summary>
        /// Returns true if the details panel is currently open.
        /// </summary>
        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(PathPinPointDetails), new PropertyMetadata(false, OnIsOpenChanged));
        /// <summary>
        /// Exposes the <see cref="IsOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        static PathPinPointDetails()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PathPinPointDetails), new FrameworkPropertyMetadata(typeof(PathPinPointDetails)));
        }

        public override void OnApplyTemplate()
        {
            var closeButton = Template.FindName("PART_CloseButton", this) as Button;
            if (closeButton != null)
            {
                closeButton.Click += CloseButtonOnClick;
            }
            base.OnApplyTemplate();
        }

        private void CloseButtonOnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private static void OnIsOpenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (PathPinPointDetails) d;
            control.OnIsOpenChanged();
        }

        private void OnIsOpenChanged()
        {
            if (!IsOpen)
            {
                var closeButton = Template.FindName("PART_CloseButton", this) as Button;
                if (closeButton != null)
                {
                    closeButton.Click -= CloseButtonOnClick;
                }
                var layer = UIHelper.FindVisualParent<InformationLayer>(this);
                if (layer != null)
                {
                    layer.Items.Remove(this);
                }
            }
        }

        /// <summary>
        /// Removes the details from the map.
        /// </summary>
        public void Close()
        {
            IsOpen = false;
        }
    }
}
