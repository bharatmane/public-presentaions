﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An easy way to control the look of the details section during load and records
    /// </summary>
    public class DetailContentControl : ContentControl
    {

        /// <summary>
        /// The is initial load property
        /// </summary>
        public static readonly DependencyProperty IsInitialLoadProperty =
            DependencyProperty.Register("IsInitialLoad", typeof(bool), typeof(DetailContentControl), new PropertyMetadata(true));

        /// <summary>
        /// Gets or sets a value indicating whether this instance is initial load.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is initial load; otherwise, <c>false</c>.
        /// </value>
        public bool IsInitialLoad
        {
            get { return (bool)GetValue(IsInitialLoadProperty); }
            set { SetValue(IsInitialLoadProperty, value); }
        }

        /// <summary>
        /// True if the items list is busy.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(DetailContentControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsBusyProperty"/> DependencyProperty.
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        /// <summary>
        /// True if a record is not null.
        /// </summary>
        public static readonly DependencyProperty HasDetailProperty =
            DependencyProperty.Register("HasDetail", typeof(bool), typeof(DetailContentControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="HasDetailProperty"/> DependencyProperty.
        /// </summary>
        public bool HasDetail
        {
            get { return (bool)GetValue(HasDetailProperty); }
            set { SetValue(HasDetailProperty, value); }
        }

        static DetailContentControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DetailContentControl), new FrameworkPropertyMetadata(typeof(DetailContentControl)));
        }
    }
}
