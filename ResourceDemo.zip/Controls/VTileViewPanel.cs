﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using GalaSoft.MvvmLight;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The panel for the tile view control.
    /// </summary>
    public class VTileViewPanel : Panel, IScrollInfo
    {
        private readonly TimeSpan _animationLength = TimeSpan.FromMilliseconds(200);

        private Size _cellSize;
        private VTileViewDropAdorner _adorner;
        private VTileViewItem _dragItem;

        /// <summary>
        /// Gets or sets the background used to highlight during a drag and drop operation.
        /// </summary>
        public static readonly DependencyProperty HighlightBackgroundProperty =
            DependencyProperty.Register("HighlightBackground", typeof(Brush), typeof(VTileViewPanel), new PropertyMetadata(Brushes.LightBlue));
        /// <summary>
        /// Exposes the <see cref="HighlightBackgroundProperty"/> DependencyProperty.
        /// </summary>
        public Brush HighlightBackground
        {
            get { return (Brush)GetValue(HighlightBackgroundProperty); }
            set { SetValue(HighlightBackgroundProperty, value); }
        }

        /// <summary>
        /// The number of columns in the panel.
        /// </summary>
        public static readonly DependencyProperty ColumnsProperty =
            DependencyProperty.Register("Columns", typeof(int), typeof(VTileViewPanel), new FrameworkPropertyMetadata(8, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));
        /// <summary>
        /// Exposes the <see cref="ColumnsProperty"/> DependencyProperty.
        /// </summary>
        public int Columns
        {
            get { return (int)GetValue(ColumnsProperty); }
            set { SetValue(ColumnsProperty, value); }
        }

        /// <summary>
        /// The number of rows in the panel.
        /// </summary>
        public static readonly DependencyProperty RowsProperty =
            DependencyProperty.Register("Rows", typeof(int), typeof(VTileViewPanel), new FrameworkPropertyMetadata(8, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));
        /// <summary>
        /// Exposes the <see cref="RowsProperty"/> DependencyProperty.
        /// </summary>
        public int Rows
        {
            get { return (int)GetValue(RowsProperty); }
            set { SetValue(RowsProperty, value); }
        }

        /// <summary>
        /// The number of rows a minimised tile takes up.
        /// </summary>
        public static readonly DependencyProperty MinimisedRowsProperty =
            DependencyProperty.Register("MinimisedRows", typeof(int), typeof(VTileViewPanel), new PropertyMetadata(2));
        /// <summary>
        /// Exposes the <see cref="MinimisedRowsProperty"/> DependencyProperty.
        /// </summary>
        public int MinimisedRows
        {
            get { return (int)GetValue(MinimisedRowsProperty); }
            set { SetValue(MinimisedRowsProperty, value); }
        }

        /// <summary>
        /// The number of columns a minimised tile takes up. 
        /// </summary>
        public static readonly DependencyProperty MinimisedColumnsProperty =
            DependencyProperty.Register("MinimisedColumns", typeof(int), typeof(VTileViewPanel), new PropertyMetadata(2));
        /// <summary>
        /// Exposes the <see cref="MinimisedColumnsProperty"/> DependencyProperty.
        /// </summary>
        public int MinimisedColumns
        {
            get { return (int)GetValue(MinimisedColumnsProperty); }
            set { SetValue(MinimisedColumnsProperty, value); }
        }

        /// <summary>
        /// The column to place the item.
        /// </summary>
        public static readonly DependencyProperty ColumnProperty =
            DependencyProperty.RegisterAttached("Column", typeof(int), typeof(VTileViewPanel), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Sets the column of an item.
        /// </summary>
        public static void SetColumn(UIElement element, int value)
        {
            element.SetValue(ColumnProperty, value);
        }
        /// <summary>
        /// Gets the column of an item.
        /// </summary>
        public static int GetColumn(UIElement element)
        {
            return (int)element.GetValue(ColumnProperty);
        }

        /// <summary>
        /// The row to place the item.
        /// </summary>
        public static readonly DependencyProperty RowProperty =
            DependencyProperty.RegisterAttached("Row", typeof(int), typeof(VTileViewPanel), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Sets the row of an item.
        /// </summary>
        public static void SetRow(UIElement element, int value)
        {
            element.SetValue(RowProperty, value);
        }
        /// <summary>
        /// Gets the row of an item.
        /// </summary>
        public static int GetRow(UIElement element)
        {
            return (int)element.GetValue(RowProperty);
        }

        /// <summary>
        /// The column span of the item.
        /// </summary>
        public static readonly DependencyProperty ColumnSpanProperty =
            DependencyProperty.RegisterAttached("ColumnSpan", typeof(int), typeof(VTileViewPanel), new FrameworkPropertyMetadata(1, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Sets the column span of an item.
        /// </summary>
        public static void SetColumnSpan(UIElement element, int value)
        {
            element.SetValue(ColumnSpanProperty, value);
        }
        /// <summary>
        /// Gets the column span of an item.
        /// </summary>
        public static int GetColumnSpan(UIElement element)
        {
            return (int)element.GetValue(ColumnSpanProperty);
        }

        /// <summary>
        /// The row span of the item.
        /// </summary>
        public static readonly DependencyProperty RowSpanProperty =
            DependencyProperty.RegisterAttached("RowSpan", typeof(int), typeof(VTileViewPanel), new FrameworkPropertyMetadata(1, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Sets the row span of an item.
        /// </summary>
        public static void SetRowSpan(UIElement element, int value)
        {
            element.SetValue(RowSpanProperty, value);
        }
        /// <summary>
        /// Gets the row span of an item.
        /// </summary>
        public static int GetRowSpan(UIElement element)
        {
            return (int)element.GetValue(RowSpanProperty);
        }

        /// <summary>
        /// The state of the item, expanded or collapsed.
        /// </summary>
        public static readonly DependencyProperty StateProperty =
            DependencyProperty.RegisterAttached("State", typeof(VTileViewState), typeof(VTileViewPanel), new PropertyMetadata(VTileViewState.Normal, OnStateChanged));
        /// <summary>
        /// Sets the state of an item.
        /// </summary>
        public static void SetState(UIElement element, VTileViewState value)
        {
            element.SetValue(StateProperty, value);
        }
        /// <summary>
        /// Gets the state of an item.
        /// </summary>
        public static VTileViewState GetState(UIElement element)
        {
            return (VTileViewState)element.GetValue(StateProperty);
        }

        /// <summary>
        /// Gets or sets the scrollviewer of the panel.
        /// </summary>
        public ScrollViewer ScrollOwner { get; set; }

        /// <summary>
        /// Gets or sets if the panel can scroll Horizontally.
        /// </summary>
        public bool CanHorizontallyScroll { get; set; }

        /// <summary>
        /// Gets or sets if the panel can scroll Vertically.
        /// </summary>
        public bool CanVerticallyScroll { get; set; }

        private Size _extent;
        /// <summary>
        /// The total height of items in the scrollviewer.
        /// </summary>
        public double ExtentHeight
        {
            get { return _extent.Height; }
        }

        /// <summary>
        /// The total width of items in the scrollviewer.
        /// </summary>
        public double ExtentWidth
        {
            get { return _extent.Width; }
        }

        private Size _viewport;
        /// <summary>
        /// The total height of the scrollviewers viewport.
        /// </summary>
        public double ViewportHeight
        {
            get { return _viewport.Height; }
        }

        /// <summary>
        /// The total width of the scrollviewers viewport.
        /// </summary>
        public double ViewportWidth
        {
            get { return _viewport.Width; }
        }

        private Point _offset;
        /// <summary>
        /// The current scrollviewer horizontal offset.
        /// </summary>
        public double HorizontalOffset
        {
            get { return _offset.X; }
        }

        /// <summary>
        /// The current scrollviewer vertical offset.
        /// </summary>
        public double VerticalOffset
        {
            get { return _offset.Y; }
        }

        private VTileViewState _state;
        /// <summary>
        /// The state of the panel.
        /// </summary>
        public VTileViewState State
        {
            get { return _state; }
        }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public VTileViewPanel()
        {
            Background = Brushes.Transparent;
        }

        /// <summary>
        /// Measures the items in the panel.
        /// </summary>
        protected override Size MeasureOverride(Size availableSize)
        {
            var cellSize = CalculateCellSize(availableSize);
            var extent = new Size();
            var items = Children.OfType<UIElement>().OrderBy(x => (GetColumn(x) + (GetRow(x)*Rows))).ToList();
            var expandedItem = items.FirstOrDefault(x => GetState(x) == VTileViewState.Expanded);

            if (expandedItem == null)
            {
                _state = VTileViewState.Normal;
                foreach (var child in items)
                {
                    var column = GetColumn(child);
                    var columnSpan = GetColumnSpan(child);
                    var row = GetRow(child);
                    var rowSpan = GetRowSpan(child);
                    child.Measure(new Size(columnSpan * cellSize.Width, rowSpan * cellSize.Height));
                    extent.Width = Math.Max(extent.Width, (column + columnSpan) * cellSize.Width);
                    extent.Height = Math.Max(extent.Height, (row + rowSpan) * cellSize.Height);
                }

                extent.Width = Math.Ceiling(extent.Width / availableSize.Width) * availableSize.Width;
                extent.Height = Math.Ceiling(extent.Height / availableSize.Height) * availableSize.Height;
                SetVerticalOffset(0);
            }
            else
            {
                _state = VTileViewState.Expanded;
                var expandedSize = new Size(cellSize.Width * (Columns - MinimisedColumns), availableSize.Height);
                extent.Width = availableSize.Width;
                foreach (var child in items)
                {
                    var state = GetState(child);
                    if (state == VTileViewState.Expanded)
                    {
                        child.Measure(expandedSize);
                    }
                    else
                    {
                        child.Measure(new Size(cellSize.Width * MinimisedColumns, cellSize.Height * MinimisedRows));
                        extent.Height = extent.Height + (cellSize.Height * MinimisedRows);
                    }
                }
            }

            UpdateViewport(availableSize);
            UpdateExtent(extent);

            InvalidateScroll();

            return extent;
        }

        /// <summary>
        /// Arranges the items in the panel.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var cellSize = _cellSize;
            var currentY = 0d;
            var items = Children.OfType<FrameworkElement>().OrderBy(x => (GetColumn(x) + (GetRow(x) * Rows))).ToList();
            var expandedItem = items.FirstOrDefault(x => GetState(x) == VTileViewState.Expanded);

            foreach (var child in items)
            {
                var trans = child.RenderTransform as TranslateTransform;
                if (trans == null)
                {
                    child.RenderTransformOrigin = new Point(0, 0);
                    trans = new TranslateTransform();
                    child.RenderTransform = trans;
                }

                if (expandedItem == null)
                {
                    var column = GetColumn(child);
                    var columnSpan = GetColumnSpan(child);
                    var row = GetRow(child);
                    var rowSpan = GetRowSpan(child);

                    child.Arrange(new Rect(0, 0, columnSpan * cellSize.Width, rowSpan * cellSize.Height));
                    trans.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation((column * cellSize.Width) -_offset.X, _animationLength), HandoffBehavior.Compose);
                    trans.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation((row * cellSize.Height) -_offset.Y, _animationLength), HandoffBehavior.Compose);
                }
                else
                {
                    var state = GetState(child);
                    
                    if (state == VTileViewState.Normal)
                    {
                        child.Arrange(new Rect(0, 0, cellSize.Width * MinimisedColumns, cellSize.Height * MinimisedRows));
                        trans.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation((cellSize.Width * (Columns - MinimisedColumns)) - _offset.X, _animationLength), HandoffBehavior.Compose);
                        trans.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(currentY - _offset.Y, _animationLength), HandoffBehavior.Compose);
                        currentY = currentY + (cellSize.Height * MinimisedRows);
                    }
                    else
                    {
                        child.Arrange(new Rect(0, 0, cellSize.Width * (Columns - MinimisedColumns), ViewportHeight));
                        trans.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(0, _animationLength), HandoffBehavior.Compose);
                        trans.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, _animationLength), HandoffBehavior.Compose);
                    }
                }
            }

            InvalidateScroll();

            return finalSize;
        }

        private Size CalculateCellSize(Size availableSize)
        {
            _cellSize = new Size(availableSize.Width/Columns, availableSize.Height/Rows);
            return _cellSize;
        }

        private void UpdateViewport(Size availableSize)
        {
            if (availableSize != _viewport)
            {
                _viewport = availableSize;
                InvalidateScroll();
            }
        }

        private void UpdateExtent(Size extent)
        {
            if (extent != _extent)
            {
                _extent = extent;
                InvalidateScroll();
            }
        }

        private void InvalidateScroll()
        {
            if (ScrollOwner != null)
            {
                ScrollOwner.InvalidateScrollInfo();
            }
        }

        /// <summary>
        /// Called during a scrollviewer line down.
        /// </summary>
        public void LineDown()
        {
            SetVerticalOffset(VerticalOffset + _cellSize.Height);
        }

        /// <summary>
        /// Called during a scrollviewer line up.
        /// </summary>
        public void LineUp()
        {
            SetVerticalOffset(VerticalOffset - _cellSize.Height);
        }

        /// <summary>
        /// Called during a scrollviewer line left.
        /// </summary>
        public void LineLeft()
        {
            SetHorizontalOffset(HorizontalOffset - _cellSize.Width);
        }

        /// <summary>
        /// Called during a scrollviewer line right.
        /// </summary>
        public void LineRight()
        {
            SetHorizontalOffset(HorizontalOffset + _cellSize.Width);
        }

        /// <summary>
        /// Called during a scrollviewer mouse wheel down.
        /// </summary>
        public void MouseWheelDown()
        {
            SetVerticalOffset(VerticalOffset + _cellSize.Height);
        }

        /// <summary>
        /// Called during a scrollviewer mouse wheel up.
        /// </summary>
        public void MouseWheelUp()
        {
            SetVerticalOffset(VerticalOffset - _cellSize.Height);
        }

        /// <summary>
        /// Called during a scrollviewer mouse wheel left.
        /// </summary>
        public void MouseWheelLeft()
        {
            SetHorizontalOffset(HorizontalOffset - _cellSize.Width);
        }

        /// <summary>
        /// Called during a scrollviewer mouse wheel right.
        /// </summary>
        public void MouseWheelRight()
        {
            SetHorizontalOffset(HorizontalOffset + _cellSize.Width);
        }

        /// <summary>
        /// Called during a scrollviewer page down.
        /// </summary>
        public void PageDown()
        {
            SetVerticalOffset(VerticalOffset + ViewportHeight);
        }

        /// <summary>
        /// Called during a scrollviewer page up.
        /// </summary>
        public void PageUp()
        {
            SetVerticalOffset(VerticalOffset - ViewportHeight);
        }

        /// <summary>
        /// Called during a scrollviewer page left.
        /// </summary>
        public void PageLeft()
        {
            SetHorizontalOffset(HorizontalOffset - ViewportWidth);
        }

        /// <summary>
        /// Called during a scrollviewer page right.
        /// </summary>
        public void PageRight()
        {
            SetHorizontalOffset(HorizontalOffset + ViewportWidth);
        }

        /// <summary>
        /// Sets the horizontal offset of the scrollviewer and updates the items positions.
        /// </summary>
        public void SetHorizontalOffset(double offset)
        {
            offset = Math.Max(0, Math.Min(offset, ExtentWidth - ViewportWidth));
            if (offset < _offset.X || offset > _offset.X)
            {
                _offset.X = offset;
                InvalidateScroll();
                InvalidateArrange();
            }
        }

        /// <summary>
        /// Sets the vertical offset of the scrollviewer and updates the items positions.
        /// </summary>
        public void SetVerticalOffset(double offset)
        {
            offset = Math.Max(0, Math.Min(offset, ExtentHeight - ViewportHeight));
            if (offset > _offset.Y || offset < _offset.Y)
            {
                _offset.Y = offset;
                InvalidateScroll();
                InvalidateArrange();
            }
        }

        /// <summary>
        /// Makes an item visible by scrolling to its position.
        /// </summary>
        public Rect MakeVisible(Visual visual, Rect rectangle)
        {
            var child = Children.OfType<UIElement>().FirstOrDefault(x => Equals(visual, x));
            if (child != null)
            {
                var cellSize = CalculateCellSize(RenderSize);
                var row = GetRow(child);

                SetVerticalOffset(cellSize.Height * row);
            }
            return rectangle;
        }

        private static void OnStateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VTileViewItem) d;
            var value = (VTileViewState) e.NewValue;
            var panel = UIHelper.FindVisualParent<VTileViewPanel>(control);
            if (panel != null)
            {
                var expandedItem = panel.Children.OfType<VTileViewItem>().FirstOrDefault(x => !Equals(control, x) && GetState(x) == VTileViewState.Expanded);
                if (expandedItem != null)
                {
                    SetState(expandedItem, VTileViewState.Normal);
                }
                control.State = value;
                panel.Dispatcher.BeginInvoke(new Action(() =>
                {
                    panel.InvalidateMeasure();
                }), DispatcherPriority.Background);
            }
        }

        internal void StartDrag(VTileViewItem item, Point mouseOffset)
        {
            if (_adorner == null)
            {
                _dragItem = item;
                _adorner = new VTileViewDropAdorner(this, item, HighlightBackground, _cellSize, mouseOffset);
            }
        }

        internal void StopDrag(VTileViewItem item)
        {
            if (_adorner != null)
            {
                UpdateDragPosition(item);
                _adorner.Cleanup();
                _adorner = null;
                _dragItem = null;
            }
        }

        /// <summary>
        /// Highlights an item during a drag and drop operation.
        /// </summary>
        protected override void OnPreviewDragOver(DragEventArgs e)
        {
            if (_adorner != null && _dragItem != null)
            {
                var pos = e.GetPosition(this);
                var column = (int)Math.Floor((pos.X + HorizontalOffset) / _cellSize.Width);
                var row = (int)Math.Floor((pos.Y + VerticalOffset) / _cellSize.Height);
                var intersecting = GetIntersecting(_dragItem, column, row, GetRowSpan(_dragItem), GetColumnSpan(_dragItem));
                if ((row + GetRowSpan(_dragItem)) <= Rows && (column + GetColumnSpan(_dragItem)) <= Columns && !intersecting)
                {
                    _adorner.Column = column;
                    _adorner.Row = row;
                }
                _adorner.Position = pos;
            }
            base.OnPreviewDragOver(e);
        }

        private void UpdateDragPosition(VTileViewItem item)
        {
            if (_adorner != null)
            {
                var column = _adorner.Column;
                var row = _adorner.Row;
                var pos = _adorner.ActualPosition;
                var trans = new TranslateTransform((pos.X + HorizontalOffset), (pos.Y + VerticalOffset));
                item.RenderTransform = trans;
                SetColumn(item, column);
                SetRow(item, row);
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    InvalidateScroll();
                    InvalidateVisual();
                }), DispatcherPriority.Background);
            }
        }

        private bool GetIntersecting(VTileViewItem item, int column, int row, int rowspan, int columnSpan)
        {
            var itemArea = GetOccupiedArea(column, row, rowspan, columnSpan);
            return Children.OfType<VTileViewItem>().Any(child => !Equals(item, child) && itemArea.IntersectsWith(GetOccupiedArea(GetColumn(child), GetRow(child), GetRowSpan(child), GetColumnSpan(child))));
        }

        private Rect GetOccupiedArea(int column, int row, int rowSpan, int columnSpan)
        {
            var cellSize = _cellSize;
            var rect = new Rect((column*cellSize.Width) - _offset.X, (row*cellSize.Height) - _offset.Y, (columnSpan*cellSize.Width) - 8, (rowSpan*cellSize.Height) -8);
            return rect;
        }

        
    }

    /// <summary>
    /// An adorner used in the VTileView to highlight a drop position.
    /// </summary>
    public class VTileViewDropAdorner : Adorner, ICleanup
    {
        private AdornerLayer _adornerLayer;
        private Image _image;

        private Point _position;
        /// <summary>
        /// The position of the currently dragged VTileViewItem.
        /// </summary>
        public Point Position
        {
            get { return _position; }
            set
            {
                if (!Equals(_position, value))
                {
                    _position = value;
                    OnPositionChanged();
                }
            }
        }

        /// <summary>
        /// The position relative to the mouse offset.
        /// </summary>
        public Point ActualPosition
        {
            get { return new Point(Position.X - MouseOffset.X, Position.Y - MouseOffset.Y); }
        }

        private readonly Brush _background;
        /// <summary>
        /// The highlight background.
        /// </summary>
        public Brush Background
        {
            get { return _background; }
        }

        private int _column;
        /// <summary>
        /// The column of the item dragged.
        /// </summary>
        public int Column
        {
            get { return _column; }
            internal set { _column = value; }
        }

        private int _row;
        /// <summary>
        /// The row of the item dragged.
        /// </summary>
        public int Row
        {
            get { return _row; }
            internal set { _row = value; }
        }

        private readonly int _columns;
        /// <summary>
        /// The columns the item occupies.
        /// </summary>
        public int Columns
        {
            get { return _columns; }
        }

        private readonly int _rows;
        /// <summary>
        /// The rows the item occupies.
        /// </summary>
        public int Rows
        {
            get { return _rows; }
        }

        private readonly Size _cellSize;
        /// <summary>
        /// The size of a cell in the panel.
        /// </summary>
        public Size CellSize
        {
            get { return _cellSize; }
        }

        private readonly Point _mouseOffset;
        /// <summary>
        /// The initial offset of the mouse in relation to the dragged element.
        /// </summary>
        public Point MouseOffset
        {
            get { return _mouseOffset; }
        }

        /// <summary>
        /// The default constructor for the adorner.
        /// </summary>
        public VTileViewDropAdorner(VTileViewPanel panel, VTileViewItem dragElement,  Brush highlightBackground, Size cellSize, Point mouseOffset)
            : base(panel)
        {
            _cellSize = cellSize;
            _column = VTileViewPanel.GetColumn(dragElement);
            _row = VTileViewPanel.GetRow(dragElement);
            _columns = VTileViewPanel.GetColumnSpan(dragElement);
            _rows = VTileViewPanel.GetRowSpan(dragElement);
            _mouseOffset = mouseOffset;
            _position = GetPosition(Column, Row);
            _background = highlightBackground;
            _adornerLayer = AdornerLayer.GetAdornerLayer(panel);
            _adornerLayer.Add(this);
            _image = GetClone(dragElement);
            IsHitTestVisible = false;
        }

        /// <summary>
        /// Measures the drag item.
        /// </summary>
        protected override Size MeasureOverride(Size constraint)
        {
            _image.Measure(constraint);
            return constraint;
        }

        /// <summary>
        /// Arranges the drag item.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            _image.Arrange(new Rect(ActualPosition, _image.DesiredSize));
            return finalSize;
        }

        /// <summary>
        /// Renders the drop hint on the adorner.
        /// </summary>
        protected override void OnRender(DrawingContext dc)
        {
            if (CellSize.Height > 0 && CellSize.Width > 0)
            {
                var size = CellSize;
                var y = (_row * size.Height);
                var x = (_column * size.Width);
                var width = size.Width * Columns;
                var height = size.Height * Rows;

                dc.DrawRectangle(Background, null, new Rect(x + 8, y + 8, width - 8, height - 8));
            }

            base.OnRender(dc);
        }

        /// <summary>
        /// Returns the drag item.
        /// </summary>
        protected override Visual GetVisualChild(int index)
        {
            return _image;
        }

        /// <summary>
        /// Returns the drag item count = 1.
        /// </summary>
        protected override int VisualChildrenCount
        {
            get { return 1; }
        }

        private Image GetClone(FrameworkElement dragElement)
        {
            return new Image { Source = CreateBitmapSourceFromVisual(dragElement), Width = dragElement.ActualWidth, Height = dragElement.ActualHeight };
        }

        private static BitmapSource CreateBitmapSourceFromVisual(FrameworkElement dragElement)
        {
            var bmp = new RenderTargetBitmap((Int32)Math.Ceiling(dragElement.ActualWidth), (Int32)Math.Ceiling(dragElement.ActualHeight), 96, 96, PixelFormats.Pbgra32);
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                var vb = new VisualBrush(dragElement);
                dc.DrawRectangle(vb, null, new Rect(new Point(), new Size(dragElement.ActualWidth, dragElement.ActualHeight)));
            }
            bmp.Render(dv);
            return bmp;
        }

        internal Point GetPosition(int column, int row)
        {
            return new Point((column * _cellSize.Width) - MouseOffset.X, (row * _cellSize.Height) - MouseOffset.Y);
        }

        private void OnPositionChanged()
        {
            if (_adornerLayer != null)
            {
                _adornerLayer.Update(AdornedElement);
            }
        }

        /// <summary>
        /// Cleans up the adorner.
        /// </summary>
        public void Cleanup()
        {
            _adornerLayer.Remove(this);
            _adornerLayer = null;
            _image = null;
        }
    }

    /// <summary>
    /// Determines the state of the VTileView.
    /// </summary>
    public enum VTileViewState
    {
        /// <summary>
        /// The normal state.
        /// </summary>
        Normal,

        /// <summary>
        /// A tile is expanded.
        /// </summary>
        Expanded
    }
}
