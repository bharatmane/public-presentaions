﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Generic column for grid view
    /// </summary>
    public class VGridViewGenericColumn : GridViewBoundColumnBase
    {
        /// <summary>
        /// The custom value binding
        /// </summary>
        public Binding CustomValueBinding;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="VGridViewGenericColumn"/> class.
        /// </summary>
        public VGridViewGenericColumn()
        {
            IsSortable = false;
            IsFilterable = false;
            IsResizable = false;           
        }

        #endregion

        #region Overriden Methods

        /// <summary>
        /// Creates the cell element.
        /// </summary>
        /// <param name="cell">The cell of type <see cref="GridViewCell"/>.</param>
        /// <param name="dataItem">The data item.</param>
        /// <returns>Single object of type <see cref="FrameworkElement"/>.</returns>
        public override FrameworkElement CreateCellElement(GridViewCell cell, object dataItem)
        {
            var control = new ContentControl();

            if (CustomValueBinding != null)
            {
                control.SetBinding(ContentControl.ContentProperty, CustomValueBinding);
            }
            else
            {
                control.SetBinding(ContentControl.ContentProperty, DataMemberBinding);
            }
            control.ContentTemplate = CellTemplate;
            return control;
        }

        /// <summary>
        /// Creates the cell edit element.
        /// </summary>
        /// <param name="cell">The cell of type <see cref="GridViewCell"/>.</param>
        /// <param name="dataItem">The data item.</param>
        /// <returns>Single object of type <see cref="FrameworkElement"/>.</returns>
        public override FrameworkElement CreateCellEditElement(GridViewCell cell, object dataItem)
        {
            var control = new ContentControl(); 
           
            if (CustomValueBinding != null)
            {
                control.SetBinding(ContentControl.ContentProperty, CustomValueBinding);
            }
            else
            {
                control.SetBinding(ContentControl.ContentProperty, DataMemberBinding);
            }
            control.ContentTemplate = CellEditTemplate;
            return control;
        }

        #endregion
    }
}
