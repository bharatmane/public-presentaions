﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using GalaSoft.MvvmLight.Command;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A combobox that can be used to filter data.
    /// This has the addition of a clear button which sets the SelectedItem value to null.
    /// </summary>
    public class FilterComboBox : RadComboBox
    {
        /// <summary>
        /// Used to clear the selected item property.
        /// By default this is set to null.
        /// </summary>
        public static readonly DependencyProperty ClearCommandProperty = 
            DependencyProperty.Register("ClearCommand", typeof(ICommand), typeof(FilterComboBox), new PropertyMetadata());
        /// <summary>
        /// Exposes the <see cref="ClearCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand ClearCommand
        {
            get { return (ICommand)GetValue(ClearCommandProperty); }
            set { SetValue(ClearCommandProperty, value); }
        }

        static FilterComboBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(FilterComboBox), new FrameworkPropertyMetadata(typeof(FilterComboBox)));
        }

        /// <summary>
        /// Applies the template to the control.
        /// </summary>
        public override void OnApplyTemplate()
        {
            ClearCommand = new RelayCommand(ClearItem);
            base.OnApplyTemplate();
        }

        private void ClearItem()
        {
            SelectedItem = null;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Mouse.Capture(null);
                Focus();
            }), DispatcherPriority.Background);
            
        }
    }
}
