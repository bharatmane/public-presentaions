﻿using GalaSoft.MvvmLight.Command;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The Editable Content Control
    /// </summary>
    public class EditableContentControl : TextBox
    {
        #region Properties
        /// <summary>
        /// The parent popup
        /// </summary>
        private Popup _parentPopup;

        /// <summary>
        /// The editable textbox
        /// </summary>
        private TextBox _editableTextbox;

        /// <summary>
        /// The original text
        /// </summary>
        private string _originalText;

        /// <summary>
        /// The is in edit mode property
        /// </summary>
        public static readonly DependencyProperty IsInEditModeProperty =
            DependencyProperty.Register("IsInEditMode", typeof(bool), typeof(EditableContentControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="IsInEditModeProperty"/> DependencyProperty.
        /// </summary>
        public bool IsInEditMode
        {
            get { return (bool)GetValue(IsInEditModeProperty); }
            set
            {
                SetValue(IsInEditModeProperty, value);
            }
        }


        /// <summary>
        /// The button text property
        /// </summary>
        public static readonly DependencyProperty ButtonTextProperty =
            DependencyProperty.Register("ButtonText", typeof(string), typeof(EditableContentControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the button text.
        /// </summary>
        /// <value>
        /// The button text.
        /// </value>
        public string ButtonText
        {
            get { return (string)GetValue(ButtonTextProperty); }
            set { SetValue(ButtonTextProperty, value); }
        }

        /// <summary>
        /// The save command property
        /// </summary>
        public static readonly DependencyProperty SaveCommandProperty =
            DependencyProperty.Register("SaveCommand", typeof(RelayCommand), typeof(EditableContentControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SaveCommandProperty"/> DependencyProperty.
        /// </summary>
        public RelayCommand SaveCommand
        {
            get { return (RelayCommand)GetValue(SaveCommandProperty); }
            set { SetValue(SaveCommandProperty, value); }
        }

        /// <summary>
        /// The save command property
        /// </summary>
        public static readonly DependencyProperty EditModeCommandProperty =
            DependencyProperty.Register("EditModeCommand", typeof(RelayCommand), typeof(EditableContentControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="EditModeCommandProperty"/> DependencyProperty.
        /// </summary>
        public RelayCommand EditModeCommand
        {
            get { return (RelayCommand)GetValue(EditModeCommandProperty); }
            set { SetValue(EditModeCommandProperty, value); }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Called when [is in edit mode click].
        /// </summary>
        private void OnIsInEditModeClick()
        {
            IsReadOnly = false;
            IsInEditMode = true;
            _editableTextbox.Focus();
            _editableTextbox.CaretIndex = _editableTextbox.Text.Length;
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        private void Save()
        {        
            IsInEditMode = string.IsNullOrWhiteSpace(Text);
            _originalText = Text;
            ClosePopup();
        }

        /// <summary>
        /// Cancels this instance.
        /// </summary>
        private void Cancel()
        {
            ClosePopup();
        }

        /// <summary>
        /// Closes the popup.
        /// </summary>
        private void ClosePopup()
        {
            if (_parentPopup != null)
            {
                _parentPopup.IsOpen = false;
            }
        }

        /// <summary>
        /// Called when [main grid mouse down].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventArgs">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        private void OnMainGridMouseDown(object sender, MouseButtonEventArgs eventArgs)
        {
            if (eventArgs.LeftButton == MouseButtonState.Pressed && eventArgs.ClickCount == 2)
            {
                IsReadOnly = false;
                IsInEditMode = true;
                _editableTextbox.Focus();
                _editableTextbox.CaretIndex = _editableTextbox.Text.Length;
                 if (!string.IsNullOrWhiteSpace(_editableTextbox.Text))
                {
                    _editableTextbox.CaretIndex = _editableTextbox.Text.Length;
                    _editableTextbox.Focus();

                }
            }
        }

        /// <summary>
        /// Handles the Closed event of the _parentPopup control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void parentPopup_Closed(object sender, System.EventArgs eventArgs)
        {
            if (IsInEditMode)
            {
                if (!string.IsNullOrWhiteSpace(_originalText))
                {
                    IsInEditMode = false;
                }

                Text = _originalText;
            }
        }

        /// <summary>
        /// Handles the Opened event of the parentPopup control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void parentPopup_Opened(object sender, System.EventArgs e)
        {
            IsReadOnly = true;
            if (!string.IsNullOrWhiteSpace(_editableTextbox.Text))
            {
                _editableTextbox.Focus();
                _editableTextbox.CaretIndex = _editableTextbox.Text.Length;
            }
            else if(string.IsNullOrWhiteSpace(_editableTextbox.Text))
            {
                IsReadOnly = false;
                _editableTextbox.Focus();
                _editableTextbox.CaretIndex = _editableTextbox.Text.Length;
            }
        }
        #endregion

        #region Override Methods
        /// <summary>
        /// Is called when a control template is applied.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            IsReadOnly = true;
            var editButton = Template.FindName("Part_ButtonEdit", this) as PathButton;
            if (editButton != null)
            {
                editButton.Click += (sender, args) => OnIsInEditModeClick();
            }

            var saveButton = Template.FindName("Part_ButtonSave", this) as RadButton;
            if (saveButton != null)
            {
                saveButton.Click += (sender, args) => Save();
                if (!string.IsNullOrWhiteSpace(ButtonText))
                {
                    saveButton.Content = ButtonText;
                }
            }

            var cancelButton = Template.FindName("Part_ButtonCancel", this) as PathButton;
            if (cancelButton != null)
            {
                cancelButton.Click += (sender, args) => Cancel();
            }

            var editableTextbox = Template.FindName("Part_EditableTextbox", this) as TextBox;      
            if (editableTextbox != null)
            {
                _editableTextbox = editableTextbox;
                editableTextbox.PreviewMouseDoubleClick += (sender, args) => OnIsInEditModeClick();
            }
           
            var mainGrid = Template.FindName("GridMain", this) as Grid;
            if (mainGrid != null)
            {
               mainGrid.MouseDown += OnMainGridMouseDown;
            }

            //Get the parent popup so that it can be closed, or the previous state can be retained if the popup loses focus.
            DependencyObject popup = Parent;

            while (!(popup is Popup) && popup != null)
            {
                popup = LogicalTreeHelper.GetParent(popup);
            }

            if (popup is Popup)
            {
                _parentPopup = popup as Popup;
                _parentPopup.Opened += parentPopup_Opened;
                _parentPopup.Closed += parentPopup_Closed;
            }

            _originalText = Text;

            if (string.IsNullOrWhiteSpace(_originalText))
            {
                IsInEditMode = true;
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes the <see cref="EditableContentControl"/> class.
        /// </summary>
        static EditableContentControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(EditableContentControl), new FrameworkPropertyMetadata(typeof(EditableContentControl)));
        }
        #endregion
    }
}
