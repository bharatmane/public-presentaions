﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// V Ships toolbar control deriving from the vanilla toolbar.
    /// Ateepts to fix the WPF layout error when binding the items in the toolbar.
    /// </summary>
    public class VToolbar : ToolBar
    {
        private FrameworkElement _overflow;

        /// <summary>
        /// Displays any additional content for the toolbar. By default this is to the right of the toolbar.
        /// </summary>
        public static readonly DependencyProperty AdditionalContentProperty =
            DependencyProperty.Register("AdditionalContent", typeof(object), typeof(VToolbar), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="AdditionalContentProperty"/> DependencyProperty.
        /// </summary>
        public object AdditionalContent
        {
            get { return GetValue(AdditionalContentProperty); }
            set { SetValue(AdditionalContentProperty, value); }
        }

        static VToolbar()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VToolbar), new FrameworkPropertyMetadata(typeof(VToolbar)));
        }

        /// <summary>
        /// Applies the default template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            _overflow = Template.FindName("Overflow", this) as FrameworkElement;
            base.OnApplyTemplate();
            //Workaround for problems with the vanilla toolbar.
            Dispatcher.BeginInvoke(new Action(() =>
            {
                InvalidateMeasure();
                InvalidateVisual();
            }), DispatcherPriority.Background);

            SizeChanged += OnSizeChanged;
        }

        private void OnSizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (_overflow != null)
            {
                _overflow.Visibility = HasOverflowItems ? Visibility.Visible : Visibility.Collapsed;
            }
        }
    }
}
