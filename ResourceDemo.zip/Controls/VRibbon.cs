﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Resource.Common.Extensions;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A specialised toolbar control that acts similiar to a ribbon.
    /// </summary>
    public class VRibbon : ItemsControl
    {
        /// <summary>
        /// Additional details which by default displays on the right of the ribbon.
        /// </summary>
        public static readonly DependencyProperty AdditionalDetailsProperty =
            DependencyProperty.Register("AdditionalDetails", typeof(object), typeof(VRibbon), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="AdditionalDetails"/> DependencyProperty.
        /// </summary>
        public object AdditionalDetails
        {
            get { return GetValue(AdditionalDetailsProperty); }
            set { SetValue(AdditionalDetailsProperty, value); }
        }

        /// <summary>
        /// Additional details template.
        /// </summary>
        public static readonly DependencyProperty AdditionalDetailsTemplateProperty =
            DependencyProperty.Register("AdditionalDetailsTemplate", typeof(DataTemplate), typeof(VRibbon), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="AdditionalDetailsTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate AdditionalDetailsTemplate
        {
            get { return (DataTemplate)GetValue(AdditionalDetailsTemplateProperty); }
            set { SetValue(AdditionalDetailsTemplateProperty, value); }
        }

        /// <summary>
        /// The is hidden property
        /// </summary>
        public static readonly DependencyProperty IsHiddenProperty =
            DependencyProperty.Register("IsHidden", typeof(bool), typeof(VRibbon), new PropertyMetadata(false, OnIsHiddenChanged));

        /// <summary>
        /// Gets or sets a value indicating whether this instance is hidden.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is hidden; otherwise, <c>false</c>.
        /// </value>
        public bool IsHidden
        {
            get { return (bool)GetValue(IsHiddenProperty); }
            set { SetValue(IsHiddenProperty, value); }
        }        

        /// <summary>
        /// Gets or sets a value indicating whether [enable expander].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [enable expander]; otherwise, <c>false</c>.
        /// </value>
        public bool IsRibbonCollapsible
        {
            get { return (bool)GetValue(IsRibbonCollapsibleProperty); }
            set { SetValue(IsRibbonCollapsibleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsRibbonCollapsible.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The enable expander property
        /// </summary>
        public static readonly DependencyProperty IsRibbonCollapsibleProperty =
            DependencyProperty.Register("IsRibbonCollapsible", typeof(bool), typeof(VRibbon), new PropertyMetadata(false));

        static VRibbon()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VRibbon), new FrameworkPropertyMetadata(typeof(VRibbon)));
        }

        /// <summary>
        /// Checks if the item is of type <see cref="SortItemControl"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VRibbonGroup;
        }

        /// <summary>
        /// Returns a new item of type <see cref="SortItemControl"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VRibbonGroup();
        }
       
        /// <summary>
        /// Raises the <see cref="E:System.Windows.FrameworkElement.Initialized"/> event. This method is invoked whenever <see cref="P:System.Windows.FrameworkElement.IsInitialized"/> is set to true internally.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Windows.RoutedEventArgs"/> that contains the event data.</param>
        protected override void OnInitialized(EventArgs e)
        {
            CreateDynamicRibbonGroups();            
        }

        /// <summary>
        /// Creates the dynamic ribbon groups.
        /// </summary>
        public async void CreateDynamicRibbonGroups()
        {
            DynamicVRibbonGroups dynamicVRibbon = new DynamicVRibbonGroups();
            var vRibbonGroups = await dynamicVRibbon.GetAllGroups();
            if (vRibbonGroups != null && vRibbonGroups.Any())
            {
                foreach (var item in vRibbonGroups)
                {
                    Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Called when [is hidden changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsHiddenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VRibbon)d;
            ItemCollection listOfGroups = control.Items;            
            foreach (var child in listOfGroups)
            {
                ((VRibbonGroup)child).IsHidden = control.IsHidden;
                ((VRibbonGroup)child).IsCollapsed = control.IsHidden;
                if (((VRibbonGroup)child).Items.Count > 0)
                {
                    var item = ((VRibbonGroup)child).Items.GetItemAt(0);
                    if (control.IsHidden && ((VRibbonGroup)child).IsSingle && item is VShips.Framework.Common.ViewModel.Menu.MenuItemDropDownButton)
                    {
                        ((VShips.Framework.Common.ViewModel.Menu.MenuItemDropDownButton)item).DisplaySize = Framework.Common.ViewModel.Menu.DisplaySize.TextOnly;
                    }
                    else if (!control.IsHidden && ((VRibbonGroup)child).IsSingle && item is VShips.Framework.Common.ViewModel.Menu.MenuItemDropDownButton)
                    {
                        ((VShips.Framework.Common.ViewModel.Menu.MenuItemDropDownButton)item).DisplaySize = ((VShips.Framework.Common.ViewModel.Menu.MenuItemDropDownButton)item).OriginalDisplaySize.Value;
                    }
                }                
            }
        }

        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e)
        {
            OnIsHiddenChanged(this, new DependencyPropertyChangedEventArgs());
            base.OnItemsChanged(e);
        }
    }
}
