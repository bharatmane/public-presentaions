﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Practices.ServiceLocation;
using Telerik.Windows.Controls;
using VShips.Framework.Common.Services;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that mixes a windows titlebar with a tab control.
    /// </summary>
    public class TitlebarTabControl : RadTabControl
    {
        /// <summary>
        /// The geometry LogoData of the path
        /// </summary>
        public static readonly DependencyProperty LogoDataProperty =
            DependencyProperty.Register("LogoData", typeof(Geometry), typeof(TitlebarTabControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="LogoDataProperty"/> DependencyProperty.
        /// </summary>
        public Geometry LogoData
        {
            get { return (Geometry)GetValue(LogoDataProperty); }
            set { SetValue(LogoDataProperty, value); }
        }

        /// <summary>
        /// The geometry QuickLinksData of the path
        /// </summary>
        public static readonly DependencyProperty QuickLinksDataProperty =
            DependencyProperty.Register("QuickLinksData", typeof(Geometry), typeof(TitlebarTabControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="QuickLinksDataProperty"/> DependencyProperty.
        /// </summary>
        public Geometry QuickLinksData
        {
            get { return (Geometry)GetValue(QuickLinksDataProperty); }
            set { SetValue(QuickLinksDataProperty, value); }
        }

        /// <summary>
        /// The state of the window that the titlebar control relates to.
        /// </summary>
        public static readonly DependencyProperty WindowStateProperty =
            DependencyProperty.Register("WindowState", typeof(WindowState), typeof(TitlebarTabControl), new FrameworkPropertyMetadata(WindowState.Maximized, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        /// <summary>
        /// Exposes the <see cref="WindowStateProperty"/> DependencyProperty.
        /// </summary>
        public WindowState WindowState
        {
            get { return (WindowState)GetValue(WindowStateProperty); }
            set { SetValue(WindowStateProperty, value); }
        }

        /// <summary>
        /// If the main menu of the app is open.
        /// </summary>
        public static readonly DependencyProperty IsMenuOpenProperty =
            DependencyProperty.Register("IsMenuOpen", typeof(bool), typeof(TitlebarTabControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsMenuOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool IsMenuOpen
        {
            get { return (bool)GetValue(IsMenuOpenProperty); }
            set { SetValue(IsMenuOpenProperty, value); }
        }

        /// <summary>
        /// If the main menu of the app is open.
        /// </summary>
        public static readonly DependencyProperty IsMenuEnabledProperty =
            DependencyProperty.Register("IsMenuEnabled", typeof(bool), typeof(TitlebarTabControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsMenuEnabled" /> DependencyProperty.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is menu enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsMenuEnabled
        {
            get { return (bool)GetValue(IsMenuEnabledProperty); }
            set { SetValue(IsMenuEnabledProperty, value); }
        }

        private Window _mainWindow;
        /// <summary>
        /// Gets the related window.
        /// </summary>
        public Window MainWindow
        {
            get { return _mainWindow ?? (_mainWindow = UIHelper.FindVisualParent<Window>(this)); }
        }

        static TitlebarTabControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TitlebarTabControl), new FrameworkPropertyMetadata(typeof(TitlebarTabControl)));
        }

        /// <summary>
        /// Applies the template for the control.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            var dragPanel = Template.FindName("PART_HeaderBorder", this) as Border;
            if (dragPanel != null)
            {
                dragPanel.MouseDown += DragPanelOnMouseDown;
                dragPanel.MouseMove += DragPanel_MouseMove;
            }

            var min = Template.FindName("PART_Minimise", this) as Button;
            if (min != null)
            {
                min.Click += MinOnClick;
            }

            var max = Template.FindName("PART_Max", this) as Button;
            if (max != null)
            {
                max.Click += MaxOnClick;
            }

            var close = Template.FindName("PART_Close", this) as Button;
            if (close != null)
            {
                close.Click += CloseOnClick;
            }
        }

        /// <summary>
        /// Handles the MouseMove event of the DragPanel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="MouseEventArgs"/> instance containing the event data.</param>
        private void DragPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Released && MainWindow.WindowState == WindowState.Normal && MainWindow.Top == 0)
            {
                MainWindow.WindowState = WindowState.Maximized;
            }
            else if (e.LeftButton == MouseButtonState.Pressed)
            {
                var dragPanel = Template.FindName("PART_HeaderBorder", this) as Border;
                var source = e.Source as Border;
                var grid = UIHelper.FindVisualChildren<Grid>(sender as Border).FirstOrDefault();
                var button = grid.ChildrenOfType<PathToggleButton>().Where(x => x.Name == "PART_IconButton").FirstOrDefault() as PathToggleButton;                
                if (source != null && source.Name == dragPanel.Name && source.IsMouseOver && source.IsMouseDirectlyOver && button.IsHitTestVisible)
                {
                    //Setting Top and left as zero prevents the window from moving to previous coordinate on the screen.
                    MainWindow.Left = 0;
                    MainWindow.Top = 0;
                    MainWindow.WindowState = WindowState.Normal;
                    MainWindow.DragMove();
                }
            }
        }

        private void CloseOnClick(object sender, RoutedEventArgs e)
        {
            ServiceLocator.Current.GetInstance<IDialogService>().Confirm("Close Application?", o =>
            {
                if (o == true)
                {
                    MainWindow.Close();
                }
            });
        }

        private void MaxOnClick(object sender, RoutedEventArgs e)
        {
            MainWindow.Top = 20;
            WindowState = MainWindow.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void MinOnClick(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void DragPanelOnMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (e.ClickCount == 2)
                {
                    if (MainWindow.WindowState == WindowState.Maximized)
                    {
                        MainWindow.Top = 20;
                    }
                    WindowState = MainWindow.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
                }
                else
                {
                    if (e.LeftButton == MouseButtonState.Pressed)
                    {
                        MainWindow.DragMove();
                    }
                }
            }
        }

        /// <summary>
        /// True if the item is of type <see cref="TitleBarTabItem"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is TitleBarTabItem;
        }

        /// <summary>
        /// Returns a new <see cref="TitleBarTabItem"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new TitleBarTabItem();
        }

        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var tab = (TitleBarTabItem) element;
            tab.ContextMenu = CreateContextMenu(tab);
            base.PrepareContainerForItemOverride(element, item);
        }

        private ContextMenu CreateContextMenu(TitleBarTabItem tab)
        {
            var menu = new ContextMenu();
            var close = new MenuItem{Header = "Close tab", Command = new DelegateCommand(o => CloseTab(tab), o => tab.CanClose)};
            var closeOther = new MenuItem { Header = "Close other tabs", Command = new DelegateCommand(o => CloseOtherTabs(tab)) };
            var closeRight = new MenuItem { Header = "Close tabs to the right", Command = new DelegateCommand(o => CloseRightTabs(tab)) };
            menu.Items.Add(close);
            menu.Items.Add(closeOther);
            menu.Items.Add(closeRight);
            return menu;
        }

        private void CloseRightTabs(TitleBarTabItem tab)
        {
            var index = ItemContainerGenerator.IndexFromContainer(tab) + 1;
            var total = (ItemsSource != null ? ItemsSource.OfType<object>().Count() : 0);

            if (index < total)
            {
                var itemsToClose = new List<TitleBarTabItem>();
                for (var x = index; x < total; x++)
                {
                    var itemTab = ItemContainerGenerator.ContainerFromIndex(x) as TitleBarTabItem;
                    if (itemTab != null)
                    {
                        itemsToClose.Add(itemTab);
                    }
                }
                foreach (var itemTab in itemsToClose)
                {
                    CloseTab(itemTab);
                }
                if (tab != null) tab.IsSelected = true;
            }
        }

        private void CloseOtherTabs(TitleBarTabItem tab)
        {
            if (ItemsSource != null)
            {
                foreach (var item in ItemsSource.OfType<object>().ToList())
                {
                    var itemTab = ItemContainerGenerator.ContainerFromItem(item) as TitleBarTabItem;
                    if (!Equals(itemTab, tab))
                    {
                        CloseTab(itemTab);
                    }
                }
                if (tab != null) tab.IsSelected = true;
            }
        }

        private void CloseTab(TitleBarTabItem tab)
        {
            if (tab != null)
            {
                if (tab.CloseCommand != null && tab.CanClose)
                {
                    tab.CloseCommand.Execute(null);
                }
            }
        }
    }
}
