﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Shapes;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Implementation of VCallout
    /// </summary>
    public class VCallOut : PathDropDownButton
    {
        #region Private variables
        /// <summary>
        /// The button position
        /// </summary>                                                   
        private ContentPresenter _buttonPosition = null;
        /// <summary>
        /// The callout detail popup
        /// </summary>
        private Popup _calloutDetailPopup = null;
        /// <summary> 
        /// The callout popup
        /// </summary>
        private Popup _calloutPopup = null;
        /// <summary>
        /// The call out up path
        /// </summary>
        private Path _callOutUpPath = null;
        /// <summary>
        /// The call out down path
        /// </summary>
        private Path _callOutDownPath = null;
        /// <summary>
        /// The drop down popup border
        /// </summary>
        private Border _dropDownPopupBorder = null;
        /// <summary>
        /// The cover
        /// </summary>
        private Path _pathCoverUp = null;
        /// <summary>
        /// The path line cover
        /// </summary>
        private Line _pathLineCover = null;
        /// <summary>
        /// The top coordinate
        /// </summary>
        private int topCoordinate = 0;
        #endregion

        #region Dependency Properties
        /// <summary>
        /// The is data loading property. Using a DependencyProperty as the backing store for IsDataLoading.  This enables animation, styling, binding, etc...
        /// </summary>
        public static readonly DependencyProperty IsDataLoadingProperty =
            DependencyProperty.Register("IsDataLoading", typeof(bool), typeof(VCallOut), new PropertyMetadata(OnIsDataLoadingChanged));
        /// <summary>
        /// Gets or sets a value indicating whether this instance is data loading.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is data loading; otherwise, <c>false</c>.
        /// </value>
        public bool IsDataLoading
        {
            get { return (bool)GetValue(IsDataLoadingProperty); }
            set { SetValue(IsDataLoadingProperty, value); }
        }

        /// <summary>
        /// The no details found label property
        /// </summary>
        public static readonly DependencyProperty NoDetailsFoundLabelProperty =
            DependencyProperty.Register("NoDetailsFoundLabel", typeof(string), typeof(VCallOut), new PropertyMetadata("No data found."));
        /// <summary>
        /// Gets or sets the no details found label.
        /// </summary>
        /// <value>
        /// The no details found label.
        /// </value>
        public string NoDetailsFoundLabel
        {
            get { return (string)GetValue(NoDetailsFoundLabelProperty); }
            set { SetValue(NoDetailsFoundLabelProperty, value); }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Called when [is data loading changed].
        /// </summary>
        /// <param name="d">The Dependency Object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsDataLoadingChanged(DependencyObject d, DependencyPropertyChangedEventArgs eventArgs)
        {
            if (!(bool)eventArgs.NewValue)
            {
                var callout = (VCallOut)d;
                if (callout.IsOpen)
                {
                    callout.AdjustCalloutAnchor();
                }
            }
        }
        #endregion

        #region Overridden Methods
        /// <summary>
        /// Called when [is open changed].
        /// </summary>
        /// <param name="newValue">if set to <c>true</c> [new value].</param>
        /// <param name="oldValue">if set to <c>true</c> [old value].</param>
        protected override void OnIsOpenChanged(bool newValue, bool oldValue)
        {
            base.OnIsOpenChanged(newValue, oldValue);

            if (newValue)
            {
                _calloutDetailPopup.BringIntoView();
                AdjustCalloutAnchor();
            }
        }

        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            _buttonPosition = Template.FindName("ContentPresenterContent", this) as ContentPresenter;
            _calloutDetailPopup = Template.FindName("DropDownPopup", this) as Popup;
            _calloutPopup = Template.FindName("PopupCallout", this) as Popup;
            _callOutUpPath = Template.FindName("PathButtonUp", this) as Path;
            _callOutDownPath = Template.FindName("PathButtonDown", this) as Path;
            _dropDownPopupBorder = Template.FindName("DropDownPopupBorder", this) as Border;
            if(_dropDownPopupBorder != null)
            {
                _dropDownPopupBorder.SizeChanged += CallOutDetailPopupSizeChanged;
            }
            _pathCoverUp = Template.FindName("PathCoverUp", this) as Path;
            if(Template.FindName("PathLineCover", this) != null)
            {
                _pathLineCover = Template.FindName("PathLineCover", this) as Line;
            }
        }

        /// <summary>
        /// Calls the out detail popup size changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void CallOutDetailPopupSizeChanged(object sender, SizeChangedEventArgs e)
        {
            AdjustCalloutAnchor();
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Adjusts the callout anchor.
        /// </summary>
        private void AdjustCalloutAnchor()
        {
            if (_buttonPosition == null || _calloutDetailPopup == null || _calloutPopup == null || _callOutUpPath == null || _callOutDownPath == null || _pathCoverUp == null || _dropDownPopupBorder == null || _buttonPosition.IsVisible == false)
            {
                return;
            }
            var elementPoint = _buttonPosition.PointToScreen(new Point(0, 0));
            var popupSize = _calloutDetailPopup.Child.DesiredSize;
            var resolution = System.Windows.Forms.Screen.PrimaryScreen.Bounds;

            var currentHeight = Application.Current.MainWindow.ActualHeight;
            var currentWidth = Application.Current.MainWindow.ActualWidth;

            var Top = Application.Current.MainWindow.WindowState == WindowState.Maximized ? 0 : Application.Current.MainWindow.RestoreBounds.Top;
            var Left = Application.Current.MainWindow.WindowState == WindowState.Maximized ? 0 :  Application.Current.MainWindow.RestoreBounds.Left;

            if ((elementPoint.Y) + _buttonPosition.ActualHeight + popupSize.Height + 12 >= currentHeight + Top)
            {
                _callOutDownPath.Visibility = Visibility.Visible;
                _callOutUpPath.Visibility = Visibility.Collapsed;
                topCoordinate = -11;
            }
            else
            {
                _callOutDownPath.Visibility = Visibility.Collapsed;
                _callOutUpPath.Visibility = Visibility.Visible;
                topCoordinate = 11;
            }

            if (_callOutDownPath.Visibility == Visibility.Visible)
            {
                _calloutDetailPopup.Placement = PlacementMode.Top;
                _calloutPopup.Placement = PlacementMode.Top;
            }
            else
            {
                _calloutDetailPopup.Placement = PlacementMode.Bottom;
                _calloutPopup.Placement = PlacementMode.Bottom;
            }

            if ((elementPoint.X) + popupSize.Width >= currentWidth + Left)
            {
                _calloutDetailPopup.HorizontalOffset = 60 - popupSize.Width;
            }
            else
            {
                _calloutDetailPopup.HorizontalOffset = -20;
            }
            _calloutPopup.HorizontalOffset = (_buttonPosition.ActualWidth / 2) - 12;

            //Code for solving the issue of line which comes above the triangle when tooltip appears
            if(_pathLineCover != null)
            {
                _pathLineCover.VerticalAlignment = topCoordinate == 11 ? VerticalAlignment.Top : VerticalAlignment.Bottom;
                if (_pathCoverUp.IsVisible)
                {
                    Point coverPoint = _pathCoverUp.PointToScreen(new Point(0, 0));
                    Point borderPoint = _dropDownPopupBorder.PointToScreen(new Point(0, 0));

                    _pathLineCover.X1 = coverPoint.X - borderPoint.X + 4;
                    _pathLineCover.Y1 = topCoordinate;
                    _pathLineCover.X2 = (coverPoint.X - borderPoint.X) + 19 + 5;
                    _pathLineCover.Y2 = topCoordinate;
                }
            }
        }

        /// <summary>
        /// Override that closes the popup if closes on click is true.
        /// </summary>
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            Control control = e.OriginalSource as Control;

            if (control != null)
            {
                bool closeCallOutOnControlClick = (bool) control.GetValue(ControlHelper.CloseCallOutOnClickProperty);

                if (IsOpen && (ClosesOnClick || closeCallOutOnControlClick))
                {
                    IsOpen = false;
                }
            }

            base.OnPreviewMouseUp(e);
        }

        ///This method is overridden to handle the unneccessary movement of the VCallOut, when mouse wheel is scrolled.
        /// <summary>
        /// Invoked when an unhandled <see cref="E:System.Windows.Input.Mouse.PreviewMouseWheel" /> attached event reaches an element in its route that is derived from this class. Implement this method to add class handling for this event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Windows.Input.MouseWheelEventArgs" /> that contains the event data.</param>
        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e)
        {            
            //This if is to handle all the Mouse Wheel event done outside the VCallOut when VCallOut is opened.
            if (IsOpen && ((UIElement)e.OriginalSource).IsMouseCaptureWithin)
            {
                var control = ((UIElement)e.OriginalSource);

                control = UIHelper.FindVisualParent<ScrollViewer>(control as DependencyObject, null);

                if (control != null && control is ScrollViewer && (control as ScrollViewer).ComputedVerticalScrollBarVisibility == Visibility.Visible)
                {
                    IsOpen = false;
                }

            }
            //This else is to handle all the Mouse Wheel event done inside the VCallOut when VCallOut is opened.
            else
            {

                //if (!((UIElement)e.Source).IsMouseDirectlyOver)
                //{
                //    IsOpen = false;
                //}
                //This is the VCallOut that is opened.
                var parent = ((UIElement)e.OriginalSource);

                //This is to get any scrollviewer available inside the VCallOut.
                parent = UIHelper.FindVisualParent<ScrollViewer>(parent as DependencyObject, null);

                var scroll = (parent as ScrollViewer);
                //This locks the scroll event inside the VCallout only.
                if (scroll != null && scroll.VerticalOffset == 0 && e.Delta > 0)
                {
                    e.Handled = true;
                }
                if (scroll != null && scroll.ScrollableHeight == scroll.VerticalOffset && e.Delta < 0)
                {
                    e.Handled = true;
                }
                
                //This if checks whether the VCallOut has Mouse Directly Over it and to check that Source that raised the event does not have the Mouse Directly over it and its not a Scollviewer.
                //This means, if the Mouse wheel event happened inside the VCallOut which does not have any scrollable element, then the event is handled.
                if (((UIElement)e.OriginalSource).IsMouseDirectlyOver && !((UIElement)e.Source).IsMouseDirectlyOver && parent == null)
                {
                    e.Handled = true;
                }
                //This else if checks whether the parent is ScollViewer and is Not Null and the ComputedVerticalScrollBarVisibility of the Scrollviewer is Not Visible.
                //This means, if the Mouse wheel event happened inside the VCallOut contains a GridView and has Vertical Scroll Bar visible, 
                //when user scrolls even beyond when last or first element is reached, that event needs to be handled.
                else if (parent is ScrollViewer && parent != null && (parent as ScrollViewer).ComputedVerticalScrollBarVisibility != Visibility.Visible)
                {
                    e.Handled = true;
                }
            }
        }
        #endregion
    }
}