﻿using GalaSoft.MvvmLight.Command;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A checkbox column for the vgridview.
    /// </summary>
    public sealed class VGridViewCheckboxColumn : GridViewBoundColumnBase
    {
        /// <summary>
        /// Gets or sets the cancel row edit command.
        /// </summary>
        /// <value>
        /// The cancel row edit command.
        /// </value>
        public RelayCommand<object> CancelRowEditCommand
        {
            get { return (RelayCommand<object>)GetValue(CancelRowEditCommandProperty); }
            set { SetValue(CancelRowEditCommandProperty, value); }
        }

        /// <summary>
        /// The cancel row edit command property
        /// </summary>
        public static readonly DependencyProperty CancelRowEditCommandProperty =
            DependencyProperty.Register("CancelRowEditCommand", typeof(RelayCommand<object>), typeof(VGridViewCheckboxColumn), new PropertyMetadata(new RelayCommand<object>(ExecuteCommand)));

        /// <summary>
        /// Executes the command.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        private static void ExecuteCommand(object parameter)
        {
            var cancelCommand = RadGridViewCommands.CancelRowEdit as RoutedUICommand;
            cancelCommand.Execute(null, (parameter as VGridView));
        }


        private Binding _headerBinding;
        /// <summary>
        /// The binding used to set the checkbox header binding.
        /// </summary>
        public Binding HeaderBinding
        {
            get { return _headerBinding; }
            set { _headerBinding = value; }
        }

        private object _header;
        /// <summary>
        /// The cell header. By default this is a checkbox.
        /// </summary>
        public override object Header
        {
            get
            {
                if (_header == null)
                {
                    var header = new CheckBox
                    {
                        Padding = new Thickness(0),
                        Margin = new Thickness(0),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        DataContext = DataContext,
                        Style = FindResource("GridViewCheckBoxStyle") as Style //TODO : Rahul - Remove Once modified style for CheckBox is final
                    };
                    _header = header;
                    UpdateHeaderBinding(header);
                }
                return _header;
            }
            set { _header = value; }
        }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public VGridViewCheckboxColumn()
        {
            IsSortable = false;
            IsFilterable = false;
            IsResizable = false;
            IsGroupable = false;
            IsReorderable = false;
            CellStyle = FindResource("GridViewCellZeroPaddingStyleCustom") as Style;
        }

        /// <summary>
        /// Updates the header binding.
        /// </summary>
        /// <param name="header">The header.</param>
        private void UpdateHeaderBinding(CheckBox header)
        {
            if (HeaderBinding != null && HeaderBinding.Path != null)
            {
                SetupValueBinding(header, HeaderBinding);
            }
        }

        /// <summary>
        /// Creates the columns edit cell.
        /// </summary>
        public override FrameworkElement CreateCellElement(GridViewCell cell, object dataItem)
        {
            var _row = (cell.ParentRow as GridViewNewRow);
            if ((_row != null) && (_row.IsVisible))
            {
                var button = new PathButton
                {
                    Command = RadGridViewCommands.CancelRowEdit,
                    CommandTarget = (IInputElement)cell.Column.Parent,
                    Data = TryFindResource("CrossGeometry") as Geometry,
                    Style = TryFindResource("SmallInternalPathButtonStyle") as Style,
                    EllipseSize = 10,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    PathStrokeThickness = 1
                };
                return button;                
            }

            var checkBox = new CheckBox { Padding = new Thickness(0), Margin = new Thickness(0), HorizontalAlignment = HorizontalAlignment.Center, Style = FindResource("GridViewCheckBoxStyle") as Style }; //TODO : Rahul - Remove Style property Once modified style for CheckBox is final
            SetupValueBinding(checkBox, DataMemberBinding);
            return checkBox;

        }

        /// <summary>
        /// Creates the cell edit element.
        /// </summary>
        public override FrameworkElement CreateCellEditElement(GridViewCell cell, object dataItem)
        {            
            var _row = (cell.ParentRow as GridViewNewRow);
            if ((_row != null) && (_row.IsVisible))
            {
                return base.CreateCellEditElement(cell, dataItem);
            }
            return base.CreateCellElement(cell, dataItem);
        }

        /// <summary>
        /// Setups the value binding.
        /// </summary>
        /// <param name="control">The control.</param>
        /// <param name="DataMemberBinding">The data member binding.</param>
        private void SetupValueBinding(CheckBox control, Binding DataMemberBinding)
        {
            control.SetBinding(CheckBox.IsCheckedProperty, DataMemberBinding);
            if (IsReadOnlyBinding != null)
            {
                control.SetBinding(CheckBox.IsEnabledProperty, IsReadOnlyBinding);
            }
        }
    }    
}
