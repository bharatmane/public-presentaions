﻿using GalaSoft.MvvmLight.Command;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Custom column for VGridViewSelectColumn
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.GridViewSelectColumn" />
    public class VGridViewSelectColumn : GridViewSelectColumn
    {
        /// <summary>
        /// Gets or sets the cancel row edit command.
        /// </summary>
        /// <value>
        /// The cancel row edit command.
        /// </value>
        public RelayCommand<object> CancelRowEditCommand
        {
            get { return (RelayCommand<object>)GetValue(CancelRowEditCommandProperty); }
            set { SetValue(CancelRowEditCommandProperty, value); }
        }

        /// <summary>
        /// The cancel row edit command property
        /// </summary>
        public static readonly DependencyProperty CancelRowEditCommandProperty =
            DependencyProperty.Register("CancelRowEditCommand", typeof(RelayCommand<object>), typeof(VGridViewSelectColumn), new PropertyMetadata(new RelayCommand<object>(ExecuteCommand)));

        /// <summary>
        /// Executes the command.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        private static void ExecuteCommand(object parameter)
        {
            var cancelCommand = RadGridViewCommands.CancelRowEdit as RoutedUICommand;
            cancelCommand.Execute(null, (parameter as VGridView));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VGridViewSelectColumn" /> class.
        /// </summary>
        public VGridViewSelectColumn()
        {
            IsSortable = false;
            IsReadOnly = false;

            //This style is created for the checkbox in header of the column
            Style style = new Style(typeof(CheckBox), (FindResource("GridViewCheckBoxStyle") as Style));
            style.Setters.Add(new Setter(CheckBox.HorizontalAlignmentProperty, HorizontalAlignment.Center));
            style.Setters.Add(new Setter(CheckBox.PaddingProperty, new Thickness(0)));
            HeaderCheckBoxStyle = style;

            CellStyle = FindResource("GridViewCellZeroPaddingStyleCustom") as Style;
        }

        /// <summary>
        /// Creates the cell element.
        /// </summary>
        /// <param name="cell">The cell.</param>
        /// <param name="dataItem">The data item.</param>
        /// <returns></returns>
        public override FrameworkElement CreateCellElement(GridViewCell cell, object dataItem)
        {
            var ce = (cell.ParentRow as GridViewNewRow);
            if ((ce != null) && (ce.IsVisible))
            {
                cell.Column.IsReadOnly = false;
                var button = new PathButton
                {
                    Command = RadGridViewCommands.CancelRowEdit,
                    CommandTarget = (IInputElement)cell.Column.Parent,
                    Data = TryFindResource("CrossGeometry") as Geometry,
                    Style = TryFindResource("SmallInternalPathButtonStyle") as Style,
                    EllipseSize = 10,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    PathStrokeThickness = 1
                };
                return button;
            }

            CheckBox checkBox = new CheckBox { Padding = new Thickness(0), Margin = new Thickness(0), HorizontalAlignment = HorizontalAlignment.Center, Style = FindResource("GridViewCheckBoxStyle") as Style };
            GridViewRowItem parentRow = cell.ParentRow;
            if (parentRow != null)
                checkBox.SetBinding(ToggleButton.IsCheckedProperty, (BindingBase)new Binding("IsSelected")
                {
                    Source = parentRow,
                    Mode = BindingMode.TwoWay
                });
            return checkBox;
        }

        /// <summary>
        /// Creates the cell edit element.
        /// </summary>
        /// <param name="cell">The cell.</param>
        /// <param name="dataItem">The data item.</param>
        /// <returns></returns>
        public override FrameworkElement CreateCellEditElement(GridViewCell cell, object dataItem)
        {
            var _row = (cell.ParentRow as GridViewNewRow);
            if ((_row != null) && (_row.IsVisible))
            {
                return base.CreateCellEditElement(cell, dataItem);
            }
            return base.CreateCellElement(cell, dataItem);
        }

        /// <summary>
        /// Determines whether this instance can edit the specified item.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns>
        ///   <c>true</c> if this instance can edit the specified item; otherwise, <c>false</c>.
        /// </returns>
        public override bool CanEdit(object item)
        {
            return true;
        }
    }
}
