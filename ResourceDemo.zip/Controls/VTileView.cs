﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A specialised tile view control.
    /// </summary>
    public class VTileView : ItemsControl
    {
        /// <summary>
        /// If the control is busy or not.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(VTileView), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsBusyProperty"/> DependencyProperty.
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        static VTileView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VTileView), new FrameworkPropertyMetadata(typeof(VTileView)));
        }

        /// <summary>
        /// Checks if the item is of type <see cref="VTileViewItem"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VTileViewItem;
        }

        /// <summary>
        /// Returns a new item of type <see cref="VTileViewItem"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VTileViewItem();
        }

        
    }
}
