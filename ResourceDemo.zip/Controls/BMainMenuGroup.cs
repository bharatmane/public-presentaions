﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control representing a group in the main menu.
    /// </summary>
    public class VMainMenuGroup : Menu
    {
        /// <summary>
        /// The selected item
        /// </summary>
        private VMainMenuItem _selectedItem;
        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public VMainMenuItem SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                if (_selectedItem != null && _selectedItem != value)
                {
                    _selectedItem.IsSelected = false;
                }
                _selectedItem = value;
            }
        }
        
        /// <summary>
        /// Gets or sets the qucik links.
        /// </summary>
        /// <value>
        /// The qucik links.
        /// </value>
        public object QuickLinks
        {
            get { return (object)GetValue(QuickLinksProperty); }
            set { SetValue(QuickLinksProperty, value); }
        }

        /// <summary>
        /// The qucik links property
        /// </summary>
        public static readonly DependencyProperty QuickLinksProperty =
            DependencyProperty.Register("QuickLinks", typeof(object), typeof(VMainMenuGroup), new PropertyMetadata(null));


        /// <summary>
        /// Raised whenever the <see cref="IsSelected"/> changes.
        /// </summary>
        public static readonly RoutedEvent SelectedEvent =
            EventManager.RegisterRoutedEvent("Selected", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(VMainMenuGroup));
        /// <summary>
        /// Exposes the <see cref="SelectedEvent"/> RoutedEvent.
        /// </summary>
        public event RoutedEventHandler Selected
        {
            add { AddHandler(SelectedEvent, value); }
            remove { RemoveHandler(SelectedEvent, value); }
        }

        /// <summary>
        /// The header of the group.
        /// </summary>
        public static readonly DependencyProperty HeaderProperty =
            DependencyProperty.Register("Header", typeof(object), typeof(VMainMenuGroup), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="HeaderProperty"/> DependencyProperty.
        /// </summary>
        public object Header
        {
            get { return GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        /// <summary>
        /// The icon property
        /// </summary>
        public static readonly DependencyProperty IconProperty =
            DependencyProperty.Register("Icon", typeof(object), typeof(VMainMenuGroup), new PropertyMetadata(null));
        /// <summary>
        /// Gets or sets the icon.
        /// </summary>
        /// <value>
        /// The icon.
        /// </value>
        public object Icon
        {
            get { return (object)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }

        /// <summary>
        /// If the group is selected or expanded. 
        /// </summary>
        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(VMainMenuGroup), new PropertyMetadata(false, OnIsSelectedChanged));
        /// <summary>
        /// Exposes the <see cref="IsSelectedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }

        /// <summary>
        /// Initializes the <see cref="VMainMenuGroup"/> class.
        /// </summary>
        static VMainMenuGroup()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VMainMenuGroup), new FrameworkPropertyMetadata(typeof(VMainMenuGroup)));
        }

        /// <summary>
        /// Checks if the item is of type <see cref="VMainMenuItem"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VMainMenuItem;
        }

        /// <summary>
        /// Prepares the specified element to display the specified item.
        /// </summary>
        /// <param name="element">The element used to display the specified item.</param>
        /// <param name="item">The item to display.</param>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (VMainMenuItem)element;
            control.Selected += ControlOnSelected;
            if (control.IsSelected)
            {
                SelectedItem = control;
            }
            base.PrepareContainerForItemOverride(element, item);
        }

        /// <summary>
        /// Creates a new instance of <see cref="VMainMenuItem"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VMainMenuItem();
        }

        /// <summary>
        /// Called when [is selected changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (VMainMenuGroup)d;
            if ((bool)e.NewValue)
            {
                control.RaiseSelected();
            }
        }

        /// <summary>
        /// Controls the on selected.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void ControlOnSelected(object sender, RoutedEventArgs e)
        {
            SelectedItem = (VMainMenuItem)sender;
        }

        /// <summary>
        /// Raises the selected.
        /// </summary>
        private void RaiseSelected()
        {
            var newEventArgs = new RoutedEventArgs(SelectedEvent);
            RaiseEvent(newEventArgs);
        }

    }
}
