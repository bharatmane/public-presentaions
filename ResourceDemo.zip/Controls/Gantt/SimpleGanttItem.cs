﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// Represents an item in the <see cref="SimpleGanttChart"/>
    /// </summary>
    public class SimpleGanttItem : ContentControl
    {
        private AdornerLayer _adornerLayer;
        private SimpleGanttLabelAdorner _adorner;
        private bool _previousLabelVis;

        /// <summary>
        /// The start date of the item.
        /// </summary>
        public static readonly DependencyProperty StartDateProperty = 
            DependencyProperty.Register("StartDate", typeof(DateTime?), typeof(SimpleGanttItem), new PropertyMetadata(DateTime.Now));
        /// <summary>
        /// Exposes the <see cref="StartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime? StartDate
        {
            get { return (DateTime?)GetValue(StartDateProperty); }
            set { SetValue(StartDateProperty, value); }
        }

        /// <summary>
        /// The end date of the item.
        /// </summary>
        public static readonly DependencyProperty EndDateProperty =
            DependencyProperty.Register("EndDate", typeof(DateTime?), typeof(SimpleGanttItem), new PropertyMetadata(DateTime.Now));
        /// <summary>
        /// Exposes the <see cref="EndDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime? EndDate
        {
            get { return (DateTime?)GetValue(EndDateProperty); }
            set { SetValue(EndDateProperty, value); }
        }

        /// <summary>
        /// Shows the label on the adorner layer.
        /// </summary>
        public static readonly DependencyProperty ShowLabelProperty = 
            DependencyProperty.Register("ShowLabel", typeof(bool), typeof(SimpleGanttItem), new PropertyMetadata(false, OnShowLabelChanged));
        /// <summary>
        /// Exposes the <see cref="ShowLabelProperty"/> DependencyProperty.
        /// </summary>
        public bool ShowLabel
        {
            get { return (bool)GetValue(ShowLabelProperty); }
            set { SetValue(ShowLabelProperty, value); }
        }

        /// <summary>
        /// The datat template for the label shown on the adorner layer.
        /// </summary>
        public static readonly DependencyProperty LabelTemplateProperty = 
            DependencyProperty.Register("LabelTemplate", typeof(DataTemplate), typeof(SimpleGanttItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="LabelTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate LabelTemplate
        {
            get { return (DataTemplate)GetValue(LabelTemplateProperty); }
            set { SetValue(LabelTemplateProperty, value); }
        }

        /// <summary>
        /// True if the item is selected.
        /// </summary>
        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(SimpleGanttItem), new PropertyMetadata(false, OnIsSelectedChanged));
        /// <summary>
        /// Exposes the <see cref="LabelTemplateProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }

        static SimpleGanttItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SimpleGanttItem), new FrameworkPropertyMetadata(typeof(SimpleGanttItem)));
        }

        public override void OnApplyTemplate()
        {
            IsVisibleChanged += (sender, args) =>
            {
                if (IsVisible)
                {
                    ShowLabel = _previousLabelVis;
                }
                else
                {
                    HideLabelWithPrevious();
                }
            };
            base.OnApplyTemplate();
        }

        private static void OnShowLabelChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SimpleGanttItem) d;
            if ((bool) e.NewValue)
            {
                control.DisplayLabel();
            }
            else
            {
                control.HideLabel();
            }
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            var row = UIHelper.FindVisualParent<SimpleGanttRow>(this);
            if (row != null)
            {
                row.UnSelectAll(this);
            }
            IsSelected = true;
            base.OnMouseLeftButtonDown(e);
        }

        private static void OnIsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SimpleGanttItem) d;
            control.OnIsSelectedChanged();
        }

        private void OnIsSelectedChanged()
        {
            var row = UIHelper.FindVisualParent<SimpleGanttRow>(this);
            if (row != null)
            {
                if (IsSelected)
                {
                    row.AddToSelected(this);
                }
                else
                {
                    row.RemoveFromSelected(this);
                }
            }
        }

        private void DisplayLabel()
        {
            if (LabelTemplate != null)
            {
                _adornerLayer = AdornerLayer.GetAdornerLayer(this);
                _adorner = new SimpleGanttLabelAdorner(this) { Child = CreateLabelControl() };
                _adornerLayer.Add(_adorner);
            }
        }

        private void HideLabel()
        {
            if (_adornerLayer != null)
            {
                _adornerLayer.Remove(_adorner);
                _adornerLayer = null;
                _adorner = null;
            }
        }

        internal void HideLabelWithPrevious()
        {
            if (ShowLabel)
            {
                _previousLabelVis = true;
                ShowLabel = false;
            }
        }

        private ContentControl CreateLabelControl()
        {
            var control = new ContentControl
            {
                ContentTemplate = LabelTemplate, 
                Content = DataContext
            };
            return control;
        }
    }
}
