﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// Provides a scrollbar for the <see cref="SimpleGanttChart"/>.
    /// </summary>
    public class SimpleGanttScrollbar : ScrollBar
    {
        private bool _isUpdating;
        /// <summary>
        /// The minimum scrollable start date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartMinimumDateProperty =
            DependencyProperty.Register("ChartMinimumDate", typeof(DateTime), typeof(SimpleGanttScrollbar), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1), FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartMinimumDate
        {
            get { return (DateTime)GetValue(ChartMinimumDateProperty); }
            set { SetValue(ChartMinimumDateProperty, value); }
        }

        /// <summary>
        /// The maximum scrollable end date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartMaximumDateProperty =
            DependencyProperty.Register("ChartMaximumDate", typeof(DateTime), typeof(SimpleGanttScrollbar), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1).AddYears(1), FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartMaximumDate
        {
            get { return (DateTime)GetValue(ChartMaximumDateProperty); }
            set { SetValue(ChartMaximumDateProperty, value); }
        }

        /// <summary>
        /// The start date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartStartDateProperty =
            DependencyProperty.Register("ChartStartDate", typeof(DateTime), typeof(SimpleGanttScrollbar), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1), FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartStartDate
        {
            get { return (DateTime)GetValue(ChartStartDateProperty); }
            set { SetValue(ChartStartDateProperty, value); }
        }

        /// <summary>
        /// The end date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartEndDateProperty =
            DependencyProperty.Register("ChartEndDate", typeof(DateTime), typeof(SimpleGanttScrollbar), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1).AddYears(1), FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="ChartEndDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartEndDate
        {
            get { return (DateTime)GetValue(ChartEndDateProperty); }
            set { SetValue(ChartEndDateProperty, value); }
        }

        /// <summary>
        /// The display range for the gantt chart.
        /// </summary>
        public static readonly DependencyProperty RangeProperty =
            DependencyProperty.Register("Range", typeof(GanttRange), typeof(SimpleGanttScrollbar), new FrameworkPropertyMetadata(GanttRange.Year, FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="RangeProperty"/> DependencyProperty. 
        /// </summary>
        public GanttRange Range
        {
            get { return (GanttRange)GetValue(RangeProperty); }
            set { SetValue(RangeProperty, value); }
        }

        static SimpleGanttScrollbar()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SimpleGanttScrollbar), new FrameworkPropertyMetadata(typeof(SimpleGanttScrollbar)));
        }

        /// <summary>
        /// The default constructor for the <see cref="SimpleGanttScrollbar"/>.
        /// </summary>
        public SimpleGanttScrollbar()
        {
            Orientation = Orientation.Horizontal;
        }

        /// <summary>
        /// Ensures the scrollbar is in sync with the start and end dates.
        /// </summary>
        public override void OnApplyTemplate()
        {
            UpdateScrollbar();
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Updates the start and end dates on scroll.
        /// </summary>
        protected override void OnValueChanged(double oldValue, double newValue)
        {
            UpdateStartEndDates();
            base.OnValueChanged(oldValue, newValue);
        }

        /// <summary>
        /// Updates the render of the scrollbar when the dates change.
        /// </summary>
        /// <param name="drawingContext">The drawing context.</param>
        protected override void OnRender(DrawingContext drawingContext)
        {
            UpdateScrollbar();
            base.OnRender(drawingContext);
        }

        private void UpdateStartEndDates()
        {
            if (!_isUpdating)
            {
                var diff = (ChartEndDate - ChartStartDate).TotalMilliseconds;
                var conversion = SimpleGanttRowPanel.CalculateConversion(ChartStartDate, ChartEndDate, ActualWidth);
                var current = -SimpleGanttRowPanel.DateToPixel(ChartMinimumDate, ChartStartDate, conversion);
                var actualValue = Value - current;
                var start = SimpleGanttRowPanel.PixelToDate(ChartStartDate, ChartEndDate, actualValue, ActualWidth);
                var end = start.AddMilliseconds(diff);
                if (start > ChartEndDate)
                {
                    ChartEndDate = end;
                    ChartStartDate = start;
                }
                else
                {
                    ChartStartDate = start;
                    ChartEndDate = end;
                }  
            }
        }

        internal void UpdateScrollbar()
        {
            var conversion = SimpleGanttRowPanel.CalculateConversion(ChartStartDate, ChartEndDate, ActualWidth);
            if (conversion > 0)
            {
                _isUpdating = true;
                var current = -SimpleGanttRowPanel.DateToPixel(ChartMinimumDate, ChartStartDate, conversion);
                var max = current + SimpleGanttRowPanel.DateToPixel(ChartMaximumDate, ChartStartDate, conversion);
                var largeChangeDate = ChartStartDate.AddDays((int)Range * 4);
                var smallChangeDate = ChartStartDate.AddDays((int)Range);
                var largeChange = SimpleGanttRowPanel.DateToPixel(largeChangeDate, ChartStartDate, conversion);
                var smallChange = SimpleGanttRowPanel.DateToPixel(smallChangeDate, ChartStartDate, conversion);
                Minimum = 0;
                Maximum = max;
                ViewportSize = ActualWidth;
                LargeChange = largeChange;
                SmallChange = smallChange;
                Value = current;
                _isUpdating = false;
            }
        }
        
    }
}
