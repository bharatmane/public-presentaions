﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// Represent a row in the <see cref="SimpleGanttChart"/>.
    /// </summary>
    public class SimpleGanttRow : HeaderedItemsControl
    {
        private readonly List<SimpleGanttItem> _selectedItems = new List<SimpleGanttItem>();

        /// <summary>
        /// The start date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartStartDateProperty =
            DependencyProperty.Register("ChartStartDate", typeof(DateTime), typeof(SimpleGanttRow), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1), FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartStartDate
        {
            get { return (DateTime)GetValue(ChartStartDateProperty); }
            set { SetValue(ChartStartDateProperty, value); }
        }

        /// <summary>
        /// The end date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartEndDateProperty =
            DependencyProperty.Register("ChartEndDate", typeof(DateTime), typeof(SimpleGanttRow), new FrameworkPropertyMetadata((new DateTime(DateTime.Now.Year, 1, 1).AddYears(1)), FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));
        /// <summary>
        /// Exposes the <see cref="ChartEndDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartEndDate
        {
            get { return (DateTime)GetValue(ChartEndDateProperty); }
            set { SetValue(ChartEndDateProperty, value); }
        }

        /// <summary>
        /// The brush used in the rows header.
        /// </summary>
        public static readonly DependencyProperty HeaderBackgroundProperty = 
            DependencyProperty.Register("HeaderBackground", typeof(Brush), typeof(SimpleGanttRow), new PropertyMetadata(Brushes.White));
       /// <summary>
        /// Exposes the <see cref="HeaderBackgroundProperty"/> DependencyProperty.
       /// </summary>
        public Brush HeaderBackground
        {
            get { return (Brush)GetValue(HeaderBackgroundProperty); }
            set { SetValue(HeaderBackgroundProperty, value); }
        }

        /// <summary>
        /// True if this is the currently selected row.
        /// </summary>
        public static readonly DependencyProperty IsSelectedProperty = 
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(SimpleGanttRow), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsSelectedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }

        /// <summary>
        /// Determines if this is the row that shows the vessel postions.
        /// </summary>
        public static readonly DependencyProperty IsPositionRowProperty = 
            DependencyProperty.Register("IsPositionRow", typeof(bool), typeof(SimpleGanttRow), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsPositionRowProperty"/> DependencyProperty.
        /// </summary>
        public bool IsPositionRow
        {
            get { return (bool)GetValue(IsPositionRowProperty); }
            set { SetValue(IsPositionRowProperty, value); }
        }

        /// <summary>
        /// If true the tasks will be hidden on the row.
        /// </summary>
        public static readonly DependencyProperty HideTasksProperty =
            DependencyProperty.Register("HideTasks", typeof(bool), typeof(SimpleGanttRow), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="HideTasksProperty"/> DependencyProperty.
        /// </summary>
        public bool HideTasks
        {
            get { return (bool)GetValue(HideTasksProperty); }
            set { SetValue(HideTasksProperty, value); }
        }

        static SimpleGanttRow()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SimpleGanttRow), new FrameworkPropertyMetadata(typeof(SimpleGanttRow)));
        }

        /// <summary>
        /// Returns true if the item is of type <see cref="SimpleGanttItem"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is SimpleGanttItem;
        }

        /// <summary>
        /// Returns a new <see cref="SimpleGanttItem"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new SimpleGanttItem();
        }

        /// <summary>
        /// Ensures there is no adorner lying around.
        /// </summary>
        protected override void ClearContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (SimpleGanttItem) element;
            control.HideLabelWithPrevious();
            base.ClearContainerForItemOverride(element, item);
        }

        internal void AddToSelected(SimpleGanttItem item)
        {
            if (!_selectedItems.Contains(item))
            {
                _selectedItems.Add(item);
                item.IsSelected = true;
            }
        }

        internal void RemoveFromSelected(SimpleGanttItem item)
        {
            if (_selectedItems.Contains(item))
            {
                _selectedItems.Remove(item);
                item.IsSelected = false;
            }
        }

        internal void UnSelectAll(SimpleGanttItem currentItem)
        {
            foreach (var item in _selectedItems.Where(x => !Equals(x, currentItem)).ToList())
            {
                item.IsSelected = false;
            }
        }
    }
}
