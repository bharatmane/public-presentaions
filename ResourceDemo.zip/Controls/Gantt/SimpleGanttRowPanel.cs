﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// Represent the panel that displays the items in the <see cref="SimpleGanttChart"/>.
    /// </summary>
    public class SimpleGanttRowPanel : Panel
    {
        /// <summary>
        /// The start date attached property of the item.
        /// </summary>
        public static readonly DependencyProperty StartDateProperty =
            DependencyProperty.RegisterAttached("StartDate", typeof(DateTime?), typeof(SimpleGanttRowPanel), new FrameworkPropertyMetadata(DateTime.Now, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Sets the start date.
        /// </summary>
        public static void SetStartDate(UIElement element, DateTime? value)
        {
            element.SetValue(StartDateProperty, value);
        }
        /// <summary>
        /// Gets the start date.
        /// </summary>
        public static DateTime? GetStartDate(UIElement element)
        {
            return (DateTime?)element.GetValue(StartDateProperty);
        }

        /// <summary>
        /// The end date attached property of the item.
        /// </summary>
        public static readonly DependencyProperty EndDateProperty =
            DependencyProperty.RegisterAttached("EndDate", typeof(DateTime?), typeof(SimpleGanttRowPanel), new FrameworkPropertyMetadata(DateTime.Now, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Sets the end date.
        /// </summary>
        public static void SetEndDate(UIElement element, DateTime? value)
        {
            element.SetValue(EndDateProperty, value);
        }
        /// <summary>
        /// Gets the end date.
        /// </summary>
        public static DateTime? GetEndDate(UIElement element)
        {
            return (DateTime?)element.GetValue(EndDateProperty);
        }

        /// <summary>
        /// Gets the chart start date.
        /// </summary>
        public static readonly DependencyProperty ChartStartDateProperty =
            DependencyProperty.Register("ChartStartDate", typeof(DateTime), typeof(SimpleGanttRowPanel), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1), FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartStartDate
        {
            get { return (DateTime)GetValue(ChartStartDateProperty); }
            set { SetValue(ChartStartDateProperty, value); }
        }

        /// <summary>
        /// Gets the chart end date.
        /// </summary>
        public static readonly DependencyProperty ChartEndDateProperty =
            DependencyProperty.Register("ChartEndDate", typeof(DateTime), typeof(SimpleGanttRowPanel), new FrameworkPropertyMetadata((new DateTime(DateTime.Now.Year, 1, 1).AddYears(1)), FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));
        /// <summary>
        /// Exposes the <see cref="ChartEndDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartEndDate
        {
            get { return (DateTime)GetValue(ChartEndDateProperty); }
            set { SetValue(ChartEndDateProperty, value); }
        }

        /// <summary>
        /// The default constructor for the <see cref="SimpleGanttRowPanel"/>.
        /// </summary>
        public SimpleGanttRowPanel()
        {
            ClipToBounds = true;
            SnapsToDevicePixels = true;
        }

        /// <summary>
        /// Measures each item in the chart based on its start and end dates.
        /// </summary>
        protected override Size MeasureOverride(Size availableSize)
        {
            var conversion = CalculateConversion(ChartStartDate, ChartEndDate, availableSize.Width);

            foreach (var child in Children.OfType<FrameworkElement>())
            {
                var startPixel = DateToPixelStartDate(GetStartDate(child), ChartStartDate, conversion);
                var endPixel = DateToPixelEndDate(GetEndDate(child), ChartStartDate, ChartEndDate, conversion);
                var width = CalculateWidth(startPixel, endPixel, child);
                child.Measure(new Size(width, availableSize.Height));
            }

            return base.MeasureOverride(availableSize);
        }

        /// <summary>
        /// Aranges each item in the chart based on its start and end dates.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var conversion = CalculateConversion(ChartStartDate, ChartEndDate, finalSize.Width);

            foreach (var child in Children.OfType<FrameworkElement>())
            {
                var startPixel = DateToPixelStartDate(GetStartDate(child), ChartStartDate, conversion);
                var endPixel = DateToPixelEndDate(GetEndDate(child), ChartStartDate, ChartEndDate, conversion);
                var width = CalculateWidth(startPixel, endPixel, child);
                if (Equals(startPixel, endPixel) && width > 0)
                {
                    var offset = (width / 2);
                    startPixel = startPixel - offset;
                }
                child.Arrange(new Rect(startPixel, 0, width, finalSize.Height));
            }

            return base.ArrangeOverride(finalSize);
        }

        private double CalculateWidth(double startPixel, double endPixel, FrameworkElement child)
        {
            return Math.Max(double.IsNaN(child.Width) ? endPixel - startPixel : child.Width, child.MinWidth);
        }

        internal static double DateToPixelEndDate(DateTime? date, DateTime chartStartDate, DateTime chartEndDate, double conversion)
        {
            var d = date ?? chartEndDate.AddMonths(1);
            return DateToPixel(d, chartStartDate, conversion);
        }

        internal static double DateToPixelStartDate(DateTime? date, DateTime chartStartDate, double conversion)
        {
            var d = date ?? chartStartDate.AddMonths(-1);
            return DateToPixel(d, chartStartDate, conversion);
        }

        internal static double DateToPixel(DateTime date, DateTime chartStartDate, double conversion)
        {
            var pixel = (date - chartStartDate).Ticks * conversion;
            return pixel;
        }

        internal static double CalculateConversion(DateTime chartStartDate, DateTime chartEndDate, double width)
        {
            var conversion = width / (chartEndDate - chartStartDate).Ticks;
            return conversion;
        }

        internal static DateTime PixelToDate(DateTime chartStartDate, DateTime chartEndDate, double value, double width)
        {
            if (width > 0)
            {
                var totalMilli = (chartEndDate - chartStartDate).Ticks;
                var milli = (long) (totalMilli * (value / width));
                return chartStartDate.AddTicks(milli);
            }
            return chartStartDate;
        }
    }
}
