﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// Draws the header of the <see cref="SimpleGanttChart"/>.
    /// </summary>
    public class SimpleGanttHeaderPanel : Control
    {
        /// <summary>
        /// The start date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartStartDateProperty =
            DependencyProperty.Register("ChartStartDate", typeof(DateTime), typeof(SimpleGanttHeaderPanel), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1), FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartStartDate
        {
            get { return (DateTime)GetValue(ChartStartDateProperty); }
            set { SetValue(ChartStartDateProperty, value); }
        }

        /// <summary>
        /// The end date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartEndDateProperty =
            DependencyProperty.Register("ChartEndDate", typeof(DateTime), typeof(SimpleGanttHeaderPanel), new FrameworkPropertyMetadata((new DateTime(DateTime.Now.Year, 1, 1).AddYears(1)), FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="ChartEndDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartEndDate
        {
            get { return (DateTime)GetValue(ChartEndDateProperty); }
            set { SetValue(ChartEndDateProperty, value); }
        }

        /// <summary>
        /// The display range for the gantt chart.
        /// </summary>
        public static readonly DependencyProperty RangeProperty =
            DependencyProperty.Register("Range", typeof(GanttRange), typeof(SimpleGanttHeaderPanel), new FrameworkPropertyMetadata(GanttRange.Year, FrameworkPropertyMetadataOptions.AffectsRender));
        /// <summary>
        /// Exposes the <see cref="RangeProperty"/> DependencyProperty. 
        /// </summary>
        public GanttRange Range
        {
            get { return (GanttRange)GetValue(RangeProperty); }
            set { SetValue(RangeProperty, value); }
        }

        /// <summary>
        /// The default constructor for the <see cref="SimpleGanttHeaderPanel"/>.
        /// </summary>
        public SimpleGanttHeaderPanel()
        {
            ClipToBounds = true;
            SnapsToDevicePixels = true;
            MinHeight = 32;
        }

        /// <summary>
        /// Draws the headers when the date changes.
        /// </summary>
        protected override void OnRender(DrawingContext dc)
        {
            dc.DrawLine(new Pen(BorderBrush, 1), new Point(0, RenderSize.Height / 2), new Point(RenderSize.Width, RenderSize.Height / 2));
            if (ChartEndDate > ChartStartDate)
            {
                var start = ChartStartDate.AddMonths(-1).Date;
                var end = ChartEndDate.AddMonths(1).Date;
                var bufferStartWeek = GetFirstMonday(start);
                var bufferEndWeek = GetFirstMonday(end);
                var bufferStartMonth =  new DateTime(start.Year, start.Month, 1);
                var bufferEndMonth = new DateTime(end.Year, end.Month, 1);
                var diffWeek = (int)((bufferEndWeek - bufferStartWeek).TotalDays / 7);
                var diffMonth = ((bufferEndMonth.Year - bufferStartMonth.Year)*12) + (bufferEndMonth.Month - bufferStartMonth.Month);
                var diffDays = (int)(bufferEndWeek - bufferStartWeek).TotalDays;
                if (diffWeek > 0 && diffMonth > 0 && diffDays > 0)
                {
                    var conversion = SimpleGanttRowPanel.CalculateConversion(ChartStartDate, ChartEndDate, RenderSize.Width);
                    var currentDate = bufferStartWeek;
                    if ((int)Range <= 2)
                    {
                        for (var x = 0; x < diffDays; x++)
                        {
                            DrawDayHeader(dc, currentDate, conversion);
                            currentDate = currentDate.AddDays(1);
                        }
                    }
                    else
                    {
                        for (var x = 0; x < diffWeek; x++)
                        {
                            DrawWeekHeader(dc, currentDate, conversion);
                            currentDate = currentDate.AddDays(7);
                        }
                    }
                    
                    currentDate = bufferStartMonth;
                    for (var x = 0; x < diffMonth; x++)
                    {
                        DrawMonthHeader(dc, currentDate, conversion);
                        currentDate = currentDate.AddMonths(1);
                    }
                }
            }

            base.OnRender(dc);
        }

        private void DrawWeekHeader(DrawingContext dc, DateTime date, double conversion)
        {
            DrawHeader(dc, date, date.AddDays(7), "dd", conversion, false);
        }

        private void DrawMonthHeader(DrawingContext dc, DateTime date, double conversion)
        {
            DrawHeader(dc, date, date.AddMonths(1), "MMM yy", conversion, true);
        }

        private void DrawDayHeader(DrawingContext dc, DateTime date, double conversion)
        {
            DrawHeader(dc, date, date.AddDays(1), "dd", conversion, false);
        }

        private void DrawHeader(DrawingContext dc, DateTime startDate, DateTime endDate, string stringFormat, double conversion, bool top)
        {
            const double borderWidth = 1d;
            var pixelStart = SimpleGanttRowPanel.DateToPixel(startDate, ChartStartDate, conversion);
            var pixelEnd = SimpleGanttRowPanel.DateToPixel(endDate, ChartStartDate, conversion) - borderWidth;
            var width = pixelEnd - pixelStart;
            var centreX = pixelStart + (width / 2);
            var centreY = (RenderSize.Height / 4) * (top ? 1 : 3);
            var typeface = new Typeface(FontFamily, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
            var formattedText = new FormattedText(startDate.ToString(stringFormat), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, typeface, (top ? FontSize : 9), Foreground);
            var textLocation = new Point(centreX - (formattedText.WidthIncludingTrailingWhitespace / 2), centreY - (formattedText.Height / 2));
            dc.DrawLine(new Pen(BorderBrush, borderWidth), new Point(pixelEnd + (borderWidth / 2), (top ? 0 : RenderSize.Height / 2)), new Point(pixelEnd, RenderSize.Height / (top ? 2 : 1)));
            dc.DrawText(formattedText, textLocation);
        }

        private DateTime GetFirstMonday(DateTime date)
        {
            var dayOfWeek = date.DayOfWeek == DayOfWeek.Sunday ? 7 : (int) date.DayOfWeek;
            var delta = 1 - dayOfWeek;
            return date.AddDays(delta);
        }
    }
}
