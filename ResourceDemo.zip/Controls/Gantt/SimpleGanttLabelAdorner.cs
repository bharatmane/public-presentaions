﻿using System;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// An adorner for presenting a label on an item.
    /// </summary>
    public class SimpleGanttLabelAdorner : Adorner
    {
        /// <summary>
        /// The count of the visual children.
        /// </summary>
        protected override int VisualChildrenCount
        {
            get
            {
                return 1;
            }
        }

        private FrameworkElement _child;
        /// <summary>
        /// The child in the adorner.
        /// </summary>
        public FrameworkElement Child
        {
            get { return _child; }
            set
            {
                if (_child != null)
                {
                    RemoveVisualChild(_child);
                }
                _child = value;
                if (_child != null)
                {
                    AddVisualChild(_child);
                }
            }
        }

        /// <summary>
        /// The default constructor for the <see cref="SimpleGanttLabelAdorner"/>.
        /// </summary>
        /// <param name="adornedElement">The item to adorn the label.</param>
        public SimpleGanttLabelAdorner(UIElement adornedElement) 
            : base(adornedElement)
        {
            IsClipEnabled = true;
        }

        /// <summary>
        /// Measures the contained child.
        /// </summary>
        protected override Size MeasureOverride(Size constraint)
        {
            _child.Measure(constraint);
            return _child.DesiredSize;
        }

        /// <summary>
        /// Arranges the contained child.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            _child.Arrange(new Rect(new Point(0, 0), finalSize));
            return new Size(_child.ActualWidth, _child.ActualHeight);
        }

        /// <summary>
        /// Returns the contained child.
        /// </summary>
        protected override Visual GetVisualChild(int index)
        {
            if (index != 0) throw new ArgumentOutOfRangeException();
            return _child;
        }
    }
}
