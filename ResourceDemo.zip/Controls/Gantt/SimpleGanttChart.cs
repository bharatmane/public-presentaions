﻿using System;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using VShips.Framework.Common.Model;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls.Gantt
{
    /// <summary>
    /// A simple gannt chart control for display only purposes
    /// </summary>
    public class SimpleGanttChart : Selector
    {

        /// <summary>
        /// The minimum scrollable start date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartMinimumDateProperty = 
            DependencyProperty.Register("ChartMinimumDate", typeof(DateTime), typeof(SimpleGanttChart), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1)));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartMinimumDate
        {
            get { return (DateTime)GetValue(ChartMinimumDateProperty); }
            set { SetValue(ChartMinimumDateProperty, value); }
        }

        /// <summary>
        /// The maximum scrollable end date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartMaximumDateProperty =
            DependencyProperty.Register("ChartMaximumDate", typeof(DateTime), typeof(SimpleGanttChart), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1).AddYears(1)));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartMaximumDate
        {
            get { return (DateTime)GetValue(ChartMaximumDateProperty); }
            set { SetValue(ChartMaximumDateProperty, value); }
        }

        /// <summary>
        /// The start date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartStartDateProperty =
            DependencyProperty.Register("ChartStartDate", typeof(DateTime), typeof(SimpleGanttChart), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1), OnStartDateChanged));
        /// <summary>
        /// Exposes the <see cref="ChartStartDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartStartDate
        {
            get { return (DateTime)GetValue(ChartStartDateProperty); }
            set { SetValue(ChartStartDateProperty, value); }
        }

        /// <summary>
        /// The end date of the chart.
        /// </summary>
        public static readonly DependencyProperty ChartEndDateProperty =
            DependencyProperty.Register("ChartEndDate", typeof(DateTime), typeof(SimpleGanttChart), new FrameworkPropertyMetadata(new DateTime(DateTime.Now.Year, 1, 1).AddYears(1), OnEndDateChanged));
        /// <summary>
        /// Exposes the <see cref="ChartEndDateProperty"/> DependencyProperty.
        /// </summary>
        public DateTime ChartEndDate
        {
            get { return (DateTime)GetValue(ChartEndDateProperty); }
            set { SetValue(ChartEndDateProperty, value); }
        }

        /// <summary>
        /// The date highlighted.
        /// </summary>
        public static readonly DependencyProperty TodayProperty = 
            DependencyProperty.Register("Today", typeof(DateTime), typeof(SimpleGanttChart), new PropertyMetadata(DateTime.Now));
        /// <summary>
        /// Exposes the <see cref="TodayProperty"/> DependencyProperty.
        /// </summary>
        public DateTime Today
        {
            get { return (DateTime)GetValue(TodayProperty); }
            set { SetValue(TodayProperty, value); }
        }

        /// <summary>
        /// The brush used in the rows header.
        /// </summary>
        public static readonly DependencyProperty HeaderBackgroundProperty =
            DependencyProperty.Register("HeaderBackground", typeof(Brush), typeof(SimpleGanttChart), new PropertyMetadata(Brushes.White));
        /// <summary>
        /// Exposes the <see cref="HeaderBackgroundProperty"/> DependencyProperty.
        /// </summary>
        public Brush HeaderBackground
        {
            get { return (Brush)GetValue(HeaderBackgroundProperty); }
            set { SetValue(HeaderBackgroundProperty, value); }
        }

        /// <summary>
        /// Executed whenever the mouse is double clicked on a row.
        /// </summary>
        public static readonly DependencyProperty DoubleClickCommandProperty = 
            DependencyProperty.Register("DoubleClickCommand", typeof(ICommand), typeof(SimpleGanttChart), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="DoubleClickCommandProperty"/> DependencyProperty. 
        /// </summary>
        public ICommand DoubleClickCommand
        {
            get { return (ICommand)GetValue(DoubleClickCommandProperty); }
            set { SetValue(DoubleClickCommandProperty, value); }
        }

        /// <summary>
        /// The display range for the gantt chart.
        /// </summary>
        public static readonly DependencyProperty RangeProperty =
            DependencyProperty.Register("Range", typeof(GanttRange), typeof(SimpleGanttChart), new PropertyMetadata(GanttRange.Year, OnRangeChanged));
        /// <summary>
        /// Exposes the <see cref="RangeProperty"/> DependencyProperty. 
        /// </summary>
        public GanttRange Range
        {
            get { return (GanttRange)GetValue(RangeProperty); }
            set { SetValue(RangeProperty, value); }
        }

        /// <summary>
        /// Shows or hides the vessel positions part.
        /// </summary>
        public static readonly DependencyProperty PositionsVisibilityProperty = 
            DependencyProperty.Register("PositionsVisibility", typeof(Visibility), typeof(SimpleGanttChart), new PropertyMetadata(Visibility.Collapsed));
        /// <summary>
        /// Exposes the <see cref="PositionsVisibilityProperty"/> DependencyProperty. 
        /// </summary>
        public Visibility PositionsVisibility
        {
            get { return (Visibility)GetValue(PositionsVisibilityProperty); }
            set { SetValue(PositionsVisibilityProperty, value); }
        }

        /// <summary>
        /// The vessel positions for the top of the chart;
        /// </summary>
        public static readonly DependencyProperty PostionsProperty =
            DependencyProperty.Register("Postions", typeof(IEnumerable), typeof(SimpleGanttChart), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="PostionsProperty"/> DependencyProperty. 
        /// </summary>
        public IEnumerable Postions
        {
            get { return (IEnumerable)GetValue(PostionsProperty); }
            set { SetValue(PostionsProperty, value); }
        }

        /// <summary>
        /// Determines the style of the items representing a vessel position.
        /// </summary>
        public static readonly DependencyProperty PositionItemStyleProperty = 
            DependencyProperty.Register("PositionItemStyle", typeof(Style), typeof(SimpleGanttChart), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="PositionItemStyleProperty"/> DependencyProperty. 
        /// </summary>
        public Style PositionItemStyle
        {
            get { return (Style)GetValue(PositionItemStyleProperty); }
            set { SetValue(PositionItemStyleProperty, value); }
        }

        /// <summary>
        /// Determines the style of the line items representing a vessel position.
        /// </summary>
        public static readonly DependencyProperty PositionItemLineStyleProperty = 
            DependencyProperty.Register("PositionItemLineStyle", typeof(Style), typeof(SimpleGanttChart), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="PositionItemLineStyleProperty"/> DependencyProperty. 
        /// </summary>
        public Style PositionItemLineStyle
        {
            get { return (Style)GetValue(PositionItemLineStyleProperty); }
            set { SetValue(PositionItemLineStyleProperty, value); }
        }

        /// <summary>
        /// If the positions are from the fleet.
        /// </summary>
        public static readonly DependencyProperty IsFleetProperty =
            DependencyProperty.Register("IsFleet", typeof(bool), typeof(SimpleGanttChart), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsFleetProperty"/> DependencyProperty. 
        /// </summary>
        public bool IsFleet
        {
            get { return (bool)GetValue(IsFleetProperty); }
            set { SetValue(IsFleetProperty, value); }
        }
        
        private FrameworkElement OverlayPanel
        {
            get { return Template.FindName("PART_OverlayPanel", this) as FrameworkElement; }
        }

        static SimpleGanttChart()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SimpleGanttChart), new FrameworkPropertyMetadata(typeof(SimpleGanttChart)));
        }

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            UpdateEndDate();
            UpdateSelection();
            UpdateScrollbar();

            var zoomOut = Template.FindName("PART_ZoomPlus", this) as Button;
            var zoomIn = Template.FindName("PART_ZoomMinus", this) as Button;

            if (zoomOut != null)
            {
                zoomOut.Click += (sender, args) =>
                {
                    ZoomToPosition(OverlayPanel.ActualWidth/2, 1);
                };
            }

            if (zoomIn != null)
            {
                zoomIn.Click += (sender, args) =>
                {
                    ZoomToPosition(OverlayPanel.ActualWidth / 2, -1);
                };
            }
        }

        /// <summary>
        /// Creates the item container.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is SimpleGanttRow;
        }

        /// <summary>
        /// Returns true if the item is of type <see cref="SimpleGanttRow"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new SimpleGanttRow();
        }

        /// <summary>
        /// Prepares the item for the control.
        /// </summary>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            base.PrepareContainerForItemOverride(element, item);
            var control = (SimpleGanttRow) element;
            control.IsSelected = Equals(control.DataContext, SelectedItem);
        }

        /// <summary>
        /// Updates the selection.
        /// </summary>
        protected override void OnSelectionChanged(SelectionChangedEventArgs e)
        {
            UpdateSelection();
            base.OnSelectionChanged(e);
        }

        /// <summary>
        /// Executes the <see cref="DoubleClickCommand"/>.
        /// </summary>
        protected override void OnMouseDoubleClick(MouseButtonEventArgs e)
        {
            if (DoubleClickCommand != null && !e.Handled)
            {
                var control = UIHelper.FindVisualParent<SimpleGanttRow>((DependencyObject)e.OriginalSource, this);
                if (control != null && !control.IsPositionRow && DoubleClickCommand.CanExecute(null))
                {
                    DoubleClickCommand.Execute(null);
                    e.Handled = true;
                }
            }
            base.OnMouseDoubleClick(e);
        }

        /// <summary>
        /// Selects a row.
        /// </summary>
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);
            var control = UIHelper.FindVisualParent<SimpleGanttRow>((DependencyObject) e.OriginalSource, this);
            if (control != null && !control.IsPositionRow)
            {
                SelectedItem = control.DataContext;
            }
        }

        /// <summary>
        /// Zooms using the mouse wheel.
        /// </summary>
        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e)
        {
            e.Handled = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
            if (e.Handled)
            {
                var pos = Mouse.GetPosition(OverlayPanel).X;
                ZoomToPosition(pos, e.Delta);
            }
            
            base.OnPreviewMouseWheel(e);
        }

        private void UpdateScrollbar()
        {
            var scrollbar = UIHelper.FindVisualChild<SimpleGanttScrollbar>(this);
            if (scrollbar != null)
            {
                scrollbar.UpdateScrollbar();
            }
        }

        private void ZoomToPosition(double pos, int increment)
        {
            var r = UpdateRange(increment);

            if (!Equals(r, Range))
            {
                var panel = OverlayPanel;
                var posDate = SimpleGanttRowPanel.PixelToDate(ChartStartDate, ChartEndDate, pos, panel.ActualWidth);
                var endDate = GetEndDate(posDate, r);
                var pixToDate = SimpleGanttRowPanel.PixelToDate(posDate, endDate, pos, panel.ActualWidth);
                var startDate = posDate.AddMilliseconds((posDate - pixToDate).TotalMilliseconds);
                Range = r;
                ChartStartDate = startDate;
            }
        }

        private GanttRange UpdateRange(int increment)
        {
            var range = Range;
            var rangeIncrement = increment > 0 ? -1 : 1;
            var newRange = (int)Range + rangeIncrement;
            var totalRange = Enum.GetNames(typeof(GanttRange)).Length;
            if (newRange >= 1 && newRange <= totalRange)
            {
                range = (GanttRange) newRange;
            }
            return range;
        }

        private static void OnRangeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SimpleGanttChart) d;
            control.OnRangeChanged();
        }

        private static void OnStartDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SimpleGanttChart)d;
            control.OnStartDateChanged();
        }

        private static void OnEndDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SimpleGanttChart)d;
            control.OnEndDateChanged();
        }

        private void OnRangeChanged()
        {
            UpdateEndDate();
        }

        private void OnEndDateChanged()
        {
        }

        private void OnStartDateChanged()
        {
            UpdateEndDate();
        }

        private void UpdateEndDate()
        {
            SetValue(ChartEndDateProperty, GetEndDate(ChartStartDate, Range)); 
        }

        private DateTime GetEndDate(DateTime startDateTime, GanttRange range)
        {
            return startDateTime.AddMonths((int)range).AddDays(-1);
        }

        private void UpdateSelection()
        {
            if (ItemsSource != null)
            {
                foreach (var item in ItemsSource)
                {
                    var control = ItemContainerGenerator.ContainerFromItem(item) as SimpleGanttRow;
                    if (control != null)
                    {
                        control.IsSelected = Equals(control.DataContext, SelectedItem);
                    }
                }
            }
        }
        
    }
}
