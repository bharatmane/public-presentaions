﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using VShips.Framework.Common.Model;
using VShips.Framework.Resource.Controls.Model;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that shows a message unobtrusively on the adorner layer. Used primarily to notify the user of a successful or failed save.
    /// </summary>
    public class UIMessengeControl : ContentControl, IUIMessage
    {
        private AdornerLayer _layer;
        private MessengerAdorner _adorner;
        private TranslateTransform _tran;

        /// <summary>
        /// The type of message to display.
        /// </summary>
        public static readonly DependencyProperty MessageTypeProperty =
            DependencyProperty.Register("MessageType", typeof(MessageType), typeof(UIMessengeControl), new PropertyMetadata(MessageType.Success));
        /// <summary>
        /// Exposes the <see cref="MessageTypeProperty"/> DependencyProperty property.
        /// </summary>
        public MessageType MessageType
        {
            get { return (MessageType)GetValue(MessageTypeProperty); }
            set { SetValue(MessageTypeProperty, value); }
        }

        static UIMessengeControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(UIMessengeControl), new FrameworkPropertyMetadata(typeof(UIMessengeControl)));
        }

        /// <summary>
        /// Shows the message on the adorner layer.
        /// </summary>
        public void Show(MessageType messageType, object message)
        {
            MessageType = messageType;
            Content = message;
            var mainWindow = Application.Current.MainWindow;
            var content = UIHelper.FindVisualChild<TitlebarTabControl>(mainWindow);
            _layer = AdornerLayer.GetAdornerLayer(content);
            if (_layer != null)
            {
                var closeExecute = new DelayedExection(TimeSpan.FromSeconds(5), Dispatcher.CurrentDispatcher);
                _adorner = new MessengerAdorner(content, this);
                _layer.Add(_adorner);
                CaptureMouse();
                _tran = new TranslateTransform(0, 30);
                RenderTransform = _tran;
                var db = new DoubleAnimation { To = 0, Duration = TimeSpan.FromSeconds(0.15) };
                _tran.BeginAnimation(TranslateTransform.YProperty, db);
                closeExecute.Execute(Close);
            }
        }

        /// <summary>
        /// Closes the message.
        /// </summary>
        public void Close()
        {
            ReleaseMouseCapture();
        }

        /// <summary>
        /// Releases any mouse captures.
        /// </summary>
        protected override void OnLostMouseCapture(MouseEventArgs e)
        {
            base.OnLostMouseCapture(e);
            if (_tran != null)
            {
                var db = new DoubleAnimation { To = 30, Duration = TimeSpan.FromSeconds(0.15) };
                db.Completed += (sender, args) => RemoveLayer();
                _tran.BeginAnimation(TranslateTransform.YProperty, db);
            }
            else
            {
                RemoveLayer();
            }
        }

        /// <summary>
        /// Closes the message on mouse down anywhere in the app.
        /// </summary>
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);
            Close();
        }

        private void RemoveLayer()
        {
            if (_layer != null && _adorner != null)
            {
                _layer.Remove(_adorner);
                _adorner = null;
                _layer = null;
            }
        }

        /// <summary>
        /// Shows the specified message type.
        /// </summary>
        /// <param name="messageType">Type of the message.</param>
        /// <param name="message">The message.</param>
        /// <param name="buttonContent">Content of the button.</param>
        /// <param name="relayCommand">The relay command.</param>
        /// <exception cref="NotImplementedException"></exception>
        public void Show(MessageType messageType, object message, string buttonContent, Action relayCommand)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// The adorner used to display the message.
    /// </summary>
    public class MessengerAdorner : Adorner
    {
        private readonly UIElement _content;
        private readonly VisualCollection _visuals;

        /// <summary>
        /// Overrides the visual children count and returns 1 representing the border overlay.
        /// This is neccesery step in order to allow the WPF framework to render the adorner. 
        /// </summary>
        protected override int VisualChildrenCount
        {
            get { return _visuals.Count; }
        }

        /// <summary>
        /// The default contructor for the WindowFadeAdorner.
        /// </summary>
        /// <param name="adornedElement">The element on which to draw on top.</param>
        /// <param name="content">The message to display.</param>
        public MessengerAdorner(FrameworkElement adornedElement, UIElement content)
            : base(adornedElement)
        {
            _content = content;
            _visuals = new VisualCollection(this) { content };
            IsHitTestVisible = false;
        }

        /// <summary>
        /// Overrides the measure override to measure the message
        /// </summary>
        protected override Size MeasureOverride(Size constraint)
        {
            _content.Measure(constraint);
            return base.MeasureOverride(constraint);
        }

        /// <summary>
        /// Overrides the ArrangeOverride method to place the message.
        /// </summary>
        /// <param name="finalSize">The size of the owned window.</param>
        /// <returns>The final size.</returns>
        protected override Size ArrangeOverride(Size finalSize)
        {
            _content.Arrange(new Rect(0, finalSize.Height - _content.DesiredSize.Height, finalSize.Width, _content.DesiredSize.Height));
            return finalSize;
        }

        /// <summary>
        /// Overrides the GetVisualChild to return the overlay border.
        /// This is neccesery step in order to allow the WPF framework to render the adorner.
        /// </summary>
        /// <param name="index">The index of the child which never exceeds the <see cref="VisualChildrenCount"/>.</param>
        /// <returns>The visual relating to the index. In this case the overlay border.</returns>
        protected override Visual GetVisualChild(int index)
        {
            return _visuals[index];
        }
    }

}
