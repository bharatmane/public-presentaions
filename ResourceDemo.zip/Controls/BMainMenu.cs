﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Represents the main menu of the app.
    /// </summary>
    public class VMainMenu : ItemsControl
    {
        /// <summary>
        /// The selected item
        /// </summary>
        private VMainMenuGroup _selectedItem;
        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public VMainMenuGroup SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                if (_selectedItem != null)
                {
                    _selectedItem.IsSelected = false;
                }
                _selectedItem = value;
            }
        }

        /// <summary>
        /// If the menu is currently open.
        /// </summary>
        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(VMainMenu), new PropertyMetadata(false, OnIsOpenChanged));

        /// <summary>
        /// Called when [is open changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsOpenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue == false)
            {
                ((VMainMenu)d).SelectedItem = null;
            }
        }

        /// <summary>
        /// Exposes the <see cref="IsOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        static VMainMenu()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VMainMenu), new FrameworkPropertyMetadata(typeof(VMainMenu)));
            EventManager.RegisterClassHandler(typeof(VMainMenu), VMainMenuItem.ClickEvent, new RoutedEventHandler(ItemClicked));
            EventManager.RegisterClassHandler(typeof(VMainMenu), Button.ClickEvent, new RoutedEventHandler(ItemClicked));
        }

        /// <summary>
        /// Checks if the item is of type <see cref="VMainMenuGroup"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is VMainMenuGroup;
        }

        /// <summary>
        /// Creates a new instance of <see cref="VMainMenuGroup"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new VMainMenuGroup();
        }

        /// <summary>
        /// Prepares the control before displaying it.
        /// </summary>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (VMainMenuGroup)element;
            control.Selected += ControlOnSelected;
            if (control.IsSelected)
            {
                SelectedItem = control;
            }
            base.PrepareContainerForItemOverride(element, item);
        }

        /// <summary>
        /// Clears the control after it is unloaded from the view.
        /// </summary>
        protected override void ClearContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (VMainMenuGroup)element;
            control.Selected -= ControlOnSelected;
            base.ClearContainerForItemOverride(element, item);
        }

        /// <summary>
        /// Controls the on selected.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void ControlOnSelected(object sender, RoutedEventArgs e)
        {
            SelectedItem = (VMainMenuGroup)sender;
        }

        /// <summary>
        /// Items the clicked.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private static void ItemClicked(object sender, RoutedEventArgs e)
        {
            var mainMenu = sender as VMainMenu;
            if (mainMenu != null)
            {
                if(e.OriginalSource is VMainMenuItem || e.OriginalSource is Button)
                {
                    mainMenu.IsOpen = false;
                }
            }
        }

    }
}
