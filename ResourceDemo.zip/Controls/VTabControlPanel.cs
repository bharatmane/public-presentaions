﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Telerik.Windows.Controls;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The panel used to layout the item in the <see cref="VTabControl"/>.
    /// </summary>
    public class VTabControlPanel : Panel
    {
        /// <summary>
        /// The default constructor.
        /// </summary>
        public VTabControlPanel()
        {
            ClipToBounds = true;
            HorizontalAlignment = HorizontalAlignment.Left;
        }

        /// <summary>
        /// Measures the items in the panel.
        /// </summary>
        protected override Size MeasureOverride(Size availableSize)
        {
            if (!double.IsInfinity(availableSize.Width))
            {
                var currentX = 0d;
                var currentY = 0d;
                var measure = new Size(double.PositiveInfinity, double.PositiveInfinity);
                foreach (UIElement child in Children)
                {
                    child.Measure(measure);
                    currentX = currentX + child.DesiredSize.Width;
                    currentY = Math.Max(currentY, child.DesiredSize.Height);
                }
                return new Size(availableSize.Width, currentY);
            }
            return base.MeasureOverride(availableSize);
        }

        /// <summary>
        /// Arranges the items in the panel.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var tabControl = UIHelper.FindVisualParent<VTabControl>(this);
            tabControl.ClearOverflow();
            var currentX = 0d;
            foreach (var child in Children.OfType<RadTabItem>())
            {
                var newX = currentX + child.DesiredSize.Width;

                if (newX <= finalSize.Width)
                {
                    child.Arrange(new Rect(currentX, 0, child.DesiredSize.Width, finalSize.Height));
                }
                else
                {
                    child.Arrange(new Rect(0, 0, 0, 0));
                    tabControl.AddToOverFlow(child);
                }
                currentX = newX;
            }

            return base.ArrangeOverride(finalSize);
        }
    }
}
