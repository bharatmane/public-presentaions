﻿using System;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Telerik.Windows.Controls;
using System.Linq;
using System.Collections.Generic;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// VSlider Class
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.RadSlider" />
    public class VSlider : RadSlider
    {
        #region Private Properties
        /// <summary>
        /// The bottom tick bar
        /// </summary>
        private RadTickBar _bottomTickBar;
        #endregion

        #region Dependency Properties
        /// <summary>
        /// Gets or sets the bottom tick template.
        /// </summary>
        /// <value>
        /// The bottom tick template.
        /// </value>
        public DataTemplate BottomTickTemplate
        {
            get { return (DataTemplate)GetValue(BottomTickTemplateProperty); }
            set { SetValue(BottomTickTemplateProperty, value); }
        }

        /// <summary>
        /// The bottom tick template property
        /// </summary>
        public static readonly DependencyProperty BottomTickTemplateProperty =
            DependencyProperty.Register("BottomTickTemplate", typeof(DataTemplate), typeof(VSlider), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the bottom tick item source.
        /// </summary>
        /// <value>
        /// The bottom tick item source.
        /// </value>
        public IEnumerable BottomTickItemSource
        {
            get { return (IEnumerable)GetValue(BottomTickItemSourceProperty); }
            set { SetValue(BottomTickItemSourceProperty, value); }
        }

        /// <summary>
        /// The bottom tick item source property
        /// </summary>
        public static readonly DependencyProperty BottomTickItemSourceProperty =
            DependencyProperty.Register("BottomTickItemSource", typeof(IEnumerable), typeof(VSlider), new PropertyMetadata(null, OnBottomTickItemSourceChanged));

        #endregion

        #region Overriden Methods
        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            _bottomTickBar = Template.FindName("BottomTickBar", this) as RadTickBar;
            base.OnApplyTemplate();
        }

        /// <summary>
        /// When overridden in a derived class, participates in rendering operations that are directed by the layout system. The rendering instructions for this element are not used directly when this method is invoked, and are instead preserved for later asynchronous use by layout and drawing.
        /// </summary>
        /// <param name="drawingContext">The drawing instructions for a specific element. This context is provided to the layout system.</param>
        protected override void OnRender(DrawingContext drawingContext)
        {
            if (BottomTickItemSource != null && _bottomTickBar.FindChildByType<TickBarPanel>() != null)
            {
                var tickPanel = _bottomTickBar.FindChildByType<TickBarPanel>();
                var tickList = BottomTickItemSource.GetEnumerator();
                foreach (ContentPresenter item in tickPanel.Children)
                {
                    tickList.MoveNext();
                    if (item.FindChildByType<TextBlock>() != null)
                    {
                        item.FindChildByType<TextBlock>().DataContext = tickList.Current;
                    }
                }
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Called when [bottom tick item source changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnBottomTickItemSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            VSlider slider = d as VSlider;
            slider.InvalidateVisual();
        }
        #endregion
    }
}