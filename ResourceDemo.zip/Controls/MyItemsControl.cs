﻿using System.Windows;
using System.Windows.Controls;
// ReSharper disable ArrangeAccessorOwnerBody
#pragma warning disable 1591

namespace VShips.Framework.Resource.Controls
{
    public class MyItemsControl : ItemsControl
    {
        public MyItemsControl()
        {
            SizeChanged += MyItemsControl_SizeChanged;
        }

        private void MyItemsControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            CHeight = e.NewSize.Height;
            CWidth = e.NewSize.Width;
        }


        public static readonly DependencyProperty CHeightProperty =
            DependencyProperty.Register("CHeight", typeof(double), typeof(MyItemsControl), new PropertyMetadata(0.0));

        public double CHeight
        {
            get { return (double)GetValue(CHeightProperty); }
            set { SetValue(CHeightProperty, value); }
        }

        public static readonly DependencyProperty CWidthProperty =
            DependencyProperty.Register("CWidth", typeof(double), typeof(MyItemsControl), new PropertyMetadata(0.0));

        public double CWidth
        {
            get { return (double)GetValue(CWidthProperty); }
            set { SetValue(CWidthProperty, value); }
        }
    }
}