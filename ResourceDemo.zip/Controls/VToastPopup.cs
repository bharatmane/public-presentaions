﻿using GalaSoft.MvvmLight.Command;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Telerik.Windows.Controls;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Class for VToast Control
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.Model.IUIMessage" />
    /// <seealso cref="System.Windows.Window" />
    public class VToastPopup : Window, IUIMessage
    {
        #region Private Properties
        /// <summary>
        /// The name
        /// </summary>
        private readonly string _name = typeof(VToastPopup).Name;

        /// <summary>
        /// The close timer
        /// </summary>
        private DispatcherTimer _closeTimer;

        /// <summary>
        /// The top coordinate
        /// </summary>
        private double _topCoordinateForFirstToast = 80d;

        /// <summary>
        /// The close button
        /// </summary>
        private Button _closeButton;

        /// <summary>
        /// The toggle
        /// </summary>
        private RadToggleButton _toggle;

        /// <summary>
        /// The identifier
        /// </summary>
        private string _identifier;

        /// <summary>
        /// The top, left, height, width
        /// </summary>
        private double _top, _left, _height, _width, _topForMaximized, _leftForMaximized;

        /// <summary>
        /// The can align
        /// </summary>
        private bool _canAlign = false;
        #endregion Members

        #region Public Properties
        /// <summary>
        /// The can automatic close toast
        /// </summary>
        private bool _canAutoCloseToast;

        /// <summary>
        /// Gets or sets a value indicating whether this instance can automatic close toast.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can automatic close toast; otherwise, <c>false</c>.
        /// </value>
        public bool CanAutoCloseToast
        {
            get { return _canAutoCloseToast; }
            set { _canAutoCloseToast = value; }
        }

        /// <summary>
        /// The is grouped
        /// </summary>
        private bool _isGrouped = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is grouped.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is grouped; otherwise, <c>false</c>.
        /// </value>
        public bool IsGrouped
        {
            get { return _isGrouped; }
            set { _isGrouped = value; }
        }

        /// <summary>
        /// The vm service
        /// </summary>
        private IViewModelService _vmService;

        /// <summary>
        /// Retrieves the main view model service which gives access to common services.
        /// See the <see cref="IViewModelService" /> for more information.
        /// </summary>
        /// <value>
        /// The vm service.
        /// </value>
        protected IViewModelService VMService
        {
            get { return _vmService ?? (_vmService = ServiceLocator.Current.GetInstance<IViewModelService>()); }
        }

        /// <summary>
        /// Gets or sets the alert action.
        /// </summary>
        /// <value>
        /// The alert action.
        /// </value>
        public RelayCommand AlertAction
        {
            get { return (RelayCommand)GetValue(AlertActionProperty); }
            set { SetValue(AlertActionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AlertAction.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AlertActionProperty =
            DependencyProperty.Register("AlertAction", typeof(RelayCommand), typeof(VToastPopup), new PropertyMetadata(null));




        public string ButtonContent
        {
            get { return (string)GetValue(ButtonContentProperty); }
            set { SetValue(ButtonContentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ActionContent.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ButtonContentProperty =
            DependencyProperty.Register("ButtonContent", typeof(string), typeof(VToastPopup), new PropertyMetadata(null));

        #endregion

        #region Dependency Property
        /// <summary>
        /// Gets or sets the type of the message.
        /// </summary>
        /// <value>
        /// The type of the message.
        /// </value>
        public MessageType MessageType
        {
            get { return (MessageType)GetValue(MessageTypeProperty); }
            set { SetValue(MessageTypeProperty, value); }
        }

        /// <summary>
        /// The message type property
        /// </summary>
        public static readonly DependencyProperty MessageTypeProperty =
            DependencyProperty.Register("MessageType", typeof(MessageType), typeof(VToastPopup), new PropertyMetadata(MessageType.Success));

        /// <summary>
        /// Gets or sets a window's title.
        /// </summary>
        /// <value>
        /// The toast title.
        /// </value>
        public string ToastTitle
        {
            get { return (string)GetValue(ToastTitleProperty); }
            set { SetValue(ToastTitleProperty, value); }
        }

        /// <summary>
        /// The title property
        /// </summary>
        public static readonly DependencyProperty ToastTitleProperty =
            DependencyProperty.Register("ToastTitle", typeof(string), typeof(VToastPopup), new PropertyMetadata(""));

        /// <summary>
        /// Gets or sets the toast description.
        /// </summary>
        /// <value>
        /// The toast description.
        /// </value>
        public string ToastDescription
        {
            get { return (string)GetValue(ToastDescriptionProperty); }
            set { SetValue(ToastDescriptionProperty, value); }
        }

        /// <summary>
        /// The toast description property
        /// </summary>
        public static readonly DependencyProperty ToastDescriptionProperty =
            DependencyProperty.Register("ToastDescription", typeof(string), typeof(VToastPopup), new PropertyMetadata(""));

        /// <summary>
        /// Gets or sets the duration of the toast.
        /// </summary>
        /// <value>
        /// The duration of the toast.
        /// </value>
        public double ToastDuration
        {
            get { return (double)GetValue(ToastDurationProperty); }
            set { SetValue(ToastDurationProperty, value); }
        }

        /// <summary>
        /// The toast duration property
        /// </summary>
        public static readonly DependencyProperty ToastDurationProperty =
            DependencyProperty.Register("ToastDuration", typeof(double), typeof(VToastPopup), new PropertyMetadata(10d));

        /// <summary>
        /// Gets or sets the toast list.
        /// </summary>
        /// <value>
        /// The toast list.
        /// </value>
        public SpecialisedObservableCollection<VToastData> ToastList
        {
            get { return (SpecialisedObservableCollection<VToastData>)GetValue(ToastListProperty); }
            set { SetValue(ToastListProperty, value); }
        }

        /// <summary>
        /// The toast list property
        /// </summary>
        public static readonly DependencyProperty ToastListProperty =
            DependencyProperty.Register("ToastList", typeof(SpecialisedObservableCollection<VToastData>), typeof(VToastPopup), new PropertyMetadata(null));
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="VToastPopup" /> class.
        /// </summary>
        public VToastPopup()
        {
            AllowsTransparency = true;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            _identifier = Guid.NewGuid().ToString();
            VMService.SecurityService.LoginChanged += SecurityService_LoginChanged;
        }
        #endregion

        #region Overridden Methods
        /// <summary>
        /// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
        /// </summary>
        public override void OnApplyTemplate()
        {
            _closeButton = Template.FindName("PathToastClose", this) as Button;
            _toggle = Template.FindName("ButtonShowGroupedToast", this) as RadToggleButton;
            _closeButton.Click += OnVToastClose;
            _closeTimer = new DispatcherTimer();
            Loaded += OnVToastLoaded;
            Closed += OnVToastWindowClosed;
            MouseEnter += OnVToastMouseEnter;
            MouseLeave += OnVToastMouseLeave;

            base.OnApplyTemplate();
        }
        #endregion

        #region Protected Method
        /// <summary>
        /// Resets the timer.
        /// </summary>
        protected void ResetTimer()
        {
            if (CanAutoCloseToast)
            {
                _closeTimer.Interval = TimeSpan.FromSeconds(ToastDuration);
                _closeTimer.Start();
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Handles the LoginChanged event of the SecurityService control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        /// <exception cref="NotImplementedException"></exception>
        private void SecurityService_LoginChanged(object sender, EventArgs e)
        {
            OnVToastClose(sender, e as RoutedEventArgs);
        }

        /// <summary>
        /// WNDs the proc.
        /// </summary>
        /// <param name="hwnd">The HWND.</param>
        /// <param name="msg">The MSG.</param>
        /// <param name="wParam">The w parameter.</param>
        /// <param name="lParam">The l parameter.</param>
        /// <param name="handled">if set to <c>true</c> [handled].</param>
        /// <returns></returns>
        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (Application.Current != null && Application.Current.MainWindow != null)
            {
                _top = Application.Current.MainWindow.Top;
                _left = Application.Current.MainWindow.Left;
                _height = Application.Current.MainWindow.ActualHeight;
                _width = Application.Current.MainWindow.ActualWidth;
            }

            //This will trigger when window has been dragged from one position to another. Window will broadcast this message : WM_EXITSIZEMOVE = 0x0232
            //This will trigger when window is maximized or restored or minimized. Window will broadcast this message : WM_SIZE = 0x0005
            if ((msg == 0x0232) || (msg == 0x0005))
            {
                _canAlign = true;
                if (msg == 0x0005 && wParam.ToInt32() == 2)
                {
                    _top = _topForMaximized;
                    _left = _leftForMaximized;
                    _canAlign = true;
                }
                if (msg == 0x0005 && wParam.ToInt32() == 0)
                {
                    _top = Application.Current.MainWindow.Top;
                    _left = Application.Current.MainWindow.Left;
                    _canAlign = false;
                }
                ReAllignToast();
            }
            //This will trigger when any other window is maximized over the application
            //Window will broadcast this message : WM_ACTIVATEAPP = 0x001C
            if (msg == 0x001C)
            {
                SetToastTopmost(wParam.ToInt32());
            }
            return IntPtr.Zero;
        }

        /// <summary>
        /// Res the allign toast.
        /// </summary>
        private void ReAllignToast()
        {
            if (_canAlign)
            {
                var left = (_width - ActualWidth) + _left;
                var top = (_top + _topCoordinateForFirstToast);
                foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false))
                {
                    string windowName = window.GetType().Name;
                    if (windowName.Equals(_name) && !Equals(window, this))
                    {
                        top = top + window.ActualHeight;
                    }
                    if (windowName.Equals(_name) && Equals(window, this))
                    {
                        window.Top = top;
                        window.Left = left;
                        if ((window.Top + window.Height) > _height)
                        {
                            left = left - window.ActualWidth;
                            top = _top + _topCoordinateForFirstToast;
                        }
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Sets the toasts topmost.
        /// </summary>
        /// <param name="param">The parameter.</param>
        private void SetToastTopmost(int param)
        {
            foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false))
            {
                window.Topmost = param == 0 ? false : true;
            }
        }

        /// <summary>
        /// Timers the tick.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void TimerTick(object sender, EventArgs e)
        {
            if (CanAutoCloseToast)
            {
                _closeTimer.Stop();
                _closeTimer.Tick -= TimerTick;
                foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.MessageType == MessageType).ToList())
                {
                    window.RemoveAllHandlers();
                    window.Close();
                }
            }
        }

        /// <summary>
        /// vs the toast loaded.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void OnVToastLoaded(object sender, RoutedEventArgs e)
        {
            if (CanAutoCloseToast)
            {
                _closeTimer.Interval = TimeSpan.FromSeconds(ToastDuration);
                _closeTimer.Tick += TimerTick;
                _closeTimer.Start();
            }
        }

        /// <summary>
        /// Called when [v toast mouse enter].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseEventArgs"/> instance containing the event data.</param>
        private void OnVToastMouseEnter(object sender, MouseEventArgs e)
        {
            if (CanAutoCloseToast)
            {
                _closeTimer.Stop();
            }
        }

        /// <summary>
        /// vs the toast mouse leave.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="MouseEventArgs" /> instance containing the event data.</param>
        /// <exception cref="System.NotImplementedException"></exception>
        private void OnVToastMouseLeave(object sender, MouseEventArgs e)
        {
            if (CanAutoCloseToast)
            {
                _closeTimer.Interval = TimeSpan.FromSeconds(ToastDuration);
                _closeTimer.Start();
            }
        }

        /// <summary>
        /// Groups the v toast popup.
        /// </summary>
        /// <returns></returns>
        private bool GroupVToastPopup()
        {
            CanAutoCloseToast = MessageType == MessageType.Success;
            var count = Application.Current.Windows.OfType<VToastPopup>().Where(x => x.MessageType == MessageType).ToList().Count;
            var item = Application.Current.Windows.OfType<VToastPopup>().FirstOrDefault(x => x.MessageType == MessageType && x.IsGrouped == false);

            if (count > 1 && item != null)
            {
                if (item.ToastList == null)
                {
                    item.ToastList = new SpecialisedObservableCollection<VToastData>();
                    item.ToastList.Add(new VToastData()
                    {
                        CloseCommand = new RelayCommand<VToastData>(CloseToastFromList),
                        Identifier = Guid.NewGuid().ToString(),
                        MessageType = item.MessageType,
                        Parent = item,
                        ToastDescription = item.ToastDescription,
                        ToastTitle = item.ToastTitle
                    });
                }
                item.ToastList.Insert(0, new VToastData()
                {
                    CloseCommand = new RelayCommand<VToastData>(CloseToastFromList),
                    Identifier = _identifier,
                    MessageType = MessageType,
                    Parent = item,
                    ToastDescription = ToastDescription,
                    ToastTitle = ToastTitle
                });
                item.CanAutoCloseToast = CanAutoCloseToast;
                item.ToastDescription = "Click on the arrow to show all alerts.\nTotal (" + item.ToastList.Count + ")";
                item.ResetTimer();
                return false;
            }
            return true;
        }

        /// <summary>
        /// Closes the toast from list.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void CloseToastFromList(VToastData obj)
        {
            obj.Parent.ToastList.Remove(obj);
            obj.Parent.ToastDescription = "Click on the arrow to show all alerts.\nTotal (" + obj.Parent.ToastList.Count + ")";
            var list = Application.Current.Windows.OfType<VToastPopup>().Where(x => x._identifier == obj.Identifier).ToList();
            VToastPopup item = list.FirstOrDefault();
            if (list != null && list.Count != 0 && item != null)
            {
                item.RemoveAllHandlers();
                item.Close();
            }
            if (obj.Parent.ToastList.Count == 0)
            {
                obj.Parent.SizeChanged -= OnShowHideVToastList;
                obj.Parent.RemoveAllHandlers();
                obj.Parent.Close();
            }
        }

        /// <summary>
        /// Shows the hide v toast list.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs" /> instance containing the event data.</param>
        private void OnShowHideVToastList(object sender, SizeChangedEventArgs e)
        {
            if (_toggle.IsChecked == true)
            {
                VToastPopup _prevToast = null;
                double contentHeight = ActualHeight;
                double top = Top;
                if (_toggle.IsChecked == true)
                {
                    foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false))
                    {
                        if (window.Top > Top && window.Left == Left)
                        {
                            window.Top = top + contentHeight;
                            contentHeight = window.ActualHeight;
                            top = window.Top;
                        }
                        if (_prevToast != null && _prevToast.Top == window.Top && _prevToast.Left == Left)
                        {
                            window.Top = _prevToast.Top + _prevToast.ActualHeight;
                            window.Left = _prevToast.Left;
                        }
                        if ((window.Top + window.ActualHeight) > (_height + _top))
                        {
                            window.Left = Left - ActualWidth;
                            window.Top = _top + _topCoordinateForFirstToast;
                        }
                        if (_prevToast != null && _prevToast.Top + _prevToast.ActualHeight + window.ActualHeight < (_height + _top))
                        {
                            window.Top = _prevToast.Top + _prevToast.ActualHeight;
                            window.Left = _prevToast.Left;
                        }
                        _prevToast = window;
                    }
                }
            }
            if (_toggle.IsChecked == false)
            {
                VToastPopup _prevToast = null;
                double contentHeight = ActualHeight;
                double top = Top;
                if (_toggle.IsChecked == false)
                {
                    foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false))
                    {
                        if (window.Top > Top && window.Left == Left)
                        {
                            window.Top = top;
                        }
                        if (window.Left != Left)
                        {
                            if (_prevToast != null && _prevToast.Top + _prevToast.ActualHeight + window.ActualHeight < (_height + _top))
                            {
                                window.Top = _prevToast.Top + _prevToast.ActualHeight;
                                window.Left = _prevToast.Left;
                            }
                        }
                        top = window.Top + ActualHeight;
                        _prevToast = window;
                    }
                }
            }
        }

        /// <summary>
        /// Adjusts the windows.
        /// </summary>
        private void AdjustWindows()
        {
            Left = (_width - ActualWidth) + _left;
            double top = _top + _topCoordinateForFirstToast;
            foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false))
            {
                string windowName = window.GetType().Name;
                if (windowName.Equals(_name) && !Equals(window, this))
                {
                    if (Left == window.Left)
                    {
                        top = top + window.ActualHeight;
                    }
                    if ((top + ActualHeight) > _height)
                    {
                        Left = Left - ActualWidth;
                        top = _top + _topCoordinateForFirstToast;
                    }
                }
            }
            Top = top;
        }

        /// <summary>
        /// Adjust any windows that were below this one to move up
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void OnVToastWindowClosed(object sender, EventArgs e)
        {
            VToastPopup _prevToast = this;
            foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false))
            {
                if (window.Top > Top && window.Left == Left)
                {
                    window.Top -= ActualHeight;
                }
                if (window.Left != Left)
                {
                    if (_prevToast != null && _prevToast.Top + _prevToast.ActualHeight + window.ActualHeight < (_height + _top))
                    {
                        window.Top = _prevToast.Top + _prevToast.ActualHeight;
                        window.Left = _prevToast.Left;
                    }
                    if (_prevToast != null && Application.Current.Windows.OfType<VToastPopup>().Where(x => x.IsGrouped == false).ToList().Count == 1)
                    {
                        window.Top = _prevToast.Top;
                        window.Left = _prevToast.Left;
                    }
                }
                _prevToast = window;
            }
            Closed -= OnVToastWindowClosed;
        }

        /// <summary>
        /// Closes the toast.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        /// <exception cref="System.NotImplementedException"></exception>
        private void OnVToastClose(object sender, RoutedEventArgs e)
        {
            if (sender != null)
            {
                RemoveAllHandlers();
                foreach (VToastPopup window in Application.Current.Windows.OfType<VToastPopup>().Where(x => x.MessageType == MessageType).ToList())
                {
                    window.RemoveAllHandlers();
                    window.Close();
                }
            }
        }

        /// <summary>
        /// Removes all handlers.
        /// </summary>
        private void RemoveAllHandlers()
        {
            MouseEnter -= OnVToastMouseEnter;
            MouseLeave -= OnVToastMouseLeave;
            Loaded -= OnVToastLoaded;
            if (Application.Current != null && Application.Current.MainWindow != null)
            {
                Application.Current.MainWindow.SizeChanged -= WindowSizeChanged;
            }
            if (VMService.SecurityService != null)
            {
                VMService.SecurityService.LoginChanged -= SecurityService_LoginChanged;
            }
        }

        /// <summary>
        /// Windows the size changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs"/> instance containing the event data.</param>
        private void WindowSizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (Application.Current.MainWindow.WindowState == WindowState.Maximized)
            {
                _width = e.NewSize.Width;
                _height = e.NewSize.Height;
                _canAlign = true;
                ReAllignToast();
            }
            if (Application.Current.MainWindow.WindowState == WindowState.Normal)
            {
                _width = e.NewSize.Width;
                _height = e.NewSize.Height;
                _canAlign = true;
                ReAllignToast();
            }
        }

        public void Show(MessageType messageType, object message, string buttonContent, Action relayCommand)
        {
            Show(messageType, message);
            ButtonContent = buttonContent.ToString();
            AlertAction = new RelayCommand(relayCommand);
        }
        #endregion

        #region Implemented Method
        /// <summary>
        /// Shows the message on the UI.
        /// </summary>
        /// <param name="messageType">The type of message to show based on the operation.</param>
        /// <param name="message">The message to show.</param>
        public void Show(MessageType messageType, object message)
        {
            MessageType = messageType;
            ToastDescription = message != null ? message.ToString() : "";
            ToastTitle = messageType.ToString();
            _top = Application.Current.MainWindow.Top;
            _left = Application.Current.MainWindow.Left;
            _height = Application.Current.MainWindow.ActualHeight;
            _width = Application.Current.MainWindow.ActualWidth;
            _topForMaximized = -8d;
            _leftForMaximized = -8d;
            if (GroupVToastPopup())
            {
                Topmost = true;
                IsGrouped = false;
                if (Application.Current.MainWindow.WindowState == WindowState.Maximized)
                {
                    _top = _topForMaximized;
                    _left = _leftForMaximized;
                }
                Show();
                Owner = Application.Current.MainWindow;
                AdjustWindows();
                SizeChanged += OnShowHideVToastList;
                Application.Current.MainWindow.SizeChanged += WindowSizeChanged;
                HwndSource hwndSource = PresentationSource.FromVisual(Application.Current.MainWindow) as HwndSource;
                if (hwndSource != null)
                {
                    hwndSource.AddHook(WndProc);
                }
            }
        }
        #endregion Private Methods
    }

    /// <summary>
    /// Class for Grouping Toast Data
    /// </summary>
    public class VToastData
    {
        #region Public Properties
        /// <summary>
        /// Gets or sets the type of the message.
        /// </summary>
        /// <value>
        /// The type of the message.
        /// </value>
        public MessageType MessageType { get; set; }

        /// <summary>
        /// Gets or sets the toast title.
        /// </summary>
        /// <value>
        /// The toast title.
        /// </value>
        public string ToastTitle { get; set; }

        /// <summary>
        /// Gets or sets the toast description.
        /// </summary>
        /// <value>
        /// The toast description.
        /// </value>
        public string ToastDescription { get; set; }

        /// <summary>
        /// Gets or sets the close command.
        /// </summary>
        /// <value>
        /// The close command.
        /// </value>
        public RelayCommand<VToastData> CloseCommand { get; set; }

        /// <summary>
        /// Gets or sets the parent.
        /// </summary>
        /// <value>
        /// The parent.
        /// </value>
        public VToastPopup Parent { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Identifier { get; set; }
        #endregion
    }
}
