﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;
using VShips.Framework.Resource.Helpers;
using Point = System.Windows.Point;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The item in the tileview control.
    /// </summary>
    public class VTileViewItem : HeaderedContentControl
    {
        #region Private Properties

        /// <summary>
        /// The start position
        /// </summary>
        private Point? _startPos;

        /// <summary>
        /// The is dragging
        /// </summary>
        private bool _isDragging;

        /// <summary>
        /// The drag identifier
        /// </summary>
        internal const string DragId = "VTileViewItemDrag";

        #endregion

        #region Dependency Properties

        /// <summary>
        /// The state of the control. Expanded is when an item is in the expanded state.
        /// </summary>
        public static readonly DependencyProperty StateProperty = DependencyProperty.Register("State", typeof(VTileViewState), typeof(VTileViewItem), new PropertyMetadata(VTileViewState.Normal, OnStateChanged));
        
        /// <summary>
        /// The is open property
        /// </summary>
        public static readonly DependencyProperty IsOpenProperty = DependencyProperty.Register("IsOpen", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(true));        

        //TODO : Try to handle this property with relay command,if it will work we need to remove event trigger from ManagerOrderInProgressView and ManagerOutstandingOrdersView.
        /// <summary>
        /// The is expanded property
        /// </summary>
        public static readonly DependencyProperty IsExpandedProperty = DependencyProperty.Register("IsExpanded", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(null));

        /// <summary>
        /// The command used to expand and collapse the control.
        /// </summary>
        public static readonly DependencyProperty SwitchStateCommandProperty = DependencyProperty.Register("SwitchStateCommand", typeof(ICommand), typeof(VTileViewItem), new PropertyMetadata(null));

        /// <summary>
        /// The toggle slide panel command property
        /// </summary>
        public static readonly DependencyProperty ToggleSlidePanelCommandProperty = DependencyProperty.Register("ToggleSlidePanelCommand", typeof(ICommand), typeof(VTileViewItem), new PropertyMetadata(null));

        /// <summary>
        /// The content to display when the tile is expanded.
        /// </summary>
        public static readonly DependencyProperty LargeContentProperty = DependencyProperty.Register("LargeContent", typeof(object), typeof(VTileViewItem), new PropertyMetadata(null));
        
        /// <summary>
        /// The datatemplate to use to display the <see cref="LargeContent"/>.
        /// </summary>
        public static readonly DependencyProperty LargeContentTemplateProperty = DependencyProperty.Register("LargeContentTemplate", typeof(DataTemplate), typeof(VTileViewItem), new PropertyMetadata(null));
        
        /// <summary>
        /// When this is true the control will use the large contrent when its state changes, otherwise it will use the content.
        /// </summary>
        public static readonly DependencyProperty AllowContentChangeProperty = DependencyProperty.Register("AllowContentChange", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(true));
        
        /// <summary>
        /// True if the control can expand.
        /// </summary>
        public static readonly DependencyProperty CanExpandProperty = DependencyProperty.Register("CanExpand", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(true));

        /// <summary>
        /// The show slider property
        /// </summary>
        public static readonly DependencyProperty ShowSliderProperty = DependencyProperty.Register("ShowSlider", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(false));

        /// <summary>
        /// True if the control can refresh its data.
        /// </summary>
        public static readonly DependencyProperty CanRefreshProperty = DependencyProperty.Register("CanRefresh", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(true));

        /// <summary>
        /// Used on the resfresh button.
        /// </summary>
        public static readonly DependencyProperty RefreshCommandProperty = DependencyProperty.Register("RefreshCommand", typeof(ICommand), typeof(VTileViewItem), new PropertyMetadata(null));
        
        /// <summary>
        /// If the item can be dragged.
        /// </summary>
        public static readonly DependencyProperty AllowDragProperty = DependencyProperty.Register("AllowDrag", typeof(bool), typeof(VTileViewItem), new PropertyMetadata(true));

        #endregion

        #region Properties

        /// <summary>
        /// Exposes the <see cref="StateProperty"/> DependencyProperty.
        /// </summary>
        public VTileViewState State
        {
            get { return (VTileViewState)GetValue(StateProperty); }
            set { SetValue(StateProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is open.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is open; otherwise, <c>false</c>.
        /// </value>
        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is expanded.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is expanded; otherwise, <c>false</c>.
        /// </value>
        public bool IsExpanded
        {
            get { return (bool)GetValue(IsExpandedProperty); }
            set { SetValue(IsExpandedProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="SwitchStateCommand"/> DependencyProperty.
        /// </summary>
        public ICommand SwitchStateCommand
        {
            get { return (ICommand)GetValue(SwitchStateCommandProperty); }
            set { SetValue(SwitchStateCommandProperty, value); }
        }

        /// <summary>
        /// Gets or sets the toggle slide panel command.
        /// </summary>
        /// <value>
        /// The toggle slide panel command.
        /// </value>
        public ICommand ToggleSlidePanelCommand
        {
            get { return (ICommand)GetValue(ToggleSlidePanelCommandProperty); }
            set { SetValue(ToggleSlidePanelCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="LargeContentProperty"/> DependencyProperty.
        /// </summary>
        public object LargeContent
        {
            get { return GetValue(LargeContentProperty); }
            set { SetValue(LargeContentProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="LargeContentTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate LargeContentTemplate
        {
            get { return (DataTemplate)GetValue(LargeContentTemplateProperty); }
            set { SetValue(LargeContentTemplateProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="AllowContentChangeProperty"/> DependencyProperty.
        /// </summary>
        public bool AllowContentChange
        {
            get { return (bool)GetValue(AllowContentChangeProperty); }
            set { SetValue(AllowContentChangeProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="CanExpandProperty"/> DependencyProperty.
        /// </summary>
        public bool CanExpand
        {
            get { return (bool)GetValue(CanExpandProperty); }
            set { SetValue(CanExpandProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [show slider].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show slider]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowSlider
        {
            get { return (bool)GetValue(ShowSliderProperty); }
            set { SetValue(ShowSliderProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="CanRefreshProperty"/> DependencyProperty.
        /// </summary>
        public bool CanRefresh
        {
            get { return (bool)GetValue(CanRefreshProperty); }
            set { SetValue(CanRefreshProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="RefreshCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand RefreshCommand
        {
            get { return (ICommand)GetValue(RefreshCommandProperty); }
            set { SetValue(RefreshCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="AllowDragProperty"/> DependencyProperty.
        /// </summary>
        public bool AllowDrag
        {
            get { return (bool)GetValue(AllowDragProperty); }
            set { SetValue(AllowDragProperty, value); }
        }

        /// <summary>
        /// Gets the header grid.
        /// </summary>
        /// <value>
        /// The header grid.
        /// </value>
        private FrameworkElement HeaderGrid
        {
            get { return Template.FindName("HeaderGrid", this) as FrameworkElement; }
        }

        #endregion

        #region Constructors

        static VTileViewItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VTileViewItem), new FrameworkPropertyMetadata(typeof(VTileViewItem)));
        }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            SwitchStateCommand = new DelegateCommand(o => SwitchState());
            ToggleSlidePanelCommand = new DelegateCommand(o => ToggleSlidePanel());
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Switches the state of the control.
        /// </summary>
        /// <param name="eventArgs">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        protected override void OnMouseDoubleClick(MouseButtonEventArgs eventArgs)
        {
            if (CanExpand)
            {
                var header = HeaderGrid;
                if (header != null)
                {
                    var isInHeader = UIHelper.HasVisualParent((DependencyObject)eventArgs.OriginalSource, header, this);
                    if (isInHeader)
                    {
                        SwitchState();
                    }
                }
            }
            base.OnMouseDoubleClick(eventArgs);
        }

        /// <summary>
        /// Raises the <see cref="E:PreviewMouseLeftButtonDown" /> event.
        /// </summary>
        /// <param name="eventArgs">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        protected override void OnPreviewMouseLeftButtonDown(MouseButtonEventArgs eventArgs)
        {
            var header = HeaderGrid;
            if (header != null)
            {
                var isInHeader = UIHelper.HasVisualParent((DependencyObject)eventArgs.OriginalSource, header, this);
                if (isInHeader)
                {
                    _startPos = eventArgs.GetPosition(null); 
                }
            }
            base.OnPreviewMouseLeftButtonDown(eventArgs);
        }

        /// <summary>
        /// Raises the <see cref="E:PreviewMouseUp" /> event.
        /// </summary>
        /// <param name="eventArgs">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        protected override void OnPreviewMouseUp(MouseButtonEventArgs eventArgs)
        {
            _startPos = null;
            base.OnPreviewMouseUp(eventArgs);
        }

        /// <summary>
        /// Raises the <see cref="E:PreviewMouseMove" /> event.
        /// </summary>
        /// <param name="eventArgs">The <see cref="MouseEventArgs"/> instance containing the event data.</param>
        protected override void OnPreviewMouseMove(MouseEventArgs eventArgs)
        {
            if (AllowDrag)
            {
                var startPos = _startPos;
                var position = eventArgs.GetPosition(null);
                if (eventArgs.LeftButton == MouseButtonState.Pressed && startPos != null && !_isDragging)
                {
                    if (Math.Abs(position.X - startPos.Value.X) > SystemParameters.MinimumHorizontalDragDistance ||
                        Math.Abs(position.Y - startPos.Value.Y) > SystemParameters.MinimumVerticalDragDistance)
                    {
                        var dragScope = UIHelper.FindVisualParent<VTileViewPanel>(this);
                        if (dragScope.State == VTileViewState.Normal)
                        {
                            var offset = eventArgs.GetPosition(HeaderGrid);
                            StartDrag(dragScope, offset);
                        }
                    }
                }
            }
            base.OnPreviewMouseMove(eventArgs);
        }

        /// <summary>
        /// Raises the <see cref="E:PreviewMouseLeftButtonUp" /> event.
        /// </summary>
        /// <param name="eventArgs">The <see cref="MouseButtonEventArgs"/> instance containing the event data.</param>
        protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs eventArgs)
        {
            ReleaseMouseCapture();
            base.OnPreviewMouseLeftButtonUp(eventArgs);
        }

        #endregion

        #region Static Methods

        /// <summary>
        /// Called when [state changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArgs">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnStateChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArgs)
        {
            var control = (VTileViewItem)dependencyObject;
            var value = (VTileViewState)eventArgs.NewValue;
            VTileViewPanel.SetState(control, value);
            control.IsExpanded = control.State == VTileViewState.Expanded;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Starts the drag.
        /// </summary>
        /// <param name="dragScope">The drag scope.</param>
        /// <param name="offset">The offset.</param>
        private void StartDrag(VTileViewPanel dragScope, Point offset)
        {
            _isDragging = true;
            dragScope.AllowDrop = true;
            dragScope.StartDrag(this, offset);
            Visibility = Visibility.Hidden;
            var data = new DataObject(DragId, this);
            DragDrop.DoDragDrop(dragScope, data, DragDropEffects.Move);
            _startPos = null;
            Visibility = Visibility.Visible;
            dragScope.StopDrag(this);
            _isDragging = false;
        }

        /// <summary>
        /// Switches the state.
        /// </summary>
        private void SwitchState()
        {
            State = State == VTileViewState.Expanded ? VTileViewState.Normal : VTileViewState.Expanded;
        }

        /// <summary>
        /// Toggles the slide panel.
        /// </summary>
        private void ToggleSlidePanel()
        {
            VTileViewPanel parent = this.GetVisualParent<VTileViewPanel>();
            IsOpen = !IsOpen;
            if (parent != null && ShowSlider)
            {
                if (IsOpen)
                {
                    parent.MinimisedColumns = parent.MinimisedRows = 2;
                }
                else
                {
                    parent.MinimisedColumns = parent.MinimisedRows = 0;
                }
                parent.Dispatcher.BeginInvoke(new Action(() =>
                {
                    parent.InvalidateMeasure();
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        #endregion
    }
}