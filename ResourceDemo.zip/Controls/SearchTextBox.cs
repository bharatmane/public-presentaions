﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A control that provides a textbox that can be used for searching. 
    /// </summary>
    [Obsolete("Use the searchcontrol instead.")]
    public class SearchTextBox : RadWatermarkTextBox
    {
        /// <summary>
        /// The command used to initiate the search.
        /// </summary>
        public static readonly DependencyProperty SearchCommandProperty =
            DependencyProperty.Register("SearchCommand", typeof(ICommand), typeof(SearchTextBox), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SearchCommandProperty"/> DependencyProperty. 
        /// </summary>
        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        /// <summary>
        /// The command used to clear the search.
        /// </summary>
        public static readonly DependencyProperty ClearSearchCommandProperty =
            DependencyProperty.Register("ClearSearchCommand", typeof(ICommand), typeof(SearchTextBox), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="ClearSearchCommandProperty"/> DependencyProperty. 
        /// </summary>
        public ICommand ClearSearchCommand
        {
            get { return (ICommand)GetValue(ClearSearchCommandProperty); }
            set { SetValue(ClearSearchCommandProperty, value); }
        }

        /// <summary>
        /// True if the control is currently using the text search.
        /// </summary>
        public static readonly DependencyProperty IsTextSearchProperty =
            DependencyProperty.Register("IsTextSearch", typeof(bool), typeof(SearchTextBox), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsTextSearchProperty"/> DependencyProperty. 
        /// </summary>
        public bool IsTextSearch
        {
            get { return (bool)GetValue(IsTextSearchProperty); }
            set { SetValue(IsTextSearchProperty, value); }
        }

        /// <summary>
        /// True if the search is automatic and therefore without a search button.
        /// </summary>
        public static readonly DependencyProperty IsAutoProperty = 
            DependencyProperty.Register("IsAuto", typeof(bool), typeof(SearchTextBox), new PropertyMetadata(false, OnIsAutoChanged));
        /// <summary>
        /// Exposes the <see cref="IsAutoProperty"/> DependencyProperty. 
        /// </summary>
        public bool IsAuto
        {
            get { return (bool)GetValue(IsAutoProperty); }
            set { SetValue(IsAutoProperty, value); }
        }

        static SearchTextBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SearchTextBox), new FrameworkPropertyMetadata(typeof(SearchTextBox)));
        }

        private static void OnIsAutoChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SearchTextBox) d;
            control.OnIsAutoChanged();
        }

        private void OnIsAutoChanged()
        {
            if (IsAuto)
            {
                ClearSearchCommand = new RelayCommand(() => { Text = ""; });
            }
        }

        protected override void OnTextChanged(TextChangedEventArgs e)
        {
            base.OnTextChanged(e);
            if (IsAuto)
            {
                IsTextSearch = !String.IsNullOrWhiteSpace(Text);
            }
        }

        /// <summary>
        /// Executes the search on enter or return.
        /// </summary>
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Enter || e.Key == Key.Return)
            {
                ExecuteSearch();
            }
            base.OnPreviewKeyDown(e);
        }

        private void ExecuteSearch()
        {
            if (SearchCommand != null && SearchCommand.CanExecute(Text))
            {
                SearchCommand.Execute(Text);
            }
        }
    }
}
