﻿using System.Windows;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Class created to add dynamic columns to the grid view
    /// </summary>
    public class GenericColumn : BaseViewModel
    {
        #region Properties


        /// <summary>
        /// The data member binding
        /// </summary>
        private string _dataMemberBinding;

        /// <summary>
        /// Gets or sets the data member binding.
        /// </summary>
        /// <value>
        /// The data member binding.
        /// </value>
        public string DataMemberBinding
        {
            get { return _dataMemberBinding; }
            set { Set(() => DataMemberBinding, ref _dataMemberBinding, value); }
        }

        /// <summary>
        /// The header group name
        /// </summary>
        private string _headerGroupName;

        /// <summary>
        /// Gets or sets the name of the header group.
        /// </summary>
        /// <value>
        /// The name of the header group.
        /// </value>
        public string HeaderGroupName
        {
            get { return _headerGroupName; }
            set { Set(() => HeaderGroupName, ref _headerGroupName, value); }
        }

        /// <summary>
        /// The header group name wrapping
        /// </summary>
        private TextWrapping? _headerGroupNameWrapping;

        /// <summary>
        /// Gets or sets the header group name wrapping.
        /// </summary>
        /// <value>
        /// The header group name wrapping.
        /// </value>
        public TextWrapping? HeaderGroupNameWrapping
        {
            get { return _headerGroupNameWrapping; }
            set { Set(() => HeaderGroupNameWrapping, ref _headerGroupNameWrapping, value); }
        }

        /// <summary>
        /// The header group text
        /// </summary>
        private string _headerGroupText;

        /// <summary>
        /// Gets or sets the header group name text.
        /// </summary>
        /// <value>
        /// The header group name text.
        /// </value>
        public string HeaderGroupText
        {
            get { return _headerGroupText; }
            set { Set(() => HeaderGroupText, ref _headerGroupText, value); }
        }

        /// <summary>
        /// The header group template
        /// </summary>
        private string _headerGroupTemplate;
        /// <summary>
        /// Gets or sets the header group template.
        /// </summary>
        /// <value>
        /// The header group template.
        /// </value>
        public string HeaderGroupTemplate
        {
            get { return _headerGroupTemplate; }
            set { Set(() => HeaderGroupTemplate, ref _headerGroupTemplate, value); }
        }

        /// <summary>
        /// The identifier
        /// </summary>
        private string _identifier;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Identifier
        {
            get { return _identifier; }
            set { Set(() => Identifier, ref _identifier, value); }
        }

        /// <summary>
        /// The header
        /// </summary>
        private string _header;

        /// <summary>
        /// Gets or sets the header.
        /// </summary>
        /// <value>
        /// The header.
        /// </value>
        public string Header
        {
            get { return _header; }
            set { Set(() => Header, ref _header, value); }
        }

        /// <summary>
        /// The value
        /// </summary>
        private object _value;

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value.
        /// </value>
        public object Value
        {
            get { return _value; }
            set { Set(() => Value, ref _value, value); }
        }

        /// <summary>
        /// The content template
        /// </summary>
        private string _contentTemplate;

        /// <summary>
        /// Gets or sets the content template.
        /// </summary>
        /// <value>
        /// The content template.
        /// </value>
        public string ContentTemplate
        {
            get { return _contentTemplate; }
            set { Set(() => ContentTemplate, ref _contentTemplate, value); }
        }

        /// <summary>
        /// The content edit template
        /// </summary>
        private string _contentEditTemplate;

        /// <summary>
        /// Gets or sets the content edit template.
        /// </summary>
        /// <value>
        /// The content edit template.
        /// </value>
        public string ContentEditTemplate
        {
            get { return _contentEditTemplate; }
            set { Set(() => ContentEditTemplate, ref _contentEditTemplate, value); }
        }

        /// <summary>
        /// The header style
        /// </summary>
        private string _headerStyle;

        /// <summary>
        /// Gets or sets the header style.
        /// </summary>
        /// <value>
        /// The header style.
        /// </value>
        public string HeaderStyle
        {
            get { return _headerStyle; }
            set { Set(() => HeaderStyle, ref _headerStyle, value); }
        }

        /// <summary>
        /// The minimum width.
        /// </summary>
        private double? _minWidth;

        /// <summary>
        /// Gets or sets the minimum width.
        /// </summary>
        /// <value>
        /// The minimum width.
        /// </value>
        public double? MinWidth
        {
            get { return _minWidth; }
            set { Set(() => MinWidth, ref _minWidth, value); }
        }

        /// <summary>
        /// The maximum width.
        /// </summary>
        private double? _maxWidth;

        /// <summary>
        /// Gets or sets the maximum width.
        /// </summary>
        /// <value>
        /// The maximum width.
        /// </value>
        public double? MaxWidth
        {
            get { return _maxWidth; }
            set { Set(() => MaxWidth, ref _maxWidth, value); }
        }

        /// <summary>
        /// The text alignment.
        /// </summary>
        private TextAlignment? _textAlignment;

        /// <summary>
        /// Gets or sets the text alignment.
        /// </summary>
        /// <value>
        /// The text alignment.
        /// </value>
        public TextAlignment? TextAlignment
        {
            get { return _textAlignment; }
            set { Set(() => TextAlignment, ref _textAlignment, value); }
        }

        /// <summary>
        /// The is read only binding.
        /// </summary>
        private string _isReadOnlyBinding;

        /// <summary>
        /// Gets or sets the is read only binding.
        /// </summary>
        /// <value>
        /// The is read only binding.
        /// </value>
        public string IsReadOnlyBinding
        {
            get { return _isReadOnlyBinding; }
            set { Set(() => IsReadOnlyBinding, ref _isReadOnlyBinding, value); }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericColumn"/> class.
        /// </summary>
        /// <param name="navigationContext">The related <see cref="INavigationContext" />.</param>
        public GenericColumn(INavigationContext navigationContext)
            :base(navigationContext)
        {
        }

        #endregion

        #region Cleanups

        /// <summary>
        /// Cleans up the instance resources.
        /// <para>
        /// To cleanup additional resources, override this method, clean up and then call base.Cleanup().
        /// </para>
        /// </summary>
        public override void Cleanup()
        {
            if (Value != null)
            {
                Value = null;
            }
            base.Cleanup();
        }

        #endregion
    }
}
