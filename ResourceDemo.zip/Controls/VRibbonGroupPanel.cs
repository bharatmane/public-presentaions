﻿using System;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.ViewModel.Menu;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The panel used to layout items in the <see cref="VRibbonGroup"/>.
    /// </summary>
    public class VRibbonGroupPanel : Panel
    {
        /// <summary>
        /// An attached property for setting the size of a ribbon groups item.
        /// </summary>
        public static readonly DependencyProperty SizeProperty =
            DependencyProperty.RegisterAttached("Size", typeof(DisplaySize), typeof(VRibbonGroupPanel), new FrameworkPropertyMetadata(DisplaySize.Medium, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange ));
        /// <summary>
        /// Sets the size.
        /// </summary>
        public static void SetSize(UIElement element, DisplaySize value)
        {
            element.SetValue(SizeProperty, value);
        }
        /// <summary>
        /// Gets the size.
        /// </summary>
        public static DisplaySize GetSize(UIElement element)
        {
            return (DisplaySize)element.GetValue(SizeProperty);
        }

        /// <summary>
        /// Measures the items in the panel.
        /// </summary>
        protected override Size MeasureOverride(Size availableSize)
        {
            var currentX = 0d;
            var currentY = 0d;
            var currentMaxX = 0d;
            var measure = new Size(double.PositiveInfinity, double.PositiveInfinity);
           
            foreach (UIElement child in Children)
            {
                child.Measure(measure);
                var desiredY = child.DesiredSize.Height + currentY;
                if (desiredY > availableSize.Height)
                {
                    currentX = currentMaxX;
                    currentY = 0;
                }
                currentY = child.DesiredSize.Height + currentY;
                currentMaxX = Math.Max(currentMaxX, currentX + child.DesiredSize.Width);
            }
            return new Size(currentMaxX, availableSize.Height);
        }

        /// <summary>
        /// Arranges the items in the panel.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var currentX = 0d;
            var currentY = 0d;
            var currentMaxX = 0d;
            foreach (UIElement child in Children)
            {
                var desiredY = child.DesiredSize.Height + currentY;
                if (desiredY > finalSize.Height)
                {
                    currentX = currentMaxX;
                    currentY = 0;
                }
                child.Arrange(new Rect(currentX, currentY, child.DesiredSize.Width, child.DesiredSize.Height));
                currentY = child.DesiredSize.Height + currentY;
                currentMaxX = Math.Max(currentMaxX, currentX + child.DesiredSize.Width);
            }
            return base.ArrangeOverride(finalSize);
        }

        
    }

}
