﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Telerik.Windows.Controls;
using VShips.Framework.Resource.Helpers;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Implementation of VAutoCompleteBox
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.RadAutoCompleteBox" />
    public class VAutoCompleteBox : RadAutoCompleteBox
    {
        #region Properties
        /// <summary>
        /// Gets or sets a value indicating whether [show duplicate items].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show duplicate items]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowDuplicateItems
        {
            get { return (bool)GetValue(ShowDuplicateItemsProperty); }
            set { SetValue(ShowDuplicateItemsProperty, value); }
        }

        /// <summary>
        /// The show duplicate items property
        /// </summary>
        public static readonly DependencyProperty ShowDuplicateItemsProperty =
            DependencyProperty.Register("ShowDuplicateItems", typeof(bool), typeof(VAutoCompleteBox), new PropertyMetadata(false, OnShowDuplicateItemsChanged));



        /// <summary>
        /// Gets or sets a value indicating whether this instance can delete selected items.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can delete selected items; otherwise, <c>false</c>.
        /// </value>
        public bool CanDeleteItemsOnBackSpace
        {
            get { return (bool)GetValue(CanDeleteItemsOnBackSpaceProperty); }
            set { SetValue(CanDeleteItemsOnBackSpaceProperty, value); }
        }

        /// <summary>
        /// The can delete selected items property
        /// </summary>
        public static readonly DependencyProperty CanDeleteItemsOnBackSpaceProperty =
            DependencyProperty.Register("CanDeleteItemsOnBackSpace", typeof(bool), typeof(VAutoCompleteBox), new PropertyMetadata(true));


        /// <summary>
        /// The error member binding property
        /// </summary>
        public static readonly DependencyProperty ErrorMemberBindingProperty =
            DependencyProperty.Register("ErrorMemberBinding", typeof(string), typeof(VAutoCompleteBox), new PropertyMetadata(string.Empty));

        /// <summary>
        /// Gets or sets the error member binding.
        /// </summary>
        /// <value>
        /// The error member binding.
        /// </value>
        public string ErrorMemberBinding
        {
            get { return (string)GetValue(ErrorMemberBindingProperty); }
            set { SetValue(ErrorMemberBindingProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [clear text if not available in list].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [clear text if not available in list]; otherwise, <c>false</c>.
        /// </value>
        public bool ClearTextIfNotAvailableInList
        {
            get { return (bool)GetValue(ClearTextIfNotAvailableInListProperty); }
            set { SetValue(ClearTextIfNotAvailableInListProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ClearTextIfNotAvailableInList.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The clear text if not available in list property
        /// </summary>
        public static readonly DependencyProperty ClearTextIfNotAvailableInListProperty =
            DependencyProperty.Register("ClearTextIfNotAvailableInList", typeof(bool), typeof(VAutoCompleteBox), new PropertyMetadata(false));
        
        #endregion

        #region Overridden Methods
        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            RadButton arrow = Template.FindName("PART_PathButtonDownArrow", this) as RadButton;
            if (arrow != null)
            {
                arrow.Click += OnPathButtonArrowClicked;
            }
            FilteringBehavior = new EmptyTextFilteringBehavior();
            if (FilteringBehavior is EmptyTextFilteringBehavior && ShowDuplicateItems)
            {
                (FilteringBehavior as EmptyTextFilteringBehavior).ShowDuplicate(ShowDuplicateItems);
            }

            base.OnApplyTemplate();
        }

        /// <summary>
        /// Invoked when an unhandled <see cref="E:System.Windows.Input.Keyboard.PreviewKeyDown" /> attached event reaches an element in its route that is derived from this class. Implement this method to add class handling for this event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Windows.Input.KeyEventArgs" /> that contains the event data.</param>
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if ((e.Key == Key.Back) && string.IsNullOrEmpty(SearchText) && !CanDeleteItemsOnBackSpace)
            {
                e.Handled = true;
            }
            base.OnPreviewKeyDown(e);
        }

        /// <summary>
        /// Raises the <see cref="E:GotKeyboardFocus" /> event.
        /// </summary>
        /// <param name="e">The <see cref="KeyboardFocusChangedEventArgs"/> instance containing the event data.</param>
        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            RadWatermarkTextBox textBox = (UIHelper.FindVisualChild<RadWatermarkTextBox>(this) as RadWatermarkTextBox);
            if (textBox != null)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    textBox.Focus();
                    Keyboard.Focus(textBox);
                    textBox.SelectAll();
                }), DispatcherPriority.Input);
            }
            base.OnGotKeyboardFocus(e);
        }

        /// <summary>
        /// Invoked when an unhandled <see cref="E:System.Windows.Input.Keyboard.LostKeyboardFocus" /> attached event reaches an element in its route that is derived from this class. Implement this method to add class handling for this event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Windows.Input.KeyboardFocusChangedEventArgs" /> that contains event data.</param>
        protected override void OnLostKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            if (ClearTextIfNotAvailableInList)
            {
                VAutoCompleteBox control = null;
                //The source property of KeyboardFocusChangedEventArgs contains the control from where the event was generated.
                //Here the source is converted to VAutoComopleteBox.
                if (e.Source is VAutoCompleteBox)
                {
                    control = (VAutoCompleteBox)e.Source;
                }
                //In some cases like the control was AutoCompleteBoxesItemsControl and the TemplatedParent was the main control..
                //So here the templatedparent is converted to VAutoCompleteBox.
                else if (e.Source is AutoCompleteBoxesItemsControl)
                {
                    control = ((AutoCompleteBoxesItemsControl)e.Source).TemplatedParent as VAutoCompleteBox;
                }
                if (control != null && control.ItemsSource != null && !string.IsNullOrWhiteSpace(control.SearchText))
                {
                    //The selected items of control is of type IEnumerable here it is converted to IEnumerable<object> so that linq can be performed on it.
                    IEnumerable<object> selectedItems = control.SelectedItems.Cast<object>().ToList();

                    //Whenever an item is selected the SelectedItem and SelectedItems both are set to that value.
                    //So instead of checking both selectedItem and SelectedItems. Here only SelectedItems is checked to be containing atleast on element.
                    //For multiselect control the search text remains if there is not any matching data for that text. So after the focus is lost the search text is cleared.
                    if ((!selectedItems.Any() && control.SelectionMode == Telerik.Windows.Controls.Primitives.AutoCompleteSelectionMode.Single) ||
                          control.SelectionMode == Telerik.Windows.Controls.Primitives.AutoCompleteSelectionMode.Multiple)
                    {
                        control.SearchText = string.Empty;
                    }
                }
            }
        }
        #endregion

        #region Methods        
        /// <summary>
        /// Called when [path button arrow clicked].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs" /> instance containing the event data.</param>
        private void OnPathButtonArrowClicked(object sender, System.Windows.RoutedEventArgs e)
        {
            if (!IsDropDownOpen)
            {
                IsDropDownOpen = true;
                Populate("");
            }
            else
            {
                IsDropDownOpen = false;
            }
            base.OnIsDropDownOpenChanged(IsDropDownOpen);
        }

        /// <summary>
        /// Called when [show duplicate items changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnShowDuplicateItemsChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            VAutoCompleteBox control = sender as VAutoCompleteBox;
            if (control.FilteringBehavior is EmptyTextFilteringBehavior)
            {
                (control.FilteringBehavior as EmptyTextFilteringBehavior).ShowDuplicate((bool)e.NewValue);
            }
        }
        #endregion
    }

    /// <summary>
    /// EmptyTextFilteringBehavior class implementation
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.FilteringBehavior" />
    public class EmptyTextFilteringBehavior : FilteringBehavior
    {
        #region Private Properties
        /// <summary>
        /// The show duplicate
        /// </summary>
        private bool _showDuplicate;
        #endregion

        #region Methods
        /// <summary>
        /// Initializes a new instance of the <see cref="EmptyTextFilteringBehavior" /> class.
        /// </summary>
        /// <param name="ShowDuplicate">if set to <c>true</c> [show duplicate].</param>
        public void ShowDuplicate(bool ShowDuplicate)
        {
            _showDuplicate = ShowDuplicate;
        }
        #endregion

        #region Overriden Methods
        /// <summary>
        /// Finds the matching items.
        /// </summary>
        /// <param name="searchText">The search text.</param>
        /// <param name="items">The items.</param>
        /// <param name="escapedItems">The escaped items.</param>
        /// <param name="textSearchPath">The text search path.</param>
        /// <param name="textSearchMode">The text search mode.</param>
        /// <returns></returns>
        public override IEnumerable<object> FindMatchingItems(string searchText, System.Collections.IList items, IEnumerable<object> escapedItems, string textSearchPath, TextSearchMode textSearchMode)
        {
            if (_showDuplicate)
            {
                escapedItems = escapedItems.OfType<object>().Where(x => string.IsNullOrEmpty(x.ToString()));
            }
            if (string.IsNullOrWhiteSpace(searchText))
            {
                return items.OfType<object>().Where(x => !escapedItems.Contains(x));
            }
            else
            {
                return base.FindMatchingItems(searchText, items, escapedItems, textSearchPath, textSearchMode);
            }
        }
        #endregion
    }
}