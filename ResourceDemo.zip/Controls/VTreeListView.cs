﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Controls.TreeListView;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// VShips Tree view control
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.RadTreeView" />
    public class VTreeListView : RadTreeListView
    {
        #region Properties
        /// <summary>
        /// Gets or sets a value indicating whether this instance is maintain selection.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is maintain selection; otherwise, <c>false</c>.
        /// </value>
        public bool IsMaintainSelection
        {
            get { return (bool)GetValue(IsMaintainSelectionProperty); }
            set { SetValue(IsMaintainSelectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsMaintainSelection.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The is maintain selection property
        /// </summary>
        public static readonly DependencyProperty IsMaintainSelectionProperty =
            DependencyProperty.Register("IsMaintainSelection", typeof(bool), typeof(VTreeListView), new PropertyMetadata(false, OnIsMaintainSelectionChanged));



        /// <summary>
        /// Gets or sets a value indicating whether this instance is expansion from view model.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is expansion from view model; otherwise, <c>false</c>.
        /// </value>
        public bool IsExpansionFromViewModel
        {
            get { return (bool)GetValue(IsExpansionFromViewModelProperty); }
            set { SetValue(IsExpansionFromViewModelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsExpansionFromViewModel.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The is expansion from view model property
        /// </summary>
        public static readonly DependencyProperty IsExpansionFromViewModelProperty =
            DependencyProperty.Register("IsExpansionFromViewModel", typeof(bool), typeof(VTreeListView), new PropertyMetadata(false, IsExpansionFromViewModel_Changed));



        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="VTreeListView"/> class.
        /// </summary>
        public VTreeListView() 
            : base()
        {
            RowIsExpandedChanged += VTreeListView_RowIsExpandedChanged;
        }

        #endregion

        #region Methods


        /// <summary>
        /// Handles the RowIsExpandedChanged event of the VTreeListView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RowEventArgs"/> instance containing the event data.</param>
        private void VTreeListView_RowIsExpandedChanged(object sender, RowEventArgs e)
        {
            var row = e.Row as TreeListViewRow;
            if (row == null)
            {
                return;
            }
            else
            {
                var d = row.DataContext as ISearchTreeNode;
                if (d != null)
                {
                    d.OnTreeNodeExpansion(row.IsExpanded);
                }
            }
        }

        /// <summary>
        /// Determines whether [is expansion from view model changed] [the specified d].
        /// When IsExpansionFromViewModel dependency property is changed in View model the tree is refreshed again
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="System.Windows.DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        public static void IsExpansionFromViewModel_Changed(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                var tree = d as VTreeListView;
                if (tree != null)
                {
                    tree.Rebind();
                }
            }
        }
        
        /// <summary>
        /// Called when [is maintain selection changed].
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="eventArguments">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnIsMaintainSelectionChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs eventArguments)
        {
            var treeView = dependencyObject as RadTreeListView;
            if (treeView != null)
            {
                if ((bool)eventArguments.NewValue)
                {
                    treeView.SelectionChanged += TreeView_SelectionChanged;
                    treeView.RowLoaded += TreeView_RowLoaded;
                    treeView.DataLoaded += TreeView_DataLoaded;
                }
            }
        }

        /// <summary>
        /// Handles the DataLoaded event of the TreeView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private static void TreeView_DataLoaded(object sender, EventArgs e)
        {
            var tree = sender as VTreeListView;
            if (tree != null && tree.SelectedItems != null && tree.SelectedItems.Any())
            {
                tree.ScrollIntoView(tree.SelectedItems.First());
            }
        }
        
        /// <summary>
        /// Handles the RowLoaded event of the TreeView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RowLoadedEventArgs"/> instance containing the event data.</param>
        private static void TreeView_RowLoaded(object sender, RowLoadedEventArgs e)
        {
            var row = e.Row as TreeListViewRow;
            var tree = e.GridViewDataControl as VTreeListView;
            if (row == null || tree == null)
                return;
            
            tree.Dispatcher.BeginInvoke((Action)(() =>
            {
                if (row.DataContext != null)
                {
                    var d = row.DataContext as ISearchTreeNode;
                    row.IsExpanded = d.IsNodeExpandedViewModel;
                    row.IsSelected = d.IsSearched;
                    row.IsExpandable = d.IsNodeExpandable;
                    d.IsNodeExpandedView = d.IsNodeExpandedViewModel;
                }
            }));
        }

        /// <summary>
        /// Handles the SelectionChanged event of the TreeView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="SelectionChangeEventArgs"/> instance containing the event data.</param>
        private static void TreeView_SelectionChanged(object sender, SelectionChangeEventArgs e)
        {
            var gridView = (VTreeListView)sender;
            var scrollCollection = GetMultiSelectCollection(gridView);
            if (scrollCollection != null)
            {
                scrollCollection.TypeCastSelectedItems(gridView.SelectedItems);
            }
        }

        /// <summary>
        /// Gets the multi select collection.
        /// </summary>
        /// <param name="treeView">The tree view.</param>
        /// <returns></returns>
        private static IConvertibleCollection GetMultiSelectCollection(VTreeListView treeView)
        {
            if (treeView.ItemsSource != null)
            {
                var multiSelectCollection = treeView.ItemsSource as IConvertibleCollection;
                Debug.Assert(multiSelectCollection != null, "The Itemssource must implement IConvertibleCollection");
                return multiSelectCollection;
            }
            return null;
        }

        /// <summary>
        /// Detaches the selection for mark selected items.
        /// </summary>
        public void DetachSelectionForMarkSelectedItems()
        {
            SelectionChanged -= TreeView_SelectionChanged;
        }

        /// <summary>
        /// Attaches the selection for mark selected items.
        /// </summary>
        public void AttachSelectionForMarkSelectedItems()
        {
            SelectionChanged += TreeView_SelectionChanged;
        }

        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            Unloaded += gridView_Unloaded;
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Handles the Unloaded event of the gridView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void gridView_Unloaded(object sender, RoutedEventArgs e)
        {
            DetachSelectionForMarkSelectedItems();
            RowLoaded -= TreeView_RowLoaded;
            DataLoaded -= TreeView_DataLoaded;
            Unloaded -= gridView_Unloaded;
            RowIsExpandedChanged -= VTreeListView_RowIsExpandedChanged;
        }
        #endregion

    }
}
