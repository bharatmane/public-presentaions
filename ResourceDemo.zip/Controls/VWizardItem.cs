﻿using System.Windows;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// An item in the wizard control.
    /// </summary>
    public class VWizardItem : RadTabItem
    {
        /// <summary>
        /// The status of the current item.
        /// </summary>
        public static readonly DependencyProperty StatusProperty =
            DependencyProperty.Register("Status", typeof(WizardStatus), typeof(VWizardItem), new PropertyMetadata(WizardStatus.NotStarted));
        /// <summary>
        /// Exposes the <see cref="StatusProperty"/> DependencyProperty.
        /// </summary>
        public WizardStatus Status
        {
            get { return (WizardStatus)GetValue(StatusProperty); }
            set { SetValue(StatusProperty, value); }
        }

        static VWizardItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VWizardItem), new FrameworkPropertyMetadata(typeof(VWizardItem)));
        }
        
    }

    /// <summary>
    /// The status of the wizard item.
    /// </summary>
    public enum WizardStatus
    {
        /// <summary>
        /// The item is not started.
        /// </summary>
        NotStarted,

        /// <summary>
        /// The item is in progress.
        /// </summary>
        InProgress,

        /// <summary>
        /// The item is complete.
        /// </summary>
        Complete,

        /// <summary>
        /// The item is in error.
        /// </summary>
        Error
    }
}
