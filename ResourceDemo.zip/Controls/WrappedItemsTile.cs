﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Represents a tile in the wrapped items control.
    /// </summary>
    public class WrappedItemsTile : ContentControl
    {
        static WrappedItemsTile()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(WrappedItemsTile), new FrameworkPropertyMetadata(typeof(WrappedItemsTile)));
        }
    }
}
