﻿using System.Windows;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    ///  A tab item for the <see cref="TitlebarTabControl"/>.
    /// </summary>
    public class HyperLinkTabItem : RadTabItem
    {
        #region Dependency Properties
        /// <summary>
        /// The is last item property
        /// </summary>
        public static readonly DependencyProperty IsLastItemProperty =
            DependencyProperty.Register("IsLastItem", typeof(bool), typeof(HyperLinkTabItem), new PropertyMetadata(false, OnLastItemChanged));
        #endregion

        #region Properties
        /// <summary>
        /// Exposes the <see cref="IsLastItemProperty"/> DependencyProperty.
        /// </summary>
        public bool IsLastItem
        {
            get { return (bool)GetValue(IsLastItemProperty); }
            set { SetValue(IsLastItemProperty, value); }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes the <see cref="HyperLinkTabItem"/> class.
        /// </summary>
        static HyperLinkTabItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(HyperLinkTabItem), new FrameworkPropertyMetadata(typeof(HyperLinkTabItem)));
        }
        #endregion

        #region Method
        /// <summary>
        /// Called when [last item changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnLastItemChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {}
        #endregion
    }
}