﻿namespace VShips.Framework.Resource.Controls.VSearchComboBox
{
    /// <summary>
    /// The Lookup interface for VSearchComboBox.
    /// </summary>
    public interface ISearchComboBoxLookUp
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        bool IsSelected { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        string Description { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        string Identifier { get; set; }

        /// <summary>
        /// Gets or sets the index.
        /// </summary>
        /// <value>
        /// The index.
        /// </value>
        /// Do not initialize this property as it is handled in control.
        int Index { get; set; }
    }
}
