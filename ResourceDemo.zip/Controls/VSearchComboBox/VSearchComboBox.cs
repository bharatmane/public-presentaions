﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls.VSearchComboBox
{
    /// <summary>
    /// Class for VSearchComboBox control.
    /// Sample usage.
    /// <vsearchcombobox:VSearchComboBox x:Name="SearchComboBox"
    ///                                  ItemsSource="{Binding ComboDemos}"
    ///                                  SelectedItem="{Binding ComboDemo}"
    ///                                  DisplayTemplate="{StaticResource DemoTemplate}"
    ///                                  TextSearch.TextPath="Description"
    ///                                  Width="380"
    ///                                  HorizontalAlignment="Left">
    ///</vsearchcombobox:VSearchComboBox>
    /// </summary>
    /// <seealso cref="Telerik.Windows.Controls.RadComboBox" />
    public class VSearchComboBox : RadComboBox
    {
        #region Properties
        /// <summary>
        /// The RAD watermark text box
        /// </summary>
        private RadWatermarkTextBox _radWatermarkTextBox;

        /// <summary>
        /// The is filter removed
        /// </summary>
        private bool _updateIsSelectedProperty;

        /// <summary>
        /// Gets or sets the display template.
        /// </summary>
        /// <value>
        /// The display template.
        /// </value>
        public DataTemplate DisplayTemplate
        {
            get { return (DataTemplate)GetValue(DisplayTemplateProperty); }
            set { SetValue(DisplayTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [sort by is selected].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [sort by is selected]; otherwise, <c>false</c>.
        /// </value>
        public bool SortByIsSelected
        {
            get { return (bool)GetValue(SortByIsSelectedProperty); }
            set { SetValue(SortByIsSelectedProperty, value); }
        }

        /// <summary>
        /// Gets or sets the display text.
        /// </summary>
        /// <value>
        /// The display text.
        /// </value>
        public string DisplayText
        {
            get { return (string)GetValue(DisplayTextProperty); }
            set { SetValue(DisplayTextProperty, value); }
        }
        #endregion

        #region Dependency Property       

        // Using a DependencyProperty as the backing store for DisplayTemplate.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The display template property
        /// </summary>
        public static readonly DependencyProperty DisplayTemplateProperty =
            DependencyProperty.Register("DisplayTemplate", typeof(DataTemplate), typeof(VSearchComboBox), new PropertyMetadata(null));

        // Using a DependencyProperty as the backing store for SortByIsSelected.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The sort by is selected property
        /// </summary>
        public static readonly DependencyProperty SortByIsSelectedProperty =
            DependencyProperty.Register("SortByIsSelected", typeof(bool), typeof(VSearchComboBox), new PropertyMetadata(true, OnSortByIsSelectedPropertyChanged));

        // Using a DependencyProperty as the backing store for DisplayText.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The display text property
        /// </summary>
        public static readonly DependencyProperty DisplayTextProperty =
            DependencyProperty.Register("DisplayText", typeof(string), typeof(VSearchComboBox), new PropertyMetadata(null));
        #endregion

        #region Constructor

        /// <summary>
        /// Initializes the <see cref="VSearchComboBox" /> class.
        /// </summary>
        static VSearchComboBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VSearchComboBox), new FrameworkPropertyMetadata(typeof(VSearchComboBox)));
        }

        #endregion

        #region Overridden Methods      

        /// <summary>
        /// Called when [apply template].
        /// </summary>
        public override void OnApplyTemplate()
        {
            _radWatermarkTextBox = GetTemplateChild("PART_SearchBox") as RadWatermarkTextBox;
            if (_radWatermarkTextBox != null)
            {
                _radWatermarkTextBox.TextChanged += SearchTextChanged;
            }
            Items.SortDescriptions.Add(new SortDescription("IsSelected", ListSortDirection.Descending));
            Items.SortDescriptions.Add(new SortDescription("Index", ListSortDirection.Ascending));
            Unloaded += VSearchComboBox_Unloaded;
            base.OnApplyTemplate();
        }

        /// <summary>
        /// Handles the Unloaded event of the VSearchComboBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void VSearchComboBox_Unloaded(object sender, RoutedEventArgs e)
        {
            if (_radWatermarkTextBox != null)
            {
                _radWatermarkTextBox.TextChanged -= SearchTextChanged;
            }
            Unloaded += VSearchComboBox_Unloaded;
        }

        /// <summary>
        /// Handles the key down.
        /// </summary>
        /// <param name="systemKey">The system key.</param>
        /// <param name="platformKeyCode">The platform key code.</param>
        /// <returns></returns>
        protected override bool HandleKeyDown(Key systemKey, int platformKeyCode)
        {
            if (systemKey == Key.Back)
            {
                return true;
            }

            return base.HandleKeyDown(systemKey, platformKeyCode);
        }

        /// <summary>
        /// Raises the <see cref="E:SelectionChanged" /> event.
        /// </summary>
        /// <param name="e">The <see cref="SelectionChangedEventArgs" /> instance containing the event data.</param>
        protected override void OnSelectionChanged(SelectionChangedEventArgs e)
        {
            if (_updateIsSelectedProperty)
            {
                if (e.AddedItems != null && e.AddedItems.Count > 0)
                {
                    for (int i = 0; i < e.AddedItems.Count; i++)
                    {
                        ((ISearchComboBoxLookUp)e.AddedItems[i]).IsSelected = true;

                    }
                }
                if (e.RemovedItems != null && e.RemovedItems.Count > 0 && _updateIsSelectedProperty)
                {
                    for (int i = 0; i < e.RemovedItems.Count; i++)
                    {

                        ((ISearchComboBoxLookUp)e.RemovedItems[i]).IsSelected = false;

                    }
                }
                UpdateSelectedItems();
            };
            base.OnSelectionChanged(e);

            if (!AllowMultipleSelection && _updateIsSelectedProperty)
            {
                IsDropDownOpen = false;
            }
        }

        /// <summary>
        /// Raises the <see cref="E:DropDownOpened" /> event.
        /// </summary>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        protected override void OnDropDownOpened(EventArgs e)
        {
            Items.IsLiveSorting = true;
            Items.Refresh();
            Items.IsLiveSorting = false;

            base.OnDropDownOpened(e);
            //This base.OnDropDownOpened() should be first because it has Display logic,
            //then only our custom logic should fire.
            var container = ItemContainerGenerator.ContainerFromIndex(0) as RadComboBoxItem;
            if (container != null)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    container.BringIntoView();
                }));
            }
        }

        /// <summary>
        /// Raises the <see cref="E:DropDownClosed" /> event.
        /// </summary>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        protected override void OnDropDownClosed(EventArgs e)
        {
            _radWatermarkTextBox.Text = string.Empty;
            base.OnDropDownClosed(e);
        }

        /// <summary>
        /// Updates the current selection when an item in the <see cref="T:System.Windows.Controls.Primitives.Selector" /> has changed
        /// </summary>
        /// <param name="e">The event data.</param>
        protected override void OnItemsChanged(NotifyCollectionChangedEventArgs e)
        {
            int i = 0;
            if (ItemsSource != null)
            {
                foreach (var item in ItemsSource)
                {
                    (item as ISearchComboBoxLookUp).Index = i;
                    i++;
                }
            }
            UpdateSelectedItems();
            base.OnItemsChanged(e);
        }
        #endregion

        #region Methods

        /// <summary>
        /// Updates the selected items.
        /// </summary>
        private void UpdateSelectedItems()
        {
            _updateIsSelectedProperty = false;
            if (AllowMultipleSelection && ItemsSource != null)
            {
                Transfer(ItemsSource.Cast<ISearchComboBoxLookUp>().Where(x => x.IsSelected).ToList() as IList, base.SelectedItems);
            }
            else if (!AllowMultipleSelection && ItemsSource != null)
            {
                SelectedItem = ItemsSource.Cast<ISearchComboBoxLookUp>().Where(x => x.IsSelected).ToList().FirstOrDefault();
            }
            _updateIsSelectedProperty = true;
            if (ItemsSource != null)
            {
                DisplayText = string.Join(MultipleSelectionSeparator.ToString(), ItemsSource.Cast<ISearchComboBoxLookUp>().Where(x => x.IsSelected).Select(x => x.Description).ToList());
            }
        }

        /// <summary>
        /// Handles the KeyUp event of the RadWatermarkTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Input.KeyEventArgs" /> instance containing the event data.</param>
        private void SearchTextChanged(object sender, TextChangedEventArgs e)
        {
            _updateIsSelectedProperty = false;
            if (ItemsSource != null)
            {
                CollectionView itemsViewOriginal = (CollectionView)CollectionViewSource.GetDefaultView(ItemsSource);

                itemsViewOriginal.Filter += FilterPredicate;
                DisplayText = string.Join(MultipleSelectionSeparator.ToString(), ItemsSource.Cast<ISearchComboBoxLookUp>().Where(x => x.IsSelected).Select(x => x.Description).ToList());
            }
            _updateIsSelectedProperty = true;
        }

        /// <summary>
        /// Filters the predicate.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        private bool FilterPredicate(object value)
        {
            var item = value as ISearchComboBoxLookUp;
            var text = _radWatermarkTextBox.Text;
            if (!(value is string))
            {
                var textPath = (string)GetValue(System.Windows.Controls.TextSearch.TextPathProperty);
                if (textPath != null)
                {
                    value = value.GetType().GetProperty(textPath).GetValue(value);
                }
            }

            // No text, no filter
            if (text.Length == 0)
            {
                return true;
            }

            // Case insensitive search, selected items will be retained in search.
            return value.ToString().ToLower().Contains(text.ToLower());
        }

        /// <summary>
        /// Transfers the specified source.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        public static void Transfer(IList source, IList target)
        {
            if (source == null || target == null)
                return;

            target.Clear();
            foreach (var o in source)
            {
                target.Add(o);
            }
        }

        /// <summary>
        /// Called when [sort by is selected property changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        /// <exception cref="NotImplementedException"></exception>
        private static void OnSortByIsSelectedPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var combobox = d as VSearchComboBox;
            if (!combobox.SortByIsSelected)
            {
                combobox.Items.IsLiveSorting = false;
                combobox.Items.SortDescriptions.Clear();
                combobox.Items.SortDescriptions.Add(new SortDescription("Index", ListSortDirection.Ascending));
            }
            if (combobox.SortByIsSelected)
            {
                combobox.Items.IsLiveSorting = true;
                combobox.Items.SortDescriptions.Clear();
                combobox.Items.SortDescriptions.Add(new SortDescription("IsSelected", ListSortDirection.Descending));
                combobox.Items.SortDescriptions.Add(new SortDescription("Index", ListSortDirection.Ascending));
            }
        }
        #endregion
    }
}