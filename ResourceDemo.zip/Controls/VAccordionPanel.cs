﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The panel used to layout items in the accordian.
    /// </summary>
    public class VAccordionPanel : Panel
    {
        /// <summary>
        /// An attached property that determines the expanded item.
        /// </summary>
        public static readonly DependencyProperty IsItemExpandedProperty =
            DependencyProperty.RegisterAttached("IsItemExpanded", typeof(bool), typeof(VAccordionPanel), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsParentMeasure | FrameworkPropertyMetadataOptions.AffectsParentArrange));
        /// <summary>
        /// Exposes the <see cref="IsItemExpandedProperty"/> DependencyProperty.
        /// </summary>
        public static void SetIsItemExpanded(UIElement element, bool value)
        {
            element.SetValue(IsItemExpandedProperty, value);
        }
        /// <summary>
        /// Exposes the <see cref="IsItemExpandedProperty"/> DependencyProperty.
        /// </summary>
        public static bool GetIsItemExpanded(UIElement element)
        {
            return (bool)element.GetValue(IsItemExpandedProperty);
        }

        /// <summary>
        /// Measures the items in the panel.
        /// </summary>
        protected override Size MeasureOverride(Size availableSize)
        {
            var all = Children.OfType<FrameworkElement>().ToList();
            var children = all.Where(x => !GetIsItemExpanded(x)).ToList();
            var expanded = all.FirstOrDefault(GetIsItemExpanded);
            var height = 0d;

            foreach (var child in children)
            {
                child.Measure(availableSize);
                height = height + child.DesiredSize.Height;
            }

            if (expanded != null)
            {
                var remaining = Math.Max(availableSize.Height - height, 0);
                expanded.Measure(new Size(availableSize.Width, remaining));
            }

            return base.MeasureOverride(availableSize);
        }

        /// <summary>
        /// Arranges the items in the panel.
        /// </summary>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var all = Children.OfType<FrameworkElement>().ToList();
            var currentY = 0d;

            foreach (var child in all)
            {
                child.Arrange(new Rect(0, currentY, finalSize.Width, child.DesiredSize.Height));
                currentY = currentY + child.DesiredSize.Height;
            }

            return base.ArrangeOverride(finalSize);
        }
    }
}
