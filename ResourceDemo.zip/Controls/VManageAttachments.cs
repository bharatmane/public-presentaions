﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Control for managing attachment in application where you do not have drag and drop area available.
    /// DO NOT DELETE THIS BLANK CLASS. BEFORE MAKING ANY CHANGE, SPEAK TO PUNIT JAIN (PI TEAM)
    /// </summary>
    public class VManageAttachments : Control
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="VManageAttachments"/> class.
        /// </summary>
        public VManageAttachments()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VManageAttachments), new FrameworkPropertyMetadata(typeof(VManageAttachments)));
        }
        #endregion
    }
}
