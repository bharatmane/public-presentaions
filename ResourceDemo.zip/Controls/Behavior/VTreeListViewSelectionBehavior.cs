﻿using System.Collections;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Interactivity;

namespace VShips.Framework.Resource.Controls.Behavior
{
    /// <summary>
    /// Bahavior class for VShips Tree View
    /// </summary>
    /// <seealso cref="System.Windows.Interactivity.Behavior{VShips.Framework.Resource.Controls.VTreeListView}" />
    public class VTreeListViewSelectionBehavior : Behavior<VTreeListView>
    {
        #region Properties
        /// <summary>
        /// The is local transfer in progress
        /// </summary>
        private bool _isLocalTransferInProgress;

        /// <summary>
        /// Gets or sets the selected items.
        /// </summary>
        /// <value>
        /// The selected items.
        /// </value>
        public INotifyCollectionChanged SelectedItems
        {
            get { return (INotifyCollectionChanged)GetValue(SelectedItemsProperty); }
            set { SetValue(SelectedItemsProperty, value); }
        }

        /// <summary>
        /// The selected items property
        /// </summary>
        public static readonly DependencyProperty SelectedItemsProperty =
            DependencyProperty.Register("SelectedItems",
                typeof(INotifyCollectionChanged),
                typeof(VTreeListViewSelectionBehavior),
                new PropertyMetadata(null, OnSelectedItemsPropertyChanged));

        #endregion

        #region Methods

        /// <summary>
        /// Called when [selected items property changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnSelectedItemsPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var collection = e.NewValue as INotifyCollectionChanged;
            if (collection != null)
            {
                collection.CollectionChanged += ((VTreeListViewSelectionBehavior)d).Context_CollectionChanged;
            }
        }

        /// <summary>
        /// Handles the CollectionChanged event of the Context control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="NotifyCollectionChangedEventArgs"/> instance containing the event data.</param>
        private void Context_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (!_isLocalTransferInProgress)
            {
                UnsubscribeFromEvents();

                Transfer(SelectedItems as IList, AssociatedObject.SelectedItems);

                SubscribeToEvents();
            }
        }

        /// <summary>
        /// Unsubscribes from events.
        /// </summary>
        private void UnsubscribeFromEvents()
        {
            AssociatedObject.DetachSelectionForMarkSelectedItems();

            if (SelectedItems != null)
            {
                SelectedItems.CollectionChanged -= Context_CollectionChanged;
            }
        }

        /// <summary>
        /// Subscribes to events.
        /// </summary>
        private void SubscribeToEvents()
        {
            AssociatedObject.AttachSelectionForMarkSelectedItems();

            if (SelectedItems != null)
            {
                SelectedItems.CollectionChanged += Context_CollectionChanged;
            }
        }

        /// <summary>
        /// Transfers the specified source.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        private void Transfer(IList source, IList target)
        {
            if (source == null || target == null)
                return;

            _isLocalTransferInProgress = true;
            target.Clear();

            foreach (var s in source)
            {
                target.Add(s);
            }
            _isLocalTransferInProgress = false;
        }
        #endregion
    }
}
