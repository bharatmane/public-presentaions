﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;
using Telerik.Windows.DragDrop;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Resource.Controls.Behavior
{
    /// <summary>
    /// DO NOT USE: REVIEW PENDING. HAD TO CHECKIN FOR DEMO
    /// Grid view drag drop behavior class
    /// </summary>
    /// <seealso cref="System.Windows.Interactivity.Behavior{VShips.Framework.Resource.Controls.VGridView}" />
    public class VGridViewDragDropBehavior : Behavior<VGridView>
    {

        #region Properties
        /// <summary>
        /// Gets or sets the grid events handler.
        /// </summary>
        /// <value>
        /// The grid events handler.
        /// </value>
        public IDragDropHandler GridEventsHandler
        {
            get { return (IDragDropHandler)GetValue(GridEventsHandlerProperty); }
            set { SetValue(GridEventsHandlerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GridEventsHandler.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The grid events handler property
        /// </summary>
        public static readonly DependencyProperty GridEventsHandlerProperty =
            DependencyProperty.Register("GridEventsHandler", typeof(IDragDropHandler), typeof(VGridViewDragDropBehavior), new PropertyMetadata(null));

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="VGridViewDragDropBehavior"/> class.
        /// </summary>
        public VGridViewDragDropBehavior()
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Called when [drag initialize].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragInitializeEventArgs" /> instance containing the event data.</param>
        private void OnDragInitialize(object sender, DragInitializeEventArgs e)
        {
            if (GridEventsHandler != null)
            {
                e.Data = AssociatedObject.SelectedItems;
                e.DragVisualOffset = e.RelativeStartPoint;
                e.AllowedEffects = DragDropEffects.All;

                var data = AssociatedObject.SelectedItems.Where(x => x != null).OfType<IDragData>().ToList();
                e.DragVisual = new ContentControl
                {
                    Content = DragAndDropItems.GetDragItems(data)
                };
                GridEventsHandler.DragInitialize(AssociatedObject.SelectedItems);
            }
        }

        /// <summary>
        /// Called when [drag over].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Telerik.Windows.DragDrop.DragEventArgs" /> instance containing the event data.</param>
        private void OnDragOver(object sender, Telerik.Windows.DragDrop.DragEventArgs e)
        {
            e.Effects = DragDropEffects.Move;
        }

        /// <summary>
        /// Called when [drag drop completed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragDropCompletedEventArgs" /> instance containing the event data.</param>
        private void OnDragDropCompleted(object sender, DragDropCompletedEventArgs e)
        {
        }

        /// <summary>
        /// Called when [attached].
        /// </summary>
        protected override void OnAttached()
        {
            DragDropManager.AddDragInitializeHandler(AssociatedObject, OnDragInitialize, true);
            DragDropManager.AddDragOverHandler(AssociatedObject, OnDragOver, true);
            DragDropManager.AddDragDropCompletedHandler(AssociatedObject, OnDragDropCompleted, true);

            base.OnAttached();
        }

        /// <summary>
        /// Called when [detaching].
        /// </summary>
        protected override void OnDetaching()
        {
            DragDropManager.RemoveDragInitializeHandler(AssociatedObject, OnDragInitialize);
            DragDropManager.RemoveDragOverHandler(AssociatedObject, OnDragOver);
            DragDropManager.RemoveDragDropCompletedHandler(AssociatedObject, OnDragDropCompleted);

            base.OnDetaching();
        }

        #endregion

    }
}
