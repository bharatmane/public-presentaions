﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;
using System.Windows.Media;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using Telerik.Windows.Controls.TreeListView;
using Telerik.Windows.DragDrop;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Resource.Controls.Behavior
{
    /// <summary>
    /// Behaviour class for Drag drop feature of telerik tree list view
    /// </summary>
    /// <seealso cref="System.Windows.Interactivity.Behavior{VShips.Framework.Resource.Controls.VTreeListView}" />
    public class VTreeListViewDragDropBehavior : Behavior<VTreeListView>
    {

        #region Properties
        /// <summary>
        /// The last dropped target
        /// </summary>
        private object _lastDroppedTarget;

        /// <summary>
        /// Gets or sets the drag drop handler.
        /// </summary>
        /// <value>
        /// The drag drop handler.
        /// </value>
        public IDragDropHandler DragDropHandler
        {
            get { return (IDragDropHandler)GetValue(DragDropHandlerProperty); }
            set { SetValue(DragDropHandlerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DragDropHandler.  This enables animation, styling, binding, etc...
        /// <summary>
        /// The drag drop handler property
        /// </summary>
        public static readonly DependencyProperty DragDropHandlerProperty =
            DependencyProperty.Register("DragDropHandler", typeof(IDragDropHandler), typeof(VTreeListViewDragDropBehavior), new PropertyMetadata(null));

        /// <summary>
        /// The previous cell dragged on
        /// </summary>
        private GridViewCell _previousDraggedOnCell;
        
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="VTreeListViewDragDropBehavior"/> class.
        /// </summary>
        public VTreeListViewDragDropBehavior()
        {
        }
        #endregion

        #region Methods

        /// <summary>
        /// Called when [attached].
        /// </summary>
        protected override void OnAttached()
        {
            DragDropManager.AddDragInitializeHandler(AssociatedObject, OnDragInitialize, true);
            DragDropManager.AddDropHandler(AssociatedObject, OnDrop, true);
            DragDropManager.AddDragDropCompletedHandler(AssociatedObject, OnDragDropCompleted, true);

            base.OnAttached();
        }        

        /// <summary>
        /// Called when [drag initialize].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragInitializeEventArgs"/> instance containing the event data.</param>
        private void OnDragInitialize(object sender, DragInitializeEventArgs e)
        {
            if (DragDropHandler != null)
            {
                Collection<object> sourceDraggedObjects = e.Data as Collection<object>;
                e.Cancel = !DragDropHandler.CanDrag(sourceDraggedObjects);
                if (!e.Cancel)
                {
                    //var payload = DragDropPayloadManager.GeneratePayload(null);
                    var data = sourceDraggedObjects.Where(x => x != null).OfType<IDragData>().ToList();
                    
                    /*payload.SetData("DragAndDropHelperData", data);
                    e.Data = payload;*/

                    e.DragVisual = new ContentControl
                    {
                        Content = DragAndDropItems.GetDragItems(data)
                    };
                    DragDropHandler.DragInitialize(sourceDraggedObjects);
                }
            }
        }

        /// <summary>
        /// Called when [drop].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Telerik.Windows.DragDrop.DragEventArgs"/> instance containing the event data.</param>
        private void OnDrop(object sender, Telerik.Windows.DragDrop.DragEventArgs e)
        {
            if (_previousDraggedOnCell != null)
            {
                _previousDraggedOnCell.Foreground = Brushes.Black;
            }

            if (e.Data != null && e.AllowedEffects != DragDropEffects.None)
            {
                if (DragDropHandler != null)
                {
                    _lastDroppedTarget = (e.OriginalSource as FrameworkElement).DataContext;

                    if (_lastDroppedTarget != null)
                    {
                        e.Handled = DragDropHandler.CanDrop(_lastDroppedTarget);
                        if (e.Handled)
                        {
                            DragDropHandler.Drop(_lastDroppedTarget);
                            e.Effects = DragDropEffects.Move;
                        }
                        else
                        {
                            e.Effects = DragDropEffects.None;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Called when [drag drop completed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="DragDropCompletedEventArgs"/> instance containing the event data.</param>
        private void OnDragDropCompleted(object sender, DragDropCompletedEventArgs e)
        {
            if (e.Data != null && e.Effects != DragDropEffects.None)
            {
                if (DragDropHandler != null)
                {
                    if (e.Effects == DragDropEffects.Move)
                    {
                        DragDropHandler.Move(e.Data, _lastDroppedTarget, (TreeListViewDropPosition)(e.OriginalSource as TreeListViewRow)
                            .GetValue(RadTreeListView.DropPositionProperty));
                    }
                    DragDropHandler.DragDropComplete(_lastDroppedTarget);
                }
            }
        }

        /// <summary>
        /// Called when [detaching].
        /// </summary>
        protected override void OnDetaching()
        {
            DragDropManager.RemoveDragInitializeHandler(AssociatedObject, OnDragInitialize);
            DragDropManager.RemoveDropHandler(AssociatedObject, OnDrop);
            DragDropManager.RemoveDragDropCompletedHandler(AssociatedObject, OnDragDropCompleted);

            _previousDraggedOnCell = null;

            base.OnDetaching();
        } 
        #endregion
    }
}
