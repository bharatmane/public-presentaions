﻿using DevExpress.DashboardWpf;
using DevExpress.Mvvm.UI.Interactivity;
using System;
using System.Windows;
using System.Windows.Input;
using DevExpress.Data;

//Dev Express Dashboard Thread Safe Event To Command
namespace VShips.Framework.Resource.Controls.Behavior
{
    public class DashboardEventToCmdBehaviour : Behavior<DashboardControl>
    {
        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.Register("Command", typeof(ICommand), typeof(DashboardEventToCmdBehaviour),
                new PropertyMetadata());

        public ICommand Command
        {
            get { return (ICommand) GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.AsyncDataLoading += AsyncDataLoading;
        }

        protected override void OnDetaching()
        {
            AssociatedObject.AsyncDataLoading -= AsyncDataLoading;
            base.OnDetaching();
        }

        private void AsyncDataLoading(object sender, DevExpress.DashboardCommon.DataLoadingEventArgs e)
        {
            ICommand command = null;
            Dispatcher.Invoke(() => command = Command);
            if (command != null)
                command.Execute(e);
        }

    }
}
