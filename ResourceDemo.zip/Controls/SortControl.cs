﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Control used to define sorting on a collection.
    /// </summary>
    public class SortControl : Selector
    {
        /// <summary>
        /// Gets or sets a value that determines if the popup is openened.
        /// </summary>
        public static readonly DependencyProperty IsOpenedProperty = 
            DependencyProperty.Register("IsOpened", typeof(bool), typeof(SortControl), new PropertyMetadata(false, OnIsOpenedChanged));
        /// <summary>
        /// Exposes the <see cref="IsOpenedProperty"/> DependencyProperty. 
        /// </summary>
        public bool IsOpened
        {
            get { return (bool)GetValue(IsOpenedProperty); }
            set { SetValue(IsOpenedProperty, value); }
        }

        /// <summary>
        /// Gets or sets the maximum height of the drop down.
        /// </summary>
        public static readonly DependencyProperty DropDownMaxHeightProperty =
            DependencyProperty.Register("DropDownMaxHeight", typeof(double), typeof(SortControl), new PropertyMetadata(400d));
        /// <summary>
        /// Exposes the <see cref="DropDownMaxHeightProperty"/> DependencyProperty. 
        /// </summary>
        public double DropDownMaxHeight
        {
            get { return (double)GetValue(DropDownMaxHeightProperty); }
            set { SetValue(DropDownMaxHeightProperty, value); }
        }

        static SortControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SortControl), new FrameworkPropertyMetadata(typeof(SortControl)));
        }

        /// <summary>
        /// Applies the template to the control
        /// </summary>
        public override void OnApplyTemplate()
        {
            var popup = Template.FindName("PART_DropDownPopup", this) as Popup;
            var clearButton = Template.FindName("PART_ClearButton", this) as Button;

            if (clearButton != null)
            {
                clearButton.Click += (sender, args) =>
                {
                    SelectedItem = null;
                    
                    if (popup != null)
                    {
                        popup.IsOpen = false;
                    }
                };
            }

            base.OnApplyTemplate();
        }

        /// <summary>
        /// Checks if the item is of type <see cref="SortItemControl"/>.
        /// </summary>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is SortItemControl;
        }

        /// <summary>
        /// Returns a new item of type <see cref="SortItemControl"/>.
        /// </summary>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new SortItemControl();
        }

        /// <summary>
        /// The following assumes a binding exists to a sort definition
        /// and prepares the binding accordingly.
        /// </summary>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var control = (SortItemControl) element;

            control.SetBinding(ContentControl.ContentProperty, new Binding("DisplayName"));
            control.SetBinding(SortItemControl.ListSortDirectionProperty, new Binding("ListSortDirection"){ Mode = BindingMode.TwoWay});

            base.PrepareContainerForItemOverride(element, item);
        }

        private static void OnIsOpenedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SortControl)d;
            control.UpdateOpenedState((bool) e.NewValue);
        }

        private void UpdateOpenedState(bool isOpened)
        {
            if (!IsOpened)
            {
                Focus();
            }
            VisualStateManager.GoToState(this, isOpened ? "Opened" : "Closed", false);
        }
    }
}
