﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media.Animation;
using Microsoft.Practices.ServiceLocation;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A panel that displays content at the side.
    /// </summary>
    public class SlidePanel : ContentControl
    {
        private bool _isInitialised;

        /// <summary>
        /// A unique id for the control allowing it to save its position.
        /// </summary>
        public static readonly DependencyProperty IdProperty =
            DependencyProperty.Register("Id", typeof(string), typeof(SlidePanel), new PropertyMetadata(""));
        /// <summary>
        /// Exposes the <see cref="IdProperty"/> DependencyProperty. 
        /// </summary>
        public string Id
        {
            get { return (string)GetValue(IdProperty); }
            set { SetValue(IdProperty, value); }
        }

        /// <summary>
        /// Raised whenever the <see cref="IsOpenProperty"/> changes.
        /// </summary>
        public static readonly RoutedEvent OpenedEvent =
            EventManager.RegisterRoutedEvent("Opened", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(SlidePanel));
        /// <summary>
        /// Exposes the <see cref="OpenedEvent"/> RoutedEvent.
        /// </summary>
        public event RoutedEventHandler Opened
        {
            add { AddHandler(OpenedEvent, value); }
            remove { RemoveHandler(OpenedEvent, value); }
        }

        /// <summary>
        /// Raised whenever the <see cref="IsOpenProperty"/> changes.
        /// </summary>
        public static readonly RoutedEvent ClosedEvent =
            EventManager.RegisterRoutedEvent("Closed", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(SlidePanel));
        /// <summary>
        /// Exposes the <see cref="ClosedEvent"/> RoutedEvent.
        /// </summary>
        public event RoutedEventHandler Closed
        {
            add { AddHandler(ClosedEvent, value); }
            remove { RemoveHandler(ClosedEvent, value); }
        }

        /// <summary>
        /// If the panel is open.
        /// </summary>
        public static readonly DependencyProperty IsOpenProperty = 
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(SlidePanel), new PropertyMetadata(false, OnIsOpenChanged));
        /// <summary>
        /// Exposes the <see cref="IsOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        /// <summary>
        /// The width of the panel.
        /// </summary>
        public static readonly DependencyProperty SlideWidthProperty =
            DependencyProperty.Register("SlideWidth", typeof(double), typeof(SlidePanel), new PropertyMetadata(320d, OnSlideWidthChanged));
        /// <summary>
        /// Exposes the <see cref="SlideWidthProperty"/> DependencyProperty.
        /// </summary>
        public double SlideWidth
        {
            get { return (double)GetValue(SlideWidthProperty); }
            set { SetValue(SlideWidthProperty, value); }
        }

        /// <summary>
        /// The maximum slide width of the panel.
        /// </summary>
        public static readonly DependencyProperty MaxSlideWidthProperty = 
            DependencyProperty.Register("MaxSlideWidth", typeof(double), typeof(SlidePanel), new PropertyMetadata(600d));
        /// <summary>
        /// Exposes the <see cref="MaxSlideWidthProperty"/> DependencyProperty.
        /// </summary>
        public double MaxSlideWidth
        {
            get { return (double)GetValue(MaxSlideWidthProperty); }
            set { SetValue(MaxSlideWidthProperty, value); }
        }

        /// <summary>
        /// The minumum width of the panel.
        /// </summary>
        public static readonly DependencyProperty MinDragWidthProperty =
            DependencyProperty.Register("MinDragWidth", typeof(double), typeof(SlidePanel), new PropertyMetadata(200d));
        /// <summary>
        /// Exposes the <see cref="MinDragWidthProperty"/> DependencyProperty.
        /// </summary>
        public double MinDragWidth
        {
            get { return (double)GetValue(MinDragWidthProperty); }
            set { SetValue(MinDragWidthProperty, value); }
        }

        /// <summary>
        /// The minumum slide width.
        /// </summary>
        public static readonly DependencyProperty MinSlideWidthProperty = 
            DependencyProperty.Register("MinSlideWidth", typeof(double), typeof(SlidePanel), new PropertyMetadata(0d));
        /// <summary>
        /// Exposes the <see cref="MinSlideWidthProperty"/> DependencyProperty.
        /// </summary>
        public double MinSlideWidth
        {
            get { return (double)GetValue(MinSlideWidthProperty); }
            set { SetValue(MinSlideWidthProperty, value); }
        }

        /// <summary>
        /// If the width can be resized.
        /// </summary>
        public static readonly DependencyProperty AllowResizeProperty = 
            DependencyProperty.Register("AllowResize", typeof(bool), typeof(SlidePanel), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="AllowResizeProperty"/> DependencyProperty.
        /// </summary>
        public bool AllowResize
        {
            get { return (bool)GetValue(AllowResizeProperty); }
            set { SetValue(AllowResizeProperty, value); }
        }

        /// <summary>
        /// If the drag thumb should show a drop shadow.
        /// </summary>
        public static readonly DependencyProperty ShowDropShadowProperty =
            DependencyProperty.Register("ShowDropShadow", typeof(bool), typeof(SlidePanel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="ShowDropShadowProperty"/> DependencyProperty.
        /// </summary>
        public bool ShowDropShadow
        {
            get { return (bool)GetValue(ShowDropShadowProperty); }
            set { SetValue(ShowDropShadowProperty, value); }
        }

        /// <summary>
        /// Gets or sets the direction in which the panel slides.
        /// </summary>
        public static readonly DependencyProperty SlideDirectionProperty =
            DependencyProperty.Register("SlideDirection", typeof(SlideDirection), typeof(SlidePanel), new PropertyMetadata(SlideDirection.LeftToRight));
        /// <summary>
        /// Exposes the <see cref="SlideDirectionProperty"/> DependencyProperty.
        /// </summary>
        public SlideDirection SlideDirection
        {
            get { return (SlideDirection)GetValue(SlideDirectionProperty); }
            set { SetValue(SlideDirectionProperty, value); }
        }

        /// <summary>
        /// if true and the <see cref="Id"/> property is not null the state of the <see cref="IsOpen"/> property will be persisted.
        /// </summary>
        public static readonly DependencyProperty PersistIsOpenProperty =
            DependencyProperty.Register("PersistIsOpen", typeof(bool), typeof(SlidePanel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="PersistIsOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool PersistIsOpen
        {
            get { return (bool)GetValue(PersistIsOpenProperty); }
            set { SetValue(PersistIsOpenProperty, value); }
        }

        /// <summary>
        /// if true and the <see cref="Id"/> property is not null the state of the <see cref="SlideWidth"/> property will be persisted.
        /// </summary>
        public static readonly DependencyProperty PersistSlideWidthProperty =
            DependencyProperty.Register("PersistSlideWidth", typeof(bool), typeof(SlidePanel), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="PersistSlideWidthProperty"/> DependencyProperty.
        /// </summary>
        public bool PersistSlideWidth
        {
            get { return (bool)GetValue(PersistSlideWidthProperty); }
            set { SetValue(PersistSlideWidthProperty, value); }
        }

        private IConfiguration Configuration
        {
            get { return ServiceLocator.Current.GetInstance<IConfiguration>(); }
        }

        static SlidePanel()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SlidePanel), new FrameworkPropertyMetadata(typeof(SlidePanel)));
        }

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            var sideFilterThumb = Template.FindName("PART_DragThumb", this) as Thumb;
            if (sideFilterThumb != null)
            {
                
                sideFilterThumb.DragDelta += (sender, e) =>
                {
                    var change = SlideDirection == SlideDirection.LeftToRight ? e.HorizontalChange : -e.HorizontalChange;
                    SlideWidth = CoerceSideFilterWidth(SlideWidth + change);
                };
                sideFilterThumb.DragCompleted += (sender, args) =>
                {
                    SlideWidthChanged();
                };
            }
            Loaded += OnLoaded;
            base.OnApplyTemplate();
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            Loaded -= OnLoaded;
            Initialise();
        }

        private void Initialise()
        {
            LoadPanelDetails();
            UpdateWidth();
            _isInitialised = true;
        }

        private void UpdateWidth()
        {
            Width = IsOpen ? SlideWidth : MinSlideWidth;
        }

        private double CoerceSideFilterWidth(double newWidth)
        {
            return Math.Max(Math.Min(newWidth, MaxSlideWidth), MinDragWidth);
        }

        private static void OnSlideWidthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SlidePanel)d;
            control.OnSlideWidthChanged();
        }

        private void OnSlideWidthChanged()
        {
            if (_isInitialised)
            {
                UpdateWidth();
            }
        }

        private static void OnIsOpenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SlidePanel) d;
            control.OnIsOpenChanged();
        }

        private void OnIsOpenChanged()
        {
            if (_isInitialised && IsLoaded)
            {
                if (IsOpen)
                {
                    IsOpening();
                }
                else
                {
                    IsClosing();
                }
                var duration = new Duration(new TimeSpan(0, 0, 0, 0, 300));
                var anim = new DoubleAnimation(IsOpen ? SlideWidth : MinSlideWidth, duration)
                {
                    EasingFunction = new QuarticEase { EasingMode = EasingMode.EaseOut }
                };

                Storyboard.SetTargetProperty(anim, new PropertyPath(WidthProperty));
                Storyboard.SetTarget(anim, this);

                var s = new Storyboard();
                s.Children.Add(anim);
                s.FillBehavior = FillBehavior.Stop;
                s.Completed += (sender, args) =>
                {
                    UpdateWidth();
                    if (IsOpen)
                    {
                        IsOpened();
                    }
                    else
                    {
                        IsClosed();
                    }
                };
                s.Begin();
            }
        }

        /// <summary>
        /// Called when the slide width has changed.
        /// </summary>
        protected virtual void SlideWidthChanged()
        {
            SavePanelDetails();
        }

        /// <summary>
        /// Called before the animation opens the panel.
        /// </summary>
        protected virtual void IsOpening()
        {
            
        }

        /// <summary>
        /// Called after the animation opens the panel.
        /// </summary>
        protected virtual void IsOpened()
        {
            RaiseOpen();
            SavePanelDetails();
        }

        /// <summary>
        /// Called before the animation closes the panel.
        /// </summary>
        protected virtual void IsClosing()
        {

        }

        /// <summary>
        /// Called after the animation closes the panel.
        /// </summary>
        protected virtual void IsClosed()
        {
            RaiseClosed();
            SavePanelDetails();
        }

        private void RaiseOpen()
        {
            var newEventArgs = new RoutedEventArgs(OpenedEvent);
            RaiseEvent(newEventArgs);
        }

        private void RaiseClosed()
        {
            var newEventArgs = new RoutedEventArgs(ClosedEvent);
            RaiseEvent(newEventArgs);
        }

        private void LoadPanelDetails()
        {
            if (!string.IsNullOrWhiteSpace(Id) && !DesignerProperties.GetIsInDesignMode(this))
            {
                var config = Configuration;
                if (PersistSlideWidth)
                {
                    SlideWidth = config.GetValue(Id + "_Width", SlideWidth);
                }
                if (PersistIsOpen)
                {
                    IsOpen = config.GetValue(Id + "_IsOpen", IsOpen);
                }
            }
        }

        private void SavePanelDetails()
        {
            if (!string.IsNullOrWhiteSpace(Id) && IsLoaded && IsInitialized && !DesignerProperties.GetIsInDesignMode(this))
            {
                var config = Configuration;
                if (PersistSlideWidth)
                {
                    config.Update(Id + "_Width", SlideWidth.ToString(CultureInfo.InvariantCulture), false);
                }
                if (PersistIsOpen)
                {
                    config.Update(Id + "_IsOpen", IsOpen.ToString(CultureInfo.InvariantCulture), false);
                }
                if (PersistSlideWidth || PersistIsOpen)
                {
                    config.Save();
                }
            }
        }

        
       
    }

    /// <summary>
    /// The direction of the panels slide.
    /// </summary>
    public enum SlideDirection
    {
        /// <summary>
        /// Slides in from left to right.
        /// </summary>
        LeftToRight,

        /// <summary>
        /// Slides in from right to left.
        /// </summary>
        RightToLeft
    }
}
