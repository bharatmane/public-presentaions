﻿using Microsoft.Practices.ServiceLocation;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using VShips.Framework.Common;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;


namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// This class is usesd to display crew name  and navigate to biodata when it is double clilcked.
    /// </summary>
    public class CrewBioDataNavigationControl : Button
    {

        #region Properties

        /// <summary>
        /// The navigate to bio data
        /// </summary>
        private bool _navigateToBioData;

        /// <summary>
        /// Gets or sets a value indicating whether [navigate to bio data].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [navigate to bio data]; otherwise, <c>false</c>.
        /// </value>
        public bool NavigateToBioData
        {
            get { return _navigateToBioData; }
            set { _navigateToBioData = value; }
        }
        /// <summary>
        /// The navigate to selected tab
        /// </summary>
        private string _navigateToSelectedTab;
        /// <summary>
        /// Gets or sets the navigate to selected tab.
        /// </summary>
        /// <value>
        /// The navigate to selected tab.
        /// </value>
        public string NavigateToSelectedTab
        {
            get { return _navigateToSelectedTab; }
            set { _navigateToSelectedTab = value; }
        }



        /// <summary>
        /// The vm service
        /// </summary>
        private IViewModelService _vmService;

        /// <summary>
        /// Retrieves the main view model service which gives access to common services.
        /// See the <see cref="IViewModelService" /> for more information.
        /// </summary>
        /// <value>
        /// The vm service.
        /// </value>
        protected IViewModelService VMService
        {
            get { return _vmService ?? (_vmService = ServiceLocator.Current.GetInstance<IViewModelService>()); }
        }

        #endregion

        #region Dependency Properties

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId
        {
            get { return (string)GetValue(CrewIdProperty); }
            set { SetValue(CrewIdProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CrewId.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CrewIdProperty =
            DependencyProperty.Register("CrewId", typeof(string), typeof(CrewBioDataNavigationControl),
                new PropertyMetadata(string.Empty));

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        public string FirstName
        {
            get { return (string)GetValue(FirstNameProperty); }
            set { SetValue(FirstNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FirstName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FirstNameProperty =
            DependencyProperty.Register("FirstName", typeof(string), typeof(CrewBioDataNavigationControl),
                new PropertyMetadata(string.Empty));

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        public string LastName
        {
            get { return (string)GetValue(LastNameProperty); }
            set { SetValue(LastNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LastName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LastNameProperty =
            DependencyProperty.Register("LastName", typeof(string), typeof(CrewBioDataNavigationControl),
                new PropertyMetadata(string.Empty));

        /// <summary>
        /// Gets or sets the name of the middle.
        /// </summary>
        /// <value>
        /// The name of the middle.
        /// </value>
        public string MiddleName
        {
            get { return (string)GetValue(MiddleNameProperty); }
            set { SetValue(MiddleNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MiddleName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MiddleNameProperty =
            DependencyProperty.Register("MiddleName", typeof(string), typeof(CrewBioDataNavigationControl),
                new UIPropertyMetadata(string.Empty));

        /// <summary>
        /// Gets or sets a value indicating whether this instance is crew locked.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is crew locked; otherwise, <c>false</c>.
        /// </value>
        public bool IsCrewLocked
        {
            get { return (bool)GetValue(IsCrewLockedProperty); }
            set { SetValue(IsCrewLockedProperty, value); }
        }

        /// <summary>
        /// The is crew locked property
        /// </summary>
        public static readonly DependencyProperty IsCrewLockedProperty =
            DependencyProperty.Register("IsCrewLocked", typeof(bool), typeof(CrewBioDataNavigationControl),
                new PropertyMetadata(false));

        /*
        Note : NavigationContext Dependency Property is created for GanttView since class used is not inherited from BaseViewModel.cs
        */
        /// <summary>
        /// Gets or sets the navigation context.
        /// </summary>
        /// <value>
        /// The navigation context.
        /// </value>
        public INavigationContext NavigationContext
        {
            get { return (INavigationContext)GetValue(NavigationContextProperty); }
            set { SetValue(NavigationContextProperty, value); }
        }

        /// <summary>
        /// The is navigation context property
        /// </summary>
        public static readonly DependencyProperty NavigationContextProperty =
            DependencyProperty.Register("NavigationContext", typeof(INavigationContext), typeof(CrewBioDataNavigationControl),
                new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the navigation completed command.
        /// </summary>
        /// <value>
        /// The navigation completed command.
        /// </value>
        public ICommand NavigationCompletedCommand
        {
            get { return (ICommand)GetValue(NavigationCompletedCommandProperty); }
            set { SetValue(NavigationCompletedCommandProperty, value); }
        }

        /// <summary>
        /// The navigation completed command property
        /// </summary>
        public static readonly DependencyProperty NavigationCompletedCommandProperty =
            DependencyProperty.Register("NavigationCompletedCommand", typeof(ICommand), typeof(CrewBioDataNavigationControl), new PropertyMetadata(null));

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="CrewBioDataNavigationControl"/> class.
        /// </summary>
        public CrewBioDataNavigationControl()
        {
            this.Click += CrewBioDataNavigationControl_Click;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Handles the Click event of the CrewBioDataNavigationControl control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void CrewBioDataNavigationControl_Click(object sender, RoutedEventArgs eventArgs)
        {
            if (NavigateToBioData && (!string.IsNullOrWhiteSpace(CrewId)))
            {
                Dictionary<string, object> parameter = new Dictionary<string, object>
                {
                    {NavigationParameterConstant.CrewId,CrewId },
                    {NavigationParameterConstant.CrewForeName,FirstName },
                    {NavigationParameterConstant.CrewLastName,LastName },
                    {NavigationParameterConstant.NavigateSelectedTab,NavigateToSelectedTab }
                };

                if (DataContext != null && DataContext is BaseViewModel && ((BaseViewModel)DataContext).NavigationContext != null)
                {
                    VMService.ModuleNavigationService.Crew.CrewNavigateCrewSummary(parameter, CrewId, ((BaseViewModel)DataContext).NavigationContext, IsCrewLocked);
                }
                else if (NavigationContext != null)
                {
                    VMService.ModuleNavigationService.Crew.CrewNavigateCrewSummary(parameter, CrewId, NavigationContext, IsCrewLocked);
                }
                else
                {
                    VMService.ModuleNavigationService.Crew.CrewNavigateCrewSummary(parameter, CrewId);
                }
                if (NavigationCompletedCommand != null)
                {
                    NavigationCompletedCommand.Execute(null);
                }
                eventArgs.Handled = true;
            }
        }

        #endregion
    }
}
