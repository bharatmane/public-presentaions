﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// 
    /// </summary>
    [TemplatePart(Name = HighlighttextblockName, Type = typeof(TextBlock))]
    public class HighlightingTextBlock : Control
    {
        /// <summary>
        /// The highlighttextblock name
        /// </summary>
        private const string HighlighttextblockName = "PartHighlightTextblock";

        /// <summary>
        /// The match count property key
        /// </summary>
        private static readonly DependencyPropertyKey MatchCountPropertyKey
            = DependencyProperty.RegisterReadOnly("MatchCount", typeof(int), typeof(HighlightingTextBlock),
                new PropertyMetadata(0));

        /// <summary>
        /// The match count property
        /// </summary>
        public static readonly DependencyProperty MatchCountProperty
            = MatchCountPropertyKey.DependencyProperty;

        /// <summary>
        /// The highlight text property
        /// </summary>
        public static readonly DependencyProperty HighlightTextProperty =
            DependencyProperty.Register("HighlightText", typeof(string), typeof(HighlightingTextBlock),
                new PropertyMetadata(string.Empty, OnHighlightTextPropertyChanged));

        /// <summary>
        /// The text property
        /// </summary>
        public static readonly DependencyProperty TextProperty = TextBlock.TextProperty.AddOwner(
            typeof(HighlightingTextBlock),
            new PropertyMetadata(string.Empty, OnTextPropertyChanged));

        /// <summary>
        /// The text wrapping property
        /// </summary>
        public static readonly DependencyProperty TextWrappingProperty = TextBlock.TextWrappingProperty.AddOwner(
            typeof(HighlightingTextBlock),
            new PropertyMetadata(TextWrapping.NoWrap));

        /// <summary>
        /// The text trimming property
        /// </summary>
        public static readonly DependencyProperty TextTrimmingProperty = TextBlock.TextTrimmingProperty.AddOwner(
            typeof(HighlightingTextBlock),
            new PropertyMetadata(TextTrimming.None));

        /// <summary>
        /// The highlight foreground property
        /// </summary>
        public static readonly DependencyProperty HighlightForegroundProperty =
            DependencyProperty.Register("HighlightForeground", typeof(Brush),
                typeof(HighlightingTextBlock),
                new PropertyMetadata(Brushes.White));

        /// <summary>
        /// The highlight background property
        /// </summary>
        public static readonly DependencyProperty HighlightBackgroundProperty =
            DependencyProperty.Register("HighlightBackground", typeof(Brush),
                typeof(HighlightingTextBlock),
                new PropertyMetadata(Brushes.Blue));


        /// <summary>
        /// The highlight multiple text property
        /// </summary>
        public static readonly DependencyProperty HighlightMultipleTextProperty =
            DependencyProperty.Register("HighlightMultipleText", typeof(IEnumerable<string>), typeof(HighlightingTextBlock),
                new PropertyMetadata(null, OnHighlightMultipleTextPropertyChanged));


        /// <summary>
        /// The _highlight text block
        /// </summary>
        private TextBlock _highlightTextBlock;

        /// <summary>
        /// Initializes the <see cref="HighlightingTextBlock"/> class.
        /// </summary>
        static HighlightingTextBlock()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(HighlightingTextBlock),
                new FrameworkPropertyMetadata(typeof(HighlightingTextBlock)));
        }

        /// <summary>
        /// Gets or sets the match count.
        /// </summary>
        /// <value>
        /// The match count.
        /// </value>
        public int MatchCount
        {
            get { return (int)GetValue(MatchCountProperty); }
            protected set { SetValue(MatchCountPropertyKey, value); }
        }

        /// <summary>
        /// Gets or sets the highlight background.
        /// </summary>
        /// <value>
        /// The highlight background.
        /// </value>
        public Brush HighlightBackground
        {
            get { return (Brush)GetValue(HighlightBackgroundProperty); }
            set { SetValue(HighlightBackgroundProperty, value); }
        }

        /// <summary>
        /// Gets or sets the highlight foreground.
        /// </summary>
        /// <value>
        /// The highlight foreground.
        /// </value>
        public Brush HighlightForeground
        {
            get { return (Brush)GetValue(HighlightForegroundProperty); }
            set { SetValue(HighlightForegroundProperty, value); }
        }

        /// <summary>
        /// Gets or sets the highlight text.
        /// </summary>
        /// <value>
        /// The highlight text.
        /// </value>
        public string HighlightText
        {
            get { return (string)GetValue(HighlightTextProperty); }
            set { SetValue(HighlightTextProperty, value); }
        }

        /// <summary>
        /// Gets or sets the highlight multiple text.
        /// </summary>
        /// <value>
        /// The highlight multiple text.
        /// </value>
        public IEnumerable<string> HighlightMultipleText
        {
            get { return (IEnumerable<string>)GetValue(HighlightMultipleTextProperty); }
            set { SetValue(HighlightMultipleTextProperty, value); }
        }

        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>
        /// The text.
        /// </value>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// Gets or sets the text wrapping.
        /// </summary>
        /// <value>
        /// The text wrapping.
        /// </value>
        public TextWrapping TextWrapping
        {
            get { return (TextWrapping)GetValue(TextWrappingProperty); }
            set { SetValue(TextWrappingProperty, value); }
        }

        /// <summary>
        /// Gets or sets the text trimming.
        /// </summary>
        /// <value>
        /// The text trimming.
        /// </value>
        public TextTrimming TextTrimming
        {
            get { return (TextTrimming)GetValue(TextTrimmingProperty); }
            set { SetValue(TextTrimmingProperty, value); }
        }

        /// <summary>
        /// Called when [highlight text property changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnHighlightTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var textblock = (HighlightingTextBlock)d;
            textblock.ProcessTextChanged(textblock.Text, e.NewValue as string);
        }

        /// <summary>
        /// Called when [highlight multiple text property changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnHighlightMultipleTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var textblock = (HighlightingTextBlock)d;
            var searchTexts = e != null && e.NewValue != null ? e.NewValue as IEnumerable<string> : null;
            if (textblock.HighlightMultipleText != null && searchTexts != null)
            {
                textblock.ProcessTextChangedMultiple(textblock.Text, textblock.HighlightMultipleText);
            }
        }

        /// <summary>
        /// Called when [text property changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var textblock = (HighlightingTextBlock)d;
            textblock.ProcessTextChanged(e.NewValue as string, textblock.HighlightText);
        }

        /// <summary>
        /// Processes the text changed.
        /// </summary>
        /// <param name="mainText">The main text.</param>
        /// <param name="highlightText">The highlight text.</param>
        private void ProcessTextChanged(string mainText, string highlightText)
        {
            if (_highlightTextBlock == null)
                return;
            _highlightTextBlock.Inlines.Clear();
            SetValue(MatchCountPropertyKey, 0);
            if (_highlightTextBlock == null || string.IsNullOrWhiteSpace(mainText))
            {
                return;
            }
            if (string.IsNullOrWhiteSpace(highlightText))
            {
                var completeRun = new Run(mainText);
                _highlightTextBlock.Inlines.Add(completeRun);
                return;
            }
            var find = 0;
            var searchTextLength = highlightText.Length;
            while (true)
            {
                var oldFind = find;
                find = mainText.IndexOf(highlightText, find, StringComparison.InvariantCultureIgnoreCase);
                if (find == -1)
                {
                    _highlightTextBlock.Inlines.Add(
                        oldFind > 0
                            ? GetRunForText(mainText.Substring(oldFind, mainText.Length - oldFind), false)
                            : GetRunForText(mainText, false));
                    break;
                }

                if (oldFind == find)
                {
                    _highlightTextBlock.Inlines.Add(GetRunForText(mainText.Substring(oldFind, searchTextLength), true));
                    SetValue(MatchCountPropertyKey, MatchCount + 1);
                    find = find + searchTextLength;
                    continue;
                }

                _highlightTextBlock.Inlines.Add(GetRunForText(mainText.Substring(oldFind, find - oldFind), false));
            }
        }

        /// <summary>
        /// Processes the text changed multiple.
        /// </summary>
        /// <param name="mainText">The main text.</param>
        /// <param name="highlightTexts">The highlight texts.</param>
        private void ProcessTextChangedMultiple(string mainText, IEnumerable<string> highlightTexts)
        {
            if (_highlightTextBlock == null)
                return;

            _highlightTextBlock.Inlines.Clear();

            SetValue(MatchCountPropertyKey, 0);
            if (_highlightTextBlock == null || string.IsNullOrWhiteSpace(mainText))
            {
                return;
            }
            if (highlightTexts == null)
            {
                var completeRun = new Run(mainText);
                _highlightTextBlock.Inlines.Add(completeRun);
                return;
            }
            var find = 0;

            while (true)
            {
                int finalFind = 0, tempFind = 0;
                string highlightText = "";
                var oldFind = find;

                foreach (string searchString in highlightTexts)
                {
                    if (string.IsNullOrEmpty(searchString))
                    {
                        finalFind = tempFind != -1 || tempFind != 0 ? tempFind : -1;
                        continue;
                    }
                    tempFind = mainText.IndexOf(searchString, find, StringComparison.InvariantCultureIgnoreCase);

                    if ((tempFind < finalFind && tempFind != -1) || finalFind == -1)
                    {
                        finalFind = tempFind;
                        highlightText = searchString;
                    }

                    if (string.IsNullOrEmpty(highlightText))
                    {
                        finalFind = tempFind;
                        highlightText = searchString;
                    }
                }

                int searchTextLength = highlightText.Length;
                find = finalFind;

                if (find == -1)
                {
                    _highlightTextBlock.Inlines.Add(
                        oldFind > 0
                            ? GetRunForText(mainText.Substring(oldFind, mainText.Length - oldFind), false)
                            : GetRunForText(mainText, false));
                    break;
                }

                if (oldFind == find)
                {
                    _highlightTextBlock.Inlines.Add(GetRunForText(mainText.Substring(oldFind, searchTextLength), true));
                    SetValue(MatchCountPropertyKey, MatchCount + 1);
                    find = find + searchTextLength;
                    continue;
                }

                _highlightTextBlock.Inlines.Add(GetRunForText(mainText.Substring(oldFind, find - oldFind), false));
            }
        }

        /// <summary>
        /// Gets the run for text.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="isHighlighted">if set to <c>true</c> [is highlighted].</param>
        /// <returns></returns>
        private Run GetRunForText(string text, bool isHighlighted)
        {
            var textRun = new Run(text)
            {
                Foreground = isHighlighted ? HighlightForeground : Foreground,
                Background = isHighlighted ? HighlightBackground : Background
            };
            return textRun;
        }

        /// <summary>
        /// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
        /// </summary>
        public override void OnApplyTemplate()
        {
            _highlightTextBlock = GetTemplateChild(HighlighttextblockName) as TextBlock;
            if (_highlightTextBlock == null)
                return;
            ProcessTextChanged(Text, HighlightText);
        }
    }
}