﻿using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A specialised listboxitem control used in the <see cref="VListBox"/>.
    /// </summary>
    public class VListBoxItem : ListBoxItem
    {
        /// <summary>
        /// True if the listbox uses the datascrolling mechanism.
        /// </summary>
        public static readonly DependencyProperty UsesDataScrollingProperty =
            DependencyProperty.Register("UsesDataScrolling", typeof(bool), typeof(VListBoxItem), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="UsesDataScrollingProperty"/> DependencyProperty.
        /// </summary>
        public bool UsesDataScrolling
        {
            get { return (bool)GetValue(UsesDataScrollingProperty); }
            set { SetValue(UsesDataScrollingProperty, value); }
        }

        /// <summary>
        /// If the item is a dummy/skeleton item used to display data before it is loaded.
        /// </summary>
        public static readonly DependencyProperty IsDummyItemProperty =
            DependencyProperty.Register("IsDummyItem", typeof(bool), typeof(VListBoxItem), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsDummyItemProperty"/> DependencyProperty.
        /// </summary>
        public bool IsDummyItem
        {
            get { return (bool)GetValue(IsDummyItemProperty); }
            set { SetValue(IsDummyItemProperty, value); }
        }

        /// <summary>
        /// Sets the template to use if the item is a dummy item. This should be a skeleton template in order to display data before it is loaded.
        /// </summary>
        public static readonly DependencyProperty DummyItemTemplateProperty =
            DependencyProperty.Register("DummyItemTemplate", typeof(DataTemplate), typeof(VListBoxItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="DummyItemTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate DummyItemTemplate
        {
            get { return (DataTemplate)GetValue(DummyItemTemplateProperty); }
            set { SetValue(DummyItemTemplateProperty, value); }
        }

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            Loaded += (sender, args) =>
            {
                if (UsesDataScrolling)
                {
                    var vm = DataContext as IScrollItem;
                    if (vm != null)
                    {
                        vm.OnViewLoaded();
                    }
                }
            };
            base.OnApplyTemplate();
        }

        static VListBoxItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(VListBoxItem), new FrameworkPropertyMetadata(typeof(VListBoxItem)));
        }
        
        
    }
}
