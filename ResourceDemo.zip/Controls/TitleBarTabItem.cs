﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A tab item for the <see cref="TitlebarTabControl"/>.
    /// </summary>
    public class TitleBarTabItem : RadTabItem
    {
        /// <summary>
        /// The icon for the tab item.
        /// </summary>
        public static readonly DependencyProperty IconProperty =
            DependencyProperty.Register("Icon", typeof(object), typeof(TitleBarTabItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="IconProperty"/> DependencyProperty.
        /// </summary>
        public object Icon
        {
            get { return GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }

        /// <summary>
        /// The template for the icon.
        /// </summary>
        public static readonly DependencyProperty IconTemplateProperty =
            DependencyProperty.Register("IconTemplate", typeof(DataTemplate), typeof(TitleBarTabItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="IconTemplateProperty"/> DependencyProperty.
        /// </summary>
        public DataTemplate IconTemplate
        {
            get { return (DataTemplate)GetValue(IconTemplateProperty); }
            set { SetValue(IconTemplateProperty, value); }
        }

        /// <summary>
        /// The template slector for the icon.
        /// </summary>
        public static readonly DependencyProperty IconTemplateSelectorProperty =
            DependencyProperty.Register("IconTemplateSelector", typeof(DataTemplateSelector), typeof(TitleBarTabItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="IconTemplateSelectorProperty"/> DependencyProperty. 
        /// </summary>
        public DataTemplateSelector IconTemplateSelector
        {
            get { return (DataTemplateSelector)GetValue(IconTemplateSelectorProperty); }
            set { SetValue(IconTemplateSelectorProperty, value); }
        }

        /// <summary>
        /// If the tab can close. The home page for example may not allow this.
        /// </summary>
        public static readonly DependencyProperty CanCloseProperty =
            DependencyProperty.Register("CanClose", typeof(bool), typeof(TitleBarTabItem), new PropertyMetadata(true));
        /// <summary>
        /// Exposes the <see cref="CanCloseProperty"/> DependencyProperty.
        /// </summary>
        public bool CanClose
        {
            get { return (bool)GetValue(CanCloseProperty); }
            set { SetValue(CanCloseProperty, value); }
        }

        /// <summary>
        /// The command to execute when the tab closes.
        /// </summary>
        public static readonly DependencyProperty CloseCommandProperty =
            DependencyProperty.Register("CloseCommand", typeof(ICommand), typeof(TitleBarTabItem), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="CloseCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand CloseCommand
        {
            get { return (ICommand)GetValue(CloseCommandProperty); }
            set { SetValue(CloseCommandProperty, value); }
        }

        /// <summary>
        /// If the current tab is busy.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(TitleBarTabItem), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsBusyProperty"/> DependencyProperty. 
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        /// <summary>
        /// If the current tab is dirty.
        /// </summary>
        public static readonly DependencyProperty IsDirtyProperty =
            DependencyProperty.Register("IsDirty", typeof(bool), typeof(TitleBarTabItem), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsDirtyProperty"/> DependencyProperty. 
        /// </summary>
        public bool IsDirty
        {
            get { return (bool)GetValue(IsDirtyProperty); }
            set { SetValue(IsDirtyProperty, value); }
        }

        static TitleBarTabItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TitleBarTabItem), new FrameworkPropertyMetadata(typeof(TitleBarTabItem)));
        }
    }
}
