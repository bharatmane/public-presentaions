﻿using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// Template side control
    /// </summary>
    /// <seealso cref="System.Windows.Controls.HeaderedContentControl" />
    public class TemplateSideListControl : HeaderedContentControl
    {
        #region Dependency Properties
        
        /// <summary>
        /// The search text property
        /// </summary>
        public static readonly DependencyProperty SearchTextProperty =
            DependencyProperty.Register("SearchText", typeof(string), typeof(TemplateSideListControl), new PropertyMetadata(null));

        /// <summary>
        /// The header visibility property
        /// </summary>
        public static readonly DependencyProperty HeaderVisibilityProperty =
            DependencyProperty.Register("HeaderVisibility", typeof(Visibility), typeof(TemplateSideListControl), new PropertyMetadata(Visibility.Visible));

        /// <summary>
        /// The search visibility property
        /// </summary>
        public static readonly DependencyProperty SearchVisibilityProperty =
            DependencyProperty.Register("SearchVisibility", typeof(Visibility), typeof(TemplateSideListControl), new PropertyMetadata(Visibility.Visible));

        /// <summary>
        /// The items source property
        /// </summary>
        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(TemplateSideListControl), new PropertyMetadata(null));

        /// <summary>
        /// The selected item property
        /// </summary>
        public static readonly DependencyProperty SelectedItemProperty =
            DependencyProperty.Register("SelectedItem", typeof(object), typeof(TemplateSideListControl), new PropertyMetadata(null));

        /// <summary>
        /// The item template property
        /// </summary>
        public static readonly DependencyProperty ItemTemplateProperty =
            DependencyProperty.Register("ItemTemplate", typeof(DataTemplate), typeof(TemplateSideListControl), new PropertyMetadata(null));

        /// <summary>
        /// The command executed when search button is pressed.
        /// </summary>
        public static readonly DependencyProperty SearchCommandProperty =
            DependencyProperty.Register("SearchCommand", typeof(ICommand), typeof(TemplateSideListControl), new PropertyMetadata(null));
        
        /// <summary>
        /// The command executed when the clear button is pressed.
        /// </summary>
        public static readonly DependencyProperty ClearCommandProperty =
            DependencyProperty.Register("ClearCommand", typeof(ICommand), typeof(TemplateSideListControl), new PropertyMetadata(null));
        
        /// <summary>
        /// Set this to true if search is complete.
        /// </summary>
        public static readonly DependencyProperty IsSearchCompleteProperty =
            DependencyProperty.Register("IsSearchComplete", typeof(bool), typeof(TemplateSideListControl), new PropertyMetadata(false));
        
        #endregion

        #region Properties

        /// <summary>
        /// Exposes the <see cref="SearchCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="ClearCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand ClearCommand
        {
            get { return (ICommand)GetValue(ClearCommandProperty); }
            set { SetValue(ClearCommandProperty, value); }
        }

        /// <summary>
        /// Exposes the <see cref="IsSearchCompleteProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSearchComplete
        {
            get { return (bool)GetValue(IsSearchCompleteProperty); }
            set { SetValue(IsSearchCompleteProperty, value); }
        }

        /// <summary>
        /// Gets or sets the search visibility.
        /// </summary>
        /// <value>
        /// The search visibility.
        /// </value>
        public Visibility SearchVisibility
        {
            get { return (Visibility)GetValue(SearchVisibilityProperty); }
            set { SetValue(SearchVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets or sets the items source.
        /// </summary>
        /// <value>
        /// The items source.
        /// </value>
        public IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public object SelectedItem
        {
            get { return (object)GetValue(SelectedItemProperty); }
            set { SetValue(SelectedItemProperty, value); }
        }

        /// <summary>
        /// Gets or sets the item template.
        /// </summary>
        /// <value>
        /// The item template.
        /// </value>
        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the header visibility.
        /// </summary>
        /// <value>
        /// The header visibility.
        /// </value>
        public Visibility HeaderVisibility
        {
            get { return (Visibility)GetValue(HeaderVisibilityProperty); }
            set { SetValue(HeaderVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets or sets the search text.
        /// </summary>
        /// <value>
        /// The search text.
        /// </value>
        public string SearchText
        {
            get { return (string)GetValue(SearchTextProperty); }
            set { SetValue(SearchTextProperty, value); }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes the <see cref="TemplateSideListControl"/> class.
        /// </summary>
        static TemplateSideListControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TemplateSideListControl), new FrameworkPropertyMetadata(typeof(TemplateSideListControl)));
        }

        #endregion
    }
}
