﻿namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// A set of common controls used throughout the apps modules.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
