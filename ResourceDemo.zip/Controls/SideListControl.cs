﻿using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The control used to display the items in a side list.
    /// </summary>
    public class SideListControl : HeaderedContentControl
    {
        private bool _previousVesselIsOpen;

        /// <summary>
        /// The unique id of the side list used to persist its width.
        /// </summary>
        public static readonly DependencyProperty IdProperty =
            DependencyProperty.Register("Id", typeof(string), typeof(SideListControl), new PropertyMetadata(""));
        /// <summary>
        /// Exposes the <see cref="IdProperty"/> DependencyProperty. 
        /// </summary>
        public string Id
        {
            get { return (string)GetValue(IdProperty); }
            set { SetValue(IdProperty, value); }
        }

        /// <summary>
        /// If the side list is currently open.
        /// </summary>
        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(SideListControl), new PropertyMetadata(true, OnIsOpenChanged));
        /// <summary>
        /// Exposes the <see cref="IsOpenProperty"/> DependencyProperty.
        /// </summary>
        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        /// <summary>
        /// The desired width of the side list.
        /// </summary>
        public static readonly DependencyProperty SlideWidthProperty =
            DependencyProperty.Register("SlideWidth", typeof(double), typeof(SideListControl), new PropertyMetadata(300d));
        /// <summary>
        /// Exposes the <see cref="SlideWidthProperty"/> DependencyProperty.
        /// </summary>
        public double SlideWidth
        {
            get { return (double)GetValue(SlideWidthProperty); }
            set { SetValue(SlideWidthProperty, value); }
        }

        /// <summary>
        /// Gets or sets the visibility of the side filter. 
        /// </summary>
        public static readonly DependencyProperty FilterVisibilityProperty =
            DependencyProperty.Register("FilterVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="FilterVisibilityProperty"/> DependencyProperty.
        /// </summary>
        public Visibility FilterVisibility
        {
            get { return (Visibility)GetValue(FilterVisibilityProperty); }
            set { SetValue(FilterVisibilityProperty, value); }
        }

        /// <summary>
        /// If the side filter is open.
        /// </summary>
        public static readonly DependencyProperty IsFilterOpenedProperty =
            DependencyProperty.Register("IsFilterOpened", typeof(bool), typeof(SideListControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsFilterOpenedProperty"/> DependencyProperty.
        /// </summary>
        public bool IsFilterOpened
        {
            get { return (bool)GetValue(IsFilterOpenedProperty); }
            set { SetValue(IsFilterOpenedProperty, value); }
        }

        /// <summary>
        /// The width of the side filter panel when opened.
        /// </summary>
        public static readonly DependencyProperty FilterSlideWidthProperty =
            DependencyProperty.Register("FilterSlideWidth", typeof(double), typeof(SideListControl), new PropertyMetadata(240d));
        /// <summary>
        /// Exposes the <see cref="FilterSlideWidthProperty"/> DependencyProperty.
        /// </summary>
        public double FilterSlideWidth
        {
            get { return (double)GetValue(FilterSlideWidthProperty); }
            set { SetValue(FilterSlideWidthProperty, value); }
        }

        /// <summary>
        /// The content for the side filter.
        /// </summary>
        public static readonly DependencyProperty FilterContentProperty =
            DependencyProperty.Register("FilterContent", typeof(object), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="FilterContentProperty"/> DependencyProperty.
        /// </summary>
        public object FilterContent
        {
            get { return GetValue(FilterContentProperty); }
            set { SetValue(FilterContentProperty, value); }
        }

        /// <summary>
        /// The visibility of the search box.
        /// </summary>
        public static readonly DependencyProperty SearchVisibilityProperty =
            DependencyProperty.Register("SearchVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="SearchVisibilityProperty"/> DependencyProperty.
        /// </summary>
        public Visibility SearchVisibility
        {
            get { return (Visibility)GetValue(SearchVisibilityProperty); }
            set { SetValue(SearchVisibilityProperty, value); }
        }

        /// <summary>
        /// The text used for searching.
        /// </summary>
        public static readonly DependencyProperty SearchTextProperty =
            DependencyProperty.Register("SearchText", typeof(string), typeof(SideListControl), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        /// <summary>
        /// Exposes the <see cref="SearchTextProperty"/> DependencyProperty.
        /// </summary>
        public string SearchText
        {
            get { return (string)GetValue(SearchTextProperty); }
            set { SetValue(SearchTextProperty, value); }
        }

        /// <summary>
        /// The command executed when searching.
        /// </summary>
        public static readonly DependencyProperty SearchCommandProperty =
            DependencyProperty.Register("SearchCommand", typeof(ICommand), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SearchCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        /// <summary>
        /// The command executed when searching.
        /// </summary>
        public static readonly DependencyProperty ClearSearchCommandProperty =
            DependencyProperty.Register("ClearSearchCommand", typeof(ICommand), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="ClearSearchCommandProperty"/> DependencyProperty.
        /// </summary>
        public ICommand ClearSearchCommand
        {
            get { return (ICommand)GetValue(ClearSearchCommandProperty); }
            set { SetValue(ClearSearchCommandProperty, value); }
        }

        /// <summary>
        /// Set this to true if search is complete.
        /// </summary>
        public static readonly DependencyProperty IsSearchCompleteProperty =
            DependencyProperty.Register("IsSearchComplete", typeof(bool), typeof(SideListControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsSearchCompleteProperty"/> DependencyProperty.
        /// </summary>
        public bool IsSearchComplete
        {
            get { return (bool)GetValue(IsSearchCompleteProperty); }
            set { SetValue(IsSearchCompleteProperty, value); }
        }

        /// <summary>
        /// The visibility of the header.
        /// </summary>
        public static readonly DependencyProperty HeaderVisibilityProperty =
            DependencyProperty.Register("HeaderVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="HeaderVisibilityProperty"/> DependencyProperty.
        /// </summary>
        public Visibility HeaderVisibility
        {
            get { return (Visibility)GetValue(HeaderVisibilityProperty); }
            set { SetValue(HeaderVisibilityProperty, value); }
        }

        /// <summary>
        /// The filter items.
        /// </summary>
        public static readonly DependencyProperty FilterItemsProperty =
            DependencyProperty.Register("FilterItems", typeof(IEnumerable), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="FilterItemsProperty"/> DependencyProperty.
        /// </summary>
        public IEnumerable FilterItems
        {
            get { return (IEnumerable)GetValue(FilterItemsProperty); }
            set { SetValue(FilterItemsProperty, value); }
        }

        /// <summary>
        /// A collection used to sort the main collection.
        /// </summary>
        public static readonly DependencyProperty SortItemsProperty =
            DependencyProperty.Register("SortItems", typeof(IEnumerable), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SortItemsProperty"/> DependencyProperty.
        /// </summary>
        public IEnumerable SortItems
        {
            get { return (IEnumerable)GetValue(SortItemsProperty); }
            set { SetValue(SortItemsProperty, value); }
        }

        /// <summary>
        /// The selected sort.
        /// </summary>
        public static readonly DependencyProperty SelectedSortProperty =
            DependencyProperty.Register("SelectedSort", typeof(object), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SelectedSortProperty"/> DependencyProperty.
        /// </summary>
        public object SelectedSort
        {
            get { return GetValue(SelectedSortProperty); }
            set { SetValue(SelectedSortProperty, value); }
        }

        /// <summary>
        /// A collection used to group the main collection.
        /// </summary>
        public static readonly DependencyProperty GroupsProperty =
            DependencyProperty.Register("Groups", typeof(IEnumerable), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="GroupsProperty"/> DependencyProperty.
        /// </summary>
        public IEnumerable Groups
        {
            get { return (IEnumerable)GetValue(GroupsProperty); }
            set { SetValue(GroupsProperty, value); }
        }

        /// <summary>
        /// The current group used to group the main collection.
        /// </summary>
        public static readonly DependencyProperty SelectedGroupProperty =
            DependencyProperty.Register("SelectedGroup", typeof(object), typeof(SideListControl), new PropertyMetadata(null));
        /// <summary>
        /// Exposes the <see cref="SelectedGroupProperty"/> DependencyProperty.
        /// </summary>
        public object SelectedGroup
        {
            get { return GetValue(SelectedGroupProperty); }
            set { SetValue(SelectedGroupProperty, value); }
        }

        /// <summary>
        /// The visibility of the sort control.
        /// </summary>
        public static readonly DependencyProperty SortVisibilityProperty =
            DependencyProperty.Register("SortVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="SortVisibilityProperty"/> DependencyProperty.
        /// </summary>
        public Visibility SortVisibility
        {
            get { return (Visibility)GetValue(SortVisibilityProperty); }
            set { SetValue(SortVisibilityProperty, value); }
        }

        /// <summary>
        /// The visiblity of the group control.
        /// </summary>
        public static readonly DependencyProperty GroupVisibilityProperty =
            DependencyProperty.Register("GroupVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Visible));
        /// <summary>
        /// Exposes the <see cref="GroupVisibilityProperty"/> DependencyProperty.
        /// </summary>
        public Visibility GroupVisibility
        {
            get { return (Visibility)GetValue(GroupVisibilityProperty); }
            set { SetValue(GroupVisibilityProperty, value); }
        }

        /// <summary>
        /// If the main collection is busy. i.e loading or retreiving data.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(SideListControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsBusyProperty"/> DependencyProperty.
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        /// <summary>
        /// If the main collection is scrolling in a lazy loading scenario.
        /// </summary>
        public static readonly DependencyProperty IsScrollingProperty =
            DependencyProperty.Register("IsScrolling", typeof(bool), typeof(SideListControl), new PropertyMetadata(false));
        /// <summary>
        /// Exposes the <see cref="IsScrollingProperty"/> DependencyProperty.
        /// </summary>
        public bool IsScrolling
        {
            get { return (bool)GetValue(IsScrollingProperty); }
            set { SetValue(IsScrollingProperty, value); }
        }

        /// <summary>
        /// Used to replace the search box. If this is not null then the search will be collpsed and this content will be used instead.
        /// Can be used to display a date range for example.
        /// </summary>
        public static readonly DependencyProperty QuickFilterContentProperty =
            DependencyProperty.Register("QuickFilterContent", typeof(object), typeof(SideListControl), new PropertyMetadata(null, OnQuickFilterContentChanged));
        /// <summary>
        /// Exposes the <see cref="QuickFilterContentProperty"/> DependencyProperty.
        /// </summary>
        public object QuickFilterContent
        {
            get { return GetValue(QuickFilterContentProperty); }
            set { SetValue(QuickFilterContentProperty, value); }
        }

        /// <summary>
        /// Controls the visibility of the Quick Filter. This is set to visibile automatically if the <see cref="QuickFilterContent"/> property is not null.
        /// </summary>
        public static readonly DependencyProperty QuickFilterVisibilityProperty =
            DependencyProperty.Register("QuickFilterVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Collapsed));
        /// <summary>
        /// Exposes the <see cref="QuickFilterVisibilityProperty"/> DependencyProperty.
        /// </summary>
        public Visibility QuickFilterVisibility
        {
            get { return (Visibility)GetValue(QuickFilterVisibilityProperty); }
            set { SetValue(QuickFilterVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets or sets the direction in which the panel slides.
        /// </summary>
        public static readonly DependencyProperty SlideDirectionProperty =
            DependencyProperty.Register("SlideDirection", typeof(SlideDirection), typeof(SideListControl), new PropertyMetadata(SlideDirection.LeftToRight));
        /// <summary>
        /// Exposes the <see cref="SlideDirectionProperty"/> DependencyProperty.
        /// </summary>
        public SlideDirection SlideDirection
        {
            get { return (SlideDirection)GetValue(SlideDirectionProperty); }
            set { SetValue(SlideDirectionProperty, value); }
        }

        static SideListControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SideListControl), new FrameworkPropertyMetadata(typeof(SideListControl)));
        }

        /// <summary>
        /// Applies the controls template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            var panel = Template.FindName("SlidePanel", this) as SlidePanel;
            if (panel != null)
            {
                panel.Closed += (sender, args) => UpdateVisibility();
            }

            UpdateVisibility();
            base.OnApplyTemplate();
        }

        private static void OnIsOpenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SideListControl) d;
            control.UpdateFilterIsOpen();
            control.UpdateVisibility();
        }

        private void UpdateFilterIsOpen()
        {
            if (IsOpen)
            {
                IsFilterOpened = _previousVesselIsOpen;
            }
            else
            {
                _previousVesselIsOpen = IsFilterOpened;
                IsFilterOpened = false;
            }
        }

        private void UpdateVisibility()
        {
            if (IsOpen)
            {
                var content = Template.FindName("Content", this) as FrameworkElement;
                if (content != null)
                {
                    content.Visibility = IsOpen ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        private static void OnQuickFilterContentChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (SideListControl)d;
            control.OnQuickFilterContentChanged();
        }

        private void OnQuickFilterContentChanged()
        {
            if (QuickFilterContent != null)
            {
                SearchVisibility = Visibility.Collapsed;
                QuickFilterVisibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// The clear filter visibility property
        /// </summary>
        public static readonly DependencyProperty ClearFilterVisibilityProperty =
            DependencyProperty.Register("ClearFilterVisibility", typeof(Visibility), typeof(SideListControl), new PropertyMetadata(Visibility.Collapsed));

        /// <summary>
        /// Gets or sets the clear filter visibility.
        /// </summary>
        /// <value>
        /// The clear filter visibility.
        /// </value>
        public Visibility ClearFilterVisibility
        {
            get { return (Visibility)GetValue(ClearFilterVisibilityProperty); }
            set { SetValue(ClearFilterVisibilityProperty, value); }
        }

        /// <summary>
        /// The clear filter command property
        /// </summary>
        public static readonly DependencyProperty ClearFilterCommandProperty =
            DependencyProperty.Register("ClearFilterCommand", typeof(ICommand), typeof(SideListControl), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the clear filter command.
        /// </summary>
        /// <value>
        /// The clear filter command.
        /// </value>
        public ICommand ClearFilterCommand
        {
            get { return (ICommand)GetValue(ClearFilterCommandProperty); }
            set { SetValue(ClearFilterCommandProperty, value); }
        }
    }
}
