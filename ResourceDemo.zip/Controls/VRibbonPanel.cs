﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.Controls
{
    /// <summary>
    /// The panel used to layout the groups in the VRibbon control.
    /// </summary>
    public class VRibbonPanel : Panel
    {
        #region Properties

        /// <summary>
        /// The minimum group width
        /// </summary>
        private const double MinGroupWidth = 100d;

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Measures the panels children.
        /// </summary>
        /// <param name="availableSize">The available size that this element can give to child elements. Infinity can be specified as a value to indicate that the element will size to whatever content is available.</param>
        /// <returns>The size that this element determines it needs during layout, based on its calculations of child element sizes.</returns>
        protected override Size MeasureOverride(Size availableSize)
        {
            if (!double.IsInfinity(availableSize.Width))
            {
                var isCollapsed = false;
                var currentX = 0d;
                var currentY = 0d;
                var infinityMeasure = new Size(double.PositiveInfinity, double.PositiveInfinity);
                var minMeasure = new Size(MinGroupWidth, double.PositiveInfinity);
                var remain = Children.Count;

                foreach (VRibbonGroup child in Children)
                {
                    remain--;
                    ExpandChild(child);
                    child.Measure(infinityMeasure);
                    if ((currentX + child.DesiredSize.Width + (MinGroupWidth * remain)) > availableSize.Width || (isCollapsed && child.IsCollapsed))
                    {
                        isCollapsed = true;
                        CollapseChild(child);
                        currentX = currentX + MinGroupWidth;
                        child.Measure(minMeasure);
                    }
                    else
                    {
                        currentX = currentX + child.DesiredSize.Width;
                    }
                    currentY = Math.Max(currentY, child.DesiredSize.Height);
                }
                return new Size(availableSize.Width, currentY);
            }
            return base.MeasureOverride(availableSize);
        }

        /// <summary>
        /// Arranges the panels children.
        /// </summary>
        /// <param name="finalSize">The final area within the parent that this element should use to arrange itself and its children.</param>
        /// <returns>The actual size used of type <see cref="Size"/>.</returns>
        protected override Size ArrangeOverride(Size finalSize)
        {
            var currentX = 0d;
            foreach (VRibbonGroup child in Children)
            {
                var width = child.IsCollapsed ? MinGroupWidth : child.DesiredSize.Width;
                child.Arrange(new Rect(currentX, 0, width, child.DesiredSize.Height));

                currentX = currentX + width;
            }
            return base.ArrangeOverride(finalSize);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Expands the child.
        /// </summary>
        /// <param name="child">The child of type <see cref="VRibbonGroup"/>.</param>
        private void ExpandChild(VRibbonGroup child)
        {
            child.IsCollapsed = false;
        }

        /// <summary>
        /// Collapses the child.
        /// </summary>
        /// <param name="child">The child of type <see cref="VRibbonGroup"/>.</param>
        private void CollapseChild(VRibbonGroup child)
        {
            child.IsCollapsed = (child.Items != null && child.Items.Count > 1);
        }

        #endregion
    }
}