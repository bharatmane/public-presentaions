﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts a date into a simplified version
    /// </summary>
    public class DateTimeConverter : IValueConverter
    {
        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a DateTime value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The value as a formatted date</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null && value is DateTime)
            {
                var dateTime = (DateTime)value;

                if (IsToday(dateTime))
                {
                    return dateTime.ToString("hh:mm");
                }

                if (IsWeek(dateTime))
                {
                    return dateTime.ToString("dddd hh:mm");
                }

                return dateTime.ToString(VShips.Framework.Resource.Helpers.Constants.ApplicationDateFormat);
            }

            return "Unknown";
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }

        private bool IsToday(DateTime date)
        {
            return Equals(date.Date, DateTime.Now.Date);
        }

        private bool IsWeek(DateTime date)
        {
            var firstDayInWeek = GetFirstDayInWeek();
            return date >= firstDayInWeek && date < firstDayInWeek.AddDays(7);
        }

        private DateTime GetFirstDayInWeek()
        {
            var firstWeekDay = CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
            var firstDayInWeek = DateTime.Now;
            if (firstDayInWeek.DayOfWeek == firstWeekDay)
            {
                firstDayInWeek = firstDayInWeek.AddDays(-6);
            }
            else
            {
                while (firstDayInWeek.DayOfWeek != firstWeekDay)
                {
                    firstDayInWeek = firstDayInWeek.AddDays(-1);
                }
            }

            return firstDayInWeek;
        }
    }
}
