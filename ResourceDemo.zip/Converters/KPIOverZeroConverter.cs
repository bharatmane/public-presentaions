﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Returns a <see cref="KPIBrush"/> if the value passed in is over zero.
    /// </summary>
    public class KPIOverZeroConverter : IValueConverter
    {
        /// <summary> 
        /// If the value is greater than 0 this brush will be returned
        /// </summary>
        public Brush KPIBrush { get; set; }

        /// <summary> 
        /// If the value is less than or equal to 0 this brush will be returned
        /// </summary>
        public Brush NormalBrush { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects an int value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The <see cref="KPIBrush"/> if the value is greater than 0, otherwise the <see cref="NormalBrush"/></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value != null && ((int)value) > 0 ? KPIBrush : NormalBrush;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
