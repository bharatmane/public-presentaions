﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A simple alternation converter that assumes 2 index values.
    /// </summary>
    public class SimpleAlternationConverter : IValueConverter
    {
        /// <summary>
        /// The object returned with value 0.
        /// </summary>
        public object Index0 { get; set; }

        /// <summary>
        /// The object returned with value 1.
        /// </summary>
        public object Index1 { get; set; }

        /// <summary>
        /// Converters an integer index to the values held in the properties <see cref="Index0"/> and <see cref="Index1"/>.
        /// </summary>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var index = (int) value;

            return index == 1 ? Index1 : Index0;
        }

        /// <summary>
        /// Backwards conversion are not supported.
        /// </summary>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported!");
        }
    }
}
