﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A converter class for handling the visibility in case if value is Null Or Zero Or Greater Than Zero.
    /// Default visibility for different values are as follows:
    /// Null : Collpased.
    /// Zero : Collpased.
    /// Greater Than Zero : Visible.
    /// </summary>
    /// <seealso cref="System.Windows.Data.IValueConverter" />
    public class NullOrZeroToVisibilityConverter : IValueConverter
    {
        /// <summary>
        /// Gets or sets the null visibility.
        /// </summary>
        /// <value>
        /// The null visibility.
        /// </value>
        public Visibility NullVisibility { get; set; }

        /// <summary>
        /// Gets or sets the zero visibility.
        /// </summary>
        /// <value>
        /// The zero visibility.
        /// </value>
        public Visibility ZeroVisibility { get; set; }

        /// <summary>
        /// Gets or sets the not zero visibility.
        /// </summary>
        /// <value>
        /// The not zero visibility.
        /// </value>
        public Visibility NotZeroVisibility { get; set; }

        /// <summary>
        /// The default constructor which sets the default visibility properties.
        /// </summary>
        public NullOrZeroToVisibilityConverter()
        {
            NullVisibility = ZeroVisibility = Visibility.Collapsed;
            NotZeroVisibility = Visibility.Visible;
        }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// Visibility value.
        /// </returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value == null)
            {
                return NullVisibility;
            }
            else 
            {
                return value.ToString() == "0" ? ZeroVisibility : NotZeroVisibility;
            }
        }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value that is produced by the binding target.</param>
        /// <param name="targetType">The type to convert to.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <exception cref="NotSupportedException"></exception>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
