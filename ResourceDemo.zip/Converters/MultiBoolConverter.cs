﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    public class MultiBoolConverter : IMultiValueConverter
    {
        /// <summary>
        /// The object returned if the value was true
        /// </summary>
        public object TrueValue { get; set; }

        /// <summary>
        /// The object returned if the value was false
        /// </summary>
        public object FalseValue { get; set; }

        /// <summary>
        /// The object returned if the value was null
        /// </summary>
        public object NullValue { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a bool value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns><see cref="TrueValue"/> if the value is True, <see cref="FalseValue"/> is the value is False.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            bool combinedValue=true;

            foreach (object value in values) { 
                if (value is bool)
                { combinedValue = combinedValue && (bool)value; }
                else
                {
                    bool b;
                    bool.TryParse(value.ToString(), out b);
                    combinedValue = combinedValue && b;
                }
            }

            //return combinedValue ? TrueValue : FalseValue;
            return combinedValue ? TrueValue : FalseValue;
        }

        /// <summary>
        /// Reverses the value conversion
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>True if the value equals <see cref="TrueValue"/>, False if the value equals <see cref="FalseValue"/></returns>
        public object[] ConvertBack(object value, Type[] targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }

      
        
    }

}
