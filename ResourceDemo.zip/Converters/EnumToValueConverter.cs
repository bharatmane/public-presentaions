﻿using System;
using System.Globalization;
using System.Windows.Data;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// A <see cref="IValueConverter"/> that takes order status
    /// and returns a order status key, order status value or both.
    /// </para>
    /// <para>
    /// The first value expected is a order status.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example creates a <see cref="System.Windows.Controls.TextBlock"/> control
    /// and sets its Text property to binding which passes in the values of the properties 
    /// Parameter specify the output required.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:CurrencyConverter x:Key="CurrencyConverter" /> 
    /// 
    /// <TextBlock Margin="{StaticResource MarginL}"
    ///            Text="{Binding OrderStatus, Converter={StaticResource EnumToValueConverter} ,ConverterParameter=PurchaseOrderStatus*valuedescription}"> 
    /// </TextBlock>
    /// ]]>
    /// </code>
    /// </example>
    public class EnumToValueConverter : IValueConverter
    {
        /// <summary>
        /// Shows the value on the enum.
        /// </summary>
        public bool ShowKeyValue { get; set; }

        /// <summary>
        /// Shows the description on the enum.
        /// </summary>
        public bool ShowDescription { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [show short code].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show short code]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowShortCode { get; set; }

        /// <summary>
        /// Retreives the <see cref="EnumValueDataAttribute"/> matadata from an enum type.
        /// Returns a string representing the metadata values.
        /// </summary>
        /// <param name="value">An enum whos matadata contains the type <see cref="EnumValueDataAttribute"/>.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>A string determined by the enums metadata.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var ret = "";

            if (value != null)
            {

                if (ShowKeyValue || ShowDescription)
                {
                    var data = EnumValueConverter.GetEnumMetadata(value);
                    if (data != null)
                    {
                        if (ShowKeyValue)
                        {
                            ret = data.KeyValue;
                        }

                        if (ShowDescription)
                        {
                            ret = !string.IsNullOrWhiteSpace(ret) ? ret + " - " + data.Name : data.Name;
                        }
                    }
                }

                if (ShowShortCode)
                {
                    var shortCodeData = EnumValueConverter.GetEnumShortCode(value);
                    if (shortCodeData != null)
                    {
                        ret = shortCodeData.ShortCode;
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }

    }

}