﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A two way converter between an enum and an int.
    /// The paramter expectes the type of the enum.
    /// </summary>
    public class EnumToIntConverter : IValueConverter
    {
        /// <summary>
        /// Converts an enum to an int.
        /// </summary>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (int) value;
        }

        /// <summary>
        /// Converts an int to an enum where the parameter is the type of the enum.
        /// </summary>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Enum.Parse((Type)parameter, value.ToString());
        }
    }
}
