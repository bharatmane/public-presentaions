﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts the degree value to a string in the correct display format.
    /// </summary>
    public class DegreeConverter : IValueConverter
    {
        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a timespan value.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The degree value as a formated string.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string valueFormat = "000";
            float defaultValue = 0;

            if (value == null)
            {
                return defaultValue;
            }
            else
            {
                float inputValue = (float)value;
                
                if (inputValue == 0)
                {
                    return defaultValue;
                }
                else
                {
                    return inputValue.ToString(valueFormat);
                }
                
            }
        }

        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetType">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
