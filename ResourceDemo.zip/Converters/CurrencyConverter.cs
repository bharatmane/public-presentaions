﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// A <see cref="IMultiValueConverter"/> that takes both a number and a culture string
    /// and returns a number formatted by the cultures currency.
    /// </para>
    /// <para>
    /// The first value expected is a number.
    /// </para>
    /// <para>
    /// And the second value expected is the culture specific currency
    /// </para>
    /// <para>
    /// A list of culture codes can be found at https://msdn.microsoft.com/en-gb/library/ee825488(v=cs.20).aspx
    /// </para>
    /// </summary>
    /// <example>
    /// The following example creates a <see cref="System.Windows.Controls.TextBlock"/> control
    /// and sets its Text property to multibinding which passes in the values of the properties
    /// YearAllocation and CultureInfo to the CurrencyConverter. If YearAllocation = 12 and 
    /// CultureInfo = en-GB the resulting text will be £12.00.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:CurrencyConverter x:Key="CurrencyConverter" /> 
    /// 
    /// <TextBlock>
    ///     <TextBlock.Text>
    ///         <MultiBinding Converter="{StaticResource CurrencyConverter}">
    ///             <Binding Path="YearAllocation" />
    ///             <Binding Path="CultureInfo" />
    ///         </MultiBinding>
    ///     </TextBlock.Text>
    /// </TextBlock>]]>
    /// </code>
    /// </example>
    public class CurrencyConverter : IMultiValueConverter
    {
        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="values">Expects double and string values</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The value as a currency</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                if (values.Length >= 2)
                {
                    var value = values[0];
                    var currency = (string)values[1];
                    if (value != null && !string.IsNullOrWhiteSpace(currency))
                    {
                        double number;
                        double.TryParse(value.ToString(), out number);

                        return number.ToString("C", CultureInfo.CreateSpecificCulture(currency));
                    }
                }
            }
            catch (Exception)
            {
                return 0;
            }
            return 0;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetTypes">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
