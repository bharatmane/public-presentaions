﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts a KPI enum to its corresponding brush.
    /// </summary>
    public class VettingStatusKPIConverter : IValueConverter
    {
        /// <summary>
        /// The brush used to convert KPI.Requested
        /// </summary>
        public Brush RequestedBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.ReadyForVetting
        /// </summary>
        public Brush ReadyForVettingBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.VettingInProgress
        /// </summary>
        public Brush VettingInProgressBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.PendingSignOff
        /// </summary>
        public Brush PendingSignOffBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Approved
        /// </summary>
        public Brush ApprovedBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Rejected
        /// </summary>
        public Brush RejectedBrush { get; set; }

        /// <summary>
        /// Gets or sets the cancelled brush.
        /// </summary>
        /// <value>
        /// The cancelled brush.
        /// </value>
        public Brush CancelledBrush { get; set; }
        
        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a KPI enum value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a Brush correspoding to the passed in KPI</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var kpi = (VettingStatusKPI)value;
            switch (kpi)
            {
                case VettingStatusKPI.Requested:
                    return RequestedBrush;
                case VettingStatusKPI.ReadyForVetting:
                    return ReadyForVettingBrush;
                case VettingStatusKPI.VettingInProgress:
                    return VettingInProgressBrush;
                case VettingStatusKPI.PendingSignOff:
                    return PendingSignOffBrush;
                case VettingStatusKPI.Approved:
                    return ApprovedBrush;
                case VettingStatusKPI.Rejected:
                    return RejectedBrush;
                case VettingStatusKPI.Cancelled:
                    return CancelledBrush;
                case VettingStatusKPI.RequestIncomplete:
                    return RequestedBrush;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
