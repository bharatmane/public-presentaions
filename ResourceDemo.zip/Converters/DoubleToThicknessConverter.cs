﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts a number to a <see cref="Thickness"/>
    /// </summary>
    public class DoubleToThicknessConverter : IValueConverter
    {
        /// <summary>
        /// If Left should be used in the conversion
        /// </summary>
        public bool L { get; set; }

        /// <summary>
        /// If Top should be used in the conversion
        /// </summary>
        public bool T { get; set; }

        /// <summary>
        /// If Right should be used in the conversion
        /// </summary>
        public bool R { get; set; }

        /// <summary>
        /// If Bottom should be used in the conversion
        /// </summary>
        public bool B { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a double value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a <see cref="Thickness"/> with its appropriate L T R B values set</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var val = (double) value;
            return new Thickness(L ? val : 0, T ? val : 0, R ? val : 0, B ? val : 0);
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
