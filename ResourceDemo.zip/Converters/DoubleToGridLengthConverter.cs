﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts a double value into a GridLength. 
    /// </summary>
    public class DoubleToGridLengthConverter : IValueConverter
    {
        /// <summary>
        /// Multiplies the double value by this amount.
        /// the default value is 1.
        /// </summary>
        public double Multiplier { get; set; }

        /// <summary>
        /// The default constructor which set the <see cref="Multiplier"/> to 1.
        /// </summary>
        public DoubleToGridLengthConverter()
        {
            Multiplier = 1;
        }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a double value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a GridLength by multiplting the value by the <see cref="Multiplier"/></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var d = (double) value;
            return new GridLength(d * Multiplier);
        }

        /// <summary>
        /// Reverses the value conversion
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns the value of a GridLength divided by the <see cref="Multiplier"/></returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var gridLength = (GridLength) value;
            return gridLength.Value/Multiplier;
        }
    }
}
