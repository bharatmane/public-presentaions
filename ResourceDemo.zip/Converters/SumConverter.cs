﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// A <see cref="IMultiValueConverter"/> that takes multiple numbers and returns the sum total as string.
    /// </para>
    /// <para>
    /// The first parameter are the values expected to be added up.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example creates a <see cref="System.Windows.Controls.TextBlock"/> control
    /// and sets its Text property to multibinding which passes in the values of the properties
    /// Actual and Accrual to the SumConverter. If Actual = 10000.278 and 
    /// Accrual = 2000.89 the resulting text will be 12001.168
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:SumConverter x:Key="SumConverter" /> 
    /// 
    /// <TextBlock>
    ///     <TextBlock.Text>
    ///         <MultiBinding Converter="{StaticResource SumConverter}">
    ///             <Binding Path="Actual" />
    ///             <Binding Path="Accrual" />
    ///         </MultiBinding>
    ///     </TextBlock.Text>
    /// </TextBlock>]]>
    /// </code>
    /// 
    /// The following example creates a <see cref="System.Windows.Controls.TextBlock"/> control
    /// and sets its Text property to multibinding which passes in the values of the properties
    /// Actual and Accrual to the SumConverter. If Actual = 10000.278 and 
    /// Accrual = 2000.89 and if ConverterParameter="2" than the resulting text will be 12,001.17
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:SumConverter x:Key="SumConverter" /> 
    /// 
    /// <TextBlock>
    ///     <TextBlock.Text>
    ///         <MultiBinding Converter="{StaticResource SumConverter}" ConverterParameter="2">
    ///             <Binding Path="Actual" />
    ///             <Binding Path="Accrual" />
    ///         </MultiBinding>
    ///     </TextBlock.Text>
    /// </TextBlock>]]>
    /// </code>
    /// </example>
    public class SumConverter : IMultiValueConverter
    {
        /// <summary>
        /// Executes the value conversion. 
        /// </summary>
        /// <param name="values">Expects an array of values that can be parsed as doubles.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>A sum of all the values passed.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double total = values.Sum(val => val != null ? double.Parse(val.ToString()) : 0);
            //if you want to show Total Amount in proper Format,that time you pass parameters with sumconverter.
            if (parameter != null)
            {
                var currencyFormatter = new CurrencyFormatConverter();
                return currencyFormatter.Convert(total, targetType, parameter, culture).ToString();
            }
            return total.ToString(CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are only supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetTypes">The types of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
