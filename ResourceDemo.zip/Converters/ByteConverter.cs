﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A generic converter which takes a byte value
    /// and returns the values represented by its related
    /// <see cref="TrueValue"/> and <see cref="FalseValue"/> properties.
    /// </summary>
    /// <example>
    /// The following example will return the Yes resource if the value 
    /// passed to the converter is 1 or the No resource if the value
    /// is 0.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:ByteConverter x:Key="ByteToYesOrNO" TrueValue="Yes" FalseValue="No" />]]>
    /// </code>
    /// </example>
    /// 

    public class ByteConverter : IValueConverter
    {
        /// <summary>
        /// The object returned if the value was 1
        /// </summary>
        public object TrueValue { get; set; }

        /// <summary>
        /// The object returned if the value was 0
        /// </summary>
        public object FalseValue { get; set; }

        /// <summary>
        /// Gets or sets the null value.
        /// </summary>
        /// <value>
        /// The null value.
        /// </value>
        public object NullValue { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary> 
        /// <param name="value">Expects a byte value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns><see cref="TrueValue"/> if the value is 1, <see cref="FalseValue"/> is the value is 0.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
            {
                return NullValue;
            }
            var b = (byte)value;
            return b == 1 ? TrueValue : FalseValue;
        }

        /// <summary>
        /// Reverses the value conversion
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>True if the value equals <see cref="TrueValue"/>, False if the value equals <see cref="FalseValue"/></returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Equals(value, TrueValue);
        }


    }
}
