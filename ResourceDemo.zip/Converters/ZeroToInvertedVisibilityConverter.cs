﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// An <see cref="IValueConverter"/> used to check the passed in object for null.
    /// </para>
    /// <para>
    /// If it is null it returns the <see cref="ZeroValue"/> property, otherwise it will return the <see cref="NotZeroValue"/> property.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example declares a NullToBoolConverter which will return false
    /// if the object passed in is null.
    /// <code lang="XAML" title="Visible when not null">
    /// <![CDATA[
    /// <converters:NullToBoolConverter x:Key="NullToBoolConverter" />
    /// ]]>
    /// </code>
    /// </example>
    /// <example>
    /// The following example declares a NullToBoolConverter which will return true
    /// if the object passed in is null.
    /// <code lang="XAML" title="Visible when null">
    /// <![CDATA[
    /// <converters:NullToBoolConverter x:Key="NullToBoolConverter" NullValue="True" NotNullValue="False" />
    /// ]]>
    /// </code>
    /// </example>
    public class ZeroToInvertedVisibilityConverter : IValueConverter
    {
          /// <summary>
        /// Gets or sets the visiblity returned if the value is null. The default value is <see cref="Visibility.Collapsed"/>.
        /// </summary>
        public Visibility ZeroValue { get; set; }

        /// <summary>
        /// Gets or sets the visiblity returned if the value is not null. The default value is <see cref="Visibility.Visible"/>.
        /// </summary>
        public Visibility NotZeroValue { get; set; }

        /// <summary>
        /// The default constructor which sets the default visibility properties.
        /// </summary>
        public ZeroToInvertedVisibilityConverter()
        {
            ZeroValue = Visibility.Collapsed;
            NotZeroValue = Visibility.Visible;
        }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects an object</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns <see cref="ZeroValue"/> if the value is null or <see cref="NotZeroValue"/> if the value is not null.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value.ToString() == "0" || value.ToString() == "0.0" || value.ToString() == "0.00" ? ZeroValue : NotZeroValue;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
