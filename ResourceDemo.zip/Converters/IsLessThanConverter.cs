﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts a KPI enum to its corresponding brush.
    /// </summary>
    public class IsLessThanConverter : IValueConverter
    {
        /// <summary> 
        /// If the value is less than 0 this brush will be returned
        /// </summary>
        public Brush RedBrush { get; set; }

        /// <summary> 
        /// If the value is equal to 0 this brush will be returned
        /// </summary>
        public Brush NormalBrush { get; set; }

        /// <summary> 
        /// If the value is greater than 0 this brush will be returned
        /// </summary>
        public Brush GreenBrush { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a KPI enum value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a Brush correspoding to the passed in KPI</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int val = 0;
            if (value != null && IsNumber(value, out val))
            {
                if (val == 0)
                { return NormalBrush; }
                else if (val < 0)
                { return RedBrush; }
                else
                { return GreenBrush; }
            }
            else
            {
                return NormalBrush;
            }
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }

        /// <summary>
        /// Determines whether the specified object is number.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="val">The value.</param>
        /// <returns>
        ///   <c>true</c> if the specified object is number; otherwise, <c>false</c>.
        /// </returns>
        private bool IsNumber(object obj, out int val)
        {
            val = 0;
            double doubleNum;
            long longNum;
            decimal decimalNum;
            if (double.TryParse(System.Convert.ToString(obj), out doubleNum))
            {
                if (doubleNum > 0)
                {
                    val = 1;
                }
                else if (doubleNum < 0)
                {
                    val = -1;
                }
                return true;
            }
            else if (long.TryParse(System.Convert.ToString(obj), out longNum))
            {
                if (longNum > 0)
                {
                    val = 1;
                }
                else if (longNum < 0)
                {
                    val = -1;
                }
                return true;
            }
            else if (decimal.TryParse(System.Convert.ToString(obj), out decimalNum))
            {
                if (decimalNum > 0)
                {
                    val = 1;
                }
                else if (decimalNum < 0)
                {
                    val = -1;
                }
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
