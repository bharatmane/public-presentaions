﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// An <see cref="IValueConverter"/> used to check the passed in object for null.
    /// </para>
    /// <para>
    /// If it is null it returns the <see cref="NullValue"/> property, otherwise it will return the <see cref="NotNullValue"/> property.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example declares a NullToBoolConverter which will return false
    /// if the object passed in is null.
    /// <code lang="XAML" title="Visible when not null">
    /// <![CDATA[
    /// <converters:NullToBoolConverter x:Key="NullToBoolConverter" />
    /// ]]>
    /// </code>
    /// </example>
    /// <example>
    /// The following example declares a NullToBoolConverter which will return true
    /// if the object passed in is null.
    /// <code lang="XAML" title="Visible when null">
    /// <![CDATA[
    /// <converters:NullToBoolConverter x:Key="NullToBoolConverter" NullValue="True" NotNullValue="False" />
    /// ]]>
    /// </code>
    /// </example>
    public class NullToBoolConverter : IValueConverter
    {
        /// <summary>
        /// Gets or sets the bool returned if the value is null. The default value is false.
        /// </summary>
        public bool NullValue { get; set; }

        /// <summary>
        /// Gets or sets the bool returned if the value is not null. The default value is true.
        /// </summary>
        public bool NotNullValue { get; set; }

        /// <summary>
        /// The default constructor which sets the default visibility properties.
        /// </summary>
        public NullToBoolConverter()
        {
            NullValue = false;
            NotNullValue = true;
        }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects an object</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns <see cref="NullValue"/> if the value is null or <see cref="NotNullValue"/> if the value is not null.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (value == null || String.IsNullOrWhiteSpace(value.ToString())) ? NullValue : NotNullValue;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
