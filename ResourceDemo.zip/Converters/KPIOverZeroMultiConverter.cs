﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A multiconverter which takes a number and a KPI
    /// if the number is greater than zero it uses the brush 
    /// properties to return a brush relating to the KPI. 
    /// Otherwise it will return the <see cref="NormalBrush"/>.
    /// </summary>
    /// <example>
    /// The following example uses the KPIOverZeroMultiConverter to set the background of the
    /// Border determined by the Deficiencies and KPI properties of it's ViewModel. If the Deficiencies
    /// property is greater than 0 the KPI property will be used to display it's related Brush.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:KPIOverZeroMultiConverter x:Key="KPIOverZeroMultiConverter" 
    ///             NormalBrush="{StaticResource BrushBlack}" 
    ///             GoodBrush="{StaticResource BrushGreen}" 
    ///             PreWarningBrush="{StaticResource Brushyellow}"
    ///             WarningBrush="{StaticResource BrushOrange}" 
    ///             CrticalBrush="{StaticResource BrushRed}" />
    /// 
    /// <Border>
    ///     <Border.Background>
    ///         <MultiBinding Converter="{StaticResource KPIOverZeroMultiConverter}">
    ///             <Binding Path="Deficiencies" />
    ///             <Binding Path="KPI" />
    ///         </MultiBinding>
    ///     </Border.Background>
    /// </Border>]]>
    /// </code>
    /// </example>
    public class KPIOverZeroMultiConverter : IMultiValueConverter
    {
        /// <summary>
        /// Returned if the value is zero or KPI.Normal
        /// </summary>
        public Brush NormalBrush { get; set; }

        /// <summary>
        /// Returned if the value greater than zero and the KPI is KPI.Good.
        /// </summary>
        public Brush GoodBrush { get; set; }

        /// <summary>
        /// Returned if the value greater than zero and the KPI is KPI.PreWarning.
        /// </summary>
        public Brush PreWarningBrush { get; set; }

        /// <summary>
        /// Returned if the value greater than zero and the KPI is KPI.Warning.
        /// </summary>
        public Brush WarningBrush { get; set; }

        /// <summary>
        /// Returned if the value greater than zero and the KPI is KPI.Critical.
        /// </summary>
        public Brush CrticalBrush { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="values">Expects int and KPI values</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>A brush corresponding to the passed in KPI if the value is greater than 0, otherwise the <see cref="NormalBrush"/></returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var value = (int)values[0];
            var kpi = (KPI)values[1];

            if (value > 0)
            {
                switch (kpi)
                {
                    case KPI.Normal:
                        return NormalBrush;
                    case KPI.Good:
                        return GoodBrush;
                    case KPI.PreWarning:
                        return PreWarningBrush;
                    case KPI.Warning:
                        return WarningBrush;
                    case KPI.Critical:
                        return CrticalBrush;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }

            return NormalBrush;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetTypes">The types of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
