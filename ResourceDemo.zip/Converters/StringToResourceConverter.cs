﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using VShips.Framework.Common.Model.Icons;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// Converts a string to a resource by the same name found in the Application scope.
    /// </para>
    /// <para>
    /// Null will be returned if the resource is not found.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example creates a DataTemplate for a ResourceIcon and uses
    /// the StringToResourceConverter to find a Geometry based resource by the name provided 
    /// by the Value property.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:StringToResourceConverter x:Key="StringToResourceConverter" />
    /// 
    /// <DataTemplate DataType="{x:Type icons:ResourceIcon}">
    ///     <Path Data="{Binding Value, Converter={StaticResource StringToResourceConverter}}" Fill="{StaticResource BrushInverted}" Stretch="Uniform"/>
    /// </DataTemplate>
    /// ]]>
    /// </code>
    /// </example>
    public class StringToResourceConverter : IValueConverter    
    {
        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects an object and calls ToString()</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a resource by the name passed as the value or null if it can't be found.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            object resource = null;

            if (value != null)
            {
                var resourceIcon = value as ResourceIcon;

                var resourceName = (string)((resourceIcon != null) ? resourceIcon.Value : value);
                if (resourceName != null)
                {
                    resource = Application.Current.TryFindResource(resourceName.Trim());
                }
            }

            if (resource == null)
            {
                Debug.Print("Resource not found: " + (value != null ? value.ToString() : "Unknown name!!!"));
            }

            return resource;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
