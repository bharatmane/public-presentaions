﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// An <see cref="IValueConverter"/> used to check the value passed in object for null or blank.
    /// </para>
    /// <para>
    /// If it is null or blank, it returns the <see cref="NullVisibility"/> property, otherwise it will return the <see cref="NotNullVisibility"/> property.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example declares a NullToVisibilityConverter which will return <see cref="Visibility.Collapsed"/>
    /// if the object passed in is null or blank.
    /// <code lang="XAML" title="Visible when not null">
    /// <![CDATA[
    /// <converters:NullToVisibilityConverter x:Key="NullToVisibilityConverter" />
    /// ]]>
    /// </code>
    /// </example>
    /// <example>
    /// The following example declares a NullToVisibilityConverter which will return <see cref="Visibility.Visible"/>
    /// if the object passed in is null or blank.
    /// <code lang="XAML" title="Visible when null">
    /// <![CDATA[
    /// <converters:NullToVisibilityConverter x:Key="NullToVisibilityConverterInverted" NullVisibility="Visible" NotNullVisibility="Collapsed" />
    /// ]]>
    /// </code>
    /// </example>
    public class NullToVisibilityConverter : IValueConverter
    {
        /// <summary>
        /// Gets or sets the visiblity returned if the value is null. The default value is <see cref="Visibility.Collapsed"/>.
        /// </summary>
        public Visibility NullVisibility { get; set; }

        /// <summary>
        /// Gets or sets the visiblity returned if the value is not null. The default value is <see cref="Visibility.Visible"/>.
        /// </summary>
        public Visibility NotNullVisibility { get; set; }

        /// <summary>
        /// The default constructor which sets the default visibility properties.
        /// </summary>
        public NullToVisibilityConverter()
        {
            NullVisibility = Visibility.Collapsed;
            NotNullVisibility = Visibility.Visible;
        }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects an object</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns <see cref="NullVisibility"/> if the value is null or <see cref="NotNullVisibility"/> if the value is not null.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value == null || String.IsNullOrWhiteSpace(value.ToString()) ? NullVisibility : NotNullVisibility;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
