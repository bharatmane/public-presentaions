﻿using System.Windows.Data;
using System.Globalization;
using System;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts the decimal number to formatted string
    /// </summary>
    public class CurrencyFormatConverter : IValueConverter
    {
        /// <summary>
        /// Formats amount with thousand separator and rounded decimals upto the number of decimal specified.
        /// </summary>
        /// <param name="value">Amount to be formated </param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">Number of decimals up to which the amount should be rounded off.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Single value of type string.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                int intNoOfDecimals = 0;
                string strDecimals = "";
                if (parameter != null)
                    intNoOfDecimals = int.Parse(parameter.ToString());

                if (intNoOfDecimals >= 0)
                {
                    strDecimals = "{0:N" + intNoOfDecimals + "}";
                }

                if (value == null)
                {
                    return String.Format(strDecimals, 0);
                }
                else
                {
                    if (intNoOfDecimals >= 0)
                    {
                        return String.Format(strDecimals, value);
                    }
                    else
                    {
                        return value.ToString();
                    }
                }
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        ///  NotSupportedException will be thrown as only OneWay bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}