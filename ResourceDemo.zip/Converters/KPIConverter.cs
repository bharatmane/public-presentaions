﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converts a KPI enum to its corresponding brush.
    /// </summary>
    public class KPIConverter : IValueConverter
    {
        /// <summary>
        /// The brush used to convert KPI.Normal
        /// </summary>
        public Brush NormalBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Good
        /// </summary>
        public Brush GoodBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Better
        /// </summary>
        public Brush BetterBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Best
        /// </summary>
        public Brush BestBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Excellent
        /// </summary>
        public Brush ExcellentBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.PreWarning
        /// </summary>
        public Brush PreWarningBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Warning
        /// </summary>
        public Brush WarningBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Critical  
        /// </summary>
        public Brush CrticalBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Poor
        /// </summary>
        public Brush PoorBrush { get; set; }


        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a KPI enum value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a Brush correspoding to the passed in KPI</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var kpi = (KPI)value;
            switch (kpi)
            {
                case KPI.Normal:
                    return NormalBrush;
                case KPI.Good:
                    return GoodBrush;
                case KPI.Better:
                    return BetterBrush;
                case KPI.Best:
                    return BestBrush;
                case KPI.Excellent:
                    return ExcellentBrush;
                case KPI.PreWarning:
                    return PreWarningBrush;
                case KPI.Warning:
                    return WarningBrush;
                case KPI.Critical:
                    return CrticalBrush;
                case KPI.Poor:
                    return PoorBrush;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
