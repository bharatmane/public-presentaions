﻿namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A set of common value converters used throughout the apps modules.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
