﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Returns a substring of the passed in string.
    /// The amount of characters to return are specified by 
    /// the <see cref="CharacterCount"/> property.
    /// </summary>
    /// <example>
    /// The following example displays the first letter of the propery OrderType.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:SubStringConverter x:Key="SubStringConverter" CharacterCount="1" />
    /// 
    /// <TextBlock Text="{Binding OrderType, Converter={StaticResource SubStringConverter}}" />
    /// ]]>
    /// </code>
    /// </example>
    public class SubStringConverter : IValueConverter   
    {
        /// <summary>
        /// The amount of characters to return in the substring. The default value is 1.
        /// </summary>
        public int CharacterCount { get; set; }

        /// <summary>
        /// The default constructor which sets the <see cref="CharacterCount"/> to 1.
        /// </summary>
        public SubStringConverter()
        {
            CharacterCount = 1;
        }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects an object and calls ToString()</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a Substring of the value based on the <see cref="CharacterCount"/> property.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                var text = value.ToString();

                if (!string.IsNullOrWhiteSpace(text) && text.Length >= CharacterCount)
                {
                    return text.Substring(0, CharacterCount);
                }
            }

            return value;
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
