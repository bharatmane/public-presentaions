﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Data;


namespace VShips.Framework.Resource.Converters
{

    /// <summary>
    /// Converter to get list of multiple command parameter
    /// </summary>
    /// <seealso cref="System.Windows.Data.IMultiValueConverter" />
    /// <example>
    /// The following example will return list of object as single object 
    /// While using this parameter, this single object can be casted in original list of object. 
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <telerik:RadButton x:Name="ButtonChangePassword"  
    ///                   Command="{Binding ChangePasswordCommand}"   
    ///                     Content="Change Password" 
    ///                    IsDefault="True">
    ///                    <telerik:RadButton.CommandParameter>
    ///                        <MultiBinding Converter = "{StaticResource MultiBindingListConverter}" >
    ///                            < Binding ElementName="OldPasswordBox"/>
    ///                            < Binding ElementName = "NewPasswordBox" />
    ///                            < Binding ElementName="ConfirmPasswordBox"/>
    ///                        </MultiBinding>
    ///                    </telerik:RadButton.CommandParameter>
    ///  </telerik:RadButton>
    ///  ]]>
    /// </code>
    /// </example> 

    public class MultiBindingListConverter : IMultiValueConverter
    {
        /// <summary>
        /// Converts source values to a value for the binding target. The data binding engine calls this method when it propagates the values from source bindings to the binding target.
        /// </summary>
        /// <param name="values">The array of values that the source bindings in the <see cref="T:System.Windows.Data.MultiBinding" /> produces. The value <see cref="F:System.Windows.DependencyProperty.UnsetValue" /> indicates that the source binding has no value to provide for conversion.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value.If the method returns null, the valid null value is used.A return value of <see cref="T:System.Windows.DependencyProperty" />.<see cref="F:System.Windows.DependencyProperty.UnsetValue" /> indicates that the converter did not produce a value, and that the binding will use the <see cref="P:System.Windows.Data.BindingBase.FallbackValue" /> if it is available, or else will use the default value.A return value of <see cref="T:System.Windows.Data.Binding" />.<see cref="F:System.Windows.Data.Binding.DoNothing" /> indicates that the binding does not transfer the value or use the <see cref="P:System.Windows.Data.BindingBase.FallbackValue" /> or the default value.
        /// </returns>
        object IMultiValueConverter.Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            List<object> list = new List<object>();
            if (values != null && values.Any())
            {
                foreach (var value in values)
                {
                    if (value != null)
                    {
                        list.Add(value);
                    }
                }
            }
            return (object)list;
        }

        /// <summary>
        /// Converts a binding target value to the source binding values.
        /// </summary>
        /// <param name="value">The value that the binding target produces.</param>
        /// <param name="targetTypes">The array of types to convert to. The array length indicates the number and types of values that are suggested for the method to return.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// An array of values that have been converted from the target value back to the source values.
        /// </returns>
        /// <exception cref="System.NotImplementedException"></exception>
        object[] IMultiValueConverter.ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
