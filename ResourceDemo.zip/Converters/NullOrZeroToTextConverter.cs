﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A converter class to convert a Null or Zero value to a Text value. 
    /// Note: Pass the Text value as parameter from xaml file while using converter.
    /// </summary>
    /// <seealso cref="IValueConverter" />
    public class NullOrZeroToTextConverter : IValueConverter
    {
        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A text value. 
        /// "None" if no parameter passed else passed parameter.
        /// </returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string result;
            if(parameter != null && parameter is string)
            {
                result = parameter as string;
            }
            else
            {
                result = "None";
            }
            return value == null || String.IsNullOrWhiteSpace(value.ToString()) || value.ToString() == "0" ? result : value.ToString();
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
