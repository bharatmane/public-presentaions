﻿using System;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// The start of day converter.
    /// </summary>
    public class StartOfDayConverter : IValueConverter
    {
        /// <summary>
        /// To be only used when selectable start date is today's date.
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <example>
        /// The following example uses the StartOfDayConverter where selectablestartdate is set to today's date for DatePicker."
        /// <code lang="XAML" title="XAML">
        /// <![CDATA[<telerik:RadDatePicker x:Name="DatePickerSupplierInvoiceDate" 
        ///                        SelectableDateStart="{Binding Source={x:Static sys:DateTime.Now},Converter={StaticResource StartOfDayConverter}}"
        ///                        SelectedValue="{Binding VesselOrderCreateInvoiceManuallyView.InvoiceDetails.InvoiceDate, Mode=TwoWay, ValidatesOnDataErrors=True, UpdateSourceTrigger=PropertyChanged}"
        ///                        InputMode="DatePicker"
        ///                        TodayButtonVisibility="Visible"/>]
        /// </code>
        /// </example>
        public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                DateTime date = (DateTime) value;
                return new DateTime(
                    date.Year,
                    date.Month,
                    date.Day,
                    00, 00, 00, 0000);
            }
            return null;
        }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value that is produced by the binding target.</param>
        /// <param name="targetType">The type to convert to.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new System.NotImplementedException();
        }
    }
}
