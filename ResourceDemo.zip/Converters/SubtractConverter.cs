﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// <para>
    /// A <see cref="IMultiValueConverter"/> that takes multiple numbers and subtracts
    /// each number from the result of the previous subtraction.
    /// </para>
    /// </summary>
    /// <example>
    /// The following example creates a <see cref="System.Windows.Controls.TextBlock"/> control
    /// and sets its Text property to multibinding which passes in the values of the properties
    /// Actual and Accrual to the SumConverter. If Actual = 10000 and 
    /// Accrual = 2000 the resulting text will be 8000
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:SubtractConverter x:Key="SubtractConverter" /> 
    /// 
    /// <TextBlock>
    ///     <TextBlock.Text>
    ///         <MultiBinding Converter="{StaticResource SubtractConverter}">
    ///             <Binding Path="Actual" />
    ///             <Binding Path="Accrual" />
    ///         </MultiBinding>
    ///     </TextBlock.Text>
    /// </TextBlock>]]>
    /// </code>
    /// </example>
    public class SubtractConverter : IMultiValueConverter
    {
        /// <summary>
        /// Executes the value conversion. Subtracts each number passed to the converter
        /// starting by subtracting the first number from the second and so on...
        /// </summary>
        /// <param name="values">Expects an array of values that can be parsed as doubles.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>A sum of all the values passed.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var total = 0d;
            var items = values.ToList();
            if (items.Count >= 2)
            {
                total = double.Parse(items.First().ToString());
                items.RemoveAt(0);
                total = items.Aggregate(total, (current, value) => current - double.Parse(value.ToString()));
            }

            //if you want to show Total Amount in proper Format,that time you pass parameters with subtractconverter.
            if (parameter != null)
            {
                var currencyFormatter = new CurrencyFormatConverter();
                return currencyFormatter.Convert(total, targetType, parameter, culture).ToString();
            }
            return total.ToString(CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWay bindings are only supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetTypes">The types of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
