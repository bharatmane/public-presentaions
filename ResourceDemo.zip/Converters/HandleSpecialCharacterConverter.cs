﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A generic converter which takes a string value
    /// and remove special character from the string.
    /// </summary>
    /// <example>
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:HandleSpecialCharacterConverter x:Key="HandleSpecialCharacterConverter" />
    ///  <TextBlock x:Name="textblock_supplierAddress"
    ///             Text="{Binding CmpAddr,Converter={StaticResource HandleSpecialCharacterConverter},TargetNullValue='Unknown', FallbackValue=''}" />
    /// ]]>
    /// </code>
    /// </example>
    public class HandleSpecialCharacterConverter : IValueConverter
    {
        /// <summary>
        /// Trim special character (like : \r\n) using the converter.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <example>
        /// The following example will return the AccentMain resource
        /// <code lang="XAML" title="XAML">
        /// <![CDATA[
        /// <converters:HandleSpecialCharacterConverter x:Key="HandleSpecialCharacterConverter"/>
        ///  <TextBlock x:Name="textblock_supplierAddress"
        ///             Text="{Binding CmpAddr,Converter={StaticResource HandleSpecialCharacterConverter},TargetNullValue='Unknown', FallbackValue=''}" />
        /// ]]>                    
        /// </code>
        /// </example>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value != null ? value.ToString().Replace("\r\n", " ").Trim() : "";
        }

        /// <summary>
        /// NotSupportedException will be thrown as only OneWayToSource bindings are supported.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>NotSupportedException</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
