﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A <see cref="IMultiValueConverter"/> that takes multiple numbers and returns the average as string.
    /// </summary>
    public class AverageConverter : IMultiValueConverter
    {
        /// <summary>
        /// Executes the value conversion .
        /// </summary>
        /// <param name="values">Expects an array of values that can be parsed as doubles.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns the average of all values passed.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double total = values.Sum(val => val != null ? double.Parse(val.ToString()) : 0);
            int valuesCount = values.Count();

            double average = total / valuesCount;
            return average.ToString(CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetTypes">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
