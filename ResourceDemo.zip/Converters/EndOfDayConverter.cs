﻿using System;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// Converter to get the date as end of the day.
    /// </summary>
    /// <seealso cref="System.Windows.Data.IValueConverter" />
    public class EndOfDayConverter : IValueConverter
    {
        /// <summary>
        /// To be only used for enabling the Today's button in datepicker where future dates are blocked
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <example>
        /// The following example uses the EndofDayConverter to set today button visible for DatePicker. While we are using SelectableDateEnd="{Binding Source={x:Static sys:DateTime.Now}}"
        /// then Today button in Datepicker controls calender is disable to get that enable we are using this converter.
        /// <code lang="XAML" title="XAML">
        /// <![CDATA[<telerik:RadDatePicker x:Name="DatePickerSupplierInvoiceDate" 
        ///                        SelectableDateEnd="{Binding Source={x:Static sys:DateTime.Now},Converter={StaticResource EndOfDayConverter}}"
        ///                        SelectedValue="{Binding VesselOrderCreateInvoiceManuallyView.InvoiceDetails.InvoiceDate, Mode=TwoWay, ValidatesOnDataErrors=True, UpdateSourceTrigger=PropertyChanged}"
        ///                        InputMode="DatePicker"
        ///                        TodayButtonVisibility="Visible"/>]
        /// </code>
        /// </example>
        public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null) 
            {
                DateTime date = (DateTime)value;
                return new DateTime(
                 date.Year,
                 date.Month,
                 date.Day,
                 23, 59, 59, 999);
            }
            return value;
        }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value that is produced by the binding target.</param>
        /// <param name="targetType">The type to convert to.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                DateTime date = (DateTime)value;
                return new DateTime(
                 date.Year,
                 date.Month,
                 date.Day,
                 23, 59, 59, 999);
            }
            return value;
        }
    }
}
