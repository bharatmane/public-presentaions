﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A generic converter which takes a bool value
    /// and returns the values represented by its related
    /// <see cref="TrueValue"/> and <see cref="FalseValue"/> properties.
    /// </summary>
    /// <example>
    /// The following example will return the AccentMain resource if the value 
    /// passed to the converter is true or the InvertedLow resource if the value
    /// is false.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    /// <converters:BoolConverter x:Key="BoolToSupplierColourConverter"
    ///                           TrueValue="{StaticResource AccentMain}"
    ///                           FalseValue="{StaticResource InvertedLow}" />]]>
    /// </code>
    /// </example>
    public class BoolConverter : IValueConverter
    {
        /// <summary>
        /// The object returned if the value was true
        /// </summary>
        public object TrueValue { get; set; }

        /// <summary>
        /// The object returned if the value was false
        /// </summary>
        public object FalseValue { get; set; }

        /// <summary>
        /// The object returned if the value was null
        /// </summary>
        public object NullValue { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a bool value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns><see cref="TrueValue"/> if the value is True, <see cref="FalseValue"/> is the value is False.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value ==null)
            {
                return  NullValue ?? "";
            }
            bool b;
            bool.TryParse(value.ToString(),out b);
            return b ? TrueValue : FalseValue;
        }

        /// <summary>
        /// Reverses the value conversion
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>True if the value equals <see cref="TrueValue"/>, False if the value equals <see cref="FalseValue"/></returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Equals(value, TrueValue);
        }
    }
}
