﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Converters
{
    /// <summary>
    /// A Converter takes a the 2 numbers and a condition.
    /// If condition passed then converter will return <see cref="HighlightBrush"/>.
    /// else then converter will return <see cref="NormalBrush"/>.
    /// </summary>
    /// <example>
    /// The following example uses the NumericToKPIConverter to set the foreground of the number
    /// Pivot number is the central number base on which the condition is checked.
    /// <code lang="XAML" title="XAML">
    /// <![CDATA[
    ///<converters:NumericToKPIConverter x:Key="NegativeAmountToKPIConverter"
    ///                                  HighlightBrush="{StaticResource BrushRed}"
    ///                                  NormalBrush="{StaticResource BrushForeground}"
    ///                                  Operator="LessThan"
    ///                                  PivotNumber="0"/>
    /// 
    /// <TextBlock x:Name="TextBlockInvoiceAmount"
    ///            Foreground="{Binding InvoiceAmount, Converter={StaticResource  NegativeAmountToKPIConverter}}"
    ///            Text="{Binding InvoiceAmount}">
    /// </TextBlock>
    /// ]]>
    /// </code>
    /// </example>
    public class NumericToKPIConverter : IValueConverter
    {
        /// <summary>
        /// Gets or sets the pivot number.
        /// </summary>
        /// <value>
        /// The pivot number.
        /// </value>
        public decimal PivotNumber { get; set; }


        /// <summary>
        /// Gets or sets the operator.
        /// </summary>
        /// <value>
        /// The operator.
        /// </value>
        public ComparisonOperator Operator { get; set; }

        /// <summary>
        /// Gets or sets the highlight brush.
        /// </summary>
        /// <value>
        /// The highlight brush.
        /// </value>
        public Brush HighlightBrush { get; set; }

        /// <summary>
        /// Gets or sets the normal brush.
        /// </summary>
        /// <value>
        /// The normal brush.
        /// </value>
        public Brush NormalBrush { get; set; }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Brush brush = null;
            var decimalValue = (decimal?)(value);//value for comparision
            if (decimalValue.HasValue)
            {
                var comparisonOperator = Operator;
                switch (comparisonOperator)
                {
                    case ComparisonOperator.GreaterThan: 
                        brush = decimalValue > PivotNumber ? HighlightBrush : NormalBrush;
                        break;
                    case ComparisonOperator.GreaterThanOrEqualsTo:
                        brush = decimalValue >= PivotNumber ? HighlightBrush : NormalBrush;
                        break;
                    case ComparisonOperator.LessThan: 
                        brush = decimalValue < PivotNumber ? HighlightBrush : NormalBrush;
                        break;
                    case ComparisonOperator.LessThanOrEqualsTo:
                        brush = decimalValue <= PivotNumber ? HighlightBrush : NormalBrush;
                        break;
                    case ComparisonOperator.Equals:
                        brush = decimalValue != PivotNumber ? HighlightBrush : NormalBrush;
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }

            return brush ?? NormalBrush;
        }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value that is produced by the binding target.</param>
        /// <param name="targetType">The type to convert to.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <exception cref="System.NotImplementedException">Only one way bindings are supported with this converter</exception>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException("Only one way bindings are supported with this converter");
        }
    }
}
