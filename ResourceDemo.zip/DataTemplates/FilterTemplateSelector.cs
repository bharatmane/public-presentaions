﻿using System;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// Selects a template based on the filter type.
    /// </summary>
    public class FilterTemplateSelector : DataTemplateSelector
    {
        /// <summary>
        /// A datatemplate defining how to display a group of tree filters.
        /// </summary>
        public DataTemplate TreeTemplate { get; set; }

        /// <summary>
        /// A datatemplate defining how to display a checkable filter.
        /// </summary>
        public DataTemplate CheckableTemplate { get; set; }

        /// <summary>
        /// A datatemplate defining how to display a group of checkable filters.
        /// </summary>
        public DataTemplate CheckableGroupTemplate { get; set; }

        /// <summary>
        /// A datatemplate to display a seperator.
        /// </summary>
        public DataTemplate SeperatorTemplate { get; set; }

        /// <summary>
        /// Returns the corrent template based on the filter type.
        /// </summary>
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var filter = item as IFilterItem;
            if (filter == null)
            {
                throw new NotSupportedException("Object must derive from IFilterItem");
            }
            switch (filter.FilterType)
            {
                case FilterTypes.Tree:
                    return TreeTemplate;
                case FilterTypes.Checkable:
                    return CheckableTemplate;
                case FilterTypes.CheckableGroup:
                    return CheckableGroupTemplate;
                case FilterTypes.Seperator:
                    return SeperatorTemplate;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
