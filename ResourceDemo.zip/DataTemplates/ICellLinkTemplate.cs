﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// 
    /// </summary>
    public interface ICellLinkTemplate
    {
        /// <summary>
        /// Gets a value indicating whether this instance can show link.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can show link; otherwise, <c>false</c>.
        /// </value>
        bool CanShowLink { get; }
    }
}
