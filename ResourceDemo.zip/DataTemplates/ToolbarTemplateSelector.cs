﻿using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.ViewModel;
using VShips.Framework.Common.ViewModel.Menu;

namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// A template selector used to display a template for particular menuitem viewmodel types.
    /// </summary>
    public class ToolbarTemplateSelector : DataTemplateSelector
    {
        /// <summary>
        /// Represents a Button menuitem.
        /// </summary>
        public DataTemplate Button { get; set; }

        /// <summary>
        /// Represents a ToggleButton menuitem.
        /// </summary>
        public DataTemplate ToggleButton { get; set; }

        /// <summary>
        /// Represents a DropDownButton menuitem.
        /// </summary>
        public DataTemplate DropDownButton { get; set; }

        /// <summary>
        /// Represents a CheckBox menuitem.
        /// </summary>
        public DataTemplate CheckBox { get; set; }

        /// <summary>
        /// Represents a RadioButton menuitem.
        /// </summary>
        public DataTemplate RadioButton { get; set; }

        /// <summary>
        /// Represents a ComboBox menuitem.
        /// </summary>
        public DataTemplate ComboBox { get; set; }

        /// <summary>
        /// Represents a multiselect menuitem.
        /// </summary>
        public DataTemplate MultiSelect { get; set; }

        /// <summary>
        /// Represents a date picker menuitem.
        /// </summary>
        public DataTemplate DatePicker { get; set; }

        public DataTemplate TextBox { get; set; }

        /// <summary>
        /// Represents a Seperator menuitem.
        /// </summary>
        public DataTemplate Seperator { get; set; }

        /// <summary>
        /// Represents a lookup menuitem.
        /// </summary>
        public DataTemplate Lookup { get; set; }

        /// <summary>
        /// Gets or sets the tree drop down.
        /// </summary>
        /// <value>
        /// The tree drop down.
        /// </value>
        public DataTemplate TreeDropDown { get; set; }

        /// <summary>
        /// Selects the template based on the type of menuitem used.
        /// A default button template will be used if one is not found.
        /// </summary>
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (item is PathButtonTreeDropDownFilterViewModel)
            {
                return TreeDropDown;
            }

            if (item is MenuItemDropDownButton)
            {
                return DropDownButton;
            }

            if (item is MenuItemToggleButton)
            {
                return ToggleButton;
            }

            if (item is MenuItemRadio)
            {
                return RadioButton;
            }

            if (item is MenuItemCheckbox)
            {
                return CheckBox;
            }

            if (item is MenuItemCombobox)
            {
                return ComboBox;
            }

            if (item is MenuItemDatePicker)
            {
                return DatePicker;
            }

            if (item is MenuItemTextBox)
            {
                return TextBox;
            }

            if (item is MenuItemMultiSelection)
            {
                return MultiSelect;
            }

            if (item is MenuItemSeperator)
            {
                return Seperator;
            }

            return Button;
        }
    }
}
