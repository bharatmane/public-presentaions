﻿
namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// The Interface of Row BackColor Template
    /// </summary>
    public interface IRowBackColorTemplate
    {
        /// <summary>
        /// Gets a value indicating whether this instance can show yellow color.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can show yellow color; otherwise, <c>false</c>.
        /// </value>
        bool CanShowYellowColor { get; }

        /// <summary>
        /// Gets a value indicating whether this instance can show red color.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can show red color; otherwise, <c>false</c>.
        /// </value>
        bool CanShowRedColor { get; }
    }
}
