﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// To select a template depending on journal type
    /// </summary>
    /// <seealso cref="System.Windows.Controls.DataTemplateSelector" />
    public class OrderNumberCellTemplateSelector: DataTemplateSelector
    {
        /// <summary>
        /// When overridden in a derived class, returns a <see cref="T:System.Windows.DataTemplate" /> based on custom logic.
        /// </summary>
        /// <param name="item">The data object for which to select the template.</param>
        /// <param name="container">The data-bound object.</param>
        /// <returns>
        /// Returns a <see cref="T:System.Windows.DataTemplate" /> or null. The default value is null.
        /// </returns>
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            ICellLinkTemplate viewModel = (ICellLinkTemplate)item;
            if (viewModel != null && viewModel.CanShowLink)
            {
                return LinkCellTemplate;
            }
            else
            {
                return TextCelTemplate;
            }
        }


        /// <summary>
        /// Gets or sets the link cell template.
        /// </summary>
        /// <value>
        /// The link cell template.
        /// </value>
        public DataTemplate LinkCellTemplate { get; set; }

        /// <summary>
        /// Gets or sets the text cel template.
        /// </summary>
        /// <value>
        /// The text cel template.
        /// </value>
        public DataTemplate TextCelTemplate { get; set; }
    }
}
