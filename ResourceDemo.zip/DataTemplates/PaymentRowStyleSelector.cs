﻿using System.Windows;
using System.Windows.Controls;

namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// The Payment Row Style Selector
    /// </summary>
    /// <seealso cref="System.Windows.Controls.StyleSelector" />
    public class PaymentRowStyleSelector : StyleSelector
    {
        /// <summary>
        /// When overridden in a derived class, returns a <see cref="T:System.Windows.Style" /> based on custom logic.
        /// </summary>
        /// <param name="item">The content.</param>
        /// <param name="container">The element to which the style will be applied.</param>
        /// <returns>
        /// Returns an application-specific style to apply; otherwise, null.
        /// </returns>
        public override Style SelectStyle(object item, DependencyObject container)
        {
            IRowBackColorTemplate viewModel = (IRowBackColorTemplate)item;
            if (viewModel != null && viewModel.CanShowYellowColor)
            {
                return YellowColorStyle;
            }
            else if (viewModel != null && viewModel.CanShowRedColor)
            {
                return RedColorStyle;
            }
            return null;
        }

        /// <summary>
        /// Gets or sets the yellow color style.
        /// </summary>
        /// <value>
        /// The yellow color style.
        /// </value>
        public Style YellowColorStyle { get; set; }

        /// <summary>
        /// Gets or sets the red color style.
        /// </summary>
        /// <value>
        /// The red color style.
        /// </value>
        public Style RedColorStyle { get; set; }
    }
}
