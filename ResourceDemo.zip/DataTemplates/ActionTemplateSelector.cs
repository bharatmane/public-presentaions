﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.DataTemplates
{
    /// <summary>
    /// Selects a template based on the action type.
    /// </summary>
    public class ActionTemplateSelector : DataTemplateSelector
    {
        /// <summary>
        /// A template displaying a button.
        /// </summary>
        public DataTemplate ButtonTemplate { get; set; }

        /// <summary>
        /// A template displaying a collection of actions.
        /// </summary>
        public DataTemplate CollectionTemplate { get; set; }

        /// <summary>
        /// Selects the template based on the values in IMenuItem.
        /// </summary>
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var action = item as IMenuItem;
            if (action != null && action.Items != null && action.Items.Any())
            {
                return CollectionTemplate;
            }

            return ButtonTemplate;
        }
    }

}
