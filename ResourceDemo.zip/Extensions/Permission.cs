﻿using System;
using System.Windows.Markup;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.Extensions
{
    /// <summary>
    /// A markup extension that returns a <see cref="ModuleControlPermission"/> from the module name and control Id.
    /// </summary>
    [MarkupExtensionReturnType(typeof(ModuleControlPermission))]
    public class Permission : MarkupExtension
    {
        /// <summary>
        /// The name of the module that contains the permission.
        /// </summary>
        [ConstructorArgument("moduleName")] 
        public string ModuleName { get; set; }

        /// <summary>
        /// The Id of the control.
        /// </summary>
        [ConstructorArgument("controlId")]  
        public string ControlId { get; set; }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public Permission()
        {
        }

        /// <summary>
        /// Constructor that accepts the module name and control Id.
        /// </summary>
        public Permission(string moduleName, string controlId)
        {
            ModuleName = moduleName;
            ControlId = controlId;
        }

        /// <summary>
        /// Returns a <see cref="ModuleControlPermission"/> based on the <see cref="ModuleName"/> and <see cref="ControlId"/> properties.
        /// </summary>
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return new ModuleControlPermission {ModuleName = ModuleName, ControlId = ControlId};
        }
    }
}
