﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace System

{
    /// <summary>
    /// DateTime Extensions class
    /// </summary>
    public static class DateTimeExtensions
    {
        /// <summary>
        /// Get the Start Of Week
        /// </summary>
        /// <param name="dt">this DateTime</param>
        /// <param name="startOfWeek">the Start of Week</param>
        /// <returns></returns>
        public static DateTime StartOfWeek(this DateTime dt, DayOfWeek startOfWeek)
        {
            int diff = (7 + (dt.DayOfWeek - startOfWeek)) % 7;
            return dt.AddDays(-1 * diff).Date;
        }
    }
}
