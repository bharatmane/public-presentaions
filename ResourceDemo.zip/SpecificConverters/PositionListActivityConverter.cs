﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// Converts the value returned from the data service to the full display name for a sea passage.
    /// </summary>
    public class PositionListActivityConverter : IMultiValueConverter
    {

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="values">Expects string and bool values</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The full name of the position list type for a sea passage.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values != null && values.Length == 3)
            {
                string activity = !string.IsNullOrEmpty(values[0] as string) ? values[0].ToString() : string.Empty;
                bool isSeaPassage = values[1] is bool ? (bool)values[1] : false;
                bool isLoaded = values[2] is bool ? (bool)values[2] : false;

                if (isSeaPassage)
                {
                    return isLoaded == true ? "SEA PASSAGE LOADED" : "SEA PASSAGE BALLAST";
                }
                else
                {
                    return activity;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetTypes">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
