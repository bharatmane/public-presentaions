﻿using System;
using System.Globalization;
using System.Windows.Data;
using VShips.DataServices.Shared.Enumerations.VoyageReporting;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// Returns the voyage status text using the voyage start and end dates
    /// </summary>
    public class VoyageStatusConverter : IMultiValueConverter
    {
        /// <summary>
        /// Executes the value conversion
        /// </summary>
        /// <param name="values">The voyage start and end dates to use to determine the status</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Text describing the status of the voyage.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values != null && values.Length == 1)
            {
                var statusAsObject = values[0];

                VoyageStatus status = statusAsObject is VoyageStatus ? (VoyageStatus)statusAsObject : VoyageStatus.Unknown;

                switch (status)
                {
                    case VoyageStatus.Completed:
                        return "Completed";
                    case VoyageStatus.InPort:
                        return "In Port";
                    case VoyageStatus.AtSea:
                        return "At Sea";
                    case VoyageStatus.Planned:
                        return "Planned";
                    default:
                        return string.Empty;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetTypes">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
