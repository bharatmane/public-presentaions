﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// Generates a description for the port using the port name and the country code 
    /// </summary>
    public class VoyageActivityListPortDescriptionConverter : IMultiValueConverter
    {
        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="values">Expects string and bool values</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The full name of the position list type for a sea passage.</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values != null && values.Length == 2)
            {
                string portName = !string.IsNullOrEmpty(values[0] as string) ? values[0].ToString() : string.Empty;
                string portCountryCode = !string.IsNullOrEmpty(values[1] as string) ? values[1].ToString() : string.Empty;

                if (string.IsNullOrEmpty(portName))
                {
                    return string.Empty;
                }

                if (string.IsNullOrEmpty(portCountryCode))
                {
                    return portName;
                }

                return string.Format("{0}, {1}", portName, portCountryCode);
            }

            return string.Empty;
        }

        /// <summary>
        /// Reverse conversion is not supported
        /// </summary>
        /// <param name="value">The source values</param>
        /// <param name="targetTypes">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns><exception cref="System.NotSupportedException"></exception></returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
