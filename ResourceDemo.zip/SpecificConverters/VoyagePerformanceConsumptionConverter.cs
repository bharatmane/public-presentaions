﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// A multiconverter which takes a number and a charter
    /// requirement, if the number is greater than the charter requirements
    /// it uses the property <see cref="WarningBrush"/>
    /// Otherwise it will return the <see cref="NormalBrush"/>.
    /// </summary>
    public class VoyagePerformanceConsumptionConverter : IMultiValueConverter
    {
        /// <summary>
        ///
        /// </summary>
        public Brush GoodBrush { get; set; }

        /// <summary>
        /// The brush used to display when value is under the charter requirements
        /// </summary>
        public Brush NormalBrush { get; set; }

        /// <summary>
        /// The brush used to display when value is over the charter requirements
        /// </summary>
        public Brush WarningBrush { get; set; }

        /// <summary>
        /// Executes the value conversion
        /// </summary>
        /// <param name="values">Expects a KPI enum value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a Brush correspoding to whether the report value is within the charter requirements</returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (!(values[0] == DependencyProperty.UnsetValue) && !(values[1] == DependencyProperty.UnsetValue))
            {
                float charterRequirementValue = (float)values[0];
                float actualValue = (float)values[1];

                if (actualValue < charterRequirementValue)
                {
                    return WarningBrush;
                }
            }

            if (parameter != null)
            {
                return GoodBrush;
            }

            return NormalBrush;
        }

        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetTypes">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
