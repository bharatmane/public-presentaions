﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.DataServices.Shared.Enumerations.Purchasing;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// Converts a PurchaseOrderPriority enum to its corresponding brush.
    /// </summary>
    public class OrderPriorityToKPIConverter : IValueConverter
    {
        /// <summary>
        /// The brush used to convert KPI.Good
        /// </summary>
        public Brush GoodBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Warning
        /// </summary>
        public Brush WarningBrush { get; set; }

        /// <summary>
        /// The brush used to convert KPI.Critical
        /// </summary>
        public Brush CrticalBrush { get; set; }

        /// <summary>
        /// Executes the value conversion 
        /// </summary>
        /// <param name="value">Expects a KPI enum value</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Returns a Brush correspoding to the passed in KPI</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var priority = (PurchaseOrderPriority)value;
            switch (priority)
            {
                case PurchaseOrderPriority.Local:
                    return GoodBrush;
                case PurchaseOrderPriority.Normal:
                    return GoodBrush;
                case PurchaseOrderPriority.FastTrack:
                    return WarningBrush;
                case PurchaseOrderPriority.Urgent:
                    return CrticalBrush;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetType">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
    }
}
