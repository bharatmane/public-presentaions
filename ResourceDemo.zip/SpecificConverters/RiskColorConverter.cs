﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Resource.SpecificConverters
{
    public class RiskColorConverter : IValueConverter
    {
        public Brush NormalBrush {get; set;}
        /// <summary>
        ///
        /// </summary>
        public Brush MinorBrush { get; set; }

        /// <summary>
        /// The brush used to display when value is Moderat
        /// </summary>
        public Brush ModerateBrush { get; set; }

        /// <summary>
        /// The brush used to display when value is severe
        /// </summary>
        public Brush SevereBrush { get; set; }

        /// <summary>
        /// The brush used to display when value is Major
        /// </summary>
        public Brush MajorBrush { get; set; }

        /// <summary>
        /// The brush used to display when value Critical
        /// </summary>
        public Brush CriticalBrush { get; set; }

        /// <summary>
        /// The brush used to display when value is Disastrous
        /// </summary>
        public Brush DisastrousBrush { get; set; }

        /// <summary>
        /// Executes the value conversion
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            
            if (value is int)
            {
                var risk = (RiskSeverity)value;
                switch (risk)
                {
                    case RiskSeverity.Minor:
                        return MinorBrush;
                    case RiskSeverity.Moderate:
                        return ModerateBrush;
                    case RiskSeverity.Severe:
                        return SevereBrush;
                    case RiskSeverity.Major:
                        return MajorBrush;
                    case RiskSeverity.Critical:
                        return CriticalBrush;
                    case RiskSeverity.Disastrous:
                        return DisastrousBrush;
                    default:
                        throw new ArgumentOutOfRangeException();
                    
                }

               
            }
          

                return NormalBrush;
            }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter");
        }
        }

    }

