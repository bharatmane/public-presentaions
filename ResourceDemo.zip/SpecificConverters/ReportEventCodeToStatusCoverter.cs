﻿using System;
using System.Globalization;
using System.Windows.Data;
using VShips.Contracts.Custom.VoyageReporting;
using VShips.DataServices.Shared.Enumerations.PositionList;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// Converts the value of the position list status enum to its corresponding display status.
    /// </summary>
    public class ReportEventCodeToStatusCoverter : IValueConverter
    {
        /// <summary>
        /// Executes the value conversion
        /// </summary>
        /// <param name="value">Expects a PositionListEventStatus enum</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>The status of a position list activity report</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var reportEvent = (PositionListPreviewEvent)value;

            switch (reportEvent.Status)
            {
                case PositionListEventStatus.VoyageArrived:
                    return reportEvent.IsEstimatedEventDate ? "ETA" : "E.O.S.P.";
                case PositionListEventStatus.VoyageDeparted:
                    return reportEvent.IsEstimatedEventDate ? "ETD" : "F.A.O.P.";
                case PositionListEventStatus.BerthArrived:
                    return reportEvent.IsEstimatedEventDate ? "ETA" : "BTHD";
                case PositionListEventStatus.BerthDeparted:
                    return reportEvent.IsEstimatedEventDate ? "ETD" : "UNBTHD";
                default:
                    throw new ArgumentOutOfRangeException();
            }

        }

        /// <summary>
        /// Converts the back.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="targetType">Type of the target.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="culture">The culture.</param>
        /// <returns>NotSupportedException</returns>
        /// <exception cref="System.NotSupportedException">Only one way bindings are supported with this converter</exception>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
