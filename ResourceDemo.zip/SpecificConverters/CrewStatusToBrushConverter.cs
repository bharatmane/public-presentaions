﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using VShips.DataServices.Shared.Enumerations;
using VShips.DataServices.Shared.Enumerations.Crew;
using VShips.Framework.Resource.Helpers;
using Constants = VShips.Framework.Common.ModuleNavigation.Crew.Constants;

namespace VShips.Framework.Resource.SpecificConverters
{
    /// <summary>
    /// This converter is used to retun a brush based on the crew status type.
    /// </summary>
    /// <seealso cref="System.Windows.Data.IValueConverter" />
    public class CrewStatusToBrushConverter : IValueConverter
    {
        #region Dictionary

        /// <summary>
        /// The brush by status identifier
        /// </summary>
        private Dictionary<string, Brush> _brushByStatusId = null;

        /// <summary>
        /// Gets the brush by status identifier.
        /// </summary>
        /// <value>
        /// The brush by status identifier.
        /// </value>
        private Dictionary<string, Brush> BrushByStatusId { get { return _brushByStatusId ?? (_brushByStatusId = GetBuildDictionary()); } }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the on board brush.
        /// </summary>
        /// <value>
        /// The on board brush.
        /// </value>
        public Brush OnboardBrush { get; set; }

        /// <summary>
        /// Gets or sets the travel brush.
        /// </summary>
        /// <value>
        /// The travel brush.
        /// </value>
        public Brush TravelBrush { get; set; }

        /// <summary>
        /// Gets or sets the training brush.
        /// </summary>
        /// <value>
        /// The training brush.
        /// </value>
        public Brush TrainingBrush { get; set; }

        /// <summary>
        /// Gets or sets the major overdue brush.
        /// </summary>
        /// <value>
        /// The major overdue brush.
        /// </value>
        public Brush MajorOverdueBrush { get; set; }

        /// <summary>
        /// Gets or sets the minor overdue brush.
        /// </summary>
        /// <value>
        /// The minor overdue brush.
        /// </value>
        public Brush MinorOverdueBrush { get; set; }

        /// <summary>
        /// Gets or sets the approved brush.
        /// </summary>
        /// <value>
        /// The approved brush.
        /// </value>
        public Brush ApprovedBrush { get; set; }

        /// <summary>
        /// Gets or sets the cancelled brush.
        /// </summary>
        /// <value>
        /// The cancelled brush.
        /// </value>
        public Brush CancelledBrush { get; set; }

        /// <summary>
        /// Gets or sets the joined brush.
        /// </summary>
        /// <value>
        /// The joined brush.
        /// </value>
        public Brush JoinedBrush { get; set; }

        /// <summary>
        /// Gets or sets the planned brush.
        /// </summary>
        /// <value>
        /// The planned brush.
        /// </value>
        public Brush PlannedBrush { get; set; }

        /// <summary>
        /// Gets or sets the proposed brush.
        /// </summary>
        /// <value>
        /// The proposed brush.
        /// </value>
        public Brush ProposedBrush { get; set; }

        /// <summary>
        /// Gets or sets the ready brush.
        /// </summary>
        /// <value>
        /// The ready brush.
        /// </value>
        public Brush ReadyBrush { get; set; }

        /// <summary>
        /// Gets or sets the released brush.
        /// </summary>
        /// <value>
        /// The released brush.
        /// </value>
        public Brush ReleasedBrush { get; set; }

        /// <summary>
        /// Gets or sets the rejected brush.
        /// </summary>
        /// <value>
        /// The rejected brush.
        /// </value>
        public Brush RejectedBrush { get; set; }

        /// <summary>
        /// Gets or sets the default brush.
        /// </summary>
        /// <value>
        /// The default brush.
        /// </value>
        public Brush DefaultBrush { get; set; }

        /// <summary>
        /// Gets or sets the overlap brush.
        /// </summary>
        /// <value>
        /// The overlap brush.
        /// </value>
        public Brush OverlapBrush { get; set; }

        /// <summary>
        /// Gets or sets the budgeted berth brush.
        /// </summary>
        /// <value>
        /// The budgeted berth brush.
        /// </value>
        public Brush BudgetedBerthBrush { get; set; }

        /// <summary>
        /// Gets or sets the extra berth tech brush.
        /// </summary>
        /// <value>
        /// The extra berth tech brush.
        /// </value>
        public Brush ExtraBerthTechBrush { get; set; }

        /// <summary>
        /// Gets or sets the extra berth owner brush.
        /// </summary>
        /// <value>
        /// The extra berth owner brush.
        /// </value>
        public Brush ExtraBerthOwnerBrush { get; set; }

        /// <summary>
        /// Gets or sets the training berth brush.
        /// </summary>
        /// <value>
        /// The training berth brush.
        /// </value>
        public Brush TrainingBerthBrush { get; set; }

        /// <summary>
        /// Gets or sets the expired berth brush.
        /// </summary>
        /// <value>
        /// The expired berth brush.
        /// </value>
        public Brush ExpiredBerthBrush { get; set; }

        /// <summary>
        /// Gets or sets the overlap berth brush.
        /// </summary>
        /// <value>
        /// The overlap berth brush.
        /// </value>
        public Brush OverlapBerthBrush { get; set; }

        /// <summary>
        /// Gets or sets the plan proposed brush.
        /// </summary>
        /// <value>
        /// The plan proposed brush.
        /// </value>
        public Brush PlanProposedBrush { get; set; }

        /// <summary>
        /// Gets or sets the disputed brush.
        /// </summary>
        /// <value>The disputed brush.</value>
        public Brush DisputedBrush { get; set; }

        #endregion

        #region Interface Methods

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string statusId = (string)value;

            Brush brushValue = DefaultBrush;

            if (!string.IsNullOrWhiteSpace(statusId) && BrushByStatusId.ContainsKey(statusId))
            {
                brushValue = BrushByStatusId[statusId];
            }
            return brushValue;
        }

        /// <summary>
        /// Converts a value.
        /// </summary>
        /// <param name="value">The value that is produced by the binding target.</param>
        /// <param name="targetType">The type to convert to.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Only one way bindings are supported with this converter.");
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets the build dictionary.
        /// </summary>
        /// <returns>Single dictionary</returns>
        private Dictionary<string, Brush> GetBuildDictionary()
        {
            var tempDictionary = new Dictionary<string, Brush>();

            //Add Crew Status brush to dictionary
            foreach (CrewStatus crewStatus in EnumsHelper.GetValues<CrewStatus>())
            {
                Brush brush = null;
                switch (crewStatus)
                {
                    case CrewStatus.InTransit:
                        brush = TravelBrush;
                        break;
                    case CrewStatus.Onboard:
                        brush = OnboardBrush;
                        break;
                    case CrewStatus.Training:
                        brush = TrainingBrush;
                        break;
                    case CrewStatus.Overlap:
                        brush = OverlapBrush;
                        break;
                }
                if (brush != null && !tempDictionary.ContainsKey(EnumsHelper.GetKeyValue(crewStatus)))
                {
                    tempDictionary.Add(EnumsHelper.GetKeyValue(crewStatus), brush);
                }
            }

            //Add Crew planning status brush to dictionary
            foreach (CrewPlanningStatus crewPlanningStatus in EnumsHelper.GetValues<CrewPlanningStatus>())
            {
                Brush brush = null;
                switch (crewPlanningStatus)
                {
                    case CrewPlanningStatus.Approved:
                        brush = ApprovedBrush;
                        break;
                    case CrewPlanningStatus.Cancelled:
                        brush = CancelledBrush;
                        break;
                    case CrewPlanningStatus.Joined:
                        brush = JoinedBrush;
                        break;
                    case CrewPlanningStatus.Planned:
                        brush = PlannedBrush;
                        break;
                    case CrewPlanningStatus.Proposed:
                        brush = ProposedBrush;
                        break;
                    case CrewPlanningStatus.Ready:
                        brush = ReadyBrush;
                        break;
                    case CrewPlanningStatus.Rejected:
                        brush = RejectedBrush;
                        break;
                    case CrewPlanningStatus.Released:
                        brush = ReleasedBrush;
                        break;
                    case CrewPlanningStatus.PlanProposed:
                        brush = PlanProposedBrush;
                        break;
                    case CrewPlanningStatus.Dispute:
                        brush = DisputedBrush;
                        break;
                }
                if (brush != null && !tempDictionary.ContainsKey(EnumsHelper.GetDescription(crewPlanningStatus)))
                {
                    tempDictionary.Add(EnumsHelper.GetDescription(crewPlanningStatus), brush);
                }
            }

            //Add berth type brush to dictionary
            foreach (BerthType berthType in EnumsHelper.GetValues<BerthType>())
            {
                Brush brush = null;
                switch (berthType)
                {
                    case BerthType.BudgetedBerth:
                        brush = BudgetedBerthBrush;
                        break;
                    case BerthType.ExtraBerthTech:
                        brush = ExtraBerthTechBrush;
                        break;
                    case BerthType.ExtraBerthOwner:
                        brush = ExtraBerthOwnerBrush;
                        break;
                    case BerthType.TrainingBerth:
                        brush = TrainingBerthBrush;
                        break;
                    case BerthType.ExpiredBerth:
                        brush = ExpiredBerthBrush;
                        break;
                    case BerthType.OverlapBerth:
                        brush = OverlapBerthBrush;
                        break;
                }
                if (brush != null && !tempDictionary.ContainsKey(EnumsHelper.GetKeyValue(berthType)))
                {
                    tempDictionary.Add(EnumsHelper.GetKeyValue(berthType), brush);
                }
            }

            tempDictionary.Add(Constants.CrewOverdueTypeMinor, MinorOverdueBrush);
            tempDictionary.Add(Constants.CrewOverdueTypeMajor, MajorOverdueBrush);

            return tempDictionary;
        }

        #endregion
    }
}