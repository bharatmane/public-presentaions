﻿using GalaSoft.MvvmLight.Messaging;
using System.Collections.Generic;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// This class is to be used to pass message to WizardViewModel from WizardStepViewModel for changing steps
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ChangeWizardSteps<T> : MessageBase
    {
        /// <summary>
        /// The _step changes
        /// </summary>
        private List<ChangeWizardStep<T>> _stepChanges;
        /// <summary>
        /// The object selected.
        /// </summary>
        /// <value>
        /// The step changes.
        /// </value>
        public List<ChangeWizardStep<T>> StepChanges
        {
            get { return _stepChanges; }
        }

        /// <summary>
        /// The _context identifier
        /// </summary>
        private readonly string _contextId;
        /// <summary>
        /// Gets the unique Id for the context where selection occured.
        /// </summary>
        /// <value>
        /// The context identifier.
        /// </value>
        public string ContextId
        {
            get { return _contextId; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChangeWizardSteps{T}" /> class.
        /// </summary>
        /// <param name="stepChanges">The step changes.</param>
        /// <param name="contextId">The context identifier.</param>
        public ChangeWizardSteps(List<ChangeWizardStep<T>> stepChanges, string contextId)
        {
            _stepChanges = stepChanges;
            _contextId = contextId;
        }
    }
    /// <summary>
    /// This class is to be used to pass message to WizardViewModel from WizardStepViewModel for changing steps
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ChangeWizardStep<T> : MessageBase
    {
        /// <summary>
        /// The _index
        /// </summary>
        private readonly int _index;
        /// <summary>
        /// Gets the index.
        /// </summary>
        /// <value>
        /// The index.
        /// </value>
        public int Index
        {
            get { return _index; }
        }

        /// <summary>
        /// The _step
        /// </summary>
        private readonly T _step;
        /// <summary>
        /// Gets the step.
        /// </summary>
        /// <value>
        /// The step.
        /// </value>
        public T Step
        {
            get { return _step; }
        }

        /// <summary>
        /// The _action
        /// </summary>
        private readonly WizardStepAction _action;
        /// <summary>
        /// Gets the action.
        /// </summary>
        /// <value>
        /// The action.
        /// </value>
        public WizardStepAction Action
        {
            get { return _action; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChangeWizardStep{T}"/> class.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <param name="step">The step.</param>
        /// <param name="action">The action.</param>
        public ChangeWizardStep(int index, T step, WizardStepAction action)
        {
            _index = index;
            _step = step;
            _action = action;
        }
    }

    /// <summary>
    /// This enum is to be used to pass message to WizardViewModel from WizardStepViewModel for changing steps
    /// </summary>
    public enum WizardStepAction
    {
        /// <summary>
        /// The add
        /// </summary>
        Add,
        /// <summary>
        /// The remove
        /// </summary>
        Remove
    }
}
