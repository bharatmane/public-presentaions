﻿namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// Application wide messages that are published using the Messaging system.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
