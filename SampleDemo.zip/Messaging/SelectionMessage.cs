﻿using GalaSoft.MvvmLight.Messaging;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// A message raised whenever selection occurs.
    /// </summary>
    /// <typeparam name="T">The type of object selected.</typeparam>
    public class SelectionMessage<T> : MessageBase
    {
        private readonly T _selectedItem;
        /// <summary>
        /// The object selected.
        /// </summary>
        public T SelectedItem
        {
            get { return _selectedItem; }
        }

        private readonly string _contextId;
        /// <summary>
        /// Gets the unique Id for the context where selection occured.
        /// </summary>
        public string ContextId
        {
            get { return _contextId; }
        }

        private readonly object _additionalInfo;
        /// <summary>
        /// Used to specify additional selection criteria during selection.
        /// Such as filter info.
        /// </summary>
        public object AdditionalInfo
        {
            get { return _additionalInfo; }
        }

        /// <summary>
        /// The default constuctor for the SelectionMessage.
        /// </summary>
        /// <param name="selectedItem">The item selected.</param>
        /// <param name="contextId">The unique id of the context that raised the selection.</param>
        /// <param name="additionalInfo">sed to specify additional selection criteria during selection.</param>
        public SelectionMessage(T selectedItem, string contextId, object additionalInfo = null)
        {
            _selectedItem = selectedItem;
            _contextId = contextId;
            _additionalInfo = additionalInfo;
        }
    }
}
