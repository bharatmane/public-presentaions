﻿using GalaSoft.MvvmLight.Messaging;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// Data used to publish an event when an entity is selected.
    /// </summary>
    /// <example>
    /// The following example uses the default messenger to publish the fact an entity has been selected.
    /// <code lang="C#" title="C#">
    /// Messenger.Default.Send(new EntitySelectionMessage(NavigationContext.CurrentView.ModuleName, ModuleInit.VesselInspection, SelectedInspection.Id, SelectedInspection.Name, "InspectionGeometry"));
    /// </code>
    /// </example>
    public class EntitySelectionMessage : MessageBase
    {
        private readonly string _moduleName;
        /// <summary>
        /// The name of the module holding the entity.
        /// </summary>
        public string ModuleName
        {
            get { return _moduleName; }
        }

        private readonly string _viewName;
        /// <summary>
        /// The name of the navigation view the entity was selected on.
        /// </summary>
        public string ViewName
        {
            get { return _viewName; }
        }

        private readonly object _navigationParameter;
        /// <summary>
        /// Gets the paramater used to navigated to the entity.
        /// This could be the unique Id of the entity or a compisite key.
        /// </summary>
        public object NavigationParameter
        {
            get { return _navigationParameter; }
        }

        private readonly string _label;
        /// <summary>
        /// The label for the entity.
        /// </summary>
        public string Label
        {
            get { return _label; }
        }

        private readonly string _iconReference;
        /// <summary>
        /// A reference to an icon resource used to identify the entity.
        /// </summary>
        public string IconReference
        {
            get { return _iconReference; }
        }

        /// <summary>
        /// The constructor for the EntitySelectionMessage.
        /// </summary>
        /// <param name="moduleName">The name of the module holding the entity.</param>
        /// <param name="viewName">The name of the navigation view the entity was selected on.</param>
        /// <param name="navigationParameter">The parameter passed to the <see cref="INavigationService"/> during navigating to the entity.</param>
        /// <param name="label">The label for the entity.</param>
        /// <param name="iconReference">A reference to an icon resource used to identify the entity.</param>
        public EntitySelectionMessage(string moduleName, string viewName, object navigationParameter, string label, string iconReference)
        {
            _moduleName = moduleName;
            _viewName = viewName;
            _navigationParameter = navigationParameter;
            _label = label;
            _iconReference = iconReference;
        }

    }
}
