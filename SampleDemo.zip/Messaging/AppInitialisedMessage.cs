﻿using GalaSoft.MvvmLight.Messaging;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// Message sent out informing that the app is initialised.
    /// </summary>
    public class AppInitialisedMessage : MessageBase
    {

    }
}
