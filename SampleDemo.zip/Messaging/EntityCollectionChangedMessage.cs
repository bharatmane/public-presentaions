﻿using System.Collections.Generic;
using GalaSoft.MvvmLight.Messaging;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// Data used to publish an event when an entity is selected.
    /// </summary>
    /// <example>
    /// The following example uses the default messenger to publish the fact an entity has been changed.
    /// <code lang="C#" title="C#">
    /// Messenger.Default.Send(new EntityCollectionChangedMessage(Entities, ChangeTypes.Updated, NavigationContext.ID));
    /// </code>
    /// </example>
    public class EntityCollectionChangedMessage<T> : MessageBase
    {
        private readonly IEnumerable<T> _entities;
        /// <summary>
        /// The entity that changed.
        /// </summary>
        public IEnumerable<T> Entities
        {
            get { return _entities; }
        }

        private readonly ChangeTypes _changeType;
        /// <summary>
        /// The type of change made to the entity.
        /// </summary>
        public ChangeTypes ChangeType   
        {
            get { return _changeType; }
        }

        private readonly string _contextId;
        /// <summary>
        /// Gets the unique Id for the context that changed the entity.
        /// </summary>
        public string ContextId
        {
            get { return _contextId; }
        }

        /// <summary>
        /// The default constuctor for the EntityChangedMessage.
        /// </summary>
        /// <param name="entities">The entities that changed.</param>
        /// <param name="changeType">The type of change made.</param>
        /// <param name="contextId">The Id for the context that changed the entity.</param>
        public EntityCollectionChangedMessage(IEnumerable<T> entities, ChangeTypes changeType, string contextId)
        {
            _entities = entities;
            _changeType = changeType;
            _contextId = contextId;
        }
    }

    
}
