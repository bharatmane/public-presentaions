﻿using GalaSoft.MvvmLight.Messaging;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// A generic message for showing a details view.
    /// </summary>
    /// <typeparam name="T">The type of object to show details for.</typeparam>
    public class ShowDetailsMessage<T> : MessageBase
    {
        private readonly T _item;
        /// <summary>
        /// The object selected.
        /// </summary>
        public T Item
        {
            get { return _item; }
        }

        private readonly string _contextId;
        /// <summary>
        /// Gets the unique Id for the context where selection occured.
        /// </summary>
        public string ContextId
        {
            get { return _contextId; }
        }

        private readonly string _detailId;
        /// <summary>
        /// The identifier for the details view. This can be the name or unique reference.
        /// </summary>
        public string DetailId
        {
            get { return _detailId; }
        }

        /// <summary>
        /// The default constuctor for the SelectionMessage.
        /// </summary>
        /// <param name="item">The item to show the details for.</param>
        /// <param name="contextId">The unique id of the context that raised the message.</param>
        /// <param name="detailId">The identifier for the details view. This can be the name or unique reference.</param>
        public ShowDetailsMessage(T item, string contextId, string detailId)
        {
            _item = item;
            _contextId = contextId;
            _detailId = detailId;
        }
    }
}
