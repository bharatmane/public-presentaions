﻿using GalaSoft.MvvmLight.Messaging;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// Message sent out informing that the app is shutting down.
    /// </summary>
    public class AppShutdownMessage : MessageBase
    {
    }
}
