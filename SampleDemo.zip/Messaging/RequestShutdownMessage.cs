﻿using System;
using GalaSoft.MvvmLight.Messaging;

namespace VShips.Framework.Common.Messaging
{
    /// <summary>
    /// A message sent out requesting if the app can shutdown.
    /// </summary>
    /// <example>
    /// The following example registers for notifications whenever an app shutdown is requested. 
    /// The RequestShutdown method is called and can used to cancel shutdown if necessery.
    /// <code lang="C#" title="C#">
    /// Messenger.Default.Register&lt;RequestShutdownMessage&gt;(this, RequestShutdown); 
    /// </code>
    /// </example>
    public class RequestShutdownMessage : MessageBase
    {
        /// <summary>
        /// Determines if the app can shutdown.
        /// </summary>
        public bool CanShutDown
        {
            get { return String.IsNullOrWhiteSpace(Reasons); }
        }

        private string _reasons = "";
        /// <summary>
        /// The reasons preventing the app from shutting down
        /// </summary>
        public string Reasons
        {
            get { return _reasons.Trim(); }
        }

        /// <summary>
        /// Appends a reason preventing the app from shutting down
        /// </summary>
        /// <param name="reason">A reason preventing the app shutting down</param>
        public void AppendReason(string reason)
        {
            _reasons = _reasons + reason + Environment.NewLine;
        }
    }
}
