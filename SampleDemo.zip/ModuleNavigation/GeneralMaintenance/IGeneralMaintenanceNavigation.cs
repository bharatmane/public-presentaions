﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Reporting;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.GeneralMaintenance
{
    /// <summary>
    /// Navigation service for the Marine Maintenance module.
    /// </summary>
    public interface IGeneralMaintenanceNavigation
    {
        #region Navigation Methods

        /// <summary>
        /// Maintain the navigation link for maintainer.
        /// </summary>
        void NavigateStart();
        /// <summary>
        /// Creates the Global Settings Maintainer.
        /// </summary>
        void CreateGlobalSettingsMaintenance();

        /// <summary>
        /// Opens the edit report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void OpenEditReport(INavigationContext navigationContext, string parameter,Action RefreshReportListAfterSave);


        /// <summary>
        /// Opens the map parameters.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportid">The reportid.</param>
        /// <param name="reportname">The reportname.</param>
        void OpenMapParameters(INavigationContext navigationContext, string reportid,string reportname);

        /// <summary>
        /// Adds the edit report navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isView">if set to <c>true</c> [is view].</param>
        void AddEditReportNavigate(INavigationContext navigationContext, string parameter, bool isView);


        /// <summary>
        /// Adds the report goup navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sendNewGroupIdAction">The send new group identifier action.</param>
        void AddReportGoupNavigate(INavigationContext navigationContext, Action<string> sendNewGroupIdAction);

        /// <summary>
        /// Selects the report location.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectFolderAction">The select folder action.</param>
        void SelectReportLocation(INavigationContext navigationContext,Action<ReportLocationFolderType> selectFolderAction);

        /// <summary>
        /// Navigates to map role dialo view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportid">The reportid.</param>
        /// <param name="reportname">The reportname.</param>
        void NavigateToMapRoleDialoView(INavigationContext navigationContext, string reportid, string reportname);

        /// <summary>
        /// Navigates to map module dialo view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportid">The reportid.</param>
        /// <param name="reportname">The reportname.</param>
        void NavigateToMapModuleDialoView(INavigationContext navigationContext, string reportid, string reportname);

        /// <summary>
        /// Navigates to add edit report parameter view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToAddEditReportParameterView(INavigationContext navigationContext, Dictionary<string, object> parameters);
        /// <summary>
        /// Navigates to report log dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="reportName">Name of the report.</param>
        void NavigateToReportLogDialogView(INavigationContext navigationContext, string reportId, string reportName);

        /// <summary>
        /// Navigates to map report files dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="reportName">Name of the report.</param>
        void NavigateToMapReportFilesDialogView(INavigationContext navigationContext, string reportId, string reportName);

        /// <summary>
        /// Navigates to package splitter.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateToPackageSplitter(INavigationContext navigationContext);
        #endregion
    }
}