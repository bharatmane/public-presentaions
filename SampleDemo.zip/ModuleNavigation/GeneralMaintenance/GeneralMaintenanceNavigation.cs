﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Reporting;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.GeneralMaintenance
{
    /// <summary>
    /// Default implementation of the <see cref="IGeneralMaintenanceNavigation"/> service.
    /// </summary>
    public class GeneralMaintenanceNavigation : BaseModuleNavigationService, IGeneralMaintenanceNavigation
    {
        #region Constructors

        /// <summary>
        /// The default constructor for Marine Maintenance.
        /// </summary>
        public GeneralMaintenanceNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }


        #endregion

        #region Navigation methods
        /// <summary>
        /// Start.
        /// </summary>
        public void NavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }
        /// <summary>
        /// Creates the Global Settings Maintainer.
        /// </summary>
        public void CreateGlobalSettingsMaintenance()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.GeneralMaintenanceTitle);
        }

        /// <summary>
        /// Opens the edit report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void OpenEditReport(INavigationContext navigationContext, string parameter, Action RefreshReportListAfterSave)
        {
            var param = new Dictionary<string, object>
            {
                {Common.Constants.SelectedId, parameter},
                {Common.Constants.Action, RefreshReportListAfterSave},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportMaintainerEditNavigationView, navigationContext, param);
        }


        /// <summary>
        /// Opens the map parameters.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportid">The reportid.</param>
        /// <param name="reportname">The reportname.</param>
        public void OpenMapParameters(INavigationContext navigationContext, string reportid,string reportname)
        {
            var param = new Dictionary<string, string>
            {
                {Common.Constants.ReportId, reportid},
                {Common.Constants.ReportName, reportname},
            };
            NavigationService.NavigateDialog(Constants.ModuleName,Constants.ReportMaintainerMapParametersView,navigationContext,param);
        }

        /// <summary>
        /// Adds the edit report navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isView">if set to <c>true</c> [is view].</param>
        public void AddEditReportNavigate(INavigationContext navigationContext, string parameter, bool isView)
        {
            var param = new Dictionary<string, object>
            {
                {Common.Constants.ReportId, parameter},
                {Common.Constants.IsView, isView},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditReportView, navigationContext, param);
        }
        /// <summary>
        /// Adds the report goup navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sendNewGroupIdAction">The send new group identifier action.</param>
        public void AddReportGoupNavigate(INavigationContext navigationContext,Action<string>sendNewGroupIdAction)
        {
            var param = new Dictionary<string, object>
            {
                {Common.Constants.Action, sendNewGroupIdAction}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddReportGroupView, navigationContext, param);
        }

        /// <summary>
        /// Selects the report location.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectFolderAction">The select folder action.</param>
        public void SelectReportLocation(INavigationContext navigationContext, Action<ReportLocationFolderType> selectFolderAction)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectReportLocationView, navigationContext,selectFolderAction);
        }


        /// <summary>
        /// Navigates to map role dialo view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportid">The reportid.</param>
        /// <param name="reportname">The reportname.</param>
        public void NavigateToMapRoleDialoView(INavigationContext navigationContext, string reportid, string reportname)
        {
            var parmaters = new Dictionary<string, string>
            {
                {Common.Constants.ReportId, reportid},
                {Common.Constants.ReportName, reportname},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapRoleDialogView, navigationContext, parmaters);
        }

        // <summary>
        /// Navigates to map module dialo view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportid">The reportid.</param>
        /// <param name="reportname">The reportname.</param>
        public void NavigateToMapModuleDialoView(INavigationContext navigationContext, string reportid, string reportname)
        {
            var parmaters = new Dictionary<string, string>
            {
                {Common.Constants.ReportId, reportid},
                {Common.Constants.ReportName, reportname},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapModuleDialogView, navigationContext, parmaters);
        }

        /// <summary>
        /// Navigates to add edit report parameter view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAddEditReportParameterView(INavigationContext navigationContext, Dictionary<string,object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditReportParameterView, navigationContext, parameters);
        }
        /// <summary>
        /// Navigates to report log dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="reportName">Name of the report.</param>
        public void NavigateToReportLogDialogView(INavigationContext navigationContext,string reportId, string reportName)
        {

            var parmaters = new Dictionary<string, string>
            {
                {Common.Constants.ReportId, reportId},
                {Common.Constants.ReportName, reportName},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportLogsDialogView, navigationContext, parmaters);
        }

        /// <summary>
        /// Navigates to map report files dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="reportName">Name of the report.</param>
        public void NavigateToMapReportFilesDialogView(INavigationContext navigationContext, string reportId, string reportName)
        {
            var parmaters = new Dictionary<string, string>
            {
                {Common.Constants.ReportId, reportId},
                {Common.Constants.ReportName, reportName},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapReportExportyTypeDialogView, navigationContext, parmaters);
        }


        /// <summary>
        /// Navigates to package splitter.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToPackageSplitter(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PackageSplitterView, navigationContext);
        }

        #endregion
    }
}