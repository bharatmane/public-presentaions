﻿namespace VShips.Framework.Common.ModuleNavigation.GeneralMaintenance 
{
    /// <summary>
    /// Services and constants relating to the Account Maintenance module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}