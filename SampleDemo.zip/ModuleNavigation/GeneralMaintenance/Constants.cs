﻿namespace VShips.Framework.Common.ModuleNavigation.GeneralMaintenance
{
    /// <summary>
    /// Names of accessible views and regions related to the AccountMaintenance module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "GeneralMaintenance";

        /// <summary>
        /// The marine maintenance title
        /// </summary>
        public const string GeneralMaintenanceTitle = "Global Settings";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "MaintenanceGeometry";

        //Views

        /// <summary>
        /// The general maintenance start view
        /// </summary>
        public const string StartView = "GeneralMaintenanceStartView";

        /// <summary>
        /// The report maintainer start view
        /// </summary>
        public const string ReportMaintainerStartView = "ReportMaintainerStartView";

        /// <summary>
        /// The vessel version maintainer start view
        /// </summary>
        public const string VesselVersionMaintainerStartView = "VesselVersionMaintainerStartView";

        /// <summary>
        /// The report maintainer edit navigation view
        /// </summary>
        public const string ReportMaintainerEditNavigationView = "ReportMaintainerEditNavigationView";

        /// <summary>
        /// The report maintainer map parameters view
        /// </summary>
        public const string ReportMaintainerMapParametersView = "ReportMaintainerMapParametersView";



        /// <summary>
        /// The add report group view
        /// </summary>
        public const string AddReportGroupView = "AddReportGroupView";

        /// <summary>
        /// The add edit group view
        /// </summary>
        public const string AddEditReportView = "AddEditReportView";

        /// <summary>
        /// The select report location view
        /// </summary>
        public const string SelectReportLocationView = "SelectReportLocationView";

        /// <summary>
        /// The add edit report wizard view
        /// </summary>
        public const string AddEditReportWizardView = "public const string";

        /// <summary>
        /// The map role dialog view
        /// </summary>
        public const string MapRoleDialogView = "MapRoleDialogView";

        /// <summary>
        /// The map module dialog view
        /// </summary>
        public const string MapModuleDialogView = "MapModuleDialogView";

        /// <summary>
        /// The bi report maintainer view
        /// </summary>
        public const string BIReportMaintainerView = "BIReportMaintainerView";

        /// <summary>
        /// The add edit report parameter view
        /// </summary>
        public const string AddEditReportParameterView = "AddEditReportParameterView";

        /// <summary>
        /// The report logs dialog view
        /// </summary>
        public const string ReportLogsDialogView = "ReportLogsDialogView";

        /// <summary>
        /// The map report files dialog view
        /// </summary>
        public const string MapReportExportyTypeDialogView = "MapReportExportyTypeDialogView";

        /// <summary>
        /// The package splitter view
        /// </summary>
        public const string PackageSplitterView = "PackageSplitterView";
    }
}
