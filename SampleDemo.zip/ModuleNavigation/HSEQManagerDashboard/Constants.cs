﻿namespace VShips.Framework.Common.ModuleNavigation.HSEQManagerDashboard
{
    /// <summary>
    /// Names of accessible views and regions related to the superintendent dashboard module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "HSEQManagerDashboard";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "VesselGeometry";

        /// <summary>
        /// The landing or start view for the superintendent dashboard.
        /// </summary>
        public const string StartView = "HSEQManagerDashboardStartView";

        public const string HazOcsModuleName = "HazOcs";

        /// <summary>The landing or start view for haz oc.</summary>
        public const string HazOcsStartView = "HazOcsStartView";

    }
}
