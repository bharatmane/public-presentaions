﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.ModuleNavigation.IHSEQManagerDashboard;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.HSEQManagerDashboard
{
    public class HSEQManagerDashboardNavigation : BaseModuleNavigationService, IHSEQManagerDashboardNavigation
    {
        /// <summary>
        /// The default contructor for the InspectionNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public HSEQManagerDashboardNavigation(INavigationService navigationService)
            : base(navigationService)
        {

        }
        
    }
}
