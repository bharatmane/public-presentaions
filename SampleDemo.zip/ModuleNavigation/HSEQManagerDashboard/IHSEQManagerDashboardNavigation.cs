﻿using GalaSoft.MvvmLight.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VShips.Contracts.Custom.DefectManager;
using VShips.Contracts.Custom.PlannedMaintenance;
using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.ModuleNavigation.IHSEQManagerDashboard
{
    public interface IHSEQManagerDashboardNavigation
    {
    }
}
