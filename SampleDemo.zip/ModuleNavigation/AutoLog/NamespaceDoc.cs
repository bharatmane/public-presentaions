﻿namespace VShips.Framework.Common.ModuleNavigation.AutoLog
{
    /// <summary>
    /// Services and constants relating to the vessel module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}