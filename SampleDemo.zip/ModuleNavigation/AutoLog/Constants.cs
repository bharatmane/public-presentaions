﻿// ReSharper disable InconsistentNaming
#pragma warning disable 1591
namespace VShips.Framework.Common.ModuleNavigation.AutoLog
{
    public static class Constants
    {
        public const string ModuleName = "AutoLog";
        public const string ModuleIcon = "VesselGeometry";
        public const string SeaRoutesWeather = "SeaRoutesWeather";
        public const string StartView = "AutoLogStartView";
        public const string VesselSimulationView = "VesselSimulationView";
        public const string VesselAISTabView = "VesselAISTabView";
        public const string AISSeaRoutesView = "AISSeaRoutesView";
    }
}
