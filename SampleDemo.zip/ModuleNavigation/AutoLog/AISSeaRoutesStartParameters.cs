﻿using System;
using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.ModuleNavigation.AutoLog
{
    public class AISSeaRoutesStartParameters
    {
        private string _posId;
        public string PosId
        {
            get { return _posId; }
            set { _posId = value; }
        }

        private string _vesselId;
        public string VesselId
        {
            get { return _vesselId; }
            set { _vesselId = value; }
        }

        private DateTime _fromDate;
        public DateTime FromDate
        {
            get { return _fromDate; }
            set { _fromDate = value; }
        }

        private DateTime _toDate;
        public DateTime ToDate
        {
            get { return _toDate; }
            set { _toDate = value; }
        }

        private string _selectedTab;
        public string SelectedTab
        {
            get { return _selectedTab; }
            set { _selectedTab = value; }
        }

        private UserMenuItem _filter;
        public UserMenuItem Filter
        {
            get { return _filter; }
            set { _filter = value; }
        }

        
        public AISSeaRoutesStartParameters(DateTime fromDate, DateTime toDate, string vesselId)
        {
            _fromDate = fromDate;
            _toDate = toDate;
            _vesselId = vesselId;
        }

        public AISSeaRoutesStartParameters()
        {
        }
    }

}
