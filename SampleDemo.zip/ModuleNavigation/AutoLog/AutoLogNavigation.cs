﻿using System.Collections.Generic;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.AutoLog
{
    /// <inheritdoc cref="IAutoLogNavigation" />
    public class AutoLogNavigation : BaseModuleNavigationService, IAutoLogNavigation
    {
        /// <inheritdoc />
        public AutoLogNavigation(INavigationService navigationService) : base(navigationService)
        {
        }

        /// <inheritdoc />
        public void AutoLogNavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }

        /// <inheritdoc />
        public void AutoLogVesselSimulation(string vesselId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VesselSimulationView, vesselId);
        }

        /// <inheritdoc />
        public void AutoLogAISPlotNavigation(string vesselId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VesselAISTabView, vesselId);
        }

        /// <inheritdoc />
        public void AISSeaRoutesComparisonNavigation(string vesselId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AISSeaRoutesView, vesselId);
        }

        /// <inheritdoc />
        //public void SeaRoutesWeatherDetailNavigation(INavigationContext navigationContext, SeaRoutesWeatherResponseModel seaRoutesWeather, double top, double left)
        //{
        //    var seaRoutesWeatherParameter = new Dictionary<string, object>
        //    {
        //        { Constants.SeaRoutesWeather, seaRoutesWeather }
        //    };
        //    NavigationService.NavigateDialog(Constants.ModuleName, Constants.SeaRoutesWeatherDetailView, navigationContext, seaRoutesWeatherParameter, top, left);
        //}
    }
}
