﻿using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.AutoLog
{
    /// <summary>
    /// Interface for AutoLog navigation operations
    /// </summary>
    public interface IAutoLogNavigation
    {
        /// <summary>
        /// AutoLog navigation startup stuff
        /// </summary>
        void AutoLogNavigateStart();

        /// <summary>
        /// Navigate to AutoLog Vessel Simulation
        /// </summary>
        /// <param name="vesselId"></param>
        void AutoLogVesselSimulation(string vesselId);

        /// <summary>
        /// Navigate to AutoLog AIS Plot
        /// </summary>
        /// <param name="vesselId"></param>
        void AutoLogAISPlotNavigation(string vesselId);

        /// <summary>
        /// Navigate to AIS SeaRoutes Comparison
        /// </summary>
        /// <param name="vesselId"></param>
        void AISSeaRoutesComparisonNavigation(string vesselId);


        //void SeaRoutesWeatherDetailNavigation(INavigationContext navigationContext, SeaRoutesWeatherResponseModel seaRoutesWeather, double top, double left);
    }
}