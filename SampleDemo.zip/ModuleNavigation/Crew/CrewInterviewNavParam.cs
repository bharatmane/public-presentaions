﻿namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Crew Interview Navigation Parameters
    /// </summary>
    public class CrewInterviewNavParam
    {
        /// <summary>
        /// Gets or sets the cri identifier.
        /// </summary>
        /// <value>
        /// The cri identifier.
        /// </value>
        public string CriId { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is read only mode.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is read only mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsReadOnlyMode { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }
    }
}