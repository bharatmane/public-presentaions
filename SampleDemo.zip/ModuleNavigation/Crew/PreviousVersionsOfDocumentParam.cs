﻿using VShips.DataServices.Shared.Enumerations.Document;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Previous Versions Of Document Parameter
    /// </summary>
    public class PreviousVersionsOfDocumentParam
    {
        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>
        /// The name of the file.
        /// </value>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets the file description.
        /// </summary>
        /// <value>
        /// The file description.
        /// </value>
        public string FileDescription { get; set; }

        /// <summary>
        /// Gets or sets the document category.
        /// </summary>
        /// <value>
        /// The document category.
        /// </value>
        public DocumentCategory DocumentCategory { get; set; }
    }
}
