﻿namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// CrewGenericAppraisalNavParameter Class
    /// </summary>
    public class CrewGenericAppraisalNavParameter
    {
        /// <summary>
        /// Gets or sets the application identifier.
        /// </summary>
        /// <value>
        /// The application identifier.
        /// </value>
        public string AppId { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is read only mode.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is read only mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsReadOnlyMode { get; set; }
    }
}