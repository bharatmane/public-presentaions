﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.Services.Default;
using Microsoft.Practices.ServiceLocation;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// CrewNavigationHelper Class
    /// </summary>
    public static class CrewNavigationHelper
    {
        /// <summary>
        /// Gets the navigation context.
        /// </summary>
        /// <param name="isDailog">if set to <c>true</c> [is dailog].</param>
        /// <returns> A INavigationContext Object. </returns>
        public static INavigationContext GetNavigationContext(bool isDailog)
        {
            IModuleService moduleService = ServiceLocator.Current.GetInstance<IModuleService>();
            string moduleName = Constants.ModuleName;
            ILoggerService loggerService = ServiceLocator.Current.GetInstance<ILoggerService>();
            IDialogManager dialogManager = ServiceLocator.Current.GetInstance<IDialogManager>();

            return new NavigationContext(moduleService, moduleName, loggerService, dialogManager, isDailog ? ContextType.Dialog : ContextType.New);
        }
    }
}
