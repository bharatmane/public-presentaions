﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Enumerations.Crew;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Class
    /// </summary>
    public class CrewNavParam
    {
        /// <summary>
        /// The save executed
        /// </summary>
        public Action<bool, object> SaveExecuted { get; set; }

        /// <summary>
        /// Gets or sets the save executed from PMD.
        /// </summary>
        /// <value>
        /// The save executed from PMD.
        /// </value>
        public Action<bool,object,string> SaveExecutedFromPMD { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is sub status selection required.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is sub status selection required; otherwise, <c>false</c>.
        /// </value>
        public bool IsSubStatusSelectionRequired { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the onsigner set ids.
        /// </summary>
        /// <value>
        /// The onsigner set ids.
        /// </value>
        public List<string> OnsignerSetIds { get; set; }

        /// <summary>
        /// Gets or sets the offsigner set ids.
        /// </summary>
        /// <value>
        /// The offsigner set ids.
        /// </value>
        public List<string> OffsignerSetIds { get; set; }

        /// <summary>
        /// Gets or sets the lineup identifier.
        /// </summary>
        /// <value>
        /// The lineup identifier.
        /// </value>
        public string LineupId { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the set identifier.
        /// </summary>
        /// <value>
        /// The set identifier.
        /// </value>
        public string SetId { get; set; }

        /// <summary>
        /// Gets or sets the centralised request identifier.
        /// </summary>
        /// <value>
        /// The centralised request identifier.
        /// </value>
        public string CentralisedRequestId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is user tpa.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is user tpa; otherwise, <c>false</c>.
        /// </value>
        public bool IsUserTPA { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the window title.
        /// </summary>
        /// <value>
        /// The window title.
        /// </value>
        public string WindowTitle { get; set; }

        /// <summary>
        /// Gets or sets the label message.
        /// </summary>
        /// <value>
        /// The label message.
        /// </value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the label text.
        /// </summary>
        /// <value>
        /// The label text.
        /// </value>
        public string LabelText { get; set; }

        /// <summary>
        /// Gets or sets the crew ids.
        /// </summary>
        /// <value>
        /// The crew ids.
        /// </value>
        public List<string> CrewIds { get; set; }

        /// <summary>
        /// Gets or sets the planning status identifier.
        /// </summary>
        /// <value>
        /// The planning status identifier.
        /// </value>
        public string PlanningStatusId { get; set; }

        /// <summary>
        /// Gets or sets the planning status short code.
        /// </summary>
        /// <value>
        /// The planning status short code.
        /// </value>
        public string PlanningStatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the planning status description.
        /// </summary>
        /// <value>
        /// The planning status description.
        /// </value>
        public string PlanningStatusDescription { get; set; }

        /// <summary>
        /// Gets or sets the crew sign on.
        /// </summary>
        /// <value>
        /// The crew sign on.
        /// </value>
        public DateTime? CrewSignOn { get; set; }

        /// <summary>
        /// Gets or sets the crew due relief.
        /// </summary>
        /// <value>
        /// The crew due relief.
        /// </value>
        public DateTime? CrewDueRelief { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is local save.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is local save; otherwise, <c>false</c>.
        /// </value>
        public bool IsLocalSave { get; set; }

        /// <summary>
        /// Gets or sets the CST ids.
        /// </summary>
        /// <value>
        /// The CST ids.
        /// </value>
        public List<string> CstIds { get; set; }

        /// <summary>
        /// Gets or sets the DefaultWorkingListType.
        /// </summary>
        /// <value>
        /// The DefaultWorkingListType.
        /// </value>
        public CrewWorkingListType? DefaultTypeSelectionOnLoad { get; set; }

        /// <summary>
        /// removes previously selected item
        /// </summary>
        public bool DiscardPreviousSelection { get; set; }

        /// <summary>
        /// Flag to ByPass Equality Check
        /// </summary>
        public bool SkipRefreshOnNavigation { get; set; }

        #region Private Fields

        /// <summary>
        /// Parameter Created Time
        /// </summary>
        private DateTime _createdTime;

        #endregion

        #region Constructor

        /// <summary>
        /// CrewNavParam
        /// </summary>
        public CrewNavParam()
        {
            _createdTime = DateTime.Now;
        }
        #endregion

        #region Overriden Methods

        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            bool skipEqualityCheck = false;
            var newItem = obj as CrewNavParam;

            if (newItem != null)
            {
                var latestObj = newItem._createdTime > _createdTime ? newItem : this;
                skipEqualityCheck = latestObj.SkipRefreshOnNavigation;
            }

            return skipEqualityCheck ? true : base.Equals(obj);
        }
        #endregion
    }
}