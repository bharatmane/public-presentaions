﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Contracts.Custom.AppraisalManagement;
using VShips.Contracts.Custom.Crew;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Crew;
using VShips.DataServices.Shared.Enumerations.Crew;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Default implementation of the <see cref="ICrewNavigation"/> service.
    /// </summary>
    public class CrewNavigation : BaseModuleNavigationService, ICrewNavigation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CrewNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public CrewNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Crews the navigate crew search.
        /// </summary>
        /// <param name="poolId">The pool identifier.</param>
        /// <param name="selectedStatus">The selected status.</param>
        /// <param name="isIncludeInactive">if set to <c>true</c> [is include inactive].</param>
        public void CrewNavigateCrewSearch(string poolId, string selectedStatus, bool isIncludeInactive)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.PoolId, poolId },
                { Constants.SelectedStatus, selectedStatus },
                { Constants.IsIncludeInactive,isIncludeInactive }
            };
            NavigationService.NavigateNew(Constants.ModuleName, Constants.CrewSearchStartView, parameters);
        }

        /// <summary>
        /// Crewings the navigate to crew search start view.
        /// </summary>
        /// <param name="parentId"></param>
        public void CrewingNavigateCrewSearchStartView(string parentId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewSearchStartView, parentId);
        }

        /// <summary>
        /// Crews the navigate crew summary.
        /// </summary>
        /// <param name="crewNavigationParameter">The crew navigation parameter.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isCrewLocked">if set to <c>true</c> [is crew locked].</param>
        public void CrewNavigateCrewSummary(object crewNavigationParameter, string crewId, INavigationContext navigationContext = null, bool isCrewLocked = false)
        {
            if (isCrewLocked)
            {
                NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewBasicDetailDialogView, navigationContext, crewId);
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(crewId))
                {
                    NavigationService.NavigateExisting(Constants.ModuleName, Constants.BioDataNavItem, crewNavigationParameter, crewId);
                }
                else
                {
                    NavigationService.NavigateNew(Constants.ModuleName, Constants.BioDataNavItem, crewNavigationParameter);
                }
            }
        }


        /// <summary>
        /// Navigate to Crew Working List
        /// </summary>
        /// <param name="paramter"></param>
        public void CrewNavigateWorkingLists(CrewNavParam paramter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.BioDataMainView, paramter);
        }

        /// <summary>
        /// Crews the list start view.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="isPlanningTabSelected">if set to <c>true</c> [is planning tab selected].</param>
        public void CrewListStartView(string vesselId, string vesselName, bool isPlanningTabSelected = false)
        {
            var dictionaryAttachments = new Dictionary<string, object>
            {
                { Constants.VesselId, vesselId },
                { Constants.VesselName, vesselName },
                { Constants.IsPlanningViewTabSelected, isPlanningTabSelected }
            };

            NavigationService.NavigateNew(Constants.ModuleName, Constants.CrewListStartView, dictionaryAttachments);
        }

        /// <summary>
        /// Crews the list start view.
        /// </summary>
        public void CrewListStartView()
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.CrewListStartView);
        }

        /// <summary>
        /// Opens Add Attachment Dialog.
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="fileNames"></param>
        /// <param name="attachmentParam"></param>
        /// <param name="isShowCategoryType"></param>
        public void CrewingNavigateAddAttachment(INavigationContext navigationContext, IEnumerable<string> fileNames, AttachmentParameter attachmentParam, bool isShowCategoryType)
        {
            var dictionaryAttachments = new Dictionary<string, object>
            {
                { Constants.AttachmentParameter, attachmentParam },
                { Constants.Files, fileNames.ToList() },
                { Constants.IsShowCategoryType, isShowCategoryType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AttachmentAddView, navigationContext, dictionaryAttachments);
        }

        /// <summary>
        /// Opens Edit Attachment Dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="attachmentParam">The attachment parameter.</param>
        /// <param name="isShowCategoryType"></param>
        public void CrewingNavigateEditAttachment(INavigationContext navigationContext, object entity, AttachmentParameter attachmentParam, bool isShowCategoryType)
        {
            var dictionaryAttachment = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                { Constants.AttachmentParameter,attachmentParam},
                { Constants.IsShowCategoryType, isShowCategoryType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AttachmentEditView, navigationContext, dictionaryAttachment);
        }

        /// <summary>
        /// Crewings the navigate crew list add edit berth.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="IsOptimiserEnabled">if set to <c>true</c> [is optimiser enabled].</param>
        /// <param name="vesselOwnerId">The vessel owner identifier.</param>
        /// <param name="vesselOwnerName">Name of the vessel owner.</param>
        /// <param name="onboardCrewServiceId">The onboard crew service identifier.</param>
        public void CrewingNavigateCrewListAddEditBerth(INavigationContext navigationContext, string vesselId, object entity, bool IsOptimiserEnabled, string vesselOwnerId, string vesselOwnerName, string onboardCrewServiceId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity }, {"vesselId", vesselId},{Constants.IsOptimiserEnabledVessel,IsOptimiserEnabled }
                ,{Constants.VesselOwnerId,vesselOwnerId},{Constants.VesselOwnerName,vesselOwnerName},{Constants.OnboardCrewServiceIdForBerth,onboardCrewServiceId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditBerthDialogView, navigationContext, parameters);
        }
        /// <summary>
        /// Crewings the navigate import budgeted crew list.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isBudgetedBerthExists">if set to <c>true</c> [_is budgeted berth exists].</param>
        public void CrewingNavigateImportBudgetedCrewList(INavigationContext navigationContext, string vesselId, bool isBudgetedBerthExists)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.VesselId, vesselId }, {Constants.IsBudgetedBerthExists,isBudgetedBerthExists}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportBudgetedCrewListDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// the navigate propose.
        /// </summary>
        /// <param name="crewListDetail">The crew list detail.</param>
        /// <param name="isConsiderForwardPlanning">if set to <c>true</c> [is consider forward planning].</param>
        public void CrewingNavigatePropose(CrewListDetail crewListDetail, bool isConsiderForwardPlanning)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewListDetail, crewListDetail},
                {Constants.IsConsiderForwardPlanning, isConsiderForwardPlanning}
            };
            NavigationService.NavigateNew(Constants.ModuleName, Constants.ProposeView, parameters);
        }

        /// <summary>
        /// Crewings the navigate to position list dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="setPortAgentDetails">The set port agent details.</param>
        public void CrewingNavigatePositionListDialogView(INavigationContext navigationContext, string vesselId, Action<object> setPortAgentDetails)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselId, vesselId},
                {Constants.SetPortAgentMethod, setPortAgentDetails}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PositionListDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate to line up start view.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void CrewingNavigateLineUpStartView(object parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.LineUpSatrtView, parameters);
        }

        /// <summary>
        /// Crewings the navigate line up add crew.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="lineUpId">The line up identifier.</param>
        /// <param name="getOnsignerAndOffsigner">The get onsigner and offsigner.</param>
        /// <param name="isOnsigner">if set to <c>true</c> [is onsigner].</param>
        public void CrewingNavigateLineUpAddCrew(INavigationContext navigationContext, string vesselId, string vesselName, string lineUpId, Action<object, object> getOnsignerAndOffsigner, bool isOnsigner)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselId,vesselId},
                {Constants.VesselName,vesselName},
                {Constants.LineupId,lineUpId},
                {Constants.GetSelectedOnsignerOffsigner,getOnsignerAndOffsigner},
                {Constants.IsOnSigner,isOnsigner }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LineUpAddCrew, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit planning details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewRecord">The crew record.</param>
        /// <param name="vacancyDetails">The vacancy details.</param>
        /// <param name="crewBioDataRecord">The crew bio data record.</param>
        /// <param name="updateCrewHeaderDetails">The update header details.</param>
        public void CrewingNavigateAddEditPlanningDetails(INavigationContext navigationContext, object crewRecord, object vacancyDetails, object crewBioDataRecord, Action updateCrewHeaderDetails)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.CrewRecord, crewRecord },
                {Constants.VacancyDetails,vacancyDetails},
                {Constants.CrewBioDataRecord,crewBioDataRecord},
                {Constants.UpdateCrewHeaderDetails,updateCrewHeaderDetails}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditPlanningDetailsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit scheduled contact.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="selectedScheduledContract">The selected scheduled contract.</param>
        /// <param name="isEditScheduledContract">if set to <c>true</c> [is edit scheduled contract].</param>
        /// <param name="mobilisationScheduledContractOverDueStatusId">The mobilisation scheduled contract over due status identifier.</param>
        public void CrewingNavigateAddEditScheduledContact(INavigationContext navigationContext, string crewId, string selectedScheduledContract, bool isEditScheduledContract, object mobilisationScheduledContractOverDueStatusId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.CrewId, crewId },
                { Constants.SelectedScheduledContract, selectedScheduledContract },
                { Constants.IsEditScheduledContract, isEditScheduledContract},
                { Constants.MobilisationScheduledContractOverDueStatusId, mobilisationScheduledContractOverDueStatusId}

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditScheduledContactView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit line up.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="lineupId">The lineup identifier.</param>
        public void CrewingNavigateAddEditLineUp(INavigationContext navigationContext, string vesselId, string vesselName, string lineupId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselId,vesselId},
                {Constants.VesselName,vesselName},
                {Constants.LineupId,lineupId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditLineUpView, navigationContext, parameters);
        }

        /// <summary>
        /// Crew list update onboard record.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        public void CrewingNavigateCrewListUpdateOnboardRecord(INavigationContext navigationContext, object entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateOnboardRecordDialogView, navigationContext, entity);
        }

        /// <summary>
        /// Crewings the navigate crew list crew change.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="selectedBerths">The selected berths.</param>
        /// <param name="lineupId">The lineup identifier.</param>
        /// <param name="portDetail">The port detail.</param>
        /// <param name="VesselId">The vessel identifier.</param>
        public void CrewingNavigateCrewListCrewChange(INavigationContext navigationContext, string vesselName, List<CrewListDetail> selectedBerths, string lineupId, PortDetail portDetail, string VesselId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.VesselName, vesselName },
                { Constants.SelectedBerths,selectedBerths },
                { Constants.LineupId, lineupId },
                { Constants.PortDetail, portDetail },
                { Constants.VesselId , VesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewChangeView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate lineup.
        /// </summary>
        /// <param name="lineupDetail">The lineup detail.</param>
        public void CrewingNavigateLineup(object lineupDetail)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.LineUpSatrtView, lineupDetail);
        }

        /// <summary>
        /// Crewings the navigate crew list relief history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="rankName">Name of the rank.</param>
        /// <param name="selectedBerth">The selected berth.</param>
        public void CrewingNavigateCrewListReliefHistory(INavigationContext navigationContext, string vesselName, string rankName, string selectedBerth)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselName,vesselName},
                {Constants.RankName,rankName},
                {Constants.SelectedBerths,selectedBerth}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReliefHistoryView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add contacted detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="updateSummaryPanelMethod">The update summary panel method.</param>
        /// <param name="isContactAdddedFromMO">if set to <c>true</c> [is contact addded from mo].</param>
        /// <param name="scheduledContactId">The scheduled contact identifier.</param>
        public void CrewingNavigateAddContactedDetail(INavigationContext navigationContext, string crewId, Action updateSummaryPanelMethod, bool isContactAdddedFromMO = false, string scheduledContactId = null)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId,crewId},
                {Constants.UpdateSummaryPanelMethod,updateSummaryPanelMethod},
                {Constants.IsCrewContactAddedFromMO ,isContactAdddedFromMO },
                {Constants.ScheduledContactId,scheduledContactId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ContactDetailsView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate my group.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateMyGroup(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UserVesselGroupsView, navigationContext);
        }

        /// <summary>
        /// Crewings the navigate overlap service record.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="overlapDetail">The overlap detail.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="isOverlapDetailExists">if set to <c>true</c> [is overlap detail exists].</param>
        /// <param name="setOnboardDetail">The set onboard detail.</param>
        /// <param name="fromStartDate">From start date.</param>
        /// <param name="flightType">Type of the flight.</param>
        /// <param name="isFromDispensationTab">if set to <c>true</c> [is from dispensation tab].</param>
        /// <param name="isIncludePlanningRecords">if set to <c>true</c> [is include planning records].</param>
        public void CrewingNavigateOverlapServiceRecord(INavigationContext navigationContext, List<CrewServiceHistory> overlapDetail, string crewId, bool isOverlapDetailExists, Action<object> setOnboardDetail, DateTime? fromStartDate, CrewADNOCFlightType? flightType, bool isFromDispensationTab, bool isIncludePlanningRecords)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.OverlapDetail, overlapDetail },
                { Constants.CrewId, crewId },
                { Constants.IsOverlapDetailExists, isOverlapDetailExists },
                { Constants.SetOnboardDetail, setOnboardDetail },
                { Constants.IsFromDispensationTab, isFromDispensationTab },
                { Constants.IsIncludePlanningRecords, isIncludePlanningRecords },
                { Constants.StartDate, fromStartDate },
                { Constants.FlightType, flightType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OverlappingServiceRecordsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate address dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void CrewingNavigateAddressDialog(INavigationContext navigationContext, string crewId, object entity, bool isInViewMode)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                {Constants.CrewId,crewId},
                { Constants.IsInViewMode,isInViewMode}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditAddressView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate contact dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void CrewingNavigateContactDialog(INavigationContext navigationContext, string crewId, object entity, bool isInViewMode)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                { Constants.CrewId,crewId},
                { Constants.IsInViewMode,isInViewMode}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditContactView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate attributes dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="attributeValueId">The attribute value identifier.</param>
        public void CrewingNavigateAttributesDialog(INavigationContext navigationContext, string crewId, string attributeValueId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId, crewId},{Constants.AttributeValueId, attributeValueId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AttributesDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate next of kin dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="nokId">The nok identifier.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void CrewingNavigateNextOfKinDialog(INavigationContext navigationContext, string crewId, string nokId, bool isInViewMode)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId,crewId},
                {Constants.NokId,nokId },
                { Constants.IsInViewMode,isInViewMode}

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddNextOfKinView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate new crew member.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="tpaControlDetails">The tpa control details.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void CrewingNavigateNewCrewMember(INavigationContext navigationContext, object tpaControlDetails, string parentId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.TPADetails, tpaControlDetails },
                { Constants.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NewCrewMemberValidationView, navigationContext, parameters);
        }

        /// <summary>
        /// Crew navigate to contract start view.
        /// </summary>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="serviceId">The service identifier.</param>
        /// <param name="contractId">The contract identifier.</param>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isContractPermanent">if set to <c>true</c> [is contract permanent].</param>
        /// <param name="crewDetails">The crew details.</param>
        public void CrewingNavigateContractStartView(string crewId, string vesselId, string serviceId, string contractId, INavigationContext navigationContext, bool isContractPermanent = false, object crewDetails = null)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId,crewId},
                {Constants.VesselId,vesselId },
                {Constants.ServiceId,serviceId},
                {Constants.ContractId,contractId },
                {Constants.IsPermanentContract, isContractPermanent }
            };
            string uniqueIdentifier = isContractPermanent ? contractId : serviceId;
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewContractView, parameters, uniqueIdentifier);
        }

        /// <summary>
        /// Crewings the navigate edit change contract.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="firstName">The first name.</param>
        /// <param name="lastName">The last name.</param>
        public void CrewingNavigateEditChangeContract(INavigationContext navigationContext, string crewId, string vesselId, string vesselName, string firstName, string lastName)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId,crewId},
                {Constants.VesselId,vesselId },
                {Constants.CrewForeName,firstName },
                {Constants.CrewSurName,lastName},
                {Constants.VesselName,vesselName }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditChangeContractView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate create member cv view.
        /// </summary>
        /// <param name="crewDetails">The crew details.</param>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateCreateMemberCvView(object crewDetails, INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateMemberCv, navigationContext, crewDetails);
        }

        /// <summary>
        /// Crewings the navigate crew lookup view.
        /// </summary>
        /// <param name="navigationContext">The naviagtion context.</param>
        /// <param name="crewDetails">The crew details.</param>
        public void CrewingNavigateCrewLookupView(INavigationContext navigationContext, object crewDetails)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewLookupView, navigationContext, crewDetails);
        }

        /// <summary>
        /// Crewings the navigate user vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="isFilterTPAVessel">if set to <c>true</c> [is filter tpa vessel].</param>
        public void CrewingNavigateUserVesselLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged, bool isFilterTPAVessel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SearchText, searchText},
                {Constants.Action, selectedItemChanged},
                {Constants.IsFilterTPAVessel, isFilterTPAVessel}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UserVesselLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Crewings the navigate external appraisal dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateExternalAppraisalDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddExternalAppraisalView, navigationContext);
        }

        /// <summary>
        /// Crewings the navigate appraisal dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateAppraisalDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AppraisalAddEditView, navigationContext);
        }

        /// <summary>
        /// Crewings the navigate add edit crew image dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewDetails">The crew details.</param>
        /// <param name="updateImage"></param>
        public void CrewingNavigateAddEditCrewImageDialogView(INavigationContext navigationContext, CrewWorkingList crewDetails, Action updateImage)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.Entity, crewDetails},
                {Constants.Action, updateImage},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewImageDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate send signature email view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewName">The crew name.</param>
        /// <param name="crewEmailId">The crew email identifier.</param>
        /// <param name="managerEmailId">The manager email identifier.</param>
        /// <param name="contractId">The contract identifier.</param>
        /// <param name="contractTemplateId">The contract template identifier.</param>
        /// <param name="document">The document.</param>
        /// <param name="crewId">The crew identifier.</param>
        public void CrewingNavigateSendSignatureEmailView(INavigationContext navigationContext, string crewName, string crewEmailId, string managerEmailId, string contractId, string contractTemplateId, object document, string crewId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.Crew, crewName},
                {Constants.CrewEmailId, crewEmailId},
                {Constants.ManagerEmailId, managerEmailId},
                {Constants.ContractId, contractId},
                {Constants.ContractTemplateId, contractTemplateId},
                {Constants.Document, document},
                {Constants.CrewId, crewId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SendSignatureEmailView, navigationContext, parameter);
        }

        /// <summary>
        /// Crewings the navigate planning status comment view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CrewingNavigatePlanningStatusCommentView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PlanningStatusCommentView, navigationContext, parameters);
        }


        /// <summary>
        /// Crewings the navigate add edit crew availability dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        public void CrewingNavigateAddEditCrewAvailabilityDialogView(INavigationContext navigationContext, string crewId, object entity)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                {Constants.CrewId,crewId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewAvailabilityDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit travel dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="travelParameter">The travel parameter.</param>
        /// <param name="travelId">The travel identifier.</param>
        /// <param name="isOpenedFromTravelTab">if set to <c>true</c> [is opened from travel tab].</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void CrewingNavigateAddEditTravelDialogView(INavigationContext navigationContext, object travelParameter, string travelId, bool isOpenedFromTravelTab, bool isInViewMode)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.TravelParameter,travelParameter},
                {Constants.TravelId,travelId},
                {Constants.IsOpenedFromTravelTab,isOpenedFromTravelTab},
                {Constants.IsInViewMode , isInViewMode }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditTravelDialogView, navigationContext, parameters);
        }


        /// <summary>
        /// Crewings the navigate link assignment dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        public void CrewingNavigateLinkAssignmentDialogView(INavigationContext navigationContext, string crewId, object entity)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                {Constants.CrewId,crewId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkAssignmentDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit loi dialog view.
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="serviceId"></param>
        /// <param name="assignmentNotificationId"></param>
        /// <param name="parentId"></param>
        /// <param name="berthId"></param>
        /// <param name="markNANAsApproved"></param>
        /// <param name="resendNaN"></param>
        /// <param name="existingNanId"></param>
        /// <param name="isShowResendNan"></param>
        /// <param name="onResendRequested"></param>
        public void CrewingNavigateAddEditLOIDialogView(INavigationContext navigationContext, string serviceId, string assignmentNotificationId, string parentId, string berthId, bool markNANAsApproved = false, bool resendNaN = false, string existingNanId = null, bool isShowResendNan = false, Action onResendRequested = null)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.ServiceId, serviceId },
                { Constants.AssignmentNotificationId, assignmentNotificationId },
                { Constants.ParentId, parentId },
                { Constants.SvlId , berthId},
                { Constants.MarkNANAsApproved , markNANAsApproved},
                { Constants.ResendLOI, resendNaN },
                { Constants.ExistingAssignmentNotificationId, existingNanId },
                { Constants.IsShowResendNan, isShowResendNan },
                { Constants.Action, onResendRequested }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditLOIDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate select seafarer dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        public void CrewingNavigateSelectSeafarerDialogView(INavigationContext navigationContext, string crewId, object entity)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                {Constants.CrewId,crewId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectSeafarerDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit crew task dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        public void CrewingNavigateAddEditCrewTaskDialogView(INavigationContext navigationContext, string crewId, object entity)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                {Constants.CrewId,crewId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewTaskDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate reassign task dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="userTaskDetailsViewModel">The user task details view model.</param>
        /// <param name="isChangeOwner">if set to <c>true</c> [is change owner].</param>
        /// <param name="crewId">The crew identifier.</param>
        public void CrewingNavigateReassignTaskDialogView(INavigationContext navigationContext, object userTaskDetailsViewModel, bool isChangeOwner, string crewId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.UserTaskList, userTaskDetailsViewModel },
                {Constants.IsChangeOwner,isChangeOwner},
                {Constants.CrewId,crewId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReassignTaskDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate update task status dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="userTaskDetailslist">The usertaskdetailslist.</param>
        public void CrewingNavigateUpdateTaskStatusDialogView(INavigationContext navigationContext, object userTaskDetailslist)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateTaskStatusDialogViewModel, navigationContext, userTaskDetailslist);
        }

        /// <summary>
        /// Navigates to user notes dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="recipientId">The recipient identifier.</param>
        public void CrewingNavigateUserNotesDialogView(INavigationContext navigationContext, string recipientId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UserNotesDialogView, navigationContext, recipientId);
        }

        /// <summary>
        /// Crewings the navigate task additional information dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taskId">The task identifier.</param>
        public void CrewingNavigateTaskAdditionalInfoDialogView(INavigationContext navigationContext, string taskId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TaskAdditionalInfoDialogView, navigationContext, taskId);
        }

        /// <summary>
        /// Crewings the navigate add user task additional data dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taskDetail">The task detail.</param>
        /// <param name="taskId">The task identifier.</param>
        public void CrewingNavigateAddUserTaskAdditionalDataDialogView(INavigationContext navigationContext, UserTaskDetailMain taskDetail, string taskId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (taskDetail != null)
            {
                parameters.Add(Constants.Entity, taskDetail);
            }
            else if (!String.IsNullOrWhiteSpace(taskId))
            {
                parameters.Add(Constants.TaskId, taskId);
            }

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddUserTaskAdditionalDataDialogView, navigationContext, parameters);
        }
        /// <summary>
        ///Navigates to add agent emergency contact dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId"></param>
        /// <param name="agentDetailId"></param>
        public void CrewingNavigateAddAgentEmergencyContact(INavigationContext navigationContext, string companyId, string agentDetailId = null)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CompanyId, companyId},
                {Constants.AgentDetailId, agentDetailId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAgentEmergencyContactDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate task response data dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taskId">The task identifier.</param>
        public void CrewingNavigateTaskResponseDataDialogView(INavigationContext navigationContext, string taskId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TaskResponseDataDialogView, navigationContext, taskId);
        }

        /// <summary>
        /// Crewings the navigate edit crew task dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taskDetail">The task detail.</param>
        /// <param name="taskTitle">The task title.</param>
        public void CrewingNavigateEditCrewTaskDialogView(INavigationContext navigationContext, object taskDetail, string taskTitle)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewTaskDetails, taskDetail},
                {Constants.CrewTaskTypeTitle, taskTitle}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewTaskDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate nan manager view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateNANManagerView(INavigationContext navigationContext)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.NANManagerView, navigationContext);
        }

        /// <summary>
        /// Navigates to nan manager view.
        /// </summary>
        /// <param name="poolId">The pool identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void CrewingNavigateNANManagerView(string poolId, string vesselId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.PoolId, poolId},
                {Constants.VesselId, vesselId }
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.NANManagerView, parameters);
        }

        /// <summary>
        /// Navigates to mobilisation overview.
        /// </summary>
        public void MobilisationOverview()
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.MobilisationOverviewView);
        }

        /// <summary>
        /// Navigates to add edit recruitment view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isCalledFromCrewList">The value indicating is called from crew list</param>
        /// <param name="recruitmentDetail">the recruitmentDetail</param>
        public void CrewingNavigateAddEditRecruitmentView(INavigationContext navigationContext, bool isCalledFromCrewList, object recruitmentDetail)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, recruitmentDetail },
                { Constants.IsCalledFromCrewList,isCalledFromCrewList}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditRecruitmentView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate user task history view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taskId">The task identifier.</param>
        /// <param name="taskTitle">The task title.</param>
        public void CrewingNavigateUserTaskHistoryDialogView(INavigationContext navigationContext, string taskId, string taskTitle)
        {
            var parameters = new Dictionary<string, object>()
            {
                {Constants.TaskId,taskId},
                {Constants.TaskTitle,taskTitle}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UserTaskHistoryDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate update crew line up details dialog view.
        /// </summary>
        /// <param name="navigationContext">The update crew line up details dialog view.</param>
        /// <param name="selectedCrew"></param>
        /// <param name="arrivalDate"></param>
        /// <param name="departureDate"></param>
        /// <param name="updateAction"></param>
        public void CrewingNavigateUpdateCrewLineUpDetailsDialogView(INavigationContext navigationContext, object selectedCrew, DateTime? arrivalDate, DateTime? departureDate, Action updateAction)
        {
            var parameters = new Dictionary<string, object>()
            {
                {Constants.Entity,selectedCrew},
                {Constants.ArrivalDate,arrivalDate},
                {Constants.DepartureDate,departureDate},
                {Constants.Action,updateAction}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateCrewLineUpDetailsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate update onsigners plan to join dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="arrivalDate">The arrival date.</param>
        /// <param name="departureDate">The departure date.</param>
        /// <param name="updatePlanToJoinDate">The update plan to join date.</param>
        public void CrewingNavigateUpdateOnsignersPlanToJoinDialogView(INavigationContext navigationContext, DateTime? arrivalDate, DateTime? departureDate, Action<DateTime?, bool> updatePlanToJoinDate)
        {
            var parameters = new Dictionary<string, object>()
            {
                {Constants.ArrivalDate,arrivalDate},
                {Constants.DepartureDate,departureDate},
                {Constants.Action,updatePlanToJoinDate},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateOnsignersPlanToJoinDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate experience matrix dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="SelectedVacancy">The selected vacancy.</param>
        /// <param name="isOpenFromPlan">if set to <c>true</c> [is open from plan].</param>
        /// <param name="SelectedTBASlot">The selected tba slot.</param>
        public void CrewingNavigateExperienceMatrixDialogView(INavigationContext navigationContext, string vesselId, string vesselName, CrewListDetail SelectedVacancy, bool isOpenFromPlan, CreateTBASlotDetail SelectedTBASlot)
        {

            var parameters = new Dictionary<string, object>()
            {
                {Constants.VesselId,vesselId},
                {Constants.VesselName,vesselName},
                {Constants.VacancyDetails,SelectedVacancy},
                {Constants.IsOpenFromPlanning,isOpenFromPlan},
                {Constants.SelectedTBASlot, SelectedTBASlot}

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewExperienceMatrixView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate check crew compliance dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CrewingNavigateCheckCrewComplianceDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CheckCrewComplianceDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate crew compliance dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewComplianceParameters">The crew compliance parameters.</param>
        public void CrewingNavigateCrewComplianceDialogView(INavigationContext navigationContext, object crewComplianceParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewComplianceDialogView, navigationContext, crewComplianceParameters);
        }

        /// <summary>
        /// Crewings the navigate verify crew task documents view.
        /// </summary>
        /// <param name="poolId">The pool identifier.</param>
        public void CrewingNavigateVerifyCrewTaskDocumentsView(string poolId)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.VerifyCrewTaskDocumentsView, poolId);
        }

        /// <summary>
        /// navigates to the crews the reject document dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="updateDocumentRejectedReason">The update document rejected reason.</param>
        public void CrewRejectDocumentDialogView(INavigationContext navigationContext, Action<Dictionary<string, object>> updateDocumentRejectedReason)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RejectDocumentDialogView, navigationContext, updateDocumentRejectedReason);
        }

        /// <summary>
        /// Crews the appraisal records dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="crewName"></param>
        /// <param name="setSelectedAppraisal">The set selected appraisal.</param>
        public void CrewAppraisalRecordsDialogView(INavigationContext navigationContext, string crewId, string crewName, Action<object> setSelectedAppraisal)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId,crewId},
                {Constants.OnBoardCrewName,crewName},
                {Constants.Action,setSelectedAppraisal}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewAppraisalRecordsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crews the export and merge documents view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CrewExportAndMergeDocumentsView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExportAndMergeDocumentsView, navigationContext, parameter);
        }

        /// <summary>
        /// Crews the appraisal review view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CrewAppraisalReviewView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.AppraisalReviewView, parameter);
        }

        /// <summary>
        /// Crew Edit Next Assignment Dialog
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="parameter"></param>
        /// <param name="action"></param>
        public void CrewEditNextAssignmentDialog(INavigationContext navigationContext, object parameter, Action<CrewPlanningPreview> action)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.Entity, parameter },
                {Constants.Action, action }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditNextAssignmentDialog, navigationContext, parameters);
        }

        // <summary>
        /// <summary>
        /// Crewings the navigate add mobilisation cell dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="serviceId">The service identifier.</param>
        /// <param name="updateRelieverDetails">The update reliever details.</param>
        public void CrewingNavigateAddMobilisationCellDialogView(INavigationContext navigationContext, string crewId, string serviceId, Action<string, string, string, string> updateRelieverDetails)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.ServiceId, serviceId },
                { Constants.CrewId, crewId },
                { Constants.Action,  updateRelieverDetails}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddMobilisationCellDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// navigates to crews the attachment type dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="selectedDocAttachment">The selected document attachment.</param>
        public void CrewAttachmentTypeDialogView(INavigationContext navigationContext, string crewId, object selectedDocAttachment)
        {
            var parameters = new Dictionary<string, object>
            {
             { Constants.CrewId, crewId },
             { Constants.Entity, selectedDocAttachment }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AttachmentTypeDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Documentses the cloud status view dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void DocumentsCloudStatusViewDialog(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DocumentsCloudStatusView, navigationContext, parameter);
        }

        /// <summary>
        /// Crewing the navigate to add attachment editable dialog view
        /// </summary>
        /// <param name="navigationContext">The navigation context</param>
        /// <param name="fileNames">The file names</param>
        /// <param name="crewId">The crew identifier</param>
        /// <param name="selectedAttachments">The selected attachments</param>
        /// <param name="attachmentParameter">The attachment parameter</param>
        public void CrewingNavigateAddAttachmentEditableDialogView(INavigationContext navigationContext, IEnumerable<string> fileNames, string crewId, object selectedAttachments, object attachmentParameter)
        {
            CrewingNavigateAddAttachmentEditableDialogView(navigationContext, fileNames, crewId, selectedAttachments, attachmentParameter, false);
        }

        /// <summary>
        /// Crewings the navigate add attachment editable dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="selectedAttachments">The selected attachments.</param>
        /// <param name="attachmentParameter">The attachment parameter.</param>
        /// <param name="isLocalSaveMode">if set to <c>true</c> [is local save mode].</param>
        public void CrewingNavigateAddAttachmentEditableDialogView(INavigationContext navigationContext, IEnumerable<string> fileNames, string crewId, object selectedAttachments, object attachmentParameter, bool isLocalSaveMode)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Files, fileNames != null ? fileNames.ToList() : null },
                { Constants.CrewId, crewId },
                { Constants.SelectedAttachments, selectedAttachments },
                { Constants.AttachmentParameter, attachmentParameter },
                { Constants.IsLocalSaveMode, isLocalSaveMode }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAttachmentEditableDialogView, navigationContext, parameters);
        }


        /// <summary>
        /// Crewings the navigate add crew document group filter dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedDocuments">The selected documents.</param>
        /// <param name="lengthOfContract">The length of contract.</param>
        /// <param name="updateCrewDocumentSearchDetails">The update crew document search details.</param>
        public void CrewingNavigateAddCrewDocumentGroupFilterDialogView(INavigationContext navigationContext, SpecialisedObservableCollection<string> selectedDocuments, string lengthOfContract, Action<Dictionary<string, object>> updateCrewDocumentSearchDetails)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SelectedDocuments, selectedDocuments },
                { Constants.Action, updateCrewDocumentSearchDetails},
                { Constants.LOC, lengthOfContract}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewDocumentGroupFilterDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add crew rank group filter dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedRank">The selected rank.</param>
        /// <param name="updateCrewRankSearchDetails">The update crew rank search details.</param>
        public void CrewingNavigateAddCrewRankGroupFilterDialogView(INavigationContext navigationContext, SpecialisedObservableCollection<string> selectedRank, Action<SpecialisedObservableCollection<string>> updateCrewRankSearchDetails)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.SelectedRank, selectedRank },
                {Constants.Action, updateCrewRankSearchDetails }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewRankGroupFilterDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to add edit VMS appraisal dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="appraisalId">The appraisal identifier.</param>
        /// <param name="canViewAppraisal">if set to <c>true</c> [can view appraisal].</param>
        public void CrewingNavigateAddEditVMSAppraisalDialogView(INavigationContext navigationContext, string crewId, string appraisalId, bool canViewAppraisal)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId, crewId },
                {Constants.AppraisalId, appraisalId },
                {Constants.IsInViewMode, canViewAppraisal }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditVMSAppraisalDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate crew list report dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void CrewingNavigateCrewListReportDialogView(INavigationContext navigationContext, string vesselId, string vesselName)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.VesselId, vesselId },
                {Constants.VesselName, vesselName }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewListReportDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate crew compliance tasks dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewComplianceTaksParameters">The crew compliance Task parameters.</param>
        public void CrewingNavigateCrewComplianceTasksDialogView(INavigationContext navigationContext, object crewComplianceTaksParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewComplianceTasksDialogView, navigationContext, crewComplianceTaksParameters);
        }

        /// <summary>
        /// Crewings the navigate export to PDF appraisals view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CrewingNavigateExportToPdfAppraisalsView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExportToPdfAppraisalsView, navigationContext, parameter);
        }

        /// <summary>
        /// Crewings the navigate add tba slots dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedDepartments">The selected departments.</param>
        /// <param name="selectedRanks">The selected ranks.</param>
        /// <param name="selectedRankCategories">The selected rank categories.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void CrewingNavigateAddTBASlotsDialogView(INavigationContext navigationContext, List<string> selectedDepartments, List<string> selectedRanks, List<string> selectedRankCategories, string vesselId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselId, vesselId },
                {Constants.SelectedDepartments, selectedDepartments },
                {Constants.SelectedRank, selectedRanks },
                {Constants.SelectedRankCategories, selectedRankCategories },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddTBASlotsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crews the reject optimiser result dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewsList">The selected crews list.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void CrewRejectOptimiserResultDialogView(INavigationContext navigationContext, List<CrewListDetail> selectedCrewsList, string vesselId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselId, vesselId },
                {Constants.Crew, selectedCrewsList}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RejectOptimiserResultDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add edit foreign details dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddEditForeignDetailsDialogView(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditForeignDetailsView, context, parameters);
        }

        /// <summary>
        /// Navigates the crew contract selection dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateCrewContractSelectionDialog(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewContractSelectionDialogView, context, parameters);
        }

        /// <summary>
        /// Crewings the navigate add edit foreign address view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void CrewingNavigateAddEditForeignAddressView(INavigationContext navigationContext, string crewId, object entity, bool isInViewMode)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                { Constants.CrewId, crewId },
                { Constants.IsInViewMode, isInViewMode },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditForeignAddressView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the re assign SFC dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedCrewId">The selected crew identifier.</param>
        public void NavigateReAssignSFCDialogView(INavigationContext context, List<string> selectedCrewId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReAssignSFCDialogView, context, selectedCrewId);
        }

        /// <summary>
        /// Navigates the re assign mobilisation cell dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedCrewIds">The selected crew ids.</param>
        /// <param name="loginUserMobilisationCellList">The login user mobilisation cell list.</param>
        public void NavigateReAssignMobilisationCellDialogView(INavigationContext context, List<string> selectedCrewIds, List<Lookup> loginUserMobilisationCellList)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SelectedCrewList, selectedCrewIds },
                { Constants.LoginUserMobilisationCellList, loginUserMobilisationCellList },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReAssignMobilisationCellDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the re assign planning cell dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedCrewIds">The selected crew ids.</param>
        /// <param name="loginUserPlanningCellList">The login user planning cell list.</param>
        public void NavigateReAssignPlanningCellDialogView(INavigationContext context, List<string> selectedCrewIds, List<Lookup> loginUserPlanningCellList)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SelectedCrewList, selectedCrewIds },
                { Constants.LoginUserPlanningCellList, loginUserPlanningCellList },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReAssignPlanningCellDialogView, context, parameters);
        }


        /// <summary>
        /// Crewings the navigate plan from working list.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewListDetails">The crew list details.</param>
        public void CrewingNavigatePlanFromWorkingList(INavigationContext navigationContext, List<CrewListDetail> crewListDetails)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PlanFromWorkingListView, navigationContext, crewListDetails);
        }

        /// <summary>
        /// Crewings the navigate plan previously onboard.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewListDetails">The crew list details.</param>
        public void CrewingNavigatePlanPreviouslyOnboard(INavigationContext navigationContext, List<CrewListDetail> crewListDetails)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PlanPreviouslyOnboardView, navigationContext, crewListDetails);
        }

        /// <summary>
        /// Crewings the navigate delete tba slots dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CrewingNavigateDeleteTBASlotsDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DeleteTBASlotsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Crewings the navigate configure slot loc.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewListDetail">The crew list detail.</param>
        public void CrewingNavigateConfigureSlotLOC(INavigationContext navigationContext, CrewListDetail crewListDetail)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ConfigureSlotLOCView, navigationContext, crewListDetail);
        }


        /// <summary>
        /// Navigates the crew contract wages dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateCrewContractWagesDialogView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewWagesDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to add recruited crew dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAddRecruitedCrewDialogView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddRecruitedCrewDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to edit crew recruitment status dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToEditCrewRecruitmentStatusDialogView(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewRecruitmentStatusDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to crew basic detail dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="crewId"></param>
        public void NavigateToCrewBasicDetailDialogView(INavigationContext context, string crewId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewBasicDetailDialogView, context, crewId);
        }

        /// <summary>
        /// Navigates to update crew requirement status view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isCrewStatusUpdated">The is crew status updated.</param>
        public void NavigateToUpdateCrewRequirementStatusView(INavigationContext navigationContext, object parameter, Action<bool, bool> isCrewStatusUpdated)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Parameter, parameter },
                { Constants.Action, isCrewStatusUpdated },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateCrewRequirementStatusView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to assign policy dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAssignPolicyDialogView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AssignPolicyDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to assignment email dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAssignmentEmailDialog(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AssignmentEmailDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to assignment email send grid dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAssignmentEmailSendGridDialog(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AssignmentEmailSendGridDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to add edit crew generic appraisal dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditCrewGenericAppraisalDialog(INavigationContext context, CrewGenericAppraisalNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewGenericAppraisalDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to approve appraisal review dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToApproveAppraisalReviewDialog(INavigationContext context, ApproveAppraisalNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ApproveAppraisalReviewDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to cancel policy assignment dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="policyAssignmentId">The policy assignment identifier.</param>
        public void NavigateToCancelPolicyAssignmentDialog(INavigationContext context, string policyAssignmentId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CancelPolicyAssignmentDialogView, context, policyAssignmentId);
        }

        /// <summary>
        /// Navigates to compliance template details dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToComplianceTemplateDetailsDialog(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ComplianceTemplateDetailsDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to image editor tool dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToImageEditorToolDialog(INavigationContext context, ImageEditorNavParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImageEditorToolDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to crew confirmation dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToCrewConfirmationDialog(INavigationContext context, CrewConfirmationDialogParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewConfirmationDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to gantt view dialog.
        /// </summary>
        public void NavigateToGanttViewDialog()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.GanttViewForMultipleVesselStartView);
        }

        /// <summary>
        /// Navigates to download as document dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToDownloadAsDocumentDialog(INavigationContext context, CrewDownloadAsParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DownloadAsDocumentView, context, parameter);
        }

        /// <summary>
        /// Navigates to remove PDF pages dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToRemovePdfPagesDialog(INavigationContext context, CrewRemovePdfPagesParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewRemovePdfPagesView, context, parameter);
        }

        /// <summary>
        /// Navigates to previous versions of document dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToPreviousVersionsOfDocumentDialog(INavigationContext context, PreviousVersionsOfDocumentParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PreviousVersionsOfDocumentView, context, parameter);
        }

        /// <summary>
        /// Navigates to update requirement status.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requirementId">The requirement identifier.</param>
        /// <param name="allCandidatesAreRejected">if set to <c>true</c> [all candidates are rejected].</param>
        /// <param name="recruitmentStatusUpdated">The recruitment status updated.</param>
        /// <param name="isBerthAutoApprove">if set to <c>true</c> [is berth automatic approve].</param>
        public void NavigateToUpdateRequirementStatus(INavigationContext navigationContext, string requirementId, bool allCandidatesAreRejected, Action<bool> recruitmentStatusUpdated, bool isBerthAutoApprove)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.RequirementId, requirementId },
                { Constants.AllCandidatesAreRejected, allCandidatesAreRejected },
                { Constants.Action, recruitmentStatusUpdated },
                { Constants.IsBerthAutoApprove, isBerthAutoApprove}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateRequirementStatusView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add recruitement cancel notes dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="addCancellationNotes">The add cancellation notes.</param>
        /// <param name="isBerthAutoApprove">if set to <c>true</c> [is berth automatic approve].</param>
        public void CrewingNavigateAddRecruitementCancelNotesDialogView(INavigationContext navigationContext, Action<string, int?> addCancellationNotes, bool isBerthAutoApprove)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Action, addCancellationNotes},
                { Constants.IsBerthAutoApprove, isBerthAutoApprove}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddRecruitementCancelNotesDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to my rank groups.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMyRankGroups(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UserRankGroupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit de briefing view.
        /// </summary>
        /// <param name="crewDetails">The crew details.</param>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToAddEditDeBriefingView(object crewDetails, INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditDebriefingDialogView, navigationContext, crewDetails);
        }


        /// <summary>
        /// Navigates to revise contract confirmation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="seniortyUpdate">The seniorty update.</param>
        public void NavigateToReviseContractConfirmationView(INavigationContext navigationContext, Action<Dictionary<string, object>> seniortyUpdate)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Action, seniortyUpdate}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReviseContractConfirmationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to contract log dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="contractId">The contract identifier.</param>
        public void NavigateToContractLogDialog(INavigationContext context, string contractId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ContractLogDialogView, context, contractId);
        }

        /// <summary>
        /// Navigates to signing entity dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="signingEntity">The signing entity.</param>
        public void NavigateToSigningEntityDialog(INavigationContext context, object signingEntity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SigningEntitiesDialogView, context, signingEntity);
        }

        /// <summary>
        /// Navigates to condition of service dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToConditionOfServiceDialog(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ConditionOfServiceDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the knowledge skills view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateKnowledgeSkillsView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewKnowledgeDescriptionNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit appraisal view.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAddEditAppraisalView(CrewOnboardCrewingStartParameter parameters)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.CrewAddEditOnboardAppraisalView, parameters);
        }

        /// <summary>
        /// Navigates to add edit onboard appraisal view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditOnboardAppraisalView(object parameter)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.CrewAddEditOnboardAppraisalView, parameter);
        }

        /// <summary>
        /// Navigates to add objective.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedObjective">The selected objective.</param>
        /// <param name="objId">The object identifier.</param>
        /// <param name="isReview">The is review.</param>
        public void NavigateToAddObjective(INavigationContext navigationContext, object selectedObjective, int? objId, string isReview)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedObjective, selectedObjective },
                { NavigationParameterConstant.IsReview, isReview },
                { NavigationParameterConstant.ObjId, objId },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewAddObjectiveNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to active objective.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        public void NavigateToActiveObjective(INavigationContext navigationContext, string crewId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewActiveObjectiveNavigationView, navigationContext, crewId);
        }

        /// <summary>
        /// Navigates to active training.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewDetails">The crew details.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateToActiveTraining(INavigationContext navigationContext, AppraisalCrewDetailResponse crewDetails, string vesselName)
        {
            var parameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.CrewDetails, crewDetails },
                { NavigationParameterConstant.VesselName, vesselName },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewActiveTrainingNeedsNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Reopens the appraisal navigation.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter">The parameter.</param>
        public void ReopenAppraisalNavigation(INavigationContext context, CrewOnboardCrewingStartParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewReopenAppraisalNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add training view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="trainingNeeds">The training needs.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddTrainingView(INavigationContext navigationContext, AppraisalTrainingNeeds trainingNeeds, CrewOnboardCrewingStartParameter parameter)
        {
            Dictionary<string, object> TrainingNeedParameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.TrainingNeeds, trainingNeeds },
                { NavigationParameterConstant.TrainingNeedsParameter, parameter }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewAddTrainingNeedsNavigationView, navigationContext, TrainingNeedParameter);
        }

        /// <summary>
        /// Navigates to appraisal attachments.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAppraisalAttachments(INavigationContext context, CrewOnboardCrewingStartParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewAddEditAppraisalAttachmentsView, context, parameter);
        }

        /// <summary>
        /// Navigates to alert save dialog view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAlertSaveDialogView(INavigationContext navigation, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AlertSaveDialogView, navigation, parameter);
        }

        /// <summary>
        /// Navigates to open payperiod list dialog view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToOpenPayperiodListDialogView(INavigationContext navigation, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OpenPayperiodListDialogView, navigation, parameter);
        }

        /// <summary>
        /// Navigates to promote or tranfer crew view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="selectedBerths">The selected berths.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateToPromoteOrTranferCrewView(INavigationContext navigation, string vesselName, List<CrewListDetail> selectedBerths, string vesselId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.VesselName, vesselName },
                { Constants.SelectedBerths,selectedBerths },
                { Constants.VesselId, vesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PromoteOrTransferCrew, navigation, parameters);
        }

        /// <summary>
        /// Navigates the t add edit joining briefing dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateTAddEditJoiningBriefingDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditJoiningBriefingView, context, parameter);
        }

        /// <summary>
        /// Navigates the add edit document vaccine dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddEditDocumentVaccineDialogView(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewDocumentVaccineDetailsView, context, parameter);
        }

        /// <summary>
        /// Navigates objective history view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="objectiveId">The objective identifier.</param>
        /// <param name="objectiveName">Name of the objective.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateObjectiveHistoryView(INavigationContext context, string objectiveId, string objectiveName, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.ObjectiveId, objectiveId},
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.ObjectiveName, objectiveName}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OfficeObjectiveReviewHistoryNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit crew16 view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAddEditCrewInterviewDetailView(INavigationContext context, CrewInterviewNavParam parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AddEditCrewInterviewDetailView, parameters);
        }

        /// <summary>
        /// Crewings the navigate seafarer notification dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="notificationId">The notification identifier.</param>
        /// <param name="isCrewUsingMobileApp">if set to <c>true</c> [is crew using mobile application].</param>
        /// <param name="crewFullName">Full name of the crew.</param>
        public void CrewingNavigateSeafarerNotificationDialog(INavigationContext navigationContext, string crewId, string notificationId, bool isCrewUsingMobileApp, string crewFullName)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId,crewId},
                {Constants.NotificationId,notificationId },
                {Constants.IsCrewUsingMobileApp,isCrewUsingMobileApp },
                {Constants.OnBoardCrewName,crewFullName }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditSeafarerNotificationsDialogView, navigationContext, parameters);
        }


        /// <summary>
        /// Navigates the crew search experiance dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="filters">The filters.</param>
        public void NavigateCrewSearchExperianceDialogView(INavigationContext context, object filters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewSearchExperianceDialogView, context, filters);
        }

        /// <summary>
        /// Navigates to exclude automatic assigned template view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToExcludeAutoAssignedTemplateView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExcludeAutoAssignedTemplateView, context, parameters);
        }

        /// <summary>
        /// Crewings the navigate add crew excluded rank group filter dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedRank">The selected rank.</param>
        /// <param name="updateCrewRankSearchDetails">The update crew rank search details.</param>
        public void CrewingNavigateAddCrewExcludedRankGroupFilterDialogView(INavigationContext navigationContext, string vesselId, SpecialisedObservableCollection<string> selectedRank, Action<SpecialisedObservableCollection<string>> updateCrewRankSearchDetails)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.VesselId, vesselId },
                {Constants.SelectedRank, selectedRank },
                {Constants.Action, updateCrewRankSearchDetails }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewExcludeRankGroupFilterDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to add osa missing remarks view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddOsaMissingRemarksView(INavigationContext context, CrewNavParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddOsaMissingRemarksView, context, parameter);
        }

        /// <summary>
        /// Navigates to linked service details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="selectedService">The selected service.</param>
        public void NavigateToLinkedServiceDetailsView(INavigationContext context, string crewId, object selectedService)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId, crewId },
                {Constants.SelectedRecord, selectedService }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkedServiceDetailsView, context, parameters);
        }

        /// <summary>
        /// Navigates to fly2c book tickets preview dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToFly2cBookTicketsPreviewDialog(INavigationContext context, CrewNavParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.Fly2cBookTicketsPreviewDialog, context, parameter);
        }

        /// <summary>
        /// Navigates to crew hazocc details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="signOnDate">The sign on date.</param>
        /// <param name="signOffDate">The sign off date.</param>
        /// <param name="setCrewHazoccDetail">The set crew hazocc detail.</param>
        public void NavigateToCrewHazoccDetailsView(INavigationContext context, string crewId, DateTime? signOnDate, DateTime? signOffDate, Action<object> setCrewHazoccDetail)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CrewId, crewId },
                {Constants.ServiceStartDate, signOnDate },
                {Constants.ServiceEndDate, signOffDate },
                { Constants.SetCrewHazoccDetail, setCrewHazoccDetail },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewHazoccRecordsDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to medical history view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateToMedicalHistoryView(INavigationContext context)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.MedicalHistoryView, context);
        }

        /// <summary>
        /// Navigates to export crew list to fidelio dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToExportCrewListToFidelioDialog(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewListExportToFidelioView, context, parameters);
        }

        /// <summary>
        /// Opens the approve dispensation view
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CrewDispensationApproveView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ApproveDispensationView, parameter);
        }

        /// <summary>
        /// Navigates to add crew mobilisation checklist manual checks dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddCrewMobilisationChecklistManualChecksDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddMobilisationChecklistManualChecksDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add edit centralised request view dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditCentralisedRequestViewDialogView(INavigationContext context, CrewNavParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCentralisedRequestView, context, parameter);
        }

        /// <summary>
        /// Navigates to crew log details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="logRequest">The log request.</param>
        public void NavigateToCrewLogDetailsView(INavigationContext context, CrewingLogDetailsRequest logRequest)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewLogDetailsView, context, logRequest);
        }

        /// <summary>
        /// Navigates to re assign technical fleet dialog view model.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToReAssignTechnicalFleetDialogViewModel(INavigationContext context, CrewNavParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReAssignTechnicalFleetDialogView, context, parameter);
        }
    }
}