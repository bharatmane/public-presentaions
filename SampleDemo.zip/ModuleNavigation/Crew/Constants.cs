﻿namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Names of accessible views and regions related to the crew module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "Crew";

        /// <summary>
        /// The name of the common module.
        /// </summary>
        public const string CommonModuleName = "Common";

        /// <summary>
        /// The crew list
        /// </summary>
        public const string CrewList = "Crew List";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "CrewGeometry";

        /// <summary>
        /// The crew lineup geometry
        /// </summary>
        public const string CrewLineupGeometry = "CrewLineupGeometry";

        /// <summary>
        /// The crew list geometry
        /// </summary>
        public const string CrewListGeometry = "CrewListGeometry";

        /// <summary>
        /// The crew search geometry
        /// </summary>
        public const string CrewSearchGeometry = "CrewSearchGeometry";
        //Views

        /// <summary>The landing or start view for the certificates module.</summary>
        public const string StartView = "CrewStartView";

        /// <summary>The Crew Search View.</summary>
        public const string CrewSearchView = "CrewSearchView";

        /// <summary>The Crew Member Validation View.</summary>
        public const string NewCrewMemberValidationView = "New Crew Member Validation";

        /// <summary>The Crew Member Biodataview.</summary>
        public const string CrewSummaryView = "CrewStartMainView";

        /// <summary>The Crew Member ContactDetailsView    /// </summary>
        public const string ContactDetailsView = "ContactDetailView";

        /// <summary>The Crew Member CreateCVView    /// </summary>
        public const string CreateMemberCv = "CreateMemberCvView";

        /// <summary>
        /// The bio data main view
        /// </summary>
        public const string BioDataMainView = "BioDataMainView";

        /// <summary>
        /// The bio data nav item
        /// </summary>
        public const string BioDataNavItem = "BioDataNavItem";

        /// <summary>
        /// The add next of kin view
        /// </summary>
        public const string AddNextOfKinView = "AddNextOfKinView";

        /// <summary>
        /// The add edit address view
        /// </summary>
        public const string AddEditAddressView = "AddEditAddressView";

        /// <summary>
        /// The add edit contact view
        /// </summary>
        public const string AddEditContactView = "AddEditContactView";

        /// <summary>
        /// The next of kin attachment add view
        /// </summary>
        public const string NextOfKinAttachmentAddEditView = "NextOfKinAttachmentAddView";

        /// <summary>
        /// The attachment add view
        /// </summary>
        public const string AttachmentAddView = "AttachmentAddView";

        /// <summary>
        /// The documents add view
        /// </summary>
        public const string DocumentsAddEditView = "DocumentsAddView";

        /// <summary>
        /// The attributes dialog view
        /// </summary>
        public const string AttributesDialogView = "AttributesDialogView";

        /// <summary>
        /// The service and summary dialog view
        /// </summary>
        public const string ServiceAndSummaryDialogView = "ServiceAndSummaryDialogView";

        /// <summary>
        /// The crew list start view
        /// </summary>
        public const string CrewListStartView = "CrewListStartView";

        /// <summary>
        /// The overlapping service records dialog view
        /// </summary>
        public const string OverlappingServiceRecordsDialogView = "OverlappingServiceRecordsDialogView";

        /// <summary>
        /// The appraisal add edit view
        /// </summary>
        public const string AppraisalAddEditView = "AppraisalAddEditView";

        /// <summary>
        /// The add external appraisal view
        /// </summary>
        public const string AddExternalAppraisalView = "AddExternalAppraisalView";

        /// <summary>
        /// The add edit berth dialog view
        /// </summary>
        public const string AddEditBerthDialogView = "AddEditBerthDialogViewModel";

        /// <summary>
        /// The import budgeted crew list dialog view
        /// </summary>
        public const string ImportBudgetedCrewListDialogView = "ImportBudgetedCrewListDialogView";

        /// <summary>
        /// The email dialog view model
        /// </summary>
        public const string EmailDialogViewModel = "EmailDialogViewModel";

        /// <summary>
        /// The user vessel lookup view
        /// </summary>
        public const string UserVesselLookupView = "UserVesselLookupView";

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";

        /// <summary>
        /// The is budgeted berth exists
        /// </summary>
        public const string IsBudgetedBerthExists = "IsBudgetedBerthExists";

        /// <summary>
        /// The propose start view
        /// </summary>
        public const string ProposeView = "ProposeView";

        /// <summary>
        /// The document maintainer
        /// </summary>
        public const string DocumentMaintainer = "Document Maintainer";

        /// <summary>
        /// The document maintainer view
        /// </summary>
        public const string DocumentMaintainerView = "DocumentMaintainerStartView";

        /// <summary>
        /// The document geometry
        /// </summary>
        public const string DocumentGeometry = "DocumentGeometry";

        /// <summary>
        /// The line up satrt view
        /// </summary>
        public const string LineUpSatrtView = "LineUpStartView";

        /// <summary>
        /// The position list dialog view
        /// </summary>
        public const string PositionListDialogView = "PositionListDialogView";

        /// <summary>
        /// The line up add crew
        /// </summary>
        public const string LineUpAddCrew = "LineUpAddCrewView";

        /// <summary>
        /// The add edit planning details dialog view
        /// </summary>
        public const string AddEditPlanningDetailsDialogView = "AddEditPlanningDetailsDialogView";

        /// <summary>
        /// The add edit scheduled contact view
        /// </summary>
        public const string AddEditScheduledContactView = "AddEditScheduledContactView";

        /// <summary>
        /// The add edit line up view
        /// </summary>
        public const string AddEditLineUpView = "AddEditLineUpView";
        /// <summary>
        /// The vacancy details
        /// </summary>
        public const string VacancyDetails = "VacancyDetails";

        /// <summary>
        /// The is open from planning
        /// </summary>
        public const string IsOpenFromPlanning = "IsOpenFromPlanning";

        /// <summary>
        /// The selected tba slot
        /// </summary>
        public const string SelectedTBASlot = "SelectedTBASlot";

        /// <summary>
        /// The crew record
        /// </summary>
        public const string CrewRecord = "CrewRecord";

        /// <summary>
        /// The crew bio data record
        /// </summary>
        public const string CrewBioDataRecord = "CrewBioDataRecord";

        /// <summary>
        /// The update onboard record dialog view
        /// </summary>
        public const string UpdateOnboardRecordDialogView = "UpdateOnboardRecordDialogView";

        /// <summary>
        /// The crew maintenance
        /// </summary>
        public const string CrewMaintenance = "Crew Maintenance";

        /// <summary>
        /// The crew type owner crew
        /// </summary>
        public const string CrewTypeOwnerCrew = "Owner";

        /// <summary>
        /// The time line quarter
        /// </summary>
        public const string TimeLineQuarter = "Q";

        /// <summary>
        /// The time line month
        /// </summary>
        public const string TimeLineMonth = "M";

        /// <summary>
        /// The time line week
        /// </summary>
        public const string TimeLineWeek = "W";

        /// <summary>
        /// The crew change view
        /// </summary>
        public const string CrewChangeView = "CrewChangeView";

        /// <summary>
        /// The relief history view
        /// </summary>
        public const string ReliefHistoryView = "ReliefHistoryView";

        /// <summary>
        /// The lineup identifier
        /// </summary>
        public const string LineupId = "LineupId";
        
        /// <summary>
        /// The vessel name
        /// </summary>
        public const string VesselName = "VesselName";

        /// <summary>
        /// The vessel
        /// </summary>
        public const string Vessel = "Vessel";
        /// <summary>
        /// The rank name
        /// </summary>
        public const string RankName = "RankName";

        /// <summary>
        /// The rank
        /// </summary>
        public const string Rank = "Rank";

        /// <summary>
        /// The data grid
        /// </summary>
        public const string DataGrid = "DataGrid";

        /// <summary>
        /// The selected crew members
        /// </summary>
        public const string SelectedBerths = "SelectedBerths";

        /// <summary>
        /// The set port agent method
        /// </summary>
        public const string SetPortAgentMethod = "SetPortAgentMethod";

        /// <summary>
        /// The lineup detail
        /// </summary>
        public const string LineupDetail = "LineupDetail";

        /// <summary>
        /// The is navigated from superintendent dash board
        /// </summary>
        public const string IsNavigatedFromSuperintendentDashBoard = "IsNavigatedFromSuperintendentDashBoard";

        /// <summary>
        /// The status applicant
        /// </summary>
        public const string StatusApplicant = "AP";

        /// <summary>
        /// The status briefing
        /// </summary>
        public const string StatusBriefing = "B";

        /// <summary>
        /// The satus seminar
        /// </summary>
        public const string SatusSeminar = "S";

        /// <summary>
        /// The get selected onsigner offsigner
        /// </summary>
        public const string GetSelectedOnsignerOffsigner = "SelectedOnsignerOffsigner";


        /// <summary>
        /// The lineup nav item view
        /// </summary>
        public const string LineupNavItemView = "LineupNavItemView";

        /// <summary>
        /// The crew identifier
        /// </summary>
        public const string CrewId = "CrewId";

        /// <summary>
        /// The policy assignment identifier
        /// </summary>
        public const string PolicyAssignmentId = "PolicyAssignmentId";

        /// <summary>
        /// The nok identifier
        /// </summary>
        public const string NokId = "NokId";

        /// <summary>
        /// The update summary panel method
        /// </summary>
        public const string UpdateSummaryPanelMethod = "UpdateSummaryPanelMethod";

        /// <summary>
        /// The timeline record type service
        /// </summary>
        public const string TimelineRecordTypeService = "Service";

        /// <summary>
        /// The timeline record type event
        /// </summary>
        public const string TimelineRecordTypeEvent = "Event";

        /// <summary>
        /// The user vessel groups view
        /// </summary>
        public const string UserVesselGroupsView = "UserVesselGroupsView";

        /// <summary>
        /// The crew service status overdue
        /// </summary>
        public const string CrewServiceStatusOverdue = "Overdue";

        /// <summary>
        /// The crew overdue status identifier
        /// </summary>
        public const string CrewOverdueStatusId = "OD";

        /// <summary>
        /// The crew overdue type major
        /// </summary>
        public const string CrewOverdueTypeMajor = "MajorOverdue";

        /// <summary>
        /// The crew overdue type minor
        /// </summary>
        public const string CrewOverdueTypeMinor = "MinorOverdue";

        /// <summary>
        /// The age calculation constant
        /// </summary>
        public const double AgeCalculationConstant = 1/365.242199;

        /// <summary>
        /// The update header details
        /// </summary>
        public const string UpdateCrewHeaderDetails = "UpdateCrewHeaderDetails";

        /// <summary>
        /// The port detail
        /// </summary>
        public const string PortDetail = "PortDetail";

        /// <summary>
        /// The crew full name format
        /// The format for crew name should be- Lastname, FirstName MiddleName.
        /// </summary>
        public const string CrewFullNameFormat = "{0}, {1} {2}";

        /// <summary>
        /// The overlap detail
        /// </summary>
        public const string OverlapDetail = "OverlapDetail";

        /// <summary>
        /// The is over lap detail exists
        /// </summary>
        public const string IsOverlapDetailExists = "IsOverlapDetailExists";

        /// <summary>
        /// The set onboard detail
        /// </summary>
        public const string SetOnboardDetail = "SetOnboardDetail";

        /// <summary>
        /// The one service day constant
        /// </summary>
        public const int OneServiceDayConstant = 1;

        /// <summary>
        /// The entity
        /// </summary>
        public const string Entity = "Entity";

        /// <summary>
        /// The user task list
        /// </summary>
        public const string UserTaskList = "UserTaskList";

        /// <summary>
        /// The is change owner
        /// </summary>
        public const string IsChangeOwner = "IsChangeOwner";

        /// <summary>
        /// The parent identifier
        /// </summary>
        public const string ParentId = "ParentId";

        /// <summary>
        /// The tpa details
        /// </summary>
        public const string TPADetails = "TPADetails";

        /// <summary>
        /// The crew fore name
        /// </summary>
        public const string CrewForeName = "CrewForeName";

        /// <summary>
        /// The crew sur name
        /// </summary>
        public const string CrewSurName = "CrewSurName";

        /// <summary>
        /// The crew vessel contract
        /// </summary>
        public const string CrewVesselContract = "Crew Contract";

        /// <summary>
        /// The contract start view
        /// </summary>
        public const string CrewContractView = "CrewContractView";

        /// <summary>
        /// The edit change contract view
        /// </summary>
        public const string EditChangeContractView = "EditChangeContractView";

        /// <summary>
        /// The crew lookup view
        /// </summary>
        public const string CrewLookupView = "CrewLookupView";

        /// <summary>
        /// The nationality
        /// </summary>
        public const string Nationality = "Nationality";

        /// <summary>
        /// The rank identifier
        /// </summary>
        public const string RankId = "RankId";

        /// <summary>
        /// The wage group type identifier
        /// </summary>
        public const string WageGroupTypeId = "WageGroupTypeId";

        /// <summary>
        /// The add edit crew image dialog view
        /// </summary>
        public const string AddEditCrewImageDialogView = "AddEditCrewImageDialogView";

        /// <summary>
        /// The service identifier
        /// </summary>
        public const string ServiceId = "ServiceId";

        /// <summary>
        /// The service status identifier
        /// </summary>
        public const string ServiceStatusId = "ServiceStatusId";

        /// <summary>
        /// The due date
        /// </summary>
        public const string DueDate = "DueDate";

        /// <summary>
        /// The access code
        /// </summary>
        public const string AccessCode = "AccessCode";

        /// <summary>
        /// The policy assignment email URL
        /// </summary>
        public const string PolicyAssignmentEmailUrl = "PolicyAssignmentEmailUrl";

        /// <summary>
        /// The contract identifier
        /// </summary>
        public const string ContractId = "ContractId";

        /// <summary>
        /// The is crew onboard
        /// </summary>
        public const string IsContractSigned = "IsContractSigned";

        /// <summary>
        /// The action
        /// </summary>
        public const string Action = "Action";

        /// <summary>
        /// The action on cancel
        /// </summary>
        public const string ActionOnCancel = "ActionOnCancel";

        /// <summary>
        /// The payscale status personalize
        /// </summary>
        public const string PayscaleStatusPersonalize = "Personalised";

        /// <summary>
        /// The payscalestatus system
        /// </summary>
        public const string PayscalestatusSystem = "System";

        /// <summary>
        /// The search text
        /// </summary>
        public const string SearchText = "SearchText";


        /// <summary>
        /// The attribute value identifier
        /// </summary>
        public const string AttributeValueId = "AttributeValueId";

        /// <summary>
        /// The files
        /// </summary>
        public const string Files = "Files";

        /// <summary>
        /// The is show category type
        /// </summary>
        public const string IsShowCategoryType = "IsShowCategoryType";

        /// <summary>
        /// The attachment parameter
        /// </summary>
        public const string AttachmentParameter = "AttachmentParameter";

        /// <summary>
        /// The attachment edit view
        /// </summary>
        public const string AttachmentEditView = "AttachmentEditView";

        /// <summary>
        /// The view geometry
        /// </summary>
        public const string ViewGeometry = "ViewGeometry";

        /// <summary>
        /// The excel export geometry
        /// </summary>
        public const string ExcelExportGeometry = "ExcelExportGeometry";

        /// <summary>
        /// The nan manager geometry
        /// </summary>
        public const string NANManagerGeometry = "NANManagerGeometry";

        /// <summary>
        /// The send signature email view
        /// </summary>
        public const string SendSignatureEmailView = "SendSignatureEmailView";

        /// <summary>
        /// The crew email identifier
        /// </summary>
        public const string CrewEmailId = "CrewEmailId";

        /// <summary>
        /// The manager email identifier
        /// </summary>
        public const string ManagerEmailId = "ManagerEmailId";

        /// <summary>
        /// The document
        /// </summary>
        public const string Document = "Document";

        /// <summary>
        /// The API key for hello sign
        /// </summary>
        public const string ApiKeyForHelloSign = "ecd208e8a3205ec66dd34400c1521fe7d5e69727e0391e874877f0523ea35acb";

        /// <summary>
        /// The e signature title
        /// </summary>
        public const string eSignatureTitle = "Crew Contract e-Signature";

        /// <summary>
        /// The signer1
        /// </summary>
        public const string Signer1 = "Signer 1";

        /// <summary>
        /// The signer2
        /// </summary>
        public const string Signer2 = "Signer 2";

        /// <summary>
        /// The crew
        /// </summary>
        public const string Crew = "Crew";

        /// <summary>
        /// The manager
        /// </summary>
        public const string Manager = "Manager";

        /// <summary>
        /// The subject content
        /// </summary>
        public const string SubjectContent = "e-Signing of Contract";

        /// <summary>
        /// The crew email address
        /// </summary>
        public const string CrewEmailAddress = "CrewEmailAddress";

        /// <summary>
        /// The manager email address
        /// </summary>
        public const string ManagerEmailAddress = "ManagerEmailAddress";

        /// <summary>
        /// The length of contract
        /// </summary>
        public const string LOC = "LOC";

        // <summary>
        /// The length of contract unit
        /// </summary>
        public const string LOCUnit = "LOCUnit";

        /// <summary>
        /// The duration
        /// </summary>
        public const string Duration = "Duration";

        /// <summary>
        /// The system constant
        /// </summary>
        public const string System = "System";

        /// <summary>
        /// The planning status comment view
        /// </summary>
        public const string PlanningStatusCommentView = "PlanningStatusCommentView";

        /// <summary>
        /// The selected status
        /// </summary>
        public const string SelectedStatus = "SelectedStatus";

        /// <summary>
        /// The constant for zero value
        /// </summary>
        public const string DropdownDefaultValue = "0";

        /// <summary>
        /// The contract template identifier
        /// </summary>
        public const string ContractTemplateId = "ContractTemplateId";

        /// <summary>
        /// The contract upload file types
        /// </summary>
        public const string ContractUploadFileTypes = "Pdf Files (*.pdf)|*.pdf|Word Document Files (.docx)|*.docx|Word Document Files (.doc)|*.doc|All Files|*.pdf;*.docx;*.doc;";

        /// <summary>
        /// The image upload file types
        /// </summary>
        public const string ImageUploadFileTypes = "JPG Files (.jpg)|*.jpg|bmp files (.bmp)|*.bmp|png files (.png)|*.png|All Files|*.jpg;*.bmp;*.png";

        /// <summary>
        /// The menu item view
        /// </summary>
        public const string MenuItemView = "View";

        /// <summary>
        /// The menu item edit
        /// </summary>
        public const string MenuItemEdit = "Edit";

        /// <summary>
        /// The menu item delete
        /// </summary>
        public const string MenuItemDelete = "Delete";

        /// <summary>
        /// The menu item previous versions
        /// </summary>
        public const string MenuItemPreviousVersions = "Previous Versions";

        /// <summary>
        /// The menu item downlaod as
        /// </summary>
        public const string MenuItemDownlaodAs = "Download As";

        /// <summary>
        /// The menu item edit file
        /// </summary>
        public const string MenuItemEditFile = "Edit File";

        /// <summary>
        /// The menu item split pages
        /// </summary>
        public const string MenuItemSplitPages = "Split PDF Pages";

        /// <summary>
        /// The menu item remove pages
        /// </summary>
        public const string MenuItemRemovePages = "Remove PDF Pages";

        /// <summary>
        /// The add edit Crew availability view
        /// </summary>
        public const string AddEditCrewAvailabilityDialogView = "AddEditCrewAvailabilityDialogView";

        /// <summary>
        /// The add edit travel view
        /// </summary>
        public const string AddEditTravelDialogView = "AddEditTravelDialogView";


        /// <summary>
        /// The link assignment dialog view
        /// </summary>
        public const string LinkAssignmentDialogView = "LinkAssignmentDialogView";


        /// <summary>
        /// The task manager start view
        /// </summary>
        public const string TaskManagerStartView = "TaskManagerStartView";

        /// <summary>
        /// The add edit loi dialog view
        /// </summary>
        public const string AddEditLOIDialogView = "AddEditLOIDialogView";

        /// <summary>
        /// The create nan
        /// </summary>
        public const string CreateLOI = "Create NAN";

        /// <summary>
        /// The nan awaiting response
        /// </summary>
        public const string LOIAwaitingResponse = "NAN Awaiting Response";

        /// <summary>
        /// The nan awaiting response
        /// </summary>
        public const string LOIReadBySeafarer = "NAN Read By Seafarer";

        /// <summary>
        /// The nan accepted
        /// </summary>
        public const string LOIAccepted = "NAN Accepted";

        /// <summary>
        /// The nan rejected
        /// </summary>
        public const string LOIRejected = "NAN Rejected";

        /// <summary>
        /// The select seafarer dialog view
        /// </summary>
        public const string SelectSeafarerDialogView = "SelectSeafarerDialogView";

        /// <summary>
        /// The add edit crew task dialog view
        /// </summary>
        public const string AddEditCrewTaskDialogView = "AddEditCrewTaskDialogView";

        /// <summary>
        /// The hello sign default message
        /// </summary>
        public const string HelloSignDefaultMessage = "Crew Mobilization has requested your signature. Message from Crew Mobilization:<br><br>{0}<br><br>Please click the Review and Sign link below to sign the document.<br><a href='{1}'>Review and Sign</a><br> Thanks, <br>Crew Mobilization";

        /// <summary>
        /// The hello sign review and sign anchor tag
        /// </summary>
        public const string HelloSignReviewAndSignAnchorTag = "<a href='{0}'>Review and Sign</a>";

        /// <summary>
        /// The hello sign signing URL identifier
        /// </summary>
        public const string HelloSignSigningURLIdentifier = "__signingURL";

        /// <summary>
        /// the hello sign crew name identifier
        /// </summary>
        public const string HelloSignCrewNameIdentifier = "__crewName";

        /// <summary>
        /// The assign email crew name
        /// </summary>
        public const string AssignEmailCrewName = "##CREWNAME##";

        /// <summary>
        /// The assign email due date
        /// </summary>
        public const string AssignEmailDueDate = "##DUEDATE##";

        /// <summary>
        /// The assign email URL
        /// </summary>
        public const string AssignEmailUrl = "##URL##";

        /// <summary>
        /// The assign email access code
        /// </summary>
        public const string AssignEmailAccessCode = "##ACCESSCODE##";

        /// <summary>
        /// The travel identifier
        /// </summary>
        public const string TravelId = "TravelId";

        /// <summary>
        /// The travel parameter
        /// </summary>
        public const string TravelParameter = "TravelParameter";

        /// <summary>
        /// The is opened from travel tab
        /// </summary>
        public const string IsOpenedFromTravelTab = "IsOpenedFromTravelTab";

        /// <summary>
        /// The assignment notification identifier
        /// </summary>
        public const string AssignmentNotificationId = "AssignmentNotificationId";

        /// <summary>
        /// The reassign task dialog view
        /// </summary>
        public const string ReassignTaskDialogView = "ReassignTaskDialogView";

        /// <summary>
        /// The update task status dialog view model
        /// </summary>
        public const string UpdateTaskStatusDialogViewModel = "UpdateTaskStatusDialogViewModel";

        /// <summary>
        /// The verify crew task documents view
        /// </summary>
        public const string VerifyCrewTaskDocumentsView = "VerifyCrewTaskDocumentsView";

        /// <summary>
        /// The task status open short code
        /// </summary>
        public const string TaskStatusOpenShortCode = "O";

        /// <summary>
        /// The task status cancelled short code
        /// </summary>
        public const string TaskStatusCancelledShortCode = "C";

        /// <summary>
        /// The task status cancelled x short code
        /// </summary>
        public const string TaskStatusCancelledXShortCode = "X";

        /// <summary>
        /// The task status unassigned short code
        /// </summary>
        public const string TaskStatusUnassignedShortCode = "U";

        /// <summary>
        /// The task status completed short code
        /// </summary>
        public const string TaskStatusCompletedShortCode = "C";

        /// <summary>
        /// The task status awaiting release short code
        /// </summary>
        public const string TaskStatusAwaitingReleaseShortCode = "AR";

        /// <summary>
        /// The task status awaiting approval short code
        /// </summary>
        public const string TaskStatusAwaitingApprovalShortCode = "AA";

        /// <summary>
        /// The Fleet Landing page
        /// </summary>
        public const string FleetLandingView = "FleetLandingView";

        /// <summary>
        /// The mobilisation overview view
        /// </summary>
        public const string MobilisationOverviewView = "MobilisationOverviewView";

        /// <summary>
        /// The travel provider name
        /// </summary>
        public const string TravelProviderName = "TravelProviderName";

        /// <summary>
        /// The user notes dialog view
        /// </summary>
        public const string UserNotesDialogView = "UserNotesDialogView";

        /// <summary>
        /// The task additional information dialog view
        /// </summary>
        public const string TaskAdditionalInfoDialogView = "TaskAdditionalInfoDialogView";

        /// <summary>
        /// The add user task additional data dialog view
        /// </summary>
        public const string AddUserTaskAdditionalDataDialogView = "AddUserTaskAdditionalDataDialogView";

        /// <summary>
        /// The add agent emergency contact dialog view
        /// </summary>
        public const string AddAgentEmergencyContactDialogView = "AddAgentEmergencyContactDialogView";

        /// <summary>
        /// The agent detail identifier
        /// </summary>
        public const string AgentDetailId = "AgentDetailId";

        /// <summary>
        /// The company identifier
        /// </summary>
        public const string CompanyId = "CompanyId";

        /// <summary>
        /// The pool identifier
        /// </summary>
        public const string PoolId = "PoolId";

        /// <summary>
        /// The task response data dialog view
        /// </summary>
        public const string TaskResponseDataDialogView = "TaskResponseDataDialogView";

        /// <summary>
        /// The user task detail identifier
        /// </summary>
        public const string TaskId = "TaskId";

        /// <summary>
        /// The edit crew task dialog view
        /// </summary>
        public const string EditCrewTaskDialogView = "EditCrewTaskDialogView";

        /// <summary>
        /// The nan manager view
        /// </summary>
        public const string NANManagerView = "NANManagerView";

        /// <summary>
        /// The crew search start view
        /// </summary>
        public const string CrewSearchStartView = "CrewSearchStartView";

        /// <summary>
        /// The add edit recruitment view
        /// </summary>
        public const string AddEditRecruitmentView = "AddEditRecruitmentView";

        /// <summary>
        /// The user task history dialog view
        /// </summary>
        public const string UserTaskHistoryDialogView = "UserTaskHistoryDialogView";

        /// <summary>
        /// The task title
        /// </summary>
        public const string TaskTitle = "TaskTitle";

        /// <summary>
        /// The recruitment request list start view
        /// </summary>
        public const string RecruitmentRequestListStartView = "RecruitmentRequestListStartView";

        /// <summary>
        /// The is called from crew list
        /// </summary>
        public const string IsCalledFromCrewList = "IsCalledFromCrewList";

        /// <summary>
        /// The is crew on signer
        /// </summary>
        public const string IsOnSigner = "IsOnSigner";

        /// <summary>
        /// The update crew line up details dialog view
        /// </summary>
        public const string UpdateCrewLineUpDetailsDialogView = "UpdateCrewLineUpDetailsDialogView";


        /// <summary>
        /// The arrival date
        /// </summary>
        public const string ArrivalDate = "ArrivalDate";

        /// <summary>
        /// The departure date
        /// </summary>
        public const string DepartureDate = "DepartureDate";

        /// <summary>
        /// The planning overlap loi content
        /// </summary>
        public const string PlanningOverlapLOIContent = "Update NAN Status";

        /// <summary>
        /// The update onsigners plan to join dialog view
        /// </summary>
        public const string UpdateOnsignersPlanToJoinDialogView = "UpdateOnsignersPlanToJoinDialogView";

        /// <summary>
        /// The is include inactive
        /// </summary>
        public const string IsIncludeInactive = "IsIncludeInactive";

        /// <summary>
        /// The crew experience matrix view
        /// </summary>
        public const string CrewExperienceMatrixView = "CrewExperienceMatrixView";

        /// <summary>
        /// The check crew compliance dialog view
        /// </summary>
        public const string CheckCrewComplianceDialogView = "CheckCrewComplianceDialogView";

        /// <summary>
        /// The crew compliance dialog view
        /// </summary>
        public const string CrewComplianceDialogView = "CrewComplianceDialogView";

        /// <summary>
        /// The signing company identifier
        /// </summary>
        public const string SigningCompanyId = "SigningCompanyId";

        /// <summary>
        /// The personal details seniority date
        /// </summary>
        public const string PersonalDetailsSeniorityDate = "PersonalDetailsSeniorityDate";

        /// <summary>
        /// The Current seniority date
        /// </summary>
        public const string CurrentSeniorityDate = "CurrentSeniorityDate";

        /// <summary>
        /// The Current seniority year
        /// </summary>
        public const string CurrentSeniorityYear = "CurrentSeniorityYear";

        /// <summary>
        /// The next seniority date
        /// </summary>
        public const string NextSeniorityDate = "NextSeniorityDate";

        /// <summary>
        /// The next seniority year
        /// </summary>
        public const string NextSeniorityYear = "NextSeniorityYear";

        /// <summary>
        /// The is next seniority increment
        /// </summary>
        public const string IsNextSeniorityIncrement = "IsNextSeniorityIncrement";

        /// <summary>
        /// The Service start Date
        /// </summary>
        public const string ServiceStartDate = "ServiceStartDate";

        /// <summary>
        /// The cos identifier
        /// </summary>
        public const string COSId = "COSId";

        /// <summary>
        /// The contract end date
        /// </summary>
        public const string ContractEndDate = "ContractEndDate";

        /// <summary>
        /// The wage start date
        /// </summary>
        public const string WageStartDate = "WageStartDate";

        /// <summary>
        /// The on board crew identifier
        /// </summary>
        public const string OnBoardCrewID = "onBoardCrewID";

        /// <summary>
        /// The on board crew set identifier
        /// </summary>
        public const string OnBoardCrewSET_ID = "onBoardCrewSET_ID";

        /// <summary>
        /// The on board crew name
        /// </summary>
        public const string OnBoardCrewName = "onBoardCrewName";

        /// <summary>
        /// The releiver crew identifier
        /// </summary>
        public const string ReleiverCrewID = "releiverCrewID";

        /// <summary>
        /// The releiver crew set identifier
        /// </summary>
        public const string ReleiverCrewSET_ID = "releiverCrewSET_ID";

        /// <summary>
        /// The releiver crew name
        /// </summary>
        public const string ReleiverCrewName = "releiverCrewName";

        /// <summary>
        /// The show releiver
        /// </summary>
        public const string ShowReleiver = "ShowReleiver";

        /// <summary>
        /// The manual
        /// </summary>
        public const string Manual = "M";

        /// <summary>
        /// The optimised
        /// </summary>
        public const string Optimised = "O";

        /// <summary>
        /// The suggested reliever
        /// </summary>
        public const string SuggestedReliever = "S";

        /// <summary>
        /// The days to months
        /// </summary>
        public const int DaysToMonths = 30;

        /// <summary>
        /// The reject document dialog view
        /// </summary>
        public const string RejectDocumentDialogView = "RejectDocumentDialogView";

        /// <summary>
        /// The crew sign on
        /// </summary>
        public const string CrewSignOn = "CrewSignOn";

        /// <summary>
        /// The crew sign off
        /// </summary>
        public const string CrewSignOff = "CrewSignOff";

        /// <summary>
        /// The crew appraisal records dialog view
        /// </summary>
        public const string CrewAppraisalRecordsDialogView = "CrewAppraisalRecordsDialogView";

        /// <summary>
        /// The contract length
        /// </summary>
        public const string ContractLength = "ContractLength";

        /// <summary>
        /// The contract length unit
        /// </summary>
        public const string ContractLengthUnit = "ContractLengthUnit";


        /// <summary>
        /// The edit geometry
        /// </summary>
        public const string EditGeometry = "EditGeometry";

        /// <summary>
        /// The delete geometry
        /// </summary>
        public const string DeleteGeometry = "DeleteGeometry";

        /// <summary>
        /// The edit image geometry
        /// </summary>
        public const string EditImageGeometry = "EditImageGeometry";

        /// <summary>
        /// The edit PDF geometry
        /// </summary>
        public const string EditPDFGeometry = "EditPDFGeometry";

        /// <summary>
        /// The split PDF geometry
        /// </summary>
        public const string SplitPDFGeometry = "SplitPDFGeometry";

        /// <summary>
        /// The remove PDF pages geometry
        /// </summary>
        public const string RemovePDFPagesGeometry = "RemovePDFPagesGeometry";

        /// <summary>
        /// The download geometry
        /// </summary>
        public const string DownloadGeometry = "DownloadGeometry";

        /// <summary>
        /// The SVL identifier
        /// </summary>
        public const string SvlId = "SvlId";

        /// <summary>
        /// The export and merge documents view
        /// </summary>
        public const string ExportAndMergeDocumentsView = "ExportAndMergeDocumentsView";

        /// <summary>
        /// The appraisal review view
        /// </summary>
        public const string AppraisalReviewView = "AppraisalReviewView";

        /// <summary>
        /// The accident ashore identifier
        /// </summary>
        public const string AccidentAshoreId = "GLAS00000006";

        /// <summary>
        /// The Edit Next Assignment Dialog
        /// </summary>
        public const string EditNextAssignmentDialog = "EditNextAssignmentDialog";

        /// <summary>
        /// The add mobilisation cell dialog view
        /// </summary>
        public const string AddMobilisationCellDialogView = "AddMobilisationCellDialogView";

        /// <summary>
        /// The mandatory count
        /// </summary>
        public const string MandatoryCount = "MandatoryCount";

        /// <summary>
        /// The attachment type dialog view
        /// </summary>
        public const string AttachmentTypeDialogView = "AttachmentTypeDialogView";

        /// <summary>
        /// The documents cloud status view
        /// </summary>
        public const string DocumentsCloudStatusView = "DocumentsCloudStatusView";

        /// <summary>
        /// The Add Attachment Editable Dialog View
        /// </summary>
        public const string AddAttachmentEditableDialogView = "AddAttachmentEditableDialogView";

        /// <summary>
        /// The selected attachments
        /// </summary>
        public const string SelectedAttachments = "SelectedAttachments";

        /// <summary>
        /// The personal notes
        /// </summary>
        public const string PersonalNotes = "PersonalNotes";

        /// <summary>
        /// The add crew document group filter dialog view
        /// </summary>
        public const string AddCrewDocumentGroupFilterDialogView = "AddCrewDocumentGroupFilterDialogView";

        /// <summary>
        /// The selected documents
        /// </summary>
        public const string SelectedDocuments = "SelectedDocuments";

        /// <summary>
        /// The add crew rank group filter dialog view
        /// </summary>
        public const string AddCrewRankGroupFilterDialogView = "AddCrewRankGroupFilterDialogView";

        /// <summary>
        /// The selected rank
        /// </summary>
        public const string SelectedRank = "SelectedRank";

        /// <summary>
        /// The add edit VMS appraisal dialog view
        /// </summary>
        public const string AddEditVMSAppraisalDialogView = "AddEditVMSAppraisalDialogView";

        /// <summary>
        /// The appraisal identifier
        /// </summary>
        public const string AppraisalId = "AppraisalId";

        /// <summary>
        /// The recruitment in draft
        /// </summary>
        public const string RecruitmentInDraft = "Recruitment In Draft";

        /// <summary>
        /// The sent to recruitment
        /// </summary>
        public const string SentToRecruitment = "Sent To Recruitment";

        /// <summary>
        /// The recruitment in endorse
        /// </summary>
        public const string RecruitmentInEndorse = "Candidate Endorsed";

        /// <summary>
        /// The recruitment status pending
        /// </summary>
        public const string RecruitmentStatusPending = "Pending";

        /// <summary>
        /// The recruitment in progress
        /// </summary>
        public const string RecruitmentInProgress = "Recruitment In Progress";

        /// <summary>
        /// The add appraisal
        /// </summary>
        public const string AddAppraisal = "Add Appraisal";

        /// <summary>
        /// The edit appraisal
        /// </summary>
        public const string EditAppraisal = "Edit Appraisal";

        /// <summary>
        /// The crew list report dialog view
        /// </summary>
        public const string CrewListReportDialogView = "CrewListReportDialogView";

        /// <summary>
        /// The is crew contact added from mo
        /// </summary>
        public const string IsCrewContactAddedFromMO = "IsCrewContactAddedFromMO";

        /// <summary>
        /// The crew compliance tasks dialog view
        /// </summary>
        public const string CrewComplianceTasksDialogView = "CrewComplianceTasksDialogView";

        /// <summary>
        /// The payscale basic pay item column number
        /// </summary>
        public const string PayscaleBasicPayItemColumnNumber = "1";

        /// <summary>
        /// The export to PDF appraisals view
        /// </summary>
        public const string ExportToPdfAppraisalsView = "ExportToPdfAppraisalsView";

        /// <summary>
        /// The add tba slots dialog view
        /// </summary>
        public const string AddTBASlotsDialogView = "AddTBASlotsDialogView";

        /// <summary>
        /// The selected departments
        /// </summary>
        public const string SelectedDepartments = "SelectedDepartments";

        /// <summary>
        /// The selected rank categories
        /// </summary>
        public const string SelectedRankCategories = "SelectedRankCategories";

        /// <summary>
        /// The reject optimiser result dialog view
        /// </summary>
        public const string RejectOptimiserResultDialogView = "RejectOptimiserResultDialogView";

        /// <summary>
        /// The reject optimiser messenger token
        /// </summary>
        public const string RejectOptimiserMessengerToken = "OptimisationRejection";

        /// <summary>
        /// The is planning view tab selected
        /// </summary>
        public const string IsPlanningViewTabSelected = "IsPlanningViewTabSelected";

        /// <summary>
        /// The add edit foreign details view
        /// </summary>
        public const string AddEditForeignDetailsView = "AddEditForeignDetailsView";

        /// <summary>
        /// The crew contract selection dialog view
        /// </summary>
        public const string CrewContractSelectionDialogView = "CrewContractSelectionDialogView";

        /// <summary>
        /// The is in view mode
        /// </summary>
        public const string IsInViewMode = "IsInViewMode";

        /// <summary>
        /// The view appraisal
        /// </summary>
        public const string ViewAppraisal = "View Appraisal";

        /// <summary>
        /// The add edit foreign address view
        /// </summary>
        public const string AddEditForeignAddressView = "AddEditForeignAddressView";

        /// <summary>
        /// The is from dispensation tab
        /// </summary>
        public const string IsFromDispensationTab = "IsFromDispensationTab";

        /// <summary>
        /// The is include planning records
        /// </summary>
        public const string IsIncludePlanningRecords = "IsIncludePlanningRecords";

        /// <summary>
        /// The crew list detail
        /// </summary>
        public const string CrewListDetail = "CrewListDetail";

        /// <summary>
        /// The is consider forward planning
        /// </summary>
        public const string IsConsiderForwardPlanning = "IsConsiderForwardPlanning";

        /// <summary>
        /// The selected scheduled contract
        /// </summary>
        public const string SelectedScheduledContract = "SelectedScheduledContract";

        /// <summary>
        /// The is edit scheduled contract
        /// </summary>
        public const string IsEditScheduledContract = "IsEditScheduledContract";

        /// <summary>
        /// The mobilisation scheduled contract over due status identifier
        /// </summary>
        public const string MobilisationScheduledContractOverDueStatusId = "MobilisationScheduledContractOverDueStatusId";

        /// <summary>
        /// The reassign SFC
        /// </summary>
        public const string ReassignSFC = "Reassign SFC";

        /// <summary>
        /// The reassign mobilisation cell
        /// </summary>
        public const string ReassignMobilisationCell = "Reassign Mobilisation Cell";

        /// <summary>
        /// The reassign planning cell
        /// </summary>
        public const string ReassignPlanningCell = "Reassign Planning Cell";

        /// <summary>
        /// The re assign SFC dialog view
        /// </summary>
        public const string ReAssignSFCDialogView = "ReAssignSFCDialogView";

        /// <summary>
        /// The re assign mobilisation cell dialog view
        /// </summary>
        public const string ReAssignMobilisationCellDialogView = "ReAssignMobilisationCellDialogView";

        /// <summary>
        /// The re assign planning cell dialog view
        /// </summary>
        public const string ReAssignPlanningCellDialogView = "ReAssignPlanningCellDialogView";

        /// <summary>
        /// The list of selected crew
        /// </summary>
        public const string SelectedCrewList = "SelectedCrewList";

        /// <summary>
        /// The login user mobilisation cell list
        /// </summary>
        public const string LoginUserMobilisationCellList = "LoginUserMobilisationCellList";

        /// <summary>
        /// The login user planning cell list
        /// </summary>
        public const string LoginUserPlanningCellList = "LoginUserPlanningCellList";

        /// <summary>
        /// The plan previously onboard view
        /// </summary>
        public const string PlanPreviouslyOnboardView = "PlanPreviouslyOnboardView";

        /// <summary>
        /// The plan from working ListView
        /// </summary>
        public const string PlanFromWorkingListView = "PlanFromWorkingListView";

        /// <summary>
        /// The is optimiser enabled vessel
        /// </summary>
        public const string IsOptimiserEnabledVessel = "IsOptimiserEnabledVessel";

        /// <summary>
        /// The delete tba slots dialog view
        /// </summary>
        public const string DeleteTBASlotsDialogView = "DeleteTBASlotsDialogView";

        /// <summary>
        /// configure slot loc view
        /// </summary>
        public const string ConfigureSlotLOCView = "ConfigureSlotLOCView";

        /// <summary>
        /// The crew wages dialog view
        /// </summary>
        public const string CrewWagesDialogView = "CrewWagesDialogView";

        /// <summary>
        /// The crew assign wages
        /// </summary>
        public const string CrewAssignWages = "Assign Wage Scale";

        /// <summary>
        /// The crew edit wages
        /// </summary>
        public const string CrewEditWages = "Edit Wage Scale";

        /// <summary>
        /// The add recruited crew dialog view
        /// </summary>
        public const string AddRecruitedCrewDialogView = "AddRecruitedCrewDialogView";

        /// <summary>
        /// The edit crew recruitment status dialog view
        /// </summary>
        public const string EditCrewRecruitmentStatusDialogView = "EditCrewRecruitmentStatusDialogView";

        /// <summary>
        /// The scheduled contact identifier
        /// </summary>
        public const string ScheduledContactId = "ScheduledContactId";

        /// <summary>
        /// The crew basic detail dialog view
        /// </summary>
        public const string CrewBasicDetailDialogView = "CrewBasicDetailDialogView";

        /// <summary>
        /// The crew reassign action response
        /// </summary>
        public const string CrewReassignActionResponse = "CrewReassignActionResponse";

        /// <summary>
        /// The cell type
        /// </summary>
        public const string CellType = "CellType";

        /// <summary>
        /// The is user tpa
        /// </summary>
        public const string IsUserTPA = "IsUserTPA";

        /// <summary>
        /// The update crew requirement status view
        /// </summary>
        public const string UpdateCrewRequirementStatusView = "UpdateCrewRequirementStatusView";

        /// <summary>
        /// The assign policy dialog view
        /// </summary>
        public const string AssignPolicyDialogView = "AssignPolicyDialogView";

        /// <summary>
        /// The assignment email dialog view
        /// </summary>
        public const string AssignmentEmailDialogView = "AssignmentEmailDialogView";

        /// <summary>
        /// The assignment email send grid dialog view
        /// </summary>
        public const string AssignmentEmailSendGridDialogView = "AssignmentEmailSendGridDialogView";

        /// <summary>
        /// The add edit crew generic appraisal dialog view
        /// </summary>
        public const string AddEditCrewGenericAppraisalDialogView = "AddEditCrewGenericAppraisalDialogView";

        /// <summary>
        /// The approve appraisal review dialog view
        /// </summary>
        public const string ApproveAppraisalReviewDialogView = "ApproveAppraisalReviewDialogView";

        /// <summary>
        /// The cancel policy assignment dialog view
        /// </summary>
        public const string CancelPolicyAssignmentDialogView = "CancelPolicyAssignmentDialogView";

        /// <summary>
		/// The XML file name
		/// </summary>
		public const string XmlFileName = "Preferences.xml";

        /// <summary>
        /// The json file name
        /// </summary>
        public const string JsonFileName = "Preferences.json";

        /// <summary>
        /// The Crew Working List json file name
        /// </summary>
        public const string JsonCrewWorkingListFileName = "CrewWorkingList.json";

        /// <summary>
        /// The Crew Working List Max Count name
        /// </summary>
        public const int JsonCrewWorkingListMaxCount = 250;

        /// <summary>
        /// The preference XML element name
        /// </summary>
        public const string PreferenceXmlElementName = "Preference";

        /// <summary>
		/// The name attribute
		/// </summary>
		public const string NameAttribute = "Name";

        /// <summary>
        /// The value attribute
        /// </summary>
        public const string ValueAttribute = "Value";

        /// <summary>
        /// The is policy resend
        /// </summary>
        public const string IsPolicyResend = "IsPolicyResend";

        /// <summary>
        /// The is policy email send using send grid
        /// </summary>
        public const string IsPolicyEmailSendUsingSendGrid = "IsPolicyEmailSendUsingSendGrid";

        /// <summary>
        /// The compliance template details dialog view
        /// </summary>
        public const string ComplianceTemplateDetailsDialogView = "ComplianceTemplateDetailsDialogView";

        /// <summary>
        /// The image editor tool dialog view
        /// </summary>
        public const string ImageEditorToolDialogView = "CrewImageEditorToolDialogView";

        /// <summary>
        /// The crew confirmation dialog view
        /// </summary>
        public const string CrewConfirmationDialogView = "CrewConfirmationDialogView";

        /// <summary>
        /// The download as document view
        /// </summary>
        public const string DownloadAsDocumentView = "DownloadAsDocumentView";

        /// <summary>
        /// The crew remove PDF pages view
        /// </summary>
        public const string CrewRemovePdfPagesView = "CrewRemovePdfPagesView";

        /// <summary>
        /// The previous versions of document view
        /// </summary>
        public const string PreviousVersionsOfDocumentView = "CrewPreviousVersionsOfDocumentView";

        /// <summary>
        /// The gantt view for multiple vessel start view
        /// </summary>
        public const string GanttViewForMultipleVesselStartView = "GanttViewForMultipleVesselStartView";

        /// <summary>
        /// The policy status
        /// </summary>
        public const string PolicyStatus = "PolicyStatus";

        /// <summary>
        /// The is all policy agreed
        /// </summary>
        public const string IsAllPolicyAgreed = "IsAllPolicyAgreed";

        /// <summary>
        /// The completed policy list
        /// </summary>
        public const string CompletedPolicyList = "##COMPLETEDPOLICYLIST##";

        /// <summary>
        /// The agreed policy list
        /// </summary>
        public const string AgreedPolicyList = "AgreedPolicyList";

        /// <summary>
        /// The gantt view json file name
        /// </summary>
        public const string GanttViewJsonFileName = "GanttViewPreferences.json";

        /// <summary>
        /// The plan reliever action
        /// </summary>
        public const string PlanRelieverAction = "Plan Reliever";

        /// <summary>
        /// The update requirement status view
        /// </summary>
        public const string UpdateRequirementStatusView = "UpdateRequirementStatusView";

        /// <summary>
        /// The requirement identifier
        /// </summary>
        public const string RequirementId = "RequirementId";

        /// <summary>
        /// The add recruitement cancel notes dialog view
        /// </summary>
        public const string AddRecruitementCancelNotesDialogView = "AddRecruitementCancelNotesDialogView";

        /// <summary>
        /// All candidates are rejected
        /// </summary>
        public const string AllCandidatesAreRejected = "AllCandidatesAreRejected";

        /// <summary>
        /// The is berth automatic approve
        /// </summary>
        public const string IsBerthAutoApprove = "IsBerthAutoApprove";

        /// <summary>
        /// The user rank group view
        /// </summary>
        public const string UserRankGroupView = "UserRankGroupView";

        /// <summary>
        /// The Parameter
        /// </summary>
        public const string Parameter = "Parameter";

        /// <summary>
        /// The add edit debriefing dialog view
        /// </summary>
        public const string AddEditDebriefingDialogView = "AddEditDebriefingDialogView";

        /// <summary>
        /// The revise contract confirmation view
        /// </summary>
        public const string ReviseContractConfirmationView = "ReviseContractConfirmationView";

        /// <summary>
        /// The is seniority updated
        /// </summary>
        public const string IsSeniorityUpdated = "IsSeniorityUpdated";

        /// <summary>
        /// The start date
        /// </summary>
        public const string StartDate = "StartDate";

        /// <summary>
        /// The flight type
        /// </summary>
        public const string FlightType = "FlightType";

        /// <summary>
        /// The contract log dialog view
        /// </summary>
        public const string ContractLogDialogView = "ContractLogDialogView";

        /// <summary>
        /// The condition of service dialog view
        /// </summary>
        public const string ConditionOfServiceDialogView = "ConditionOfServiceDialogView";

        /// <summary>
        /// The signing entities dialog view
        /// </summary>
        public const string SigningEntitiesDialogView = "SigningEntitiesDialogView";

        /// <summary>
        /// The crew knowledge description navigation view
        /// </summary>
        public const string CrewKnowledgeDescriptionNavigationView = "CrewKnowledgeDescriptionNavigationView";

        /// <summary>
        /// The crew add edit onboard appraisal view
        /// </summary>
        public const string CrewAddEditOnboardAppraisalView = "CrewAddEditOnboardAppraisalView";

        /// <summary>
        /// The crew add objective navigation view
        /// </summary>
        public const string CrewAddObjectiveNavigationView = "CrewAddObjectiveNavigationView";

        /// <summary>
        /// The crew active objective navigation view
        /// </summary>
        public const string CrewActiveObjectiveNavigationView = "CrewActiveObjectiveNavigationView";

        /// <summary>
        /// The crew active training needs navigation view
        /// </summary>
        public const string CrewActiveTrainingNeedsNavigationView = "CrewActiveTrainingNeedsNavigationView";

        /// <summary>
        /// The crew add training needs navigation view
        /// </summary>
        public const string CrewAddTrainingNeedsNavigationView = "CrewAddTrainingNeedsNavigationView";

        /// <summary>
        /// The crew reopen appraisal navigation view
        /// </summary>
        public const string CrewReopenAppraisalNavigationView = "CrewReopenAppraisalNavigationView";

        /// <summary>
        /// The crew add edit appraisal attachments view
        /// </summary>
        public const string CrewAddEditAppraisalAttachmentsView = "CrewAddEditAppraisalAttachmentsView";
        
        /// <summary>
        /// The salary transfer letter maintainer start view
        /// </summary>
        public const string SalaryTransferLetterMaintainerStartView = "SalaryTransferLetterMaintainerStartView";
        /// <summary>
        /// The travel event maintainer start view
        /// </summary>
        public const string TravelEventMaintainerStartView = "TravelEventMaintainerStartView";

        /// <summary>
        /// The alert save dialog view
        /// </summary>
        public const string AlertSaveDialogView = "AlertSaveDialogView";

        /// <summary>
        /// The open payperiod list dialog view
        /// </summary>
        public const string OpenPayperiodListDialogView = "OpenPayperiodListDialogView";

        /// <summary>
        /// The next seniority allowance
        /// </summary>
        public const string NextSeniorityAllowance = "NextSeniorityAllowance";

        /// <summary>
        /// The payscale seniority allowance item column number
        /// </summary>
        public const string PayscaleSeniorityAllowanceItemColumnNumber = "6";

        /// <summary>
        /// The can create new task
        /// </summary>
        public const string CanCreateNewTask = "CanCreateNewTask";

        /// <summary>
        /// The rejected reason
        /// </summary>
        public const string RejectedReason = "RejectedReason";

        /// <summary>
        /// The promote or transfer crew
        /// </summary>
        public const string PromoteOrTransferCrew = "PromoteOrTransferCrewView";

        /// <summary>
        /// The add edit joining briefing view
        /// </summary>
        public const string AddEditJoiningBriefingView = "AddEditJoiningBriefingView";

        /// <summary>
        /// The crew document vaccine details view
        /// </summary>
        public const string CrewDocumentVaccineDetailsView = "CrewDocumentVaccineDetailsView";

        /// <summary>
        /// The office objective review history navigation view
        /// </summary>
        public const string OfficeObjectiveReviewHistoryNavigationView = "OfficeObjectiveReviewHistoryNavigationView";

        /// <summary>
        /// The permanent contract type identifier
        /// </summary>
        public const string PermanentContractTypeId = "VSHP00000004";

        /// <summary>
        /// The add edit crew16 view
        /// </summary>
        public const string AddEditCrewInterviewDetailView = "AddEditCrewInterviewDetailView";

        /// <summary>
        /// The pay basis contract type
        /// </summary>
        public const string PayBasisContractType = "PayBasisContractType";

        /// <summary>
        /// The contract start date
        /// </summary>
        public const string ContractStartDate = "ContractStartDate";

        /// <summary>
        /// The is vessel details visible
        /// </summary>
        public const string IsVesselDetailsVisible = "IsVesselDetailsVisible";

        /// <summary>
        /// The is permanent contract
        /// </summary>
        public const string IsPermanentContract = "IsPermanentContract";

        /// <summary>
        /// The contract start date changed token
        /// </summary>
        public const string ContractStartDateChangedToken = "ContractStartDateChangedToken";

        /// <summary>
        /// The contract end date changed token
        /// </summary>
        public const string ContractEndDateChangedToken = "ContractEndDateChangedToken";

        /// <summary>
        /// The permanent contract end date
        /// </summary>
        public const string PermanentContractEndDate = "PermanentContractEndDate";

        /// <summary>
        /// The navigation context
        /// </summary>
        public const string NavigationContext = "NavigationContext";

        /// <summary>
        /// The contract pay basis type changed token
        /// </summary>
        public const string ContractPayBasisTypeChangedToken = "ContractPayBasisTypeChangedToken";

        /// <summary>
        /// The notification identifier
        /// </summary>
        public const string NotificationId = "NotificationId";

        /// <summary>
        /// The add edit seafarer notifications dialog view
        /// </summary>
        public const string AddEditSeafarerNotificationsDialogView = "AddEditSeafarerNotificationsDialogView";

        /// <summary>
        /// The is crew using mobile application
        /// </summary>
        public const string IsCrewUsingMobileApp = "IsCrewUsingMobileApp";

        /// <summary>
        /// The crew search experiance dialog view
        /// </summary>
        public const string CrewSearchExperianceDialogView = "CrewSearchExperianceDialogView";

        /// <summary>
        /// The exclude automatic assigned template view
        /// </summary>
        public const string ExcludeAutoAssignedTemplateView = "ExcludeAutoAssignedTemplateView";
        
        /// <summary>
        /// The matrix compliance pre so identifier
        /// </summary>
        public const string MatrixCompliancePreSoId = "GLAS00000035";

        /// <summary>
        /// The add crew exclude rank group filter dialog view
        /// </summary>
        public const string AddCrewExcludeRankGroupFilterDialogView = "AddCrewExcludeRankGroupFilterDialogView";

        /// <summary>
        /// The is local save mode
        /// </summary>
        public const string IsLocalSaveMode = "IsLocalSaveMode";

        /// <summary>
        /// The add osa missing remarks view
        /// </summary>
        public const string AddOsaMissingRemarksView = "AddOsaMissingRemarksView";

        /// <summary>
        /// The fly2c book tickets preview dialog
        /// </summary>
        public const string Fly2cBookTicketsPreviewDialog = "Fly2cBookTicketsPreviewDialog";
        
        /// <summary>
        /// The covid vaccine details updated token
        /// </summary>
        public const string CovidVaccineDetailsUpdatedToken = "CovidVaccineDetailsUpdatedToken";

        /// <summary>
        /// The linked service details view
        /// </summary>
        public const string LinkedServiceDetailsView = "LinkedServiceDetailsView";

        /// <summary>
        /// The selected record
        /// </summary>
        public const string SelectedRecord = "SelectedRecord";

        /// <summary>
        /// The service end date
        /// </summary>
        public const string ServiceEndDate = "ServiceEndDate";

        /// <summary>
        /// The set crew hazocc detail
        /// </summary>
        public const string SetCrewHazoccDetail = "SetCrewHazoccDetail";

        /// <summary>
        /// The crew hazocc records view
        /// </summary>
        public const string CrewHazoccRecordsDialogView = "CrewHazoccRecordsDialogView";

        /// <summary>
        /// The medical history view
        /// </summary>
        public const string MedicalHistoryView = "MedicalHistoryView";

        /// <summary>
        /// The vessel owner identifier
        /// </summary>
        public const string VesselOwnerId = "VesselOwnerId";

        /// <summary>
        /// The vessel owner name
        /// </summary>
        public const string VesselOwnerName = "VesselOwnerName";

        /// <summary>
        /// The is filter tpa vessel
        /// </summary>
        public const string IsFilterTPAVessel = "IsFilterTPAVessel";

        /// <summary>
        /// The mark service active
        /// </summary>
        public const string MarkServiceActive = "Mark as Active";

        /// <summary>
        /// The mark service inactive
        /// </summary>
        public const string MarkServiceInactive = "Mark as Inactive";

        /// <summary>
        /// The crew list export to fidelio view
        /// </summary>
        public const string CrewListExportToFidelioView = "CrewListExportToFidelioView";

        /// <summary>
        /// The crew task type title
        /// </summary>
        public const string CrewTaskTypeTitle = "TaskTypeTitle";

        /// <summary>
        /// The crew task details
        /// </summary>
        public const string CrewTaskDetails = "CrewTaskDetail";

        /// <summary>
        /// The banking tab selected
        /// </summary>
        public const string BankingTabSelected = "BankingTabSelected";

        /// <summary>
        /// The nok sub tab selected
        /// </summary>
        public const string NokSubTabSelected = "NokSubTabSelected";

        /// <summary>
        /// The policy assignment tab selected
        /// </summary>
        public const string PolicyAssignmentSubTabSelected = "PolicyAssignmentSubTabSelected";

        /// <summary>
        /// The briefing sub tab selected
        /// </summary>
        public const string BriefingSubTabSelected = "OnBriefingSubTabSelected";

        /// <summary>
        /// The documents tab selected
        /// </summary>
        public const string DocumentsTabSelected = "DocumentsTabSelected";

        /// <summary>
        /// The centralised request tab selection requested
        /// </summary>
        public const string CentralisedRequestTabSelectionRequested = "CentralisedRequestTabSelectionRequested";

        /// <summary>
        /// The training needs tab selection and add requested
        /// </summary>
        public const string TrainingNeedsTabSelectionAndAddRequested = "TrainingNeedsTabSelectionAndAddRequested";

        /// <summary>
        /// The approve dispensation view
        /// </summary>
        public const string ApproveDispensationView = "ApproveDispensationView";

        /// <summary>
        /// The export file name prefx requested dispensation
        /// </summary>
        public const string ExportFileNamePrefxRequestedDispensation = "Requested_Dispensation";

        /// <summary>
        /// The add crew mobilisation checklist manual checks dialog view
        /// </summary>
        public const string AddMobilisationChecklistManualChecksDialogView = "AddMobilisationChecklistManualChecksDialogView";

        /// <summary>
        /// The crew mob checklist selected templates
        /// </summary>
        public const string CrewMobChecklistSelectedTemplates = "CrewMobChecklistSelectedTemplates";

        /// <summary>
        /// The crew mob checklist save selected templates
        /// </summary>
        public const string CrewMobChecklistSaveSelectedTemplatesAction = "CrewMobChecklistSaveSelectedTemplatesAction";

        /// <summary>
        /// The onboard crew service identifier for berth
        /// </summary>
        public const string OnboardCrewServiceIdForBerth = "OnboardCrewServiceIdForBerth";

        /// <summary>
        /// The add edit centralised request view
        /// </summary>
        public const string AddEditCentralisedRequestView = "AddEditCentralisedRequestView";

        /// <summary>
        /// The re assign technical fleet dialog view
        /// </summary>
        public const string ReAssignTechnicalFleetDialogView = "ReAssignTechnicalFleetDialogView";

        /// <summary>
        /// The centralized requests start view
        /// </summary>
        public const string CentralizedRequestsStartView = "CentralizedRequestsStartView";

        /// <summary>
        /// The crew log details view
        /// </summary>
        public const string CrewLogDetailsView = "CrewLogDetailsView";

        /// <summary>
        /// The lineup crew contract details refesh token
        /// </summary>
        public const string LineupCrewContractDetailsRefeshToken = "LineupCrewContractDetailsRefeshToken";

        /// <summary>
        /// The crew requirement data
        /// </summary>
        public const string CrewRequirementData = "CrewRequirementData";

        /// <summary>
        /// The update reliever not required
        /// </summary>
        public const string UpdateRelieverNotRequired = "UpdateRelieverNotRequired";

        /// <summary>
        /// The refresh budgeted list on crew requirement update
        /// </summary>
        public const string RefreshBudgetedListOnCrewRequirementUpdate = "RefreshBudgetedListOnCrewRequirementUpdate";

        /// <summary>
        /// The mark nan as approved
        /// </summary>
        public const string MarkNANAsApproved = "MarkNANAsApproved";

        /// <summary>
        /// The planning cell identifier
        /// </summary>
        public const string PlanningCellId = "PlanningCellId";

        /// <summary>
        /// The CMP cell identifier
        /// </summary>
        public const string CmpCellId = "CmpCellId";

        /// <summary>
        /// The resend LOI 
        /// </summary>
        public const string ResendLOI = "Resend NAN";

        /// <summary>
        /// The is show resend nan
        /// </summary>
        public const string IsShowResendNan = "IsShowResendNan";

        /// <summary>
        /// The existing NAN ID
        /// </summary>
        public const string ExistingAssignmentNotificationId = "ExistingAssignmentNotificationId";

        /// <summary>
        /// The nan no response reject reason identifier
        /// </summary>
        public const string NANNoResponseRejectReasonId = "VGRP00000009";
    }
}