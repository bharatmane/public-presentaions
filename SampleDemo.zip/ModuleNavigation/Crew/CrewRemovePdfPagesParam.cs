﻿using System;
using VShips.DataServices.Shared.Enumerations.Document;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// CrewRemovePdfPagesParam Class
    /// </summary>
    public class CrewRemovePdfPagesParam
    {
        /// <summary>
        /// Gets or sets the closed.
        /// </summary>
        /// <value>
        /// The closed.
        /// </value>
        public Action<bool> Closed { get; set; }

        /// <summary>
        /// Gets or sets the temporary folder path.
        /// </summary>
        /// <value>
        /// The temporary folder path.
        /// </value>
        public string TempFolderPath { get; set; }

        /// <summary>
        /// Gets or sets the document path.
        /// </summary>
        /// <value>
        /// The document path.
        /// </value>
        public string DocumentPath { get; set; }

        /// <summary>
        /// Gets or sets the document description.
        /// </summary>
        /// <value>
        /// The document description.
        /// </value>
        public string DocumentDescription { get; set; }

        /// <summary>
        /// Gets or sets the document filename.
        /// </summary>
        /// <value>
        /// The document filename.
        /// </value>
        public string DocumentFilename { get; set; }

        /// <summary>
        /// Gets or sets the cloud document identifier.
        /// </summary>
        /// <value>
        /// The cloud document identifier.
        /// </value>
        public string CloudDocumentIdentifier { get; set; }
        
        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the matched identifier.
        /// </summary>
        /// <value>
        /// The matched identifier.
        /// </value>
        public string MatchedId { get; set; }

        /// <summary>
        /// Gets or sets the entity reference2.
        /// </summary>
        /// <value>
        /// The entity reference2.
        /// </value>
        public string EntityReference2 { get; set; }

        /// <summary>
        /// Gets or sets the document category.
        /// </summary>
        /// <value>
        /// The document category.
        /// </value>
        public DocumentCategory DocumentCategory { get; set; }
    }
}
