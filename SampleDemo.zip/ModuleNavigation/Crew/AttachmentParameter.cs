﻿using VShips.Contracts.Custom.Crew;
using VShips.DataServices.Shared.Enumerations.Crew;
using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Input parameters for Attachment
    /// </summary>
    public class AttachmentParameter : BaseViewModel
    {
        #region Properties        
        /// <summary>
        /// The foreign key matched identifier
        /// </summary>
        private string _foreignKeyMatchedId;

        /// <summary>
        /// Gets or sets the foreign key matched identifier.
        /// </summary>
        /// <value>
        /// The foreign key matched identifier.
        /// </value>
        public string ForeignKeyMatchedId
        {
            get { return _foreignKeyMatchedId; }
            set { Set(() => ForeignKeyMatchedId, ref _foreignKeyMatchedId, value); }
        }

        /// <summary>
        /// The crew identifier
        /// </summary>
        private string _crewId;

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId
        {
            get { return _crewId; }
            set { Set(() => CrewId, ref _crewId, value); }
        }

        /// <summary>
        /// The document category type
        /// </summary>
        private DocumentCategory _documentCategoryType;

        /// <summary>
        /// Gets or sets the type of the document category.
        /// </summary>
        /// <value>
        /// The type of the document category.
        /// </value>
        public DocumentCategory DocumentCategoryType
        {
            get { return _documentCategoryType; }
            set { Set(() => DocumentCategoryType, ref _documentCategoryType, value); }
        }

        /// <summary>
        /// The default file name
        /// </summary>
        private string _defaultFileName;

        /// <summary>
        /// Gets or sets the default name of the file.
        /// </summary>
        /// <value>
        /// The default name of the file.
        /// </value>
        public string DefaultFileName
        {
            get { return _defaultFileName; }
            set { Set(() => DefaultFileName, ref _defaultFileName, value); }
        }

        /// <summary>
        /// The _is attacchment allowed
        /// </summary>
        private bool _isAttachmentAllowed;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is attacchment allowed.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is attacchment allowed; otherwise, <c>false</c>.
        /// </value>
        public bool IsAttachmentAllowed
        {
            get { return _isAttachmentAllowed; }
            set { Set(() => IsAttachmentAllowed, ref _isAttachmentAllowed, value); }
        }

        /// <summary>
        /// The document scanned group
        /// </summary>
        private CrewDocumentScannedGroup? _documentScannedGroup;

        /// <summary>
        /// Gets or sets the document scanned group.
        /// </summary>
        /// <value>
        /// The document scanned group.
        /// </value>
        public CrewDocumentScannedGroup? DocumentScannedGroup
        {
            get { return _documentScannedGroup; }
            set { Set(() => DocumentScannedGroup, ref _documentScannedGroup, value); }
        }

        /// <summary>
        /// The Document Category Identifier
        /// </summary>
        private string _documentCategoryId;

        /// <summary>
        /// Gets or sets the document category identifier.
        /// </summary>
        /// <value>
        /// The document category identifier.
        /// </value>
        public string DocumentCategoryId
        {
            get { return _documentCategoryId; }
            set { Set(() => DocumentCategoryId, ref _documentCategoryId, value); }
        }

        /// <summary>
        /// The entity reference 2
        /// </summary>
        private string _entityReference2;

        /// <summary>
        /// Gets or sets the entity reference 2.
        /// </summary>
        /// <value>
        /// The entity reference 2.
        /// </value>
        public string EntityReference2
        {
            get { return _entityReference2; }
            set { Set(() => EntityReference2, ref _entityReference2, value); }
        }

        /// <summary>
        /// The is attachment from additional section
        /// </summary>
        private bool _isAttachmentFromAdditionalSection;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is attachment from additional section.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is attachment from additional section; otherwise, <c>false</c>.
        /// </value>
        public bool IsAttachmentFromAdditionalSection
        {
            get { return _isAttachmentFromAdditionalSection; }
            set { Set(() => IsAttachmentFromAdditionalSection, ref _isAttachmentFromAdditionalSection, value); }
        }

        /// <summary>
        /// The linked description
        /// </summary>
        private string _linkedDescription;

        /// <summary>
        /// Gets or sets the linked description.
        /// </summary>
        /// <value>
        /// The linked description.
        /// </value>
        public string LinkedDescription
        {
            get { return _linkedDescription; }
            set { Set(() => LinkedDescription, ref _linkedDescription, value); }
        }

        /// <summary>
        /// The crew lineup detail
        /// </summary>
        private CrewCloudDocumentForLineupDetail _crewLineupDetail;

        /// <summary>
        /// Gets or sets the crew lineup detail.
        /// </summary>
        /// <value>
        /// The crew lineup detail.
        /// </value>
        public CrewCloudDocumentForLineupDetail CrewLineupDetail
        {
            get { return _crewLineupDetail; }
            set { Set(() => CrewLineupDetail, ref _crewLineupDetail, value); }
        }

        /// <summary>
        /// The is contract extension authorization
        /// </summary>
        private bool _isContractExtensionAuthorization;
        /// <summary>
        /// Gets or sets a value indicating whether this instance is contract extension authorization.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is contract extension authorization; otherwise, <c>false</c>.
        /// </value>
        public bool IsContractExtensionAuthorization
        {
            get { return _isContractExtensionAuthorization; }
            set { Set(() => IsContractExtensionAuthorization, ref _isContractExtensionAuthorization, value); }
        }
        #endregion
    }
}
