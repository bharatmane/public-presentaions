﻿using System;
using VShips.DataServices.Shared.Enumerations.Document;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// CrewDownloadAsParam Class
    /// </summary>
    public class CrewDownloadAsParam
    {
        /// <summary>
        /// Gets or sets the type of the selected document.
        /// </summary>
        /// <value>
        /// The type of the selected document.
        /// </value>
        public DocumentFileType SelectedDocumentType { get; set; }

        /// <summary>
        /// Gets or sets the closed.
        /// </summary>
        /// <value>
        /// The closed.
        /// </value>
        public Action<DocumentFileType?> Closed { get; set; }
    }
}
