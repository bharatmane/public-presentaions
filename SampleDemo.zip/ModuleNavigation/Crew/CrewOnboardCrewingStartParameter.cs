﻿using System;
using System.Collections.Generic;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Enumerations.Vessel;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// CrewOnboardCrewingStartParameter Class
    /// </summary>
    public class CrewOnboardCrewingStartParameter
    {
        #region Properties
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the cah identifier.
        /// </summary>
        /// <value>
        /// The cah identifier.
        /// </value>
        public string CahId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is in edit mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is in edit mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsInEditMode { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is from self appraisal.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from self appraisal; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromSelfAppraisal { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is unsync crew.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is unsync crew; otherwise, <c>false</c>.
        /// </value>
        public bool IsUnsyncCrew { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is from activate.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from activate; otherwise, <c>false</c>.
        /// </value>
        public bool? IsFromActivate { get; set; }

        /// <summary>
        /// Gets or sets the allotment identifier.
        /// </summary>
        /// <value>
        /// The allotment identifier.
        /// </value>
        public string AllotmentId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from allotment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from allotment; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromAllotment { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public OBAccountType AccountType { get; set; }

        /// <summary>
        /// Gets or sets the transaction identifier.
        /// </summary>
        /// <value>
        /// The transaction identifier.
        /// </value>
        public string TransactionId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is slopchest sale charterer.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is slopchest sale charterer; otherwise, <c>false</c>.
        /// </value>
        public bool IsSlopchestSaleCharterer { get; set; }

        /// <summary>
        /// Gets or sets the type of the transaction.
        /// </summary>
        /// <value>
        /// The type of the transaction.
        /// </value>
        public OBTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets the active month.
        /// </summary>
        /// <value>
        /// The active month.
        /// </value>
        public DateTime? ActiveMonth { get; set; }

        /// <summary>
        /// Gets or sets the account currency.
        /// </summary>
        /// <value>
        /// The account currency.
        /// </value>
        public string AccountCurrency { get; set; }

        /// <summary>
        /// Gets or sets the selectable start date.
        /// </summary>
        /// <value>
        /// The selectable start date.
        /// </value>
        public DateTime? SelectableStartDate { get; set; }

        /// <summary>
        /// Gets or sets the selectable end date.
        /// </summary>
        /// <value>
        /// The selectable end date.
        /// </value>
        public DateTime? SelectableEndDate { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        public object Entity { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is submit allotment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is submit allotment; otherwise, <c>false</c>.
        /// </value>
        public bool IsSubmitAllotment { get; set; }

        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the selected month.
        /// </summary>
        /// <value>
        /// The selected month.
        /// </value>
        public DateTime SelectedMonth { get; set; }

        /// <summary>
        /// Gets or sets the service rank short code.
        /// </summary>
        /// <value>
        /// The service rank short code.
        /// </value>
        public string ServiceRankShortCode { get; set; }

        /// <summary>
        /// Gets or sets the set identifier.
        /// </summary>
        /// <value>
        /// The set identifier.
        /// </value>
        public string SetId { get; set; }

        /// <summary>
        /// Gets or sets the training identifier.
        /// </summary>
        /// <value>
        /// The training identifier.
        /// </value>
        public string TrainingId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from performance.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from performance; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromPerformance { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is on signer invalid.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is on signer invalid; otherwise, <c>false</c>.
        /// </value>
        public bool IsOnSignerInvalid { get; set; }

        /// <summary>
        /// Gets or sets the sign on date.
        /// </summary>
        /// <value>
        /// The sign on date.
        /// </value>
        public DateTime SignOnDate { get; set; }

        /// <summary>
        /// Gets or sets the signed off date.
        /// </summary>
        /// <value>
        /// The signed off date.
        /// </value>
        public DateTime SignedOffDate { get; set; }

        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObject { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier tp.
        /// </summary>
        /// <value>
        /// The crew identifier tp.
        /// </value>
        public string CrewIdTp { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier TPS.
        /// </summary>
        /// <value>
        /// The crew identifier TPS.
        /// </value>
        public List<string> CrewIdTps { get; set; }

        /// <summary>
        /// Gets or sets the pay identifier.
        /// </summary>
        /// <value>
        /// The pay identifier.
        /// </value>
        public string PayId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is account history.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is account history; otherwise, <c>false</c>.
        /// </value>
        public bool IsAccountHistory { get; set; }

        /// <summary>
        /// Gets or sets the oah identifier.
        /// </summary>
        /// <value>
        /// The oah identifier.
        /// </value>
        public string OahId { get; set; }

        /// <summary>
        /// Gets or sets the account type identifier.
        /// </summary>
        /// <value>
        /// The account type identifier.
        /// </value>
        public string AccountTypeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the report.
        /// </summary>
        /// <value>
        /// The name of the report.
        /// </value>
        public string ReportName { get; set; }

        /// <summary>
        /// Gets or sets the report identifier.
        /// </summary>
        /// <value>
        /// The report identifier.
        /// </value>
        public string ReportId { get; set; }

        /// <summary>
        /// Gets or sets the report popup title.
        /// </summary>
        /// <value>
        /// The report popup title.
        /// </value>
        public string ReportPopupTitle { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is historic allotment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is historic allotment; otherwise, <c>false</c>.
        /// </value>
        public bool IsHistoricAllotment { get; set; }

        /// <summary>
        /// The is documents tab selected
        /// </summary>
        public bool IsDocumentsTabSelected;

        /// <summary>
        /// Gets or sets the sas identifier.
        /// </summary>
        /// <value>
        /// The sas identifier.
        /// </value>
        public int? SasId { get; set; }

        /// <summary>
        /// The is edit from allotment detail
        /// </summary>
        public bool IsEditFromAllotmentDetail;

        /// <summary>
        /// The is fixed allotment
        /// </summary>
        public bool? IsFixedAllotment;

        /// <summary>
        /// The is from unsync crew sign on
        /// </summary>
        public bool IsFromUnsyncCrewSignOn;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is last appraisal.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is last appraisal; otherwise, <c>false</c>.
        /// </value>
        public bool? IsLastAppraisal { get; set; }

        /// <summary>
        /// Gets or sets the type of the apparisal source.
        /// </summary>
        /// <value>
        /// The type of the apparisal source.
        /// </value>
        public ApparisalSourceType? ApparisalSourceType { get; set; }

        /// <summary>
        /// Gets or sets the planning status identifier.
        /// </summary>
        /// <value>
        /// The planning status identifier.
        /// </value>
        public string PlanningStatusId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is mobisation active check list.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is mobisation active check list; otherwise, <c>false</c>.
        /// </value>
        public bool IsMobisationActiveCheckList { get; set; }

        #endregion

        #region AddCrewWizardNavigationProperties

        /// <summary>
        /// Gets or sets a value indicating whether this instance is crew change by vessel.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is crew change by vessel; otherwise, <c>false</c>.
        /// </value>
        public bool IsCrewChangeByVessel { get; set; }

        /// <summary>
        /// Gets or sets the document type list.
        /// </summary>
        /// <value>
        /// The document type list.
        /// </value>
        public List<Lookup> DocumentTypeList { get; set; }

        /// <summary>
        /// Gets or sets the nationality list.
        /// </summary>
        /// <value>
        /// The nationality list.
        /// </value>
        public List<Lookup> NationalityList { get; set; }

        /// <summary>
        /// Gets or sets the country list.
        /// </summary>
        /// <value>
        /// The country list.
        /// </value>
        public List<Lookup> CountryList { get; set; }

        /// <summary>
        /// Gets or sets the supplier list.
        /// </summary>
        /// <value>
        /// The supplier list.
        /// </value>
        public List<Lookup> SupplierList { get; set; }

        /// <summary>
        /// Gets or sets the role list.
        /// </summary>
        /// <value>
        /// The role list.
        /// </value>
        public List<RoleDetail> RoleList { get; set; }

        #endregion
    }
}
