﻿using VShips.Contracts.Custom.Crew;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// ApproveAppraisalNavParameter Class
    /// </summary>
    public class ApproveAppraisalNavParameter
    {
        /// <summary>
        /// Gets or sets the appraisal update request.
        /// </summary>
        /// <value>
        /// The appraisal update request.
        /// </value>
        public CrewAppraisalUpdateRequest AppraisalUpdateRequest { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is approve mode.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is approve mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsApproveMode { get; set; }
    }
}
