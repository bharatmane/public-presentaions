﻿using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.DataServices.Shared.Enumerations.Common;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Parameters used in navigating to the Certificates start view.
    /// </summary>
    public class CrewStartParameter 
    {

    }
}
