﻿namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// Services and constants relating to the budget module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}