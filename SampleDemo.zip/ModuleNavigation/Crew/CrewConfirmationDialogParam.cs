﻿using System;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// CrewConfirmationDialogParam Class
    /// </summary>
    public class CrewConfirmationDialogParam
    {
        #region Properties

        /// <summary>
        /// Gets or sets the content of the text.
        /// </summary>
        /// <value>
        /// The content of the text.
        /// </value>
        public object TextContent { get; set; }

        /// <summary>
        /// Gets or sets the content of the UI.
        /// </summary>
        /// <value>
        /// The content of the UI.
        /// </value>
        public object UiContent { get; set; }

        /// <summary>
        /// Gets or sets the closed.
        /// </summary>
        /// <value>
        /// The closed.
        /// </value>
        public Action<bool?> Closed { get; set; }

        #endregion
    }
}