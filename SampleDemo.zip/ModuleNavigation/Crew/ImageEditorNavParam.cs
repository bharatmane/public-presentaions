﻿using System;

namespace VShips.Framework.Common.ModuleNavigation.Crew
{
    /// <summary>
    /// ImageEditorNavParam Class
    /// </summary>
    public class ImageEditorNavParam
    {
        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>
        /// The file path.
        /// </value>
        public string FilePath { get; set; }

        /// <summary>
        /// Gets or sets the file saved.
        /// </summary>
        /// <value>
        /// The file saved.
        /// </value>
        public Action<string> FileSaved { get; set; }
    }
}