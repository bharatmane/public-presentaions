﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.EntityFinanceDashboard
{
    /// <summary>
    /// This class is EntityFinanceDashboardNavigation.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.EntityFinanceDashboard.IEntityFinanceDashboardNavigation" />
    public class EntityFinanceDashboardNavigation : BaseModuleNavigationService, IEntityFinanceDashboardNavigation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EntityFinanceDashboardNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public EntityFinanceDashboardNavigation(INavigationService navigationService)
            : base(navigationService)
        {

        }

        #endregion

        #region Methods  

        /// <summary>
        /// Method for navigation
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="viewName"></param>
        public void NavigateToModule(string moduleName, string viewName)
        {
            NavigationService.NavigateExisting(moduleName, viewName);
        }

        #endregion
    }
}
