﻿namespace VShips.Framework.Common.ModuleNavigation.EntityFinanceDashboard
{
    /// <summary>
    /// Navigation service for the Entity Finance Dashboard module.
    /// </summary>
    public interface IEntityFinanceDashboardNavigation
    {
        /// <summary>
        /// Method for navigation
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="viewName"></param>
        void NavigateToModule(string moduleName, string viewName);
    }
}
