﻿namespace VShips.Framework.Common.ModuleNavigation.EntityFinanceDashboard
{
    /// <summary>
    /// Names of accessible views and regions related to the Entity Finance Dashboard.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "EntityFinanceDashboard";

        /// <summary>
        /// The entity senior MGMT module name.
        /// </summary>
        public const string EntitySrMgmtModuleName = "EntitySeniorManagementDashboard";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "FinanceGeometry";

        /// <summary>
        /// The landing or start view for the Entity Finance Dashboard.
        /// </summary>
        public const string StartView = "EntityFinanceDashboardStartView";

        /// <summary>
        /// The entity senior MGMT start view.
        /// </summary>
        public const string EntitySeniorMgmtStartView = "EntitySeniorMgmtStartView";

        /// <summary>
        /// The entity r2 r dashboard module name.
        /// </summary>
        public const string EntityR2RDashboardModuleName = "EntityR2RDashboard";

        /// <summary>
        /// The entity r2 r dashboard start view.
        /// </summary>
        public const string EntityR2RDashboardStartView = "EntityR2RDashboardStartView";

        /// <summary>
        /// The entity p2 p dashboard module name.
        /// </summary>
        public const string EntityP2PDashboardModuleName = "EntityP2PDashboard";

        /// <summary>
        /// The entity p2 p dashboard start view
        /// </summary>
        public const string EntityP2PDashboardStartView = "EntityP2PDashboardStartView";

        /// <summary>
        /// The entity o2 c dashboard module name
        /// </summary>
        public const string EntityO2CDashboardModuleName = "EntityO2CDashboard";

        /// <summary>
        /// The entity O2C dashboard start view
        /// </summary>
        public const string EntityO2CDashboardStartView = "EntityO2CDashboardStartView";
    }
}
