﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation
{
    /// <summary>
    /// A base class for all module navigation services.
    /// </summary>
    public abstract class BaseModuleNavigationService
    {
        private readonly INavigationService _navigationService;
        /// <summary>
        /// Gets the <see cref="INavigationService"/>.
        /// </summary>
        public INavigationService NavigationService
        {
            get { return _navigationService; }
        }      

        internal BaseModuleNavigationService(INavigationService navigationService)
        {
            _navigationService = navigationService;
        }
    }
}
