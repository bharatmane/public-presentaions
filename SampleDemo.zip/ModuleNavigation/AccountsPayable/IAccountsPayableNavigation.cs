﻿using System;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.Framework.Common.Services;
namespace VShips.Framework.Common.ModuleNavigation.AccountsPayable
{
    /// <summary>
    /// Navigation service for the budget module.
    /// </summary>
    public interface IAccountsPayableNavigation
    {
        /// <summary>
        /// Creates the payable accounts.
        /// </summary>
        void CreatePayableAccounts();
        /// <summary>
        /// Creates the payable accounts.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="selectedVoucher">The selected voucher.</param>
        /// <param name="isNegativeAmount">if set to <c>true</c> [is negative amount].</param>
        void CreatePayableAccounts(object parameter, string selectedVoucher, bool isNegativeAmount);

        /// <summary>
        /// Creates the payable accounts.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        void CreatePayableAccounts(object coyId);
        /// <summary>
        /// Creates the entity payable accounts.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="selectedVoucher">The selected voucher.</param>
        /// <param name="isNegativeAmount">if set to <c>true</c> [is negative amount].</param>
        void CreateEntityPayableAccounts(object parameter, string selectedVoucher, bool isNegativeAmount);

        /// <summary>
        /// Creates the entity payable accounts.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        void CreateEntityPayableAccounts(string coyId);

        /// <summary>
        /// Creates the deferred invoice payments.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="voucherNumber">The voucher number.</param>
        /// <param name="isCalledFromEntity">if set to <c>true</c> [is called from entity].</param>
        /// <param name="isMultiSelect">if set to <c>true</c> [is multi select].</param>
        void CreateDeferredInvoicePayments(string coyId, string voucherNumber, bool isCalledFromEntity, bool isMultiSelect = false);

        /// <summary>
        /// Creates the invoices and credit notes management.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void CreateInvoicesAndCreditNotesManagement(INavigationContext context, object parameter);

        /// <summary>
        /// Creates the entity invoices and credit notes management.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="coyId">The coy identifier.</param>
        void CreateEntityInvoicesAndCreditNotesManagement(INavigationContext context, string coyId);

        /// <summary>
        /// Creates the pre payment invoices.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="voucherNumber">The voucher number.</param>
        /// <param name="isCalledFromEntity">if set to <c>true</c> [is called from entity].</param>
        void CreatePrePaymentInvoices(string coyId, string voucherNumber, bool isCalledFromEntity);
        
        /// <summary>
        /// Creates the payment enquiries.
        /// </summary>
        void CreatePaymentEnquiries();

        /// <summary>
        /// Creates the payment enquiries.
        /// </summary>
        void CreatePaymentEnquiries(object parameter);

        /// <summary>
        /// Creates the confirm payment dailog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="_notProcessedInvoices">The not processed invoices.</param>
        /// <param name="coyType">Type of the coy.</param>
        /// <param name="paymentType">Type of the payment.</param>
        void CreateConfirmPaymentDailog(INavigationContext context, object parameter,object _notProcessedInvoices, VesselEntityType coyType, InvoicePaymentTypeEnum paymentType);

        /// <summary>
        /// Creates the crew confirm payment dailog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="_notProcessedInvoices">The not processed invoices.</param>
        /// <param name="coyType">Type of the coy.</param>
        /// <param name="paymentType">Type of the payment.</param>
        void CreateCrewConfirmPaymentDailog(INavigationContext context, object parameter, object _notProcessedInvoices, VesselEntityType coyType, InvoicePaymentTypeEnum paymentType);

        /// <summary>
        /// Creates the finalise payment dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="listOfInvoice">The list of invoice.</param>
        /// <param name="parameterObject">The parameter object.</param>
        /// <param name="accountsPaymentMethod">The accounts payment method.</param>
        void CreateFinalisePaymentDialog(INavigationContext context, object listOfInvoice, object parameterObject, AccountsPaymentMethod accountsPaymentMethod);

        /// <summary>
        /// Creates the invoice memo dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void CreateInvoiceMemoDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Creates the link invoice and credit note dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vessel">The vessel.</param>
        /// <param name="accountingCompanyTitle">The accounting company title.</param>
        /// <param name="isCallFromEntity">if set to <c>true</c> [is call from entity].</param>
        void CreateLinkInvoiceAndCreditNoteDialog(INavigationContext context, ManagementVesselDetail vessel, string accountingCompanyTitle, bool isCallFromEntity);

        /// <summary>
        /// Creates the link invoice and credit note dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vessel">The vessel.</param>
        /// <param name="accountingCompanyTitle">The accounting company title.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isCallFromEntity">if set to <c>true</c> [is call from entity].</param>
        void CreateLinkInvoiceAndCreditNoteDialog(INavigationContext context, ManagementVesselDetail vessel, string accountingCompanyTitle, object parameter, bool isCallFromEntity);

        /// <summary>
        /// Posts the invoice dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="displayInvoiceNumber">The display invoice no in title.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="postAction">The post action.</param>
        /// <param name="selectNonProcessedInvoicesAction">The select non processed invoices action.</param>
        void PostInvoiceDialog(INavigationContext context, object parameter, string displayInvoiceNumber, object selectedInvoiceList, Action<DateTime?> postAction, Action<object> selectNonProcessedInvoicesAction);

        /// <summary>
        /// Navigates the select for payment.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="saveSuccessfulAction">The save successful action.</param>
        /// <param name="functionalCurrency">The functional currency.</param>
        /// <param name="totalFunctionalAmount">The total functional amount.</param>
        void NavigateSelectForPayment(INavigationContext context, string accountingCompanyId, object selectedInvoiceList, Action<bool, string, string, string> saveSuccessfulAction,string functionalCurrency,Decimal totalFunctionalAmount);

        /// <summary>
        /// Navigates the select for payment.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="saveSuccessfulAction">The save successful action.</param>
        /// <param name="functionalCurrency">The functional currency.</param>
        /// <param name="totalFunctionalAmount">The total functional amount.</param>
        void NavigateSelectForPayment(INavigationContext context, string accountingCompanyId, object selectedInvoiceList, Action<bool, bool, string, string, string> saveSuccessfulAction, string functionalCurrency, Decimal totalFunctionalAmount);

        /// <summary>
        /// Navigates to bank links dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateToBankLinksDialog(INavigationContext context);


        /// <summary>
        /// Navigates to transfer files dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateToTransferFilesDialog(INavigationContext context);

        /// <summary>Accounts payable navigate progress.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sourcePath">The source path.</param>
        /// <param name="destinationPath">The destination path.</param>
        void AccountsPayableNavigateProgress(INavigationContext navigationContext, string sourcePath, string destinationPath);

        /// <summary>
        /// Navigates to electronic payments batch processing.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateToElectronicPaymentsBatchProcessing(INavigationContext navigationContext);

        /// <summary>
        /// Electronics the payments coy summary dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameterDictionary">The parameter dictionary.</param>
        void ElectronicPaymentsCoySummaryDialogView(INavigationContext navigationContext, object parameterDictionary);

        /// <summary>
        /// Electronics the payments batch status dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void ElectronicPaymentsBatchStatusDialogView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates to accounts payable from electronic payments batch process.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAccountsPayableFromElectronicPaymentsBatchProcess(object parameter);

        #region Vessel Crew Accounts Payable Navigation

        /// <summary>
        /// Navigates the crew future posted navigation view.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="voucherNumber">The voucher number.</param>
        void NavigateCrewFuturePostedNavigationView(string coyId, string voucherNumber);

        /// <summary>
        /// Navigates the crew payment on hold navigation view.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="voucherNumber">The voucher number.</param>
        void NavigateCrewPaymentOnHoldNavigationView(string coyId, string voucherNumber);

        /// <summary>
        /// Navigates the crew select for payment dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="saveSuccessfulAction">The save successful action.</param>
        /// <param name="functionalCurrency">The functional currency.</param>
        /// <param name="totalFunctionalAmount">The total functional amount.</param>
        void NavigateCrewSelectForPaymentDialogView(INavigationContext context, string accountingCompanyId, object selectedInvoiceList, Action<bool, string, string, string> saveSuccessfulAction, string functionalCurrency, decimal totalFunctionalAmount);

        /// <summary>
        /// Navigates the crew invoice detail dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        /// <param name="allowToCreateOrReplyToMemo">if set to <c>true</c> [allow to create or reply to memo].</param>
        void NavigateCrewInvoiceDetailDialogView(INavigationContext context, string accountingCompanyId, string voucherNo, string invoiceHeaderId, bool allowToCreateOrReplyToMemo);

        /// <summary>
        /// Crews the post invoice dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="displayInvoiceNumber">The display invoice number.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="postAction">The post action.</param>
        /// <param name="selectNonProcessedInvoicesAction">The select non processed invoices action.</param>
        void CrewPostInvoiceDialog(INavigationContext context, object parameter, string displayInvoiceNumber, object selectedInvoiceList, Action<DateTime?> postAction, Action<object> selectNonProcessedInvoicesAction);

        /// <summary>
        /// Crews the post invoice summary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="totalInvoiceCount">The total invoice count.</param>
        /// <param name="successInvoiceCount">The success invoice count.</param>
        /// <param name="failedInvoiceList">The failed invoice list.</param>
        void CrewPostInvoiceSummaryDialogView(INavigationContext context, int totalInvoiceCount, int successInvoiceCount, object failedInvoiceList);

        /// <summary>
        /// Crews the finalise payment dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="listOfInvoice">The list of invoice.</param>
        /// <param name="parameterObject">The parameter object.</param>
        /// <param name="accountsPaymentMethod">The accounts payment method.</param>
        void CrewFinalisePaymentDialogView(INavigationContext context, object listOfInvoice, object parameterObject, AccountsPaymentMethod accountsPaymentMethod);
        #endregion

        /// <summary>
        /// Navigates the ap overview summary dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        void NavigateAPOverviewSummaryDialog(INavigationContext navigationContext, string accountingCompanyId);

        /// <summary>
        /// Navigates the discounted invoices tabs.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDiscountedInvoicesTabs(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the discounted invoices confirm payment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedPayments">The selected payments.</param>
        /// <param name="coyType">Type of the coy.</param>
        /// <param name="paymentType">Type of the payment.</param>
        void NavigateDiscountedInvoicesConfirmPayment(INavigationContext navigationContext, object selectedPayments, VesselEntityType coyType, InvoicePaymentTypeEnum paymentType);

        /// <summary>
        /// Navigates to payment enquiries.
        /// </summary>
        /// <param name="parameter">The context.</param>
        void NavigateToEntityPaymentEnquiryMainView(object parameter);
    }
}