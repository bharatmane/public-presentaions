﻿
namespace VShips.Framework.Common.ModuleNavigation.AccountsPayable
{
    public class AccountsPayableStartParameter
    {
        #region Properties
        /// <summary>
        /// The filter
        /// </summary>
        private AccountsPayableFilters _filter;

        /// <summary>
        /// Gets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        public AccountsPayableFilters Filter
        {
            get { return _filter; }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountMaintenenceStartParameter"/> class.
        /// </summary>
        public AccountsPayableStartParameter()
        {
            if (_filter == null)
            {
                _filter = new AccountsPayableFilters();
            }
        }

        #endregion
    }
}
