﻿namespace VShips.Framework.Common.ModuleNavigation.AccountsPayable
{
    /// <summary>
    /// Names of accessible views and regions related to the AccountsPayable module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "AccountsPayable";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "AccountsPayableGeometry";

        /// <summary>
        /// The accounts payable moudle tittle
        /// </summary>
        public const string AccountspayableMoudleTittle = "Accounts Payable";
        /// <summary>
        /// The vessel module title
        /// </summary>
        public const string VesselModuleTitle = "Vessel Accounts Payable";
        
        /// <summary>
        /// The entity module title
        /// </summary>
        public const string EntityModuleTitle = "Entity Accounts Payable";

        /// <summary>
        /// The accounts payable icon
        /// </summary>
        public const string InvoiceGeometry = "InvoiceGeometry";
        //Views

        /// <summary>The landing or start view for the AccountsPayable module.</summary>
        public const string StartView = "AccountsPayableStartView";

        /// <summary>The single AccountsPayable entity view.</summary>
        public const string NavItemView = "AccountsPayableStartItemView";

        /// <summary>
        /// The accounts payable start view
        /// </summary>
        public const string AccountsPayableNavigationView = "AccountsPayableNavigationView";

        /// <summary>
        /// The accounts payable entity navigation view
        /// </summary>
        public const string AccountsPayableEntityNavigationView = "AccountsPayableEntityNavigationView";


        /// <summary>
        /// The rollback invoice view
        /// </summary>
        public const string PostInvoiceView = "PostInvoiceView";

        /// <summary>
        /// The select for payment dialog view
        /// </summary>
        public const string SelectForPaymentDialogView = "SelectForPaymentDialogView";

        /// <summary>
        /// The accounts payable overview start view
        /// </summary>
        public const string AccountsPayableOverviewStartView = "AccountsPayableOverviewStartView";

        /// <summary>
        /// The rollback invoice dialog
        /// </summary>
        public const string InvoiceCommentDialog = "InvoiceCommentDialogView";

        /// <summary>
        /// The post invoice summary dialog
        /// </summary>
        public const string PostInvoiceSummaryDialog = "PostInvoiceSummaryDialogView";

        /// <summary>
        /// The deferred invoices navigation view
        /// </summary>
        public const string DeferredInvoicesNavigationView = "DeferredInvoicesNavigationView";

        /// <summary>
        /// The deferred invoices navigation entity view
        /// </summary>
        public const string DeferredInvoicesNavigationEntityView = "DeferredInvoicesNavigationEntityView";

        /// <summary>
        /// The invoice and credit note management navigation view
        /// </summary>
        public const string InvoicesAndCreditNotesManagementNavigationView = "InvoicesAndCreditNotesManagementNavigationView";

        /// <summary>
        /// The entity invoice and credit note management navigation view
        /// </summary>
        public const string EntityInvoiceAndCreditNoteManagementNavigationView = "EntityInvAndCreditNoteMgmtNavigationView";

        /// <summary>
        /// The pre payment invoices navigation view
        /// </summary>
        public const string PrePaymentInvoicesNavigationView = "PrePaymentInvoicesNavigationView";

        /// <summary>
        /// The pre payment invoices navigation entity view
        /// </summary>
        public const string PrePaymentInvoicesNavigationEntityView = "PrePaymentInvoicesNavigationEntityView";

        /// <summary>
        /// The payment enquiry main view
        /// </summary>
        public const string PaymentEnquiryMainView = "PaymentEnquiryMainView";

        /// <summary>
        /// The entity payment enquiry main view
        /// </summary>
        public const string EntityPaymentEnquiryMainView = "EntityPaymentEnquiryMainView";

        /// <summary>
        /// The confirm payment dialog view
        /// </summary>
        public const string ConfirmPaymentDialogView = "ConfirmPaymentDialogView";

        /// <summary>
        /// The crew confirm payment dialog view
        /// </summary>
        public const string CrewConfirmPaymentDialogView = "CrewConfirmPaymentDialogView";

        /// <summary>
        /// The finalise payment dialog view
        /// </summary>
        public const string FinalisePaymentDialogView = "FinalisePaymentDialogView";

        /// <summary>
        /// The link invoice and credit notes dialog view
        /// </summary>
        public const string LinkUnlinkInvoiceAndCreditNotesDialogView = "LinkUnlinkInvoiceAndCreditNotesDialogView";

        /// <summary>
        /// The is called from entity
        /// </summary>
        public const string IsCalledFromEntity = "IsCalledFromEntity";

        /// <summary>
        /// The coy identifier
        /// </summary>
        public const string CoyId = "CoyId";

        /// <summary>
        /// The enity accounting companies
        /// </summary>
        public const string EnityAccountingCompanies = "Enity Accounting Companies";

        /// <summary>
        /// The accounting company identifier
        /// </summary>
        public const string AccountingCompanyId = "CoyId";

        /// <summary>
        /// The folder path
        /// </summary>
        public const string FolderPath = "FolderPath";

        /// <summary>
        /// The source path
        /// </summary>
        public const string SourcePath = "SourcePath";

        /// <summary>
        /// The destination path
        /// </summary>
        public const string DestinationPath = "DestinationPath";

        /// <summary>
        /// The list of selected invoice
        /// </summary>
        public const string ListOfSelectedInvoice = "ListOfSelectedInvoice";

        /// <summary>
        /// The functional currency
        /// </summary>
        public const string FunctionalCurrency = "FunctionalCurrency";

        /// <summary>
        /// The total functional amount
        /// </summary>
        public const string TotalFunctionalAmount = "TotalFunctionalAmount";
        /// <summary>
        /// The parameter object
        /// </summary>
        public const string ParameterObject = "ParameterObject";
        /// <summary>
        /// The accounts payment method enum
        /// </summary>
        public const string AccountsPaymentMethodEnum = "AccountsPaymentMethodEnum";

        /// <summary>
        /// The action after save
        /// </summary>
        public const string ActionAfterSave = "ActionAfterSave";

        /// <summary>
        /// The accounting company type
        /// </summary>
        public const string AccountingCompanyType = "AccountingCompanyType";

        /// <summary>
        /// The ap payee and bank wrapper
        /// </summary>
        public const string APPayeeAndBankWrapper = "APPayeeAndBankWrapper";

        /// <summary>
        /// The invoice and credit note management
        /// </summary>
        public const string InvoiceAndCreditNoteManagement = "Invoice and Credit Note Management";

        /// <summary>
        /// The bank links dialog view
        /// </summary>
        public const string BankLinksDialogView = "Bank Links Dialog View";

        /// <summary>
        /// The transfer files dialog view
        /// </summary>
        public const string TransferFilesDialogView = "Transfer Files Dialog View";

    
        /// <summary>
        /// The transfer files progress bar view
        /// </summary>
        public const string TransferFilesProgressBarView = "Transfer Files Progress Bar View";

        /// <summary>
        /// The electronic bank groups
        /// </summary>
        public const string ElectronicBankGroups = "Electronic Bank Groups";

        /// <summary>
        /// The transfer files
        /// </summary>
        public const string TransferFiles = "Transfer Files";

        /// <summary>
        /// The payment type
        /// </summary>
        public const string PaymentType = "PaymentType";

        /// <summary>
        /// The entity payment enquiry
        /// </summary>
        public const string EntityPaymentEnquiry = "Entity Payment Enquiry";

        /// <summary>
        /// The issue batch processing geometry
        /// </summary>
        public const string IssueBatchProcessingGeometry= "IssueBatchProcessingGeometry";

        /// <summary>
        /// The electronic payments batch processing
        /// </summary>
        public const string ElectronicPaymentsBatchProcessing= "ElectronicPaymentsBatchProcessingView";

        /// <summary>
        /// The batch status
        /// </summary>
        public const string BatchStatus= "Batch Status";

        /// <summary>
        /// The batch identifier
        /// </summary>
        public const string SelectedBatch= "SelectedBatch";

        /// <summary>
        /// From date
        /// </summary>
        public const string FromDate= "FromDate";

        /// <summary>
        /// To date
        /// </summary>
        public const string ToDate="ToDate";

        /// <summary>
        /// The electronic payments coy summary dialog view
        /// </summary>
        public const string ElectronicPaymentsCoySummaryDialogView = "ElectronicPaymentsCoySummaryDialogView";

        /// <summary>
        /// The electronic payments batch status dialog view
        /// </summary>
        public const string ElectronicPaymentsBatchStatusDialogView = "ElectronicPaymentsBatchStatusDialogViewModel";

        /// <summary>
        /// The vessel crew accounts payable navigation view
        /// </summary>
        public const string VesselCrewAccountsPayableNavigationView = "VesselCrewAccountsPayableNavigationView";

        /// <summary>
        /// The vessel crew account payable title
        /// </summary>
        public const string VesselCrewAccountPayableTitle = "Vessel Crew Accounts Payable";

        /// <summary>
        /// The crew future posted navigation view
        /// </summary>
        public const string CrewFuturePostedNavigationView = "CrewFuturePostedNavigationView";

        /// <summary>
        /// The crew payment on hold navigation view
        /// </summary>
        public const string CrewPaymentOnHoldNavigationView = "CrewPaymentOnHoldNavigationView";

        /// <summary>
        /// The crew invoice detail dialog view
        /// </summary>
        public const string CrewInvoiceDetailDialogView = "CrewInvoiceDetailDialogView";

        /// <summary>
        /// The crew select for payment dialog view
        /// </summary>
        public const string CrewSelectForPaymentDialogView = "CrewSelectForPaymentDialogView";


        /// <summary>
        /// The crew post invoice dialog view
        /// </summary>
        public const string CrewPostInvoiceDialogView = "CrewPostInvoiceDialogView";

        /// <summary>
        /// The crew post invoice summary dialog view
        /// </summary>
        public const string CrewPostInvoiceSummaryDialogView = "CrewPostInvoiceSummaryDialogView";

        /// <summary>
        /// The total invoice count
        /// </summary>
        public const string TotalInvoiceCount = "TotalInvoiceCount";

        /// <summary>
        /// The success invoice count
        /// </summary>
        public const string SuccessInvoiceCount = "SuccessInvoiceCount";

        /// <summary>
        /// The failed invoice list
        /// </summary>
        public const string FailedInvoiceList = "FailedInvoiceList";

        /// <summary>
        /// The crew finalise payment dialog view
        /// </summary>
        public const string CrewFinalisePaymentDialogView = "CrewFinalisePaymentDialogView";

        /// <summary>
        /// The crew payment enquiry start view
        /// </summary>
        public const string CrewPaymentEnquiryStartView = "CrewPaymentEnquiryStartView";

        /// <summary>
        /// The ap bank payment summary navigation view
        /// </summary>
        public const string APBankPaymentSummaryNavigationView = "APBankPaymentSummaryNavigationView";

        /// <summary>
        /// The discounted invoices tabs view
        /// </summary>
        public const string DiscountedInvoicesTabsView = "DiscountedInvoicesTabsView";

        /// <summary>
        /// The Discounted Invoices confirm payment dialog view
        /// </summary>
        public const string DIConfirmPaymentDialogView = "DIConfirmPaymentDialogView";

        /// <summary>
        /// The is multi select
        /// </summary>
        public const string IsMultiSelect = "IsMultiSelect";
    }
}
