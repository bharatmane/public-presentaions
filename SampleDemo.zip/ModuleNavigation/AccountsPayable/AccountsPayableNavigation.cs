﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.AccountsPayable
{
    /// <summary>
    /// Default implementation of the <see cref="IAccountsPayableNavigation"/> service.
    /// </summary>
    public class AccountsPayableNavigation : BaseModuleNavigationService, IAccountsPayableNavigation
    {
        /// <summary>
        /// The default contructor for the BudgetNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public AccountsPayableNavigation(INavigationService navigationService) 
            : base(navigationService)
        {
        }

        /// <summary>
        /// Creates the payable accounts.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="selectedVoucher">The selected voucher.</param>
        /// <param name="isNegativeAmount">if set to <c>true</c> [is negative amount].</param>
        public void CreatePayableAccounts(object parameter, string selectedVoucher, bool isNegativeAmount)
        {
            var payableAccountsParameters = new Dictionary<string, object>
            {
                {"Parameter", parameter},
                {"Invoice", selectedVoucher},
                {"IsNegativeAmount", isNegativeAmount}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountsPayableNavigationView, payableAccountsParameters);
        }
        /// <summary>
        /// Creates the payable accounts.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        public void CreatePayableAccounts(object coyId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountsPayableNavigationView, coyId);
        }

        /// <summary>
        /// Creates the entity payable accounts.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="selectedVoucher">The selected voucher.</param>
        /// <param name="isNegativeAmount">if set to <c>true</c> [is negative amount].</param>
        public void CreateEntityPayableAccounts(object parameter, string selectedVoucher, bool isNegativeAmount)
        {
            var payableAccountsEntityParameters = new Dictionary<string, object>
            {
                {"Parameter", parameter},
                {"Invoice", selectedVoucher},
                {"IsNegativeAmount", isNegativeAmount}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountsPayableEntityNavigationView, payableAccountsEntityParameters);
        }
        /// <summary>
        /// Creates the entity payable accounts.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        public void CreateEntityPayableAccounts(string coyId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountsPayableEntityNavigationView, coyId);
        }
        
        /// <summary>
        /// Creates the payable accounts.
        /// </summary>
        public void CreatePayableAccounts()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountsPayableNavigationView);
        }

        /// <summary>
        /// Creates the deferred invoice payments.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="selectedVoucher">The selected voucher.</param>
        /// <param name="isCalledFromEntity">if set to <c>true</c> [is called from entity].</param>
        /// <param name="isMultiSelect">if set to <c>true</c> [is multi select].</param>
        public void CreateDeferredInvoicePayments(string coyId, string selectedVoucher, bool isCalledFromEntity, bool isMultiSelect = false)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.CoyId, coyId},
                {"Voucher", selectedVoucher},
                {Constants.IsCalledFromEntity, isCalledFromEntity},
                {Constants.IsMultiSelect, isMultiSelect}
            };
            if (isCalledFromEntity)
            {
                NavigationService.NavigateExisting(Constants.ModuleName, Constants.DeferredInvoicesNavigationEntityView, parameters);
            }
            else
            {
                NavigationService.NavigateExisting(Constants.ModuleName, Constants.DeferredInvoicesNavigationView, parameters);
            }
        }

        /// <summary>
        /// Creates the invoices and credit notes management.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter">The parameter.</param>
        public void CreateInvoicesAndCreditNotesManagement(INavigationContext context, object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.InvoicesAndCreditNotesManagementNavigationView, parameter,context);
        }

        /// <summary>
        /// Creates the entity invoices and credit notes management.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="coyId">The coy identifier.</param>
        public void CreateEntityInvoicesAndCreditNotesManagement(INavigationContext context, string coyId)
        {            
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityInvoiceAndCreditNoteManagementNavigationView, coyId, context);
        }       

        /// <summary>
        /// Creates the pre payment invoices.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="selectedVoucher">The selected voucher.</param>
        /// <param name="isCalledFromEntity">if set to <c>true</c> [is called from entity].</param>
        public void CreatePrePaymentInvoices(string coyId, string selectedVoucher, bool isCalledFromEntity)
        {
            var parameters = new Dictionary<string, object>
            {
                {"CoyId", coyId},
                {"Voucher", selectedVoucher},
                {"IsCalledFromEntity", isCalledFromEntity}
            };
            if (isCalledFromEntity)
            {
                NavigationService.NavigateExisting(Constants.ModuleName, Constants.PrePaymentInvoicesNavigationEntityView, parameters);
            }
            else
            {
                NavigationService.NavigateExisting(Constants.ModuleName, Constants.PrePaymentInvoicesNavigationView, parameters);
            }
        }

        /// <summary>
        /// Creates the payment enquiries.
        /// </summary>
        public void CreatePaymentEnquiries()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.PaymentEnquiryMainView);
        }

        /// <summary>
        /// Creates the payment enquiries.
        /// </summary>
        /// <param name="parameter"></param>
        public void CreatePaymentEnquiries(object parameter)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.PaymentEnquiryMainView,parameter);
        }

        /// <summary>
        /// Creates the confirm payment dailog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="_supplierInvoiceList">The supplier invoice list.</param>
        /// <param name="coyType">Type of the coy.</param>
        /// <param name="paymentType">Type of the payment.</param>
        public void CreateConfirmPaymentDailog(INavigationContext context, object parameter,object _supplierInvoiceList, VesselEntityType coyType, InvoicePaymentTypeEnum paymentType)
        {
            var param = new Dictionary<string, object>()
            {
                {Constants.ListOfSelectedInvoice,parameter },
                {Constants.AccountingCompanyType, coyType},
                {Constants.APPayeeAndBankWrapper,_supplierInvoiceList },
                {Constants.PaymentType,paymentType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ConfirmPaymentDialogView, context, param);
        }

        /// <summary>Creates the crew confirm payment dailog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="_supplierInvoiceList">The supplier invoice list.</param>
        /// <param name="coyType">Type of the coy.</param>
        /// <param name="paymentType">Type of the payment.</param>
        public void CreateCrewConfirmPaymentDailog(INavigationContext context, object parameter, object _supplierInvoiceList, VesselEntityType coyType, InvoicePaymentTypeEnum paymentType)
        {
            var param = new Dictionary<string, object>()
            {
                {Constants.ListOfSelectedInvoice,parameter },
                {Constants.AccountingCompanyType, coyType},
                {Constants.APPayeeAndBankWrapper,_supplierInvoiceList },
                {Constants.PaymentType,paymentType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewConfirmPaymentDialogView, context, param);
        }

        /// <summary>
        /// Creates the finalise payment dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="listOfInvoice">The list of invoice.</param>
        /// <param name="parameterObject">The parameter object.</param>
        /// <param name="accountsPaymentMethod">The accounts payment method.</param>
        public void CreateFinalisePaymentDialog(INavigationContext context, object listOfInvoice, object parameterObject, AccountsPaymentMethod accountsPaymentMethod)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.ListOfSelectedInvoice, listOfInvoice},
                {Constants.ParameterObject, parameterObject},
                {Constants.AccountsPaymentMethodEnum, accountsPaymentMethod}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FinalisePaymentDialogView, context, parameters);
        }

        /// <summary>
        /// Creates the invoice memo dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CreateInvoiceMemoDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(VShips.Framework.Common.ModuleNavigation.Common.Constants.ModuleName, VShips.Framework.Common.ModuleNavigation.Common.Constants.CreateInvoiceMemoDialogView, context, parameter);
        }

        /// <summary>
        /// Creates the link invoice and credit note dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vessel">The vessel.</param>
        /// <param name="accountingCompanyTitle">The accounting company title.</param>
        /// <param name="isCallFromEntity">if set to <c>true</c> [is call from entity].</param>
        public void CreateLinkInvoiceAndCreditNoteDialog(INavigationContext context, ManagementVesselDetail vessel, string accountingCompanyTitle, bool isCallFromEntity)
        {
            var parameters = new Dictionary<string, object>
            {
                {"Vessel", vessel},
                {"AccountingCompanyTitle", accountingCompanyTitle},
                {"IsCalledFromEntity", isCallFromEntity}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkUnlinkInvoiceAndCreditNotesDialogView, context, parameters);
        }

        /// <summary>
        /// Creates the link invoice and credit note dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vessel">The vessel.</param>
        /// <param name="accountingCompanyTitle">The accounting company title.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isCallFromEntity">if set to <c>true</c> [is call from entity].</param>
        public void CreateLinkInvoiceAndCreditNoteDialog(INavigationContext context, ManagementVesselDetail vessel, string accountingCompanyTitle, object parameter, bool isCallFromEntity)
        {
            var parameters = new Dictionary<string, object>
            {                
                {"Vessel", vessel},
                {"AccountingCompanyTitle", accountingCompanyTitle},
                {"Parameter", parameter},
                {"IsCalledFromEntity", isCallFromEntity}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkUnlinkInvoiceAndCreditNotesDialogView, context, parameters);
        }

        /// <summary>
        /// Posts the invoice dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="displayInvoiceNumber">The display invoice no in title.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="postAction">The post action.</param>
        /// <param name="selectNonProcessedInvoicesAction">The select non processed invoices action.</param>
        public void PostInvoiceDialog(INavigationContext context, object parameter, string displayInvoiceNumber, object selectedInvoiceList, Action<DateTime?> postAction, Action<object> selectNonProcessedInvoicesAction)
        {
            var parameters = new Dictionary<string, object>
            {
                {"Parameter", parameter},
                {"DisplayInvoiceNumber", displayInvoiceNumber},
                {"SelectedInvoiceList", selectedInvoiceList},
                {"PostAction", postAction },
                {"SelectNonProcessedInvoicesAction", selectNonProcessedInvoicesAction }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PostInvoiceView, context, parameters);
        }

        /// <summary>
        /// Navigates the select for payment.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="saveSuccessfulAction">The save successful action.</param>
        /// <param name="functionalCurrency">The functional currency.</param>
        /// <param name="totalFunctionalAmount">The total functional amount.</param>
        public void NavigateSelectForPayment(INavigationContext context, string accountingCompanyId, object selectedInvoiceList, Action<bool, string, string, string> saveSuccessfulAction,string functionalCurrency,Decimal totalFunctionalAmount)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.ListOfSelectedInvoice, selectedInvoiceList},
                {Constants.ActionAfterSave, saveSuccessfulAction},
                {Constants.FunctionalCurrency,functionalCurrency },
                {Constants.TotalFunctionalAmount,totalFunctionalAmount }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectForPaymentDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the select for payment.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="saveSuccessfulAction">The save successful action.</param>
        /// <param name="functionalCurrency">The functional currency.</param>
        /// <param name="totalFunctionalAmount">The total functional amount.</param>
        public void NavigateSelectForPayment(INavigationContext context, string accountingCompanyId, object selectedInvoiceList, Action<bool, bool, string, string, string> saveSuccessfulAction, string functionalCurrency, Decimal totalFunctionalAmount)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.ListOfSelectedInvoice, selectedInvoiceList},
                {Constants.ActionAfterSave, saveSuccessfulAction},
                {Constants.FunctionalCurrency,functionalCurrency },
                {Constants.TotalFunctionalAmount,totalFunctionalAmount }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectForPaymentDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to bank links dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateToBankLinksDialog(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BankLinksDialogView, context);
        }

        /// <summary>
        /// Navigates to transfer files dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateToTransferFilesDialog(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TransferFilesDialogView, context);
        }

        
        /// <summary>Accounts payable navigate progress.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sourcePath">The source path.</param>
        /// <param name="destinationPath">The destination path.</param>
        public void AccountsPayableNavigateProgress(INavigationContext navigationContext, string sourcePath, string destinationPath)
        {
            var parameter = new Dictionary<string, object>
            {
                {Constants.SourcePath, sourcePath},
                {Constants.DestinationPath, destinationPath},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TransferFilesProgressBarView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to electronic payments batch processing.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToElectronicPaymentsBatchProcessing(INavigationContext navigationContext)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ElectronicPaymentsBatchProcessing);
        }

        /// <summary>
        /// Electronics the payments coy summary dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameterDictionary">The parameter dictionary.</param>
        public void ElectronicPaymentsCoySummaryDialogView(INavigationContext navigationContext, object parameterDictionary)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ElectronicPaymentsCoySummaryDialogView, navigationContext, parameterDictionary);
        }

        /// <summary>
        /// Electronics the payments batch status dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void ElectronicPaymentsBatchStatusDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ElectronicPaymentsBatchStatusDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates to accounts payable from electronic payments batch process.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAccountsPayableFromElectronicPaymentsBatchProcess(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountsPayableNavigationView, parameter);
        }

        #region Vessel Crew Accounts Payable Navigation

        /// <summary>
        /// Navigates the crew future posted navigation view.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="voucherNumber">The voucher number.</param>
        public void NavigateCrewFuturePostedNavigationView(string coyId, string voucherNumber)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {"CoyId", coyId},
                {"Voucher", voucherNumber}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewFuturePostedNavigationView, parameters);            
        }

        /// <summary>
        /// Navigates the crew payment on hold navigation view.
        /// </summary>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="voucherNumber">The voucher number.</param>
        public void NavigateCrewPaymentOnHoldNavigationView(string coyId, string voucherNumber)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {"CoyId", coyId},
                {"Voucher", voucherNumber}
            };

            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewPaymentOnHoldNavigationView, parameters);            
        }

        /// <summary>
        /// Navigates the crew select for payment dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="saveSuccessfulAction">The save successful action.</param>
        /// <param name="functionalCurrency">The functional currency.</param>
        /// <param name="totalFunctionalAmount">The total functional amount.</param>
        public void NavigateCrewSelectForPaymentDialogView(INavigationContext context, string accountingCompanyId, object selectedInvoiceList, Action<bool, string, string, string> saveSuccessfulAction, string functionalCurrency, decimal totalFunctionalAmount)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.ListOfSelectedInvoice, selectedInvoiceList},
                {Constants.ActionAfterSave, saveSuccessfulAction},
                {Constants.FunctionalCurrency,functionalCurrency },
                {Constants.TotalFunctionalAmount,totalFunctionalAmount }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewSelectForPaymentDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the crew invoice detail dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        /// <param name="allowToCreateOrReplyToMemo">if set to <c>true</c> [allow to create or reply to memo].</param>
        public void NavigateCrewInvoiceDetailDialogView(INavigationContext context, string accountingCompanyId, string voucherNo, string invoiceHeaderId, bool allowToCreateOrReplyToMemo)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Common.Constants.AccountingCompanyId, accountingCompanyId},
                {Common.Constants.VoucherNo, voucherNo},
                {Common.Constants.InvoiceHeaderId, invoiceHeaderId},
                {Common.Constants.AllowToCreateOrReplyToMemo, allowToCreateOrReplyToMemo}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewInvoiceDetailDialogView, context, parameter);
        }

        /// <summary>
        /// Crews the post invoice dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="displayInvoiceNumber">The display invoice number.</param>
        /// <param name="selectedInvoiceList">The selected invoice list.</param>
        /// <param name="postAction">The post action.</param>
        /// <param name="selectNonProcessedInvoicesAction">The select non processed invoices action.</param>
        public void CrewPostInvoiceDialog(INavigationContext context, object parameter, string displayInvoiceNumber, object selectedInvoiceList, Action<DateTime?> postAction, Action<object> selectNonProcessedInvoicesAction)
        {
            var parameters = new Dictionary<string, object>
            {
                {"Parameter", parameter},
                {"DisplayInvoiceNumber", displayInvoiceNumber},
                {"SelectedInvoiceList", selectedInvoiceList},
                {"PostAction", postAction },
                {"SelectNonProcessedInvoicesAction", selectNonProcessedInvoicesAction }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewPostInvoiceDialogView, context, parameters);
        }

        /// <summary>
        /// Crews the post invoice summary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="totalInvoiceCount">The total invoice count.</param>
        /// <param name="successInvoiceCount">The success invoice count.</param>
        /// <param name="failedInvoiceList">The failed invoice list.</param>
        public void CrewPostInvoiceSummaryDialogView(INavigationContext context, int totalInvoiceCount, int successInvoiceCount, object failedInvoiceList)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.TotalInvoiceCount,totalInvoiceCount },
                {Constants.SuccessInvoiceCount, successInvoiceCount },
                {Constants.FailedInvoiceList,failedInvoiceList }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewPostInvoiceSummaryDialogView, context, parameters);
        }

        /// <summary>
        /// Crews the finalise payment dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="listOfInvoice">The list of invoice.</param>
        /// <param name="parameterObject">The parameter object.</param>
        /// <param name="accountsPaymentMethod">The accounts payment method.</param>
        public void CrewFinalisePaymentDialogView(INavigationContext context, object listOfInvoice, object parameterObject, AccountsPaymentMethod accountsPaymentMethod)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.ListOfSelectedInvoice, listOfInvoice},
                {Constants.ParameterObject, parameterObject},
                {Constants.AccountsPaymentMethodEnum, accountsPaymentMethod}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewFinalisePaymentDialogView, context, parameters);
        }
        #endregion

        /// <summary>
        /// Navigates the ap overview summary dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        public void NavigateAPOverviewSummaryDialog(INavigationContext navigationContext, string accountingCompanyId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.APBankPaymentSummaryNavigationView, navigationContext, accountingCompanyId);
        }

        /// <summary>
        /// Navigates the discounted invoices tabs.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDiscountedInvoicesTabs(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.DiscountedInvoicesTabsView, parameter, navigationContext);
        }

        /// <summary>
        /// Navigates the discounted invoices confirm payment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedPayments">The selected payments.</param>
        /// <param name="coyType">Type of the coy.</param>
        /// <param name="paymentType">Type of the payment.</param>
        public void NavigateDiscountedInvoicesConfirmPayment(INavigationContext navigationContext, object selectedPayments, VesselEntityType coyType, InvoicePaymentTypeEnum paymentType)
        {
            var param = new Dictionary<string, object>()
            {
                {Constants.AccountingCompanyType, coyType},
                {Constants.APPayeeAndBankWrapper, selectedPayments},
                {Constants.PaymentType,paymentType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DIConfirmPaymentDialogView, navigationContext, param);
        }

        /// <summary>
        /// Navigates to payment enquiries.
        /// </summary>
        /// <param name="parameter">The context.</param>
        public void NavigateToEntityPaymentEnquiryMainView(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityPaymentEnquiryMainView, parameter);
        }
    }
}
