﻿namespace VShips.Framework.Common.ModuleNavigation.AccountsPayable
{
    /// <summary>
    /// Services and constants relating to the AccountsPayable module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
