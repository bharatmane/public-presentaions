﻿using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.ModuleNavigation.AccountsPayable
{
    /// <summary>
    /// Left side tree filter for accounts payable
    /// </summary>
    public class AccountsPayableFilters
    {
        #region Properties
        /// <summary>
        /// The search string
        /// </summary>
        private string _searchString;

        /// <summary>
        /// Gets or sets the search string.
        /// </summary>
        /// <value>
        /// The search string.
        /// </value>
        public string SearchString
        {
            get { return _searchString; }
            set
            {
                _searchString = value;
            }
        }

        /// <summary>
        /// Gets or sets the menu item.
        /// </summary>
        /// <value>
        /// The menu item.
        /// </value>
        public UserMenuItem MenuItem { get; set; }
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountsPayableFilters"/> class.
        /// </summary>
        public AccountsPayableFilters()
        {

        }
        #endregion
    }
}
