﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DundasBI
{
    public class DundasBINavigation : BaseModuleNavigationService, IDundasBINavigation
    {
        public DundasBINavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }
        
        public void NavigateDundasBI(INavigationContext navigationContext)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView, navigationContext);
        }

    }
}
