﻿#pragma warning disable 1591

namespace VShips.Framework.Common.ModuleNavigation.DundasBI
{
    public class Constants
    {
        public const string ModuleName = "DundasBI";

        public const string ModuleTitle = "Shipsure BI";

        public const string ModuleIcon = "CertificatesGeometry";

        public const string StartView = "DundasBIStartView";
    }
}