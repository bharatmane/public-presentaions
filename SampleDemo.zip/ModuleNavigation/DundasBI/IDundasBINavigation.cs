﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DundasBI
{
    public interface IDundasBINavigation
    {
        void NavigateDundasBI(INavigationContext navigationContext);
    }
}
