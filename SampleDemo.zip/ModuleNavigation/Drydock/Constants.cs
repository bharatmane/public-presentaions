﻿namespace VShips.Framework.Common.ModuleNavigation.Drydock
{
    /// <summary>
    /// Constants for Drydock module navigation.
    /// </summary>
    public class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "Drydock";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "MoveToDrydockGeometry";

        /// <summary>
        /// The drydock start view.
        /// </summary>
        public const string DrydockStartView = "DrydockStartView";

        /// <summary>
        /// The manage drydock navigation view.
        /// </summary>
        public const string ManageDrydockNavigationView = "ManageDrydockNavigationView";

        /// <summary>
        /// The add edit drydock variance view.
        /// </summary>
        public const string AddEditDrydockVarianceView = "AddEditDrydockVarianceView";
    }
}
