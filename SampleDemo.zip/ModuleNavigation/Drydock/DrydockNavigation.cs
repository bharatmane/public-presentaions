﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Drydock
{
    /// <summary>
    /// Navigation Service for Drydock Navigation.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.Drydock.IDrydockNavigation" />
    public class DrydockNavigation : BaseModuleNavigationService, IDrydockNavigation
    {
        #region Constructor

        /// <summary>
        /// The default constructor for the Drills and Campaigns.
        /// </summary>
        /// <param name="navigationService">The navigation service of type<see cref="INavigationService"/>.</param>
        public DrydockNavigation(INavigationService navigationService)
            : base(navigationService)
        { }

        #endregion

        #region Methods

        /// <summary>
        /// Navigates to manage drydock.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToManageDrydock(DrydockNavigationParameter parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ManageDrydockNavigationView, parameters);
        }

        /// <summary>
        /// Navigates to add edit drydock variance.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditDrydockVariance(INavigationContext navigationContext, DrydockNavigationParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditDrydockVarianceView, navigationContext, parameter);
        }

        #endregion
    }
}
