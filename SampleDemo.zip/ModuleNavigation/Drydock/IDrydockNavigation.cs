﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Drydock
{
    /// <summary>
    /// Interface for Drydock navigation.
    /// </summary>
    public interface IDrydockNavigation
    {
        /// <summary>
        /// Navigates to manage drydock.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void NavigateToManageDrydock(DrydockNavigationParameter parameters);

        /// <summary>
        /// Navigates to add edit drydock variance.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditDrydockVariance(INavigationContext navigationContext, DrydockNavigationParameter parameter);
    }
}
