﻿using System;
using System.Threading;
using System.Threading.Tasks;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.Drydock
{
    /// <summary>
    /// Parameter class used for filters in Drydock module.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class DrydockStartParameter : BaseViewModel
    {
        #region Actions

        /// <summary>
        /// The filter changed.
        /// </summary>
        public Action FilterChanged;        

        #endregion

        #region Properties

        /// <summary>
        /// The menu item.
        /// </summary>
        private UserMenuItem _menuItem;

        /// <summary>
        /// Gets or sets the menu item.
        /// </summary>
        /// <value>
        /// The menu item.
        /// </value>
        public UserMenuItem MenuItem
        {
            get { return _menuItem; }
            set
            {
                if (Set(() => MenuItem, ref _menuItem, value))
                {
                    OnMenuItemChanged();
                }
            }
        }

        /// <summary>
        /// The start date.
        /// </summary>
        private DateTime? _startDate;

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime? StartDate
        {
            get { return _startDate; }
            set
            {
                if (Set(() => StartDate, ref _startDate, value))
                {
                    OnStartDateChanged();
                }
            }
        }

        /// <summary>
        /// The end date.
        /// </summary>
        private DateTime? _endDate;

        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>
        public DateTime? EndDate
        {
            get { return _endDate; }
            set
            {
                if (Set(() => EndDate, ref _endDate, value))
                {
                    OnEndDateChanged();
                }
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DrydockStartParameter"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public DrydockStartParameter(INavigationContext context)
            : base(context)
        {
            SetDefaultDates();
            SetVesselIfVesselView();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Sets the vessel if vessel view.
        /// </summary>
        private void SetVesselIfVesselView()
        {
            if (IsVesselView && VMService.ModuleService.VesselDetails != null && !string.IsNullOrWhiteSpace(VMService.ModuleService.VesselDetails.VesselId))
            {
                _menuItem = new UserMenuItem()
                {
                    Identifier = VMService.ModuleService.VesselDetails.VesselId,
                    UserMenuItemType = UserMenuItemType.Vessel
                };

                //Task task = SetVesselName();
            }
        }

        /// <summary>
        /// Sets the name of the vessel.
        /// </summary>
        public async Task SetVesselName()
        {
            AddIsBusy();
            VesselPreview vesselDetail = null;
            ReleaseCurrentCancelationToken();
            CancellationToken token = CreateCurrentCancelationToken();

            try
            {
                vesselDetail = await VMService.DataService.Vessels.GetVesselHeaderDetail(VMService.ModuleService.VesselDetails.VesselId, token);
            }
            catch (OperationCanceledException) { }
            finally { RemoveIsBusy(); }

            if (vesselDetail != null && _menuItem != null)
            {
                _menuItem.DisplayText = vesselDetail.Name;
            }
        }

        /// <summary>
        /// Sets the default dates.
        /// </summary>
        private void SetDefaultDates()
        {
            _startDate = DateTime.Now.Date;
            _endDate = DateTime.Now.Date.AddYears(1);

            RaisePropertyChanged(() => StartDate);
            RaisePropertyChanged(() => EndDate);
        }

        /// <summary>
        /// Sets the dates.
        /// </summary>
        /// <param name="fromDate">From date.</param>
        /// <param name="toDate">To date.</param>
        public void SetDates(DateTime fromDate, DateTime toDate)
        {
            _startDate = fromDate;
            _endDate = toDate;

            RaisePropertyChanged(() => StartDate);
            RaisePropertyChanged(() => EndDate);
        }

        /// <summary>
        /// Raises the filter changed.
        /// </summary>
        private void RaiseFilterChanged()
        {
            if (FilterChanged != null)
            {
                FilterChanged();
            }
        }

        /// <summary>
        /// Called when [start date changed].
        /// </summary>
        private void OnStartDateChanged()
        {
            if (_startDate != null && _startDate.Value > EndDate)
            {
                _endDate = _startDate;
                RaisePropertyChanged(() => EndDate);
            }

            RaiseFilterChanged();
        }

        /// <summary>
        /// Called when [end date changed].
        /// </summary>
        private void OnEndDateChanged()
        {
            if (_endDate != null && _endDate.Value < StartDate)
            {
                _startDate = _endDate;
                RaisePropertyChanged(() => StartDate);
            }

            RaiseFilterChanged();
        }

        /// <summary>
        /// Called when [menu item changed].
        /// </summary>
        private void OnMenuItemChanged()
        {
        }

        #endregion

        #region Cleanup

        /// <summary>
        /// Cleans up the instance resources.
        /// <para>
        /// To cleanup additional resources, override this method, clean up and then call base.Cleanup().
        /// </para>
        /// </summary>
        public override void Cleanup()
        {
            FilterChanged = null;

            base.Cleanup();
        }

        #endregion
    }
}
