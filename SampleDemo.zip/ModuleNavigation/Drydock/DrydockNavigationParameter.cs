﻿using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.ModuleNavigation.Drydock
{
    /// <summary>
    /// Parameters for Drydock Navigation.
    /// </summary>
    public class DrydockNavigationParameter
    {
        /// <summary>
        /// Gets or sets the selected user menu item.
        /// </summary>
        /// <value>
        /// The selected user menu item.
        /// </value>
        public UserMenuItem SelectedUserMenuItem { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the drydock identifier.
        /// </summary>
        /// <value>
        /// The drydock identifier.
        /// </value>
        public string DrydockId { get; set; }

        /// <summary>
        /// Gets or sets the variance order identifier.
        /// </summary>
        /// <value>
        /// The variance order identifier.
        /// </value>
        public string VarianceOrderId { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }
    }
}
