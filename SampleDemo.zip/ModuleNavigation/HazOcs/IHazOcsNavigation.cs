﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.HazOcs
{
    /// <summary>
    /// Navigation service for the haz ocs module.
    /// </summary>
    public interface IHazOcsNavigation
    {
        /// <summary>
        /// Navigates to the haz occs module start view.
        /// </summary>
        void NavigateStart();

        /// <summary>
        ///  Navigates to the haz occs module landing page
        /// </summary>
        void NavigateLandingPage();

        /// <summary>
        /// Navigates to the haz occs module start view for a particualr vessel.
        /// </summary>
        void NavigateVesselStart(HazOcsParameter param);

        /// <summary>
        /// Navigates to the haz occs module start view for a particualr vessel in new tab.
        /// </summary>
        void NavigateVesselStartNew(HazOcsParameter param);

        /// <summary>
        /// Navigates to the haz occs module record view.
        /// </summary>
        void NavigateDetail(object request);

        /// <summary>
        /// Navigates to the CreateReport view
        /// </summary>
        void CreateReport(INavigationContext context, string vesselId = null);

        /// <summary>
        /// Navigates to the Analysis view
        /// </summary>
        void NavigateAnalysis(INavigationContext context, HazOcsParameter param);

        /// <summary>
        /// Navigates to the Create Witness view
        /// </summary>
        void CreateWitness(INavigationContext context, string reportId = null);

        /// <summary>
        /// Navigates to the haz occs module start view in a new tab.
        void NavigateVesselStartExisting(HazOcsParameter param);

        /// Navigates to the haz occs module file dialog
        void NavigateFileDialog(INavigationContext context, string documentId = null, string reportId = null,
            IEnumerable<string> fileNames = null);

        /// <summary>
        /// Navigates to the Statement details popup
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        void NavigateToStatementDetails(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to the Statement details popup
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        void NavigateToWitnessDetails(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to close report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToCloseReport(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to map parent.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToMapParent(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to notification edit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToNotificationEdit(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to corrections edit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedAction">The selected action.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="_incidentDate">The incident date.</param>
        void NavigateToCorrectionsEdit(INavigationContext context, string reportId, string vesselId, object selectedAction, string parentId, DateTime? _incidentDate);

        /// <summary>
        /// Navigates to corrections view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedAction">The selected action.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateToCorrectionsView(INavigationContext context, string reportId, string vesselId, object selectedAction, string parentId);

        /// <summary>
        /// Navigates the close action.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedActions">The selected actions.</param>
        void NavigateCloseAction(INavigationContext navigationContext, string parentId, string vesselId, object selectedActions);

        /// <summary>
        /// Navigates the add haz occ.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddHazOccDialog(INavigationContext context, HazOcsParameter parameter);

        /// <summary>
        /// Navigates the add accident report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateAddAccidentReportDialog(INavigationContext context, string parentId, string vesselId);

        /// <summary>
        /// Navigates the add incident report dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddIncidentReportDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the add near miss dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateAddNearMissDialog(INavigationContext context, string parentId, string vesselId);

        /// <summary>
        /// Navigates the add unsafe act dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateAddUnsafeActDialog(INavigationContext context, string parentId, string vesselId);

        /// <summary>
        /// Navigates the add unsafe condition dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateAddUnsafeConditionDialog(INavigationContext context, string parentId, string vesselId);


        /// <summary>
        /// Navigates the add safe act dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="reportTypeId">The report type identifier.</param>
        void NavigateAddSafeActDialog(INavigationContext context, string parentId, string vesselId, string reportTypeId);

        /// <summary>
        /// Navigates the add safe condition dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateAddSafeConditionDialog(INavigationContext context, string parentId, string vesselId);

        /// <summary>
        /// Navigates the add illness dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateAddIllnessDialog(INavigationContext context, string parentId, string vesselId);

        /// <summary>
        /// Navigates the reopen report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateReopenReport(INavigationContext context, HazOcsParameter parameters);

        /// <summary>
        /// Navigates to link defect view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentParameters">The component parameters.</param>
        void NavigateToLinkDefectView(INavigationContext navigationContext, Dictionary<string, object> componentParameters);

        /// <summary>
        /// Navigates to show reopen comment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reopenCommentParameter">The reopen comment parameter.</param>
        void NavigateToShowReopenComment(INavigationContext navigationContext, object reopenCommentParameter);

        /// <summary>
        /// Navigates the mexp HRS view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateMexpHrsView(INavigationContext navigationContext, object navigationParameter);

        /// <summary>
        /// Navigates the view description and comment view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateViewDescriptionAndCommentView(INavigationContext navigationContext, object navigationParameter);

        /// <summary>
        /// Navigates to the link insurance claim dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToLinkInsuranceClaimDialogView(INavigationContext context, HazOcsParameter parameters);
    }
}
