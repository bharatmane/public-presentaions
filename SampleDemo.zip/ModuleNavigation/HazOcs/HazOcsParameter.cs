﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.HazardousOccurrences;
using VShips.Contracts.DtoClasses;

namespace VShips.Framework.Common.ModuleNavigation.HazOcs
{
    /// <summary>Th paramteter used in filtering and navigation on HazOcs</summary>
    public class HazOcsParameter
    {
        #region Properties

        /// <summary>
        /// Gets or sets the incident visibilities.
        /// </summary>
        /// <value>
        /// The incident visibilities.
        /// </value>
        public object IncidentVisibilities { get; set; }

        /// <summary>
        /// Gets or sets the selected incident identifier.
        /// </summary>
        /// <value>
        /// The selected incident identifier.
        /// </value>
        public string SelectedIncidentId { get; set; }

        /// <summary>
        /// The incident filter.
        /// </summary>
        public IncidentFilter IncidentFilter { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the statement identifier.
        /// </summary>
        /// <value>
        /// The statement identifier.
        /// </value>
        public string StatementId { get; set; }

        /// <summary>
        /// Gets or sets the report identifier.
        /// </summary>
        /// <value>
        /// The report identifier.
        /// </value>
        public string ReportId { get; set; }

        //public string SelectedNotification { get; set; }

        /// <summary>Gets or sets the inn identifier.</summary>
        /// <value>The inn identifier.</value>
        public string InnId { get; set; }

        /// <summary>Gets or sets the notification by identifier.</summary>
        /// <value>The notification by identifier.</value>
        public string NotificationById { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        public string FirstName { get; set; }
        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the notification date.
        /// </summary>
        /// <value>
        /// The notification date.
        /// </value>
        public DateTime? NotificationDate { get; set; }

        /// <summary>
        /// Gets or sets the notification parameter.
        /// </summary>
        /// <value>
        /// The notification parameter.
        /// </value>
        public IncidentPreview NotificationParameter { get; set; }

        /// <summary>
        /// Gets or sets the selected notification.
        /// </summary>
        /// <value>
        /// The selected notification.
        /// </value>
        public IncidentNotification SelectedNotification { get; set; }

        /// <summary>
        /// Gets or sets the iae identifier.
        /// </summary>
        /// <value>
        /// The iae identifier.
        /// </value>
        public string IaeId { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the incident date.
        /// </summary>
        /// <value>
        /// The incident date.
        /// </value>
        public DateTime IncidentDate { get; set; }

        /// <summary>
        /// Gets or sets the incident common detail.
        /// </summary>
        /// <value>
        /// The incident common detail.
        /// </value>
        public object IncidentCommonDetail { get; set; }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has access to medical manager.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has access to medical manager; otherwise, <c>false</c>.
        /// </value>
        public bool HasAccessToMedicalManager { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value.
        /// </value>
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets the popup title.
        /// </summary>
        /// <value>
        /// The popup title.
        /// </value>
        public string PopupTitle { get; set; }

        /// <summary>
        /// Gets or sets the reference number.
        /// </summary>
        /// <value>
        /// The reference number.
        /// </value>
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the claim ids.
        /// </summary>
        /// <value>
        /// The claim ids.
        /// </value>
        public List<string> ClaimIds { get; set; }

        /// <summary>
        /// Gets or sets the type classification ids.
        /// </summary>
        /// <value>
        /// The type classification ids.
        /// </value>
        public List<HazOccTypeDetailResponse> TypeClassificationIds { get; set; }

        /// <summary>
        /// Gets or sets the haz occ search text.
        /// </summary>
        /// <value>
        /// The haz occ search text.
        /// </value>
        public string HazOccSearchText { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// The default constructor.
        /// </summary>
        public HazOcsParameter()
        {
            IncidentFilter = new IncidentFilter();
        }

        #endregion
    }
}
