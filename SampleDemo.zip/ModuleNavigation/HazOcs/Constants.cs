﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using VShips.DataServices.Shared.Enumerations;
using VShips.DataServices.Shared.Enumerations.Vessel;
namespace VShips.Framework.Common.ModuleNavigation.HazOcs
{
    /// <summary>
    /// Names of accessible views and regions related to the haz ocs module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "HazOcs";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "AlertGeometry";

        //Views

        /// <summary>The landing or start view for haz oc.</summary>
        public const string StartView = "HazOcsStartView";

        /// <summary>The single haz oc entity view.</summary>
        public const string NavDetailView = "StartDetailView"; //"HazOcsNavDetailView";

        /// <summary>
        /// Creates the report
        /// </summary>
        public const string CreateReportView = "CreateReportView";

        /// <summary>
        /// Creates the report(questionnaire)
        /// </summary>
        public const string CreateReportQuestionsView = "CreateReportQuestionsView";

        /// <summary>
        /// The add witnesses view
        /// </summary>
        public const string AddWitnessLinesView = "WitnessDetailEditView";

        /// <summary>
        /// The add witnesses view
        /// </summary>
        public const string AddVisitLinesView = "TreatmentDetailEditView";

        /// <summary>
        /// The  corrections view
        /// </summary>
        public const string AddCorrectionsView = "CorrectionsView";

        /// <summary>
        /// The add corrections view
        /// </summary>
        public const string AddCorrectionsLinesView = "CorrectionsEditView";

        /// <summary>
        /// The add corrections view
        /// </summary>
        public const string CloseActionView = "CorrectionsCloseView";

        /// <summary>
        /// The add haz occ view
        /// </summary>
        public const string AddHazOccView = "AddHazOccView";

        /// <summary>
        /// The add accident view
        /// </summary>
        public const string AddAccidentView = "AddAccidentView";

        /// <summary>
        /// The add incident view
        /// </summary>
        public const string AddIncidentView = "AddIncidentView";

        /// <summary>
        /// The add near miss view
        /// </summary>
        public const string AddNearMissView = "AddNearMissView";

        /// <summary>
        /// The add unsafe act view
        /// </summary>
        public const string AddUnsafeActView = "AddUnsafeActView";

        /// <summary>
        /// The add unsafe condition view
        /// </summary>
        public const string AddUnsafeConditionView = "AddUnsafeConditionView";

        /// <summary>
        /// The add safe act view
        /// </summary>
        public const string AddSafeActView = "AddSafeActView";

        /// <summary>
        /// The add safe condition view
        /// </summary>
        public const string AddSafeConditionView = "AddSafeConditionView";

        /// <summary>
        /// The add notifications view
        /// </summary>
        public const string AddNotificationsView = "NotificationEditView";

        // <summary>
        /// The add witnesses view
        /// </summary>
        public const string AddStatementLinesView = "StatementDetailEditView";

        /// <summary>
        /// The add illness view
        /// </summary>
        public const string AddIllnessView = "AddIllnessView";

        // <summary>
        /// The Summary view
        /// </summary>
        public const string SummaryView = "SummaryView";

        // <summary>
        /// The close report view
        /// </summary>
        public const string CloseReportView = "CloseReportView";

        /// <summary>
        /// The map parent dialog view
        /// </summary>
        public const string MapParentDialogView = "MapParentDialogView";

        // <summary>
        /// The send report view
        /// </summary>
        public const string SendReportView = "SendReportView";

        // <summary>
        /// The reopen report view
        /// </summary>
        public const string ReOpenReportView = "ReOpenReportView";

        // <summary>
        /// The reporting view
        /// </summary>
        public const string GenerateReportView = "GenerateReportView";

        // <summary>
        /// The reporting view
        /// </summary>
        public const string AnalysisView = "AnalysisPageView";


        // <summary>
        /// The hzOcc analysis view
        /// </summary>
        public const string HzOccAnalysisView = "HzMainAnalysisView";

        // <summary>
        /// The hzOcc Summary analysis view
        /// </summary>
        public const string HzOccAnalysisSummaryView = "HzMainAnalysisSummaryView";

        // <summary>
        /// The ME Exp Hrs view
        /// </summary>
        public const string MECalcReportView = "MECalcView";

        // <summary>
        /// The Matrix view
        /// </summary>
        public const string RiskMatrixView = "RiskMatrixViewModel";


        /// <summary>
        /// The Incident Report Type
        /// </summary>
        public const string IncidentReportType = "Incident";

        /// <summary>
        /// The Crew Accident Report Type
        /// </summary>
        public const string CrewAccReportType = "Crew Accident";

        /// Closed Report Status
        public const string IncidentStatus_ReportComplete = "INCMAN000004";

        /// <summary>
        /// The statement details dialog view.
        /// </summary>
        public const string StatementDetialsDialogView = "StatementDetialsDialogView";

        /// <summary>
        /// The witness detail edit view.
        /// </summary>
        public const string WitnessDetailEditView = "WitnessDetailEditView";
        
        /// <summary>
        /// The notification edit view
        /// </summary>
        public const string NotificationEditView = "NotificationEditView";

        /// <summary>
        /// The corrections edit view
        /// </summary>
        public const string CorrectionsEditView = "CorrectionsEditView";

        /// <summary>
        /// The select forms view
        /// </summary>
        public static string SelectFormsView = "SelectFormsView";

        // <summary>
        /// The Landing Page view
        /// </summary>
        public static string HazOccLandingPageView = "HazOccLandingAnalysisPageView";       

        // <summary>
        /// The Document Upload Page view
        /// </summary>
        public static string SupportingDocNavigationView = "SupportingDocNavigationView";

        /// <summary>
        /// The Accident YES/NO Combos
        /// </summary>
        public const string HazOccY = "Y";
        public const string HazOccYes = "Yes";
        public const string HazOccN = "N";
        public const string HazOccNo = "No";

        // the Accident +/- Combos
        public const string HazOccPos = "Positive";
        public const string HazOccNeg = "Negative";

        //Create hazOcc - View All type text
        public const string HazOccViewAllRptTypes = "ALL View all reports";

        public static readonly IList<String> HazOccAccidentTypes = new ReadOnlyCollection<string>
        (new List<String> { EnumsHelper.GetKeyValue(HazOccTypeCodes.CA), EnumsHelper.GetKeyValue(HazOccTypeCodes.PA), EnumsHelper.GetKeyValue(HazOccTypeCodes.TA) });

        public static readonly IList<String> HazOccIncidentTypes = new ReadOnlyCollection<string>
        (new List<String> {EnumsHelper.GetKeyValue(HazOccTypeCodes.IP),
            EnumsHelper.GetKeyValue(HazOccTypeCodes.IF), EnumsHelper.GetKeyValue(HazOccTypeCodes.IC),
            EnumsHelper.GetKeyValue(HazOccTypeCodes.IE), EnumsHelper.GetKeyValue(HazOccTypeCodes.IL),
            EnumsHelper.GetKeyValue(HazOccTypeCodes.IV), EnumsHelper.GetKeyValue(HazOccTypeCodes.IS),EnumsHelper.GetKeyValue(HazOccTypeCodes.II),
            EnumsHelper.GetKeyValue(HazOccTypeCodes.IA) ,EnumsHelper.GetKeyValue(HazOccTypeCodes.IO),EnumsHelper.GetKeyValue(HazOccTypeCodes.IW) ,EnumsHelper.GetKeyValue(HazOccTypeCodes.ID) });

        public static readonly IList<String> HazOccObservationTypes = new ReadOnlyCollection<string>
      (new List<String> { EnumsHelper.GetKeyValue(HazOccTypeCodes.NM), EnumsHelper.GetKeyValue(HazOccTypeCodes.OB), EnumsHelper.GetKeyValue(HazOccTypeCodes.SA) });

        /// <summary>
        /// The link defect view
        /// </summary>
        public const string LinkDefectView = "LinkDefectView";

        /// <summary>
        /// The show report reopen comment view
        /// </summary>
        public const string ShowReportReopenCommentView = "ShowReportReopenCommentView";

        /// <summary>
        /// The view description and comment view
        /// </summary>
        public const string ViewDescriptionAndCommentView = "ViewDescriptionAndCommentView";

        /// <summary>
        /// The link insurance claim dialog view
        /// </summary>
        public const string LinkInsuranceClaimDialogView = "LinkInsuranceClaimDialogView";
    }
}
