﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.HazOcs
{
    /// <summary>
    /// Navigation service for the haz ocs module.
    /// </summary>
    public class HazOcsNavigation : BaseModuleNavigationService, IHazOcsNavigation
    {
        /// <summary>
        /// The default constructor.
        /// </summary>
        public HazOcsNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Navigates to the haz occs module start view.
        /// </summary>
        public void NavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Navigates to the haz occs module landing page
        /// </summary>
        public void NavigateLandingPage()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.HazOccLandingPageView);
        }

        /// <summary>
        /// Navigates to the haz occs module record view.
        /// </summary>
        public void NavigateDetail(object request)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.NavDetailView, request);
        }

        /// <summary>
        /// Navigates to the haz occs module start view for a particualr vessel.
        /// </summary>
        /// <param name="param"></param>
        public void NavigateVesselStart(HazOcsParameter param)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView, param);
        }

        /// <summary>
        /// Navigates the vessel start existing.
        /// </summary>
        /// <param name="param">The parameter.</param>
        public void NavigateVesselStartExisting(HazOcsParameter param)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.StartView, param);

        }

        /// <summary>
        /// Navigates to the haz occs module start view for a particualr vessel in new tab.
        /// </summary>
        /// <param name="param"></param>
        public void NavigateVesselStartNew(HazOcsParameter param)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.StartView, param);

        }

        /// <summary>
        /// Navigates to the CreateReport View
        /// </summary>
        public void CreateReport(INavigationContext context, string vesselId = null)
        {
            var p = new Dictionary<string, object> { { "VesselId", vesselId } };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateReportView, context, p);
        }

        /// <summary>
        /// Navigates to the Analysis View
        /// </summary>
        public void NavigateAnalysis(INavigationContext context, HazOcsParameter param)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.HzOccAnalysisSummaryView, param);
        }
        /// <summary>
        /// Navigates to the Create Witness view
        /// </summary>
        public void CreateWitness(INavigationContext context, string reportId = null)
        {
            var p = new Dictionary<string, object> { { "ReportId", reportId } };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddWitnessLinesView, context, p);

        }

        /// <summary>
        /// Navigates to the upload attachment view
        /// </summary>
        public void NavigateFileDialog(INavigationContext context, string documentId = null, string reportId = null, IEnumerable<string> fileNames = null)
        {
            var p = new Dictionary<string, object>
            {
                { NavigationParameterConstant.DocumentId, documentId },
                { NavigationParameterConstant.HazOccReportId, reportId },
                { NavigationParameterConstant.FilesToUpload, fileNames != null ? fileNames.ToList() : new List<string>()}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SupportingDocNavigationView, context, p);

        }

        /// <summary>
        /// Navigates to the statement details.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        public void NavigateToStatementDetails(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.StatementDetialsDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to the statement details.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        public void NavigateToWitnessDetails(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.WitnessDetailEditView, context, parameter);
        }

        /// <summary>
        /// Navigates to close report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToCloseReport(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CloseReportView, context, parameter);
        }

        /// <summary>
        /// Navigates to map parent.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMapParent(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapParentDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to the statement details.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        public void NavigateToNotificationEdit(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NotificationEditView, context, parameter);
        }

        /// <summary>
        /// Navigates to corrections edit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedAction">The selected action.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="incidentDate">The incident date.</param>
        public void NavigateToCorrectionsEdit(INavigationContext context, string reportId, string vesselId, object selectedAction, string parentId, DateTime? incidentDate)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ReportId, reportId },
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.SelectedAction, selectedAction },
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.IncidentDate, incidentDate }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CorrectionsEditView, context, parameter);
        }

        /// <summary>
        /// Navigates to corrections view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedAction">The selected action.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateToCorrectionsView(INavigationContext context, string reportId, string vesselId, object selectedAction, string parentId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ReportId, reportId },
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.SelectedAction, selectedAction },
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.IsInViewMode, true }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CorrectionsEditView, context, parameter);
        }

        /// <summary>
        /// Navigates the close action.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedActions">The selected actions.</param>
        public void NavigateCloseAction(INavigationContext navigationContext, string parentId, string vesselId, object selectedActions)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.HazOccActions, selectedActions },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CloseActionView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add haz occ.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddHazOccDialog(INavigationContext context, HazOcsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddHazOccView, context, parameter);
        }

        /// <summary>
        /// Navigates the add accident haz occ.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateAddAccidentReportDialog(INavigationContext context, string parentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAccidentView, context, parameter);
        }

        /// <summary>
        /// Navigates the add incident report dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddIncidentReportDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddIncidentView, context, parameter);
        }

        /// <summary>
        /// Navigates the add near miss dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateAddNearMissDialog(INavigationContext context, string parentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddNearMissView, context, parameter);
        }

        /// <summary>
        /// Navigates the add unsafe act dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateAddUnsafeActDialog(INavigationContext context, string parentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddUnsafeActView, context, parameter);
        }

        /// <summary>
        /// Navigates the add unsafe condition dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateAddUnsafeConditionDialog(INavigationContext context, string parentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddUnsafeConditionView, context, parameter);
        }

        /// <summary>
        /// Navigates the add safe act dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="reportTypeId">The report type identifier.</param>
        public void NavigateAddSafeActDialog(INavigationContext context, string parentId, string vesselId, string reportTypeId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.ReportId, reportTypeId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSafeActView, context, parameter);
        }

        /// <summary>
        /// Navigates the add safe condition dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateAddSafeConditionDialog(INavigationContext context, string parentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSafeConditionView, context, parameter);
        }

        /// <summary>
        /// Navigates the add illness report dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateAddIllnessDialog(INavigationContext context, string parentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddIllnessView, context, parameter);
        }

        /// <summary>
        /// Navigates the reopen report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateReopenReport(INavigationContext context, HazOcsParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReOpenReportView, context, parameters);
        }

        /// <summary>
        /// Navigates to link defect view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentParameters">The component parameters.</param>
        public void NavigateToLinkDefectView(INavigationContext navigationContext, Dictionary<string, object> componentParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkDefectView, navigationContext, componentParameters);
        }

        /// <summary>
        /// Navigates to show reopen comment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="reopenCommentParameter">The reopen comment parameter.</param>
        public void NavigateToShowReopenComment(INavigationContext navigationContext, object reopenCommentParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ShowReportReopenCommentView, navigationContext, reopenCommentParameter);
        }

        /// <summary>
        /// Navigates the mexp HRS view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateMexpHrsView(INavigationContext navigationContext, object navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MECalcReportView, navigationContext, navigationParameter);
        }

        /// <summary>
        /// Navigates the view description and comment view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateViewDescriptionAndCommentView(INavigationContext navigationContext, object navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewDescriptionAndCommentView, navigationContext, navigationParameter);
        }

        /// <summary>
        /// Navigates to the link insurance claim dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToLinkInsuranceClaimDialogView(INavigationContext context, HazOcsParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkInsuranceClaimDialogView, context, parameters);
        }
    }
}
