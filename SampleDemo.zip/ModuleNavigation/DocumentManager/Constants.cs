﻿#pragma warning disable 1591
namespace VShips.Framework.Common.ModuleNavigation.DocumentManager
{
    public static class Constants
    {
        public const string ModuleName = "DocumentManager";

        public const string ModuleIcon = "CertificatesGeometry";

        public const string CancelButtonText = "Cancel";

        public const string UpadateButtonText = "Update";

        public const string StartView = "DocumentManagerStartView";

        public const string VesselWhitelistView = "VesselWhitelistView";

        public const string DirectoriesAddEditView = "DirectoriesAddEditView";

        public const string BulkUploadDialogView = "BulkUploadDialogView";

        public const string FilesAddEditView = "FilesAddEditView";

        public const string FileDetailsView = "FileDetailsView";

        public const string FileHistoryView = "FileHistoryView";

        public const string FileCommentsView = "FileCommentsView";

        public const string BroadcastFileView = "BroadcastFileView";

        public const string MoveFileView = "MoveFileView";

        public const string SubscribeVesselsView = "SubscribeVesselsView";

        public const string UnreadFilesReportView = "UnreadFilesReportView";

        public const string Folder = "Folder";

        public const string file = "file";

        public const string FolderFiles = "FolderFiles";

        public const string FolderId = "FolderId"; 

        public const string FileComments = "FileComments";

        public const string FilesInFolder = "FilesInFolder";

        public const string ShowIsVesselSensitive = "canViewSensitiveInfo";

        public const string publishToSubscribers = "publishToSubscribers";

        public const string closeAction = "closeAction";

        public const string IsAdd = "IsAdd";

        public const string IsView = "IsView";

        public const string DailyDownloadLimit = "DailyDownloadLimit";

        public const string VesselId = "VesselId";

        public const string ParentId = "ParentId";

        public const string VesselTypeId = "VesselTypeId";

        public const string HighConnectivityProfile = "High Connectivity";

        public const string User = "User";
    }
}