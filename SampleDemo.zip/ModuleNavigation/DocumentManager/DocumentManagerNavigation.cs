﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DocumentManager
{
    /// <summary>
    /// Default implementation of the <see cref="IDocumentManagerNavigation"/> service.
    /// </summary>
    public class DocumentManagerNavigation : BaseModuleNavigationService, IDocumentManagerNavigation
    {
        #region Constructors

        /// <summary>
        /// The default constructor for the CertificatesNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public DocumentManagerNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        #endregion

        #region Navigation Methods
        #endregion

    }
}