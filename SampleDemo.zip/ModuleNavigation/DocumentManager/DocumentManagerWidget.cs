﻿using Contracts.Enums;
using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using VShips.Contracts.Custom.Document;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.Services.Default;
using VShips.Framework.Common.ViewModel;

#pragma warning disable CS1591

namespace VShips.Framework.Common.ModuleNavigation.DocumentManager
{
    public class DocumentManagerWidget : BaseViewModel
    {
        private string _documentManagerUrl;

        public DocumentManagerWidget()
        {
            _documentManagerUrl = ConfigurationManager.AppSettings["DocumentManagerUrl"];
        }

        //public async void OpenFile(string filename)
        //{
        //    var docManFileDetails = await VMService.DataService.Shared.GetDocManFileDetailsFilename(filename, GetCurrentCancellationToken());

        //    if (docManFileDetails == null)
        //    {
        //        VMService.DialogService.AlertOnUI(MessageType.Failure, Messages.CannotViewDocumentFileDoesNotExist);
        //        return;
        //    }

        //    if (OpenLocalFile(docManFileDetails))
        //    {
        //        await VMService.DataService.Shared.LogFileDownloadOffice(docManFileDetails, GetCurrentCancellationToken());
        //        return;
        //    }

        //    if (docManFileDetails.EttId == null)
        //    {
        //        await OpenFileFromBytestream(docManFileDetails);
        //        return;
        //    }

        //    AddIsBusy();

        //    var cancelToken = GetCurrentCancellationToken();

        //    DocumentFileType documentFileType;
        //    Enum.TryParse(docManFileDetails.Filetype.Substring(1), out documentFileType);

        //    var request = new CloudDocumentDownloadRequest
        //    {
        //        DocumentCategory = DocumentCategory.DocManCloudFile,
        //        Identifier = docManFileDetails.EttId,
        //        DocumentFileType = documentFileType //EnumsHelper.GetValues<DocumentFileType>().FirstOrDefault(x => EnumsHelper.GetKeyValue(x).ToLower() == docManFileDetails.Filetype.Substring(1).ToLower())
        //    };

        //    var documentPath = await VMService.DataService.DocumentService.GetCloudEntityDocument(request, new ProgressIndicator(), cancelToken);

        //    if (File.Exists(documentPath))
        //    {
        //        Process.Start(documentPath);
        //        await VMService.DataService.Shared.LogFileDownloadOffice(docManFileDetails, GetCurrentCancellationToken());
        //    }
        //    else
        //    {
        //        VMService.DialogService.AlertOnUI(MessageType.Failure, Messages.CannotViewDocumentFileDoesNotExist);
        //    }
        //}


        //private bool OpenLocalFile(DocManFileDetails docManFileDetails)
        //{
        //    var filename = docManFileDetails.Filename;

        //    //Filename might refer to disk file or web-hosted file. Try to open from web-hosted first...
        //    if (_documentManagerUrl != null &&
        //        filename != null &&
        //        Uri.IsWellFormedUriString(_documentManagerUrl + filename.Replace(" ", "%20"), UriKind.Absolute))
        //    {
        //        var uri = new Uri(_documentManagerUrl + filename.Replace(" ", "%20"));
        //        var fileNameIdVersion = Path.GetFileName(uri.LocalPath);

        //        var localFolder = GetLocalDirectory();
        //        filename = Path.Combine(localFolder, fileNameIdVersion);

        //        if (!File.Exists(filename))
        //        {
        //            var req = System.Net.WebRequest.Create(uri);
        //            var templateStream = req.GetResponse().GetResponseStream();
        //            var byteArray = ReadFully(templateStream);

        //            using (var fileStream = new FileStream(filename, FileMode.Create))
        //            {
        //                fileStream.Write(byteArray, 0, byteArray.Length);
        //                fileStream.Dispose();
        //            }
        //        }
        //    }

        //    if (File.Exists(filename + docManFileDetails.Filetype))
        //    {
        //        Process.Start(filename + docManFileDetails.Filetype);
        //        return true;
        //    }

        //    //try to open file form user's local/home folder
        //    try
        //    {
        //        var directory = GetLocalDirectory();

        //        if (!string.IsNullOrEmpty(directory))
        //        {
        //            string filePath = Path.Combine(directory, filename + docManFileDetails.Filetype);

        //            if (File.Exists(filePath))
        //            {
        //                var info = new FileInfo(filePath);

        //                if (!docManFileDetails.UpdatedOn.HasValue || info.CreationTime >= docManFileDetails.UpdatedOn.Value)
        //                {
        //                    Process.Start(filePath);
        //                    return true;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        VMService.LoggerService.ErrorWithoutAlert(e.Message, e);
        //    }

        //    return false;
        //}


        //private string GetLocalDirectory()
        //{
        //    try
        //    {
        //        var directory = Directories.GetWindowsDefaultDownloadsDirectory();
        //        if (!Directory.Exists(directory))
        //        {
        //            var local = Directories.GetLocalDirectory();

        //            if (!string.IsNullOrEmpty(local))
        //                directory = Path.Combine(local, "Shipsure", "Documents");
        //        }

        //        if (!Directory.Exists(directory))
        //        {
        //            Directory.CreateDirectory(directory);
        //        }

        //        return directory;
        //    }
        //    catch (Exception e)
        //    {
        //        VMService.LoggerService.ErrorWithoutAlert(e.Message, e);
        //    }

        //    return "";
        //}


        //private static byte[] ReadFully(Stream input)
        //{
        //    var buffer = new byte[16 * 1024];
        //    using (var ms = new MemoryStream())
        //    {
        //        int read;
        //        while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
        //        {
        //            ms.Write(buffer, 0, read);
        //        }
        //        return ms.ToArray();
        //    }
        //}


        //private async Task<bool> OpenFileFromBytestream(DocManFileDetails docManFileDetails)
        //{
        //    if (docManFileDetails.File == null || docManFileDetails.File.Length == 0)
        //    {
        //        return false;
        //    }

        //    try
        //    {
        //        string fileName = string.Format("{0}{1}", docManFileDetails.DmfId, docManFileDetails.Filetype);
        //        var directory = GetLocalDirectory();
        //        var path = Path.Combine(directory, fileName);

        //        for (var x = 1; File.Exists(path); x++)
        //        {
        //            fileName = string.Format("{0} ({1}){2}", docManFileDetails.DmfId, x, docManFileDetails.Filetype);
        //            path = Path.Combine(directory, fileName);
        //        }

        //        File.WriteAllBytes(path, docManFileDetails.File);

        //        Process.Start(path);

        //        var vesselHeader = await VMService.DataService.Vessels.GetVesselHeaderDetail(VMService.ModuleService.VesselDetails.VesselId, GetCurrentCancellationToken());
        //        await VMService.DataService.Shared.LogFileDownloadVessel(docManFileDetails, vesselHeader.Name, GetCurrentCancellationToken());

        //        return true;
        //    }
        //    catch (Exception e)
        //    {
        //        VMService.LoggerService.ErrorWithoutAlert(e.Message, e);
        //    }

        //    VMService.DialogService.AlertOnUI(MessageType.Failure, Messages.CannotViewDocumentFileDoesNotExist);
        //    return false;
        //}

    }
}
