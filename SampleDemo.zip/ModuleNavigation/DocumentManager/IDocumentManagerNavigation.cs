﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DocumentManager
{
    /// <summary>
    /// Navigation service for the budget module.
    /// </summary>
    public interface IDocumentManagerNavigation
    { }
}