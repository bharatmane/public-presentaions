﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Home
{
    /// <summary>
    /// Default implementation of the <see cref="IHomeNavigation"/> service.
    /// </summary>
    public class HomeNavigation : BaseModuleNavigationService, IHomeNavigation
    {
        /// <summary>
        /// The default contructor for the HomeNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public HomeNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Homes the navigate vessel memos.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void HomeNavigateVesselMemos(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselMemosView, navigationContext, parameter);
        }

        /// <summary>
        /// Purchasings the manifest report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselPosition">The vessel position.</param>
        public void PurchasingManifestReport(INavigationContext navigationContext, object vesselPosition)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ManifestReportView, navigationContext, vesselPosition);
        }

        /// <summary>
        /// Homes the navigate user favourites.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void HomeNavigateUserFavourites(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UserFavouritesView, navigationContext);
        }

        /// <summary>
        /// Navigates the vessel overview.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateVesselOverview(string vesselId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VesselOverviewView, vesselId);
        }
    }
}
