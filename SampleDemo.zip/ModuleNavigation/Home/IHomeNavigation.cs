﻿using VShips.Framework.Common.Services;
namespace VShips.Framework.Common.ModuleNavigation.Home
{
    /// <summary>
    /// Navigation service for the home module.
    /// </summary>
    public interface IHomeNavigation
    {
        /// <summary>
        /// Homes the navigate vessel memos.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void HomeNavigateVesselMemos(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Purchasings the manifest report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselPosition">The vessel position.</param>
        void PurchasingManifestReport(INavigationContext navigationContext, object vesselPosition);

        /// <summary>
        /// Homes the navigate user favourites.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void HomeNavigateUserFavourites(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the vessel overview.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateVesselOverview(string vesselId);
    }

}
