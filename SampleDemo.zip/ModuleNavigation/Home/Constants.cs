﻿namespace VShips.Framework.Common.ModuleNavigation.Home
{
    /// <summary>
    /// Names of accessible views and regions related to the home module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "Homepage";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "HomepageGeometry";

        /// <summary>
        /// The main home view
        /// </summary>
        public const string HomeView = "HomeView";

        /// <summary>
        /// The buyer outstanding orders widget.
        /// </summary>
        public const string BuyerOutstandingOrdersView = "6736F132-C71F-47AD-8E66-064105EC9DA4";

        /// <summary>
        /// The buyer orders in prgress widget.
        /// </summary>
        public const string BuyerInProgressOrdersView = "CDEEBB57-5570-441A-954C-2D7E4ADD9287";

        /// <summary>
        /// The buyer outstanding orders widget.
        /// </summary>
        public const string ManagerOutstandingOrdersView = "E33A4BD1-52F2-4F9D-849E-E5C77F0124BF";

        /// <summary>
        /// The buyer orders in prgress widget.
        /// </summary>
        public const string ManagerInProgressOrdersView = "39AA72CA-8699-4426-A6AE-5692C5A8CE34";
        
        /// <summary>
        /// The invoices widget.
        /// </summary>
        public const string InvoicesWidgetView = "1703B053-EADA-450C-BDD1-B6ACBBE29FCF";

        /// <summary>
        /// The tracked orders widget.
        /// </summary>
        public const string TrackedOrdersWidgetView = "6DF541F2-FF70-4632-A780-B70417D4A5B8";

        /// <summary>
        /// The authorisation pending widget view
        /// </summary>
        public const string AuthorisationPendingWidgetView = "1DDEBA80-2F02-4399-AF94-C968FA1D1735";

        /// <summary>
        /// The world clock widget.
        /// </summary>
        public const string WorldClockWidgetView = "436F4C58-5872-4A8D-A1BC-DE6026C1E94A";

        /// <summary>
        /// The quick actions widget.
        /// </summary>
        public const string QuickActionsView = "6D003685-112B-4088-A6D2-5ACFC8AAC262";

        /// <summary>
        /// The memos widget.
        /// </summary>
        public const string MemosWidgetView = "F1E34971-F30A-4099-99AD-22DD0C4A7AF2";

        /// <summary>
        /// The position list widget.
        /// </summary>
        public const string PositionListWidgetView = "0CE53226-BED3-4C37-BE73-48ADC2029F59";

        /// <summary>
        /// The superintendent widget
        /// </summary>
        public const string SuperintendentProcurementWidget = "F3DC8926-4923-46E7-8871-9F0AACF2CA8A";

        /// <summary>
        /// The superintendent widget
        /// </summary>
        public const string HazOcsTasksWidget = "B0669979-4A98-4C55-ABC0-E15B85F16ED3";

        /// <summary>
        /// The buyer home
        /// </summary>
        public const string BuyerHome = "ManagerHomeView";

        /// <summary>The inspection managers home view.</summary>
        public const string InspectionManagerHome = "InspectionManagerHomeView";

        /// <summary>
        /// The purchasing manager home view
        /// </summary>
        public const string PurchasingManagerHomeView = "PurchasingManagerHomeView";
        /// <summary>
        /// The manifest report dialog view
        /// </summary>
        public const string ManifestReportView = "ManifestReportView";

        /// <summary>
        /// The vessel memos view
        /// </summary>
        public const string VesselMemosView = "VesselMemosView";

        /// <summary>
        /// The exchange rate widget
        /// </summary>
        public const string ExchangeRateWidget = "D8A8C4C2-3633-49C9-B950-43230A0E2C6F";

        /// <summary>
        /// The on hold orders widget
        /// </summary>
        public const string OnHoldOrdersWidgetView = "D77E06CA-FD56-4E45-A6D9-BD878E537217";

        /// <summary>
        /// All type
        /// </summary>
        public const string AllType = "All Types";
        
        /// <summary>
        /// The user favourites view
        /// </summary>
        public const string UserFavouritesView = "UserFavouritesView";

        /// <summary>
        /// The vessel overview view
        /// </summary>
        public const string VesselOverviewView = "VesselOverviewView";

    }
}
