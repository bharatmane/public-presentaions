﻿namespace VShips.Framework.Common.ModuleNavigation.EngineLogBook
{
    /// <summary>
    /// Names of accessible views and regions related to the haz ocs module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "EngineLogBook";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "AlertGeometry";

        //Views
        /// <summary>The landing or start view for haz oc.</summary>
        public const string StartView = "EngineLogBookStartView";

        /// <summary>
        /// The engine log title
        /// </summary>
        public const string EngineLogTitle = "Engine Log";

        /// <summary>
        /// The engine log book title
        /// </summary>
        public const string EngineLogBookTitle = "Engine Log Book";

        /// <summary>
        /// The engine log book view
        /// </summary>
        public const string EngineLogBookView = "EngineLogBookView";

        /// <summary>
        /// The engine log book engine condition view
        /// </summary>
        public const string EngineLogBookEngineConditionView = "EngineLogBookEngineConditionView";

        /// <summary>
        /// The engine log book acquire data view
        /// </summary>
        public const string EngineLogBookAcquireDataView = "AcquireDataView";

        /// <summary>
        /// The engine log book engine condition view title
        /// </summary>
        public const string EngineLogBookEngineConditionViewTitle = "Condition Details";

        /// <summary>
        /// The engine log book engine manage parameters
        /// </summary>
        public const string EngineLogBookEngineManageParameters = "ManageParametersView";

        /// <summary>
        /// The selected time slot
        /// </summary>
        public const string SelectedTimeSlot = "SelectedTimeSlot";

        /// <summary>
        /// The on save complete
        /// </summary>
        public const string OnSaveComplete = "OnSaveComplete";

        /// <summary>
        /// The engine log book report
        /// </summary>
        public const string EngineLogBookReport = "GLAS00047348";

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";

        /// <summary>
        /// The on manage parameter close
        /// </summary>
        public const string OnManageParameterClose = "OnManageParameterClose";

        /// <summary>
        /// The setup engine log book start view
        /// </summary>
        public const string SetupEngineLogBookStartView = "SetupEngineLogBookStartView";

        /// <summary>
        /// The add oily water separator dialog view
        /// </summary>
        public const string AddOilyWaterSeparatorDialogView = "AddOilyWaterSeparatorDialogView";

        /// <summary>
        /// The add incinerator dailog view model
        /// </summary>
        public const string AddIncineratorDailogView = "AddIncineratorDailogView";

        /// <summary>
        /// The propulsion type dialog view
        /// </summary>
        public const string PropulsionTypeDialogView = "PropulsionTypeDialogView";

        /// <summary>
        /// The initiate logbook view
        /// </summary>
        public const string InitiateLogbookView = "InitiateLogbookView";

        /// <summary>
        /// The initiate logbook
        /// </summary>
        public const string InitiateLogbook = "Initiate Logbook";

        /// <summary>
        /// The on save
        /// </summary>
        public const string OnSave = "OnSave";

        /// <summary>
        /// The map environment sludge bilge event view
        /// </summary>
        public const string MapEnvironmentSludgeBilgeEventView = "MapEnvironmentSludgeBilgeEventView";

        /// <summary>
        /// The map elb drill campaign detail view
        /// </summary>
        public const string MapELBDrillCampaignDetailView = "MapELBDrillCampaignDetailView";

        /// <summary>
        /// The update comment view
        /// </summary>
        public const string UpdateCommentView = "UpdateCommentView";

        /// <summary>
        /// The noted condition view
        /// </summary>
        public const string NotedConditionView = "NotedConditionView";

        /// <summary>
        /// The elb reported test detail view
        /// </summary>
        public const string ELBReportedTestDetailView = "ELBReportedTestDetailView";

        /// <summary>
        /// The add edit test view
        /// </summary>
        public const string AddEditTestView = "AddEditTestView";

        /// <summary>
        /// The download engine log book reports view
        /// </summary>
        public const string DownloadEngineLogBookReportsView = "DownloadEngineLogBookReportsView";
    }
}
