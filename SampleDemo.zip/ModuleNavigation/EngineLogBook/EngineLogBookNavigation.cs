﻿using System;
using System.Collections.Generic;
using VShips.Contracts.DtoClasses;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.EngineLogBook
{
    /// <summary>
    /// Navigation service for the haz ocs module.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.EngineLogBook.IEngineLogBookNavigation" />
    public class EngineLogBookNavigation : BaseModuleNavigationService, IEngineLogBookNavigation
    {
        /// <summary>
        /// The default constructor.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public EngineLogBookNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Navigates the start.
        /// </summary>
        public void NavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Navigates the engine log book.
        /// </summary>
        public void NavigateEngineLogBook()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.EngineLogBookView);
        }

        /// <summary>
        /// Engines the log book navigate engine condition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedTimeSlot">The selected time slot.</param>
        /// <param name="onSaveComplete">The on save complete.</param>
        public void EngineLogBookNavigateEngineCondition(INavigationContext navigationContext, EngineLogBookMain selectedTimeSlot, Action<string> onSaveComplete)
        {
            Dictionary<string, object> shipConditionParameter = new Dictionary<string, object>
            {
              { Constants.SelectedTimeSlot , selectedTimeSlot }, { Constants.OnSaveComplete,onSaveComplete}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EngineLogBookEngineConditionView, navigationContext, shipConditionParameter);
        }

        /// <summary>
        /// Engines the log book navigate acquire data.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void EngineLogBookNavigateAcquireData(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EngineLogBookAcquireDataView, navigationContext);
        }

        /// <summary>
        /// Engines the log book navigate manage parameters.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="onManageParameterClose">The on manage parameter close.</param>
        public void EngineLogBookNavigateManageParameters(INavigationContext navigationContext, string vesselId, Action onManageParameterClose)
        {
            Dictionary<string, object> setupParameter = new Dictionary<string, object>
            {
              { Constants.VesselId , vesselId }, { Constants.OnManageParameterClose,onManageParameterClose}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EngineLogBookEngineManageParameters, navigationContext, setupParameter);
        }

        /// <summary>
        /// Setups the engine log book navigate.
        /// </summary>
        public void NavigateSetupEngineLogBook(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.SetupEngineLogBookStartView, parameter);
        }

        /// <summary>
        /// Navigates the add oily water separator.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateAddOilyWaterSeparator(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddOilyWaterSeparatorDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the add incinerator.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateAddIncinerator(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddIncineratorDailogView, navigationContext);
        }

        /// <summary>
        /// Navigates the propulsion type dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigatePropulsionTypeDialog(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PropulsionTypeDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the initiate logbook.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="onSave">The on save.</param>
        public void NavigateInitiateLogbook(INavigationContext navigationContext, string vesselId, Action onSave)
        {
            Dictionary<string, object> initiateLogbookParameters = new Dictionary<string, object>
            {
              { Constants.VesselId, vesselId }, { Constants.OnSave, onSave}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InitiateLogbookView, navigationContext, initiateLogbookParameters);
        }

        /// <summary>Navigates to map environment sludge bilge event dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMapEnvironmentSludgeBilgeEventDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapEnvironmentSludgeBilgeEventView, context, parameter);
        }

        /// <summary>
        /// Navigates to map drill and campaign dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMapDrillAndCampaignDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapELBDrillCampaignDetailView, context, parameter);
        }

        /// <summary>Navigates to update comment view.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToUpdateCommentView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateCommentView, context, parameter);
        }

        /// <summary>Navigates to noted condition dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToNotedConditionDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NotedConditionView, context, parameter);
        }

        /// <summary>Navigates to reported test dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToReportedTestDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ELBReportedTestDetailView, context, parameter);
        }

        /// <summary>Navigates to add edit test dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditTestDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditTestView, context, parameter);
        }

        /// <summary>
        /// Navigates to download environment logbook report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToDownloadEngineLogBookReports(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DownloadEngineLogBookReportsView, context, parameter);
        }

        /// <summary>
        /// Navigates to engine logbook detail page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEngineLogbookDetailPage(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.StartView, parameter);
        }
    }
}