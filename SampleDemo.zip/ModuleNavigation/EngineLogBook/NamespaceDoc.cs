﻿namespace VShips.Framework.Common.ModuleNavigation.EngineLogBook 
{
    /// <summary>
    /// Services and constants relating to the haz occs module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
