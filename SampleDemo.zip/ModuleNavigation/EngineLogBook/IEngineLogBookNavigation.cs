﻿using System;
using VShips.Contracts.DtoClasses;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.EngineLogBook
{
    /// <summary>
    /// Navigation service for the haz ocs module.
    /// </summary>
    public interface IEngineLogBookNavigation
    {
        /// <summary>
        /// Navigates the start.
        /// </summary>
        void NavigateStart();

        /// <summary>
        /// Navigates the engine log book.
        /// </summary>
        void NavigateEngineLogBook();

        /// <summary>
        /// Engines the log book navigate engine condition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedTimeSlot">The selected time slot.</param>
        /// <param name="onSaveComplete">The on save complete.</param>
        void EngineLogBookNavigateEngineCondition(INavigationContext navigationContext, EngineLogBookMain selectedTimeSlot, Action<string> onSaveComplete);

        /// <summary>
        /// Engines the log book navigate acquire data.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void EngineLogBookNavigateAcquireData(INavigationContext navigationContext);

        /// <summary>
        /// Engines the log book navigate manage parameters.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="onManageParameterClose">The on manage parameter close.</param>
        void EngineLogBookNavigateManageParameters(INavigationContext navigationContext, string vesselId, Action onManageParameterClose);

        /// <summary>
        /// Setups the engine log book navigate.
        /// </summary>
        void NavigateSetupEngineLogBook(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add oily water separator.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateAddOilyWaterSeparator(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the add incinerator.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateAddIncinerator(INavigationContext navigationContext);      
  
        /// <summary>
        /// Navigates the propulsion type dialog.
        /// </summary>
        void NavigatePropulsionTypeDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the initiate logbook.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="onSave">The on save.</param>
        void NavigateInitiateLogbook(INavigationContext navigationContext, string vesselId, Action onSave);

        /// <summary>Navigates to map environment sludge bilge event dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToMapEnvironmentSludgeBilgeEventDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to map drill and campaign dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToMapDrillAndCampaignDialog(INavigationContext context, object parameter);

        /// <summary>Navigates to update comment view.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToUpdateCommentView(INavigationContext context, object parameter);

        /// <summary>Navigates to noted condition dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToNotedConditionDialog(INavigationContext context, object parameter);

        /// <summary>Navigates to reported test dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToReportedTestDialog(INavigationContext context, object parameter);

        /// <summary>Navigates to add edit test dialog.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditTestDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to download engine logbook report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToDownloadEngineLogBookReports(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to engine logbook detail page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEngineLogbookDetailPage(object parameter);
    }
}