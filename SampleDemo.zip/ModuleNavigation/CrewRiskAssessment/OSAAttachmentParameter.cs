﻿using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment
{
    /// <summary>
    /// Input parameters for OSA Attachment
    /// </summary>
    public class OSAAttachmentParameter : BaseViewModel
    {
        #region Properties        
        /// <summary>
        /// The foreign key matched identifier
        /// </summary>
        private string _foreignKeyMatchedId;

        /// <summary>
        /// Gets or sets the foreign key matched identifier.
        /// </summary>
        /// <value>
        /// The foreign key matched identifier.
        /// </value>
        public string ForeignKeyMatchedId
        {
            get { return _foreignKeyMatchedId; }
            set { Set(() => ForeignKeyMatchedId, ref _foreignKeyMatchedId, value); }
        }

        /// <summary>
        /// The osa extension identifier
        /// </summary>
        private string _osaExtensionId;

        /// <summary>
        /// Gets or sets the osa extension identifier.
        /// </summary>
        /// <value>
        /// The osa extension identifier.
        /// </value>
        public string OsaExtensionId
        {
            get { return _osaExtensionId; }
            set { Set(() => OsaExtensionId, ref _osaExtensionId, value); }
        }

        /// <summary>
        /// The document category type
        /// </summary>
        private DocumentCategory _documentCategoryType;

        /// <summary>
        /// Gets or sets the type of the document category.
        /// </summary>
        /// <value>
        /// The type of the document category.
        /// </value>
        public DocumentCategory DocumentCategoryType
        {
            get { return _documentCategoryType; }
            set { Set(() => DocumentCategoryType, ref _documentCategoryType, value); }
        }

        /// <summary>
        /// The default file name
        /// </summary>
        private string _defaultFileName;

        /// <summary>
        /// Gets or sets the default name of the file.
        /// </summary>
        /// <value>
        /// The default name of the file.
        /// </value>
        public string DefaultFileName
        {
            get { return _defaultFileName; }
            set { Set(() => DefaultFileName, ref _defaultFileName, value); }
        }

        /// <summary>
        /// The _is attacchment allowed
        /// </summary>
        private bool _isAttachmentAllowed;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is attacchment allowed.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is attacchment allowed; otherwise, <c>false</c>.
        /// </value>
        public bool IsAttachmentAllowed
        {
            get { return _isAttachmentAllowed; }
            set { Set(() => IsAttachmentAllowed, ref _isAttachmentAllowed, value); }
        }        

        /// <summary>
        /// The Document Category Identifier
        /// </summary>
        private string _documentCategoryId;

        /// <summary>
        /// Gets or sets the document category identifier.
        /// </summary>
        /// <value>
        /// The document category identifier.
        /// </value>
        public string DocumentCategoryId
        {
            get { return _documentCategoryId; }
            set { Set(() => DocumentCategoryId, ref _documentCategoryId, value); }
        }

        

        
        #endregion
    }
}
