﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Enumerations.Crew;

namespace VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment
{
    /// <summary>
    /// OSA Navigation Parameter Class
    /// </summary>
    public class OsaNavigationParameter
    {
        /// <summary>
        /// Gets or sets the job identifier.
        /// </summary>
        /// <value>
        /// The job identifier.
        /// </value>
        public string JobId { get; set; }
        
        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the type identifier.
        /// </summary>
        /// <value>
        /// The type identifier.
        /// </value>
        public string TypeId { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the popup origin.
        /// </summary>
        /// <value>
        /// The popup origin.
        /// </value>
        public string PopupOrigin { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public OsaJobStatus Status { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is in edit mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is in edit mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsInEditMode { get; set; }

        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObject { get; set; }

        /// <summary>
        /// Gets or sets the shared object2.
        /// </summary>
        /// <value>
        /// The shared object2.
        /// </value>
        public object SharedObject2 { get; set; }

        /// <summary>
        /// Gets or sets the shared object target.
        /// </summary>
        /// <value>
        /// The shared object target.
        /// </value>
        public object SharedObjectTarget { get; set; }

        /// <summary>
        /// The line up identifier
        /// </summary>
        public string LineUpId { get; set; }

        /// <summary>
        /// Gets or sets the date of joining.
        /// </summary>
        /// <value>
        /// The date of joining.
        /// </value>
        public DateTime? DateOfJoining { get; set; }

        /// <summary>
        /// Gets or sets the departure date.
        /// </summary>
        /// <value>
        /// The departure date.
        /// </value>
        public DateTime? DepartureDate { get; set; }

        /// <summary>
        /// Gets or sets the line up port identifier.
        /// </summary>
        /// <value>
        /// The line up port identifier.
        /// </value>
        public string LineUpPortId { get; set; }

        /// <summary>
        /// Gets or sets the line up port description.
        /// </summary>
        /// <value>
        /// The line up port description.
        /// </value>
        public string LineUpPortName { get; set; }

        /// <summary>
        /// Gets or sets the service ids.
        /// </summary>
        /// <value>
        /// The service ids.
        /// </value>
        public List<string> ServiceIds { get; set; }

        /// <summary>
        /// Gets or sets the save executed.
        /// </summary>
        /// <value>
        /// The save executed.
        /// </value>
        public Action<bool> SaveExecuted { get; set; }

    }
}