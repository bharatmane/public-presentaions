﻿using System.Collections.Generic;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment
{
    /// <summary>
    /// Navigation service for the crew risk assessment module.
    /// </summary>
    public interface ICrewRiskAssessmentNavigation
    {
        /// <summary>
        /// Navigates the create osa wizard view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateCreateOSAWizardView(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates the map risk assessment view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateMapRiskAssessmentView(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to unassigned crew details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToUnassignedCrewDetailsView(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to add edit crew answer details dialog view model.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToAddEditCrewAnswerDetailsDialogViewModel(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to view crew hazard answer details dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToViewCrewHazardAnswerDetailsDialogView(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// OSA the navigate add attachment editable dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="osaExtensionId">The osa extension identifier.</param>
        /// <param name="selectedAttachments">The selected attachments.</param>
        /// <param name="attachmentParameter">The attachment parameter.</param>
        /// <param name="isNavigateFromAddEditOSA">if set to <c>true</c> [is navigate from add edit osa].</param>
        /// <param name="osaAttachmentCollection">The osa attachment collection.</param>
        void OSANavigateAddAttachmentEditableDialogView(INavigationContext navigationContext, IEnumerable<string> fileNames, string osaExtensionId, object selectedAttachments, object attachmentParameter, bool isNavigateFromAddEditOSA, object osaAttachmentCollection);

        /// <summary>
        /// Navigates to osa start view.
        /// </summary>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToOSAStartView(OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to add edit osa additional hazards dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToAddEditOSAAdditionalHazardsDialogView(INavigationContext navigationContext, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to approve reject job details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToApproveRejectJobDetailsView(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to reopen cancel osa job details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToReopenCancelOsaJobDetailsView(INavigationContext context, OsaNavigationParameter osaParameter);
    }
}