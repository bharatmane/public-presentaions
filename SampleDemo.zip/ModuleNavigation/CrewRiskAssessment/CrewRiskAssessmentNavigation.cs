﻿using System.Collections.Generic;
using System.Linq;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment
{
    /// <summary>
    /// CrewRiskAssessmentNavigation Class
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment.ICrewRiskAssessmentNavigation" />
    public class CrewRiskAssessmentNavigation : BaseModuleNavigationService, ICrewRiskAssessmentNavigation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="CrewRiskAssessmentNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public CrewRiskAssessmentNavigation(INavigationService navigationService)
            : base(navigationService) { }

        #endregion

        #region Methods        
        /// <summary>
        /// Navigates the create osa wizard view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateCreateOSAWizardView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CreateOSAWizardView, osaParameter);
        }

        /// <summary>
        /// Navigates the map risk assessment view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateMapRiskAssessmentView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapOSARiskAssessmentDialogView, context,osaParameter);
        }

        /// <summary>
        /// Navigates to unassigned crew details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToUnassignedCrewDetailsView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UnassignedCrewDetailsNavigationView, context, osaParameter);
        }

        /// <summary>
        /// Navigates to add edit crew answer details dialog view model.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToAddEditCrewAnswerDetailsDialogViewModel(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewAnswerDetailsDialogView, context, osaParameter);
        }

        /// <summary>
        /// Navigates to view crew hazard answer details dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToViewCrewHazardAnswerDetailsDialogView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewCrewHazardsAnswerDetailsDialogView, context, osaParameter);
        }

        /// <summary>
        /// Crewings the navigate add attachment editable dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="osaExtensionId">The osa extension identifier.</param>
        /// <param name="selectedAttachments">The selected attachments.</param>
        /// <param name="attachmentParameter">The attachment parameter.</param>
        /// <param name="isNavigateFromAddEditOSA">if set to <c>true</c> [is navigate from add edit osa].</param>
        /// <param name="osaAttachmentCollection">The osa attachment collection.</param>
        public void OSANavigateAddAttachmentEditableDialogView(INavigationContext navigationContext, IEnumerable<string> fileNames, string osaExtensionId, object selectedAttachments, object attachmentParameter, bool isNavigateFromAddEditOSA,object osaAttachmentCollection)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Files, fileNames.ToList() },
                { Constants.OSAExtensionId, osaExtensionId },
                { Constants.SelectedAttachments,selectedAttachments },
                { Constants.AttachmentParameter,attachmentParameter },
                { Constants.IsNavigateFromAddEditOSA,isNavigateFromAddEditOSA },
                { Constants.OSAAttachmentCollection,osaAttachmentCollection }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OSAAttachmentDetailsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to osa start view.
        /// </summary>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToOSAStartView(OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewRiskAssessmentStartView, osaParameter);
        }

        /// <summary>
        /// Navigates to add edit osa additional hazards dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToAddEditOSAAdditionalHazardsDialogView(INavigationContext navigationContext, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OSAAddEditAdditionalHazardDialogView, navigationContext, osaParameter);
        }

        /// <summary>
        /// Navigates to approve reject job details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToApproveRejectJobDetailsView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OsaApproveRejectJobDetailsView, context, osaParameter);
        }

        /// <summary>
        /// Navigates to reopen cancel osa job details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToReopenCancelOsaJobDetailsView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReopenCancelOsaJobDetailsView, context, osaParameter);
        }

        #endregion
    }
}