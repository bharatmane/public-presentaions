﻿namespace VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment
{
    /// <summary>
    /// Names of accessible views and regions related to the crew risk assessment module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The module name
        /// </summary>
        public const string ModuleName = "CrewRiskAssessment";

        /// <summary>
        /// The module icon
        /// </summary>
        public const string ModuleIcon = "JobSafetyAnalysisGeometry";

        /// <summary>
        /// The crew risk assessment start view
        /// </summary>
        public const string CrewRiskAssessmentStartView = "CrewRiskAssessmentStartView";

        /// <summary>
        /// The create osa wizard view
        /// </summary>
        public const string CreateOSAWizardView = "CreateOSAWizardView";

        /// <summary>
        /// The map osa risk assessment dialog view
        /// </summary>
        public const string MapOSARiskAssessmentDialogView = "MapOSARiskAssessmentDialogView";

        /// <summary>
        /// The unassigned crew details navigation view
        /// </summary>
        public const string UnassignedCrewDetailsNavigationView = "UnassignedCrewDetailsNavigationView";

        /// <summary>
        /// The add edit crew answer details dialog view
        /// </summary>
        public const string AddEditCrewAnswerDetailsDialogView = "AddEditCrewAnswerDetailsDialogView";

        /// <summary>
        /// The view crew hazards answer details dialog view
        /// </summary>
        public const string ViewCrewHazardsAnswerDetailsDialogView = "ViewCrewHazardsAnswerDetailsDialogView";

        /// <summary>
        /// The files
        /// </summary>
        public const string Files = "Files";

        /// <summary>
        /// The osa extension identifier
        /// </summary>
        public const string OSAExtensionId = "OSAExtensionId";

        /// <summary>
        /// The attachment parameter
        /// </summary>
        public const string AttachmentParameter = "AttachmentParameter";

        /// <summary>
        /// The selected attachments
        /// </summary>
        public const string SelectedAttachments = "SelectedAttachments";

        /// <summary>
        /// The osa attachment details dialog view
        /// </summary>
        public const string OSAAttachmentDetailsDialogView = "OSAAttachmentDetailsDialogView";

        /// <summary>
        /// The is navigate from add edit osa
        /// </summary>
        public const string IsNavigateFromAddEditOSA = "IsNavigateFromAddEditOSA";

        /// <summary>
        /// The osa attachment collection
        /// </summary>
        public const string OSAAttachmentCollection = "OSAAttachmentCollection";

        /// <summary>
        /// The osa add edit additional hazard dialog view
        /// </summary>
        public const string OSAAddEditAdditionalHazardDialogView = "OSAAddEditAdditionalHazardDialogView";
        
        /// <summary>
        /// The osa approve reject job details view
        /// </summary>
        public const string OsaApproveRejectJobDetailsView = "OsaApproveRejectJobDetailsView";

        /// <summary>
        /// The reopen cancel osa job details view
        /// </summary>
        public const string ReopenCancelOsaJobDetailsView = "ReopenCancelOsaJobDetailsView";

    }
}