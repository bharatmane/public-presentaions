﻿namespace VShips.Framework.Common.ModuleNavigation.DatabaseReplication
{
    /// <summary>
    /// Services and constants relating to the purchasing module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
