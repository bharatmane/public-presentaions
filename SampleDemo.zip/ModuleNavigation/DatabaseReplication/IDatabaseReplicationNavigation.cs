﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Replication;
using VShips.DataServices.Shared.Enumerations.Replication;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DatabaseReplication
{
    /// <summary>
    /// Navigation service for the DatabaseReplication module.
    /// </summary>
    public interface IDatabaseReplicationNavigation
    {
        /// <summary>
        /// Databases the replication navigate start.
        /// </summary>
        void DatabaseReplicationNavigateStart();

        /// <summary>
        /// Navigates the event log dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="eventLogIds">The event log ids.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        void NavigateEventLogDialog(INavigationContext navigationContext, List<long> eventLogIds, Action RefreshParentAfterSave);

        /// <summary>
        /// Navigates the re flag for next export dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="failedRecordIds">The failed record ids.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        void NavigateReFlagForNextExportDialog(INavigationContext navigationContext, List<long> failedRecordIds, Action RefreshParentAfterSave);


        /// <summary>
        /// Navigates the edit hub site detail dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        void NavigateEditHubSiteDetailDialog(INavigationContext navigationContext, string vesselId, Action RefreshParentAfterSave);

        /// <summary>
        /// Replications the navigate map columns.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="selectedTableId">The selected table identifier.</param>
        /// <param name="RefreshAfterSave">The refresh after save.</param>
        void ReplicationNavigateMapColumns(INavigationContext parentContext, int? selectedTableId, Action RefreshAfterSave);

        /// <summary>
        /// Navigates the add field relationship dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="refreshParentAfterSave">The refresh parent after save.</param>
        void NavigateAddFieldRelationshipDialog(INavigationContext navigationContext, Action refreshParentAfterSave);

        /// <summary>
        /// Navigates the add vessel replication dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        void NavigateAddVesselReplicationDialog(INavigationContext navigationContext, Action RefreshParentAfterSave);

        /// <summary>
        /// Navigates the add edit vessel profiler dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="profilerId">The profiler identifier.</param>
        /// <param name="RefreshParent">The refresh parent.</param>
        void NavigateAddEditVesselProfilerDialog(INavigationContext navigationContext, int? profilerId, Action RefreshParent);
        /// <summary>
        /// Replications the navigate add edit unmapped tables.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="selectedTableId">The selected table identifier.</param>
        /// <param name="RefreshAfterSave">The refresh after save.</param>
        void ReplicationNavigateAddEditUnmappedTables(INavigationContext parentContext, int? selectedTableId, Action RefreshAfterSave);

        /// <summary>
        /// Navigates the event log list.
        /// </summary>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateEventLogList(int siteId, string vesselId, string vesselName);

        /// <summary>
        /// Navigates the conflicts list.
        /// </summary>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateConflictsList(int siteId, string vesselId, string vesselName);

        /// <summary>
        /// Navigates the change vessel configuration dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        void NavigateChangeVesselConfigurationDialog(INavigationContext navigationContext, int siteId, Action RefreshParentAfterSave);

        /// <summary>
        /// Navigates the site wise package list.
        /// </summary>
        void NavigateSiteWisePackageList();

        /// <summary>
        /// Navigates to database health report.
        /// </summary>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateToDatabaseHealthReport(int siteId, string vesselId, string vesselName);

        /// <summary>
        /// Navigates to show history for package dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="packageNo">The package no.</param>
        /// <param name="packageSubType">Type of the package sub.</param>
        /// <param name="packageType">Type of the package.</param>
        void NavigateToShowHistoryForPackageDialog(INavigationContext navigationContext, int siteId, int packageNo, int packageSubType, int packageType);

        /// <summary>Navigates to show package tracking dialog.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="packageNo"></param>
        /// <param name="packageSubType"></param>
        /// <param name="rowGuid">The row unique identifier.</param>
        /// <param name="packageType">Type of the package.</param>
        void NavigateToShowPackageTrackingDialog(INavigationContext navigationContext, int siteId, int packageNo, int packageSubType, long rowGuid, int packageType);

        /// <summary>
        /// Navigates to add edit support issue dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supportIssueId">The support issue identifier.</param>
        /// <param name="selectedOfficeId">The selected office identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="supportIssueTypeId">The support issue type identifier.</param>
        void NavigateToAddEditSupportIssueDialog(INavigationContext navigationContext, int? supportIssueId, string selectedOfficeId, string vesselId, string vesselName, int? supportIssueTypeId);

        /// <summary>
        /// Navigates to view support issue history dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supportIssueId">The support issue identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateToViewSupportIssueHistoryDialog(INavigationContext navigationContext, int? supportIssueId,string vesselName);

        /// <summary>
        /// Navigates to resolve support issue history dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supportIssueId">The support issue identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="isNavigationFromDashboard">if set to <c>true</c> [is navigation from dashboard].</param>
        void NavigateToResolveSupportIssueHistoryDialog(INavigationContext navigationContext, int? supportIssueId, string vesselName, bool isNavigationFromDashboard);

        /// <summary>
        /// Navigates to show history for failed records dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="siteName">Name of the site.</param>
        /// <param name="tableId">The table identifier.</param>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="uniqueIdentifier">The unique identifier.</param>
        void NavigateToShowHistoryForFailedRecordsDialog(INavigationContext navigationContext, int siteId, string siteName, int tableId, string tableName, string uniqueIdentifier);

        /// <summary>
        /// Navigates to site wise package hub view.
        /// </summary>
        /// <param name="navigationContext">The navigation context of type <see cref="INavigationContext" />.</param>
        /// <param name="searchRequest">The search request of type <see cref="PackageDetailRequest" />.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateToSiteWisePackageHubView(INavigationContext navigationContext, PackageDetailRequest searchRequest, string vesselId, string vesselName);

        /// <summary>
        /// Navigates the manage support issues ListView.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateManageSupportIssuesListView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the import export request package view.
        /// </summary>
        void NavigateImportExportRequestPackageView();

        /// <summary>
        /// Navigates the export package view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isRegenerate">if set to <c>true</c> [is regenerate].</param>
        /// <param name="action">The action.</param>
        void NavigateExportRegeneratePackageView(INavigationContext navigationContext, bool isRegenerate, Action<object, object> action);

        /// <summary>
        /// Navigates the failed record rules add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="failedRecordRuleId">The failed record rule identifier.</param>
        /// <param name="action">The action.</param>
        void NavigateFailedRecordRulesAddEditView(INavigationContext navigationContext, int failedRecordRuleId, Action action);

        /// <summary>
        /// Navigates the event logs rules add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="eventLogRuleId">The event log rule identifier.</param>
        /// <param name="action">The action.</param>
        void NavigateEventLogsRulesAddEditView(INavigationContext navigationContext, int eventLogRuleId, Action action);

        /// <summary>
        /// Navigates to add edit release version history dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="releaseVersion">The release version.</param>
        /// <param name="action">The action.</param>
        void NavigateToAddEditReleaseVersionHistoryDialog(INavigationContext navigationContext, string releaseVersion, Action action);

        /// <summary>
        /// Navigates to support issue support remarks dialog.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="remark">The remark.</param>
        void NavigateToSupportIssueSupportRemarksDialog(INavigationContext navigation, string remark);
    }
}
