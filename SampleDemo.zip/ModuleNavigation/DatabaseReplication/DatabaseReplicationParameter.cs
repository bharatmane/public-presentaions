﻿using VShips.Contracts.Custom.Replication;

namespace VShips.Framework.Common.ModuleNavigation.DatabaseReplication
{
    /// <summary>
    /// This class is DatabaseReplicationParameter.
    /// </summary>
    public class DatabaseReplicationParameter
    {
        #region Properties

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the package listing request.
        /// </summary>
        /// <value>
        /// The package listing request.
        /// </value>
        public PackageDetailRequest PackageListingRequest { get; set; }

        #endregion
    }
}
