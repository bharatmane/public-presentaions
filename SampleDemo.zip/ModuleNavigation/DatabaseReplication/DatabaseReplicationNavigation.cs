﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Replication;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DatabaseReplication
{
    /// <summary>
    /// Default implementation of the <see cref="IDatabaseReplicationNavigation"/> service.
    /// </summary>
    public class DatabaseReplicationNavigation : BaseModuleNavigationService, IDatabaseReplicationNavigation
    {
        /// <summary>
        /// The default constructor for the DatabaseReplicationNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public DatabaseReplicationNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Databases the replication navigate start.
        /// </summary>
        public void DatabaseReplicationNavigateStart()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Navigates the event log dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="eventLogIds">The event log ids.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        public void NavigateEventLogDialog(INavigationContext navigationContext, List<long> eventLogIds, Action RefreshParentAfterSave)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.EventLogIds, eventLogIds != null ? eventLogIds:new List<long>()},
                {Constants.Action, RefreshParentAfterSave}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEventLogCommentDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the re flag for next export dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="failedRecordIds">The failed record ids.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        public void NavigateReFlagForNextExportDialog(INavigationContext navigationContext, List<long> failedRecordIds, Action RefreshParentAfterSave)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.FailedRecordIds, failedRecordIds != null ? failedRecordIds:new List<long>()},
                {Constants.Action, RefreshParentAfterSave}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReFlagForNextExportDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the edit hub site detail dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        public void NavigateEditHubSiteDetailDialog(INavigationContext navigationContext, String vesselId, Action RefreshParentAfterSave)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.VesselId, vesselId},
                {Constants.Action, RefreshParentAfterSave}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditManageHubSiteDetailDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add field relationship dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="refreshParentAfterSave">The refresh parent after save.</param>
        public void NavigateAddFieldRelationshipDialog(INavigationContext navigationContext, Action refreshParentAfterSave)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddFieldRelationshipDialogView, navigationContext, refreshParentAfterSave);
        }

        /// <summary>
        /// Navigates the add vessel replication dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        public void NavigateAddVesselReplicationDialog(INavigationContext navigationContext, Action RefreshParentAfterSave)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.Action, RefreshParentAfterSave }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddVesselForReplicationWizardView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit vessel profiler dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="profilerId">The profiler identifier.</param>
        /// <param name="RefreshParent">The refresh parent.</param>
        public void NavigateAddEditVesselProfilerDialog(INavigationContext navigationContext, int? profilerId, Action RefreshParent)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.ProfilerId, profilerId},
                {Constants.Action, RefreshParent }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditVesselProfileDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Replications the navigate add edit unmapped tables.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="selectedTableId">The selected table identifier.</param>
        /// <param name="RefreshAfterSave">The refresh after save.</param>
        public void ReplicationNavigateAddEditUnmappedTables(INavigationContext parentContext, int? selectedTableId, Action RefreshAfterSave)
        {
            var parameter = new Dictionary<string, object>
            {
                {Common.Constants.SelectedId, selectedTableId},
                {Common.Constants.Action, RefreshAfterSave},
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditTableFieldMappingView, parentContext, parameter);
        }

        /// <summary>
        /// Replications the navigate map columns.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="selectedTableId">The selected table identifier.</param>
        /// <param name="RefreshAfterSave">The refresh after save.</param>
        public void ReplicationNavigateMapColumns(INavigationContext parentContext, int? selectedTableId, Action RefreshAfterSave)
        {
            var parameter = new Dictionary<string, object>
            {
                {Common.Constants.SelectedId, selectedTableId},
                {Common.Constants.Action, RefreshAfterSave},
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapColumnsView, parentContext, parameter);
        }

        /// <summary>
        /// Navigates the event log list.
        /// </summary>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateEventLogList(int siteId, string vesselId, string vesselName)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SiteId, siteId },
                { Constants.VesselId, vesselId},
                { Constants.VesselName, vesselName}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HubEventLogListView, parameters);
        }

        /// <summary>
        /// Navigates the site wise package list.
        /// </summary>
        public void NavigateSiteWisePackageList()
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.SiteWisePackageHubView);
        }

        /// <summary>
        /// Navigates the conflicts list.
        /// </summary>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateConflictsList(int siteId, string vesselId, string vesselName)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SiteId, siteId },
                { Constants.VesselId, vesselId},
                { Constants.VesselName, vesselName}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.FailedRecordListView, parameters);
        }

        /// <summary>
        /// Navigates the change vessel configuration dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="RefreshParentAfterSave">The refresh parent after save.</param>
        public void NavigateChangeVesselConfigurationDialog(INavigationContext navigationContext, int siteId, Action RefreshParentAfterSave)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SiteId, siteId},
                {Constants.Action, RefreshParentAfterSave}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ChangeVesselConfigurationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to database health report.
        /// </summary>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateToDatabaseHealthReport(int siteId, string vesselId, string vesselName)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SiteId, siteId },
                { Constants.VesselId, vesselId},
                { Constants.VesselName, vesselName}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.DBHealthRecordView, parameters);
        }

        /// <summary>
        /// Navigates to show history for package dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="packageNo"></param>
        /// <param name="packageSubType"></param>
        /// <param name="packageType"></param>
        public void NavigateToShowHistoryForPackageDialog(INavigationContext navigationContext, int siteId, int packageNo, int packageSubType, int packageType)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SiteId, siteId},
                {Constants.PackageNo, packageNo},
                {Constants.PackageType, packageType},
                {Constants.PackageSubType, packageSubType}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ShowHistoryForPackageView, navigationContext, parameter);
        }

        /// <summary>Navigates to show package tracking dialog.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="packageNo"></param>
        /// <param name="packageSubType"></param>
        /// <param name="rowGuid">The row unique identifier.</param>
        /// <param name="packageType">Type of the package.</param>
        public void NavigateToShowPackageTrackingDialog(INavigationContext navigationContext, int siteId, int packageNo, int packageSubType, long rowGuid, int packageType)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SiteId, siteId},
                {Constants.PackageNo, packageNo},
                {Constants.UniqueIdentifier, rowGuid},
                {Constants.PackageType, packageType},
                {Constants.PackageSubType, packageSubType}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ShowPackageTrackingView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add edit support issue dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supportIssueId">The support issue identifier.</param>
        /// <param name="selectedOfficeId">The selected office identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="supportIssueTypeId">The support issue type identifier.</param>
        public void NavigateToAddEditSupportIssueDialog(INavigationContext navigationContext, int? supportIssueId, string selectedOfficeId, string vesselId, string vesselName, int? supportIssueTypeId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SupportIssueId, supportIssueId},
                {Constants.OfficeId, selectedOfficeId},
                {Constants.VesselId, vesselId},
                {Constants.SupportIssueTypeId, supportIssueTypeId },
                {Constants.VesselName, vesselName }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditSupportIssueView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to view support issue history dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supportIssueId">The support issue identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateToViewSupportIssueHistoryDialog(INavigationContext navigationContext, int? supportIssueId, string vesselName)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SupportIssueId, supportIssueId},
                {Constants.VesselName, vesselName}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewSupportIssueHistory, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to resolve support issue history dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supportIssueId">The support issue identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="isNavigationFromDashboard">if set to <c>true</c> [is navigation from dashboard].</param>
        public void NavigateToResolveSupportIssueHistoryDialog(INavigationContext navigationContext, int? supportIssueId, string vesselName, bool isNavigationFromDashboard)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SupportIssueId, supportIssueId},
                {Constants.VesselName, vesselName},
                {Constants.IsNavigationFromDashboard, isNavigationFromDashboard }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ResolveSupportIssueHistory, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to show history for failed records dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="siteId">The site identifier.</param>
        /// <param name="siteName"></param>
        /// <param name="tableId">The table identifier.</param>
        /// <param name="tableName"></param>
        /// <param name="uniqueIdentifier"></param>
        public void NavigateToShowHistoryForFailedRecordsDialog(INavigationContext navigationContext, int siteId, string siteName, int tableId, string tableName, string uniqueIdentifier)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SiteId, siteId},
                {Constants.VesselName, siteName},
                {Constants.TableId, tableId},
                {Constants.TableName, tableName},
                {Constants.UniqueIdentifier, uniqueIdentifier}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ShowHistoryForFailedRecordsView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to site wise package hub view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchRequest">The search request.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateToSiteWisePackageHubView(INavigationContext navigationContext, PackageDetailRequest searchRequest, string vesselId, string vesselName)
        {
            DatabaseReplicationParameter parameter = new DatabaseReplicationParameter()
            {
                VesselId = vesselId,
                VesselName = vesselName,
                PackageListingRequest = searchRequest
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.SiteWisePackageHubView, parameter, navigationContext);
        }

        /// <summary>
        /// Navigates the manage support issues ListView.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateManageSupportIssuesListView(INavigationContext navigationContext)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ManageSupportIssuesListView, navigationContext);
        }

        /// <summary>
        /// Navigates the import export request package view.
        /// </summary>
        public void NavigateImportExportRequestPackageView()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ImportExportRequestPackageView);
        }

        /// <summary>
        /// Navigates the export package view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isRegenerate">if set to <c>true</c> [is regenerate].</param>
        /// <param name="action">The action.</param>
        public void NavigateExportRegeneratePackageView(INavigationContext navigationContext, bool isRegenerate, Action<object, object> action)
        {
            var parameter = new Dictionary<string, object>();
            parameter.Add(Constants.IsRegenerate, isRegenerate);
            parameter.Add(Constants.Action, action);
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExportPackageView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the failed record rules add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="faildRecordRuleId">The faild record rule identifier.</param>
        /// <param name="action">The action.</param>
        public void NavigateFailedRecordRulesAddEditView(INavigationContext navigationContext, int faildRecordRuleId, Action action)
        {
            var parameter = new Dictionary<string, object>();
            parameter.Add(Constants.FailedRecordIds, faildRecordRuleId);
            parameter.Add(Constants.Action, action);

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditFailedRecordRulesView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the event logs rules add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="eventLogRuleId">The event log rule identifier.</param>
        /// <param name="action">The action.</param>
        public void NavigateEventLogsRulesAddEditView(INavigationContext navigationContext, int eventLogRuleId, Action action)
        {
            var parameter = new Dictionary<string, object>();
            parameter.Add(Constants.EventLogIds, eventLogRuleId);
            parameter.Add(Constants.Action, action);

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditEventLogsRulesView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add edit release version history dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="releaseVersion">The release version.</param>
        /// <param name="action">The action.</param>
        public void NavigateToAddEditReleaseVersionHistoryDialog(INavigationContext navigationContext, string releaseVersion, Action action)
        {
            var parameter = new Dictionary<string, object>();
            parameter.Add(Constants.UniqueIdentifier, releaseVersion);
            parameter.Add(Constants.Action, action);

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditReleaseVersionHistoryView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to support issue support remarks dialog.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="remark">The remark.</param>
        public void NavigateToSupportIssueSupportRemarksDialog(INavigationContext navigation, string remark)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SupportIssueSupportRemarksView, navigation, remark);
        }

    }
}
