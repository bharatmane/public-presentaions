﻿namespace VShips.Framework.Common.ModuleNavigation.DatabaseReplication
{
    /// <summary>
    /// Names of accessible views and regions related to the DatabaseReplication module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The module name
        /// </summary>
        public const string ModuleName = "DatabaseReplication";

        /// <summary>
        /// The module icon
        /// </summary>
        public const string ModuleIcon = "SpecialUtilityGeometry";

        /// <summary>
        /// The database health record icon
        /// </summary>
        public const string DatabaseHealthRecordIcon = "ProcurementGeometry";

        /// <summary>
        /// The running process icon
        /// </summary>
        public const string RunningProcessIcon = "HistoryGeometry";

        /// <summary>
        /// The site wise package list icon
        /// </summary>
        public const string SiteWisePackageListIcon = "ManageLocationGeometry";

        /// <summary>
        /// The site wise package hub view
        /// </summary>
        public const string SiteWisePackageHubView = "SiteWisePackageHubView";

        /// <summary>
        /// The table and field mapping icon
        /// </summary>
        public const string TableAndFielMappingIcon = "TableAndFieldMappingGeometry";

        /// <summary>
        /// The new record history icon
        /// </summary>
        public const string NewRecordHistoryIcon = "RescheduledWorkOrderGeometry";

        /// <summary>
        /// The field relationship icon
        /// </summary>
        public const string FieldRelationshipIcon = "LinkSupplier";

        /// <summary>
        /// The event log icon
        /// </summary>
        public const string EventLogIcon = "EventLogGeometry";

        /// <summary>
        /// The database backup history icon
        /// </summary>
        public const string DatabaseBackupHistoryIcon = "BackupDatabaseGeometry";

        /// <summary>
        /// The replication control room icon
        /// </summary>
        public const string ReplicationControlRoomIcon = "ControlRoomGeometry";

        /// <summary>
        /// The conflicts record icon
        /// </summary>
        public const string ConflictsRecordIcon = "ConflictRecords";

        /// <summary>
        /// The manage site icon
        /// </summary>
        public const string ManageSiteIcon = "ManageSiteDetailsGeometry";

        /// <summary>
        /// The vessel profiler icon
        /// </summary>
        public const string VesselProfilerIcon = "ManageSyncProfileGeometry";

        /// <summary>
        /// The start view
        /// </summary>
        public const string StartView = "DatabaseReplicationStartView";

        /// <summary>
        /// The site list view
        /// </summary>
        public const string SiteListView = "SiteListView";

        /// <summary>
        /// The control room view model
        /// </summary>
        public const string ControlRoomView = "ControlRoomView";

        /// <summary>
        /// The vessel replication list view
        /// </summary>
        public const string VesselReplicationListView = "VesselReplicationListView";

        /// <summary>
        /// The hub event log list view
        /// </summary>
        public const string HubEventLogListView = "HubEventLogListView";

        /// <summary>
        /// The vessel event log list view
        /// </summary>
        public const string VesselEventLogListView = "VesselEventLogListView";

        /// <summary>
        /// The table and field mapping view
        /// </summary>
        public const string TableAndFieldMappingView = "TableAndFieldMappingView";

        /// <summary>
        /// The add edit table field mapping view
        /// </summary>
        public const string AddEditTableFieldMappingView = "AddEditTableFieldMappingView";

        /// <summary>
        /// The add edit vessel profile dialog view
        /// </summary>
        public const string AddEditVesselProfileDialogView = "AddEditVesselProfileDialogView";

        /// <summary>
        /// The map columns view
        /// </summary>
        public const string MapColumnsView = "MapColumnsView";

        /// <summary>
        /// The record generation view
        /// </summary>
        public const string RecordGenerationView = "RecordGenerationView";

        /// <summary>
        /// The hub scheduler frequency view
        /// </summary>
        public const string HUBSetupView = "HUBSetupView";

        /// <summary>
        /// The application tracking view.
        /// </summary>
        public const string ApplicationTrackingView = "ApplicationTrackingView";

        /// <summary>
        /// The package tracking listing view.
        /// </summary>
        public const string PackageTrackingListingView = "PackageTrackingListingView";

        /// <summary>
        /// The import package view
        /// </summary>
        public const string ImportPackageView = "ImportPackageView";

        /// <summary>
        /// The export package view
        /// </summary>
        public const string ExportPackageView = "ExportPackageView";

        /// <summary>
        /// The backup database view
        /// </summary>
        public const string BackupDatabaseView = "BackupDatabaseView";

        /// <summary>
        /// The package generation view
        /// </summary>
        public const string PackageGenerationView = "PackageGenerationView";

        /// <summary>
        /// The add event log comment dialog view
        /// </summary>
        public const string AddEventLogCommentDialogView = "AddEventLogCommentDialogView";

        /// <summary>
        /// The failed record list view
        /// </summary>
        public const string FailedRecordListView = "FailedRecordListView";

        /// <summary>
        /// The field relationship ListView
        /// </summary>
        public const string FieldRelationshipListView = "FieldRelationshipListView";

        /// <summary>
        /// The database health record view
        /// </summary>
        public const string DBHealthRecordView = "DBHealthRecordView";

        /// <summary>
        /// The edit manage hub site detail dialog view
        /// </summary>
        public const string EditManageHubSiteDetailDialogView = "EditManageHubSiteDetailDialogView";

        /// <summary>
        /// The add field relationship dialog view
        /// </summary>
        public const string AddFieldRelationshipDialogView = "AddFieldRelationshipDialogView";

        /// <summary>
        /// The vessel profile ListView
        /// </summary>
        public const string VesselProfileListView = "VesselProfileListView";

        /// <summary>
        /// The running process trace view
        /// </summary>
        public const string RunningProcessTraceView = "RunningProcessTraceView";

        /// <summary>
        /// The new record history view
        /// </summary>
        public const string NewRecordHistoryView = "NewRecordHistoryView";

        /// <summary>
        /// The vessel dashboard view
        /// </summary>
        public const string VesselDashboardView = "VesselDashboardView";

        /// <summary>
        /// The manage site list View
        /// </summary>
        public const string ManageSiteListView = "ManageSiteListView";

        /// <summary>
        /// The re flag for next export dialog view
        /// </summary>
        public const string ReFlagForNextExportDialogView = "ReFlagForNextExportDialogView";

        /// <summary>
        /// The change vessel configuration view
        /// </summary>
        public const string ChangeVesselConfigurationView = "ChangeVesselConfigurationView";

        /// <summary>
        /// The add vessel for replication wizard view
        /// </summary>
        public const string AddVesselForReplicationWizardView = "AddVesselForReplicationWizardView";

        /// <summary>
        /// The show history for package view
        /// </summary>
        public const string ShowHistoryForPackageView = "ShowHistoryForPackageView";

        /// <summary>
        /// The show package tracking view.
        /// </summary>
        public const string ShowPackageTrackingView = "ShowPackageTrackingView";

        /// <summary>
        /// The add edit support issue view.
        /// </summary>
        public const string AddEditSupportIssueView = "AddEditSupportIssueNavigationView";

        /// <summary>
        /// The view support issue history.
        /// </summary>
        public const string ViewSupportIssueHistory = "ViewSupportIssueHistoryNavigationView";

        /// <summary>
        /// The resolve support issue history
        /// </summary>
        public const string ResolveSupportIssueHistory = "ResolveSupportIssueHistoryNavigationView";

        /// <summary>
        /// The show history for failed records view
        /// </summary>
        public const string ShowHistoryForFailedRecordsView = "ShowHistoryForFailedRecordsView";

        /// <summary>
        /// The event log ids
        /// </summary>
        public const string EventLogIds = "EventLogIds";

        /// <summary>
        /// The failed record ids
        /// </summary>
        public const string FailedRecordIds = "FailedRecordIds";

        /// <summary>
        /// The site identifier
        /// </summary>
        public const string SiteId = "SiteId";

        /// <summary>
        /// The site type identifier
        /// </summary>
        public const string SupportIssueTypeId = "SupportIssueTypeId";

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";


        /// <summary>
        /// The vessel name
        /// </summary>
        public const string VesselName = "VesselName";

        /// <summary>
        /// The profiler identifier
        /// </summary>
        public const string ProfilerId = "ProfilerId";

        /// <summary>
        /// The add event log comment
        /// </summary>
        public const string AddEventLogComment = "Add Comment";

        /// <summary>
        /// The action
        /// </summary>
        public const string Action = "Action";

        /// <summary>
        /// The varchar
        /// </summary>
        public const string VarcharType = "varchar";

        /// <summary>
        /// The image type
        /// </summary>
        public const string ImageType = "image";

        /// <summary>
        /// The bit type
        /// </summary>
        public const string BitType = "bit";

        /// <summary>
        /// The nvarchar type
        /// </summary>
        public const string NvarcharType = "nvarchar";

        /// <summary>
        /// The package no
        /// </summary>
        public const string PackageNo = "PackageNo";

        /// <summary>
        /// The package type
        /// </summary>
        public const string PackageType = "PackageType";

        /// <summary>
        /// The package sub type
        /// </summary>
        public const string PackageSubType = "PackageSubType";

        /// <summary>
        /// The table identifier
        /// </summary>
        public const string TableId = "TableId";

        /// <summary>
        /// The table name
        /// </summary>
        public const string TableName = "TableName";

        /// <summary>
        /// The primary key
        /// </summary>
        public const string PrimaryKey = "PrimaryKey";

        /// <summary>
        /// The unique identifier
        /// </summary>
        public const string UniqueIdentifier = "UniqueIdentifier";

        /// <summary>
        /// The data tracker view.
        /// </summary>
        public const string DataTrackerView = "DataTrackerView";

        /// <summary>
        /// The import export request package view
        /// </summary>
        public const string ImportExportRequestPackageView = "ImportExportRequestPackageView";

        /// <summary>
        /// The is regenerate
        /// </summary>
        public const string IsRegenerate = "IsRegenerate";

        /// <summary>
        /// The import export request icon
        /// </summary>
        public const string ImportExportRequestIcon = "ImportExportRequestGeomtery";

        /// <summary>
        /// The import export document tracking view
        /// </summary>
        public const string ImportExportDocumentTrackingView = "ImportExportDocumentTrackingView";

        /// <summary>
        /// The failed record rules view
        /// </summary>
        public const string FailedRecordRulesView = "FailedRecordRulesView";

        /// <summary>
        /// The add edit failed record rules view
        /// </summary>
        public const string AddEditFailedRecordRulesView = "AddEditFailedRecordRulesView";

        /// <summary>
        /// The event logs rules view
        /// </summary>
        public const string EventLogsRulesView = "EventLogsRulesView";

        /// <summary>
        /// The add edit event logs rules view
        /// </summary>
        public const string AddEditEventLogsRulesView = "AddEditEventLogsRulesView";

        /// <summary>
        /// The event log rules geometry
        /// </summary>
        public const string EventLogRulesIcon = "EventLogRulesGeometry";

        /// <summary>
        /// The release version history view
        /// </summary>
        public const string ReleaseVersionHistoryView = "ReleaseVersionHistoryView";

        /// <summary>
        /// The add edit release version history view
        /// </summary>
        public const string AddEditReleaseVersionHistoryView = "AddEditReleaseVersionHistoryView";

        /// <summary>
        /// The conflict rules icon
        /// </summary>
        public const string ConflictRulesIcon = "ConflictRulesGeometry";

        /// <summary>
        /// The document tracking icon
        /// </summary>
        public const string DocumentTrackingIcon = "TrackingGeometry";

        /// <summary>
        /// The vessel release icon
        /// </summary>
        public const string VesselReleaseIcon = "VesselReleaseVersionGeometry";

        /// <summary>
        /// The manage support issues geometry.
        /// </summary>
        public const string ManageSupportIssuesGeometry = "DocumentGeometry";

        /// <summary>
        /// The manage support issues ListView.
        /// </summary>
        public const string ManageSupportIssuesListView = "ManageSupportIssuesListView";

        /// <summary>
        /// The support issue identifier.
        /// </summary>
        public const string SupportIssueId = "SupportIssueId";

        /// <summary>
        /// The office identifier.
        /// </summary>
        public const string OfficeId = "OfficeId";

        /// <summary>
        /// The resolve remark save token.
        /// </summary>
        public const string ResolveRemarkSaveToken = "ResolveRemarkSaveToken";

        /// <summary>
        /// The support issue support remarks view
        /// </summary>
        public const string SupportIssueSupportRemarksView = "SupportIssueSupportRemarksView";

        /// <summary>
        /// The support issue add from dashboard
        /// </summary>
        public const string SupportIssueAddFromDashboard = "SupportIssueAddFromDashboard";

        /// <summary>
        /// The is navigation from dashboard
        /// </summary>
        public const string IsNavigationFromDashboard = "IsNavigationFromDashboard";

        /// <summary>
        /// The record request view
        /// </summary>
        public const string RecordRequestView = "RecordRequestView";
    }
}