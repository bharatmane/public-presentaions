﻿using VShips.Framework.Common.ModuleNavigation.Purchasing;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Demo
{
    /// <summary>
    /// This interface is used for navigation in demo module
    /// </summary>
    public interface IDemoNavigation
    {
        /// <summary>
        /// Demoes the navigate side list.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void DemoNavigateSideList(PurchasingStartParameter parameters);

        /// <summary>
        /// Demoes the navigate wizard.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void DemoNavigateWizard(PurchasingStartParameter parameters);

        /// <summary>
        /// Demoes the navigate wizard in popup.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void DemoNavigateWizardInPopup(INavigationContext context, PurchasingStartParameter parameters);

        /// <summary>
        /// Demoes the navigate purchasing item.
        /// </summary>
        /// <param name="orderNumber">The order number.</param>
        /// <param name="coyId">The coy identifier.</param>
        void DemoNavigatePurchasingItem(string orderNumber, string coyId);
    }
}
