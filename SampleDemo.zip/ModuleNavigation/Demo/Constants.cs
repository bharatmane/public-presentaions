﻿namespace VShips.Framework.Common.ModuleNavigation.Demo
{
    /// <summary>
    /// Names of accessible views and regions related to the configuration module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "Demo";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "DemoGeometry";

        //Views

        /// <summary>
        /// The landing or start view for demo.
        /// </summary>
        public const string StartView = "DemoStartView";

        /// <summary>
        /// The purchase order start view
        /// </summary>
        public const string ListDetailView = "PurchaseOrderListDetailView";

        /// <summary>
        /// The wizard view
        /// </summary>
        public const string WizardView = "WizardView";

        /// <summary>
        /// The navigate order view
        /// </summary>
        public const string NavigateOrderView = "NavigateOrderView";
    }
}
