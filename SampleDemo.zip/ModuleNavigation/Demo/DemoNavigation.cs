﻿using System.Collections.Generic;
using VShips.Framework.Common.ModuleNavigation.Purchasing;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Demo
{
    /// <summary>
    /// This class is implementation of navigation in demo module
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.Demo.IDemoNavigation" />
    public class DemoNavigation : BaseModuleNavigationService, IDemoNavigation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DemoNavigation" /> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public DemoNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Demoes the navigate side list.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void DemoNavigateSideList(PurchasingStartParameter parameters)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.ListDetailView, parameters);
        }

        /// <summary>
        /// Demoes the navigate purchasing item.
        /// </summary>
        /// <param name="orderNumber">The order number.</param>
        /// <param name="coyId">The coy identifier.</param>
        public void DemoNavigatePurchasingItem(string orderNumber, string coyId)
        {
            var data = new Dictionary<string, string>();
            data.Add("OrderNumber", orderNumber);
            data.Add("CoyId", coyId);

            NavigationService.NavigateNew(Constants.ModuleName, Constants.NavigateOrderView, data);
        }

        /// <summary>
        /// Demoes the navigate wizard.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void DemoNavigateWizard(PurchasingStartParameter parameters)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.WizardView, parameters);
        }

        /// <summary>
        /// Demoes the navigate wizard.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameters">The parameters.</param>
        public void DemoNavigateWizardInPopup(INavigationContext context, PurchasingStartParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.WizardView, context, parameters);
        }
    }
}
