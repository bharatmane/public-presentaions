﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CMPDashboard
{
    /// <summary>
    /// Default implementation of the <see cref="ICMPDashboardNavigation"/> service. 
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.CMPDashboard.ICMPDashboardNavigation" />
    class CMPDashboardNavigation : BaseModuleNavigationService , ICMPDashboardNavigation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CMPDashboardNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public CMPDashboardNavigation(INavigationService navigationService)
            :base(navigationService)
        {

        }

        /// <summary>
        /// CMPs the dashboard start view.
        /// </summary>
        public void CMPDashboardStartView(INavigationContext navigationContext)
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.CMPDashboardStartView);
        }
    }
}