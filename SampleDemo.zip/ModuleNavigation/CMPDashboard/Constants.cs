﻿namespace VShips.Framework.Common.ModuleNavigation.CMPDashboard
{
    /// <summary>
    /// The constants for CMPDashboard
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "CMPDashboard";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "CMPDashboardGeometry";

        /// <summary>
        /// The CMP dashboard start view
        /// </summary>
        public const string CMPDashboardStartView = "CMPDashboardStartView";

        /// <summary>
        /// The PCN missing
        /// </summary>
        public const string PCNMissing = "Missing";
    }
}