﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CMPDashboard
{
    /// <summary>
    /// Navigation service for CMP Dashboard module
    /// </summary>
    public interface ICMPDashboardNavigation
    {
        /// <summary>
        /// CMPs the dashboard start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void CMPDashboardStartView(INavigationContext navigationContext);
    }
}