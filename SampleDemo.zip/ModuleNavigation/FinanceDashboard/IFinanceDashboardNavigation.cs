﻿namespace VShips.Framework.Common.ModuleNavigation.FinanceDashboard
{
    /// <summary>
    /// Navigation service for the finance dashboard module.
    /// </summary>
    public interface IFinanceDashboardNavigation
    {
        /// <summary>
        /// Method for navigation
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="viewName"></param>
        void NavigateToModule(string moduleName,string viewName);
    }
}
