﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.FinanceDashboard
{
    /// <summary>
    /// Default implementation of the <see cref="IFinanceDashboardNavigation" /> service.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.FinanceDashboard.IFinanceDashboardNavigation" />
    public class FinanceDashboardNavigation : BaseModuleNavigationService, IFinanceDashboardNavigation
    {
        #region Constructor        
        /// <summary>
        /// Initializes a new instance of the <see cref="FinanceDashboardNavigation"/> class.
        /// </summary>
        public FinanceDashboardNavigation(INavigationService navigationService):base(navigationService)
        {

        }

        #endregion

        #region Methods
        /// <summary>
        /// Method for navigation
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="viewName"></param>
        public void NavigateToModule(string moduleName, string viewName)
        {
            NavigationService.NavigateExisting(moduleName, viewName);
        }
        #endregion
    }
}
