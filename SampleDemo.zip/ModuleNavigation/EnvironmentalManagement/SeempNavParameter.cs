﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.EnvironmentalManagement.SEEMP;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared.Enumerations.Vessel;
using VShips.Framework.Common.Model;

namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
    /// <summary>
    /// Seemp Nav Parameter Class
    /// </summary>
    public class SeempNavParameter
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the SPH identifier.
        /// </summary>
        /// <value>
        /// The SPH identifier.
        /// </value>
        public string SphId { get; set; }

        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObj { get; set; }

        /// <summary>
        /// The average measured list
        /// </summary>
        public List<float?> _avgMeasuredList;

        /// <summary>
        /// Gets or sets the graph details.
        /// </summary>
        /// <value>
        /// The graph details.
        /// </value>
        public List<VoyageSummarySeemp> GraphDetails { get; set; }

        /// <summary>
        /// Gets or sets the seemp header.
        /// </summary>
        /// <value>
        /// The seemp header.
        /// </value>
        public SeempHeaderResponse SeempHeader { get; set; }

        /// <summary>
        /// Gets or sets the seemp number.
        /// </summary>
        /// <value>
        /// The seemp number.
        /// </value>
        public string SeempNumber { get; set; }
        /// <summary>
        /// Gets or sets the status description.
        /// </summary>
        /// <value>
        /// The status description.
        /// </value>
        public string StatusDescription { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public SeempStatus? Status { get; set; }

        /// <summary>
        /// Gets or sets the status code.
        /// </summary>
        /// <value>
        /// The status code.
        /// </value>
        public string StatusCode { get; set; }

        /// <summary>
        /// Gets or sets the color of the status.
        /// </summary>
        /// <value>
        /// The color of the status.
        /// </value>
        public KPI StatusColor { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance can edit view.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can edit view; otherwise, <c>false</c>.
        /// </value>
        public bool CanEditView { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has voyage data.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has voyage data; otherwise, <c>false</c>.
        /// </value>
        public bool HasVoyageData { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has comments.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has comments; otherwise, <c>false</c>.
        /// </value>
        public bool HasComments { get; set; }

        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>
        /// The comments.
        /// </value>
        public string Comments { get; set; }

    }
}