﻿namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
    /// <summary>
    /// Constants class
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "EnvironmentalManagement";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "EnvironmentalManagementGeometry";

        /// <summary>
        /// The landing page view
        /// </summary>
        public static string LandingPageView = "EnvironmentalManagementLandingPageView";

		/// <summary>
		/// The logbook setup view
		/// </summary>
		public static string LogbookSetupView = "LogbookSetupView";

        /// <summary>
        /// The browse page start view
        /// </summary>
        public static string BrowsePageStartView = "BrowsePageStartView";

		/// <summary>
		/// The map shape file view
		/// </summary>
		public static string MapShapeFileView = "MapShapeFile";

        /// <summary>
        /// The add ods gas supply log view
        /// </summary>
        public static string AddODSGasSupplyLogView = "AddODSGasSupplyLogView";

		/// <summary>
		/// The ods gas landing log confirm view
		/// </summary>
		public static string ODSGasLandingLogConfirmView = "ODSGasLandingLogConfirmView";

		/// <summary>
		/// The ods gas landing log link view
		/// </summary>
		public static string ODSGasLandingLogLinkView = "ODSGasLandingLogLinkView";

		/// <summary>
		/// The ods gas landing log view
		/// </summary>
		public static string ODSGasLandingLogView = "ODSGasLandingLogView";

		/// <summary>
		/// The edit ods gas landed item view
		/// </summary>
		public static string EditOdsGasLandedItemView = "EditOdsGasLandedItemView";

        /// <summary>
        /// The add supply details ods view
        /// </summary>
        public static string AddSupplyDetailsOdsView = "AddSupplyDetailsOdsView";

        /// <summary>
        /// The environment document navigation view
        /// </summary>
        public static string EnvironmentDocumentNavigationView = "EnvironmentDocumentNavigationView";

        /// <summary>
        /// The add cago waste discharge view
        /// </summary>
        public static string AddCagoWasteDischargeView = "AddCagoWasteDischargeView";

        /// <summary>
        /// The add edit sludge waste discharge view
        /// </summary>
        public static string AddEditSludgeWasteDischargeView = "AddEditSludgeWasteDischargeView";

        /// <summary>
        /// The add edit oily waste discharge view
        /// </summary>
        public static string AddEditOilyWasteDischargeView = "AddEditOilyWasteDischargeView";

        /// <summary>
        /// The add edit ozone depleting substances
        /// </summary>
        public static string AddEditOzoneDepletingSubstances = "AddEditOzoneDepletingSubstances";

        /// <summary>
        /// The Advanced Notification View
        /// </summary>
        public static string AdvNotificationView = "AdvancedNotificationView";

        /// <summary>
        /// The add edit adv notification view
        /// </summary>
        public static string AddEditAdvNotificationView = "AddEditAdvNotificationView";

        /// <summary>
        /// The add edit sewage discharge view
        /// </summary>
        public const string AddEditSewageDischargeView = "AddEditSewageDischargeView";
        /// <summary>
        /// The add edit sewage black grey water event view
        /// </summary>
        public const string AddEditSewageBlackGreyWaterEventView = "AddEditSewageBlackGreyWaterEventView";

        /// <summary>
        /// The add edit garbage discharge view
        /// </summary>
        public const string AddEditGarbageDischargeView = "AddEditGarbageDischargeView";

        /// <summary>
        /// The add garbage bulk discharges view
        /// </summary>
        public const string AddGarbageBulkDischargesView = "AddGarbageBulkDischargesView";

        /// <summary>
        /// The inadequacy dialog view
        /// </summary>
        public const string InadequacyDialogView = "InadequacyDialogView";

        /// <summary>
        /// The inadequacy summary view
        /// </summary>
        public const string InadequacySummaryView = "InadequacySummaryView";

        /// <summary>
        /// The add edit inadequacy dialog view
        /// </summary>
        public const string AddEditInadequacyDialogView = "AddEditInadequacyDialogView";

        /// <summary>
        /// The add edit inadequacy marpol dialog view
        /// </summary>
        public const string AddEditInadequacyMarpolDialogView = "AddEditInadequacyMarpolDialogView";

        /// <summary>
        /// The enviroment crew lookup view
        /// </summary>
        public const string EnviromentCrewLookupView = "EnviromentCrewLookupView";
        /// <summary>
        /// The event logbook setup navigation view
        /// </summary>
        public const string EventLogbookSetupNavigationView = "EventLogbookSetupNavigationView";

        /// <summary>
        /// The garbage discharge
        /// </summary>
        public const string GarbageDischarge = "Garbage Discharge";

        /// <summary>
        /// The sewage discharge
        /// </summary>
        public const string SewageDischarge = "Sewage Discharge";

        /// <summary>
        /// The cargo waste discharge
        /// </summary>
        public const string CargoWasteDischarge = "Oil / Oily Mixture Discharge";

        /// <summary>
        /// The sludge waste discharge
        /// </summary>
        public const string SludgeWasteDischarge = "ER Oil Residue (Sludge) Discharge";
        /// <summary>
        /// The ballasting fuel detail
        /// </summary>
        public const string BallastingFuelDetail = "Ballasting/Cleaning Fuel Tanks";

        /// <summary>
        /// The oil water waste discharge
        /// </summary>
        public const string OilWaterWasteDischarge = "ER Oily Bilge Water Discharge";

        /// <summary>
        /// The ozone depleting substances discharge
        /// </summary>
        public const string OzoneDepletingSubstancesDischarge = "Ozone Depleting Substances Discharge";

        /// <summary>
        /// The advance notification
        /// </summary>
        public const string AdvanceNotification = "Advance Notification";

        /// <summary>
        /// The discharge method
        /// </summary>
        public const string DischargeMethod = "DischargeMethod";

        /// <summary>
        /// The SECA Page
        /// </summary>
        public const string SECAStartView = "SECAStartView";
        /// <summary>
        /// The seemp start view
        /// </summary>
        public const string SEEMPStartView = "SEEMPStartView";

        /// <summary>
        /// The eumrv start view
        /// </summary>
        public const string EUMRVStartView = "EUMRVStartView";

        /// <summary>
        /// The seemp vessel parameter view
        /// </summary>
        public const string SEEMPVesselParameterView = "SEEMPVesselParameterView";
        /// <summary>
        /// The add seemp navigation view
        /// </summary>
        public const string AddSEEMPNavigationView = "AddSEEMPNavigationView";
        /// <summary>
        /// The add eumrv dialog view
        /// </summary>
        public const string AddEumrvDialogView = "AddEumrvDialogView";
        /// <summary>
        /// The get voyage navigation view
        /// </summary>
        public const string GetVoyageNavigationView = "GetVoyageNavigationView";
        /// <summary>
        /// The generate voyage navigation view
        /// </summary>
        public const string GenerateVoyageNavigationView = "GenerateVoyageNavigationView";
        /// <summary>
        /// The voyage details navigation view
        /// </summary>
        public const string VoyageDetailsNavigationView = "VoyageDetailsNavigationView";
        /// <summary>
        /// The eumrv edit comments navigation view
        /// </summary>
        public const string EUMRVEditCommentsNavigationView = "EUMRVEditCommentsNavigationView";

        /// <summary>
        /// The add approve seemp navigation view
        /// </summary>
        public const string AddApproveSEEMPNavigationView = "AddApproveSEEMPNavigationView";
        /// <summary>
        /// The reopen reject navigation view
        /// </summary>
        public const string ReopenRejectNavigationView = "ReopenRejectNavigationView";

        /// <summary>
        /// The add seemp with remark view
        /// </summary>
        public const string AddSeempWithRemarkView = "AddSeempWithRemarkView";

        /// <summary>
        /// The change over hours
        /// </summary>
        public const string AddChangeOverHours = "AddChangeOverHoursView";

        /// <summary>
        /// The start fuel over change details navigation
        /// </summary>
        public const string StartFuelOverChangeDetailsNavigation = "StartFuelOverChangeDetailsNavigationView";

        /// <summary>
        /// The complete fuel over change details navigation
        /// </summary>
        public const string CompleteFuelOverChangeDetailsNavigation = "CompleteFuelOverChangeDetailsNavigationView";
        /// <summary>
        /// The seca entry navigation
        /// </summary>
        public const string SECAEntryNavigation = "SECAEntryNavigationView";
        /// <summary>
        /// The seca exit navigation
        /// </summary>
        public const string SECAExitNavigation = "SECAExitNavigationView";
        /// <summary>
        /// The eca exit navigation
        /// </summary>
        public const string ECAExitNavigation = "ECAExitNavigationView";
        /// <summary>
        /// The exit change over
        /// </summary>
        public const string ExitChangeOver = "ExitChangeOverView";

        /// <summary>
        /// The seca geometry
        /// </summary>
        public const string SECAGeometry = "SECAGeometry";
        /// <summary>
        /// The seemp geometry
        /// </summary>
        public const string SEEMPGeometry = "SEEMPGeometry";
        /// <summary>
        /// The component image dialog
        /// </summary>
        public const string ComponentImageDialog = "ComponentImageDialogView";

        /// <summary>
        /// The inadequacy
        /// </summary>
        public const string Inadequacy = "Inadequacy";

        /// <summary>
        /// The port inadequacy detail
        /// </summary>
        public const string PortInadequacyDetail = "Port inadequacy detail";

        /// <summary>
        /// The discharge details
        /// </summary>
        public const string DischargeDetails = "Discharge Details";

        /// <summary>
        /// The eca region map view
        /// </summary>
        public const string ECARegionMapView = "ECARegionMapView";

        /// <summary>
        /// The eca setup vessel maintainer view
        /// </summary>
        public const string ECASetupVesselMaintainerView = "ECASetupVesselMaintainerView";

        /// <summary>
        /// The vessel waste emission summary report view
        /// </summary>
        public const string VesselWasteEmissionSummaryReportView = "VesselWasteEmissionSummaryReportView";

        /// <summary>
        /// The ozone depleting substances report view
        /// </summary>
        public const string OzoneDepletingSubstancesReportView = "OzoneDepletingSubstancesReportView";

        /// <summary>
        /// The vessel waste emission listing report view
        /// </summary>
        public const string VesselWasteEmissionListingReportView = "VesselWasteEmissionListingReportView";

        /// <summary>
        /// The garbage waste details report view
        /// </summary>
        public const string GarbageWasteDetailsReportView = "GarbageWasteDetailsReportView";

        /// <summary>
        /// The oil record book for cargo waste report view
        /// </summary>
        public const string OilRecordBookForCargoWasteReportView = "OilRecordBookForCargoWasteReportView";

        /// <summary>
        /// The sludge waste discharge report view
        /// </summary>
        public const string SludgeWasteDischargeReportView = "SludgeWasteDischargeReportView";

        /// <summary>
        /// The oily water waste discharge repot view
        /// </summary>
        public const string OilyWaterWasteDischargeRepotView = "OilyWaterWasteDischargeRepotView";

        /// <summary>
        /// The environment management approve view
        /// </summary>
        public const string EnvironmentManagementApproveView = "EnvironmentManagementApproveView";

        /// <summary>
        /// The environment notification approve view
        /// </summary>
        public const string EnvironmentNotificationApproveView = "EnvironmentNotificationApproveView";

        /// <summary>
        /// The vessel details dialog view
        /// </summary>
        public const string VesselDetailsDialogView = "VesselDetailsDialogView";

        /// <summary>
        /// The seca navigation
        /// </summary>
        public const string SecaNavigation = "SecaNavigation";

        /// <summary>
        /// The seemp navigation
        /// </summary>
        public const string SEEMPNavigation = "SEEMP Navigation";

        /// <summary>
        /// The voyage details view
        /// </summary>
        public const string VoyageDetailsView = "VoyageDetailsView";

        /// <summary>
        /// The add edit eumrv navigation view
        /// </summary>
        public const string AddEditEumrvNavigationView = "AddEditEumrvNavigationView";

        /// <summary>
        /// The monitoring plan navigation view.
        /// </summary>
        public const string MonitoringPlanNavigationView = "MonitoringPlanNavigationView";

        /// <summary>
        /// The add edit fuel type emission factor navigation view.
        /// </summary>
        public const string AddEditFuelTypeEmissionFactorNavigationView = "AddEditFuelTypeEmissionFactorNavigationView";

        /// <summary>
        /// The add edit measuring equipment view
        /// </summary>
        public const string AddEditMeasuringEquipmentView = "AddEditMeasuringEquipmentView";
        
        /// <summary>
        /// The export XML landing page view.
        /// </summary>
        public const string ExportXMLLandingPageView = "ExportXMLLandingPageView";

        /// <summary>
        /// The add edit fuel tank navigation view.
        /// </summary>
        public const string AddEditFuelTankNavigationView = "AddEditFuelTankNavigationView";

        /// <summary>
        /// The add edit emission source details view
        /// </summary>
        public const string AddEditEmissionSourceDetailsView = "AddEditEmissionSourceDetailsView";
        /// <summary>
        /// The add failure of monitoring control view
        /// </summary>
        public const string AddFailureOfMonitoringControlView = "AddFailureOfMonitoringControlView";
        /// <summary>
        /// The electronic logbook date navigation view
        /// </summary>
        public const string ElectronicLogbookDateNavigationView = "ElectronicLogbookDateNavigationView";
        /// <summary>
        /// The add voyage weekly rob report view
        /// </summary>
        public const string AddVoyageWeeklyRobReportView = "AddVoyageWeeklyRobReportView";
        /// <summary>
        /// The add ballasting cleaning view
        /// </summary>
        public const string AddBallastingCleaningView = "AddBallastingCleaningView";
        /// <summary>
        /// The add discharge of dirty ballast view
        /// </summary>
        public const string AddDischargeOfDirtyBallastView = "AddDischargeOfDirtyBallastView";
        /// <summary>
        /// The add edit additional operations event view
        /// </summary>
        public const string AddEditAdditionalOperationsEventView = "AddEditAdditionalOperationsEventView";

		/// <summary>
		/// The add equipment maintenance log view
		/// </summary>
		public const string AddEquipmentMaintenanceLogView = "AddEquipmentMaintenanceLogView";

        /// <summary>
        /// The add equipment recharge repair log view
        /// </summary>
        public const string AddEquipmentRechargeRepairLogView = "AddEquipmentRechargeRepairLogView";
        /// <summary>
        /// The link unique identifier navigation view
        /// </summary>
        public const string LinkUniqueIdentifierNavigationView = "LinkUniqueIdentifierNavigationView";
        /// <summary>
        /// The add unique identifier navigation view
        /// </summary>
        public const string AddUniqueIdentifierNavigationView = "AddUniqueIdentifierNavigationView";
        /// <summary>
        /// The add discharge to atmosphere navigation view
        /// </summary>
        public const string AddDischargeToAtmosphereNavigationView = "AddDischargeToAtmosphereNavigationView";

        /// <summary>
        /// The add service monitoring control view
        /// </summary>
        public const string AddServiceMonitoringControlView = "AddServiceMonitoringControlView";
        /// <summary>
        /// The service failure events ListView
        /// </summary>
        public const string ServiceFailureEventsListView = "ServiceFailureEventsListView";
        /// <summary>
        /// The log sign off navigation view
        /// </summary>
        public const string ORBPartAActionsNavigationView = "ORBPartAActionsNavigationView";
        /// <summary>
        /// The orb part b actions navigation view
        /// </summary>
        public const string ORBPartBActionsNavigationView = "ORBPartBActionsNavigationView";
        /// <summary>
        /// The ods record book actions navigation view
        /// </summary>
        public const string ODSRecordBookActionsNavigationView = "ODSRecordBookActionsNavigationView";
        /// <summary>
        /// The sewage record book action navigation view
        /// </summary>
        public const string SewageRecordBookActionNavigationView = "SewageRecordBookActionNavigationView";
        /// <summary>
        /// The ods record annexure actions navigation view
        /// </summary>
        public const string ODSRecordAnnexureActionsNavigationView = "ODSRecordAnnexureActionsNavigationView";
        /// <summary>
        /// The navigate spare view alert popup
        /// </summary>
        public const string NavigateSpareViewAlertPopup = "NavigateSpareViewAlertPopup";
        /// <summary>
        /// The master verification login view
        /// </summary>
        public const string MasterVerificationLoginView = "MasterVerificationLoginView";
		/// <summary>
		/// The garbage record book action view
		/// </summary>
		public const string GarbageRecordBookActionsNavigationView = "GarbageRecordBookActionsNavigationView";

        /// <summary>
        /// The download environment logbook report view
        /// </summary>
        public const string DownloadEnvironmentLogbookReportView = "DownloadEnvironmentLogbookReportView";

		/// <summary>
		/// The loading and ballasting detail view
		/// </summary>
		public const string LoadingAndBallastingDetailView = "LoadingAndBallastingDetailView";

		/// <summary>
		/// The internal transfer view
		/// </summary>
		public const string InternalTransferView = "InternalTransferView";

		/// <summary>
		/// The accidentally oil discharge view
		/// </summary>
		public const string AccidentallyOilDischargeView = "AccidentallyOilDischargeView";

        /// <summary>
        /// The additional operational procedures and general remarks view
        /// </summary>
        public const string AdditionalOperationalProceduresAndGeneralRemarksView = "AdditionalOperationalProceduresAndGeneralRemarksView";

        /// <summary>
        /// The add ballasting of dedicated clean ballast tank view
        /// </summary>
        public const string AddBallastingOfDedicatedCleanBallastTankView = "AddBallastingOfDedicatedCleanBallastTankView";

		/// <summary>
		/// The discharge of ballast from clean tank view
		/// </summary>
		public const string DischargeOfBallastFromCleanTankView = "DischargeOfBallastFromCleanTankView";

        /// <summary>
        /// The cleaning of cargo tanks view
        /// </summary>
        public const string CleaningOfCargoTanksView = "CleaningOfCargoTanksView";

        /// <summary>
        /// The emission guidance document navigation view
        /// </summary>
        public const string EmissionGuidanceDocumentNavigationView = "EmissionGuidanceDocumentNavigationView";

        /// <summary>
        /// The add accidental or exceptional discharge view
        /// </summary>
        public const string AddAccidentalOrExceptionalDischargeView = "AddAccidentalOrExceptionalDischargeView";
    }
}