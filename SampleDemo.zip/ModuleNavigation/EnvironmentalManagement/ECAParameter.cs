﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
	/// <summary>
	/// ECA Parameter Class
	/// </summary>
	public class ECAParameter
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }

		/// <summary>
		/// Gets or sets the eca detail identifier.
		/// </summary>
		/// <value>
		/// The eca detail identifier.
		/// </value>
		public string ECADetailId { get; set; }

		/// <summary>
		/// Gets or sets the list of stage ids.
		/// </summary>
		/// <value>
		/// The list of stage ids.
		/// </value>
		public List<string> ListOfStageIds { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from change over.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from change over; otherwise, <c>false</c>.
        /// </value>
        public bool? IsFromChangeOver { get; set; }
        /// <summary>
        /// Gets or sets the date to validate on.
        /// </summary>
        /// <value>
        /// The date to validate on.
        /// </value>
        public DateTime? DateToValidateOn { get; set; }
        /// <summary>
        /// Gets or sets from capacity to validate.
        /// </summary>
        /// <value>
        /// From capacity to validate.
        /// </value>
        public decimal? FromCapacityToValidate { get; set; }
        /// <summary>
        /// Gets or sets to capacity to validate.
        /// </summary>
        /// <value>
        /// To capacity to validate.
        /// </value>
        public decimal? ToCapacityToValidate { get; set; }
        /// <summary>
        /// Gets or sets the maximum hours.
        /// </summary>
        /// <value>
        /// The maximum hours.
        /// </value>
        public decimal? maxHours { get; set; }
        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object sharedObject { get; set; }
	}
}