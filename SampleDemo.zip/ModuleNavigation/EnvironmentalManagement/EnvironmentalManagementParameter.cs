﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.EnvironmentalManagement;
using VShips.Contracts.Custom.PlannedMaintenance;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Enumerations.Vessel;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
	/// <summary>
	/// Environmental Management Parameter Class
	/// </summary>
	public class EnvironmentalManagementParameter : BaseViewModel
    {
        #region Actions

        /// <summary>
        /// The raise filter changed
        /// </summary>
        public Action RaiseFilterChanged;

        /// <summary>
        /// The raise vessel changed
        /// </summary>
        public Action RaiseVesselChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether this instance is logbook activated.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is logbook activated; otherwise, <c>false</c>.
        /// </value>
        public bool IsLogbookActivated { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }
        /// <summary>
        /// Gets or sets the type of the discharged.
        /// </summary>
        /// <value>
        /// The type of the discharged.
        /// </value>
        public DischargeType DischargedType { get; set; }

		/// <summary>
		/// Gets or sets the discharged type identifier.
		/// </summary>
		/// <value>
		/// The discharged type identifier.
		/// </value>
		public string DischargedTypeId { get; set; }

        /// <summary>
        /// Gets or sets the gas type identifier.
        /// </summary>
        /// <value>
        /// The gas type identifier.
        /// </value>
        public string GasTypeId { get; set; }
        /// <summary>
        /// Gets or sets the type of the gas.
        /// </summary>
        /// <value>
        /// The type of the gas.
        /// </value>
        public string GasType { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is requisition mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is requisition mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsRequisitionMode { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

		/// <summary>
		/// Gets or sets the component identifier.
		/// </summary>
		/// <value>
		/// The component identifier.
		/// </value>
		public string ComponentId { get; set; }

		/// <summary>
		/// Gets or sets the PWH identifier.
		/// </summary>
		/// <value>
		/// The PWH identifier.
		/// </value>
		public string PwhId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is for sign off.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for sign off; otherwise, <c>false</c>.
        /// </value>
        public bool IsForSignOff { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is for approve.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for approve; otherwise, <c>false</c>.
        /// </value>
        public bool IsForApprove { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is for reopen.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for reopen; otherwise, <c>false</c>.
        /// </value>
        public bool IsForReopen { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is for delete.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for delete; otherwise, <c>false</c>.
        /// </value>
        public bool IsForDelete { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is for log view.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for log view; otherwise, <c>false</c>.
        /// </value>
        public bool IsForLogView { get; set; }
        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is edit mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is edit mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsEditMode { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is part added mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is part added mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsPartAddedMode { get; set; }
        /// <summary>
        /// Gets or sets the use qty label.
        /// </summary>
        /// <value>
        /// The use qty label.
        /// </value>
        public string UseQtyLabel { get; set; }

        /// <summary>
        /// Gets or sets the waste discharge identifier.
        /// </summary>
        /// <value>
        /// The waste discharge identifier.
        /// </value>
        public string WasteDischargeId { get; set; }
        /// <summary>
        /// Gets or sets the bunkring identifier.
        /// </summary>
        /// <value>
        /// The bunkring identifier.
        /// </value>
        public string BunkringId { get; set; }
        /// <summary>
        /// Gets or sets the activity identifier.
        /// </summary>
        /// <value>
        /// The activity identifier.
        /// </value>
        public string ActivityId { get; set; }
        /// <summary>
        /// Gets or sets the selected event ids.
        /// </summary>
        /// <value>
        /// The selected event ids.
        /// </value>
        public List<string> SelectedEventIds { get; set; }
        /// <summary>
        /// Gets or sets the selected status ids.
        /// </summary>
        /// <value>
        /// The selected status ids.
        /// </value>
        public List<string> SelectedStatusIds { get; set; }

        /// <summary>
        /// Gets or sets the advance notification identifier.
        /// </summary>
        /// <value>
        /// The advance notification identifier.
        /// </value>
        public string AdvanceNotificationId { get; set; }
        /// <summary>
        /// Gets or sets the logbook type identifier.
        /// </summary>
        /// <value>
        /// The logbook type identifier.
        /// </value>
        public string LogbookTypeId { get; set; }
        /// <summary>
        /// Gets or sets the name of the logbook type.
        /// </summary>
        /// <value>
        /// The name of the logbook type.
        /// </value>
        public string LogbookTypeName{ get; set; }

        /// <summary>
        /// Gets or sets the login user.
        /// </summary>
        /// <value>
        /// The login user.
        /// </value>
        public User loginUser { get; set; }

        /// <summary>
        /// Gets or sets the inadequacy identifier.
        /// </summary>
        /// <value>
        /// The inadequacy identifier.
        /// </value>
        public string InadequacyId { get; set; }

		/// <summary>
		/// Gets or sets the title.
		/// </summary>
		/// <value>
		/// The title.
		/// </value>
		public string Title { get; set; }

        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObject { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is view mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is view mode; otherwise, <c>false</c>.
        /// </value>
        public bool CanEditView { get; set; }
        /// <summary>
        /// Gets or sets the electronic logbook date.
        /// </summary>
        /// <value>
        /// The electronic logbook date.
        /// </value>
        public DateTime? CutOffDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [copy discharge].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [copy discharge]; otherwise, <c>false</c>.
        /// </value>
        public bool CopyDischarge { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is view mode.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is view mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsViewMode { get; set; }

        /// <summary>
        /// Gets or sets the requisition detail.
        /// </summary>
        /// <value>
        /// The requisition detail.
        /// </value>
        public VesselOrderSearchResponse RequisitionDetail { get; set; }

        /// <summary>
        /// Gets or sets the selected equipment.
        /// </summary>
        /// <value>
        /// The selected equipment.
        /// </value>
        public object SelectedEquipment { get; set; }

		/// <summary>
		/// Gets or sets the quantity calculation.
		/// </summary>
		/// <value>
		/// The quantity calculation.
		/// </value>
		public int QuantityCalculation { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether [applicable for port].
		/// </summary>
		/// <value>
		///   <c>true</c> if [applicable for port]; otherwise, <c>false</c>.
		/// </value>
		public bool ApplicableForPort { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether [applicable for sea].
		/// </summary>
		/// <value>
		///   <c>true</c> if [applicable for sea]; otherwise, <c>false</c>.
		/// </value>
		public bool ApplicableForSea { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is for search and link.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is for search and link; otherwise, <c>false</c>.
		/// </value>
		public bool IsForSearchAndLink { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is from search and link add items.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is from search and link add items; otherwise, <c>false</c>.
		/// </value>
		public bool IsFromSearchAndLinkAddItems { get; set; }

		/// <summary>
		/// Gets or sets the LFD identifier.
		/// </summary>
		/// <value>
		/// The LFD identifier.
		/// </value>
		public string LfdId { get; set; }

		/// <summary>
		/// Gets or sets the on search and link add items select.
		/// </summary>
		/// <value>
		/// The on search and link add items select.
		/// </value>
		public Action<List<LandedInventoryItemForODSResponse>> OnSearchAndLinkAddItemsSelect { get; set; }

		/// <summary>
		/// Gets or sets the on map landed items select.
		/// </summary>
		/// <value>
		/// The on map landed items select.
		/// </value>
		public Action<List<LandedInventoryItemForODSResponse>> OnMapLandedItemsSelect { get; set; }

		/// <summary>
		/// Gets or sets the function to be executed on save.
		/// </summary>
		/// <value>
		/// The function to be executed on save.
		/// </value>
		public Func<object,bool> FuncToBeExecutedOnSave { get; set; }

        /// <summary>Gets or sets a value indicating whether this instance is from engine log book.</summary>
        /// <value>
        ///   <c>true</c> if this instance is from engine log book; otherwise, <c>false</c>.</value>
        public bool IsFromEngineLogBook { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is outstanding attachment flag.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is outstanding attachment flag; otherwise, <c>false</c>.
        /// </value>
        public bool IsOutstandingAttachmentFlag { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [show pending inadequacy].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show pending inadequacy]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowPendingInadequacy { get; set; }

        #endregion

        #region Properties
        /// <summary>
        /// The start date
        /// </summary>
        private DateTime? _startDate;
        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime? StartDate
        {
            get { return _startDate; }
            set
            {
                if (Set(() => StartDate, ref _startDate, value))
                {

                    if (value != null)
                    {
                        if (value.Value > EndDate)
                        {
                            _endDate = value;
                            RaisePropertyChanged(() => EndDate);
                        }
                    }

                    if (RaiseFilterChanged != null)
                    {
                        RaiseFilterChanged();
                    }
                }
            }
        }

        /// <summary>
        /// The end date
        /// </summary>
        private DateTime? _endDate;
        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>
        public DateTime? EndDate
        {
            get { return _endDate; }
            set
            {
                if (Set(() => EndDate, ref _endDate, value))
                {

                    if (value != null)
                    {
                        if (value.Value < StartDate)
                        {
                            _startDate = value;
                            RaisePropertyChanged(() => StartDate);
                        }
                    }

                    if (RaiseFilterChanged != null)
                    {
                        RaiseFilterChanged();
                    }
                }
            }
        }

        /// <summary>
        /// The menu item
        /// </summary>
        private UserMenuItem _menuItem;
        /// <summary>
        /// Gets or sets the menu item.
        /// </summary>
        /// <value>
        /// The menu item.
        /// </value>
        public UserMenuItem MenuItem
        {
            get { return _menuItem; }
            set
            {
                if (Set(() => MenuItem, ref _menuItem, value))
                {
                    if (RaiseVesselChanged != null)
                    {
                        RaiseVesselChanged();
                    }
                }
            }
        }

        /// <summary>
        /// The port identifier
        /// </summary>
        private string _portId;

        /// <summary>
        /// Gets or sets the port identifier.
        /// </summary>
        /// <value>
        /// The port identifier.
        /// </value>
        public string PortId
        {
            get { return _portId; }
            set { Set(() => PortId, ref _portId, value); }
        }

        /// <summary>
        /// The position identifier
        /// </summary>
        private string _posId;

        /// <summary>
        /// Gets or sets the position identifier.
        /// </summary>
        /// <value>
        /// The position identifier.
        /// </value>
        public string PosId
        {
            get { return _posId; }
            set { Set(() => PosId, ref _posId, value); }
        }

        /// <summary>
        /// The port name
        /// </summary>
        private string _portName;

        /// <summary>
        /// Gets or sets the name of the port.
        /// </summary>
        /// <value>
        /// The name of the port.
        /// </value>
        public string PortName
        {
            get { return _portName; }
            set { Set(() => PortName, ref _portName, value); }
        }

        /// <summary>
        /// The country code
        /// </summary>
        private string _countryCode;

        /// <summary>
        /// Gets or sets the country code.
        /// </summary>
        /// <value>
        /// The country code.
        /// </value>
        public string CountryCode
        {
            get { return _countryCode; }
            set { Set(() => CountryCode, ref _countryCode, value); }
        }

        /// <summary>
        /// The country name
        /// </summary>
        private string _countryName;

        /// <summary>
        /// Gets or sets the name of the country.
        /// </summary>
        /// <value>
        /// The name of the country.
        /// </value>
        public string CountryName
        {
            get { return _countryName; }
            set { Set(() => CountryName, ref _countryName, value); }
        }
        
        #endregion

        #region Methods

        /// <summary>
        /// Sets the user menu item.
        /// </summary>
        /// <param name="userMenuItem">The user menu item.</param>
        public void SetUserMenuItem(UserMenuItem userMenuItem)
        {
            _menuItem = userMenuItem;
            RaisePropertyChanged(() => MenuItem);
        }
        #endregion

        #region Cleanups

        /// <summary>
        /// Cleans up the instance resources.
        /// <para>
        /// To cleanup additional resources, override this method, clean up and then call base.Cleanup().
        /// </para>
        /// </summary>
        public override void Cleanup()
        {
            if (RaiseFilterChanged != null)
            {
                RaiseFilterChanged = null;
            }
            if (RaiseVesselChanged != null)
            {
                RaiseVesselChanged = null;
            }
            if (MenuItem != null)
            {
                MenuItem = null;
            }
			OnSearchAndLinkAddItemsSelect = null;
			OnMapLandedItemsSelect = null;
			FuncToBeExecutedOnSave = null;
			base.Cleanup();
        }

        #endregion
    }
}
