﻿using VShips.Contracts.Custom.EnvironmentalManagement.EUMRV;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
    /// <summary>
    /// Navigation service for the environmental management module.
    /// </summary>
    public interface IEnvironmentalManagementNavigation
    {
        /// <summary>
        /// Environmental Management the navigation BrowsePage.
        /// </summary>
        void NavigateBrowsePage();

		/// <summary>
		/// Navigates the maps.
		/// </summary>
		void NavigateMaps();

        /// <summary>
        /// Navigates to crew lookup view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="crewRequest">The crew request.</param>
        /// <param name="parentID">The parent identifier.</param>
        void NavigateToCrewLookupView(INavigationContext context, object crewRequest, string parentID);

        /// <summary>
        /// Navigates to add edit cargo waste discharge.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditCargoWasteDischarge(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to electronic date popup.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToElectronicDatePopup(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to add edit failure monitoring.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditFailureMonitoring(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to add service monitoring.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddServiceMonitoring(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to log sign off view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToORBPartAActionsNavigationView(INavigationContext context, object parameter);
		
		/// <summary>
		/// Navigates to garbage record book actions navigation view.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="parameter">The parameter.</param>
		void NavigateToGarbageRecordBookActionsNavigationView(INavigationContext context, object parameter);
		
		/// <summary>
		/// Navigates to master verification navigation view.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="parameter">The parameter.</param>
		void NavigateToMasterVerificationNavigationView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to failure events list.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToFailureEventsList(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add voyage weekly rob report view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddVoyageWeeklyRobReportView(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to add ballasting view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddBallastingView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit event type view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="viewName">Name of the view.</param>
        void NavigateToAddEditEventTypeView(INavigationContext context, object parameter, string viewName);

		/// <summary>
		/// Navigates to edit ods gas landed item view.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="parameter">The parameter.</param>
		/// <param name="viewName">Name of the view.</param>
		void NavigateToEditOdsGasLandedItemView(INavigationContext context, object parameter, string viewName);

        /// <summary>
        /// Navigates to add edit sludge waste discharge.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditSludgeWasteDischarge(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit oily waste discharge.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditOilyWasteDischarge(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit ozone depleting substances.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditOzoneDepletingSubstances(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to add ods gas supply log.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddODSGasSupplyLog(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to add supply details ods view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddSupplyDetailsOdsView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the advance notification.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAdvanceNotification(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit advance notification.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditAdvanceNotification(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to environment file attachments.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEnvironmentFileAttachments(INavigationContext context, object parameter);

        /// <summary>
        /// Environmentals the management navigation browse page.
        /// </summary>
        /// <param name="paramter">The paramter.</param>
        void EnvironmentalManagementNavigationBrowsePage(object paramter);

        /// <summary>
        /// Navigates to add edit sewage.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditSewage(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit garbage.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditGarbage(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit garbage in bulk.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditGarbageInBulk(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to inadequacy dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToInadequacyDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit inadequacy dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditInadequacyDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to summary inadequacy dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToSummaryInadequacyDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to add edit inadequacy marpol dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditInadequacyMarpolDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to seca.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateToSECA(object parameter);

        /// <summary>
        /// Navigates to add change over hours.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToAddChangeOverHours(INavigationContext context, ECAParameter ecaParameter);

        /// <summary>
        /// Navigates to complete fuel over change details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToCompleteFuelOverChangeDetails(INavigationContext context, ECAParameter ecaParameter);

        /// <summary>
        /// Navigates to start fuel over change details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToStartFuelOverChangeDetails(INavigationContext context, ECAParameter ecaParameter);

        /// <summary>
        /// Navigates to seca entry.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToSECAEntry(INavigationContext context, ECAParameter ecaParameter);

        /// <summary>
        /// Navigates to seca exit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToSECAExit(INavigationContext context, ECAParameter ecaParameter);
        /// <summary>
        /// Navigates to eca exit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToECAExit(INavigationContext context, ECAParameter ecaParameter);

        /// <summary>
        /// Navigates to exit change over.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        void NavigateToExitChangeOver(INavigationContext context, ECAParameter ecaParameter);

        /// <summary>
        /// Navigates to eca setup.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="VesselId">The vessel identifier.</param>
        void NavigateToEcaSetup(INavigationContext context, string VesselId);

        /// <summary>
        /// Navigates to component image dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="name">The name.</param>
        void NavigateToComponentImageDialog(INavigationContext context, string name);

        /// <summary>
        /// Navigates to eca region map.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="edlId">The edl identifier.</param>
		void NavigateToECARegionMap(INavigationContext context, string edlId);

        /// <summary>
        /// Navigates the vessel waste emission summary report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="fleetDescription">The fleet description.</param>
        /// <param name="menuType">Type of the menu.</param>
        /// <param name="isVesselClicked">if set to <c>true</c> [is vessel clicked].</param>
        /// <param name="isPdfFormat">if set to <c>true</c> [is PDF format].</param>
        /// <param name="selectedMenuType">Type of the selected menu.</param>
        void NavigateVesselWasteEmissionSummaryReport(INavigationContext context, string fleetId, string fleetDescription, string menuType, bool isVesselClicked, bool isPdfFormat, UserMenuItemType selectedMenuType);

        /// <summary>
        /// Navigates the ozone depleting substances report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateOzoneDepletingSubstancesReport(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the vessel waste emission listing report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="fleetDescription">The fleet description.</param>
        /// <param name="menuType">Type of the menu.</param>
        void NavigateVesselWasteEmissionListingReport(INavigationContext navigationContext, string fleetId, string fleetDescription, UserMenuItemType menuType);

        /// <summary>
        /// Navigates the garbage waste details report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateGarbageWasteDetailsReport(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the oily water waste discharge report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateCargoWasteDischargeReport(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the sludge waste discharge report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateSludgeWasteDischargeReport(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the oily water waste discharge report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateOilyWaterWasteDischargeReport(INavigationContext navigationContext, string vesselId);


        /// <summary>
        /// Navigates to enviroment approve view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEnviromentApproveView(INavigationContext context, object parameter);
        /// <summary>
        /// Navigates to enviroment notification approve view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEnviromentNotificationApproveView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the vessel details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateVesselDetails(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to environment manager landing page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEnvironmentManagerLandingPage(object parameter);

        /// <summary>
        /// Navigates to download environment logbook report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToDownloadEnvironmentLogbookReport(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to emission guidance document view.
        /// </summary>
        /// <param name="context">
        /// The context.
        /// </param>
        void NavigateToEmissionGuidanceDocumentView(INavigationContext context);

        #region EU MRV  

        /// <summary>
        /// Navigates the add edit fuel tank view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity of type <see cref="EumrvNavParameter"/>.</param>
        void NavigateAddEditFuelTankView(INavigationContext navigationContext, EumrvNavParameter entity);

        /// <summary>
        /// Navigates the add edit fuel type emission factor navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="entity">The entity of type <see cref="EumrvNavParameter" />.</param>
        void NavigateAddEditFuelTypeEmissionFactorNavigationView(INavigationContext context, EumrvNavParameter entity);

        /// <summary>
        /// Navigates the monitoring plan view.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateMonitoringPlanView(string vesselId);

        /// <summary>
        /// Navigates the add edit eumrv details.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateAddEditEumrvDetails(string vesselId, string vesselName);

        /// <summary>
        /// Navigates to add eumrv navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEumrvNavigationView(INavigationContext context, EumrvNavParameter parameter);

        /// <summary>
        /// Navigates to generate voyage navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToGenerateVoyageNavigationView(INavigationContext context, EumrvNavParameter parameter);

        /// <summary>
        /// Navigates to voyage details navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToVoyageDetailsNavigationView(INavigationContext context, EumrvNavParameter parameter);

		/// <summary>
		/// Navigates to logbook setup view.
		/// </summary>
		/// <param name="parameter">The parameter.</param>
		void NavigateToLogbookSetupView( object parameter);

        /// <summary>
        /// Navigates to eumrv edit comments navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEumrvEditCommentsNavigationView(INavigationContext context, EumrvNavParameter parameter);

        /// <summary>
        /// Navigates to add edit measuring equipment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        /// <param name="isNewRecord">if set to <c>true</c> [is new record].</param>
        /// <param name="equipment">The equipment.</param>
        void NavigateToAddEditMeasuringEquipment(INavigationContext navigationContext, string vesselId, bool isEdit, bool isNewRecord, MeasuringEquipment equipment);

        /// <summary>
        /// Navigates the landing pagegenerate XML.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselIds">The vessel ids.</param>
        void NavigateLandingPagegenerateXML(INavigationContext navigationContext, string vesselIds);


        /// <summary>
        /// Navigates to add edit emission source details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        /// <param name="isNewRecord">if set to <c>true</c> [is new record].</param>
        /// <param name="emissionSource">The emission source.</param>
        void NavigateToAddEditEmissionSourceDetails(INavigationContext navigationContext, string vesselId, bool isEdit, bool isNewRecord, EmissionSourceDetails emissionSource);
        #endregion

        #region SEEMP

        /// <summary>
        /// Navigates to seemp.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateToSEEMP(object parameter);

        /// <summary>
        /// Navigates to seemp vessel parameter view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        void NavigateToSEEMPVesselParameterView(INavigationContext context, string vesselId, bool isInEditMode);

        /// <summary>
        /// Navigates to add seemp navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddSEEMPNavigationView(INavigationContext context, SeempNavParameter parameter);

        /// <summary>
        /// Navigates to get voyage navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToGetVoyageNavigationView(INavigationContext context, SeempNavParameter parameter);

        /// <summary>
        /// Navigates to add approve seemp navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddApproveSEEMPNavigationView(SeempNavParameter parameter);

        /// <summary>
        /// Navigates to reopen reject seemp navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToReopenRejectSEEMPNavigationView(INavigationContext context, SeempNavParameter parameter);

        /// <summary>
        /// Navigates to voyage details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToVoyageDetails(INavigationContext navigationContext, SeempNavParameter parameter);

        /// <summary>
        /// Navigates to add seemp wit remark.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddSEEMPWitRemark(INavigationContext context, SeempNavParameter parameter);

        #endregion
    }
}