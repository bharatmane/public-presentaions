﻿namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
    /// <summary>
    /// Services and constants relating to the haz occs module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
