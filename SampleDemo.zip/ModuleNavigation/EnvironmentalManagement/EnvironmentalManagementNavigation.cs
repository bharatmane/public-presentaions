﻿using System.Collections.Generic;
using VShips.Contracts.Custom.EnvironmentalManagement.EUMRV;
using VShips.DataServices.Shared.Enumerations;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.DataServices.Shared.Enumerations.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
    /// <summary>
    /// EnvironmentalManagementNavigation Class
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement.IEnvironmentalManagementNavigation" />
    public class EnvironmentalManagementNavigation : BaseModuleNavigationService, IEnvironmentalManagementNavigation
    {
        /// <summary>
        /// The default constructor.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public EnvironmentalManagementNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Navigates to environment file attachments.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEnvironmentFileAttachments(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EnvironmentDocumentNavigationView, context, parameter);
        }

        /// <summary>
        /// Opens the environmental management landing page.
        /// </summary>
        public void OpenEnvironmentalManagementLandingPage()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.LandingPageView);
        }

        /// <summary>
        /// Navigates to the Environmental Management browse page.
        /// </summary>
        public void NavigateBrowsePage()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.BrowsePageStartView);
        }

		 public void NavigateMaps()
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.MapShapeFileView);
        }

        /// <summary>
        /// Navigates to add edit cargo waste discharge.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditCargoWasteDischarge(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCagoWasteDischargeView, context, parameter);
        }

        /// <summary>
        /// Navigates to electronic date popup.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToElectronicDatePopup(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ElectronicLogbookDateNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit failure monitoring.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditFailureMonitoring(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddFailureOfMonitoringControlView, context, parameter);
        }

        /// <summary>
        /// Navigates to add service monitoring.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddServiceMonitoring(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddServiceMonitoringControlView, context, parameter);
        }

        /// <summary>
        /// Navigates to log sign off view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToORBPartAActionsNavigationView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ORBPartAActionsNavigationView, context, parameter);
        }

		/// <summary>
		/// Navigates to garbage record book actions navigation view.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="parameter">The parameter.</param>
		public void NavigateToGarbageRecordBookActionsNavigationView(INavigationContext context, object parameter)
		{
			NavigationService.NavigateDialog(Constants.ModuleName, Constants.GarbageRecordBookActionsNavigationView, context, parameter);
		}

		/// <summary>
		/// Navigates to master verification navigation view.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="parameter">The parameter.</param>
		public void NavigateToMasterVerificationNavigationView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MasterVerificationLoginView, context, parameter);
        }


        /// <summary>
        /// Navigates to failure events list.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToFailureEventsList(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ServiceFailureEventsListView, context, parameter);
        }

        /// <summary>
        /// Navigates to add voyage weekly rob report view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddVoyageWeeklyRobReportView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddVoyageWeeklyRobReportView, context, parameter);
        }
        /// <summary>
        /// Navigates to add ballasting view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddBallastingView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddBallastingCleaningView, context, parameter);
        }
        /// <summary>
        /// Navigates to add edit event type view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="viewName">Name of the view.</param>
        public void NavigateToAddEditEventTypeView(INavigationContext context, object parameter, string viewName)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, viewName, context, parameter);
        }

		/// <summary>
		/// Navigates to edit ods gas landed item view.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="parameter">The parameter.</param>
		/// <param name="viewName">Name of the view.</param>
		public void NavigateToEditOdsGasLandedItemView(INavigationContext context, object parameter, string viewName)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, viewName, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit sludge waste discharge.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditSludgeWasteDischarge(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditSludgeWasteDischargeView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit oily waste discharge.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditOilyWasteDischarge(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditOilyWasteDischargeView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit ozone depleting substances.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditOzoneDepletingSubstances(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditOzoneDepletingSubstances, context, parameter);
        }
        /// <summary>
        /// Navigates to add ods gas supply log.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddODSGasSupplyLog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddODSGasSupplyLogView, context, parameter);
        }

        /// <summary>
        /// Navigates to add supply details ods view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddSupplyDetailsOdsView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSupplyDetailsOdsView, context, parameter);
        }

        /// <summary>
        /// Navigates the advance notification.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAdvanceNotification(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AdvNotificationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit advance notification.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditAdvanceNotification(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditAdvNotificationView, context, parameter);
        }

        /// <summary>
        /// Environmentals the management navigation browse page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="context">The context.</param>
        public void EnvironmentalManagementNavigationBrowsePage(object parameter)
        {
            string logbookTypeId = EnumsHelper.GetKeyValue(EnvironmentalManagerLogbookType.ORBPartA);
            if (parameter != null && parameter is Dictionary<string, object>)
            {
                Dictionary<string, object> _param = parameter as Dictionary<string, object>;
                if (_param.ContainsKey(NavigationParameterConstant.LogbookTypeId))
                {
                    logbookTypeId = _param[NavigationParameterConstant.LogbookTypeId] as string;
                }
            }
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.BrowsePageStartView, parameter,logbookTypeId);
        }

        /// <summary>
        /// Navigates to add garbage.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditGarbage(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditGarbageDischargeView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit garbage in bulk.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditGarbageInBulk(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddGarbageBulkDischargesView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit sewage.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditSewage(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditSewageDischargeView, context, parameter);
        }

        /// <summary>
        /// Navigates to inadequacy dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToInadequacyDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InadequacyDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit inadequacy dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditInadequacyDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditInadequacyDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to summary inadequacy dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToSummaryInadequacyDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InadequacySummaryView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit inadequacy marpol dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditInadequacyMarpolDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditInadequacyMarpolDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to crew lookup view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="crewRequest">The crew request.</param>
        /// <param name="parentID">The parent identifier.</param>
        public void NavigateToCrewLookupView(INavigationContext context, object crewRequest, string parentID)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SharedObject, crewRequest },
                { NavigationParameterConstant.ParentId, parentID }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EnviromentCrewLookupView, context, paramters);
        }

        /// <summary>
        /// Navigates to seca.
        /// </summary>
        /// <param name="parameter"></param>
        public void NavigateToSECA(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.SECAStartView, parameter);
        }

        /// <summary>
        /// Navigates to add chnage over hours.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToAddChangeOverHours(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddChangeOverHours, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to complete fuel over change details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToCompleteFuelOverChangeDetails(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompleteFuelOverChangeDetailsNavigation, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to start fuel over change details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToStartFuelOverChangeDetails(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.StartFuelOverChangeDetailsNavigation, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to seca entry.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToSECAEntry(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SECAEntryNavigation, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to seca exit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToSECAExit(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SECAExitNavigation, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to eca exit.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToECAExit(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ECAExitNavigation, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to exit change over.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ecaParameter">The eca parameter.</param>
        public void NavigateToExitChangeOver(INavigationContext context, ECAParameter ecaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExitChangeOver, context, ecaParameter);
        }

        /// <summary>
        /// Navigates to component image dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="name">The name.</param>
        public void NavigateToComponentImageDialog(INavigationContext context, string name)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ComponentImageDialog, context, name);
        }

        /// <summary>
        /// Navigates to eca region map.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="edlId">The edl identifier.</param>
        public void NavigateToECARegionMap(INavigationContext context, string edlId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ECARegionMapView, context, edlId);
        }

        /// <summary>
        /// Navigates to eca setup.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="VesselId">The vessel identifier.</param>
        public void NavigateToEcaSetup(INavigationContext context, string VesselId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ECASetupVesselMaintainerView, VesselId);
        }

        /// <summary>
        /// Navigates the vessel waste emission summary report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="fleetDescription">The fleet description.</param>
        /// <param name="menuType">Type of the menu.</param>
        /// <param name="isVesselClicked">if set to <c>true</c> [is vessel clicked].</param>
        /// <param name="isPdfFormat">if set to <c>true</c> [is PDF format].</param>
        /// <param name="selectedMenuType">Type of the selected menu.</param>
        public void NavigateVesselWasteEmissionSummaryReport(INavigationContext navigationContext, string fleetId, string fleetDescription, string menuType, bool isVesselClicked, bool isPdfFormat, UserMenuItemType selectedMenuType)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.FleetIdentifier, fleetId },
                { NavigationParameterConstant.FleetDescription, fleetDescription },
                { NavigationParameterConstant.IsVesselClickedKey, isVesselClicked },
                { NavigationParameterConstant.UserMenuItemParam, menuType },
                { NavigationParameterConstant.IsPDFFormat, isPdfFormat },
                { NavigationParameterConstant.MenuType, selectedMenuType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselWasteEmissionSummaryReportView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the ozone depleting substances report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateOzoneDepletingSubstancesReport(INavigationContext navigationContext, string vesselId)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OzoneDepletingSubstancesReportView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the vessel waste emission listing report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="fleetDescription">The fleet description.</param>
        /// <param name="menuType">Type of the menu.</param>
        public void NavigateVesselWasteEmissionListingReport(INavigationContext navigationContext, string fleetId, string fleetDescription, UserMenuItemType menuType)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.FleetIdentifier, fleetId },
                { NavigationParameterConstant.FleetDescription, fleetDescription },
                { NavigationParameterConstant.MenuType, menuType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselWasteEmissionListingReportView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the garbage waste details report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateGarbageWasteDetailsReport(INavigationContext navigationContext, string vesselId)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GarbageWasteDetailsReportView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the oily water waste discharge report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateCargoWasteDischargeReport(INavigationContext navigationContext, string vesselId)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OilRecordBookForCargoWasteReportView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the sludge waste discharge report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateSludgeWasteDischargeReport(INavigationContext navigationContext, string vesselId)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SludgeWasteDischargeReportView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the oily water waste discharge report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateOilyWaterWasteDischargeReport(INavigationContext navigationContext, string vesselId)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OilyWaterWasteDischargeRepotView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates to enviroment approve view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEnviromentApproveView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EnvironmentManagementApproveView, context, parameter);
        }

        /// <summary>
        /// Navigates to enviroment notification approve view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEnviromentNotificationApproveView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EnvironmentNotificationApproveView, context, parameter);
        }

        /// <summary>
        /// Navigates the vessel details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateVesselDetails(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselDetailsDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to environment manager landing page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEnvironmentManagerLandingPage(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.LandingPageView, parameter);
        }

		/// <summary>
		/// Navigates to logbook setup view.
		/// </summary>
		/// <param name="parameter">The parameter.</param>
		public void NavigateToLogbookSetupView(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.LogbookSetupView, parameter);
        }

        /// <summary>
        /// Navigates to download environment logbook report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToDownloadEnvironmentLogbookReport(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DownloadEnvironmentLogbookReportView, context, parameter);
        }

        /// <summary>
        /// Navigates to emission guidance document view.
        /// </summary>
        /// <param name="context">
        /// The context.
        /// </param>
        public void NavigateToEmissionGuidanceDocumentView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EmissionGuidanceDocumentNavigationView, context);
        }

        #region EUMRV

        /// <summary>
        /// Navigates the add edit fuel tank view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity of type <see cref="EumrvNavParameter" />.</param>
        public void NavigateAddEditFuelTankView(INavigationContext navigationContext, EumrvNavParameter entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditFuelTankNavigationView, navigationContext, entity);
        }

        /// <summary>
        /// Navigates the add edit fuel type emission factor navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter of type <see cref="EumrvNavParameter"/>.</param>
        public void NavigateAddEditFuelTypeEmissionFactorNavigationView(INavigationContext context, EumrvNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditFuelTypeEmissionFactorNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the monitoring plan view.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateMonitoringPlanView(string vesselId)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.MonitoringPlanNavigationView, vesselId);
        }

        /// <summary>
        /// Navigates to add eumrv navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEumrvNavigationView(INavigationContext context, EumrvNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEumrvDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates the add edit eumrv details.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateAddEditEumrvDetails(string vesselId, string vesselName)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.VesselName, vesselName }
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AddEditEumrvNavigationView, parameters);
        }

        /// <summary>
        /// Navigates to generate voyage navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToGenerateVoyageNavigationView(INavigationContext context, EumrvNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GenerateVoyageNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to voyage details navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToVoyageDetailsNavigationView(INavigationContext context, EumrvNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VoyageDetailsNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to eumrv edit comments navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEumrvEditCommentsNavigationView(INavigationContext context, EumrvNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EUMRVEditCommentsNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit measuring equipment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        /// <param name="isNewRecord">if set to <c>true</c> [is new record].</param>
        /// <param name="equipment">The equipment.</param>
        public void NavigateToAddEditMeasuringEquipment(INavigationContext navigationContext, string vesselId, bool isEdit, bool isNewRecord, MeasuringEquipment equipment)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.IsInEditMode, isEdit},
                {NavigationParameterConstant.IsNew, isNewRecord},
                { NavigationParameterConstant.EquipmentDetails, equipment}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditMeasuringEquipmentView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the landing pagegenerate XML.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselIds">The vessel ids.</param>
        public void NavigateLandingPagegenerateXML(INavigationContext navigationContext, string vesselIds)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.VesselId, vesselIds}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExportXMLLandingPageView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add edit emission source details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        /// <param name="isNewRecord">if set to <c>true</c> [is new record].</param>
        /// <param name="emissionSource">The emission source.</param>
        public void NavigateToAddEditEmissionSourceDetails(INavigationContext navigationContext, string vesselId, bool isEdit, bool isNewRecord, EmissionSourceDetails emissionSource)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.IsInEditMode, isEdit},
                {NavigationParameterConstant.IsNew, isNewRecord},
                { NavigationParameterConstant.EmissionSource, emissionSource}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditEmissionSourceDetailsView, navigationContext, parameter);
        }
        #endregion

        #region SEEMP
        /// <summary>
        /// Navigates to seemp.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToSEEMP(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.SEEMPStartView, parameter);
        }

        /// <summary>
        /// Navigates to seemp vessel parameter view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        public void NavigateToSEEMPVesselParameterView(INavigationContext context, string vesselId, bool isInEditMode)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.InEditMode, isInEditMode }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SEEMPVesselParameterView, context, paramters);
        }

        /// <summary>
        /// Navigates to add seemp navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddSEEMPNavigationView(INavigationContext context, SeempNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSEEMPNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to get voyage navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToGetVoyageNavigationView(INavigationContext context, SeempNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GetVoyageNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to add approve seemp navigation view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddApproveSEEMPNavigationView(SeempNavParameter parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AddApproveSEEMPNavigationView, parameter);
        }

        /// <summary>
        /// Navigates to reopen reject seemp navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToReopenRejectSEEMPNavigationView(INavigationContext context, SeempNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReopenRejectNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to voyage details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToVoyageDetails(INavigationContext navigationContext, SeempNavParameter parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VoyageDetailsView, parameter, navigationContext);
        }

        /// <summary>
        /// Navigates to add seemp navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddSEEMPWitRemark(INavigationContext context, SeempNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSeempWithRemarkView, context, parameter);
        }

        #endregion
    }
}