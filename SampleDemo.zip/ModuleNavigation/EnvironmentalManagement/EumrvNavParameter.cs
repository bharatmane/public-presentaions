﻿
using System;
namespace VShips.Framework.Common.ModuleNavigation.EnvironmentalManagement
{
    /// <summary>
    /// Eumrv Nav Parameter Class
    /// </summary>
    public class EumrvNavParameter
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }
        /// <summary>
        /// Gets or sets the performance point.
        /// </summary>
        /// <value>
        /// The performance point.
        /// </value>
        public string PerformancePoint { get; set; }

        /// <summary>
        /// Gets or sets the evh identifier.
        /// </summary>
        /// <value>
        /// The evh identifier.
        /// </value>
        public string EvhId { get; set; }

        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObj { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance can edit view.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can edit view; otherwise, <c>false</c>.
        /// </value>
        public bool CanEditView { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is anchorage.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is anchorage; otherwise, <c>false</c>.
        /// </value>
        public bool IsAnchorage { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        public object Entity { get; set; }
    }
}
