﻿namespace VShips.Framework.Common.ModuleNavigation.DefectManager
{
    /// <summary>
    /// Services and constants relating to the Defect Manager module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
