﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Common;
using VShips.Contracts.Custom.DefectManager;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Enumerations.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DefectManager
{
    /// <summary>
    /// Navigation service for Defect Manager module.
    /// </summary>
    public interface IDefectManagerNavigation
    {
		/// <summary>
		/// Navigates the add edit defect.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parentId">The parent identifier.</param>
		/// <param name="systemAreaId">The system area identifier.</param>
		/// <param name="componentId">The component identifier.</param>
		/// <param name="vesselId">The vessel identifier.</param>
		/// <param name="vesselName">Name of the vessel.</param>
		/// <param name="defectWorkOrderId">The defect work order identifier.</param>
		/// <param name="damageFormLabel">The damage form label.</param>
		/// <param name="parentComponentId">The parent component identifier.</param>
		/// <param name="isGuaranteeClaim">if set to <c>true</c> [is guarantee claim].</param>
		/// <param name="isViewMode">if set to <c>true</c> [is view mode].</param>
		/// <param name="hazOccId">The haz occ identifier.</param>
		/// <param name="associationDetail">The association detail.</param>
		/// <param name="canAddAttachmentInViewMode">if set to <c>true</c> [can add attachment in view mode].</param>
		void NavigateAddEditDefect(INavigationContext navigationContext, string parentId, string systemAreaId, string componentId, string vesselId, string vesselName, string defectWorkOrderId, string damageFormLabel, string parentComponentId, bool isGuaranteeClaim, bool isViewMode, string hazOccId = "", VesModuleAssociationDetail associationDetail=null, bool canAddAttachmentInViewMode = false);

        /// <summary>
        /// Navigates the add edit defect.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="damageFormLabel">The damage form label.</param>
        /// <param name="parentComponentId">The parent component identifier.</param>
        /// <param name="isGuaranteeClaim">if set to <c>true</c> [is guarantee claim].</param>
        /// <param name="description">The defect description.</param>
        /// <param name="rank">The rank.</param>
        /// <param name="rankId">The rank Identifier.</param>
        /// <param name="assignedTo">The assigned to identifier.</param>
        /// <param name="dateIssued">The date issued.</param>
        /// <param name="dateDue">The date due.</param>
        /// <param name="findingsId">The findings identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="hazoccId">The hazocc identifier.</param>
        void NavigateAddEditDefectFromInspection(INavigationContext navigationContext, string systemAreaId, string componentId, string vesselId, string vesselName, string defectWorkOrderId, string damageFormLabel, string parentComponentId, bool isGuaranteeClaim, string description, string rank, string rankId, string assignedTo, DateTime? dateIssued, DateTime? dateDue, string findingsId, string parentId, string hazoccId = null);

        /// <summary>
        /// Navigates the add edit defect from inspection.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddEditDefectFromInspection(INavigationContext context, AddDefectNavigationViewParameters parameters);

        /// <summary>
        /// Navigates the requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedDefect">The defect of type <see cref="DefectWorkBasketResponse" />.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateRequisition(INavigationContext navigationContext, DefectWorkBasketResponse selectedDefect, string vesselId);

        /// <summary>
        /// Navigates to the link requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requisitionParameters">The requisition parameters of type <see cref="Dictionary"/>.</param>
        void NavigateLinkRequisition(INavigationContext navigationContext, Dictionary<string, object> requisitionParameters);

        /// <summary>
        /// Navigates the check spares.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sparesParameters">The spares parameters.</param>
        void NavigateCheckSpares(INavigationContext navigationContext, Dictionary<string, string> sparesParameters);

        /// <summary>
        /// Navigates the map additional job.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentParameters">The component parameters.</param>
        void NavigateMapAdditionalJob(INavigationContext navigationContext, Dictionary<string, object> componentParameters);

        /// <summary>
        /// Navigates the add defect attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="documentType">Type of the document.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateAddDefectAttachments(INavigationContext navigationContext, string vesselId, string defectWorkOrderId, DefectWorkOrderDocumentType documentType, IEnumerable<string> fileNames, string parentId);

        /// <summary>
        /// Navigates the defect report work order.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        void NavigateDefectReportWorkOrder(string vesselId, string vesselName, string defectWorkOrderId);

        /// <summary>
        /// Navigates the add edit hse.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedHSE">The selected hse.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        /// <param name="popUpOrigin">The pop up origin.</param>
        void NavigateAddEditHSE(INavigationContext navigationContext, object selectedHSE, bool isInEditMode, string popUpOrigin);

        /// <summary>
        /// Navigates the find spare part.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="addedParts">The added parts.</param>
        void NavigateFindSparePart(INavigationContext navigationContext, string vesselId, string componentId, string parentId, object addedParts);

        /// <summary>
        /// Navigates the defect adjust stock.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedSpare">The selected spare.</param>
        void NavigateDefectAdjustStock(INavigationContext navigationContext, string vesselId, string parentId, object selectedSpare);

        /// <summary>
        /// Navigates the additional job hse assessment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="hseAssessmentList">The hse assessment list.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        void NavigateAdditionalJobHSEAssessment(INavigationContext navigationContext, string vesselId, string scheduleTaskId, string workOrderId, object hseAssessmentList, bool isInEditMode);

        /// <summary>
        /// Navigates the view defect hse assessment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="hseRisks">The hse risks.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        void NavigateViewDefectHSEAssessment(INavigationContext navigationContext, object hseRisks, string scheduleTaskId);

        /// <summary>
        /// Navigates the defect history.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="damageFormLabel">The damage form label.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="isGuaranteeClaim">if set to <c>true</c> [is guarantee claim].</param>
        void NavigateDefectHistory(INavigationContext context, string vesselId, string vesselName, string damageFormLabel, string defectWorkOrderId, bool? isGuaranteeClaim);

        /// <summary>
        /// Navigates the defect reschedule.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateDefectReschedule(INavigationContext context, string vesselId, string vesselName, string defectWorkOrderId, string parentId);

        /// <summary>
        /// Navigates the defect approve reschedule.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="rescheduleCount">The reschedule count.</param>
        /// <param name="">The .</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateDefectApproveReschedule(INavigationContext context, string vesselId, string vesselName, string defectWorkOrderId, int? rescheduleCount, string parentId);

        /// <summary>
        /// Navigates the add edit task.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="defectTaskId">The defect task identifier.</param>
        /// <param name="taskName">Name of the task.</param>
        /// <param name="estimatedCompletionDate">The estimated completion date.</param>
        void NavigateAddEditTask(INavigationContext context, string vesselId, string defectTaskId, string taskName, DateTime? estimatedCompletionDate);

        /// <summary>
        /// Navigates the defect task mapping.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="defectIds">The defect ids.</param>
        void NavigateDefectTaskMapping(INavigationContext context, string vesselId, List<string> defectIds);

        /// <summary>
        /// Navigates the add edit action.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="actionDetail">The action detail.</param>
        /// <param name="date">The date.</param>
        void NavigateAddEditAction(INavigationContext context, object actionDetail, DateTime? date);

        /// <summary>
        /// Navigates the guarantee claim report work order.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateGuaranteeClaimReportWorkOrder(INavigationContext context, string defectWorkOrderId, string vesselId);

        /// <summary>
        /// Navigates the defect reschedule history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        void NavigateDefectRescheduleHistory(INavigationContext navigationContext, string defectWorkOrderId);

        /// <summary>
        /// Navigates the guarantee claim approval.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="isAccept">if set to <c>true</c> [is accept].</param>
        void NavigateGuaranteeClaimApproval(INavigationContext navigationContext, string dwoId, bool isAccept);

        /// <summary>
        /// Navigates to defect manager.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="request">The request.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="isFromDashBoard">if set to <c>true</c> [is from dash board].</param>
        /// <param name="isFromTechnicalManager">if set to <c>true</c> [is from technical manager].</param>
        void NavigateToDefectManager(UserMenuItem menuItem, DefectWorkBasketResquest request, string defectWorkOrderId, bool isFromDashBoard = false, bool isFromTechnicalManager = false);

        /// <summary>
        /// Navigates the update defect due date.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateUpdateDefectDueDate(INavigationContext navigationContext, string vesselId, string dwoId, string parentId, string vesselName);

        /// <summary>
        /// Navigates the close defect work order.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateCloseDefectWorkOrder(INavigationContext navigationContext, string vesselId, string dwoId, string parentId);

        /// <summary>
        /// Navigates to the Landing Page
        /// </summary>
        void NavigateToLandingPage();

        /// <summary>
        /// Navigates to reject defect view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateToRejectDefectView(INavigationContext navigationContext, string dwoId, string componentId, string vesselId);
    }
}
