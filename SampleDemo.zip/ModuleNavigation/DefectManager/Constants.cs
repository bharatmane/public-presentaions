﻿namespace VShips.Framework.Common.ModuleNavigation.DefectManager
{
    /// <summary>
    /// Names of accessible views and regions related to the Defect Manager module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "DefectManager";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "DefectManagerGeometry";

        /// <summary>
        /// The module title
        /// </summary>
        public const string ModuleTitle = "Project & Defect Manager";

        /// <summary>
        /// The module title
        /// </summary>
        public const string ModuleTooltip = "Project & Defect Manager";

        //Views

        /// <summary>
        /// The landing or start view of Sales Invoicing module
        /// </summary>
        public const string StartView = "DefectManagerStartView";

        /// <summary>
        /// The add defect navigation view
        /// </summary>
        public const string AddDefectNavigationView = "AddDefectNavigationView";

        /// <summary>
        /// The defect manager requisitions view.
        /// </summary>
        public const string DefectManagerRequisitionsView = "DefectManagerRequisitionsView";

        /// <summary>
        /// The link requisition dialog view.
        /// </summary>
        public const string LinkRequisitionDialogView = "LinkRequisitionDialogView";

        /// <summary>
        /// The check spares view
        /// </summary>
        public const string CheckSparesView = "CheckSparesView";

        /// <summary>
        /// The map additional job navigation view.
        /// </summary>
        public const string MapAdditionalJobNavigationView = "MapAdditionalJobNavigationView";

        /// <summary>
        /// The defect attachments navigation view
        /// </summary>
        public const string DefectAttachmentsNavigationView = "DefectAttachmentsNavigationView";

        /// <summary>
        /// The defect report work done wizard view.
        /// </summary>
        public const string DefectReportWorkDoneWizardView = "DefectReportWorkDoneWizardView";

        /// <summary>
        /// The defect hse assessment add edit view.
        /// </summary>
        public const string DefectHseAssessmentAddEditView = "DefectHseAssessmentAddEditView";

        /// <summary>
        /// The defect find spare view
        /// </summary>
        public const string DefectFindSpareView = "DefectFindSpareView";

        /// <summary>
        /// The defect inventory adjust view
        /// </summary>
        public const string DefectInventoryAdjustView = "DefectInventoryAdjustView";

        /// <summary>
        /// The defect additional job hse assessment navigation view.
        /// </summary>
        public const string DefectAdditionalJobHseAssessmentNavigationView = "DefectAdditionalJobHseAssessmentNavigationView";

        /// <summary>
        /// The defect hse assessment view.
        /// </summary>
        public const string DefectHSEAssessmentView = "DefectHSEAssessmentView";

        /// <summary>
        /// The defect history navigation view.
        /// </summary>
        public const string DefectHistoryNavigationView = "DefectHistoryNavigationView";

        /// <summary>
        /// The defect reschedule work order navigation view.
        /// </summary>
        public const string DefectRescheduleWorkOrderNavigationView = "DefectRescheduleWorkOrderNavigationView";

        /// <summary>
        /// The defect approve reschedule work order navigation view.
        /// </summary>
        public const string DefectApproveRescheduleWorkOrderNavigationView = "DefectApproveRescheduleWorkOrderNavigationView";

        /// <summary>
        /// The add task navigation view.
        /// </summary>
        public const string AddTaskNavigationView = "AddTaskNavigationView";

        /// <summary>
        /// The move to task ListView.
        /// </summary>
        public const string MoveToTaskListView = "MoveToTaskListView";

        /// <summary>
        /// The action add edit navigation view
        /// </summary>
        public const string ActionAddEditNavigationView = "ActionAddEditNavigationView";

        /// <summary>
        /// The guarantee claim report work done view
        /// </summary>
        public const string GuaranteeClaimReportWorkDoneView = "GuaranteeClaimReportWorkDoneView";

        /// <summary>
        /// The defect reschedule history view
        /// </summary>
        public const string DefectRescheduleHistoryView = "DefectRescheduleHistoryView";

        /// <summary>
        /// The guarantee claim approval detail view
        /// </summary>
        public const string GuaranteeClaimApprovalDetailView = "GuaranteeClaimApprovalDetailView";

        /// <summary>
        /// The defect work basket view
        /// </summary>
        public const string DefectWorkBasketView = "DefectWorkBasketView";

        /// <summary>
        /// The repair job details view only view
        /// </summary>
        public const string RepairJobDetailsViewOnlyView = "RepairJobDetailsViewOnlyView";

        /// <summary>
        /// The update defect due date view
        /// </summary>
        public const string UpdateDefectDueDateView = "UpdateDefectDueDateView";

        /// <summary>
        /// The close defect work order dialog view
        /// </summary>
        public const string CloseDefectWorkOrderDialogView = "CloseDefectWorkOrderDialogView";

        /// <summary>
        /// The reject defect view
        /// </summary>
        public const string RejectDefectView = "RejectDefectView";
    }
}
