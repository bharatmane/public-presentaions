﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Contracts.Custom.Common;
using VShips.Contracts.Custom.DefectManager;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Enumerations.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DefectManager
{
    /// <summary>
    /// Default implementation of the <see cref="IDefectManagerNavigation"/> service.
    /// </summary>
    public class DefectManagerNavigation : BaseModuleNavigationService, IDefectManagerNavigation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DefectManagerNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public DefectManagerNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

		#endregion

		#region Methods

		/// <summary>
		/// Navigates the add edit defect.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parentId">The parent identifier.</param>
		/// <param name="systemAreaId">The system area identifier.</param>
		/// <param name="componentId">The component identifier.</param>
		/// <param name="vesselId">The vessel identifier.</param>
		/// <param name="vesselName">Name of the vessel.</param>
		/// <param name="defectWorkOrderId">The defect work order identifier.</param>
		/// <param name="damageFormLabel">The damage form label.</param>
		/// <param name="parentComponentId">The parent component identifier.</param>
		/// <param name="isGuaranteeClaim">if set to <c>true</c> [is guarantee claim].</param>
		/// <param name="isViewMode">if set to <c>true</c> [is view mode].</param>
		/// <param name="hazOccId">The haz occ identifier.</param>
		/// <param name="associationDetail">The association detail.</param>
		/// <param name="canAddAttachmentInViewMode">if set to <c>true</c> [can add attachment in view mode].</param>
		public void NavigateAddEditDefect(INavigationContext navigationContext, string parentId, string systemAreaId, string componentId, string vesselId, string vesselName, string defectWorkOrderId, string damageFormLabel, string parentComponentId, bool isGuaranteeClaim, bool isViewMode, string hazOccId = "",VesModuleAssociationDetail associationDetail = null, bool canAddAttachmentInViewMode = false)
        {
            Dictionary<string, object> param = new Dictionary<string, object>()
            {
                {NavigationParameterConstant.VesselId,vesselId},
                { NavigationParameterConstant.ParentId, parentId},
                {NavigationParameterConstant.VesselName,vesselName},
                {NavigationParameterConstant.SystemAreaKey,systemAreaId},
                {NavigationParameterConstant.ComponentId,componentId},
                {NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId},
                {NavigationParameterConstant.DamageFormLabel,damageFormLabel},
                {NavigationParameterConstant.ParentComponentIdKey,parentComponentId},
                {NavigationParameterConstant.IsGuaranteeClaim,isGuaranteeClaim},
                {NavigationParameterConstant.IsViewMode,isViewMode},
                {NavigationParameterConstant.VesModuleAssociation,associationDetail},
                {NavigationParameterConstant.HazOccId,hazOccId},
                {NavigationParameterConstant.CanAddAttachmentInViewMode,canAddAttachmentInViewMode},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddDefectNavigationView, navigationContext, param);
        }

        /// <summary>
        /// Navigates the add edit defect.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="damageFormLabel">The damage form label.</param>
        /// <param name="parentComponentId">The parent component identifier.</param>
        /// <param name="isGuaranteeClaim">if set to <c>true</c> [is guarantee claim].</param>
        /// <param name="description">The defect description.</param>
        /// <param name="rank">The rank.</param>
        /// <param name="rankId">The rank Identifier.</param>
        /// <param name="assignedTo">The assigned to identifier.</param>
        /// <param name="dateIssued">The date issued.</param>
        /// <param name="dateDue">The date due.</param>
        /// <param name="findingsId">The findings identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="hazoccId"></param>
        public void NavigateAddEditDefectFromInspection(INavigationContext navigationContext, string systemAreaId, string componentId, string vesselId, string vesselName, string defectWorkOrderId, string damageFormLabel, string parentComponentId, bool isGuaranteeClaim, string description, string rank, string rankId, string assignedTo, DateTime? dateIssued, DateTime? dateDue, string findingsId, string parentId, string hazoccId = null)
        {
            var parameters = new AddDefectNavigationViewParameters(systemAreaId, componentId, vesselId, vesselName, defectWorkOrderId, damageFormLabel, parentComponentId, isGuaranteeClaim, description, rank, rankId, assignedTo, dateIssued, dateDue, findingsId, parentId);
            parameters.HazoccId = hazoccId;
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddDefectNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add edit defect from inspection.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddEditDefectFromInspection(INavigationContext context, AddDefectNavigationViewParameters parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddDefectNavigationView, context, parameters);
        }

        /// <summary>
        /// Navigates the requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedDefect">The defect of type <see cref="DefectWorkBasketResponse" />.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateRequisition(INavigationContext navigationContext, DefectWorkBasketResponse selectedDefect, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                {NavigationParameterConstant.VesselId,vesselId},
                 {NavigationParameterConstant.SelectedDefect,selectedDefect}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectManagerRequisitionsView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to the link requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requisitionParameters">The requisition parameters of type <see cref="Dictionary" />.</param>
        public void NavigateLinkRequisition(INavigationContext navigationContext, Dictionary<string, object> requisitionParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkRequisitionDialogView, navigationContext, requisitionParameters);
        }

        /// <summary>
        /// Navigates the check spares.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sparesParameters">The spares parameters.</param>
        public void NavigateCheckSpares(INavigationContext navigationContext, Dictionary<string, string> sparesParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CheckSparesView, navigationContext, sparesParameters);
        }

        /// <summary>
        /// Navigates the map additional job.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentParameters">The component parameters.</param>
        public void NavigateMapAdditionalJob(INavigationContext navigationContext, Dictionary<string, object> componentParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapAdditionalJobNavigationView, navigationContext, componentParameters);
        }

        /// <summary>
        /// Navigates the add defect attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="documentType">Type of the document.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateAddDefectAttachments(INavigationContext navigationContext, string vesselId, string defectWorkOrderId, DefectWorkOrderDocumentType documentType, IEnumerable<string> fileNames, string parentId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                {NavigationParameterConstant.VesselId, vesselId},
                {NavigationParameterConstant.DefectWorkOrderId, defectWorkOrderId},
                {NavigationParameterConstant.FilesToUpload, fileNames.ToList()},
                {NavigationParameterConstant.DocumentType, documentType},
                {NavigationParameterConstant.ParentId, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectAttachmentsNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the defect report work order.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        public void NavigateDefectReportWorkOrder(string vesselId, string vesselName, string defectWorkOrderId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.VesselName,vesselName},
                {NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.DefectReportWorkDoneWizardView, parameter);
        }

        /// <summary>
        /// Navigates the add edit hse.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedHSE">The selected hse.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        /// <param name="popUpOrigin">The pop up origin.</param>
        public void NavigateAddEditHSE(INavigationContext navigationContext, object selectedHSE, bool isInEditMode, string popUpOrigin)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedHSE, selectedHSE },
                { NavigationParameterConstant.IsInEditMode, isInEditMode },
                { NavigationParameterConstant.PopUpOrigin, popUpOrigin },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectHseAssessmentAddEditView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the find spare part.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="addedParts">The added parts.</param>
        public void NavigateFindSparePart(INavigationContext navigationContext, string vesselId, string componentId, string parentId, object addedParts)
        {
            Dictionary<string, object> addPartParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ComponentId, componentId } ,
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.PartListKey, addedParts }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectFindSpareView, navigationContext, addPartParameter);
        }

        /// <summary>
        /// Navigates the defect adjust stock.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedSpare">The selected spare.</param>
        public void NavigateDefectAdjustStock(INavigationContext navigationContext, string vesselId, string parentId, object selectedSpare)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.SelectedSpare, selectedSpare},
                { NavigationParameterConstant.ParentId, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectInventoryAdjustView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the additional job hse assessment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="hseAssessmentList">The hse assessment list.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        public void NavigateAdditionalJobHSEAssessment(INavigationContext navigationContext, string vesselId, string scheduleTaskId, string workOrderId, object hseAssessmentList, bool isInEditMode)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.ScheduleTaskId, scheduleTaskId},
                { NavigationParameterConstant.WorkOrderId, workOrderId},
                { NavigationParameterConstant.HseAssessmentKey, hseAssessmentList},
                { NavigationParameterConstant.IsEditMode, isInEditMode}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectAdditionalJobHseAssessmentNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the view defect hse assessment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="hseRisks">The hse risks.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        public void NavigateViewDefectHSEAssessment(INavigationContext navigationContext, object hseRisks, string scheduleTaskId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.HseAssessmentKey, hseRisks },
                {NavigationParameterConstant.ScheduleTaskId, scheduleTaskId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectHSEAssessmentView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the defect history.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="damageFormLabel">The damage form label.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="isGuaranteeClaim">if set to <c>true</c> [is guarantee claim].</param>
        public void NavigateDefectHistory(INavigationContext context, string vesselId, string vesselName, string damageFormLabel, string defectWorkOrderId, bool? isGuaranteeClaim)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.VesselName,vesselName},
                {NavigationParameterConstant.DamageFormLabel,damageFormLabel},
                {NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId},
                {NavigationParameterConstant.IsGuaranteeClaim,isGuaranteeClaim}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectHistoryNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the defect reschedule.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateDefectReschedule(INavigationContext context, string vesselId, string vesselName, string defectWorkOrderId, string parentId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.VesselName,vesselName},
                {NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId},
                {NavigationParameterConstant.ParentId,parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectRescheduleWorkOrderNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the defect approve reschedule.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="rescheduleCount">The reschedule count.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateDefectApproveReschedule(INavigationContext context, string vesselId, string vesselName, string defectWorkOrderId, int? rescheduleCount, string parentId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.VesselName,vesselName},
                {NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId},
                {NavigationParameterConstant.RescheduleCount,rescheduleCount},
                {NavigationParameterConstant.ParentId,parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectApproveRescheduleWorkOrderNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the add edit task.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="defectTaskId">The defect task identifier.</param>
        /// <param name="taskName">Name of the task.</param>
        /// <param name="estimatedCompletionDate">The estimated completion date.</param>
        public void NavigateAddEditTask(INavigationContext context, string vesselId, string defectTaskId, string taskName, DateTime? estimatedCompletionDate)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.DefectTaskId,defectTaskId},
                {NavigationParameterConstant.TaskName,taskName},
                {NavigationParameterConstant.EstimatedCompletionDate,estimatedCompletionDate}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddTaskNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the defect task mapping.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="defectIds">The defect ids.</param>
        public void NavigateDefectTaskMapping(INavigationContext context, string vesselId, List<string> defectIds)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.DefectIds,defectIds}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MoveToTaskListView, context, parameter);
        }

        /// <summary>
        /// Navigates the add edit action.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="actionDetail">The action detail.</param>
        /// <param name="date">The date.</param>
        public void NavigateAddEditAction(INavigationContext context, object actionDetail, DateTime? date)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ActionDetail, actionDetail },
                { NavigationParameterConstant.MaximumActionDate, date}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ActionAddEditNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the guarantee claim report work order.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateGuaranteeClaimReportWorkOrder(INavigationContext context, string defectWorkOrderId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId},
                {NavigationParameterConstant.VesselId,vesselId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GuaranteeClaimReportWorkDoneView, context, parameter);
        }

        /// <summary>
        /// Navigates the defect reschedule history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        public void NavigateDefectRescheduleHistory(INavigationContext navigationContext, string defectWorkOrderId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectRescheduleHistoryView, navigationContext, defectWorkOrderId);
        }

        /// <summary>
        /// Navigates the guarantee claim approval.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="isAccept">if set to <c>true</c> [is accept].</param>
        public void NavigateGuaranteeClaimApproval(INavigationContext navigationContext, string dwoId, bool isAccept)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.DefectWorkOrderId,dwoId},
                {NavigationParameterConstant.IsGuaranteeClaimAccept,isAccept},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GuaranteeClaimApprovalDetailView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to defect manager.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="request">The request.</param>
        /// <param name="defectWorkOrderId">The defect work order identifier.</param>
        /// <param name="isFromDashBoard">if set to <c>true</c> [is from dash board].</param>
        /// <param name="isFromTechnicalManager">if set to <c>true</c> [is from technical manager].</param>
        public void NavigateToDefectManager(UserMenuItem menuItem, DefectWorkBasketResquest request, string defectWorkOrderId, bool isFromDashBoard = false, bool isFromTechnicalManager = false)
        {
            var defectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem},
                { NavigationParameterConstant.WorkBasketResquest,request},
                { NavigationParameterConstant.DefectWorkOrderId,defectWorkOrderId },
                { NavigationParameterConstant.IsFromVesselDashboard, isFromDashBoard},
                { NavigationParameterConstant.IsFromTechnicalManager, isFromTechnicalManager}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.DefectWorkBasketView, defectParameters);
        }

        /// <summary>
        /// Navigates the update defect due date.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateUpdateDefectDueDate(INavigationContext navigationContext, string vesselId, string dwoId, string parentId, string vesselName)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.DefectWorkOrderId,dwoId},
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.ParentId,parentId},
                {NavigationParameterConstant.VesselName,vesselName}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateDefectDueDateView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the close defect work order.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateCloseDefectWorkOrder(INavigationContext navigationContext, string vesselId, string dwoId, string parentId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.DefectWorkOrderId, dwoId},
                {NavigationParameterConstant.VesselId,vesselId},
                {NavigationParameterConstant.ParentId,parentId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CloseDefectWorkOrderDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to the Landing Page
        /// </summary>
        public void NavigateToLandingPage()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Navigates to reject defect view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="dwoId">The dwo identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateToRejectDefectView(INavigationContext navigationContext, string dwoId, string componentId, string vesselId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.DefectWorkOrderId,dwoId},
                {NavigationParameterConstant.ComponentId,componentId},
                {NavigationParameterConstant.VesselId,vesselId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RejectDefectView, navigationContext, parameter);
        }
        #endregion
    }
}