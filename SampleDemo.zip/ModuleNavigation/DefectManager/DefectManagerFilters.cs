﻿using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.ModuleNavigation.DefectManager
{
    /// <summary>
    /// Left side tree filter for Defect Manager
    /// </summary>
    public class DefectManagerFilters
    {
        #region Contructor
        /// <summary>
        /// Initializes a new instance of the <see cref="DefectManagerFilters"/> class.
        /// </summary>
        public DefectManagerFilters()
        { }
        #endregion
    }
}
