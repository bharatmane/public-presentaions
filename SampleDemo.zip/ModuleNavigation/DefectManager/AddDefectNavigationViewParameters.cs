﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.DefectManager
{
    public class AddDefectNavigationViewParameters : BaseViewModel
    {
        private string _vesselId;
        public string VesselId
        {
            get { return _vesselId; }
        }

        private string _vesselName;
        public string VesselName
        {
            get { return _vesselName; }
        }

        private string _systemAreaId;
        public string SystemAreaId
        {
            get { return _systemAreaId; }
        }

        private string _componentId;
        public string ComponentId
        {
            get { return _componentId; }
        }

        private string _defectWorkOrderId;
        public string DefectWorkOrderId
        {
            get { return _defectWorkOrderId; }
        }

        private string _damageFormLabel;
        public string DamageFormLabel
        {
            get { return _damageFormLabel; }
        }

        private string _parentComponentIdKey;
        public string ParentComponentIdKey
        {
            get { return _parentComponentIdKey; }
        }

        private bool _isGuaranteeClaim;
        public bool IsGuaranteeClaim
        {
            get { return _isGuaranteeClaim; }
        }


        private string _description;
        public string Description
        {
            get { return _description; }
        }

        private string _rank;
        public string Rank
        {
            get { return _rank; }
        }

        private string _rankId;
        public string RankId
        {
            get { return _rankId; }
            set { _rankId = value; }
        }

        private string _assignedTo;
        public string AssignedTo
        {
            get { return _assignedTo; }
        }

        private DateTime? _dateIssued;
        public DateTime? DateIssued
        {
            get { return _dateIssued; }
        }

        private DateTime? _dateDue;
        public DateTime? DateDue
        {
            get { return _dateDue; }
        }

        /// <summary>
        /// The findings identifier
        /// </summary>
        private string _findingsId;

        /// <summary>
        /// Gets the findings identifier.
        /// </summary>
        /// <value>
        /// The findings identifier.
        /// </value>
        public string FindingsId
        {
            get { return _findingsId; }
        }

        /// <summary>
        /// The parent identifier
        /// </summary>
        private string _parentId;

        /// <summary>
        /// Gets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId
        {
            get { return _parentId; }
        }

        private bool _isFromInspection;

        public bool IsFromInspection
        {
            get { return _isFromInspection; }
        }

        /// <summary>
        /// The hazocc identifier.
        /// </summary>
        private string _hazoccId;

        /// <summary>
        /// Gets or sets the hazocc identifier.
        /// </summary>
        /// <value>
        /// The hazocc identifier.
        /// </value>
        public string HazoccId
        {
            get { return _hazoccId; }
            set { Set(() => HazoccId, ref _hazoccId, value); }
        }


        public AddDefectNavigationViewParameters()
        {

        }

        public AddDefectNavigationViewParameters(string systemAreaId, string componentId, string vesselId, string vesselName, string defectWorkOrderId, string damageFormLabel, string parentComponentId, bool isGuaranteeClaim)
        {
            _systemAreaId = systemAreaId;
            _componentId = componentId;
            _vesselId = vesselId;
            _vesselName = vesselName;
            _defectWorkOrderId = defectWorkOrderId;
            _damageFormLabel = damageFormLabel;
            _parentComponentIdKey = parentComponentId;
            _isGuaranteeClaim = isGuaranteeClaim;
        }

        public AddDefectNavigationViewParameters(string systemAreaId, string componentId, string vesselId, string vesselName, string defectWorkOrderId, string damageFormLabel, string parentComponentId, bool isGuaranteeClaim, string description, string rank, string rankId, string assignedTo, DateTime? dateIssued, DateTime? dateDue,string findingsId,string parentId)
        {
            _systemAreaId = systemAreaId;
            _componentId = componentId;
            _vesselId = vesselId;
            _vesselName = vesselName;
            _defectWorkOrderId = defectWorkOrderId;
            _damageFormLabel = damageFormLabel;
            _parentComponentIdKey = parentComponentId;
            _isGuaranteeClaim = isGuaranteeClaim;
            _findingsId = findingsId;
            _description = description;
            _rank = rank;
            _rankId = rankId;
            _assignedTo = assignedTo;
            _dateIssued = dateIssued;
            _dateDue = dateDue;
            _parentId = parentId;
        }

        /// <summary>
        /// Sets from inspection dialog.
        /// </summary>
        public void SetFromInspectionDialog()
        {
            _isFromInspection = true;
        }
    }
}
