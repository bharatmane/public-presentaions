﻿namespace VShips.Framework.Common.ModuleNavigation.HotelDefectManager
{
    /// <summary>
    /// HotelDefectManagerFilters class
    /// </summary>
    public class HotelDefectManagerFilters
    {
        #region Contructor
        /// <summary>
        /// Initializes a new instance of the <see cref="HotelDefectManagerFilters"/> class.
        /// </summary>
        public HotelDefectManagerFilters()
        { }
        #endregion
    }
}
