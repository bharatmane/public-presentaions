﻿namespace VShips.Framework.Common.ModuleNavigation.HotelDefectManager
{
    /// <summary>
    /// Services and constants relating to the Hotel Defect Manager module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}