﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.HotelDefectManager
{
    /// <summary>
    /// This is the Start Parameter for the Hotel Defect Manager Module.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class HotelDefectManagerStartParameter : BaseViewModel
    {
        #region Action

        /// <summary>
        /// The raise filter changed
        /// </summary>
        public Action RaiseFilterChanged;

        /// <summary>
        /// The raise vessel changed
        /// </summary>
        public Action RaiseVesselChanged;
        #endregion
        
        #region Properties
      
        /// <summary>
        /// The start date
        /// </summary>
        private DateTime? _startDate;

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime? StartDate
        {
            get { return _startDate; }
            set
            {
                if (Set(() => StartDate, ref _startDate, value))
                {

                    if (value != null)
                    {
                        if (value > EndDate)
                        {
                            _endDate = value;
                            RaisePropertyChanged(() => EndDate);
                        }
                    }

                    if (RaiseFilterChanged != null)
                    {
                        RaiseFilterChanged();
                    }
                }
            }
        }

        /// <summary>
        /// The end date
        /// </summary>
        private DateTime? _endDate;

        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>
        public DateTime? EndDate
        {
            get { return _endDate; }
            set
            {
                if (Set(() => EndDate, ref _endDate, value))
                {

                    if (value != null)
                    {
                        if (value < StartDate)
                        {
                            _startDate = value;
                            RaisePropertyChanged(() => StartDate);
                        }
                    }

                    if (RaiseFilterChanged != null)
                    {
                        RaiseFilterChanged();
                    }
                }
            }
        }

        /// <summary>
        /// The menu item
        /// </summary>
        private UserMenuItem _menuItem;

        /// <summary>
        /// Gets or sets the menu item.
        /// </summary>
        /// <value>
        /// The menu item.
        /// </value>
        public UserMenuItem MenuItem
        {
            get { return _menuItem; }
            set
            {
                if (Set(() => MenuItem, ref _menuItem, value))
                {
                    if (RaiseVesselChanged != null)
                    {
                        RaiseVesselChanged();
                    }
                }
            }
        }

        /// <summary>
        /// The filter
        /// </summary>
        private HotelDefectManagerFilters _filter;

        /// <summary>
        /// Gets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        public HotelDefectManagerFilters Filter
        {
            get { return _filter; }
        }

        /// <summary>
        /// The show due
        /// </summary>
        private bool _showDue;

        /// <summary>
        /// Gets or sets a value indicating whether [show due].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show due]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowDue
        {
            get { return _showDue; }
            set { Set(() => ShowDue, ref _showDue, value); }
        }

        /// <summary>
        /// The show overdue
        /// </summary>
        private bool _showOverdue;

        /// <summary>
        /// Gets or sets a value indicating whether [show overdue].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show overdue]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowOverdue
        {
            get { return _showOverdue; }
            set { Set(() => ShowOverdue, ref _showOverdue, value); }
        }

        /// <summary>
        /// The assigned to me
        /// </summary>
        private bool _assignedToMe;

        /// <summary>
        /// Gets or sets a value indicating whether [assigned to me].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [assigned to me]; otherwise, <c>false</c>.
        /// </value>
        public bool AssignedToMe
        {
            get { return _assignedToMe; }
            set { Set(() => AssignedToMe, ref _assignedToMe, value); }
        }

        /// <summary>
        /// The unassigned
        /// </summary>
        private bool _unassigned;

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="HotelDefectManagerStartParameter"/> is unassigned.
        /// </summary>
        /// <value>
        ///   <c>true</c> if unassigned; otherwise, <c>false</c>.
        /// </value>
        public bool Unassigned
        {
            get { return _unassigned; }
            set { Set(() => Unassigned, ref _unassigned, value); }
        }

        /// <summary>
        /// The reported by me
        /// </summary>
        private bool _reportedByMe;

        /// <summary>
        /// Gets or sets a value indicating whether [reported by me].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [reported by me]; otherwise, <c>false</c>.
        /// </value>
        public bool ReportedByMe
        {
            get { return _reportedByMe; }
            set { Set(() => ReportedByMe, ref _reportedByMe, value); }
        }


        /// <summary>
        /// The addedd in damage form.
        /// </summary>
        private bool _addeddInDamageForm;

        /// <summary>
        /// Gets or sets a value indicating whether [addedd in damage form].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [addedd in damage form]; otherwise, <c>false</c>.
        /// </value>
        public bool AddeddInDamageForm
        {
            get { return _addeddInDamageForm; }
            set { Set(() => AddeddInDamageForm, ref _addeddInDamageForm, value); }
        }

        /// <summary>
        /// The is critical.
        /// </summary>
        private bool _isCritical;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is critical.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is critical; otherwise, <c>false</c>.
        /// </value>
        public bool IsCritical
        {
            get { return _isCritical; }
            set { Set(() => IsCritical, ref _isCritical, value); }
        }

        /// <summary>
        /// The is temporary fix
        /// </summary>
        private bool _isTemporaryFix;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is temporary fix.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is temporary fix; otherwise, <c>false</c>.
        /// </value>
        public bool IsTemporaryFix
        {
            get { return _isTemporaryFix; }
            set { Set(() => IsTemporaryFix, ref _isTemporaryFix, value); }
        }


        /// <summary>
        /// The is guarantee claim
        /// </summary>
        private bool _isGuaranteeClaim;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is guarantee claim.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is guarantee claim; otherwise, <c>false</c>.
        /// </value>
        public bool IsGuaranteeClaim
        {
            get { return _isGuaranteeClaim; }
            set { Set(() => IsGuaranteeClaim, ref _isGuaranteeClaim, value); }
        }

        /// <summary>
        /// The is off hire
        /// </summary>
        private bool _isOffHire;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is off hire.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is off hire; otherwise, <c>false</c>.
        /// </value>
        public bool IsOffHire
        {
            get { return _isOffHire; }
            set { Set(() => IsOffHire, ref _isOffHire, value); }
        }

        /// <summary>
        /// The damage form label
        /// </summary>
        private string _damageFormLabel;

        /// <summary>
        /// Gets or sets the damage form label.
        /// </summary>
        /// <value>
        /// The damage form label.
        /// </value>
        public string DamageFormLabel
        {
            get { return _damageFormLabel; }
            set { Set(() => DamageFormLabel, ref _damageFormLabel, value); }
        }

        /// <summary>
        /// The defect statuses
        /// </summary>
        private List<string> _defectStatuses;

        /// <summary>
        /// Gets or sets the defect statuses.
        /// </summary>
        /// <value>
        /// The defect statuses.
        /// </value>
        public List<string> DefectStatuses
        {
            get { return _defectStatuses; }
            set { Set(() => DefectStatuses, ref _defectStatuses, value); }
        }

        /// <summary>
        /// The defect categories
        /// </summary>
        private List<string> _defectCategories;

        /// <summary>
        /// Gets or sets the defect categories.
        /// </summary>
        /// <value>
        /// The defect categories.
        /// </value>
        public List<string> DefectCategories
        {
            get { return _defectCategories; }
            set { Set(() => DefectCategories, ref _defectCategories, value); }
        }

        /// <summary>
        /// The defect system area ids
        /// </summary>
        private List<string> _defectSystemAreaIds;

        /// <summary>
        /// Gets or sets the defect system area ids.
        /// </summary>
        /// <value>
        /// The defect system area ids.
        /// </value>
        public List<string> DefectSystemAreaIds
        {
            get { return _defectSystemAreaIds; }
            set { Set(() => DefectSystemAreaIds, ref _defectSystemAreaIds, value); }
        }

        /// <summary>
        /// The show all defects
        /// </summary>
        private bool _showAllDefects;

        /// <summary>
        /// Gets or sets a value indicating whether [show all defects].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show all defects]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowAllDefects
        {
            get { return _showAllDefects; }
            set { Set(() => ShowAllDefects, ref _showAllDefects, value); }
        }

        /// <summary>
        /// The is from dashboard
        /// </summary>
        private bool _isFromDashboard;              

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from dash board.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is from dash board; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromDashBoard
        {
            get { return _isFromDashboard; }
            set { Set(() => IsFromDashBoard, ref _isFromDashboard, value); }
        }

        /// <summary>
        /// The HDW identifier
        /// </summary>
        private string _hdwId;

        /// <summary>
        /// Gets or sets the HDW identifier.
        /// </summary>
        /// <value>
        /// The HDW identifier.
        /// </value>
        public string HdwId
        {
            get { return _hdwId; }
            set { Set(() => HdwId, ref _hdwId, value); }
        }

        /// <summary>
        /// The status identifier
        /// </summary>
        private string _statusId;

        /// <summary>
        /// Gets or sets the status identifier.
        /// </summary>
        /// <value>
        /// The status identifier.
        /// </value>
        public string StatusId
        {
            get { return _statusId; }
            set { Set(() => StatusId, ref _statusId, value); }
        }

        /// <summary>
        /// The is from crew task
        /// </summary>
        private bool _isFromCrewTask;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from crew task.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from crew task; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromCrewTask
        {
            get { return _isFromCrewTask; }
            set { Set(() => IsFromCrewTask, ref _isFromCrewTask, value); }
        }

        /// <summary>
        /// The component hierarchy
        /// </summary>
        private object _componentHierarchy;

        /// <summary>
        /// Gets or sets the component hierarchy.
        /// </summary>
        /// <value>
        /// The component hierarchy.
        /// </value>
        public object ComponentHierarchy
        {
            get { return _componentHierarchy; }
            set { Set(() => ComponentHierarchy, ref _componentHierarchy, value); }
        }

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="HotelDefectManagerStartParameter"/> class.
        /// </summary>
        public HotelDefectManagerStartParameter()
        {
            if (_filter == null)
            {
                _filter = new HotelDefectManagerFilters();
            }
        }
        #endregion

        #region Methods

        /// <summary>
        /// Sets the user menu item.
        /// </summary>
        /// <param name="userMenuItem">The user menu item.</param>
        public void SetUserMenuItem(UserMenuItem userMenuItem)
        {
            _menuItem = userMenuItem;
            RaisePropertyChanged(() => MenuItem);
        }

        /// <summary>
        /// Sets the dates.
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="endDate">The end date.</param>
        public void SetDates(DateTime? startDate, DateTime? endDate)
        {
            _startDate = startDate;
            _endDate = endDate;

            RaisePropertyChanged(() => StartDate);
            RaisePropertyChanged(() => EndDate);
        }
        #endregion

        #region Cleanup

        /// <summary>
        /// Cleans up the instance resources.
        /// <para>
        /// To cleanup additional resources, override this method, clean up and then call base.Cleanup().
        /// </para>
        /// </summary>
        public override void Cleanup()
        {
            if (RaiseFilterChanged != null)
            {
                RaiseFilterChanged = null;
            }
            if (RaiseVesselChanged != null)
            {
                RaiseVesselChanged = null;
            }
            if (RaiseFilterChanged != null)
            {
                RaiseFilterChanged = null;
            }
            if (MenuItem != null)
            {
                MenuItem = null;
            }
            if (DefectStatuses != null)
            {
                DefectStatuses.Clear();
                DefectStatuses = null;
            }
            if (DefectCategories != null)
            {
                DefectCategories.Clear();
                DefectCategories = null;
            }
            if (DefectSystemAreaIds != null)
            {
                DefectSystemAreaIds.Clear();
                DefectSystemAreaIds = null;
            }
            base.Cleanup();
        }
            #endregion
    }
}
