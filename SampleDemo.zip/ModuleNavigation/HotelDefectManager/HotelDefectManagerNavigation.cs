﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.PlannedMaintenance;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.HotelDefectManager
{
    /// <summary>
    /// Navigation for Hotel Defect Manager
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.HotelDefectManager.IHotelDefectManagerNavigation" />
    public class HotelDefectManagerNavigation : BaseModuleNavigationService, IHotelDefectManagerNavigation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="HotelDefectManagerNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public HotelDefectManagerNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        #endregion

        #region Methods
        /// <summary>
        /// Navigates to hotel defect crew task view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="isFromDashboard"></param>
        public void NavigateToHotelDefectCrewTaskView(UserMenuItem menuItem, bool isFromDashboard)
        {
            var hotelDefectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem},
                { NavigationParameterConstant.IsFromVesselDashboard, isFromDashboard}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HotelDefectCrewTaskView, hotelDefectParameters);
        }

        /// <summary>
        /// Navigates to head of department view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="defect">The defect.</param>
        /// <param name="isFromDashboard">if set to <c>true</c> [is from dashboard].</param>
        public void NavigateToHeadOfDepartmentView(UserMenuItem menuItem, object defect, bool isFromDashboard)
        {
            var hotelDefectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem},
                { NavigationParameterConstant.SharedObject, defect},
                { NavigationParameterConstant.IsFromVesselDashboard, isFromDashboard}

            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HotelDefectHeadOfDepartmentView, hotelDefectParameters);
        }

        /// <summary>
        /// Navigates to hotel defect dashboard.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        public void NavigateToHotelDefectDashboard(UserMenuItem menuItem)
        {
            var hotelDefectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HotelDefectDashboardView, hotelDefectParameters);
        }

        /// <summary>
        /// Navigates to hotel defect maintenance history.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="isFromDashboard">if set to <c>true</c> [is from dashboard].</param>
        public void NavigateToHotelDefectMaintenanceHistory(UserMenuItem menuItem, bool isFromDashboard)
        {
            var hotelDefectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem},
                { NavigationParameterConstant.IsFromVesselDashboard, isFromDashboard}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HotelDefectMaintenanceHistoryView, hotelDefectParameters);
        }


        /// <summary>
        /// Navigates to component view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        public void NavigateToComponentView(UserMenuItem menuItem)
        {
            var hotelDefectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HotelDefectComponentView, hotelDefectParameters);
        }


        /// <summary>
        /// Navigates to component view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        public void NavigateToManageHierarchyView(UserMenuItem menuItem)
        {
            var hotelDefectParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.UserMenuItemParam, menuItem}
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HdmManageHierarchyStartView, hotelDefectParameters);
        }

        /// <summary>
        /// Navigates the hotel defect manager select category navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="isFromHod">if set to <c>true</c> [is from hod].</param>
        public void NavigateHotelDefectManagerSelectCategoryNavigationView(INavigationContext context, string vesselId, string parentId, bool isFromHod)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.VesselId,vesselId},
                { NavigationParameterConstant.IsFromHotelDefectHod, isFromHod},
                { NavigationParameterConstant.ParentId, parentId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HotelDefectManagerSelectCategoryNavigationView, context, parameters);
        }

        /// <summary>
        /// Navigates the standing wo dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        public void NavigateHDMStandingWODialog(INavigationContext navigationContext, UserMenuItem selectedVessel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedVessel, selectedVessel }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmStandingWorkOrderNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit hotel defect navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedComponent">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedWorkOrder">The selected work order.</param>
        /// <param name="IsReadOnly">if set to <c>true</c> [is read only].</param>
        /// <param name="IsFromReject">if set to <c>true</c> [is from reject].</param>
        public void NavigateAddEditHotelDefectNavigationView(INavigationContext context, string vesselId, object selectedComponent, string parentId, object selectedWorkOrder, bool IsReadOnly, bool IsFromReject)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.SelectedComponent, selectedComponent},
                { NavigationParameterConstant.IsViewMode, IsReadOnly},
                { NavigationParameterConstant.IsFromReject, IsFromReject},
                { NavigationParameterConstant.SelectedWorkOrder, selectedWorkOrder}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHotelDefectNavigationView, context, parameters);
        }

        /// <summary>
        /// Navigates the hotel defect reschedule.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedWO">The selected wo.</param>
        public void NavigateHotelDefectReschedule(INavigationContext context, string parentId, string vesselId, object selectedWO)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.WorkOrderRequest, selectedWO }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HotelDefectRescheduleNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the hotel defect approve reschedule.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="ptrId">The PTR identifier.</param>
        /// <param name="dueDate">The due date.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="jobIntervalTypeId">The job interval type identifier.</param>
        /// <param name="rescheduleCount">The reschedule count.</param>
        public void NavigateHotelDefectApproveReschedule(INavigationContext navigationContext, string vesselId, string workOrderId, string ptrId, DateTime? dueDate, string parentId, string jobIntervalTypeId, int? rescheduleCount)
        {
            var parameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.ParentId, parentId},
                {NavigationParameterConstant.ComponentId, ptrId},
                {NavigationParameterConstant.VesselId, vesselId},
                {NavigationParameterConstant.WorkOrderId, workOrderId},
                {NavigationParameterConstant.DueDate, dueDate},
                {NavigationParameterConstant.JobIntervalTypeId, jobIntervalTypeId},
                {NavigationParameterConstant.RescheduleCount, rescheduleCount}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HotelDefectApproveRescheduleNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the hotel defect report work done.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        public void NavigateHotelDefectReportWorkDone(INavigationContext context, string parentId, string vesselId, string componentId, string workOrderId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ComponentId, componentId },
                { NavigationParameterConstant.WorkOrderId, workOrderId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportWorkDoneNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the view wo details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="systemId">The system identifier.</param>
        /// <param name="SystemAreaPath"></param>
        public void NavigateViewWODetails(INavigationContext context, string vesselId, string systemId, string SystemAreaPath)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ChangeSystemArea, SystemAreaPath },
                { NavigationParameterConstant.SystemAreaIds, systemId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewWODetailsNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the edit report work done.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="hdwoId">The hdwo identifier.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void NavigateEditReportWorkDone(INavigationContext context, string parentId, string vesselId, string componentId, string hdwoId, bool isInViewMode = false)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ComponentId, componentId },
                { NavigationParameterConstant.WorkOrderId, hdwoId },
                { NavigationParameterConstant.IsInViewMode, isInViewMode }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditReportWorkDoneNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the edit round report work done.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="hdwId">The HDW identifier.</param>
        /// <param name="hrwId">The HRW identifier.</param>
        public void NavigateEditRoundReportWorkDone(INavigationContext context, string parentId, UserMenuItem selectedVessel, string componentId, string hdwId, string hrwId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.SelectedVessel, selectedVessel },
                { NavigationParameterConstant.ComponentId, componentId },
                { NavigationParameterConstant.WorkOrderId, hdwId },
                { NavigationParameterConstant.WorkOrderHistoryId, hrwId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HmmRoundsEditRwdNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the add edit hotel defect map spares navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="addedPartIds">The added part ids.</param>
        /// <param name="isFromScheduledTask">if set to <c>true</c> [is from scheduled task].</param>
        public void NavigateAddEditHotelDefectMapSparesNavigationView(INavigationContext navigationContext, string vesselId, string componentId, string parentId, List<string> addedPartIds, bool isFromScheduledTask = false)
        {
            var addPartParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ComponentId, componentId } ,
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.PartListKey, addedPartIds },
                { NavigationParameterConstant.IsFromScheduledTask, isFromScheduledTask }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHotelDefectMapSparesNavigationView, navigationContext, addPartParameter);
        }


        /// <summary>
        /// Navigates the add crew.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="crewItems">The crew items.</param>
        public void NavigateSelectCrewDialog(INavigationContext context, string vesselId, object crewItems)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId, vesselId},
                {NavigationParameterConstant.SelectedCrew,crewItems}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectCrewDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the assign responsibility view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="defectIds">The defect identifiers.</param>
        /// <param name="_vesselId">The vessel identifier.</param>
        public void NavigateAssignResponsibilityView(INavigationContext context, object defectIds, string _vesselId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.DefectTaskId, defectIds},
                { NavigationParameterConstant.VesselId, _vesselId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AssignResponsibilityDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the HMM change responsibility.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        public void NavigateHmmChangeResponsibility(INavigationContext navigationContext, string parentId, string vesselId, string workOrderId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
               { NavigationParameterConstant.ParentId, parentId},
               { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.WorkOrderId, workOrderId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HmmChangeResponsibilityDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add or edit component.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentNavigationId">The parent navigation identifier.</param>
        /// <param name="systemAreaId">The component category identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentComponentId">The parent component identifier.</param>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="copyComponentRequest">The copy component request.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        /// <param name="isChildSystemArea">if set to <c>true</c> [is child system area].</param>
        public void NavigateAddOrEditComponent(INavigationContext context, string parentNavigationId, string systemAreaId, string componentId, string parentComponentId, UserMenuItem menuItem, object copyComponentRequest = null, bool isInViewMode = true, bool isChildSystemArea = false)
        {
            var vesselComponent = new Dictionary<string, object>
            {
               { NavigationParameterConstant.ParentNavigationIdKey, parentNavigationId},
                { NavigationParameterConstant.UserMenuItemParam, menuItem},
                {NavigationParameterConstant.CategoryId, systemAreaId},
                { NavigationParameterConstant.ComponentId, componentId},
                {NavigationParameterConstant.ParentComponentIdKey, parentComponentId},
                {NavigationParameterConstant.CopyComponent, copyComponentRequest},
                {NavigationParameterConstant.IsInViewMode, isInViewMode },
                {NavigationParameterConstant.IsChildSystemArea, isChildSystemArea }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHotelDefectComponentNavigationView, context, vesselComponent);
        }

        /// <summary>
        /// Navigates the copy component.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedComponent">The selected component.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        public void NavigateCopyComponent(INavigationContext navigationContext, string parentId, object selectedComponent, object selectedVessel)
        {
            var vesselComponent = new Dictionary<string, object>
            {
               { NavigationParameterConstant.ParentNavigationIdKey, parentId},
                { NavigationParameterConstant.UserMenuItemParam, selectedVessel},
                {NavigationParameterConstant.SelectedVesselComponent, selectedComponent}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HotelDefectCopyComponentView, navigationContext, vesselComponent);
        }

        /// <summary>
        /// Navigates to retrieve component view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateToRetrieveComponentView(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
               { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.SelectedVessel, selectedVessel}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HotelDefectRetrieveComponentView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the component category system area tree.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="isParameterTabVisible">if set to <c>true</c> [is parameter tab visible].</param>
        /// <param name="parentComponentId">The parent component identifier.</param>
        /// <param name="isAdd">if set to <c>true</c> [is add].</param>
        /// <param name="isComponentView">if set to <c>true</c> [is component view].</param>
        /// <param name="isShowSystemAreaTree">if set to <c>true</c> [is show system area tree].</param>
        public void NavigateComponentCategorySystemAreaTree(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId, string systemAreaId, string componentId, bool isParameterTabVisible, string parentComponentId, bool isAdd, bool isComponentView = false, bool isShowSystemAreaTree = false)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedVessel, selectedVessel },
                { NavigationParameterConstant.CategoryId, systemAreaId},
                { NavigationParameterConstant.ComponentId, componentId},
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.IsParameterTabVisibleKey, isParameterTabVisible},
                { NavigationParameterConstant.IsComponentView ,isComponentView},
                { NavigationParameterConstant.ParentComponentIdKey, parentComponentId},
                { NavigationParameterConstant.IsAdd, isAdd},
                { NavigationParameterConstant.SystemAreaKey, isShowSystemAreaTree}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HotelDefectComponentCategorySystemAreaTreeView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the HDM jobs.
        /// </summary>
        /// <param name="selectedVessel">The selected vessel.</param>
        public void NavigateHdmJobs(UserMenuItem selectedVessel)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedVessel, selectedVessel }
            };

            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HdmJobsView, parameter);
        }

        /// <summary>
        /// Navigates the report work done.
        /// </summary>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="selectedVessel">The selected vessel of type <see cref="UserMenuItem" />.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        public void NavigateReportWorkDone(string parentId, string workOrderId, UserMenuItem selectedVessel, string workOrderHistoryId, bool isEdit = false)
        {
            var reportWorkDoneParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.WorkOrderId, workOrderId},
                { NavigationParameterConstant.EditReportWorkDone, isEdit},
                { NavigationParameterConstant.VesselDetail, selectedVessel},
                { NavigationParameterConstant.WorkOrderHistoryId, workOrderHistoryId}
            };

            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HotelReportWorkDoneWizardView, reportWorkDoneParameters);
        }

        /// <summary>
        /// Navigates the HDM jobs.
        /// </summary>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="selectedSystemArea">The selected system area.</param>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="createCopy">if set to <c>true</c> [create copy].</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        public void NavigateAddEditJobs(UserMenuItem selectedVessel, ComponentCategoryTreeResponse selectedSystemArea, string jobId, string parentId, bool createCopy, bool isInViewMode)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedVessel, selectedVessel },
                { NavigationParameterConstant.SystemAreaKey, selectedSystemArea },
                { NavigationParameterConstant.JobId, jobId },{ NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.CopyJobKey, createCopy },
                { NavigationParameterConstant.IsInViewMode, isInViewMode}
            };

            NavigationService.NavigateExisting(Constants.ModuleName, Constants.HdmAddEditJobNavigationView, parameter);
        }

        /// <summary>
        /// Navigates the hse assessment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedHseAssessment">The selected hse assessment.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        public void NavigateHseAssessment(INavigationContext navigationContext, string vesselId, object selectedHseAssessment, string scheduleTaskId)
        {
            Dictionary<string, object> hseRiskAssessmentParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.HseAssessmentKey, selectedHseAssessment},
                {NavigationParameterConstant.VesselId, vesselId},
                {NavigationParameterConstant.ScheduleTaskId, scheduleTaskId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HseAssessmentAddEditView, navigationContext, hseRiskAssessmentParameter);
        }

        /// <summary>
        /// Navigates the work order.
        /// </summary>
        /// <param name="workOrderDetail">The work order detail.</param>
        public void NavigateWorkOrder(object workOrderDetail)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.WorkOrderView, workOrderDetail);
        }


        /// <summary>
        /// Navigates the map component dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateMapComponentDialog(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmMapComponentDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the work history detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="jobId">The job identifier.</param>
        public void NavigateHdmHistoryWODetail(INavigationContext navigationContext, UserMenuItem selectedVessel, string workOrderId, string workOrderHistoryId, string scheduleTaskId, string componentId, string jobId)
        {
            var workHistoryDetailParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.WorkOrderId, workOrderId},
                { NavigationParameterConstant.VesselDetail, selectedVessel},
                { NavigationParameterConstant.WorkOrderHistoryId, workOrderHistoryId},
                { NavigationParameterConstant.ScheduleTaskId, scheduleTaskId},
                { NavigationParameterConstant.ComponentId, componentId},
                { NavigationParameterConstant.JobId, jobId}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmHistoryWODetailsNavigationView, navigationContext, workHistoryDetailParameters);
        }

        /// <summary>
        /// Navigates to retrieve job view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateToRetrieveJobView(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
               { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.SelectedVessel, selectedVessel}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmRetrieveJobsView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add delete reject comment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="hdwId">The HDW identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="isDeleteDefect">The is delete defect.</param>
        public void NavigateAddDeleteRejectComment(INavigationContext navigationContext, string hdwId, string parentId, bool isDeleteDefect = true)
        {
            Dictionary<string, object> addCommentParameter = new Dictionary<string, object>
            {
                {NavigationParameterConstant.DefectWorkOrderId, hdwId},
                {NavigationParameterConstant.IsDeleteDefect, isDeleteDefect},
                {NavigationParameterConstant.ParentId, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HDMAddDeleteRejectCommentView, navigationContext, addCommentParameter);
        }

        /// <summary>
        /// Navigates the counter not updated dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="componentList">The component list.</param>
        public void NavigateCommonCounterNotUpdatedDialog(INavigationContext context, List<NonUpdatedCounterComponentResponse> componentList)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonCounterNotUpdatedDialogView, context, componentList);
        }

        /// <summary>
        /// Navigates the reopen wo comment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="request">The request.</param>
        public void NavigateReopenWOComment(INavigationContext navigationContext, object request)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {NavigationParameterConstant.WorkOrderRequest, request}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HMMReopenWOView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the system area tree dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="isJobDetails">if set to <c>true</c> [is job details].</param>
        /// <param name="jobName">Name of the job.</param>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="isAddNewJob">if set to <c>true</c> [is add new job].</param>
        public void NavigateSystemAreaTreeDialog(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId, string systemAreaId, bool isJobDetails, string jobName, string jobId, bool isAddNewJob)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedVessel, selectedVessel },
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.CategoryId, systemAreaId},
                { NavigationParameterConstant.IsJobDetailsKey, isJobDetails} ,
                { NavigationParameterConstant.JobNameKey, jobName},
                { NavigationParameterConstant.JobId, jobId},
                { NavigationParameterConstant.IsAdd, isAddNewJob}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmSystemAreaTreeDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to map job dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="jobListParameter">The job list parameter.</param>
        public void NavigateToMapJobDialog(INavigationContext navigationContext, object jobListParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmMapJobsDialogView, navigationContext, jobListParameter);
        }

        /// <summary>
        /// Navigates the rounds report work order.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        public void NavigateRoundsReportWorkOrder(INavigationContext navigationContext, string parentId, string vesselId, string workOrderId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.WorkOrderId, workOrderId },
                { NavigationParameterConstant.ParentId, parentId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmRoundsReportWorkDoneView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the view rounds report work order.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        public void NavigateViewRoundsReportWorkOrder(INavigationContext navigationContext, UserMenuItem selectedVessel, string workOrderId, string workOrderHistoryId, string componentId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselDetail, selectedVessel },
                { NavigationParameterConstant.WorkOrderId, workOrderId },
                { NavigationParameterConstant.WorkOrderHistoryId, workOrderHistoryId },
                { NavigationParameterConstant.ComponentId, componentId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmViewRoundWODialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the work order job description.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="workOrderDetails">The work order details.</param>
        /// <param name="jobId">The job identifier.</param>
        public void NavigateWorkOrderJobDescription(INavigationContext navigationContext, object workOrderDetails, string jobId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.WorkOrderRequest, workOrderDetails},
                { NavigationParameterConstant.JobId, jobId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmWOJobDetailsView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the work order spare details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="workOrderDetails">The work order details.</param>
        public void NavigateWorkOrderSpareDetails(INavigationContext navigationContext, object workOrderDetails)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.WorkOrderRequest, workOrderDetails}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmSparesNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the copy description dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="jobTypeId">The job type identifier.</param>
        public void NavigateCopyDescriptionDialog(INavigationContext navigationContext, string vesselId, string parentId, string jobTypeId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.JobTypeId, jobTypeId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmCopyDescriptionDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the clone resource.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="componentList">The component list.</param>
        /// <param name="componentDetail">The component detail.</param>
        public void NavigateCloneResource(INavigationContext navigationContext, string parentId, object componentList, object componentDetail)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.ComponentListKey, componentList},
                { NavigationParameterConstant.ComponentDetailKey, componentDetail}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmCloneResourceView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the reschdule history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="getActiveLogs">if set to <c>true</c> [get active logs].</param>
        public void NavigateReschduleHistory(INavigationContext navigationContext, string workOrderId, string workOrderHistoryId, bool getActiveLogs)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                 { NavigationParameterConstant.WorkOrderId, workOrderId },
                 { NavigationParameterConstant.WorkOrderHistoryId, workOrderHistoryId },
                 { NavigationParameterConstant.GetActiveLogs, getActiveLogs }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RescheduleHistoryView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the closed work order dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateHmmCloseWorkOrderDialog(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HmmCloseWorkOrderDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the update work order description.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="description">The description.</param>
        /// <param name="isVesselDescription">if set to <c>true</c> [is vessel description].</param>
        public void NavigateUpdateWorkOrderDescription(INavigationContext navigationContext, string parentId, string jobId, string description, bool isVesselDescription)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.JobId, jobId},
                { NavigationParameterConstant.DescriptionKey, description},
                { NavigationParameterConstant.IsVesselDescription, isVesselDescription}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmUpdateWorkOrderDescriptionView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the vessel guidelines.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselGuidelines">The vessel guidelines.</param>
        public void NavigateVesselGuidelines(INavigationContext context, string parentId, string vesselGuidelines)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.VesselGuidelines, vesselGuidelines }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditVesselGuidelinesDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates the map spares dailogue.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateMapSparesDailogue(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmMapSparesDailogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to the add inventory location.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateAddInventoryLocation(INavigationContext navigationContext, string vesselId, string parentId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HdmAddInventoryLocationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the search defects dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateSearchDefectsDialog(INavigationContext navigationContext, string vesselId, string parentId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SearchDefectsDialogView, navigationContext, parameter);
        }

        #endregion
    }
}