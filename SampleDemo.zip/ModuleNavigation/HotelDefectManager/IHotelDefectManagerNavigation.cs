﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.PlannedMaintenance;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.HotelDefectManager
{
    /// <summary>
    /// Navigation interfacte for Hotel Defect Manager
    /// </summary>
    public interface IHotelDefectManagerNavigation
    {
        /// <summary>
        /// Navigates to hotel defect crew task view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="isFromDashboard">if set to <c>true</c> [is from dashboard].</param>
        void NavigateToHotelDefectCrewTaskView(UserMenuItem menuItem, bool isFromDashboard);

        /// <summary>
        /// Navigates to head of department view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="defect">The defect.</param>
        /// <param name="isFromDashboard">if set to <c>true</c> [is from dashboard].</param>
        void NavigateToHeadOfDepartmentView(UserMenuItem menuItem, object defect, bool isFromDashboard);

        /// <summary>
        /// Navigates to hotel defect dashboard.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        void NavigateToHotelDefectDashboard(UserMenuItem menuItem);

        /// <summary>
        /// Navigates to hotel defect maintenance history.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="isFromDashboard">if set to <c>true</c> [is from dashboard].</param>
        void NavigateToHotelDefectMaintenanceHistory(UserMenuItem menuItem, bool isFromDashboard);

        /// <summary>
        /// Navigates to component view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        void NavigateToComponentView(UserMenuItem menuItem);
        /// <summary>
        /// Navigates to manage hierarchy view.
        /// </summary>
        /// <param name="menuItem">The menu item.</param>
        void NavigateToManageHierarchyView(UserMenuItem menuItem);

        /// <summary>
        /// Navigates the hotel defect manager select category navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="isFromHod">if set to <c>true</c> [is from hod].</param>
        void NavigateHotelDefectManagerSelectCategoryNavigationView(INavigationContext context, string vesselId, string parentId, bool isFromHod);
        /// <summary>
        /// Navigates the HDM standing wo dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        void NavigateHDMStandingWODialog(INavigationContext navigationContext, UserMenuItem selectedVessel);

        /// <summary>
        /// Navigates the hotel defect reschedule.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedWO">The selected wo.</param>
        void NavigateHotelDefectReschedule(INavigationContext context,string parentId, string vesselId, object selectedWO);

        /// <summary>
        /// Navigates the hotel defect approve reschedule.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="ptrId">The PTR identifier.</param>
        /// <param name="dueDate">The due date.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="jobIntervalTypeId">The job interval type identifier.</param>
        /// <param name="rescheduleCount">The reschedule count.</param>
        void NavigateHotelDefectApproveReschedule(INavigationContext navigationContext,string vesselId, string workOrderId,string ptrId, DateTime? dueDate, string parentId, string jobIntervalTypeId, int? rescheduleCount);

        /// <summary>
        /// Navigates the hotel defect report work done.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        void NavigateHotelDefectReportWorkDone(INavigationContext context, string parentId, string vesselId, string componentId, string workOrderId);

        /// <summary>
        /// Navigates the view wo details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="systemId">The system identifier.</param>
        /// <param name="SystemAreaPath">The system area path.</param>
        void NavigateViewWODetails(INavigationContext context, string vesselId, string systemId, string SystemAreaPath);

        /// <summary>
        /// Navigates the add or edit component.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentNavigationId">The parent navigation identifier.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentComponentId">The parent component identifier.</param>
        /// <param name="menuItem">The menu item.</param>
        /// <param name="copyComponentRequest">The copy component request.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        /// <param name="isChildSystemArea">if set to <c>true</c> [is child system area].</param>
        void NavigateAddOrEditComponent(INavigationContext navigationContext, string parentNavigationId, string systemAreaId, string componentId, string parentComponentId, UserMenuItem menuItem, object copyComponentRequest = null, bool isInViewMode = true, bool isChildSystemArea = false);
        /// <summary>
        /// Navigates the copy component.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedComponent">The selected component.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        void NavigateCopyComponent(INavigationContext navigationContext, string parentId, object selectedComponent, object selectedVessel);
        
        /// <summary>
        /// Navigates to retrieve component view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateToRetrieveComponentView(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId);

        /// <summary>
        /// Navigates the edit report work done.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="hdwoId">The hdwo identifier.</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        void NavigateEditReportWorkDone(INavigationContext context, string parentId, string vesselId, string componentId, string hdwoId, bool isInViewMode = false);
        /// <summary>
        /// Navigates the edit round report work done.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="hdwId">The HDW identifier.</param>
        /// <param name="hrwId">The HRW identifier.</param>
        void NavigateEditRoundReportWorkDone(INavigationContext context, string parentId, UserMenuItem selectedVessel, string componentId, string hdwId,string hrwId);

        /// <summary>
        /// Navigates the add edit hotel defect navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedComponent">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedWorkOrder">The selected work order.</param>
        /// <param name="IsReadOnly">if set to <c>true</c> [is read only].</param>
        /// <param name="IsFromReject">if set to <c>true</c> [is from reject].</param>
        void NavigateAddEditHotelDefectNavigationView(INavigationContext context, string vesselId, object selectedComponent, string parentId, object selectedWorkOrder, bool IsReadOnly, bool IsFromReject);

        /// <summary>
        /// Navigates the add edit hotel defect map spares navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="addedPartIds">The added part ids.</param>
        /// <param name="isFromScheduledTask">if set to <c>true</c> [is from scheduled task].</param>
        void NavigateAddEditHotelDefectMapSparesNavigationView(INavigationContext navigationContext, string vesselId, string componentId, string parentId, List<string> addedPartIds, bool isFromScheduledTask = false);

        /// <summary>
        /// Navigates the select crew dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="crewItems">The crew items.</param>
        void NavigateSelectCrewDialog(INavigationContext context, string vesselId, object crewItems);

        /// <summary>
        /// Navigates the assign responsibility view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="defectIds">The defect identifiers.</param>
        /// <param name="_vesselId">The vessel identifier.</param>
        void NavigateAssignResponsibilityView(INavigationContext context, object defectIds, string _vesselId);

        /// <summary>
        /// Navigates the HMM change responsibility.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        void NavigateHmmChangeResponsibility(INavigationContext navigationContext, string parentId,string vesselId, string workOrderId);

        /// <summary>
        /// Navigates the component category system area tree.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="isParameterTabVisible">if set to <c>true</c> [is parameter tab visible].</param>
        /// <param name="parentComponentId">The parent component identifier.</param>
        /// <param name="isAdd">if set to <c>true</c> [is add].</param>
        /// <param name="isComponentView">if set to <c>true</c> [is component view].</param>
        /// <param name="isShowSystemAreaTree">if set to <c>true</c> [is show system area tree].</param>
        void NavigateComponentCategorySystemAreaTree(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId, string systemAreaId, string componentId, bool isParameterTabVisible, string parentComponentId, bool isAdd, bool isComponentView = false, bool isShowSystemAreaTree = false);

        /// <summary>
        /// Navigates the HDM jobs.
        /// </summary>
        /// <param name="selectedVessel">The selected vessel.</param>
        void NavigateHdmJobs(UserMenuItem selectedVessel);

        /// <summary>
        /// Navigates the report work done.
        /// </summary>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="selectedVessel">The selected vessel of type <see cref="UserMenuItem" />.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        void NavigateReportWorkDone(string parentId, string workOrderId, UserMenuItem selectedVessel, string workOrderHistoryId, bool isEdit = false);

        /// <summary>
        /// Navigates the add edit jobs.
        /// </summary>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="selectedSystemArea">The selected system area.</param>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="createCopy">if set to <c>true</c> [create copy].</param>
        /// <param name="isInViewMode">if set to <c>true</c> [is in view mode].</param>
        void NavigateAddEditJobs(UserMenuItem selectedVessel, ComponentCategoryTreeResponse selectedSystemArea, string jobId, string parentId, bool createCopy, bool isInViewMode);       

        /// <summary>
        /// Navigates the hse assessment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedHseAssessment">The selected hse assessment.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        void NavigateHseAssessment(INavigationContext navigationContext, string vesselId, object selectedHseAssessment, string scheduleTaskId);

        /// <summary>
        /// Navigates the work order.
        /// </summary>
        /// <param name="workOrderDetail">The work order detail.</param>
        void NavigateWorkOrder(object workOrderDetail);

        /// <summary>
        /// Initializes a new instance of the <see cref="IHotelDefectManagerNavigation" /> interface.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateMapComponentDialog(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the HDM history wo detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="scheduleTaskId">The schedule task identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="jobId">The job identifier.</param>
        void NavigateHdmHistoryWODetail(INavigationContext navigationContext, UserMenuItem selectedVessel, string workOrderId, string workOrderHistoryId, string scheduleTaskId, string componentId, string jobId);
        /// <summary>
        /// Navigates to retrieve job view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateToRetrieveJobView(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId);

        /// <summary>
        /// Navigates the add delete reject comment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="hdwId">The HDW identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="isDeleteDefect">if set to <c>true</c> [is delete defect].</param>
        void NavigateAddDeleteRejectComment(INavigationContext navigationContext, string hdwId, string parentId, bool isDeleteDefect = true);

        /// <summary>
        /// Navigates the common counter not updated dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="componentList">The component list.</param>
        void NavigateCommonCounterNotUpdatedDialog(INavigationContext context, List<NonUpdatedCounterComponentResponse> componentList);

        /// <summary>
        /// Navigates the reopen wo comment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="request">The request.</param>
        void NavigateReopenWOComment(INavigationContext navigationContext, object request);


        /// <summary>
        /// Navigates the system area tree dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="systemAreaId">The system area identifier.</param>
        /// <param name="isJobDetails">if set to <c>true</c> [is job details].</param>
        /// <param name="jobName">Name of the job.</param>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="isAddNewJob">if set to <c>true</c> [is add new job].</param>
        void NavigateSystemAreaTreeDialog(INavigationContext navigationContext, UserMenuItem selectedVessel, string parentId, string systemAreaId, bool isJobDetails, string jobName, string jobId, bool isAddNewJob);
        
        /// <summary>
        /// Navigates to map job dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="jobListParameter">The job list parameter.</param>
        void NavigateToMapJobDialog(INavigationContext navigationContext, object jobListParameter);

        /// <summary>
        /// Navigates the rounds report work order.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        void NavigateRoundsReportWorkOrder(INavigationContext navigationContext, string parentId, string vesselId, string workOrderId);

        /// <summary>
        /// Navigates the view rounds report work order.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVessel">The selected vessel.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        void NavigateViewRoundsReportWorkOrder(INavigationContext navigationContext, UserMenuItem selectedVessel, string workOrderId, string workOrderHistoryId,string componentId);

        /// <summary>
        /// Navigates the work order job description.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="workOrderDetails">The work order details.</param>
        /// <param name="jobId">The job identifier.</param>
        void NavigateWorkOrderJobDescription(INavigationContext navigationContext, object workOrderDetails, string jobId);
        /// <summary>
        /// Navigates the work order spare details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="workOrderDetails">The work order details.</param>
        void NavigateWorkOrderSpareDetails(INavigationContext navigationContext, object workOrderDetails);

        /// <summary>
        /// Navigates the copy description dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="jobTypeId">The job type identifier.</param>
        void NavigateCopyDescriptionDialog(INavigationContext navigationContext, string vesselId, string parentId, string jobTypeId);
        
        /// <summary>
        /// Navigates the clone resource.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="componentList">The component list.</param>
        /// <param name="componentDetail">The component detail.</param>
        void NavigateCloneResource(INavigationContext navigationContext, string parentId, object componentList, object componentDetail);

        /// <summary>
        /// Navigates the reschdule history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="workOrderId">The work order identifier.</param>
        /// <param name="workOrderHistoryId">The work order history identifier.</param>
        /// <param name="getActiveLogs">if set to <c>true</c> [get active logs].</param>
        void NavigateReschduleHistory(INavigationContext navigationContext, string workOrderId, string workOrderHistoryId, bool getActiveLogs);

        /// <summary>
        /// Navigates the HMM close work order dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateHmmCloseWorkOrderDialog(INavigationContext context, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the update work order description.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="description">The description.</param>
        /// <param name="isVesselDescription">if set to <c>true</c> [is vessel description].</param>
        void NavigateUpdateWorkOrderDescription(INavigationContext navigationContext, string parentId, string jobId, string description, bool isVesselDescription);

        /// <summary>
        /// Navigates the vessel guidelines.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="vesselGuidelines">The vessel guidelines.</param>
        void NavigateVesselGuidelines(INavigationContext context, string parentId, string vesselGuidelines);
        
        /// <summary>
        /// Navigates the map spares dailogue.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateMapSparesDailogue(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add inventory location.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateAddInventoryLocation(INavigationContext navigationContext, string vesselId, string parentId);

        /// <summary>
        /// Navigates the search defects dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateSearchDefectsDialog(INavigationContext navigationContext, string vesselId, string parentId);
    }
}