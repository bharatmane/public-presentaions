﻿namespace VShips.Framework.Common.ModuleNavigation.HotelDefectManager
{
    /// <summary>
    /// Module Navigation Constants for Hotel Defect Manager
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "HotelDefectManager";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "DefectManagerGeometry";

        /// <summary>
        /// The module title
        /// </summary>
        public const string ModuleTitle = "Hotel Defect Manager";

        /// <summary>
        /// The module title
        /// </summary>
        public const string ModuleTooltip = "Hotel Defect Manager";

        //Views

        /// <summary>
        /// The HDM add inventory location view
        /// </summary>
        public const string HdmAddInventoryLocationView = "HdmAddInventoryLocationView";

        /// <summary>
        /// The search defects dialog view
        /// </summary>
        public const string SearchDefectsDialogView = "SearchDefectsDialogView";

        /// <summary>
        /// The HDM map spares dailog view
        /// </summary>
        public const string HdmMapSparesDailogView = "HdmMapSparesDailogView";

        /// <summary>
        /// The edit vessel guidelines dialog view
        /// </summary>
        public const string EditVesselGuidelinesDialogView = "EditVesselGuidelinesDialogView";

        /// <summary>
        /// The HDM update work order description view
        /// </summary>
        public const string HdmUpdateWorkOrderDescriptionView = "HdmUpdateWorkOrderDescriptionView";

        /// <summary>
        /// The HDM clone resource view
        /// </summary>
        public const string HdmCloneResourceView = "HdmCloneResourceView";
        /// <summary>
        /// The HMM close work order dialog view
        /// </summary>
        public const string HmmCloseWorkOrderDialogView = "HmmCloseWorkOrderDialogView";

        /// <summary>
        /// The HDM copy description dialog view
        /// </summary>
        public const string HdmCopyDescriptionDialogView = "HdmCopyDescriptionDialogView";

        /// <summary>
        /// The HDM map jobs dialog view
        /// </summary>
        public const string HdmMapJobsDialogView = "HdmMapJobsDialogView";

        /// <summary>
        /// The start view
        /// </summary>
        public const string StartView = "HotelDefectManagerStartView";

        /// <summary>
        /// The hotel defect crew task view
        /// </summary>
        public const string HotelDefectCrewTaskView = "HotelDefectCrewTaskView";

        /// <summary>
        /// The hotel defect manager select category navigation view
        /// </summary>
        public const string HotelDefectManagerSelectCategoryNavigationView = "HotelDefectManagerSelectCategoryNavigationView";
        /// <summary>
        /// The HDM standing work order navigation view
        /// </summary>
        public const string HdmStandingWorkOrderNavigationView = "HdmStandingWorkOrderNavigationView";

        /// <summary>
        /// The add edit hotel defect navigation view
        /// </summary>
        public const string AddEditHotelDefectNavigationView = "AddEditHotelDefectNavigationView";

        /// <summary>
        /// The add edit hotel defect map spares navigation view
        /// </summary>
        public const string AddEditHotelDefectMapSparesNavigationView = "AddEditHotelDefectMapSparesNavigationView";

        /// <summary>
        /// The hotel defect head of department view
        /// </summary>
        public const string HotelDefectHeadOfDepartmentView = "HotelDefectHeadOfDepartmentView";

        /// <summary>
        /// The hotel defect dashboard view
        /// </summary>
        public const string HotelDefectDashboardView = "HotelDefectDashboardView";

        /// <summary>
        /// The select crew dialog view
        /// </summary>
        public const string SelectCrewDialogView = "SelectCrewDialogView";

        /// <summary>
        /// The hotel defect maintenance history view
        /// </summary>
        public const string HotelDefectMaintenanceHistoryView = "HotelDefectMaintenanceHistoryView";

        /// <summary>
        /// The hotel defect reschedule navigation view
        /// </summary>
        public const string HotelDefectRescheduleNavigationView = "HotelDefectRescheduleNavigationView";

        /// <summary>
        /// The hotel defect approve reschedule navigation view
        /// </summary>
        public const string HotelDefectApproveRescheduleNavigationView = "HotelDefectApproveRescheduleNavigationView";

        /// <summary>
        /// The report work done navigation view
        /// </summary>
        public const string ReportWorkDoneNavigationView = "ReportWorkDoneNavigationView";

        /// <summary>
        /// The view wo details navigation view
        /// </summary>
        public const string ViewWODetailsNavigationView = "ViewWODetailsNavigationView";

        /// <summary>
        /// The edit report work done navigation view
        /// </summary>
        public const string EditReportWorkDoneNavigationView = "EditReportWorkDoneNavigationView";
        /// <summary>
        /// The HMM rounds edit RWD navigation view
        /// </summary>
        public const string HmmRoundsEditRwdNavigationView = "HmmRoundsEditRwdNavigationView";

        /// <summary>
        /// The assign responsibility dialog view
        /// </summary>
        public const string AssignResponsibilityDialogView = "AssignResponsibilityDialogView";

        /// <summary>
        /// The HMM change responsibility dialog view
        /// </summary>
        public const string HmmChangeResponsibilityDialogView = "HmmChangeResponsibilityDialogView";

        /// <summary>
        /// The hotel defect component view
        /// </summary>
        public const string HotelDefectComponentView = "HotelDefectComponentView";
        /// <summary>
        /// The HDM manage hierarchy start view
        /// </summary>
        public const string HdmManageHierarchyStartView = "HdmManageHierarchyStartView";

        /// <summary>
        /// The add edit hotel defect component navigation view
        /// </summary>
        public const string AddEditHotelDefectComponentNavigationView = "AddEditHotelDefectComponentNavigationView";

        /// <summary>
        /// The hotel defect copy component view
        /// </summary>
        public const string HotelDefectCopyComponentView = "HotelDefectCopyComponentView";

        /// <summary>
        /// The hotel defect retrieve component view
        /// </summary>
        public const string HotelDefectRetrieveComponentView = "HotelDefectRetrieveComponentView";

        /// <summary>
        /// The hotel defect component category system area TreeView
        /// </summary>
        public const string HotelDefectComponentCategorySystemAreaTreeView = "HotelDefectComponentCategorySystemAreaTreeView";

        /// <summary>
        /// The HDM jobs view
        /// </summary>
        public const string HdmJobsView = "HdmJobsView";

        /// <summary>
        /// The hotel report work done wizard view.
        /// </summary>
        public const string HotelReportWorkDoneWizardView = "HotelReportWorkDoneWizardView";

        /// <summary>
        /// The add edit job navigation view
        /// </summary>
        public const string HdmAddEditJobNavigationView = "HdmAddEditJobNavigationView";

        /// <summary>
        /// The hse assessment add edit view.
        /// </summary>
        public const string HseAssessmentAddEditView = "HotelHseAssessmentAddEditView";

        /// <summary>
        /// The work order view
        /// </summary>
        public const string WorkOrderView = "HMMWorkOrderView";

        /// <summary>
        /// The HDM component mapping tab view
        /// </summary>
        public const string HdmMapComponentDialogView = "HdmComponentMappingTabView";
        /// <summary>
        /// The HDM history wo details navigation view
        /// </summary>
        public const string HdmHistoryWODetailsNavigationView = "HdmHistoryWODetailsNavigationView";
        /// <summary>
        /// The HDM retrieve jobs view
        /// </summary>
        public const string HdmRetrieveJobsView = "HdmRetrieveJobsView";

        /// <summary>
        /// The HDM add delete reject comment view
        /// </summary>
        public const string HDMAddDeleteRejectCommentView = "HDMAddDeleteRejectCommentView";
        /// <summary>
        /// The common counter not updated dialog view
        /// </summary>
        public const string CommonCounterNotUpdatedDialogView = "CommonCounterNotUpdatedDialogView";
        /// <summary>
        /// The HMM reopen wo view
        /// </summary>
        public const string HMMReopenWOView = "HMMReopenWOView";
        /// <summary>
        /// The HDM rounds report work done view
        /// </summary>
        public const string HdmRoundsReportWorkDoneView = "HdmRoundsReportWorkDoneView";
        /// <summary>
        /// The HDM view round wo dialog view
        /// </summary>
        public const string HdmViewRoundWODialogView = "HdmViewRoundWODialogView";
        /// <summary>
        /// The HDM wo job details view
        /// </summary>
        public const string HdmWOJobDetailsView = "HdmWOJobDetailsView";
        /// <summary>
        /// The HDM spares navigation view
        /// </summary>
        public const string HdmSparesNavigationView = "HdmSparesNavigationView";

        /// <summary>
        /// The HDM system area tree dialog view
        /// </summary>
        public const string HdmSystemAreaTreeDialogView = "HdmSystemAreaTreeDialogView";

        /// <summary>
        /// The reschedule history view.
        /// </summary>
        public const string RescheduleHistoryView = "RescheduleHistoryView";

        /// <summary>
        /// The automatic assign department ListView
        /// </summary>
        public const string AutoAssignDepartmentListView = "AutoAssignDepartmentListView";

    }
}