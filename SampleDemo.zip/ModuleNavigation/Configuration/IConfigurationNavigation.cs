﻿namespace VShips.Framework.Common.ModuleNavigation.Configuration
{
    /// <summary>
    /// Navigation service for the configuration module.
    /// </summary>
    public interface IConfigurationNavigation
    {
        /// <summary>
        /// Navigates to the configuration module start view.
        /// </summary>
        void ConfigurationNavigateStart();
    }
}
