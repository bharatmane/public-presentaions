﻿namespace VShips.Framework.Common.ModuleNavigation.Configuration
{
    /// <summary>
    /// Services and constants relating to the configuration module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
