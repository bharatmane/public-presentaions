﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Configuration
{
    /// <summary>
    /// Default implementation of the <see cref="IConfigurationNavigation"/> service.
    /// </summary>
    public class ConfigurationNavigation : BaseModuleNavigationService, IConfigurationNavigation
    {
        /// <summary>
        /// The default contructor for the ModuleNavigationService.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public ConfigurationNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Navigates to the configuration module start view.
        /// </summary>
        public void ConfigurationNavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.MainView);
        }

        
    }
}
