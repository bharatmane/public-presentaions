﻿namespace VShips.Framework.Common.ModuleNavigation.Configuration
{
    /// <summary>
    /// Names of accessible views and regions related to the configuration module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "Configuration";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "ConfigurationGeometry";

        //Views

        /// <summary>The landing or start view for configuration.</summary>
        public const string MainView = "ConfigurationStartView";

        /// <summary>
        /// Dialog to find a compnay.
        /// </summary>
        public static string CompanyLookup = "CompanyLookupDialog" ;
    }
}
