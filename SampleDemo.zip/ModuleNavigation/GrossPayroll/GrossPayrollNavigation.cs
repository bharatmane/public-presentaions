﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Enumerations.GrossPayroll;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.GrossPayroll
{
    /// <summary>
    /// Default implementation of the <see cref="IGrossPayrollNavigation" /> service.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.GrossPayroll.IGrossPayrollNavigation" />
    public class GrossPayrollNavigation : BaseModuleNavigationService, IGrossPayrollNavigation
    {

        /// <summary>
        /// The default constructor for the GrossPayrollNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public GrossPayrollNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }


        /// <summary>
        /// Navigates to the gross payroll start view.
        /// </summary>
        public void GrossPayrollNavigateStart()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Clients the setup navigate start.
        /// </summary>
        public void ClientSetupNavigateStart()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ClientSetupStartView);
        }
        /// <summary>
        /// Adds the client details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="clientId">The client identifier.</param>
        /// <param name="isClientHasMultipleVessel">if set to <c>true</c> [is client has multiple vessel].</param>
        public void NavigateAddEditClientDetails(INavigationContext navigationContext, string clientId, bool isClientHasMultipleVessel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add(Constants.ClientId, clientId);
            parameters.Add(Constants.IsClientHasMultipleVessel, isClientHasMultipleVessel);
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditClientSetupNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add edit payscale item.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="psnId">The PSN identifier.</param>
        public void NavigateAddEditPayscaleItem(INavigationContext navigationContext, string psnId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PayscaleItemAddEditNavigationView, navigationContext, psnId);
        }


        /// <summary>
        /// Opens the awaiting review in office.
        /// </summary>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="payrollStatus">The payroll status.</param>
        /// <param name="periodStartDate">The period start date.</param>
        public void OpenAwaitingReviewInOffice(string fleetId, PayrollStatus payrollStatus, DateTime periodStartDate)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add(Constants.FleetId, fleetId);
            parameters.Add(Constants.PayrollStartDate, periodStartDate);
            parameters.Add(Constants.PayrollStatus, payrollStatus);
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AwaitingReviewInOfficeView, parameters);
        }
        /// <summary>
        /// Opens the onboard crewddtails with no contract.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void OpenOnboardCrewddtailsWithNoContract(INavigationContext navigationContext, string vesselId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OnBoardCrewWithNoContractNavigateDilogView, navigationContext, vesselId);
        }

        /// <summary>
        /// Crews the transaction details earning deduction.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void CrewTransactionDetailsEarningDeduction(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewEarningAndDedutionDetailsView, inputParameter);
        }

        /// <summary>
        /// Bulks the adjustment navigate dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void BulkAdjustmentNavigateDialog(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BulkAdjustmentNavigationDilogView, navigationContext, parameter);
        }

        /// <summary>
        /// Adds the crew adjustment dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void AddCrewAdjustmentDialog(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAdjustmentNavigateDialogView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Crews the transaction details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void CrewTransactionDetails(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewTransactionStatementView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the vessel transaction summary.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="payPeriodId">The pay period identifier.</param>
        /// <param name="payPeriod">The pay period.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="currency">The currency.</param>
        public void NavigateVesselTransactionSummary(INavigationContext navigationContext, string payPeriodId, string payPeriod, string vesselId, string currency)
        {
            GrossPayrollNavParameter parameter = new GrossPayrollNavParameter()
            {
                PayPeriodId = payPeriodId,
                PayPeriod = payPeriod,
                VesselId = vesselId,
                Currency = currency
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselEarnDeductSummaryNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the open payroll dialog view.
        /// </summary>
        /// <param name="navigationContext">The i navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateOpenPayrollDialogView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OpenPayrollPeriodDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Grosses the payroll audit log view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void GrossPayrollAuditLogView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GrossPayrollAuditLogView, context, parameters);
        }

        /// <summary>
        /// Navigates the payroll start view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigatePayrollStartView(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PayrollStartView, inputParameter);
        }

        /// <summary>
        /// Navigates the crew summary view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateCrewSummaryView(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewSummaryStartView, inputParameter);
        }

        /// <summary>
        /// Navigates the crew details offsigners view.
        /// </summary>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="payrollStatus">The payroll status.</param>
        /// <param name="periodStartDate">The period start date.</param>
        public void NavigateCrewDetailsOffsignersView(string fleetId, PayrollStatus payrollStatus, DateTime periodStartDate)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add(Constants.FleetId, fleetId);
            parameters.Add(Constants.PayrollStartDate, periodStartDate);
            parameters.Add(Constants.PayrollStatus, payrollStatus);
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewDetailsOffsignersDetailView, parameters);
        }

        /// <summary>
        /// Navigate crews the allotment details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateCrewAllotmentDetailsView(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewPayrollAllotmentSummaryView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the post to account view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigatePostToAccountView(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PostToAccountsNavigationView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the post allotment view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigatePostAllotmentView(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PostAllotmentsView, inputParameter);
        }

        /// <summary>
        /// Navigates the chart detail accounts tree lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void NavigateChartDetailAccountsTreeLookupView(INavigationContext navigationContext, string chartHeaderId, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { "Identifier", chartHeaderId },
                { "SelectedItemChanged", selectedItemChanged }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ChartDetailAccountsTreeLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the create direct payment invoice navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateCreateDirectPaymentInvoiceNavigationView(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateDirectPaymentInvoiceNavigationView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the request fund paycenter navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateRequestFundPaycenterNavigationView(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RequestFundPaycenterNavigationView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the crew exclude include navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateCrewExcludeIncludeNavigationView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewExcludeIncludeNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the edit crew input.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter" />.</param>
        public void NavigateEditCrewInput(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditPayrollStaticInputNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit crew initial balance.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter" />.</param>
        public void NavigateAddEditCrewInitialBalance(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewInitialBalanceView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the export allotments validations.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateExportAllotmentsValidations(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExoprtAllotmentsValidationsErrorDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the import allotments validation.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateImportAllotmentsValidation(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportAllotmentsValidationsErrorDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit pay center maintair details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="cenId">The cen identifier.</param>
        public void NavigateAddEditPayCenterMaintairDetailsView(INavigationContext navigationContext, string cenId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditPayCenterMaintairDetailsView, navigationContext, cenId);
        }

        /// <summary>
        /// Navigates to invalid crew contract dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToInvalidCrewContractDailog(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InvalidCrewContractDetailsDialogView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to accumulator history dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToAccumulatorHistoryDailog(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccumulatorHistoryDialogView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to add edit crew accumulator details dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToAddEditCrewAccumulatorDetailsDailog(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewAccumulatorDetailsDialogView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to edit crew opening balance.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEditCrewOpeningBalance(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewOpeningBalanceNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the duplicate import allotments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDuplicateImportAllotments(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DuplicateAllotmentDetailsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigatetoes the add edit allowance template.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="allowanceTeamplateIdForEdit">The allowance teamplate identifier for edit.</param>
        public void NavigatetoAddEditAllowanceTemplate(INavigationContext navigationContext, string allowanceTeamplateIdForEdit)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditAllowanceMaintainerDialogView, navigationContext, allowanceTeamplateIdForEdit);
        }

        /// <summary>
        /// Navigates to synchronize mismatch crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToSyncMismatchCrewDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MismatchCrewDetailsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to reset pay period validation error dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToResetPayPeriodValidationErrorDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ResetPayPeriodValidationErrorDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to earnings and contributions dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEarningsAndContributionsDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ContractualEarningsAndContributionsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to import validations dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToImportValidationsDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportValidationsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to request for revision dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToRequestForRevisionDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RequestForRevisionDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to request for revision dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToTimesheetSelectStatusDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TimesheetSelectStatusDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to timesheet crew logs dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToTimesheetCrewLogsDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TimesheetCrewLogsDialogView, navigationContext, parameter);
        }
        /// <summary>
        /// Navigates to request for revision dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAllowanceRequestForRevisionDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AllowanceRequestForRevisionDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to missing crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMissingCrewDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MissingCrewDialogView, navigationContext, parameter);

        }

        /// <summary>
        /// Navigaes to crew validation check dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigaeToCrewValidationCheckDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewValidationCheckDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Imports the accounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="clientId"></param>
        public void ImportAccountsDialogView(INavigationContext navigationContext, string clientId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportAccountsDialogView, navigationContext, clientId);
        }

        /// <summary>
        /// Navigates to add extra crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddExtraCrewDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddExtraCrewDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Grosses the payroll audit log view (multiple vessel).
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void GrossPayrollAuditLogView_MV(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GrossPayrollAuditLogView_MV, context, parameters);
        }

        /// <summary>
        /// Crews the allowance details view mv.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CrewAllowanceDetailsView_MV(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewAllowanceDetailsDialogView_MV, context, parameters);
        }

        /// <summary>
        /// Navigates the payroll start view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigatePayrollStartView_MV(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PayrollStartView_MV, inputParameter);
        }

        /// <summary>
        /// Navigates the vessel transaction summary (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="payPeriodId">The pay period identifier.</param>
        /// <param name="payPeriod">The pay period.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="currency">The currency.</param>
        public void NavigateVesselTransactionSummary_MV(INavigationContext navigationContext, string payPeriodId, string payPeriod, string vesselId, string currency)
        {
            GrossPayrollNavParameter parameter = new GrossPayrollNavParameter()
            {
                PayPeriodId = payPeriodId,
                PayPeriod = payPeriod,
                VesselId = vesselId,
                Currency = currency
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselEarnDeductSummaryNavigationView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the open payroll dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The i navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateOpenPayrollDialogView_MV(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OpenPayrollPeriodDialogView_MV, navigationContext, parameters);
        }

        /// <summary>
        /// Navigate crews the allotment details view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateCrewAllotmentDetailsView_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewPayrollAllotmentSummaryView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the post to account view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigatePostToAccountView_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PostToAccountsNavigationView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the post allotment view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigatePostAllotmentView_MV(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PostAllotmentsView_MV, inputParameter);
        }

        /// <summary>
        /// Navigates the crew summary view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateCrewSummaryView_MV(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewSummaryStartView_MV, inputParameter);
        }

        /// <summary>
        /// Navigates the multi service crew summary view mv.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateMultiServiceCrewSummaryView_MV(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.MultiServiceCrewSummaryStartView_MV, inputParameter);
        }

        /// <summary>
        /// Navigates the create direct payment invoice navigation view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateCreateDirectPaymentInvoiceNavigationView_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateDirectPaymentInvoiceNavigationView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the request fund paycenter navigation view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateRequestFundPaycenterNavigationView_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RequestFundPaycenterNavigationView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the edit crew input (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter" />.</param>
        public void NavigateEditCrewInput_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditPayrollStaticInputNavigationView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the crew exclude include navigation view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateCrewExcludeIncludeNavigationView_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewExcludeIncludeNavigationView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the export allotments validations (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateExportAllotmentsValidations_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExoprtAllotmentsValidationsErrorDialogView_MV, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates the import allotments validation (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateImportAllotmentsValidation_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportAllotmentsValidationsErrorDialogView_MV, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates the add edit crew initial balance (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter" />.</param>
        public void NavigateAddEditCrewInitialBalance_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewInitialBalanceView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to invalid crew contract dailog (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToInvalidCrewContractDailog_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InvalidCrewContractDetailsDialogView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to non approved crew details view model mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToNonApprovedCrewDetailsViewModel_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NonApprovedCrewDetailsDialogView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to accumulator history dailog (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToAccumulatorHistoryDailog_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccumulatorHistoryDialogView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to edit crew opening balance (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEditCrewOpeningBalance_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewOpeningBalanceNavigationView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the duplicate import allotments (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDuplicateImportAllotments_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DuplicateAllotmentDetailsDialogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to synchronize mismatch crew dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToSyncMismatchCrewDialogView_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MismatchCrewDetailsDialogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to earnings and contributions dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEarningsAndContributionsDialogView_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ContractualEarningsAndContributionsDialogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to reset pay period validation error dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToResetPayPeriodValidationErrorDialogView_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ResetPayPeriodValidationErrorDialogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to edit crew opening balance by crew identifier navigation view mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEditCrewOpeningBalanceByCrewId_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewOpeningBalanceByCrewIdNavigationView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit crew initial balance by crew identifier mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddEditCrewInitialBalanceByCrewId_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewInitialBalanceByCrewIdView_MV, navigationContext, parameter);
        }


        /// <summary>
        /// Bulks the adjustment navigate dialog for Multivessel.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void BulkAdjustmentNavigateDialog_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BulkAdjustmentNavigationDilogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Adds the crew adjustment dialog for multivessel.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void AddCrewAdjustmentDialog_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAdjustmentNavigateDialogView_MV, navigationContext, inputParameter);
        }


        /// <summary>
        /// Navigates to add edit crew accumulator details dailog mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateToAddEditCrewAccumulatorDetailsDailog_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCrewAccumulatorDetailsDialogView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to add extra crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddExtraCrewDialogView_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddExtraCrewDialogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to the extra crew summary view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateExtraCrewSummaryView_MV(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ExtraCrewSummaryStartView_MV, inputParameter);
        }


        /// <summary>
        /// Navigates to extra crew logs dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToExtraCrewLogsDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GrossPayrollExtraCrewAuditLogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to extra crew logs dialog view mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToExtraCrewLogsDialogView_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GrossPayrollExtraCrewAuditLogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Adds the extra crew adjustment dialog mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        public void AddExtraCrewAdjustmentDialog_MV(INavigationContext navigationContext, object inputParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddExtraCrewAdjustmentDialogView_MV, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates to edit extra crew input mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToEditExtraCrewInput_MV(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExtraCrewEditStaticInputDialogView_MV, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to the extra crew summary view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        public void NavigateExtraCrewSummaryView(object inputParameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ExtraCrewSummaryStartView, inputParameter);
        }

    }
}
