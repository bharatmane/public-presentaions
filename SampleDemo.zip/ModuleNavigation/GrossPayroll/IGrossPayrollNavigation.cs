﻿using System;
using VShips.DataServices.Shared.Enumerations.GrossPayroll;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.GrossPayroll
{
    /// <summary>
    /// Navigation service for the gross payroll management module.
    /// </summary>
    public interface IGrossPayrollNavigation
    {
        /// <summary>
        /// Navigates to the gross payroll module start view.
        /// </summary>
        void GrossPayrollNavigateStart();

        /// <summary>
        /// Adds the client details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="clientId">The client identifier.</param>
        /// <param name="isClientHasMultipleVessel">if set to <c>true</c> [is client has multiple vessel].</param>
        void NavigateAddEditClientDetails(INavigationContext navigationContext, string clientId, bool isClientHasMultipleVessel);

        /// <summary>
        /// Navigates the add edit payscale item.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="psnId">The PSN identifier.</param>
        void NavigateAddEditPayscaleItem(INavigationContext navigationContext, string psnId);

        /// <summary>
        /// Opens the awaiting review in office.
        /// </summary>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="payrollStatus">The payroll status.</param>
        /// <param name="periodStartDate">The period start date.</param>
        void OpenAwaitingReviewInOffice(string fleetId, PayrollStatus payrollStatus, DateTime periodStartDate);

        /// <summary>
        /// Opens the onboard crewddtails with no contract.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void OpenOnboardCrewddtailsWithNoContract(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Crews the transaction details earning deduction.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void CrewTransactionDetailsEarningDeduction(object inputParameter);

        /// <summary>
        /// Bulks the adjustment navigate dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void BulkAdjustmentNavigateDialog(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Adds the crew adjustment dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void AddCrewAdjustmentDialog(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Crews the transaction details.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void CrewTransactionDetails(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the vessel transaction summary.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="payPeriodId">The pay period identifier.</param>
        /// <param name="payPeriod">The pay period.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="currency">The currency.</param>
        void NavigateVesselTransactionSummary(INavigationContext navigationContext, string payPeriodId, string payPeriod, string vesselId, string currency);

        /// <summary>
        /// Navigates the open payroll dialog view.
        /// </summary>
        /// <param name="navigationContext">The i navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateOpenPayrollDialogView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Grosses the payroll audit log view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void GrossPayrollAuditLogView(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates the payroll start view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigatePayrollStartView(object inputParameter);

        /// <summary>
        /// Navigates the crew summary view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateCrewSummaryView(object inputParameter);

        /// <summary>
        /// Navigates the crew details offsigners view.
        /// </summary>
        /// <param name="fleetId">The fleet identifier.</param>
        /// <param name="payrollStatus">The payroll status.</param>
        /// <param name="periodStartDate">The period start date.</param>
        void NavigateCrewDetailsOffsignersView(string fleetId, PayrollStatus payrollStatus, DateTime periodStartDate);

        /// <summary>
        /// Navigatecrews the allotment detailsview.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateCrewAllotmentDetailsView(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the post to account view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigatePostToAccountView(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the chart detail accounts tree lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void NavigateChartDetailAccountsTreeLookupView(INavigationContext navigationContext, string chartHeaderId, Action<object> selectedItemChanged);

        /// <summary>
        /// Navigates the post allotment view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigatePostAllotmentView(object inputParameter);

        /// <summary>
        /// Navigates the create direct payment invoice navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateCreateDirectPaymentInvoiceNavigationView(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the request fund paycenter navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateRequestFundPaycenterNavigationView(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the crew exclude include navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateCrewExcludeIncludeNavigationView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the edit crew input.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter"/>.</param>
        void NavigateEditCrewInput(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates the add edit crew initial balance.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter"/>.</param>
        void NavigateAddEditCrewInitialBalance(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates the export allotments validations.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateExportAllotmentsValidations(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the import allotments validation.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateImportAllotmentsValidation(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add edit pay center maintair details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="cenId">The cen identifier.</param>
        void NavigateAddEditPayCenterMaintairDetailsView(INavigationContext navigationContext, string cenId);

        /// <summary>
        /// Navigates to invalid crew contract dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToInvalidCrewContractDailog(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to accumulator history dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToAccumulatorHistoryDailog(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to add edit crew accumulator details dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToAddEditCrewAccumulatorDetailsDailog(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to edit crew opening balance.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEditCrewOpeningBalance(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates the duplicate import allotments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDuplicateImportAllotments(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigatetoes the add edit allowance template.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="allowanceTeamplateIdForEdit">The allowance teamplate identifier for edit.</param>
        void NavigatetoAddEditAllowanceTemplate(INavigationContext navigationContext, string allowanceTeamplateIdForEdit);

        /// <summary>
        /// Navigates to synchronize mismatch crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToSyncMismatchCrewDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to reset pay period validation error dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToResetPayPeriodValidationErrorDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to earnings and contributions dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEarningsAndContributionsDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to import validations dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToImportValidationsDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to request for revision dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToRequestForRevisionDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to timesheet select status dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToTimesheetSelectStatusDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to timesheet crew logs dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToTimesheetCrewLogsDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to request for revision dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAllowanceRequestForRevisionDialogView(INavigationContext navigationContext, object parameter);


        /// <summary>
        /// Navigates to missing crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <returns></returns>
        void NavigateToMissingCrewDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigaes to crew validation check dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigaeToCrewValidationCheckDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Imports the accounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="clientId">The client identifier.</param>
        void ImportAccountsDialogView(INavigationContext navigationContext, string clientId);

        /// <summary>
        /// Navigates to add extra crew dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddExtraCrewDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Grosses the payroll audit log view (multiple vessel).
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void GrossPayrollAuditLogView_MV(INavigationContext context, object parameters);

        /// <summary>
        /// Crews the allowance details view mv.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void CrewAllowanceDetailsView_MV(INavigationContext context, object parameters);


        /// <summary>
        /// Navigates the payroll start view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigatePayrollStartView_MV(object inputParameter);

        /// <summary>
        /// Navigates the vessel transaction summary (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="payPeriodId">The pay period identifier.</param>
        /// <param name="payPeriod">The pay period.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="currency">The currency.</param>
        void NavigateVesselTransactionSummary_MV(INavigationContext navigationContext, string payPeriodId, string payPeriod, string vesselId, string currency);

        /// <summary>
        /// Navigates the open payroll dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The i navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateOpenPayrollDialogView_MV(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigate crews the allotment details view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateCrewAllotmentDetailsView_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the post to account view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigatePostToAccountView_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the post allotment view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigatePostAllotmentView_MV(object inputParameter);

        /// <summary>
        /// Navigates the crew summary view (multiple vessel).
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateCrewSummaryView_MV(object inputParameter);

        /// <summary>
        /// Navigates the multi service crew summary view mv.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateMultiServiceCrewSummaryView_MV(object inputParameter);

        /// <summary>
        /// Navigates the create direct payment invoice navigation view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateCreateDirectPaymentInvoiceNavigationView_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the request fund paycenter navigation view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateRequestFundPaycenterNavigationView_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates the edit crew input (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter" />.</param>
        void NavigateEditCrewInput_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates the crew exclude include navigation view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateCrewExcludeIncludeNavigationView_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the export allotments validations (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateExportAllotmentsValidations_MV(INavigationContext navigationContext, object parameter);


        /// <summary>
        /// Navigates the import allotments validation (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateImportAllotmentsValidation_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add edit crew initial balance (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter of type <see cref="GrossPayrollNavParameter" />.</param>
        void NavigateAddEditCrewInitialBalance_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates to invalid crew contract dailog (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToInvalidCrewContractDailog_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to non approved crew details view model mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToNonApprovedCrewDetailsViewModel_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to accumulator history dailog (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToAccumulatorHistoryDailog_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to edit crew opening balance (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEditCrewOpeningBalance_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates the duplicate import allotments (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDuplicateImportAllotments_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to synchronize mismatch crew dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToSyncMismatchCrewDialogView_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to earnings and contributions dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEarningsAndContributionsDialogView_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to reset pay period validation error dialog view (multiple vessel).
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToResetPayPeriodValidationErrorDialogView_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to edit crew opening balance by crew identifier navigation view mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEditCrewOpeningBalanceByCrewId_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Navigates the add edit crew initial balance by crew identifier mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddEditCrewInitialBalanceByCrewId_MV(INavigationContext navigationContext, GrossPayrollNavParameter parameter);

        /// <summary>
        /// Bulks the adjustment navigate dialog mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void BulkAdjustmentNavigateDialog_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Adds the crew adjustment dialog mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void AddCrewAdjustmentDialog_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to add edit crew accumulator details dailog mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateToAddEditCrewAccumulatorDetailsDailog_MV(INavigationContext navigationContext, object inputParameter);

        /// <summary>
        /// Navigates to add extra crew dialog view mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddExtraCrewDialogView_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to extra crew logs dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <returns></returns>
        void NavigateToExtraCrewLogsDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to extra crew logs dialog view mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToExtraCrewLogsDialogView_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Adds the extra crew adjustment dialog mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="inputParameter">The input parameter.</param>
        void AddExtraCrewAdjustmentDialog_MV(INavigationContext navigationContext, object inputParameter);
        
        /// <summary>
        /// Navigates to the extra crew summary view mv.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        /// <returns></returns>
        void NavigateExtraCrewSummaryView_MV(object inputParameter);


        /// <summary>
        /// Navigates to edit extra crew input mv.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToEditExtraCrewInput_MV(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the extra crew summary view.
        /// </summary>
        /// <param name="inputParameter">The input parameter.</param>
        void NavigateExtraCrewSummaryView(object inputParameter);
    }
}
