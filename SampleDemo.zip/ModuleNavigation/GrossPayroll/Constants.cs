﻿
namespace VShips.Framework.Common.ModuleNavigation.GrossPayroll
{
    /// <summary>
    /// Names of accessible views and regions related to the gross payroll module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "GrossPayroll";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "GrossPayableGeometry";

        //Views

        /// <summary>
        /// The landing or start view for gross payroll.
        /// </summary>
        public const string StartView = "GrossPayrollStartView";

        /// <summary>
        /// The summary of accounts start view
        /// </summary>
        public const string SummaryOfAccountsStartView = "SummaryOfAccountsStartView";

        /// <summary>
        /// The Client Set up start up page
        /// </summary>
        public const string ClientSetupStartView = "ClientSetupStartView";

        /// <summary>
        /// The payscale items view
        /// </summary>
        public const string PayscaleItemsView = "PayscaleItemView";

        /// <summary>
        /// The payscale item add edit navigation view
        /// </summary>
        public const string PayscaleItemAddEditNavigationView = "PayscaleItemAddEditNavigationView";

        /// <summary>
        /// The payscale items maintainer view.
        /// </summary>
        public const string PayscaleItemsMaintainerView = "PayscaleItemsMaintainerView";

        /// <summary>
        /// The client setup maintainer start view.
        /// </summary>
        public const string ClientSetupMaintainerStartView = "ClientSetupMaintainerStartView";

        /// <summary>
        /// The add edit client setup navigation view.
        /// </summary>
        public const string AddEditClientSetupNavigationView = "AddEditClientSetupNavigationView";

        /// <summary>
        /// The pending transaction navigation view.
        /// </summary>
        //public const string PendingTransactionNavigationView = "PendingTransactionNavigationView";

        /// <summary>
        /// The payroll start view
        /// </summary>
        public const string PayrollStartView = "PayrollStartView";

        /// <summary>
        /// The crew summary start view.
        /// </summary>
        public const string CrewSummaryStartView = "CrewSummaryStartView";

        /// <summary>
        /// The awaiting review in office view
        /// </summary>
        public const string AwaitingReviewInOfficeView = "AwaitingReviewInOfficeView";

        /// <summary>
        /// The on board crew with nocontract navigate dilog
        /// </summary>
        public const string OnBoardCrewWithNoContractNavigateDilogView = "OnBoardCrewWithNoContractNavigateDilogView";

        /// <summary>
        /// The crew earning and dedution details view
        /// </summary>
        public const string CrewEarningAndDedutionDetailsView = "CrewEarningAndDedutionDetailsView";

        /// <summary>
        /// The bulk adjustment navigation dilog view
        /// </summary>
        public const string BulkAdjustmentNavigationDilogView = "BulkAdjustmentNavigationDilogView";

        /// <summary>
        /// The add adjustment navigate dialog view
        /// </summary>
        public const string AddAdjustmentNavigateDialogView = "AddAdjustmentNavigateDialogView";

        /// <summary>
        /// The crew transaction statement view
        /// </summary>
        public const string CrewTransactionStatementView = "CrewTransactionStatementView";

        /// <summary>
        /// The create memo
        /// </summary>
        public const string CreatePayrollMemoDialogView = "CreatePayrollMemoDialogView";

        /// <summary>
        /// The vessel earn deduct summary navigation view.
        public const string VesselEarnDeductSummaryNavigationView = "VesselEarnDeductSummaryNavigationView";
        /// </summary>

        /// <summary>
        /// The open payroll period dialog view
        /// </summary>
        public const string OpenPayrollPeriodDialogView = "OpenPayrollPeriodDialogView";

        /// <summary>
        /// The gross payroll audit log view
        /// </summary>
        public const string GrossPayrollAuditLogView = "GrossPayrollAuditLogView";

        /// <summary>
        /// The crew summary dialog view
        /// </summary>
        public const string CrewSummaryDialogView = "CrewSummaryDialogView";

        /// <summary>
        /// The crew details offsigners detail view
        /// </summary>
        public const string CrewDetailsOffsignersDetailView = "CrewDetailsOffsignersDetailView";

        /// <summary>
        /// The summary of earnings dialog view
        /// </summary>
        public const string SummaryOfEarningsDialogView = "SummaryOfEarningsDialogView";

        /// <summary>
        /// The summary of earnings drill down start view
        /// </summary>
        public const string SummaryOfEarningsDrillDownStartView = "SummaryOfEarningsDrillDownStartView";

        /// <summary>
        /// The pay item summary dialog view
        /// </summary>
        public const string PayItemSummaryDialogView = "PayItemSummaryDialogView";

        /// <summary>
        /// The payroll month analysis dialog view
        /// </summary>
        public const string PayrollMonthAnalysisDialogView = "PayrollMonthAnalysisDialogView";

        /// <summary>
        /// The client identifier
        /// </summary>
        public const string ClientId = "ClientId";

        /// <summary>
        /// The current identifier
        /// </summary>
        public const string CurId = "CurId";

        /// <summary>
        /// The payroll start date
        /// </summary>
        public const string PayrollStartDate = "PayrollStartDate";

        /// <summary>
        /// The payroll end date
        /// </summary>
        public const string PayrollEndDate = "PayrollEndDate";

        /// <summary>
        /// The frequency
        /// </summary>
        public const string Frequency = "Frequency";

        /// <summary>
        /// The display frequency
        /// </summary>
        public const string DisplayFrequency = "DisplayFrequency";

        /// <summary>
        /// The is enable edit
        /// </summary>
        public const string IsEnableEdit = "IsEnableEdit";

        /// <summary>
        /// The client name
        /// </summary>
        public const string ClientName = "ClientName";

        /// <summary>
        /// The vessel name
        /// </summary>
        public const string VesselName = "VesselName";

        /// <summary>
        /// The fleet identifier
        /// </summary>
        public const string FleetId = "FleetId";

        /// <summary>
        /// The client start date
        /// </summary>
        public const string ClientStartDate = "ClientStartDate";

        /// <summary>
        /// The payroll status identifier
        /// </summary>
        public const string PayrollStatusId = "PayrollStatusId";
        /// <summary>
        /// The payroll status identifier
        /// </summary>
        public const string PayrollStatus = "PayrollStatus";

        /// <summary>
        /// The post to accounts navigation view
        /// </summary>
        public const string PostToAccountsNavigationView = "PostToAccountsNavigationView";

        /// <summary>
        /// The crew payroll allotment summary view
        /// </summary>
        public const string CrewPayrollAllotmentSummaryView = "CrewPayrollAllotmentSummaryView";

        /// <summary>
        /// The post allotments dialog view
        /// </summary>
        public const string PostAllotmentsView = "PostAllotmentsView";

        /// <summary>
        /// The chart detail accounts tree lookup view
        /// </summary>
        public const string ChartDetailAccountsTreeLookupView = "ChartDetailAccountsTreeLookupView";

        /// <summary>
        /// The summary of earning excel file name
        /// </summary>
        public const string SummaryOfEarningExcelFileName = "SummaryOfEarning_{0} {1}-{2}-{3}";

        /// <summary>
        /// The summary of account excel file name
        /// </summary>
        public const string SummaryOfAccountExcelFileName = "SummaryOfAccount_{0} {1}-{2}-{3}";

        /// <summary>
        /// The create direct payment invoice navigation view
        /// </summary>
        public const string CreateDirectPaymentInvoiceNavigationView = "CreateDirectPaymentInvoiceNavigationView";

        /// <summary>
        /// The request fund paycenter navigation view
        /// </summary>
        public const string RequestFundPaycenterNavigationView = "RequestFundPaycenterNavigationView";

        /// <summary>
        /// The crew exclude include navigation view
        /// </summary>
        public const string CrewExcludeIncludeNavigationView = "CrewExcludeIncludeNavigationView";

        /// <summary>
        /// The edit payroll static input navigation view.
        /// </summary>
        public const string EditPayrollStaticInputNavigationView = "EditPayrollStaticInputNavigationView";

        /// <summary>
        /// The add edit crew initial balance view.
        /// </summary>
        public const string AddEditCrewInitialBalanceView = "AddEditCrewInitialBalanceView";

        /// <summary>
        /// The earning deduction item
        /// </summary>
        public const string EarningDeductionItem = "EarningDeductionItem";

        /// <summary>
        /// The pay roll period start date
        /// </summary>
        public const string PayRollPeriodStartDate = "PayRollPeriodStartDate";

        /// <summary>
        /// The status.
        /// </summary>
        public const string Status = "Status";

        /// <summary>
        /// The exoprt allotments validations error dialog view
        /// </summary>
        public const string ExoprtAllotmentsValidationsErrorDialogView = "ExoprtAllotmentsValidationsErrorDialogView";

        /// <summary>
        /// The import allotments validations error dialog view
        /// </summary>
        public const string ImportAllotmentsValidationsErrorDialogView = "ImportAllotmentsValidationsErrorDialogView";

        /// <summary>
        /// The pay center maintainer start view
        /// </summary>
        public const string PayCenterMaintainerStartView = "PayCenterMaintainerStartView";

        /// <summary>
        /// The add edit pay center maintair details view
        /// </summary>
        public const string AddEditPayCenterMaintairDetailsView = "AddEditPayCenterMaintairDetailsView";

        /// <summary>
        /// The invalid crew contract details dialog view
        /// </summary>
        public const string InvalidCrewContractDetailsDialogView = "InvalidCrewContractDetailsDialogView";

        /// <summary>
        /// The accumulator history dialog view
        /// </summary>
        public const string AccumulatorHistoryDialogView = "AccumulatorHistoryDialogView";

        /// <summary>
        /// The edit crew opening balance navigation view
        /// </summary>
        public const string EditCrewOpeningBalanceNavigationView = "EditCrewOpeningBalanceNavigationView";

        /// <summary>
        /// The duplicate allotment details dialog view
        /// </summary>
        public const string DuplicateAllotmentDetailsDialogView = "DuplicateAllotmentDetailsDialogView";

        /// <summary>
        /// The allowance maintainer
        /// </summary>
        public const string AllowanceMaintainer = "Allowance Maintainer";

        /// <summary>
        /// The allowance maintainer start view
        /// </summary>
        public const string AllowanceMaintainerStartView = "AllowanceMaintainerStartView";

        /// <summary>
        /// The add edit allowance maintainer dialog view
        /// </summary>
        public const string AddEditAllowanceMaintainerDialogView = "AddEditAllowanceMaintainerDialogView";

        /// <summary>
        /// The allowance tracking start view
        /// </summary>
        public const string AllowanceTrackingStartView = "AllowanceTrackingStartView";

        /// <summary>
        /// The timesheet start view
        /// </summary>
        public const string TimesheetView = "TimesheetView";

        /// <summary>
        /// The mismatch crew details dialog view
        /// </summary>
        public const string MismatchCrewDetailsDialogView = "MismatchCrewDetailsDialogView";

        /// <summary>
        /// The reset pay period validation error dialog view
        /// </summary>
        public const string ResetPayPeriodValidationErrorDialogView = "ResetPayPeriodValidationErrorDialogView";

        /// <summary>
        /// The contractual earnings and contributions dialog view
        /// </summary>
        public const string ContractualEarningsAndContributionsDialogView = "ContractualEarningsAndContributionsDialogView";

        /// <summary>
        /// The import validations dialog view
        /// </summary>
        public const string ImportValidationsDialogView = "ImportValidationsDialogView";

        /// <summary>
        /// The request for revision dialog view
        /// </summary>
        public const string RequestForRevisionDialogView = "RequestForRevisionDialogView";
        
        /// <summary>
        /// The allowance request for revision dialog view
        /// </summary>
        public const string AllowanceRequestForRevisionDialogView = "AllowanceRequestForRevisionDialogView";
        
        /// <summary>
        /// The timesheet select status dialog view
        /// </summary>
        public const string TimesheetSelectStatusDialogView = "TimesheetSelectStatusDialogView";

        /// <summary>
        /// The timesheet crew logs dialog view
        /// </summary>
        public const string TimesheetCrewLogsDialogView = "TimesheetCrewLogsDialogView";

        /// <summary>
        /// The missing crew dialog view
        /// </summary>
        public const string MissingCrewDialogView = "MissingCrewDialogView";

        /// <summary>
        /// The is client has multiple vessel
        /// </summary>
        public const string IsClientHasMultipleVessel = "IsClientHasMultipleVessel";

        /// <summary>
        /// The validations view
        /// </summary>
        public const string ValidationsView = "ValidationsView";

        /// <summary>
        /// The crew validation check dialog view
        /// </summary>
        public const string CrewValidationCheckDialogView = "CrewValidationCheckDialogView";

        /// <summary>
        /// The import accounts dialog view
        /// </summary>
        public const string ImportAccountsDialogView = "ImportAccountsDialogView";

        /// <summary>
        /// The add edit crew accumulator details dialog view
        /// </summary>
        public const string AddEditCrewAccumulatorDetailsDialogView = "AddEditCrewAccumulatorDetailsDialogView";
        
        /// <summary>
        /// The add edit crew accumulator details dialog view
        /// </summary>
        public const string AddExtraCrewDialogView = "AddExtraCrewDialogView";

        /// <summary>
        /// The gross payroll extra crew audit log view
        /// </summary>
        public const string GrossPayrollExtraCrewAuditLogView = "GrossPayrollExtraCrewAuditLogView";

        /// <summary>
        /// The pay identifier
        /// </summary>
        public const string PayId = "PayId";

        /// <summary>
        /// The pay period description
        /// </summary>
        public const string PayPeriodDescription = "PayPeriodDescription";

        /// <summary>
        /// The gross payroll audit log view mn
        /// </summary>
        public const string GrossPayrollAuditLogView_MV = "GrossPayrollAuditLogView_MN";

        /// <summary>
        /// The crew allowance details dialog view mv
        /// </summary>
        public const string CrewAllowanceDetailsDialogView_MV = "CrewAllowanceDetailsDialogView_MV";

        /// <summary>
        /// The payroll start view mv
        /// </summary>
        public const string PayrollStartView_MV = "PayrollStartView_MV";
        /// <summary>
        /// The vessel earn deduct summary navigation view mv
        /// </summary>
        public const string VesselEarnDeductSummaryNavigationView_MV = "VesselEarnDeductSummaryNavigationView_MV";
        /// <summary>
        /// The open payroll period dialog view mv
        /// </summary>
        public const string OpenPayrollPeriodDialogView_MV = "OpenPayrollPeriodDialogView_MV";
        /// <summary>
        /// The crew summary dialog view mv
        /// </summary>
        public const string CrewSummaryDialogView_MV = "CrewSummaryDialogView_MV";
        /// <summary>
        /// The crew payroll allotment summary view mv
        /// </summary>
        public const string CrewPayrollAllotmentSummaryView_MV = "CrewPayrollAllotmentSummaryView_MV";
        /// <summary>
        /// The post to accounts navigation view mv
        /// </summary>
        public const string PostToAccountsNavigationView_MV = "PostToAccountsNavigationView_MV";
        /// <summary>
        /// The post allotments view mv
        /// </summary>
        public const string PostAllotmentsView_MV = "PostAllotmentsView_MV";
        /// <summary>
        /// The crew summary start view mv
        /// </summary>
        public const string CrewSummaryStartView_MV = "CrewSummaryStartView_MV";

        /// <summary>
        /// The multi service crew summary start view mv
        /// </summary>
        public const string MultiServiceCrewSummaryStartView_MV = "MultiServiceCrewSummaryStartView_MV";

        /// <summary>
        /// The create direct payment invoice navigation view mv
        /// </summary>
        public const string CreateDirectPaymentInvoiceNavigationView_MV = "CreateDirectPaymentInvoiceNavigationView_MV";
        /// <summary>
        /// The request fund paycenter navigation view mv
        /// </summary>
        public const string RequestFundPaycenterNavigationView_MV = "RequestFundPaycenterNavigationView_MV";
        /// <summary>
        /// The edit payroll static input navigation view mv
        /// </summary>
        public const string EditPayrollStaticInputNavigationView_MV = "EditPayrollStaticInputNavigationView_MV";
        /// <summary>
        /// The crew exclude include navigation view mv
        /// </summary>
        public const string CrewExcludeIncludeNavigationView_MV = "CrewExcludeIncludeNavigationView_MV";
        /// <summary>
        /// The exoprt allotments validations error dialog view mv
        /// </summary>
        public const string ExoprtAllotmentsValidationsErrorDialogView_MV = "ExoprtAllotmentsValidationsErrorDialogView_MV";
        /// <summary>
        /// The import allotments validations error dialog view mv
        /// </summary>
        public const string ImportAllotmentsValidationsErrorDialogView_MV = "ImportAllotmentsValidationsErrorDialogView_MV";
        /// <summary>
        /// The add edit crew initial balance view mv
        /// </summary>
        public const string AddEditCrewInitialBalanceView_MV = "AddEditCrewInitialBalanceView_MV";
        /// <summary>
        /// The invalid crew contract details dialog view mv
        /// </summary>
        public const string InvalidCrewContractDetailsDialogView_MV = "InvalidCrewContractDetailsDialogView_MV";

        /// <summary>
        /// The non approved crew details view mv
        /// </summary>
        public const string NonApprovedCrewDetailsDialogView_MV = "NonApprovedCrewDetailsDialogView_MV";

        /// <summary>
        /// The accumulator history dialog view mv
        /// </summary>
        public const string AccumulatorHistoryDialogView_MV = "AccumulatorHistoryDialogView_MV";
        /// <summary>
        /// The edit crew opening balance navigation view mv
        /// </summary>
        public const string EditCrewOpeningBalanceNavigationView_MV = "EditCrewOpeningBalanceNavigationView_MV";
        /// <summary>
        /// The duplicate allotment details dialog view mv
        /// </summary>
        public const string DuplicateAllotmentDetailsDialogView_MV = "DuplicateAllotmentDetailsDialogView_MV";
        /// <summary>
        /// The mismatch crew details dialog view mv
        /// </summary>
        public const string MismatchCrewDetailsDialogView_MV = "MismatchCrewDetailsDialogView_MV";
        /// <summary>
        /// The contractual earnings and contributions dialog view mv
        /// </summary>
        public const string ContractualEarningsAndContributionsDialogView_MV = "ContractualEarningsAndContributionsDialogView_MV";
        /// <summary>
        /// The reset pay period validation error dialog view mv
        /// </summary>
        public const string ResetPayPeriodValidationErrorDialogView_MV = "ResetPayPeriodValidationErrorDialogView_MV";

        /// <summary>
        /// The edit crew opening balance by crew identifier navigation view mv
        /// </summary>
        public const string EditCrewOpeningBalanceByCrewIdNavigationView_MV = "EditCrewOpeningBalanceByCrewIdNavigationView_MV";

        /// <summary>
        /// The add edit crew initial balance by crew identifier view mv
        /// </summary>
        public const string AddEditCrewInitialBalanceByCrewIdView_MV = "AddEditCrewInitialBalanceByCrewIdView_MV";

        /// <summary>
        /// The bulk adjustment navigation dilog view mv
        /// </summary>
        public const string BulkAdjustmentNavigationDilogView_MV = "BulkAdjustmentNavigationDilogView_MV";

        /// <summary>
        /// The add adjustment navigate dialog view mv
        /// </summary>
        public const string AddAdjustmentNavigateDialogView_MV = "AddAdjustmentNavigateDialogView_MV";

        /// <summary>
        /// The add edit crew accumulator details dialog view mv
        /// </summary>
        public const string AddEditCrewAccumulatorDetailsDialogView_MV = "AddEditCrewAccumulatorDetailsDialogView_MV";

        /// <summary>
        /// The add extra crew dialog view mv
        /// </summary>
        public const string AddExtraCrewDialogView_MV = "AddExtraCrewDialogView_MV";

        /// <summary>
        /// The gross payroll extra crew audit log view mv
        /// </summary>
        public const string GrossPayrollExtraCrewAuditLogView_MV = "GrossPayrollExtraCrewAuditLogView_MV";

        /// <summary>
        /// The add extra crew adjustment dialog view mv
        /// </summary>
        public const string AddExtraCrewAdjustmentDialogView_MV = "AddExtraCrewAdjustmentDialogView_MV";

        /// <summary>
        /// The extra crew summary start view mv
        /// </summary>
        public const string ExtraCrewSummaryStartView_MV = "ExtraCrewSummaryStartView_MV";


        /// <summary>
        /// The extra crew edit static input dialog view mv
        /// </summary>
        public const string ExtraCrewEditStaticInputDialogView_MV = "ExtraCrewEditStaticInputDialogView_MV";

        /// <summary>
        /// The extra crew summary start view
        /// </summary>
        public const string ExtraCrewSummaryStartView = "ExtraCrewSummaryStartView";
    }
}
