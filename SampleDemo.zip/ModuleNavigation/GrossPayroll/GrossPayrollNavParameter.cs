﻿namespace VShips.Framework.Common.ModuleNavigation.GrossPayroll
{
    /// <summary>
    /// GrossPayrollNavParameter Class
    /// </summary>
    public class GrossPayrollNavParameter
    {
        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObject { get; set; }

        /// <summary>
        /// Gets or sets the client setup identifier.
        /// </summary>
        /// <value>
        /// The client setup identifier.
        /// </value>
        public string ClientSetupId { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the pay period identifier.
        /// </summary>
        /// <value>
        /// The pay period identifier.
        /// </value>
        public string PayPeriodId { get; set; }

        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets the pay period.
        /// </summary>
        /// <value>
        /// The pay period.
        /// </value>
        public string PayPeriod { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the PPC identifier.
        /// </summary>
        /// <value>
        /// The PPC identifier.
        /// </value>
        public string PpcId { get; set; }

        /// <summary>
        /// Gets or sets the pay days.
        /// </summary>
        /// <value>
        /// The pay days.
        /// </value>
        public int PayDays { get; set; }


        /// <summary>
        /// Gets or sets the name of the client.
        /// </summary>
        /// <value>
        /// The name of the client.
        /// </value>
        public string ClientName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has crew list access.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has crew list access; otherwise, <c>false</c>.
        /// </value>
        public bool HasCrewListAccess { get; set; }

    }
}
