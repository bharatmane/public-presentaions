﻿namespace VShips.Framework.Common.ModuleNavigation.DrillsAndCampaigns
{
    /// <summary>
    /// Constants for Drills And Campaigns
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "DrillsAndCampaigns";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "DrillGeometry";

        //Views
        
        /// <summary>
        /// The start view for drills and campaigns.
        /// </summary>
        public const string StartView = "DrillsAndCampaignsStartView";

        /// <summary>
        /// The drills and campaigns browse view
        /// </summary>
        public const string DrillsAndCampaignsBrowseView = "DrillsAndCampaignsBrowseView";

        /// <summary>
        /// The drill history browse view
        /// </summary>
        public const string DrillHistoryBrowseView = "DrillHistoryBrowseView";

        /// <summary>
        /// The add drills navigation view
        /// </summary>
        public const string AddDrillsNavigationView = "AddDrillsNavigationView";

        /// <summary>
        /// The drill history dialogue view
        /// </summary>
        public const string DrillHistoryDialogueView = "DrillHistoryDialogueView";

        /// <summary>
        /// The map drills and campaigns view
        /// </summary>
        public const string MapDrillsAndCampaignsView = "MapDrillsAndCampaignsView";

        /// <summary>
        /// The report drills view
        /// </summary>
        public const string ReportDrillsView = "DrillReportWorkDoneNavigationView";

        /// <summary>
        /// The add edit drill participants view
        /// </summary>
        public const string AddEditDrillParticipantsView = "AddEditDrillParticipantsView";

        /// <summary>
        /// The reschedule drill dialog view
        /// </summary>
        public const string RescheduleDrillDialogView = "RescheduleDrillDialogView";

        /// <summary>
        /// The approver reschedule pending dialog view
        /// </summary>
        public const string ApproverReschedulePendingDialogView = "ApproverReschedulePendingDialogView";

        /// <summary>
        /// The reschedule history drill dialog view
        /// </summary>
        public const string RescheduleHistoryDrillDialogView = "RescheduleHistoryDrillDialogView";

        /// <summary>
        /// The change drill responsibility view.
        /// </summary>
        public const string ChangeDrillResponsibilityView = "ChangeDrillResponsibilityView";
        /// <summary>
        /// The drills add crew view
        /// </summary>
        public const string DrillsAddCrewView = "DrillsAddCrewView";
        /// <summary>
        /// The drill RWD confirm view
        /// </summary>
        public const string DrillRWDConfirmView = "DrillRWDConfirmView";
        /// <summary>
        /// The drill maintainer navigation view
        /// </summary>
        public const string DrillMaintainerNavigationView = "DrillMaintainerNavigationView";

        /// <summary>
        /// The view drill campaign audit log navigation view
        /// </summary>
        public const string ViewDrillCampaignAuditLogNavigationView = "ViewDrillCampaignAuditLogNavigationView";

        /// <summary>
        /// The drill campaign to be deleted list
        /// </summary>
        public const string DrillCampaignToBeDeletedListView = "DrillCampaignToBeDeletedListView";
    }
}