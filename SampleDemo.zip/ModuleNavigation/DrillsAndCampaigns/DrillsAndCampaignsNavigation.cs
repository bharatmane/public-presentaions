﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.ModuleNavigation.MarineMaintenance;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DrillsAndCampaigns
{
    /// <summary>
    /// Navigation Service for Drills And Campaigns Navigation.
    /// </summary>
    public class DrillsAndCampaignsNavigation : BaseModuleNavigationService, IDrillsAndCampaignsNavigation
    {
        #region Constructor

        /// <summary>
        /// The default constructor for the Drills and Campaigns.
        /// </summary>
        /// <param name="navigationService">The navigation service of type<see cref="INavigationService"/>.</param>
        public DrillsAndCampaignsNavigation(INavigationService navigationService)
            : base(navigationService) { }

        #endregion

        #region Methods

        /// <summary>
        /// Navigates to browse page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToBrowsePage(DrillsAndCampaignsParameter parameter)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.DrillsAndCampaignsBrowseView, parameter);
        }

        /// <summary>
        /// Navigates to add edit drills.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditDrills(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddDrillsNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to map drills and campaigns.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMapDrillsAndCampaigns(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapDrillsAndCampaignsView, context, parameter);
        }

        /// <summary>
        /// Navigates to report drills.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToReportDrills(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportDrillsView, context, parameter);
        }

        /// <summary>
        /// Navigates to add edit drill participants.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditDrillParticipants(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditDrillParticipantsView, context, parameter);
        }

        /// <summary>
        /// Navigate to rescheulde drill dialogue.
        /// </summary>
        /// <param name="context">The context</param>
        /// <param name="parameter">The parameter</param>
        public void NavigateToRescheduleDrillDialog(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RescheduleDrillDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to approver reschedule dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToApproverRescheduleDialog(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ApproverReschedulePendingDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to reschedule history dialig.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToRescheduleHistoryDialog(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RescheduleHistoryDrillDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates the drill history browse.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDrillHistoryBrowse(DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.DrillHistoryBrowseView, parameter);
        }

        /// <summary>
        /// Navigates the drill history dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDrillHistoryDialog(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DrillHistoryDialogueView, context, parameter);
        }

        /// <summary>
        /// Navigates the change drill responsibility.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateChangeDrillResponsibility(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ChangeDrillResponsibilityView, context, parameter);
        }

        /// <summary>Navigates the drill add crew.</summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="crewItems">The crew items.</param>
        /// <param name="isEditMode">if set to <c>true</c> [is edit mode].</param>
        /// <param name="isTestType">if set to <c>true</c> [is test type].</param>
        public void NavigateDrillAddCrew(INavigationContext context, string vesselId, object crewItems, bool isEditMode, bool isTestType)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId, vesselId},
                {NavigationParameterConstant.IsEditMode, isEditMode},
                {NavigationParameterConstant.SelectedCrew,crewItems},
                {NavigationParameterConstant.IsTestType, isTestType}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DrillsAddCrewView, context, parameters);
        }

        /// <summary>Navigates the drill RWD confirm crew.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="Remarks">The remarks.</param>
        /// <param name="CategoryName">Name of the category.</param>
        /// <param name="maxDate">The maximum date.</param>
        /// <param name="isTestType">if set to <c>true</c> [is test type].</param>
        public void NavigateDrillRWDConfirmCrew(INavigationContext context, string parentId, string Remarks,string CategoryName, DateTime? maxDate, bool isTestType)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {NavigationParameterConstant.ParentId, parentId},
                {NavigationParameterConstant.CategoryId, CategoryName},
                {NavigationParameterConstant.MaximumActionDate,maxDate},
                {NavigationParameterConstant.SharedObject, Remarks},
                {NavigationParameterConstant.IsTestType, isTestType}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DrillRWDConfirmView, context, parameters);
        }
        /// <summary>
        /// Navigates the drill maintainer view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDrillMaintainerView(INavigationContext context, MarineMaintenanceStartParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DrillMaintainerNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates to drill and campign overview page.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateToDrillAndCampignOverviewPage(INavigationContext context)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView, context);
        }

        /// <summary>
        /// Navigates the drill campaign audit log.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDrillCampaignAuditLog(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewDrillCampaignAuditLogNavigationView, context, parameter);
        }

        /// <summary>
        /// Navigates the drill campaign to be deleted list.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDrillCampaignToBeDeletedList(INavigationContext context, DrillsAndCampaignsParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DrillCampaignToBeDeletedListView, context, parameter);
        }

        #endregion
    }
}