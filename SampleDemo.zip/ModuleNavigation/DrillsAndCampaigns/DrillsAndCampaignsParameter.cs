﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;

namespace VShips.Framework.Common.ModuleNavigation.DrillsAndCampaigns
{
    /// <summary>
    /// DrillsAndCampaignsParameter Class
    /// </summary>
    public class DrillsAndCampaignsParameter
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets the vessel detail.
        /// </summary>
        /// <value>
        /// The vessel detail.
        /// </value>
        public VesselPreview VesselDetail { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance can edit view.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can edit view; otherwise, <c>false</c>.
        /// </value>
        public bool CanEditView { get; set; }

        /// <summary>
        /// Gets or sets the department identifier.
        /// </summary>
        /// <value>
        /// The department identifier.
        /// </value>
        public string DepartmentId { get; set; }
        
        /// <summary>
        /// Gets or sets the selected drill.
        /// </summary>
        /// <value>
        /// The selected drill.
        /// </value>
        public object SharedObject { get; set; }

        /// <summary>
        /// Gets or sets the VDC identifier.
        /// </summary>
        /// <value>
        /// The VDC identifier.
        /// </value>
        public string VdcId { get; set; }
        /// <summary>
        /// Gets or sets the DCD identifier.
        /// </summary>
        /// <value>
        /// The DCD identifier.
        /// </value>
        public string DcdId { get; set; }

        /// <summary>
        /// Gets or sets the VDH identifier.
        /// </summary>
        /// <value>
        /// The VDH identifier.
        /// </value>
        public string VdhId { get; set; }

        /// <summary>
        /// Gets or sets the group identifier.
        /// </summary>
        /// <value>
        /// The group identifier.
        /// </value>
        public string GroupId { get; set; }

        /// <summary>
        /// Gets or sets the done date.
        /// </summary>
        /// <value>
        /// The done date.
        /// </value>
        public DateTime? DoneDate { get; set; }

        /// <summary>
        /// Gets or sets the selected vessel.
        /// </summary>
        /// <value>
        /// The selected vessel.
        /// </value>
        public UserMenuItem SelectedVessel { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from dashboard.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from dashboard; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromDashboard { get; set; }

        /// <summary>
        /// Gets or sets the group ids.
        /// </summary>
        /// <value>
        /// The group ids.
        /// </value>
        public List<string> GroupIds { get; set; }
        /// <summary>
        /// Gets or sets the status ids.
        /// </summary>
        /// <value>
        /// The status ids.
        /// </value>
        public List<string> StatusIds { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is due.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is due; otherwise, <c>false</c>.
        /// </value>
        public bool IsDue { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is over due.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is over due; otherwise, <c>false</c>.
        /// </value>
        public bool IsOverDue { get; set; }

        /// <summary>
        /// Gets or sets the selected identifier.
        /// </summary>
        /// <value>
        /// The selected identifier.
        /// </value>
        public string SelectedId { get; set; }

        /// <summary>
        /// Gets or sets the selected day count.
        /// </summary>
        /// <value>
        /// The selected day count.
        /// </value>
        public int SelectedDayCount { get; set; }

        /// <summary>Gets or sets the name of the vessel.</summary>
        /// <value>The name of the vessel.</value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from not planned due.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from not planned due; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromNotPlannedDue { get; set; }
    }
}
