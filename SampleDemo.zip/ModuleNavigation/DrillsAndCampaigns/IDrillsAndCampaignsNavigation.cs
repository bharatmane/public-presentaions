﻿using System;
using VShips.Framework.Common.ModuleNavigation.MarineMaintenance;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.DrillsAndCampaigns
{
    /// <summary>
    /// Interface for Drills And Campaigns navigation.
    /// </summary>
    public interface IDrillsAndCampaignsNavigation
    {
        /// <summary>
        /// Navigates to browse page.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateToBrowsePage(DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates to add edit drills.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditDrills(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates to map drills and campaigns.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToMapDrillsAndCampaigns(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates to report drills.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToReportDrills(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates to add edit drill participants.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditDrillParticipants(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigate to rescheulde drill dialogue.
        /// </summary>
        /// <param name="context">The context</param>
        /// <param name="parameter">The parameter</param>
        void NavigateToRescheduleDrillDialog(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates to approver reschedule dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToApproverRescheduleDialog(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates to reschedule history dialig.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToRescheduleHistoryDialog(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates the drill history browse.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateDrillHistoryBrowse(DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates the drill history dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDrillHistoryDialog(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>
        /// Navigates the change drill responsibility.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateChangeDrillResponsibility(INavigationContext context, DrillsAndCampaignsParameter parameter);

        /// <summary>Navigates the drill add crew.</summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="crewItems">The crew items.</param>
        /// <param name="isEditMode">if set to <c>true</c> [is edit mode].</param>
        /// <param name="isTestType">if set to <c>true</c> [is test type].</param>
        void NavigateDrillAddCrew(INavigationContext context, string vesselId, object crewItems,bool isEditMode, bool isTestType);

        /// <summary>Navigates the drill RWD confirm crew.</summary>
        /// <param name="context">The context.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="Remarks">The remarks.</param>
        /// <param name="CategoryName">Name of the category.</param>
        /// <param name="maxDate">The maximum date.</param>
        /// <param name="isTestType">if set to <c>true</c> [is test type].</param>
        void NavigateDrillRWDConfirmCrew(INavigationContext context, string parentId, string Remarks, string CategoryName, DateTime? maxDate, bool isTestType);

        /// <summary>
        /// Navigates the drill maintainer view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDrillMaintainerView(INavigationContext context, MarineMaintenanceStartParameter parameter);

        /// <summary>
        /// Navigates to drill and campign overview page.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateToDrillAndCampignOverviewPage(INavigationContext context);

        /// <summary>
        /// Navigates the drill campaign audit log.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDrillCampaignAuditLog(INavigationContext context, DrillsAndCampaignsParameter parameter);
        /// <summary>
        /// Navigates the drill campaign to be deleted list.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDrillCampaignToBeDeletedList(INavigationContext context, DrillsAndCampaignsParameter parameter);
    }
}