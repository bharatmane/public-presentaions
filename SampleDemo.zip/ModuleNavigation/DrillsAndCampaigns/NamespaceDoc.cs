﻿namespace VShips.Framework.Common.ModuleNavigation.DrillsAndCampaigns
{
    /// <summary>
    /// Services and constants relating to the Drills And Campaigns module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}