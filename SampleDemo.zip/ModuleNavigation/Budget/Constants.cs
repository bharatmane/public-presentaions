﻿namespace VShips.Framework.Common.ModuleNavigation.Budget
{
    /// <summary>
    /// Names of accessible views and regions related to the budget module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "Budget";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "ShipManagementGeometry";

        /// <summary>
        /// The new opportunities icon
        /// </summary>
        public const string NewOpportunitiesIcon = "NewOpportunitiesGeometry";


        //Views

        /// <summary>The landing or start view for the budget module.</summary>
        public const string StartView = "BudgetStartView";

        /// <summary>
        /// The edit bid requset view opens on Edit bid requset click 
        /// </summary>
        public const string EditBidRequestView = "EditBidRequestView";

        /// <summary>
        /// The create budget option view
        /// </summary>
        public const string CreateBudgetOptionView = "CreateBudgetOptionView";


        /// <summary>
        /// The budget option start view
        /// </summary>
        public const string BudgetOptionStartView = "BudgetOptionStartView";

        /// <summary>
        /// The copy from previous budget view
        /// </summary>
        public const string CopyFromPreviousBudgetView = "CopyFromPreviousBudgetView";

        /// <summary>
        /// The update overtime hours or overlap
        /// </summary>
        public const string UpdateOvertimeHoursOrOverlap = "UpdateOverTimeHoursOrOverlap";

        /// <summary>
        /// The add item view
        /// </summary>
        public const string AddItemView = "AddItemView";

        /// <summary>
        /// The bid request to validate
        /// </summary>
        public const string BidRequestToValidate = "BidDetailsToValidate";

        /// <summary>
        /// The bid request identifier
        /// </summary>
        public const string BidRequestId = "BidRequestId";

        /// <summary>
        /// The bid request number
        /// </summary>
        public const string BidRequestNumber = "BidRequestNumber";

        /// <summary>
        /// The is add bid request
        /// </summary>
        public const string IsAddBidRequest = "IsAddBidRequest";

        /// <summary>
        /// The budget details
        /// </summary>
        public const string BudgetDetails = "BudgetDetails";

        /// <summary>
        /// The group services
        /// </summary>
        public const string GroupServices = "GroupServices";

        /// <summary>
        /// The crew complement
        /// </summary>
        public const string CrewComplement = "CrewComplement";

        /// <summary>
        /// The navigate supporting document
        /// </summary>
        public const string NavigateSupportingDocument = "BudgetSupportingDocNavigationViewModel";

        /// <summary>
        /// The budget option identifier
        /// </summary>
        public const string BudgetOptionId = "BudgetOptionId";

        /// <summary>
        /// The document identifier
        /// </summary>
        public const string DocumentId = "DocumentId";

        /// <summary>
        /// The files to upload
        /// </summary>
        public const string FilesToUpload = "FilesToUpload";

        /// <summary>
        /// The budget inclusion exclusion view
        /// </summary>
        public const string BudgetInclusionExclusionView = "BudgetInclusionExclusionView";

        /// <summary>
        /// The change bid request scope
        /// </summary>
        public const string ChangeBidRequestScope = "ChangeBidRequestScope";

        /// <summary>
        /// The no assumption data found view
        /// </summary>
        public const string NoAssumptionDataFoundView = "NoAssumptionDataFoundView";

        /// <summary>
        /// The budget analysis
        /// </summary>
        public const string BudgetAnalysis = "BudgetAnalysisView";

        /// <summary>
        /// The copy budget view
        /// </summary>
        public const string CopyBudgetView = "CopyBudgetView";

        /// <summary>
        /// Copy Budget Account Code Mapping View
        /// </summary>
        public const string CopyBudgetAccountCodeMappingView = "CopyBudgetAccountCodeMappingView";

        /// <summary>
        /// The list of budget
        /// </summary>
        public const string ListOfBudget = "ListOfBudget";

        /// <summary>
        /// The selected paged index
        /// </summary>
        public const string SelectedPagedIndex = "SelectedPagedIndex";

        /// <summary>
        /// The current budget option identifier
        /// </summary>
        public const string CurrentBudgetOptionId = "CurrentBudgetOptionId";

        /// <summary>
        /// The is from finance
        /// </summary>
        public const string IsFromFinance = "IsFromFinance";

        /// <summary>
        /// The is copy from actual
        /// </summary>
        public const string IsCopyFromActual = "IsCopyFromActual";

        /// <summary>
        /// The target chart header identifier
        /// </summary>
        public const string TargetChartHeaderId = "TargetChartHeaderId";

        /// <summary>
        /// The target chart header desc
        /// </summary>
        public const string TargetChartHeaderDesc = "TargetChartHeaderDesc";

        /// <summary>
        /// the Source Chart Header Desc 
        /// </summary>
        public const string SourceChartHeaderDesc = "SourceChartHeaderDesc";

        /// <summary>
        /// The list of budget operational charts mapping
        /// </summary>
        public const string ListOfBudgetOperationalChartsMapping = "ListOfBudgetOperationalChartsMapping";

        /// <summary>
        ///the copied budget request.
        /// </summary>
        public const string CopiedBudgetRequest = "CopiedBudgetRequest";

        /// <summary>
        ///the copied budget request.
        /// </summary>
        public const string PreviousBudgetFilter = "previousBudgetFilter";

        /// <summary>
        /// Copy Budget Account Code Mapping View
        /// </summary>
        public const string EditCrewComplementView = "EditCrewComplementView";

        /// <summary>
        /// Copy Budget Account Code Mapping View
        /// </summary>
        public const string CrewComplementCount = "CrewComplementCount";

        /// <summary>
        /// Copy Budget Account Code Mapping View
        /// </summary>
        public const string BudgetOption = "BudgetOption";

        /// <summary>
        /// The edit crew projection view
        /// </summary>
        public const string EditCrewProjectionView = "EditCrewProjectionView";

        /// <summary>
        /// The cba cost element view
        /// </summary>
        public const string EditBidInformationView = "EditBidInformationView";

        /// <summary>
        /// The cba cost element view
        /// </summary>
        public const string CbaCostElementsView = "CbaCostElementsView";

        /// <summary>
        /// The speculative daily opex view
        /// </summary>
        public const string SpeculativeDailyOpexView = "SpeculativeDailyOpexView";

        /// <summary>
        /// The manning per vessel type start view
        /// </summary>
        public const string ManningPerVesselTypeStartView = "ManningPerVesselTypeStartView";

        /// <summary>
        /// The port agency start view
        /// </summary>
        public const string PortAgencyStartView = "PortAgencyStartView";

        /// <summary>
        /// The port agency start view
        /// </summary>
        public const string PortAgencyAddEditCloneYearView = "PortAgencyAddEditCloneYearView";

        /// <summary>
        /// The action
        /// </summary>
        public const string Action = "Action";

        /// <summary>
        /// The budget menu item type
        /// </summary>
        public const string BudgetMenuItemType = "BudgetMenuItemType";

        /// <summary>
        /// The maintainer header identifier
        /// </summary>
        public const string MaintainerHeaderId = "MaintainerHeaderId";

        /// <summary>
        /// The budget assumption start view
        /// </summary>
        public const string BudgetAssumptionStartView = "BudgetAssumptionStartView";

        /// <summary>
        /// The budget assumption add edit clone year view
        /// </summary>
        public const string BudgetAssumptionAddEditCloneYearView = "BudgetAssumptionAddEditCloneYearView";

        /// <summary>
        /// The fixed invoices start view
        /// </summary>
        public const string FixedInvoicesStartView = "FixedInvoicesStartView";

        /// <summary>
        /// The fixed invoices add edit clone year view
        /// </summary>
        public const string FixedInvoicesAddEditCloneYearView = "FixedInvoicesAddEditCloneYearView";

        /// <summary>
        /// The add nationality or vessel type view
        /// </summary>
        public const string AddNationalityOrVesselTypeView = "AddNationalityOrVesselTypeView";


        /// <summary>
        /// The contract length start view
        /// </summary>
        public const string ContractLengthStartView = "ContractLengthStartView";

        /// <summary>
        /// The add edit manning per vessel type view
        /// </summary>
        public const string AddEditManningPerVesselTypeView = "AddEditManningPerVesselTypeView";

        /// <summary>
        /// The add vessel type and rank view
        /// </summary>
        public const string AddVesselTypeAndRankView = "AddVesselTypeAndRankView";

        /// <summary>
        /// The cba wage scale start view
        /// </summary>
        public const string CbaWageScaleStartView = "CbaWageScaleStartView";

        /// <summary>
        /// The add edit clone year view Common view
        /// </summary>
        public const string AddEditCloneYearView = "AddEditCloneYearView";

        /// <summary>
        /// The add trading area view
        /// </summary>
        public const string AddTradingAreaView = "AddTradingAreaView";

        /// <summary>
        /// The existing data list
        /// </summary>
        public const string ExistingDataList = "ExistingDataList";

        /// <summary>
        /// The travel airfare start view
        /// </summary>
        public const string TravelAirfareStartView = "TravelAirfareStartView";

        /// <summary>
        /// The other crew cost assumption start view
        /// </summary>
        public const string OtherCrewCostAssumptionStartView = "OtherCrewCostAssumptionStartView";

        /// <summary>
        /// The other crew cost add edit clone year view
        /// </summary>
        public const string OtherCrewCostAddEditCloneYearView = "OtherCrewCostAddEditCloneYearView";

        /// <summary>
        /// The add cost element view
        /// </summary>
        public const string AddCostElementView = "AddCostElementView";

        /// <summary>
        /// The seniority add edit clone year view
        /// </summary>
        public const string SeniorityAddEditCloneYearView = "SeniorityAddEditCloneYearView";

        /// <summary>
        /// The seniority start view
        /// </summary>
        public const string SeniorityStartView = "SeniorityStartView";

        /// <summary>
        /// The add rank view
        /// </summary>
        public const string AddRankView = "AddRankView";

        /// <summary>
        /// The contract length add edit clone year view
        /// </summary>
        public const string ContractLengthAddEditCloneYearView = "ContractLengthAddEditCloneYearView";

        /// <summary>
        /// The add trading nationalities view
        /// </summary>
        public const string AddTradingNationalitiesView = "AddTradingNationalitiesView";

        /// <summary>
        /// The global assumption start view
        /// </summary>
        public const string GlobalAssumptionStartView = "GlobalAssumptionStartView";

        /// <summary>
        /// The victualing start view model
        /// </summary>
        public const string VictualingStartView = "VictualingStartView";

        /// <summary>
        /// The template identifier
        /// </summary>
        public const string TemplateId = "TemplateId";

        /// <summary>
        /// The victualing add edit template view
        /// </summary>
        public const string VictualingAddEditTemplateView = "VictualingAddEditTemplateView";

        /// <summary>
        /// The crew budget cost element start view
        /// </summary>
        public const string CrewBudgetCostElementStartView = "CrewBudgetCostElementStartView";

        /// <summary>
        /// The crew projection year item view
        /// </summary>
        public const string CrewProjectionYearItemView = "CrewProjectionYearItemView";

        /// <summary>
        /// The add year view
        /// </summary>
        public const string AddYearView = "AddYearView";

        /// <summary>
        /// The is wages
        /// </summary>
        public const string IsWages = "IsWages";

        /// <summary>
        /// The existing budget start view
        /// </summary>
        public const string ExistingBudgetsStartView = "ExistingBudgetsStartView";

        /// <summary>
        /// The new vessel budget view
        /// </summary>
        public const string NewVesselBudgetView = "NewVesselBudgetView";

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";

        /// <summary>
        /// The coy identifier
        /// </summary>
        public const string CoyId = "CoyId";

        /// <summary>
        /// The clone renew budget view
        /// </summary>
        public const string CloneRenewBudgetView = "CloneRenewBudgetView";

        /// <summary>
        /// The year
        /// </summary>
        public const string Year = "Year";

        /// <summary>
        /// The select vessel view
        /// </summary>
        public const string SelectVesselView = "SelectVesselView";

        /// <summary>
        /// The new clone renew budget view
        /// </summary>
        public const string NewCloneRenewBudgetView = "NewCloneRenewBudgetView";

        /// <summary>
        /// The select default nationalities view
        /// </summary>
        public const string SelectDefaultNationalitiesView = "SelectDefaultNationalitiesView";

        /// <summary>
        /// The officers nationality identifier
        /// </summary>
        public const string OfficersNationalityId = "OfficersNationalityId";

        /// <summary>
        /// The ratings nationality identifier
        /// </summary>
        public const string RatingsNationalityId = "RatingsNationalityId";

        /// <summary>
        /// The get default nationalities action
        /// </summary>
        public const string GetDefaultNationalitiesAction = "GetDefaultNationalitiesAction";

        /// <summary>
        /// The add edit bid request view
        /// </summary>
        public const string AddEditBidRequestView = "AddEditBidRequestView";

        /// <summary>
        /// The commit budget summary dialog view
        /// </summary>
        public const string CommitBudgetSummaryDialogView = "CommitBudgetSummaryDialogView";

        /// <summary>
        /// The budget management vessel lookup view
        /// </summary>
        public const string BudgetManagementVesselLookupView = "BudgetManagementVesselLookupView";

        /// <summary>
        /// The selected vessel changed
        /// </summary>
        public const string SelectedVesselChanged =  "SelectedVesselChanged";

        /// <summary>
        /// The vessel filter
        /// </summary>
        public const string VesselFilter = "VesselFilter";

        /// <summary>
        /// The crew complement source
        /// </summary>
        public const string CrewComplementSource = "CrewComplementSource";

        /// <summary>
        /// The update nationality actions
        /// </summary>
        public const string UpdateNationalityActions = "UpdateNationalityActions";

		/// <summary>
		/// The budget apply all distribution dialog view
		/// </summary>
		public const string CostDistributionDialogView = "CostDistributionDialogView";

        /// <summary>
        /// The budget forecasting navigation view
        /// </summary>
        public const string BudgetForecastingNavigationView = "BudgetForecastingNavigationView";

        /// <summary>
        /// The budget comparator start view
        /// </summary>
        public const string BudgetComparatorStartView = "BudgetComparatorStartView";
        /// <summary>
        /// The import budget view
        /// </summary>
        public const string ImportBudgetView = "ImportBudgetView";

        /// <summary>
        /// The import budget validation view
        /// </summary>
        public const string ImportBudgetValidationView = "ImportBudgetValidationView";
    }
}