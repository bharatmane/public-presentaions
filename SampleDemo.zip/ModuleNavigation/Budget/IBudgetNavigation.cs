﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Budget;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Budget
{
    /// <summary>
    /// Navigation service for the budget module.
    /// </summary>
    public interface IBudgetNavigation
    {
        /// <summary>
        /// Navigates to the budget module start view.
        /// </summary>
        void NavigateStart();

        /// <summary>
        /// Navigates the edit bid request.
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="bidRequestId"></param>
        /// <param name="bidRequestNumber"></param>
        /// <param name="isAddBidRequest"></param>
        void NavigateEditBidRequest(INavigationContext navigationContext, string bidRequestId, string bidRequestNumber, bool isAddBidRequest);


        /// <summary>
        /// Navigates the create budget option.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="bidDetailsToValidate">The bid details to validate.</param>
        /// <param name="bidRequestId">The bid request identifier.</param>
        /// <param name="budgetDetails">The budget details.</param>
        /// <param name="changeEditBidRequsetScope">The change edit bid requset scope.</param>
        void NavigateCreateBudgetOption(INavigationContext navigationContext, BidRequestDetailToValidateBudget bidDetailsToValidate, string bidRequestId, CreateBudgetOptionRequest budgetDetails, Action changeEditBidRequsetScope);

        /// <summary>
        /// Navigates the budget option detail.
        /// </summary>
        /// <param name="paramter">The paramter.</param>
        void NavigateBudgetOptionDetail(object paramter);


        /// <summary>
        /// Navigates the copy from previous budget.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateCopyFromPreviousBudget(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the update overtime hours or overlap.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetId">The budget identifier.</param>
        void NavigateUpdateOvertimeHoursOrOverlap(INavigationContext navigationContext, string budgetId);

        /// <summary>
        /// Navigates the add item.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddItem(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add supporting document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetOptionId">The budget option identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        void NavigateAddSupportingDocument(INavigationContext navigationContext, string budgetOptionId, string documentId, IEnumerable<string> fileNames);

        /// <summary>
        /// Navigates the budget inclusion exclusion.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The paarmeter passed during navigation.</param>
        void NavigateBudgetInclusionExclusion(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the no assumption data found.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="zeroTotalList">The zero total list.</param>
        /// <param name="isSeniority">if set to <c>true</c> [is seniority].</param>
        void NavigateNoAssumptionDataFound(INavigationContext navigationContext, object zeroTotalList, bool isSeniority);

        /// <summary>
        /// Navigates the budget analysis.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateBudgetAnalysis(object parameter);

        /// <summary>
        /// Navigates the edit crew projection.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetOptionId">The budget option identifier.</param>
        void NavigateEditCrewProjection(INavigationContext navigationContext, string budgetOptionId);

        /// <summary>
        /// Navigates the view copy budget.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="filteredBudgetDetailsList">The filtered budget details list.</param>
        /// <param name="selectedPagedIndex">Index of the selected paged.</param>
        /// <param name="previousBudgetFilter">The previous budget filter.</param>
        /// <param name="targetChhId">The target CHH identifier.</param>
        /// <param name="targetChhDesc">The target CHH desc.</param>
        void NavigateViewCopyBudget(INavigationContext navigationContext, object filteredBudgetDetailsList, int selectedPagedIndex, object previousBudgetFilter, string targetChhId, string targetChhDesc);

        /// <summary>
        /// Navigates the Copy Budget Account Code Mapping View.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="listOfBudgetOperationalChartsMapping">The list of budget operational charts mapping.</param>
        /// <param name="sourceChhDesc">The source CHH desc.</param>
        /// <param name="targetChhDesc">The target CHH desc.</param>
        /// <param name="request">The request.</param>
        void NavigateCopyBudgetAccountCodeMapping(INavigationContext navigationContext, List<BudgetOperationalChartsMapping> listOfBudgetOperationalChartsMapping, string sourceChhDesc, string targetChhDesc, CopiedPostedBudgetHeader request);

        /// <summary>
        /// Navigates the edit crew complement.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetOptionId">The budget option identifier.</param>
        /// <param name="crewComplementCount">The crew complement count.</param>
        /// <param name="budgetOption">The budget option.</param>
        void NavigateEditCrewComplement(INavigationContext navigationContext, string budgetOptionId, string crewComplementCount, object budgetOption);

        /// <summary>
        /// Navigates the edit bid information.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="bidRequestId">The bid request identifier.</param>
        /// <param name="budgetBidRequestType">Type of the budget bid request.</param>
        void NavigateEditBidInformation(INavigationContext navigationContext, string bidRequestId, BudgetBidRequestType budgetBidRequestType);

        /// <summary>
        /// Navigates the speculative daily opex view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedBidRequest">The selected bid request.</param>
        void NavigateSpeculativeDailyOpexView(INavigationContext navigationContext, object selectedBidRequest);

        /// <summary>
        /// Navigates the port agency add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="headerId">The header identifier.</param>
        /// <param name="Action">The action.</param>
        void NavigatePortAgencyAddEditCloneYearView(INavigationContext navigationContext, string headerId, object Action);

        /// <summary>
        /// Navigates the budget assumption add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The 
        void NavigateBudgetAssumptionAddEditCloneYearView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the fixed invoices add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="headerId">The header identifier.</param>
        /// <param name="Action">The action.</param>
        void NavigateFixedInvoicesAddEditCloneYearView(INavigationContext navigationContext, string headerId, object Action);

        /// <summary>
        /// Navigates the add nationality or vessel type view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="type">The type.</param>
        void NavigateAddNationalityOrVesselTypeView(INavigationContext navigationContext, object type);


        /// <summary>
        /// Navigates the type of the add edit manning per vessel.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddEditManningPerVesselType(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add vessel type and rank.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddVesselTypeAndRank(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddEditCloneYearView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add trading area view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="existingDataList">The existing data list.</param>
        /// <param name="action">The action.</param>
        void NavigateAddTradingAreaView(INavigationContext navigationContext, List<string> existingDataList, object action);

        /// <summary>
		/// Navigates the port agency add edit clone year view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="headerId">The header identifier.</param>
		/// <param name="Action">The action.</param>
		void NavigateOtherCrewCostAddEditCloneYearView(INavigationContext navigationContext, string headerId, object Action);

        /// <summary>
        /// Navigates the add cost element view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="existingDataList">The existing data list.</param>
        /// <param name="action">The action.</param>
        /// <param name="budgetMenuItemType">Type of the budget menu item.</param>
        /// <param name="isWages">if set to <c>true</c> [is wages].</param>
        void NavigateAddCostElementView(INavigationContext navigationContext, List<string> existingDataList, object action, BudgetMenuItemType budgetMenuItemType, bool isWages);

        /// <summary>
        /// Navigates the seniority add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateSeniorityAddEditCloneYearView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add rank.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddRank(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the budget assumption add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateContractLengthAddEditCloneYearView(INavigationContext navigationContext, object parameter);


        /// <summary>
        /// Navigates the add nationalities
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="existingDataList">The existing data list.</param>
        /// <param name="action">The action.</param>
        void NavigateAddNationalitiesView(INavigationContext navigationContext, List<string> existingDataList, object action);

        /// <summary>
        /// Navigates the victualing add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="templateId">The template identifier.</param>
        /// <param name="action">The action.</param>
        void NavigateVictualingAddEditView(INavigationContext navigationContext, string templateId, object action);

        /// <summary>
        /// Navigates the crew projection add year.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateCrewProjectionAddYear(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the clone renew budget view.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateCloneRenewBudgetView(object parameters, INavigationContext navigationContext);

        /// <summary>
        /// Navigates the new vessel budget view.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="year">The year.</param>
        void NavigateNewVesselBudgetView(string vesselId, string coyId, DateTime year);

        /// <summary>
        /// Navigates the select vessel view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateSelectVesselView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the new clone renew budget view.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateNewCloneRenewBudgetView(object parameters, INavigationContext navigationContext);

        /// <summary>
        /// Navigates the select default nationalities view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateSelectDefaultNationalitiesView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates the add edit bid request view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddEditBidRequestView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates the commit budget summary dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateCommitBudgetSummaryDialogView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates the budget management vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVesselChanged">The selected vessel changed.</param>
        /// <param name="vesselFilter">The vessel filter.</param>
        void NavigateBudgetManagementVesselLookupView(INavigationContext navigationContext, Action<object> selectedVesselChanged, object vesselFilter);

		/// <summary>
		/// Navigates the budget apply all distribution dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="budgetOptionId">The budget option identifier.</param>
		void NavigateCostDistributionDialogView(INavigationContext navigationContext, string budgetOptionId);

        /// <summary>
        /// Imports the budget view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void ImportBudgetView(INavigationContext navigationContext);

        /// <summary>
        /// Imports the budget validation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void ImportBudgetValidationView(INavigationContext navigationContext, object parameters);
    }
}