﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Contracts.Custom.Budget;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Budget
{
    /// <summary>
    /// Default implementation of the <see cref="IBudgetNavigation"/> service.
    /// </summary>
    public class BudgetNavigation : BaseModuleNavigationService, IBudgetNavigation
    {
        #region Constructor
        /// <summary>
        /// The default contructor for the BudgetNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public BudgetNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Navigates to the budget module start view.
        /// </summary>
        public void NavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Navigates the budget option detail.
        /// </summary>
        /// <param name="paramters">The paramters.</param>
        public void NavigateBudgetOptionDetail(object paramters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.BudgetOptionStartView, paramters);
        }

        /// <summary>
        /// Edits the bid request.
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="bidRequestId"></param>
        /// <param name="bidRequestNumber"></param>
        /// <param name="isAddBidRequest"></param>
        public void NavigateEditBidRequest(INavigationContext navigationContext, string bidRequestId, string bidRequestNumber, bool isAddBidRequest)
        {
            Dictionary<object, object> inputParameter = new Dictionary<object, object>
            {
                { Constants.BidRequestId, bidRequestId },
                { Constants.BidRequestNumber, bidRequestNumber  },
                { Constants.IsAddBidRequest, isAddBidRequest  }

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditBidRequestView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Creates the budget option.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="bidDetailsToValidate">The bid details to validate.</param>
        /// <param name="bidRequestId">The bid request identifier.</param>
        /// <param name="budgetDetails">The budget details.</param>
        /// <param name="changeEditBidRequsetScope">The change edit bid requset scope.</param>
        public void NavigateCreateBudgetOption(INavigationContext navigationContext, BidRequestDetailToValidateBudget bidDetailsToValidate, string bidRequestId, CreateBudgetOptionRequest budgetDetails, Action changeEditBidRequsetScope)
        {
            Dictionary<object, object> inputParameter = new Dictionary<object, object>
            {
                { Constants.BidRequestToValidate, bidDetailsToValidate },
                { Constants.BidRequestId, bidRequestId  },
                { Constants.BudgetDetails, budgetDetails },
                { Constants.ChangeBidRequestScope,changeEditBidRequsetScope }

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateBudgetOptionView, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the copy from previous budget.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter"></param>
        /// <exception cref="NotImplementedException"></exception>
        public void NavigateCopyFromPreviousBudget(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyFromPreviousBudgetView, navigationContext, parameter);
        }

        /// <summary>
        ///  Navigates the update overtime hours or overlap.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetId">The budget identifier.</param>
        public void NavigateUpdateOvertimeHoursOrOverlap(INavigationContext navigationContext, string budgetId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateOvertimeHoursOrOverlap, navigationContext, budgetId);
        }

        /// <summary>
        /// Navigates the add item.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddItem(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddItemView, navigationContext, parameter);
        }



        /// <summary>
        /// Navigates the budget inclusion exclusion.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The paarmeter passed during navigation.</param>
        public void NavigateBudgetInclusionExclusion(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BudgetInclusionExclusionView, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates the add supporting document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetOptionId">The budget option identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="fileNames">The file names.</param>
        public void NavigateAddSupportingDocument(INavigationContext navigationContext, string budgetOptionId, string documentId, IEnumerable<string> fileNames)
        {
            Dictionary<object, object> inputParameter = new Dictionary<object, object>
            {
                { Constants.BudgetOptionId, budgetOptionId },
                { Constants.DocumentId,documentId },
                { Constants.FilesToUpload, fileNames != null ? fileNames.ToList() : new List<string>() }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NavigateSupportingDocument, navigationContext, inputParameter);
        }

        /// <summary>
        /// Navigates the no assumption data found.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="zeroTotalList">The zero total list.</param>
        /// <param name="isSeniority">if set to <c>true</c> [is seniority].</param>
        public void NavigateNoAssumptionDataFound(INavigationContext navigationContext, object zeroTotalList, bool isSeniority)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.NoAssumptionList, zeroTotalList},
                { NavigationParameterConstant.IsSeniority, isSeniority}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NoAssumptionDataFoundView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the budget analysis.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateBudgetAnalysis(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.BudgetAnalysis, parameter);
        }

        /// <summary>
        /// Navigates the view budget.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="filteredBudgetDetailsList">The filtered budget details list.</param>
        /// <param name="selectedPagedIndex">Index of the selected paged.</param>
        /// <param name="previousBudgetFilter"></param>
        /// <param name="targetChhId">The target CHH identifier.</param>
        /// <param name="targetChhDesc">The target CHH desc.</param>
        public void NavigateViewCopyBudget(INavigationContext navigationContext, object filteredBudgetDetailsList, int selectedPagedIndex, object previousBudgetFilter, string targetChhId, string targetChhDesc)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.ListOfBudget, filteredBudgetDetailsList},
                { Constants.SelectedPagedIndex, selectedPagedIndex},
                { Constants.PreviousBudgetFilter, previousBudgetFilter},
                { Constants.TargetChartHeaderId, targetChhId},
                { Constants.TargetChartHeaderDesc, targetChhDesc}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyBudgetView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the Copy Budget Account Code Mapping View.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="listOfBudgetOperationalChartsMapping">The list of budget operational charts mapping.</param>
        /// <param name="sourceChhDesc">The source CHH desc.</param>
        /// <param name="targetChhDesc">The target CHH desc.</param>
        /// <param name="request">The request.</param>
        public void NavigateCopyBudgetAccountCodeMapping(INavigationContext navigationContext, List<BudgetOperationalChartsMapping> listOfBudgetOperationalChartsMapping, string sourceChhDesc, string targetChhDesc, CopiedPostedBudgetHeader request)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.ListOfBudgetOperationalChartsMapping, listOfBudgetOperationalChartsMapping},
                { Constants.SourceChartHeaderDesc, sourceChhDesc},
                { Constants.TargetChartHeaderDesc, targetChhDesc},
                { Constants.CopiedBudgetRequest, request}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyBudgetAccountCodeMappingView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the edit crew complement.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetOptionId">The budget option identifier.</param>
        /// <param name="crewComplementCount">The crew complement count.</param>
        /// <param name="budgetOption">The budget option.</param>
        public void NavigateEditCrewComplement(INavigationContext navigationContext, string budgetOptionId, string crewComplementCount, object budgetOption)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.BudgetOptionId, budgetOptionId },
                { Constants.CrewComplementCount, crewComplementCount},
                { Constants.BudgetOption, budgetOption}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewComplementView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the edit crew projection.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="budgetOptionId">The budget option identifier.</param>
        public void NavigateEditCrewProjection(INavigationContext navigationContext, string budgetOptionId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditCrewProjectionView, navigationContext, budgetOptionId);
        }

        /// <summary>
        /// Navigates the edit bid information.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="bidRequestId">The bid request identifier.</param>
        /// <param name="budgetBidRequestType">Type of the budget bid request.</param>
        public void NavigateEditBidInformation(INavigationContext navigationContext, string bidRequestId, BudgetBidRequestType budgetBidRequestType)
        {
            Dictionary<string, object> param = new Dictionary<string, object>();
            param.Add(Constants.BidRequestId, bidRequestId);
            param.Add(Constants.Action, budgetBidRequestType);
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditBidInformationView, navigationContext, param);
        }

        /// <summary>
        /// Navigates the port agency add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="headerId">The header identifier.</param>
        /// <param name="Action">The action.</param>
        public void NavigatePortAgencyAddEditCloneYearView(INavigationContext navigationContext, string headerId, object Action)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.MaintainerHeaderId, headerId},
                { Constants.Action, Action},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PortAgencyAddEditCloneYearView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the budget assumption add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateBudgetAssumptionAddEditCloneYearView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BudgetAssumptionAddEditCloneYearView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the fixed invoices add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="headerId">The header identifier.</param>
        /// <param name="Action">The action.</param>
        public void NavigateFixedInvoicesAddEditCloneYearView(INavigationContext navigationContext, string headerId, object Action)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.MaintainerHeaderId, headerId},
                { Constants.Action, Action},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedInvoicesAddEditCloneYearView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add nationality or vessel type view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="type">The type.</param>
        public void NavigateAddNationalityOrVesselTypeView(INavigationContext navigationContext, object type)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddNationalityOrVesselTypeView, navigationContext, type);
        }


        /// <summary>
        /// Navigates the speculative daily opex view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedBidRequest">The selected bid request.</param>
        public void NavigateSpeculativeDailyOpexView(INavigationContext navigationContext, object selectedBidRequest)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SpeculativeDailyOpexView, navigationContext, selectedBidRequest);//, navigationContext, selectedBidRequest);
        }

        /// <summary>
        /// Navigates the type of the add edit manning per vessel.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddEditManningPerVesselType(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditManningPerVesselTypeView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add vessel type and rank.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddVesselTypeAndRank(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddVesselTypeAndRankView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddEditCloneYearView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCloneYearView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add trading area view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="existingDataList">The existing data list.</param>
        /// <param name="action">The action.</param>
        public void NavigateAddTradingAreaView(INavigationContext navigationContext, List<string> existingDataList, object action)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.ExistingDataList, existingDataList},
                { Constants.Action, action},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddTradingAreaView, navigationContext, parameter);
        }

        /// <summary>
		/// Navigates the port agency add edit clone year view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="headerId">The header identifier.</param>
		/// <param name="Action">The action.</param>
		public void NavigateOtherCrewCostAddEditCloneYearView(INavigationContext navigationContext, string headerId, object Action)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.MaintainerHeaderId, headerId},
                { Constants.Action, Action},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OtherCrewCostAddEditCloneYearView, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates the add cost element view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="existingDataList">The existing data list.</param>
        /// <param name="action">The action.</param>
        /// <param name="budgetMenuItemType">Type of the budget menu item.</param>
        /// <param name="isWages">if set to <c>true</c> [is wages].</param>
        public void NavigateAddCostElementView(INavigationContext navigationContext, List<string> existingDataList, object action, BudgetMenuItemType budgetMenuItemType, bool isWages)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.ExistingDataList, existingDataList},
                { Constants.Action, action},
                { Constants.BudgetMenuItemType, budgetMenuItemType },
                {Constants.IsWages, isWages }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCostElementView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the seniority add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateSeniorityAddEditCloneYearView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SeniorityAddEditCloneYearView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add rank.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddRank(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddRankView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the budget assumption add edit clone year view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateContractLengthAddEditCloneYearView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ContractLengthAddEditCloneYearView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add nationalities
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="existingDataList">The existing data list.</param>
        /// <param name="action">The action.</param>
        public void NavigateAddNationalitiesView(INavigationContext navigationContext, List<string> existingDataList, object action)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.ExistingDataList, existingDataList},
                { Constants.Action, action},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddTradingNationalitiesView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the victualing add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="templateId">The template identifier.</param>
        /// <param name="action">The action.</param>
        public void NavigateVictualingAddEditView(INavigationContext navigationContext, string templateId, object action)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.TemplateId, templateId},
                { Constants.Action, action},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VictualingAddEditTemplateView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the crew projection add year.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateCrewProjectionAddYear(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddYearView, navigationContext);
        }

        /// <summary>
        /// Navigates the clone renew budget view.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateCloneRenewBudgetView(object parameters, INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CloneRenewBudgetView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the new vessel budget view.
        /// </summary>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="year">The year.</param>
        public void NavigateNewVesselBudgetView(string vesselId, string coyId, DateTime year)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.VesselId, vesselId},
                { Constants.CoyId, coyId},
                { Constants.Year, year},
            };
            NavigationService.NavigateNew(Constants.ModuleName, Constants.NewVesselBudgetView, parameter);
        }

        /// <summary>
        /// Navigates the select vessel view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateSelectVesselView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectVesselView, navigationContext);
        }

        /// <summary>
        /// Navigates the new clone renew budget view.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateNewCloneRenewBudgetView(object parameters, INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NewCloneRenewBudgetView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the select default nationalities view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateSelectDefaultNationalitiesView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SelectDefaultNationalitiesView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add edit bid request view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddEditBidRequestView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditBidRequestView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the commit budget summary dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateCommitBudgetSummaryDialogView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommitBudgetSummaryDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the budget management vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVesselChanged">The selected vessel changed.</param>
        /// <param name="vesselFilter">The vessel filter.</param>
        public void NavigateBudgetManagementVesselLookupView(INavigationContext navigationContext, Action<object> selectedVesselChanged, object vesselFilter)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.SelectedVesselChanged, selectedVesselChanged},
                { Constants.VesselFilter, vesselFilter}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BudgetManagementVesselLookupView, navigationContext, parameters);
        }

		/// <summary>
		/// Navigates the budget apply all distribution dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="budgetOptionId">The budget option identifier.</param>
		public void NavigateCostDistributionDialogView(INavigationContext navigationContext, string budgetOptionId)
		{
			NavigationService.NavigateDialog(Constants.ModuleName, Constants.CostDistributionDialogView, navigationContext, budgetOptionId);
		}

        /// <summary>
        /// Imports the budget view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void ImportBudgetView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportBudgetView, navigationContext);
        }

        /// <summary>
        /// Imports the budget validation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void ImportBudgetValidationView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImportBudgetValidationView, navigationContext, parameters);
        }
        #endregion
    }
}