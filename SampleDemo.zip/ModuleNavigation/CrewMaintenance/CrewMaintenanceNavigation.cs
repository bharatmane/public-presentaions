﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Contracts.Custom.Crew;
using VShips.Contracts.DtoClasses.PayrollPayscaleTemplateMainTypes;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.ModuleNavigation.Common;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CrewMaintenance
{
    /// <summary>
    /// Navigation service for the Crew Maintenance module.
    /// </summary>
    public class CrewMaintenanceNavigation : BaseModuleNavigationService, ICrewMaintenanceNavigation
    {
        /// <summary>
        /// The default constructor.
        /// </summary>
        public CrewMaintenanceNavigation(INavigationService navigationService)
        : base(navigationService)
        {
        }

        /// <summary>
        /// Navigates to the Crew Maintenance module start view.
        /// </summary>
        public void NavigateStart()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }


        /// <summary>
        /// Navigate to document maintainer.
        /// </summary>
        public void CrewMaintainanceNavigateDocumentMaintainer()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.DocumentMaintainerStartView);
        }

        /// <summary>
        /// Navigate to rank maintainer.
        /// </summary>
        public void CrewMaintainanceNavigateRankMaintainer()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.RankMaintainerStartView);
        }

        /// <summary>
        /// Navigate to contract maintainer.
        /// </summary>
        public void CrewMaintainanceNavigateContractMaintainer()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.ContractMaintainerStartView);
        }

        /// <summary>
        /// Navigate to payscale template maintainer.
        /// </summary>
        public void CrewMaintainanceNavigatePayscaleTemplateMaintainer()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.PayscaleTemplateMaintainerStartView);
        }

        /// <summary>
        /// Crewings the navigate document maintainer add edit document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="documentGroupId">The document group identifier.</param>
        public void CrewingNavigateDocMaintainerAddEditDocument(INavigationContext navigationContext, object entity, string documentGroupId)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.Entity, entity },
                { Constants.DocumentGroupId, documentGroupId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditDocumentDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add crew document group view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateAddCrewDocumentGroupView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewDocumentGroupView, navigationContext);
        }

        /// <summary>
        /// Crews the maintainence rank maintainer add edit dailog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        public void CrewMaintainenceRankMaintainerAddEditDailogView(INavigationContext navigationContext, object entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditRankDialogView, navigationContext, entity);
        }

        /// <summary>
        /// Crews the maintainence rank maintainer department add edit dailog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        public void CrewMaintainenceRankMaintainerDepartmentAddEditDailogView(INavigationContext navigationContext, object entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditDepartmentDialogView, navigationContext, entity);
        }

        /// <summary>
        /// Crewings the navigate add edit department.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="departmentId">The department identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        public void CrewingNavigateAddEditDepartment(INavigationContext navigationContext, string departmentId, bool isEdit)
        {
            var parameters = new Dictionary<string, object>
            {
                {"departmentId", departmentId},{ "IsEdit", isEdit }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditDepartmentDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add payscale template.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedItems">The selected items.</param>
        public void CrewingNavigateAddPayscaleTemplate(INavigationContext navigationContext, List<PayscaleMap> selectedItems)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SelectedItems,selectedItems}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddPayscaleTemplateView, navigationContext, parameters);
        }

        /// <summary>
        /// Crewings the navigate add contract.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateAddContract(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddContractView, navigationContext);
        }

        /// <summary>
        /// Navigates to add contract template.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateAddContractTemplate(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddContractTemplateView, navigationContext);
        }

        /// <summary>
        /// Crewings the navigate crew pool vessel configuration.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateCrewPoolVesselConfiguration(INavigationContext navigationContext)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.CrewPoolVesselConfigurationStartView);
        }

        /// <summary>
        /// Crewings the navigate add crew pool detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewPoolSummary">The selected crew pool summary.</param>
        public void CrewingNavigateAddCrewPoolDetail(INavigationContext navigationContext, CrewPoolSummary selectedCrewPoolSummary)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewPoolDetailView, navigationContext, selectedCrewPoolSummary);
        }

        /// <summary>
        /// Navigates to planning fleet maintainer.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void PlanningFleetMaintainer(INavigationContext navigationContext)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.PlanningFleetMaintainerStartView);
        }

        /// <summary>
        /// Crewings the navigate add fleet dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void CrewingNavigateAddFleetDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddFleetDialogView, navigationContext);
        }

        /// <summary>
        /// The navigates to add appraisal form.
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="inEditMode"></param>
        public void NavigateToAddAppraisalForm(INavigationContext navigationContext, bool inEditMode)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAppraisalFormNavigationView, navigationContext, inEditMode);
        }

        /// <summary>
        /// Navigates to appraisal system.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="canEditView">if set to <c>true</c> [can edit view].</param>
        /// <param name="canMapClient">if set to <c>true</c> [can map client].</param>
        public void NavigateToAppraisalSystem(string formId, bool canEditView = true, bool canMapClient = true)
        {
            var parameter = new Dictionary<string, object>
            {
                { Constants.FormId, formId },
                { Constants.CanMapClient, canMapClient },
                { Constants.IsViewAppraisal, !canEditView }
            };
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AppraisalSystemView, parameter);
        }

        /// <summary>
        /// Crewings the navigate add fleet dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToMapRank(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapRankNavigationView, navigationContext);
        }

        /// <summary>
        /// Navigates to form preview
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="formId">The form identifier.</param>
        public void NavigateToFormPreview(INavigationContext navigationContext, string formId)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.FormPreviewNavigationView, formId);
        }

        /// <summary>
        /// Navigates to map client view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="formId">The form identifier.</param>
        /// <param name="canEditView">if set to <c>true</c> [can edit view].</param>
        public void NavigateToMapClientView(INavigationContext navigationContext, string formId, bool canEditView)
        {
            var parameter = new Dictionary<string, object>
            {
                { Constants.FormId, formId },
                { Constants.IsViewAppraisal, !canEditView }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapClientNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add sub section.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sectionList">The section list.</param>
        /// <param name="scaleList">The scale list.</param>
        /// <param name="subSection">The sub section.</param>
        /// <param name="appraisalTitle">The appraisal title.</param>
        /// <param name="version">The version.</param>
        /// <param name="scale">The scale.</param>
        /// <param name="isEditMode">if set to <c>true</c> [is edit mode].</param>
        public void NavigateToAddSubSection(INavigationContext navigationContext, List<Lookup> sectionList, object scaleList, object subSection, string appraisalTitle, string version, string scale, bool? isEditMode)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constant.Section,sectionList },
                {Constant.ScaleList,scaleList },
                {Constant.SubSection,subSection },
                {Constant.FormName,appraisalTitle },
                {Constant.Version,version },
                {Constant.Scale,scale },
                {Constant.IsEditMode,isEditMode }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSubSectionNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the edit appraisal scale.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="formId">The form identifier.</param>
        public void NavigateEditAppraisalScale(INavigationContext context, string formId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditAppraisalScaleNavigationView, context, formId);
        }

        /// <summary>
        /// Navigates to add edit section view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToAddEditSectionView(INavigationContext navigationContext, CrewMaintenanceStartParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSectionNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add edit relief rule template dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        public void NavigateAddEditReliefRuleTemplateDialogView(INavigationContext navigationContext, object entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditReliefRuleDialogView, navigationContext, entity);
        }

        /// <summary>
        /// Navigates the add edit combined experience dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        public void NavigateAddEditCombinedExperienceDialogView(INavigationContext navigationContext, object entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditCombinedExperienceDialogView, navigationContext, entity);
        }

        /// <summary>
        /// Navigates to run optimiser default values maintainer.
        /// </summary>
        public void NavigateToRunOptimiserDefaultValuesMaintainer()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.RunOptimiserDefaultValuesMaintainerView);
        }

        /// <summary>
        /// Navigates to crew expected wages maintainer.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToCrewExpectedWagesMaintainer(CrewMaintenanceStartParameter parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CrewExpectedWagesMaintainerView, parameters);
        }

        /// <summary>
        /// Navigates the add edit hob group dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        public void NavigateAddEditHOBGroupDialogView(INavigationContext navigationContext, object entity)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHOBGroupDialogView, navigationContext, entity);
        }

        /// <summary>
        /// Navigates the hob manage rules view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateHOBManageRulesView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HOBManageRulesView, navigationContext);
        }

        /// <summary>
        /// Navigates the add edit hob manage rules dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="hrmId">The HRM identifier.</param>
        public void NavigateAddEditHOBManageRulesDialogView(INavigationContext navigationContext, string hrmId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHOBManageRulesDialogView, navigationContext, hrmId);
        }

        /// <summary>
        /// Navigates the map hob group vessel rules dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateMapHOBGroupVesselRulesDialogView(INavigationContext navigationContext, HOBGroupNavigationParameter navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapHOBGroupVesselRulesDialogView, navigationContext, navigationParameter);
        }

        /// <summary>
        /// Navigates the add edit hob report dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="refreshAction"></param>
        public void NavigateAddEditHOBReportDialogView(INavigationContext navigationContext, string groupId, string reportId, object refreshAction)
        {
            var parameter = new Dictionary<string, object>()
            {
                {Constants.HOBGroupId,groupId},
                {Constants.HOBReportId,reportId},
                {Constants.HOBRefeshAction, refreshAction}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHOBReportDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the expense line item reject view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="lineItem">The line item.</param>
        /// <param name="isCorrectionRequired">if set to <c>true</c> [is correction required].</param>
        /// <param name="OnSaveActionCompleted">The on save action completed.</param>
        public void NavigateExpenseLineItemRejectView(INavigationContext navigation, List<int> lineItem, bool isCorrectionRequired, Action OnSaveActionCompleted)
        {
            var parameter = new Dictionary<string, object>()
            {
                {Constants.CrewExpenseLineItems, lineItem },
                {Constants.IsCorrectionRequired, isCorrectionRequired },
                {Constants.CrewExpenseRefeshAction, OnSaveActionCompleted }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewExpenseLineItemRejectView, navigation, parameter);
        }

        /// <summary>
        /// Navigates the add crew expense details dialog view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="crewExpenseHeaderId">The crew expense header identifier.</param>
        public void NavigateAddCrewExpenseDetailsDialogView(INavigationContext navigation, int? crewExpenseHeaderId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewExpenseDetailsDialogView, navigation, crewExpenseHeaderId);
        }

        /// <summary>
        /// Navigates the add crew expense attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="expenseDetailsId">The expense details identifier.</param>
        /// <param name="attachmentCount">The attachment count.</param>
        public void NavigateAddCrewExpenseAttachments(INavigationContext navigationContext, AttachmentParameters parameters, IEnumerable<string> fileNames, string parentId, string documentId, int expenseDetailsId, int attachmentCount)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.Parameters, parameters},
                { NavigationParameterConstant.FilesToUpload, fileNames != null ? fileNames.ToList() : new List<string>()},
                { NavigationParameterConstant.ParentNavigationIdKey, parentId},
                { NavigationParameterConstant.DocumentId, documentId},
                { NavigationParameterConstant.ExpenseDetailId, expenseDetailsId },
                { NavigationParameterConstant.AttachmentCount, attachmentCount}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCrewExpenseAttachmentsNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the view common attachments dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateViewCrewExpenseAttachmentsDialogView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewCrewExpenseAttachmentsNavigationView, navigationContext, parameters);
        }
    }
}