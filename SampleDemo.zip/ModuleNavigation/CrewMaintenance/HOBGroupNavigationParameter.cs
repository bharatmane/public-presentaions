﻿using System;

namespace VShips.Framework.Common.ModuleNavigation.CrewMaintenance
{
    /// <summary>
    /// HOB Group Navigation Parameters
    /// </summary>
    public class HOBGroupNavigationParameter
    {
        /// <summary>
        /// The on save performed
        /// </summary>
        public Action<object, bool> OnSavePerformed;

        /// <summary>
        /// Gets or sets the hob group identifier.
        /// </summary>
        /// <value>
        /// The hob group identifier.
        /// </value>
        public string HobGroupId { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the shared object master rules rules.
        /// </summary>
        /// <value>
        /// The shared object master rules rules.
        /// </value>
        public object SharedObjectMasterRulesRules { get; set; }

        /// <summary>
        /// Gets or sets the shared object selected vessels.
        /// </summary>
        /// <value>
        /// The shared object selected vessels.
        /// </value>
        public object SharedObjectSelectedVessels { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is for multiple vessel.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for multiple vessel; otherwise, <c>false</c>.
        /// </value>
        public bool IsForMultipleVessel { get; set; }
    }
}
