﻿namespace VShips.Framework.Common.ModuleNavigation.CrewMaintenance
{
    /// <summary>
    /// Names of accessible views and regions related to the Crew Maintenance module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "CrewMaintenance";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "CrewMaintenanceGeometry";

        //Views

        /// <summary>The landing or start view for Crew Maintenance</summary>
        public const string StartView = "CrewMaintenanceStartView";

        /// <summary>
        /// The document maintainer view
        /// </summary>
        public const string DocumentMaintainerStartView = "DocumentMaintainerStartView";

        /// <summary>
        /// The add edit document dialog view
        /// </summary>
        public const string AddEditDocumentDialogView = "AddEditDocumentDialogView";

        /// <summary>
        /// The add crew document group view
        /// </summary>
        public const string AddCrewDocumentGroupView = "AddCrewDocumentGroupView";

        /// <summary>
        /// The rank maintainer start view
        /// </summary>
        public const string RankMaintainerStartView = "RankMaintainerStartView";

        /// <summary>
        /// The contract maintainer start view
        /// </summary>
        public const string ContractMaintainerStartView = "ContractMaintainerStartView";

        /// <summary>
        /// The Travel cost maintainer start view
        /// </summary>
        public const string TravelCostMaintainerStartView = "TravelCostMaintainerStartView";
        /// <summary>
        /// The payscale template maintainer start view
        /// </summary>
        public const string PayscaleTemplateMaintainerStartView = "PayscaleTemplateMaintainerStartView";

        /// <summary>
        /// The document maintainer
        /// </summary>
        public const string DocumentMaintainer = "Document Maintainer";

        /// <summary>
        /// The document geometry
        /// </summary>
        public const string DocumentGeometry = "DocumentGeometry";

        /// <summary>
        /// The default geometry
        /// </summary>
        public const string DefaultGeometry = "RightGeometry";

        /// <summary>
        /// The add edit rank dialog view
        /// </summary>
        public const string AddEditRankDialogView = "AddEditRankDialogView";

        /// <summary>
        /// The add edit department dialog view
        /// </summary>
        public const string AddEditDepartmentDialogView = "AddEditDepartmentDialogView";

        /// <summary>
        /// The entity
        /// </summary>
        public const string Entity = "Entity";

        /// <summary>
        /// The document group identifier
        /// </summary>
        public const string DocumentGroupId = "DocumentGroupId";

        /// <summary>
        /// The wage scale maintainer
        /// </summary>
        public const string WageScaleMaintainerStartView = "WageScaleMaintainerStartView";

        /// <summary>
        /// The add payscale template view
        /// </summary>
        public const string AddPayscaleTemplateView = "AddPayscaleTemplateView";

        /// <summary>
        /// The add contract view
        /// </summary>
        public const string AddContractView = "AddContractView";

        /// <summary>
        /// The selected items
        /// </summary>
        public const string SelectedItems = "SelectedItems";

        /// <summary>
        /// The contract maintainer geometry
        /// </summary>
        public const string ContractMaintainerGeometry = "ContractMaintainerGeometry";

		/// <summary>
		/// The travel cost maintainer geometry
		/// </summary>
		public const string TravelCostMaintainerGeometry= "ContractMaintainerGeometry";

        /// <summary>
        /// The pay scale maintainer geometry
        /// </summary>
        public const string PayscaleMaintainerGeometry = "PayscaleMaintainerGeometry";

        /// <summary>
        /// The rank maintainer geometry
        /// </summary>
        public const string RankMaintainerGeometry = "RankMaintainerGeometry";

        /// <summary>
        /// The rank maintainer
        /// </summary>
        public const string RankMaintainer = "Rank Maintainer";

        /// <summary>
        /// The contract template maintainer
        /// </summary>
        public const string ContractTemplateMaintainer = "Contract Template Maintainer";

        /// <summary>
        /// The contract maintainer
        /// </summary>
        public const string ContractMaintainer = "Contract Maintainer";

        /// <summary>
        /// The Cost Maintainer
        /// </summary>
        public const string TravelCostMaintainer = "Travel Cost Maintainer";

        /// <summary>
        /// The payscale template maintainer
        /// </summary>
        public const string PayscaleTemplateMaintainer = "Payscale Template Maintainer";

        /// <summary>
        /// The wage scale maintainer
        /// </summary>
        public const string WageScaleMaintainer = "Wage Scale Maintainer";

        /// <summary>
        /// The contract template maintainer start item view
        /// </summary>
        public const string ContractTemplateMaintainerStartView = "ContractTemplateMaintainerStartView";

        /// <summary>
        /// The add contract template view
        /// </summary>
        public const string AddContractTemplateView = "AddContractTemplateView";

        /// <summary>
        /// The current time stamp string format.
        /// </summary>
        public const string CurrentTimeStampStringFormat = "yyMMddHHmmss";

        /// <summary>
        /// The contract template file types
        /// </summary>
        public const string ContractTemplateFileTypes = "All files |*.docx;*.dot;*.doc|Doc files(.doc)|*.doc|Docx files(.docx) |*.docx|DOT files(.dot) |*.dot";

        /// <summary>
        /// The crew cell maintainer
        /// </summary>
        public const string CrewCellMaintainer = "Crew Cell Maintainer";

        /// <summary>
        /// The crew pool vessel configuration start view
        /// </summary>
        public const string CrewPoolVesselConfigurationStartView = "CrewPoolVesselConfigurationStartView";//"Crew Pool Vessel Configuration";

        /// <summary>
        /// The add crew pool detail view
        /// </summary>
        public const string AddCrewPoolDetailView = "AddCrewPoolDetailView";

        /// <summary>
        /// The planning fleet maintainer
        /// </summary>
        public const string SharedPlanningFleet = "Shared Planning Fleet";

        /// <summary>
        /// The planning fleet maintainer start view
        /// </summary>
        public const string PlanningFleetMaintainerStartView = "PlanningFleetMaintainerStartView";

        /// <summary>
        /// The add fleet dialog view
        /// </summary>
        public const string AddFleetDialogView = "AddFleetDialogView";

        /// <summary>
        /// The crew pool vessel configuration geometry
        /// </summary>
        public const string CrewPoolVesselConfigurationGeometry = "CrewPoolVesselConfigurationGeometry";

        /// <summary>
        /// The appraisal maintainer start view
        /// </summary>
        public const string AppraisalMaintainerStartView = "AppraisalMaintainerStartView";

        /// <summary>
        /// The add appraisal form navigation view
        /// </summary>
        public const string AddAppraisalFormNavigationView = "AddAppraisalFormNavigationView";

        /// <summary>
        /// The add section navigation view
        /// </summary>
        public const string AddSectionNavigationView = "AddSectionNavigationView";

        /// <summary>
        /// The appraisal system view
        /// </summary>
        public const string AppraisalSystemView = "AppraisalSystemView";

        /// <summary>
        /// The map rank navigation view.
        /// </summary>
        public const string MapRankNavigationView = "MapRankNavigationView";

        /// <summary>
        /// The in edit mode.
        /// </summary>
        public const string InEditMode = "inEditMode";

        /// <summary>
        /// The form preview navigation view.
        /// </summary>
        public const string FormPreviewNavigationView = "FormPreviewNavigationView";
        /// <summary>
        /// The map navigation client view
        /// </summary>
        public const string MapClientNavigationView = "MapClientNavigationView";

        /// <summary>
        /// The active training needs navigation view.
        /// </summary>
        public const string ActiveTrainingNeedsNavigationView = "ActiveTrainingNeedsNavigationView";

        /// <summary>
        /// The is from performance
        /// </summary>
        public const string IsFromPerformance = "IsFromPerformance";

        /// <summary>
        /// The crew details
        /// </summary>
        public const string CrewDetails = "CrewDetails";

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";

        /// <summary>
        /// The add sub section navigation view.
        /// </summary>
        public const string AddSubSectionNavigationView = "AddSubSectionNavigationView";

        /// <summary>
        /// The vessel name
        /// </summary>
        public const string VesselName = "VessleName";

        /// <summary>
        /// The cah identifier
        /// </summary>
        public const string CahId = "CahId";

        /// <summary>
        /// The edit appraisal scale navigation view.
        /// </summary>
        public const string EditAppraisalScaleNavigationView = "EditAppraisalScaleNavigationView";

        /// <summary>
        /// The is last appraisal.
        /// </summary>
        public const string IsLastAppraisal = "IsLastAppraisal";

        /// <summary>
        /// The is view appraisal.
        /// </summary>
        public const string IsViewAppraisal = "IsViewAppraisal";
        /// <summary>
        /// The can map client
        /// </summary>
        public const string CanMapClient = "CanMapClient";

        /// <summary>
        /// The form identifier
        /// </summary>
        public const string FormId = "FormId";

		/// <summary>
		/// The combined experience maintainer start view
		/// </summary>
		public const string CombinedExperienceMaintainerStartView = "CombinedExperienceMaintainerStartView";

		/// <summary>
		/// The relief rules maintainer start view
		/// </summary>
		public const string ReliefRulesMaintainerStartView = "ReliefRulesMaintainerStartView";

        /// <summary>
        /// The add edit relief rule dialog view
        /// </summary>
        public const string AddEditReliefRuleDialogView = "AddEditReliefRuleDialogView";

        /// <summary>
        /// The add edit combined experience dialog view
        /// </summary>
        public const string AddEditCombinedExperienceDialogView = "AddEditCombinedExperienceDialogView";

        /// <summary>
        /// The run optimiser default values maintainer view
        /// </summary>
        public const string RunOptimiserDefaultValuesMaintainerView = "RunOptimiserDefaultValuesMaintainerView";


        /// <summary>
        /// The crew expected wages maintainer view
        /// </summary>
        public const string CrewExpectedWagesMaintainerView = "CrewExpectedWagesMaintainerView";

		/// <summary>
		/// The port crew change cost maintainer start view
		/// </summary>
		public const string PortCrewChangeCostMaintainerStartView = "PortCrewChangeCostMaintainerStartView";

		/// <summary>
		/// The Cost Maintainer
		/// </summary>
		public const string PortCrewChangeCostMaintainer = "Port Crew Change Cost Maintainer";

		/// <summary>
		/// The travel cost maintainer geometry
		/// </summary>
		public const string PortCrewChangeCostMaintainerGeometry = "";

		/// <summary>
		/// The engine category maintainer
		/// </summary>
		public const string EngineCategoryMaintainer = "Engine Category Maintainer";
		
		/// <summary>
		/// The engine category maintainer start view
		/// </summary>
		public const string EngineCategoryMaintainerStartView = "EngineCategoryMaintainerStartView";

        /// <summary>
        /// The travel event maintainer view
        /// </summary>
        public const string TravelEventMaintainerView = "TravelEventMaintainerViewModel";       
        
        /// <summary>
        /// The salary transfer letter maintainer start view
        /// </summary>
        public const string SalaryTransferLetterMaintainerStartView = "SalaryTransferLetterMaintainerStartView";

        /// <summary>
        /// The compliance template maintainer start view
        /// </summary>
        public const string ComplianceTemplateMaintainerStartView = "ComplianceTemplateMaintainerStartView";

        /// <summary>
        /// The hob system maintainer
        /// </summary>
        public const string HOBSystemMaintainer = "HOB System Maintainer";

        /// <summary>
        /// The hob system geometry
        /// </summary>
        public const string HOBSystemGeometry = "CrewPoolVesselConfigurationGeometry";

        /// <summary>
        /// The hob system maintainer start view
        /// </summary>
        public const string HOBSystemMaintainerStartView = "HOBSystemMaintainerStartView";

        /// <summary>
        /// The add edit hob group dialog view
        /// </summary>
        public const string AddEditHOBGroupDialogView = "AddEditHOBGroupDialogView";

        /// <summary>
        /// The hob manage rules view
        /// </summary>
        public const string HOBManageRulesView = "HOBManageRulesView";

        /// <summary>
        /// The add edit hob manage rules dialog view
        /// </summary>
        public const string AddEditHOBManageRulesDialogView = "AddEditHOBManageRulesDialogView";

        /// <summary>
        /// The map hob group vessel rules dialog view
        /// </summary>
        public const string MapHOBGroupVesselRulesDialogView = "MapHOBGroupVesselRulesDialogView";

        /// <summary>
        /// The hob report start view
        /// </summary>
        public const string HOBReportStartView = "HOBReportStartView";

        /// <summary>
        /// The add edit hob report dialog view
        /// </summary>
        public const string AddEditHOBReportDialogView = "AddEditHOBReportDialogView";

        /// <summary>
        /// The hob group identifier
        /// </summary>
        public const string HOBGroupId = "HOBGroupId";

        /// <summary>
        /// The hob report identifier
        /// </summary>
        public const string HOBReportId = "HOBReportId";

        /// <summary>
        /// The hob refesh action
        /// </summary>
        public const string HOBRefeshAction = "HOBRefreshAction";

        /// <summary>
        /// The crew expenses start view
        /// </summary>
        public const string CrewExpensesStartView = "CrewExpensesStartView";

        /// <summary>
        /// The electonic payment administration geometry
        /// </summary>
        public const string ElectonicPaymentAdministrationGeometry = "ElectonicPaymentAdministrationGeometry";

        /// <summary>
        /// The crew expense line item reject view
        /// </summary>
        public const string CrewExpenseLineItemRejectView = "CrewExpenseLineItemRejectView";

        /// <summary>
        /// The add crew expense details dialog view
        /// </summary>
        public const string AddCrewExpenseDetailsDialogView = "AddCrewExpenseDetailsDialogView";

        /// <summary>
        /// The add crew expense attachments navigation view
        /// </summary>
        public const string AddCrewExpenseAttachmentsNavigationView = "AddCrewExpenseAttachmentsNavigationView";

        /// <summary>
        /// The view crew expense attachments navigation view
        /// </summary>
        public const string ViewCrewExpenseAttachmentsNavigationView = "ViewCrewExpenseAttachmentsNavigationView";

        /// <summary>
        /// The crew expense line items
        /// </summary>
        public const string CrewExpenseLineItems = "CrewExpenseLineItems";

        /// <summary>
        /// The is correction required
        /// </summary>
        public const string IsCorrectionRequired = "IsCorrectionRequired";

        /// <summary>
        /// The add expense header
        /// </summary>
        public const string AddExpenseHeader = "Add Expense Header";

        /// <summary>
        /// The crew expense refesh action
        /// </summary>
        public const string CrewExpenseRefeshAction = "CrewExpenseRefeshAction";
    }
}