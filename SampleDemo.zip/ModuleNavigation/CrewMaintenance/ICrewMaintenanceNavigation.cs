﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Crew;
using VShips.Contracts.DtoClasses.PayrollPayscaleTemplateMainTypes;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.ModuleNavigation.Common;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CrewMaintenance
{
    /// <summary>
    /// Navigation service for the Crew Maintenance module.
    /// </summary>
    public interface ICrewMaintenanceNavigation
    {
        /// <summary>
        /// Navigates to the Crew Maintenance module start view.
        /// </summary>
        void NavigateStart();

        /// <summary>
        /// Navigate to document maintainer.
        /// </summary>
        void CrewMaintainanceNavigateDocumentMaintainer();

        /// <summary>
        /// Navigate rank maintainer.
        /// </summary>
        void CrewMaintainanceNavigateRankMaintainer();

        /// <summary>
        /// Crewings the navigate add crew document group view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void CrewingNavigateAddCrewDocumentGroupView(INavigationContext navigationContext);

        /// <summary>
        /// Crewings the navigate document maintainer add edit document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="documentGroupId">The document group identifier.</param>
        void CrewingNavigateDocMaintainerAddEditDocument(INavigationContext navigationContext, object entity, string documentGroupId);

        /// <summary>
        /// Crews the maintainence rank maintainer add edit dailog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        void CrewMaintainenceRankMaintainerAddEditDailogView(INavigationContext navigationContext, object entity);

        /// <summary>
        /// Crews the maintainence rank maintainer department add edit dailog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        void CrewMaintainenceRankMaintainerDepartmentAddEditDailogView(INavigationContext navigationContext, object entity);

        /// <summary>
        /// Crewings the navigate add edit department.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="departmentId">The department identifier.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        void CrewingNavigateAddEditDepartment(INavigationContext navigationContext, string departmentId, bool isEdit);

        /// <summary>
        /// Crewings the navigate add payscale template.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedItems">The selected items.</param>
        void CrewingNavigateAddPayscaleTemplate(INavigationContext navigationContext, List<PayscaleMap> selectedItems);

        /// <summary>
        /// Crewings the navigate add contract.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void CrewingNavigateAddContract(INavigationContext navigationContext);

        /// <summary>
        /// Navigates to add contract template.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void CrewingNavigateAddContractTemplate(INavigationContext navigationContext);

        /// <summary>
        /// Crewings the navigate crew pool vessel configuration.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void CrewingNavigateCrewPoolVesselConfiguration(INavigationContext navigationContext);

        /// <summary>
        /// Crewings the navigate add crew pool detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewPoolSummary">The selected crew pool summary.</param>
        void CrewingNavigateAddCrewPoolDetail(INavigationContext navigationContext, CrewPoolSummary selectedCrewPoolSummary);

        /// <summary>
        /// Navigates to planning fleet maintainer.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void PlanningFleetMaintainer(INavigationContext navigationContext);

        /// <summary>
        /// Crewings the navigate add fleet dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void CrewingNavigateAddFleetDialogView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates to add appraisal form.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// /// <param name="inEditMode"></param>
        void NavigateToAddAppraisalForm(INavigationContext navigationContext, bool inEditMode);

        /// <summary>
        /// Navigates to add edit section view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToAddEditSectionView(INavigationContext navigationContext, CrewMaintenanceStartParameter parameter);

        /// <summary>
        /// Navigates to appraisal system.
        /// </summary>
        /// <param name="formId">The form identifier.</param>
        /// <param name="canEditView">if set to <c>true</c> [can edit view].</param>
        /// <param name="canMapClient">if set to <c>true</c> [can map client].</param>
        void NavigateToAppraisalSystem(string formId, bool canEditView = true, bool canMapClient = true);

        /// <summary>
        /// Navigates to map rank.
        /// </summary>
        /// <param name="navigationContext"></param>
        void NavigateToMapRank(INavigationContext navigationContext);

        /// <summary>
        /// Navigates to form preview.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="formId">The form identifier.</param>
        void NavigateToFormPreview(INavigationContext navigationContext, string formId);
        /// <summary>
        /// Navigates to map client view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="formId">The form identifier.</param>
        /// <param name="canEditView">if set to <c>true</c> [can edit view].</param>
        void NavigateToMapClientView(INavigationContext navigationContext, string formId, bool canEditView);

        /// <summary>
        /// Navigates to add sub section.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="sectionList">The section list.</param>
        /// <param name="scaleList">The scale list.</param>
        /// <param name="subSection">The sub section.</param>
        /// <param name="appraisalTitle">The appraisal title.</param>
        /// <param name="version">The version.</param>
        /// <param name="scale">The scale.</param>
        /// <param name="isEditMode">if set to <c>true</c> [is edit mode].</param>
        void NavigateToAddSubSection(INavigationContext navigationContext, List<Lookup> sectionList, object scaleList, object subSection, string appraisalTitle, string version, string scale, bool? isEditMode);

        /// <summary>
        /// Navigates the edit appraisal scale.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="formId">The form identifier.</param>
        void NavigateEditAppraisalScale(INavigationContext context, string formId);

        /// <summary>
        /// Navigates to add edit relief rule template dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        void NavigateAddEditReliefRuleTemplateDialogView(INavigationContext navigationContext, object entity);

        /// <summary>
        /// Navigates the add edit combined experience dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        void NavigateAddEditCombinedExperienceDialogView(INavigationContext navigationContext, object entity);

        /// <summary>
        /// Navigates to run optimiser default values maintainer.
        /// </summary>
        void NavigateToRunOptimiserDefaultValuesMaintainer();

        /// <summary>
        /// Navigates to crew expected wages maintainer.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void NavigateToCrewExpectedWagesMaintainer(CrewMaintenanceStartParameter parameters);

        /// <summary>
        /// Navigates the add edit hob group dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="entity">The entity.</param>
        void NavigateAddEditHOBGroupDialogView(INavigationContext navigationContext, object entity);

        /// <summary>
        /// Navigates the hob manage rules view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateHOBManageRulesView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the add edit hob manage rules dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="hrmId">The HRM identifier.</param>
        void NavigateAddEditHOBManageRulesDialogView(INavigationContext navigationContext, string hrmId);

        /// <summary>
        /// Navigates the map hob group vessel rules dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateMapHOBGroupVesselRulesDialogView(INavigationContext navigationContext, HOBGroupNavigationParameter navigationParameter);

        /// <summary>
        /// Navigates the add edit hob report dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="refreshAction">The refresh action.</param>
        void NavigateAddEditHOBReportDialogView(INavigationContext navigationContext, string groupId, string reportId, object refreshAction);

        /// <summary>
        /// Navigates the expense line item reject view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="lineItem">The line item.</param>
        /// <param name="isCorrectionRequired">if set to <c>true</c> [is correction required].</param>
        /// <param name="OnSaveActionCompleted">The on save action completed.</param>
        void NavigateExpenseLineItemRejectView(INavigationContext navigation, List<int> lineItem, bool isCorrectionRequired,Action OnSaveActionCompleted);

        /// <summary>
        /// Navigates the add crew expense details dialog view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="crewExpenseHeaderId">The crew expense header identifier.</param>
        void NavigateAddCrewExpenseDetailsDialogView(INavigationContext navigation, int? crewExpenseHeaderId);

        /// <summary>
        /// Navigates the add crew expense attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="expenseDetailsId">The expense details identifier.</param>
        /// <param name="attachmentCount">The attachment count.</param>
        void NavigateAddCrewExpenseAttachments(INavigationContext navigationContext, AttachmentParameters parameters, IEnumerable<string> fileNames, string parentId, string documentId, int expenseDetailsId, int attachmentCount);

        /// <summary>
        /// Navigates the view common attachments dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateViewCrewExpenseAttachmentsDialogView(INavigationContext navigationContext, object parameters);
    }
}