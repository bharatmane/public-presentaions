﻿namespace VShips.Framework.Common.ModuleNavigation.CrewMaintenance
{
    /// <summary>
    /// This class is CrewMaintenanceStartParameter.
    /// </summary>
    public class CrewMaintenanceStartParameter
    {
        #region Properties

        /// <summary>
        /// The appraisal title.
        /// </summary>
        public string AppraisalTitle { get; set; }

        /// <summary>
        /// The scale.
        /// </summary>
        public string Scale { get; set; }

        /// <summary>
        /// The version.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// The child level.
        /// </summary>
        public int? ChildLevel { get; set; }

        /// <summary>
        /// The form identifier.
        /// </summary>
        public string FormId { get; set; }

        /// <summary>
        /// Gets or sets the shared entity.
        /// </summary>
        /// <value>
        /// The shared entity.
        /// </value>
        public object SharedEntity { get; set; }

        /// <summary>
        /// Gets or sets the section level.
        /// </summary>
        /// <value>
        /// The section level.
        /// </value>
        public int SectionLevel { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier.
        /// </summary>
        /// <value>
        /// The unique identifier.
        /// </value>
        public string UniqueId { get; set; }

        #endregion
    }
}
