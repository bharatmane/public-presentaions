﻿namespace VShips.Framework.Common.ModuleNavigation.Certificates
{
    /// <summary>
    /// Services and constants relating to the budget module.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}