﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Certificates
{
    /// <summary>
    /// Navigation service for the budget module.
    /// </summary>
    public interface ICertificatesNavigation
    {
        /// <summary>
        /// Certificates the navigate add attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselCertificateLogId">The vessel certificate log identifier.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="ParentId">The parent identifier.</param>
        void CertificateNavigateAddAttachments(INavigationContext navigationContext, string vesselId, string vesselCertificateLogId, IEnumerable<string> fileNames, string ParentId = null);

        /// <summary>
        /// Navigate to add vessel certificate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselCertificatePreview">The vessel certificate preview.</param>
        /// <param name="CertificateSummaryItem">The certificate summary item.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateAddVesselCertificate(INavigationContext navigationContext, object vesselCertificatePreview, object CertificateSummaryItem, string parentId);

        /// <summary>
        ///   Navigates the delete restore certificate view.
        /// </summary>
        /// <param name="navigationContext">
        ///   The navigation context.
        /// </param>
        /// <param name="vesselId">
        ///   The vessel identifier.
        /// </param>
        /// <param name="certificateId">
        ///   The certificate identifier.
        /// </param>
        /// <param name="vesselCertificateId">
        ///   The vessel certificate identifier.
        /// </param>
        /// <param name="extendedNo">
        ///   The extended no.
        /// </param>
        /// <param name="parentId">
        ///   The parent identifier.
        /// </param>
        /// <param name="isRestore">
        ///   if set to <c>true</c> [is restore].
        /// </param>
        /// <param name="isactivate">
        ///   The isactivate.
        /// </param>
        void NavigateDeleteRestoreCertificateView(INavigationContext navigationContext, string vesselId, string certificateId, string vesselCertificateId , int? extendedNo, string parentId, bool isRestore = false, bool? isactivate = null);

        /// <summary>
        /// Navigates to the vessel certificate audit log detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselCertificateAuditLog">The vessel certificate audit log of type <see cref="VesselCertificateAuditLogDetail"/>.</param>
        /// <param name="certificateCode">The certificate code.</param>
        /// <param name="extendedNumber">The extended number.</param>
        void NavigateVesselCertificateAuditLogDetail(INavigationContext navigationContext, VesselCertificateAuditLogDetail vesselCertificateAuditLog, string certificateCode, int? extendedNumber);

        /// <summary>
        /// Navigates to the vessel certificate documents.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="certificateDetail">The certificate detail.</param>
        void NavigateVesselCertificateDocuments(INavigationContext navigationContext, CertificateDetail certificateDetail);

        /// <summary>
        /// Navigates the vessel certificate association.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void NavigateVesselCertificateAssociation(INavigationContext navigationContext, string vesselId, string vesselName);

        /// <summary>
        /// Navigates the issue vessel certificate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="certificateId">The certificate identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="lastExpiryDate">The last expiry date.</param>
        void NavigateIssueVesselCertificate(INavigationContext navigationContext, string vesselId, string certificateId, string vesselName, string parentId, DateTime? lastExpiryDate);

        /// <summary>
        /// Navigates the edit vessel certificate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="certificateId">The certificate identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="lastUpdatedDate">The last updated date.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateEditVesselCertificate(INavigationContext navigationContext, string vesselId, string certificateId, string vesselName,DateTime? lastUpdatedDate ,string parentId);

        /// <summary>
        /// Navigates the add certificate wizard.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselTypeId">The vessel type identifier.</param>
        /// <param name="CertificateSummaryItem">The certificate summary item.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateAddCertificateWizard(INavigationContext navigationContext, string vesselId, string vesselTypeId, object CertificateSummaryItem, string parentId);


        /// <summary>
        /// Navigates the incomplete certificate dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateIncompleteCertificateDailog(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the vessel certificates.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void NavigateVesselCertificates(object parameters);
        /// <summary>
        /// Navigates the certificate navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateCertificateReportsNavigationView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates to the Landing page
        /// </summary>
        void NavigatetoLandingPage();

        /// <summary>
        /// Navigates the link requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requisitionParameters">The requisition parameters.</param>
        void NavigateLinkRequisition(INavigationContext navigationContext, Dictionary<string, object> requisitionParameters);

        /// <summary>
        /// Navigates to view link requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requisitionParameters">The requisition parameters.</param>
        void NavigateToViewLinkRequisition(INavigationContext navigationContext, Dictionary<string, object> requisitionParameters);
    }
}