﻿using System;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.DataServices.Shared.DataAttributes;
using VShips.DataServices.Shared.Enumerations.Vessel;

namespace VShips.Framework.Common.ModuleNavigation.Certificates
{
    /// <summary>
    /// Parameters used in navigating to the Certificates start view.
    /// </summary>
    public class CertificatesStartParameter
    {
        #region Properties

        /// <summary>
        /// The filter.
        /// </summary>
        private readonly VesselCertificateFilter _filter;

        /// <summary>
        /// The filter for the certificates start view.
        /// </summary>
        public VesselCertificateFilter Filter
        {
            get { return _filter; }
        }

        /// <summary>
        /// The is from vessel dashboard
        /// </summary>
        private bool _isFromVesselDashboard;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from vessel dashboard.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from vessel dashboard; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromVesselDashboard
        {
            get { return _isFromVesselDashboard; }
            set { _isFromVesselDashboard = value; }
        }

        /// <summary>
        /// The certificate impact
        /// </summary>
        private CertificateImpactFilters _certificateImpact;

        /// <summary>
        /// Gets the certificate impact.
        /// </summary>
        /// <value>
        /// The certificate impact.
        /// </value>
        public CertificateImpactFilters CertificateImpact
        {
            get { return _certificateImpact; }
            set { _certificateImpact = value; }
        }

        /// <summary>
        /// The is include window
        /// </summary>
        private bool _isIncludeWindow;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is include window.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is include window; otherwise, <c>false</c>.
        /// </value>
        public bool IsIncludeWindow
        {
            get { return _isIncludeWindow; }
            set { _isIncludeWindow = value; }
        }

        /// <summary>
        /// The certificate status
        /// </summary>
        private CertificateStatusFilters _certificateStatus;

        /// <summary>
        /// Gets or sets the certificate status.
        /// </summary>
        /// <value>
        /// The certificate status.
        /// </value>
        public CertificateStatusFilters CertificateStatus
        {
            get { return _certificateStatus; }
            set { _certificateStatus = value; }
        }

        /// <summary>
        /// The certificate range types
        /// </summary>
        private CertificateRangeType? _certificateRangeTypes;

        /// <summary>
        /// Gets or sets the certificate range types.
        /// </summary>
        /// <value>
        /// The certificate range types.
        /// </value>
        public CertificateRangeType? CertificateRangeTypes
        {
            get { return _certificateRangeTypes; }
            set { _certificateRangeTypes = value; }
        }

        /// <summary>
        /// The vessel certificate identifier.
        /// </summary>
        private string _vesselCertificateId;

        /// <summary>
        /// Gets or sets the vessel certificate identifier.
        /// </summary>
        /// <value>
        /// The vessel certificate identifier.
        /// </value>
        public string VesselCertificateId
        {
            get { return _vesselCertificateId; }
            set { _vesselCertificateId = value; }
        }

        /// <summary>
        /// The certificate filter
        /// </summary>
        private CertificatePreviewFilter _certificateFilter;

        /// <summary>
        /// Gets or sets the certificate filter.
        /// </summary>
        /// <value>
        /// The certificate filter.
        /// </value>
        public CertificatePreviewFilter CertificateFilter
        {
            get { return _certificateFilter; }
            set { _certificateFilter = value; }
        }

        /// <summary>
        /// The vessel identifier
        /// </summary>
        private string _vesselId;

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId
        {
            get { return _vesselId; }
            set { _vesselId = value; }
        }


        /// <summary>
        /// The vessel name
        /// </summary>
        private string _vesselName;

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName
        {
            get { return _vesselName; }
            set { _vesselName = value; }
        }


        /// <summary>
        /// The shared object
        /// </summary>
        private object _sharedObject;

        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObject
        {
            get { return _sharedObject; }
            set { _sharedObject = value; }
        }

        /// <summary>
        /// The include vessel
        /// </summary>
        private bool _includeVessel;

        /// <summary>
        /// Gets or sets a value indicating whether [include vessel].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [include vessel]; otherwise, <c>false</c>.
        /// </value>
        public bool IncludeVessel
        {
            get { return _includeVessel; }
            set { _includeVessel = value; }
        }

        /// <summary>
        /// The include PMS
        /// </summary>
        private bool _includePMS;

        /// <summary>
        /// Gets or sets a value indicating whether [include PMS].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [include PMS]; otherwise, <c>false</c>.
        /// </value>
        public bool IncludePMS
        {
            get { return _includePMS; }
            set { _includePMS = value; }
        }

        /// <summary>
        /// The is export
        /// </summary>
        private bool _isExport;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is export.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is export; otherwise, <c>false</c>.
        /// </value>
        public bool IsExport
        {
            get { return _isExport; }
            set { _isExport = value; }
        }

        /// <summary>
        /// The is from port planning
        /// </summary>
        private bool _isFromPortPlanning;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from port planning.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from port planning; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromPortPlanning
        {
            get { return _isFromPortPlanning; }
            set { _isFromPortPlanning = value; }
        }

        /// <summary>
        /// The port parameters
        /// </summary>
        private PortPlanningParamters _portParameters;

        /// <summary>
        /// Gets or sets the port parameters.
        /// </summary>
        /// <value>
        /// The port parameters.
        /// </value>
        public PortPlanningParamters PortParameters
        {
            get { return _portParameters; }
            set { _portParameters = value; }
        }

        /// <summary>
        /// The certificate identifier
        /// </summary>
        private string _certificateId;

        /// <summary>
        /// Gets or sets the certificate identifier.
        /// </summary>
        /// <value>
        /// The certificate identifier.
        /// </value>
        public string CertificateId
        {
            get { return _certificateId; }
            set { _certificateId = value; }
        }

        /// <summary>
        /// Gets or sets the name of the certificate.
        /// </summary>
        /// <value>
        /// The name of the certificate.
        /// </value>
        public string CertificateName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is all status selected.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is all status selected; otherwise, <c>false</c>.
        /// </value>
        public bool? IsAllStatusSelected { get; set; }

        /// <summary>
        /// Gets or sets the certificate code.
        /// </summary>
        /// <value>
        /// The certificate code.
        /// </value>
        public string CertificateCode { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor 
        /// </summary>
        public CertificatesStartParameter()
        {
            _filter = new VesselCertificateFilter();
        }

        #endregion
    }

    /// <summary>
    /// Filters for certificates
    /// </summary>
    public enum CertificateStatusFilters
    {
        /// <summary>
        /// The show all
        /// </summary>
        [EnumValueData(Name = "All", KeyValue = "AllCertificates")]
        ShowAll,

        /// <summary>
        /// The show in range
        /// </summary>
        [EnumValueData(Name = "In Range", KeyValue = "ShowInRange")]
        ShowInRange,

        /// <summary>
        /// The show due
        /// </summary>
        [EnumValueData(Name = "Due", KeyValue = "ShowDue")]
        ShowDue,

        /// <summary>
        /// The show overdue
        /// </summary>
        [EnumValueData(Name = "Overdue", KeyValue = "ShowOverdue")]
        ShowOverdue
    }

    /// <summary>
    /// Certificate Impact Filter
    /// </summary>
    public enum CertificateImpactFilters
    {
        /// <summary>
        /// All
        /// </summary>
        [EnumValueData(Name = "All", KeyValue = "All")]
        All,

        /// <summary>
        /// The stop sailing
        /// </summary>
        [EnumValueData(Name = "Stop Sailing", KeyValue = "StopSailing")]
        StopSailing,

        /// <summary>
        /// The stop trading
        /// </summary>
        [EnumValueData(Name = "Stop Trading", KeyValue = "StopTrading")]
        StopTrading
    }

    /// <summary>
    /// Certificate type Filter
    /// </summary>
    public enum CertificateTypeFilters
    {
        /// <summary>
        /// All
        /// </summary>
        [EnumValueData(Name = "All", KeyValue = "All")]
        All,

        /// <summary>
        /// The Perpetual
        /// </summary>
        [EnumValueData(Name = "Perpetual", KeyValue = "Perpetual")]
        Perpetual,

        /// <summary>
        /// The Renewal
        /// </summary>
        [EnumValueData(Name = "Renewal", KeyValue = "Renewal")]
        Renewal
    }

    /// <summary>
    /// Class used for parameters of port planning.
    /// </summary>
    public class PortPlanningParamters
    {
        #region Properties

        /// <summary>
        /// Gets or sets the selected certificate identifier.
        /// </summary>
        /// <value>
        /// The selected certificate identifier.
        /// </value>
        public string SelectedCertificateId { get; set; }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime? StartDate { get; set; }

        #endregion
    }

    /// <summary>
    /// Certificate Impact Status
    /// </summary>
    public enum CertificateImpactStatus
    {
        /// <summary>
        /// All Impact
        /// </summary>
        [EnumValueData(Name = "All Impact", KeyValue = "All Impact")]
        AllImpact,

        /// <summary>
        /// No Impact
        /// </summary>
        [EnumValueData(Name = "No Impact", KeyValue = "No Impact")]
        NoImpact,

        /// <summary>
        /// The stop sailing
        /// </summary>
        [EnumValueData(Name = "Stop Sailing", KeyValue = "StopSailing")]
        StopSailing,

        /// <summary>
        /// The stop trading
        /// </summary>
        [EnumValueData(Name = "Stop Trading", KeyValue = "StopTrading")]
        StopTrading
    }
}