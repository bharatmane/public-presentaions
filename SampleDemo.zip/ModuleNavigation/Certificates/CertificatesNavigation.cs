﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.Contracts.Vessel;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Certificates
{
    /// <summary>
    /// Default implementation of the <see cref="ICertificatesNavigation"/> service.
    /// </summary>
    public class CertificatesNavigation : BaseModuleNavigationService, ICertificatesNavigation
    {
        #region Constructors

        /// <summary>
        /// The default constructor for the CertificatesNavigation.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public CertificatesNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        #endregion

        #region Navigation Methods

        /// <summary>
        /// Certificates the navigate add attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselCertificateLogId">The vessel certificate log identifier.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void CertificateNavigateAddAttachments(INavigationContext navigationContext, string vesselId, string vesselCertificateLogId, IEnumerable<string> fileNames, string parentId)
        {
            var certificateDocumentParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.VesselCertificateLogId, vesselCertificateLogId },
                { NavigationParameterConstant.FilesToUpload, fileNames.ToList() },
                { NavigationParameterConstant.ParentId, parentId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificateAddAttachments, navigationContext, certificateDocumentParameter);
        }

        /// <summary>
        /// Navigate to add vessel certificate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselCertificatePreview">The vessel certificate preview.</param>
        /// <param name="CertificateSummaryItem">The certificate summary item.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateAddVesselCertificate(INavigationContext navigationContext, object vesselCertificatePreview, object CertificateSummaryItem, string parentId)
        {
            var vesselCertificateParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.CertificateDetails, vesselCertificatePreview }, {NavigationParameterConstant.CertificateSummary, CertificateSummaryItem}, {NavigationParameterConstant.ParentId, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificateWizardView, navigationContext, vesselCertificateParameter);
        }


        /// <summary>
        ///   Navigates the delete restore certificate view.
        /// </summary>
        /// <param name="navigationContext">
        ///   The navigation context.
        /// </param>
        /// <param name="vesselId">
        ///   The vessel identifier.
        /// </param>
        /// <param name="certificateId">
        ///   The certificate identifier.
        /// </param>
        /// <param name="vesselCertificateId">
        ///   The vessel certificate identifier.
        /// </param>
        /// <param name="extendedNo">
        ///   The extended no.
        /// </param>
        /// <param name="parentId">
        ///   The parent identifier.
        /// </param>
        /// <param name="isRestore">
        ///   if set to <c>true</c> [is restore].
        /// </param>
        /// <param name="isactivate"></param>
        public void NavigateDeleteRestoreCertificateView(INavigationContext navigationContext, string vesselId, string certificateId, string vesselCertificateId, int? extendedNo, string parentId, bool isRestore = false, bool? isactivate = null)
        {
            var vesselCertificateParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.CertificateId, certificateId },
                {NavigationParameterConstant.VesselId,vesselId },
                {NavigationParameterConstant.CertificateExtendedNumber,extendedNo },
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.RestoreCertificateKey,isRestore},
                { NavigationParameterConstant.VesselCertificateId,vesselCertificateId},
                { NavigationParameterConstant.ActivateDeactivateCertificateKey,isactivate}

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DeleteCerificateNavigationView, navigationContext, vesselCertificateParameter);
        }

        /// <summary>
        /// Navigates to the vessel certificate audit log detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselCertificateAuditLog">The vessel certificate audit log of type <see cref="VesselCertificateAuditLogDetail"/>.</param>
        /// <param name="certificateCode">The certificate code.</param>
        /// <param name="extendedNumber">The extended number.</param>
        public void NavigateVesselCertificateAuditLogDetail(INavigationContext navigationContext, VesselCertificateAuditLogDetail vesselCertificateAuditLog, string certificateCode, int? extendedNumber)
        {
            var auditLogParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.AuditLogDetails, vesselCertificateAuditLog}, {NavigationParameterConstant.CertificateCode, certificateCode }, {NavigationParameterConstant.ExtendedNumber, extendedNumber }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificateAuditLogDetailView, navigationContext, auditLogParameters);
        }

        /// <summary>
        /// Navigates to the vessel certificate documents.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="certificateDetail">The certificate detail of type <see cref="CertificateDetail"/>.</param>
        public void NavigateVesselCertificateDocuments(INavigationContext navigationContext, CertificateDetail certificateDetail)
        {
            var certificateParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.CertificateDetails, certificateDetail}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificateDocumentsDialogView, navigationContext, certificateParameters);
        }

        /// <summary>
        /// Navigates the vessel certificate association.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void NavigateVesselCertificateAssociation(INavigationContext navigationContext, string vesselId, string vesselName)
        {
            var certificateAssociationParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId}, { NavigationParameterConstant.VesselName, vesselName}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AssociationReportView, navigationContext, certificateAssociationParameters);
        }

        /// <summary>
        /// Navigates the issue vessel certificate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="certificateId">The certificate identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="lastExpiryDate">The last expiry date.</param>
        public void NavigateIssueVesselCertificate(INavigationContext navigationContext, string vesselId, string certificateId, string vesselName, string parentId, DateTime? lastExpiryDate)
        {
            var issueCertificateParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.CertificateId, certificateId},
                { NavigationParameterConstant.VesselName, vesselName},
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.LastExpiryDateKey, lastExpiryDate}

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.IssueCertificateDialogView, navigationContext, issueCertificateParameters);
        }

        /// <summary>
        /// Navigates the edit vessel certificate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="certificateId">The certificate identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="lastUpdatedDate">The last updated date.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateEditVesselCertificate(INavigationContext navigationContext, string vesselId, string certificateId, string vesselName, DateTime? lastUpdatedDate, string parentId)
        {
            Dictionary<string, object> editCertificateParameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.CertificateId, certificateId},
                { NavigationParameterConstant.VesselName, vesselName},
                {NavigationParameterConstant.ParentId,parentId},
                {NavigationParameterConstant.LastUpdatedKey,lastUpdatedDate}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificateEditDialogView, navigationContext, editCertificateParameters);
        }

        /// <summary>
        /// Navigates the add certificate wizard.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselTypeId">The vessel type identifier.</param>
        /// <param name="CertificateSummaryItem">The certificate summary item.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateAddCertificateWizard(INavigationContext navigationContext, string vesselId, string vesselTypeId, object CertificateSummaryItem, string parentId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {NavigationParameterConstant.VesselId, vesselId},{NavigationParameterConstant.VesselTypeId, vesselTypeId},{NavigationParameterConstant.CertificateSummary, CertificateSummaryItem}, { NavigationParameterConstant.ParentId, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificatesWizardView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the incomplete certificate dailog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateIncompleteCertificateDailog(INavigationContext navigationContext, string vesselId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.IncompleteCertificatesDialogView, navigationContext, vesselId);
        }

        /// <summary>
        /// Navigates the vessel certificates.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void NavigateVesselCertificates(object parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.StartView, parameters);
        }

        /// <summary>
        /// Navigates the certificate navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateCertificateReportsNavigationView(INavigationContext context,object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CerificateReportsNavigationView, context,parameters);
        }

        /// <summary>
        /// Navigates to the Landing Page
        /// </summary>
        public void NavigatetoLandingPage()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.StartView);
        }

        /// <summary>
        /// Navigates the link requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requisitionParameters">The requisition parameters.</param>
        public void NavigateLinkRequisition(INavigationContext navigationContext, Dictionary<string, object> requisitionParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CertificatesLinkRequisitionDialogView, navigationContext, requisitionParameters);
        }

        /// <summary>
        /// Navigates the link requisition.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="requisitionParameters">The requisition parameters.</param>
        public void NavigateToViewLinkRequisition(INavigationContext navigationContext, Dictionary<string, object> requisitionParameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MappedRequisitionView, navigationContext, requisitionParameters);
        }
        #endregion
    }
}