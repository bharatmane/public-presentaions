﻿namespace VShips.Framework.Common.ModuleNavigation.Certificates
{
    /// <summary>
    /// Names of accessible views and regions related to the budget module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The expiry month range
        /// </summary>
        public const int ExpiryMonthRange = 3;

        /// <summary>
        /// The name of the module.
        /// </summary>
        public const string ModuleName = "Certificates";

        /// <summary>
        /// The icon representing the module.
        /// </summary>
        public const string ModuleIcon = "CertificatesGeometry";

        /// <summary>
        /// The cancel button text
        /// </summary>
        public const string CancelButtonText = "Cancel";

        /// <summary>
        /// The upadate button text
        /// </summary>
        public const string UpadateButtonText = "Update";

        //Views

        /// <summary>
        /// The landing or start view for the certificates module.
        /// </summary>
        public const string StartView = "CertificatesStartView";
        /// <summary>
        /// The cerificate reports navigation view
        /// </summary>
        public const string CerificateReportsNavigationView = "CerificateReportsNavigationView";

        /// <summary>
        /// The single certificate entity view.
        /// </summary>
        public const string NavItemView = "CertificatesStartItemView";

        /// <summary>
        /// Dialog used to select, edit CertificateAddView services.
        /// </summary>
        public const string CertificateAddView = "CertificateAddView";

        /// <summary>
        /// Dialog used to select, edit CertificateAddView services
        /// </summary>
        public const string CertificateAddDemoView = "CertificateAddDemoView";

        /// <summary>
        /// Dialog used to select, edit CertificateAddView services
        /// </summary>
        public const string CertificateWizardView = "CertificateWizardView";

        /// <summary>
        /// The delete cerificate navigation view
        /// </summary>
        public const string DeleteCerificateNavigationView = "DeleteCerificateNavigationView";

        /// <summary>
        /// Dialog used to select, edit CertificateSireReportView services.
        /// </summary>
        public const string CertificateSireReportView = "CertificateSireReportView";

        /// <summary>
        /// Dialog used to select, edit CertificateSireReportView services.
        /// </summary>
        public const string CertificateEditDialogView = "CertificateEditDialogView";

        /// <summary>
        /// The association report view.
        /// </summary>
        public const string AssociationReportView = "AssociationReportView";

        /// <summary>
        /// The certificate edit dialog view.
        /// </summary>
        public const string IssueCertificateDialogView = "IssueCertificateDialogView";

        /// <summary>
        /// The certificate add attachments
        /// </summary>
        public const string CertificateAddAttachments = "CertificateAddAttachments";

        /// <summary>
        /// The certificate documents dialog view
        /// </summary>
        public const string CertificateDocumentsDialogView = "CertificateDocumentsDialogView";

        /// <summary>
        /// The certificate audit log detail view
        /// </summary>
        public const string CertificateAuditLogDetailView = "CertificateAuditLogDetailView";

        /// <summary>
        /// The certificates wizard view
        /// </summary>
        public const string CertificatesWizardView = "CertificatesWizardView";

        /// <summary>
        /// The incomplete certificates dialog view
        /// </summary>
        public const string IncompleteCertificatesDialogView = "IncompleteCertificatesDialogView";

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";

        /// <summary>
        /// The parent identifier
        /// </summary>
        public const string ParentId = "ParentId";

        /// <summary>
        /// The vessel type identifier
        /// </summary>
        public const string VesselTypeId = "VesselTypeId";

        /// <summary>
        /// The link requisition dialog view
        /// </summary>
        public const string CertificatesLinkRequisitionDialogView = "CertificatesLinkRequisitionDialogView";

        /// <summary>
        /// The mapped requisition view
        /// </summary>
        public const string MappedRequisitionView = "MappedRequisitionView";
    }
}