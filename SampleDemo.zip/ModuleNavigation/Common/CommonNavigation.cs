using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Contracts.Custom.Accounts;
using VShips.Contracts.Custom.Document;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.ModuleNavigation.Crew;
using VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment;
using VShips.Framework.Common.ModuleNavigation.Inspection;
using VShips.Framework.Common.ModuleNavigation.InventoryLandingForm;
using VShips.Framework.Common.ModuleNavigation.Invoicing;
using VShips.Framework.Common.ModuleNavigation.PlannedMaintenance;
using VShips.Framework.Common.ModuleNavigation.VoyageReporting;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// Navigation for the common module.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.Common.ICommonNavigation" />
    public class CommonNavigation : BaseModuleNavigationService, ICommonNavigation
    {
        #region Constructors

        /// <summary>
        /// The default constructor.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public CommonNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Navigates to the upload cloud documents dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="files">The files.</param>
        /// <param name="matchedId">The matched identifier.</param>
        /// <param name="category">The category.</param>
        /// <param name="fileType">The file type.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="cmpId">The CMP identifier.</param>
        /// <param name="coyId">The coy identifier.</param>
        public void UploadCloudDocuments(INavigationContext context, List<string> files, string matchedId, DocumentCategory category, DocumentFileCategory? fileType = null, string crewId = null, string vesselId = null, string cmpId = null, string coyId = null)
        {
            Dictionary<string, object> p = new Dictionary<string, object>();
            p["Id"] = "";
            p["Files"] = files;
            p["MatchedId"] = matchedId;
            p["CrewId"] = crewId;
            p["VesselId"] = vesselId;
            p["CmpId"] = cmpId;
            p["CoyId"] = coyId;
            p["Category"] = category;
            p["FileType"] = fileType;
            context.ShowDialog(Constants.ModuleName, Constants.UploadCloudDocuments, p);

        }
        /// <summary>
        /// Edits a cloud document.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="cloudDocumentIdentifier">The cloud document identifier.</param>
        /// <param name="category">The category.</param>
        public void EditCloudDocument(INavigationContext context, string cloudDocumentIdentifier, DocumentCategory category)
        {
            Dictionary<string, object> p = new Dictionary<string, object>();
            p["Id"] = cloudDocumentIdentifier;
            context.ShowDialog(Constants.ModuleName, Constants.UploadCloudDocuments, p);
        }

        /// <summary>
        /// Vessels the order create invoice manually.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters"></param>
        public void VesselOrderCreateInvoiceManually(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            //Dictionary<string, object> parameter = new Dictionary<string, object>
            //{
            //    { "CoyId", accountingCompanyId }, { "OrderNumber", orderNumber },{"IsFromFinanceModule",isFromFinanceModule},{ "JournalTypeIsCreditInvoice",journalTypeIsCreditInvoice}
            //};
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselOrderCreateInvoiceManuallyView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the vessel lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselLookupParameter">The vessel lookup parameter.</param>
        public void NavigateVesselLookup(INavigationContext navigationContext, object vesselLookupParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselLookupView, navigationContext, vesselLookupParameter);
        }

        /// <summary>
        /// Navigates the common vessel lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselLookupParameter">The vessel lookup parameter.</param>
        public void NavigateCommonVesselLookup(INavigationContext navigationContext, object vesselLookupParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonVesselLookupView, navigationContext, vesselLookupParameter);
        }

        /// <summary>
        /// Navigates the inspection reference no lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateInspectionRefNoLookup(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InspectionRefNoLookupView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates all posting account code lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedAccountCodeChange">The selected account code change.</param>
        public void NavigateAllPostingAccountCodeLookup(INavigationContext navigationContext, Action<object> selectedAccountCodeChange)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SelectedAccountCodeChange, selectedAccountCodeChange}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AllPostingAccountCodeLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the voyage lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVoyageChange">The selected voyage change.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="isFromSeaPassage">if set to <c>true</c> [is from sea passage].</param>
        /// <param name="recordContainingSearchText">if set to <c>true</c> [record containing search text].</param>
        /// <param name="isAdvancePortPlanning">if set to <c>true</c> [is advance port planning].</param>
        /// <param name="parentNaigationContext">The parent naigation context.</param>
        public void NavigateVoyageLookup(INavigationContext navigationContext, Action<object> selectedVoyageChange, string vesselId, string parentId, bool isFromSeaPassage = false, bool recordContainingSearchText = false, bool isAdvancePortPlanning = false, INavigationContext parentNaigationContext = null)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SelectedVoyageChange, selectedVoyageChange },
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.IsFromSeaPassage, isFromSeaPassage },
                { NavigationParameterConstant.IsAdvancePortPlanning, isAdvancePortPlanning },
                { NavigationParameterConstant.RecordContainingSearchText, recordContainingSearchText },
                { NavigationParameterConstant.ParentNavigationContext, parentNaigationContext }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VoyageLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the chart detail account lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="request">The request.</param>
        /// <param name="listnerToken">messenger token to distinguish different calls</param>
        /// <param name="selectedAccountChange">The selected account change.</param>
        public void NavigateChartDetailAccountLookup(INavigationContext navigationContext, ChartAccountDetailRequest request, string listnerToken, Action<object> selectedAccountChange)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {"Request", request}, {"ListnerToken", listnerToken} , {"SelectedAccountChangeAction", selectedAccountChange}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ChartDetailAccountLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the maker lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateMakerLookup(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MakerLookupView, navigationContext);
        }

        /// <summary>
        /// Navigates the designer lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentCategoryId"></param>
        public void NavigateDesignerLookup(INavigationContext navigationContext, string componentCategoryId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DesignerLookupView, navigationContext, componentCategoryId);
        }

        /// <summary>
        /// Navigates the moc lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateMocLookup(INavigationContext navigationContext, string vesselId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MocLookupView, navigationContext, vesselId);
        }

        /// <summary>
        /// Navigates the jsa lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        public void NavigateJsaLookup(INavigationContext navigationContext, string vesselId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.JSALookupView, navigationContext, vesselId);
        }

        /// <summary>
        /// Navigates the model lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentCategoryId">The component category identifier.</param>
        public void NavigateModelLookup(INavigationContext navigationContext, string componentCategoryId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ModelLookupView, navigationContext, componentCategoryId);
        }

        /// <summary>
        /// Navigates the oil grade type lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateOilGradeTypeLookup(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OilGradeTypeLookupView, navigationContext);
        }

        /// <summary>
        /// Navigates the order search.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateOrderSearch(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OrderSearchView, navigationContext);
        }

        /// <summary>
        /// Navigates the create memo.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="createMemoParameter">The create memo parameter.</param>
        public void NavigateCreateMemo(INavigationContext navigationContext, CreateMemoParameter createMemoParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateMemoView, navigationContext, createMemoParameter);
        }

        /// <summary>
        /// Navigates the account code lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountCodeLookupParamater">The account code lookup paramater.</param>
        public void NavigateAccountCodeLookup(INavigationContext navigationContext, object accountCodeLookupParamater)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccountCodeLookupDialog, navigationContext, accountCodeLookupParamater);
        }

        /// <summary>
        /// Navigates the invoice comparator.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateInvoiceComparator(InvoiceComparatorFilter parameter)
        {
            NavigationService.NavigateExisting(Invoicing.Constants.ModuleName, Invoicing.Constants.InvoiceCamparatorView, parameter);
        }

        /// <summary>
        /// Navigates the order accruals report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateOrderAccrualsReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OrderAccrualsReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the outstanding delivery information report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateOutstandingDeliveryInformationReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OutstandingDeliveryInformationReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the outstanding order by account report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateOutstandingOrderByAccountReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OutstandingOrderByAccountReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the supplier purchase orders report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateSupplierPurchaseOrdersReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SupplierPurchaseOrdersReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the vessel order status report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateVesselOrderStatusReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselOrderStatusReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the comparison invoice report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateComparisonInvoiceReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ComparisonInvoiceReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the vessel stored orders report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateVesselStoredOrdersReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselStoredOrdersReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the vessel defect List report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateVesselDefectListReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselDefectListReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the vessel Inspection List report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateVesselInspectionListReport(INavigationContext navigationContext, ParameterOverrides parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselInspectionListReportView, navigationContext, parameters);
        }

        /// <summary>
        /// Invoices the main dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        /// <param name="allowToCreateOrReplyToMemo">if set to <c>true</c> [allow to create or reply to memo].</param>
        /// <param name="isForEntityAccountingCompany"></param>
        public void InvoiceMainDialogView(INavigationContext navigationContext, string accountingCompanyId, string voucherNo, string invoiceHeaderId, bool allowToCreateOrReplyToMemo, bool isForEntityAccountingCompany)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.VoucherNo, voucherNo},
                {Constants.InvoiceHeaderId, invoiceHeaderId},
                {Constants.AllowToCreateOrReplyToMemo, allowToCreateOrReplyToMemo},
                {Constants.IsForEntityAccountingCompany,isForEntityAccountingCompany }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InvoiceMainView, navigationContext, parameter);
        }

        /// <summary>
        /// Entities the invoice main dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>       
        public void EntityInvoiceMainDialogView(INavigationContext navigationContext, string accountingCompanyId, string voucherNo, string invoiceHeaderId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.VoucherNo, voucherNo},
                {Constants.InvoiceHeaderId, invoiceHeaderId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityInvoiceMainDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Entities the ar invoice main dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        public void EntityARInvoiceMainDialogView(INavigationContext navigationContext, string accountingCompanyId, string voucherNo, string invoiceHeaderId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.VoucherNo, voucherNo},
                {Constants.InvoiceHeaderId, invoiceHeaderId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityARInvoiceMainDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Entities the invoice create memo dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void EntityInvoiceCreateMemoDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityInvoiceCreateMemoDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates the attach invoice document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="multiAttachmentPath">The attachment path.</param>
        public void NavigateEmailDialog(INavigationContext navigationContext, string subject, List<string> multiAttachmentPath)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.EmailSubject, subject},
                {Constants.AttachmentPath, multiAttachmentPath != null ? multiAttachmentPath.ToList():new List<string>()}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EmailDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the rank lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void NavigateRankLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SearchText, searchText},
                {Constants.Action, selectedItemChanged},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RankLookupViewDialog, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the site lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void NavigateSiteLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SearchText, searchText},
                {Constants.Action, selectedItemChanged},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SiteLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the crew lookup view.
        /// </summary>
        /// <param name="navigationContext">The naviagtion context.</param>
        /// <param name="crewDetails">The crew details.</param>
        public void NavigateCrewLookupView(INavigationContext navigationContext, object crewDetails)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewLookupView, navigationContext, crewDetails);
        }

        /// <summary>
        /// Navigates the on board crew lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewDetails">The crew details.</param>
        public void NavigateOnBoardCrewLookupView(INavigationContext navigationContext, object crewRequest, string parentID)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SharedObject, crewRequest },
                { NavigationParameterConstant.ParentId, parentID }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OnBoardCrewLookupView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the disputed invoice report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateDisputedInvoiceReport(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DisputedInvoiceReportView, navigationContext, null);
        }

        /// <summary>
        /// Navigates the create order memo.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="createMemoParameter">The create memo parameter.</param>
        public void NavigateCreateOrderMemoView(INavigationContext navigationContext, CreateMemoParameter createMemoParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateOrderMemoView, navigationContext, createMemoParameter);
        }

        /// <summary>
        /// Navigates the system area component TreeView.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateSystemAreaComponentTreeView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SystemAreaComponentTreeView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add supporting document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters"></param>
        public void NavigateAddSupportingDocument(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.POSupportingDocNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the accounting company lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedAccountingCompanyChange">The selected accounting company change.</param>
        public void NavigateAccountingCompanyLookup(INavigationContext navigationContext, Action<object> selectedAccountingCompanyChange)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SelectedAccountingCompanyChange, selectedAccountingCompanyChange}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccountingCompanyLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the category lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isActive">The is active.</param>
        /// <param name="level">The level.</param>
        /// <param name="selectedCategory">The selected category.</param>
        public void NavigateCategoryLookupView(INavigationContext navigationContext, bool? isActive, int? level, Action<object> selectedCategory)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.IsActive, isActive },
                { NavigationParameterConstant.CategoryLevel, level  },
                { Constants.Action, selectedCategory}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TOMCategoryLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the type lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isActive">The is active.</param>
        /// <param name="selectedType">Type of the selected.</param>
        public void NavigateTypeLookupView(INavigationContext navigationContext, bool? isActive, Action<object> selectedType)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.IsActive, isActive },
                { Constants.Action, selectedType}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TOMTypeLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the tom system area category lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedSystemArea">The selected system area.</param>
        public void NavigateTOMSystemAreaLookupView(INavigationContext navigationContext, Action<object> selectedSystemArea)
        {
            var parameter = new Dictionary<string, object>
            {
                { Constants.Action, selectedSystemArea}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TOMSystemAreaLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        public void NavigateAddAttachments(INavigationContext navigationContext, AttachmentParameters parameters, IEnumerable<string> fileNames, string parentId, string documentId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.Parameters, parameters},
                { NavigationParameterConstant.FilesToUpload, fileNames != null ? fileNames.ToList() : new List<string>()},
                { NavigationParameterConstant.ParentNavigationIdKey, parentId},
                { NavigationParameterConstant.DocumentId, documentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAttachmentsNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Adds the edit recharge lines dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="rechargeCompanyCode">The recharge company code.</param>
        /// <param name="rechargeCompanyType">Type of the recharge company.</param>
        /// <param name="allowRecharge">if set to <c>true</c> [allow recharge].</param>
        /// <param name="customerCompany"></param>
        public void AddEditRechargeLinesDialogView(INavigationContext navigationContext, string rechargeCompanyCode, string rechargeCompanyType, bool allowRecharge, string customerCompany)
        {
            var parameters = new Dictionary<string, object>
            {
                {Common.Constants.RechargeCompanyCode, rechargeCompanyCode},
                {Common.Constants.RechargeCompanyType, rechargeCompanyType},
                {Common.Constants.AllowRecharge, allowRecharge},
                {Common.Constants.CustomerCompany, customerCompany}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditRechargeLinesDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the company lookup view model.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateCompanyLookupView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyLookupDialog, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates Company lookup Mapping ViewModel
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="parameter"></param>
        public void NavigateCompanyChildMappingView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyChildMappingViewDialog, navigationContext, parameter, 120, 75);
        }
        /// <summary>
        /// Navigates the vessel service lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedServiceChange">The selected service change.</param>
        public void NavigateVesselServiceLookupView(INavigationContext navigationContext, string vesselId, Action<object> selectedServiceChange)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SelectedServiceChange, selectedServiceChange},
                {Constants.VesselId, vesselId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselServiceLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the payroll client vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="clientId">The client identifier.</param>
        /// <param name="checkTimesheetApplicableFlag">if set to <c>true</c> [check timesheet applicable flag].</param>
        /// <param name="selectedVesselChange">The selected vessel change.</param>
        public void NavigatePayrollClientVesselLookupView(INavigationContext navigationContext, string clientId, bool checkTimesheetApplicableFlag, Action<object> selectedVesselChange)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.Action, selectedVesselChange},
                {Constants.ClientId, clientId},
                {Constants.CheckTimesheetApplicableFlag, checkTimesheetApplicableFlag}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PayrollClientVesselLookupView, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates the hierarchy explorer.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateHierarchyExplorer(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HierarchyExplorerView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the hierarchy system area.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateHierarchySystemArea(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HierarchySystemAreaView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the bank detail view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supplierId">The supplier identifier.</param>
        /// <param name="supplierName">Name of the supplier.</param>
        public void NavigateBankDetailView(INavigationContext navigationContext, string supplierId, string supplierName)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SupplierId,supplierId},
                { Constants.SupplierName,supplierName }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BankDetailDialogView, navigationContext, parameters);
        }


        /// <summary>
        /// Navigates the user login.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        public void NavigateUserLogin(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TransferFilesLoginView, navigationContext);
        }


        #endregion

        #region Global Search

        /// <summary>
        /// Navigates the global search.
        /// </summary>
        /// <param name="moduleName">Name of the module.</param>
        /// <param name="viewName">Name of the view.</param>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isDialog">if set to <c>true</c> [is dialog].</param>
        /// <param name="isNavigateExisting">if set to <c>true</c> [is navigate existing].</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateGlobalSearch(string moduleName, string viewName, INavigationContext navigationContext, bool isDialog, bool isNavigateExisting, string parameter)
        {
            if (isDialog)
            {
                if (navigationContext == null)
                {
                    navigationContext = ServiceLocator.Current.GetInstance<INavigationService>().ActiveContext;
                }
                NavigationService.NavigateDialog(moduleName, viewName, navigationContext, parameter);
            }
            else if (isNavigateExisting)
            {
                NavigationService.NavigateExisting(moduleName, viewName, parameter, navigationContext);
            }
            else
            {
                NavigationService.NavigateNew(moduleName, viewName, parameter, navigationContext);
            }

        }

        #endregion

        /// <summary>
        /// Seas the routes weather detail navigation.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="seaRoutesWeather">The sea routes weather.</param>
        /// <param name="top">The top.</param>
        /// <param name="left">The left.</param>
        public void SeaRoutesWeatherDetailNavigation(INavigationContext navigationContext, SeaRoutesWeatherFeatures seaRoutesWeather, double top, double left)
        {
            var seaRoutesWeatherParameter = new Dictionary<string, object>
            {
                { AutoLog.Constants.SeaRoutesWeather, seaRoutesWeather }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SeaRoutesWeatherDetailView, navigationContext, seaRoutesWeatherParameter, top, left);
        }

        /// <summary>
        /// Navigates the form template preview.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="formTemplateId">The form template identifier.</param>
        public void NavigateFormTemplatePreview(INavigationContext navigationContext, string formTemplateId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FormTemplatePreviewView, navigationContext, formTemplateId);
        }

        /// <summary>
        /// Navigates the map spares dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="addedPartIds">The added part ids.</param>
        public void NavigateMapSparesDialog(INavigationContext navigationContext, string vesselId, string parentId, string componentId, List<object> addedPartIds)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>()
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.ComponentId, componentId },
                { NavigationParameterConstant.PartListKey, addedPartIds }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapSparesDialogView, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates the adjust inventory stock.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedSpare">The selected spare.</param>
        public void NavigateAdjustStock(INavigationContext navigationContext, string vesselId, string parentId, object selectedSpare)
        {
            var parameters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId},
                { NavigationParameterConstant.SelectedSpare, selectedSpare},
                { NavigationParameterConstant.ParentId, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonAdjustStockView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to the add inventory location.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void NavigateAddInventoryLocation(INavigationContext navigationContext, string vesselId, string parentId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ParentId, parentId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonAddLocationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to add edit staff.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="staffParameter">The staff parameter.</param>
        public void NavigateToAddEditStaff(INavigationContext navigationContext, Dictionary<string, object> staffParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonAddEditStaffDialogView, navigationContext, staffParameter);
        }

        /// <summary>
        /// Auxiliaries the list lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="auxiliaryName">Name of the auxiliary.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="parentNavigationId">The parent navigation identifier.</param>
        public void AuxiliaryListLookupView(INavigationContext navigationContext, Auxiliary auxiliaryName, string accountingCompanyId, string searchText, string parentNavigationId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.AccountingCompanyId, accountingCompanyId },
                { NavigationParameterConstant.CurrentTextSearch, searchText },
                { NavigationParameterConstant.AuxName, auxiliaryName },
                { NavigationParameterConstant.ParentId, parentNavigationId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AuxiliaryListLookupViewDialog, navigationContext, parameter);
        }

        /// <summary>
        /// Fixeds the asset project lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="searchText">The search text.</param>
        public void FixedAssetProjectLookupView(INavigationContext navigationContext, string accountingCompanyId, string searchText)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.AccountingCompanyId, accountingCompanyId },
                { NavigationParameterConstant.CurrentTextSearch, searchText }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedAssetProjectLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Crewings the navigate user vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void CrewingUserVesselLookupViewNavigate(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SearchText, searchText},
                {Constants.Action, selectedItemChanged},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CrewUserVesselLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Generals the parameter value multi select dialog navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="rrpId">The RRP identifier.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="mappedIds">The mapped ids.</param>
        public void GeneralParameterValueMultiSelectDialogNavigate(INavigationContext navigationContext, string parameterName, string rrpId, string reportId, Action<object> selectedItemChanged, List<string> mappedIds)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SelectedId, rrpId},
                {Constants.SelectedParameterName, parameterName},
                {Constants.ReportId, reportId},
                {Constants.Action, selectedItemChanged},
                {Constants.MappedIds, mappedIds }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GeneralParameterValueMultiSelectDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the link hazocc dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateLinkHazoccDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkHazoccNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Reports the fleet tree dialog navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="userMenuItemTypes">The user menu item types.</param>
        /// <param name="selectedItem">The selected item.</param>
        public void ReportFleetTreeDialogNavigate(INavigationContext navigationContext, Action<object> selectedItemChanged, string userMenuItemTypes, object selectedItem)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.Action, selectedItemChanged},
                {Constants.RequiredTypes, userMenuItemTypes },
                {Constants.SelectedItem, selectedItem }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportFleetTreeDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the usage history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateUsageHistory(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonSparesUsageHistoryView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the duplicate spare detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateDuplicateSpareDetail(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DuplicateSpareDetailView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add link.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="childItemId">The child item identifier.</param>
        /// <param name="selectedDocument">The selected document.</param>
        public void NavigateAddLink(INavigationContext navigationContext, AttachmentParameters parameters, string parentId, string documentId, string childItemId, DocumentDetail selectedDocument)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.Parameters, parameters },
                { NavigationParameterConstant.ParentNavigationIdKey, parentId },
                { NavigationParameterConstant.DocumentId, documentId },
                { NavigationParameterConstant.SelectedDocument, selectedDocument },
                { NavigationParameterConstant.ChildItemNavigationIdKey, childItemId },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddLinkNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the haz occ lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="fromDate">From date.</param>
        /// <param name="reportId">The report identifier.</param>
        public void NavigateHazOccLookup(INavigationContext navigationContext, string vesselId, DateTime fromDate, string reportId)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.FromDate, fromDate },
                { NavigationParameterConstant.HazOccReportId, reportId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HazOccLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to port call agents details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToPortCallAgentsDetails(INavigationContext context, VoyageListParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PortCallAgentsDetailsView, context, parameter);
        }

        /// <summary>
        /// Navigates the HDM crew lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="crewRequest">The crew request.</param>
        /// <param name="parentID">The parent identifier.</param>
        public void NavigateHDMCrewLookupView(INavigationContext navigationContext, object crewRequest, string parentID)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.SharedObject, crewRequest },
                { NavigationParameterConstant.ParentId, parentID }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HDMCrewLookupView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the search location dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateSearchLocationDialog(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SearchLocationDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to map associated jobs.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToMapAssociatedJobs(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapAssociatedJobView, context, parameters);
        }

        /// <summary>
        /// Navigates the map risk assessment view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateMapRiskAssessmentView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapRiskAssessmentView, context, parameters);
        }

        /// <summary>
        /// Navigations the add edit hazard.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigationAddEditHazard(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditHazardNavigationView, context, parameters);
        }

        /// <summary>
        /// Navigates to add furter control measure view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAddFurterControlMeasureView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddFurtherControlMeasureView, context, parameters);
        }

        /// <summary>
        /// Navigates to mapped risk assessment.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToMappedRiskAssessment(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MappedRiskAssessmentView, context, parameters);
        }

        /// <summary>
        /// Navigates the document history request.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="documentId">The document identifier.</param>
        public void NavigateDocumentHistoryRequest(INavigationContext context, string documentId)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.DocumentId, documentId},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DocumentRequestHistoryView, context, paramters);
        }

        /// <summary>
        /// Navigates to dynamic report listing view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToDynamicReportListingView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DynamicReportListingView, context, parameter);
        }

        /// <summary>
        /// Navigates to dynamic report parameters view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToDynamicReportParametersView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DynamicReportParametersView, context, parameter);
        }

        /// <summary>
        /// Navigates to maker details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="makerId">The maker identifier.</param>
        public void NavigateToMakerDetailsView(INavigationContext context, string makerId)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MakerDetailsNavigationView, context, makerId);
        }

        /// <summary>
        /// Navigates to document preview view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="prameter">The prameter.</param>
        public void NavigateToDocumentPreviewView(INavigationContext context, object prameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DocumentPreviewView, context, prameter);
        }

        /// <summary>
        /// Navigates to automatic scan pc view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="prameter">The prameter.</param>
        public void NavigateToAutoScanPCView(INavigationContext context, object prameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AutoScanPCView, context, prameter);
        }


        /// <summary>
        /// Navigates to export to PDF and excel view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="title">The title.</param>
        /// <param name="reportTypes">The repor types.</param>
        public void NavigateToExportToPdfAndExcelView(INavigationContext navigationContext, string title, List<ReportExportTypes> reportTypes, Action<ReportExportTypes> actionToBePerformed)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
                { NavigationParameterConstant.Title, title},
                { NavigationParameterConstant.ReportTypeList, reportTypes},
                { NavigationParameterConstant.ActionToBePerformed, actionToBePerformed}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExportToPdfAndExcelView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates to port services dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToPortServicesDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PortServicesDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to acknowledge alert dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAcknowledgeAlertDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AcknowledgeAlertDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to pending acknowledgements dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToPendingAcknowledgementsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PendingAcknowledgementDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to vessel lookup for insurance view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="CurrentSearhText">The current searh text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void NavigateToVesselLookupForInsuranceView(INavigationContext navigationContext, string CurrentSearhText, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> paramters = new Dictionary<string, object>
            {
               { NavigationParameterConstant.CurrentTextSearch, CurrentSearhText },
               {Constants.Action, selectedItemChanged}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselLookupForInsuranceView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates the report crew multi select dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewChanged">The selected crew changed.</param>
        /// <param name="selectedCrews">The selected crews.</param>
        /// <param name="reportId">The report identifier.</param>
        public void NavigateReportCrewMultiSelectDialog(INavigationContext navigationContext, Action<object> selectedCrewChanged, object selectedCrews, string reportId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.Action, selectedCrewChanged},
                {Constants.SelectedCrews, selectedCrews },
                {Constants.ReportId, reportId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportCrewMultiSelectDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the report crew single select dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewChanged">The selected crew changed.</param>
        /// <param name="selectedCrew">The selected crew.</param>
        public void NavigateReportCrewSingleSelectDialog(INavigationContext navigationContext, Action<object> selectedCrewChanged, object selectedCrew)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.Action, selectedCrewChanged},
                {Constants.SelectedItem, selectedCrew}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ReportCrewSingleSelectDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to order details report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="orderNumber">The order number.</param>
        public void NavigateToOrderDetailsReport(INavigationContext navigationContext, string accountingCompanyId, string orderNumber)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
               { NavigationParameterConstant.AccountingCompanyId, accountingCompanyId},
                { NavigationParameterConstant.OrderNumber, orderNumber}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OrderDetailsReportView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the view attachments dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateViewAttachmentsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewAttachmentsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the common attachments dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateCommonAttachmentsDialog(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonAttachmentsDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the link jsa dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateLinkJSADialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkVesselJSADialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the link jsa dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateLinkVesselDefectsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkVesselDefectView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the link vessel requisition dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateLinkVesselRequisitionDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkVesselRequisitionDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the link work orders dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateLinkWorkOrdersDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkWorkOrdersDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the link generic spares dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateLinkGenericSparesDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkGenericSparesDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the map generic ranks dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateMapGenericRanksDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GenericMapRanksDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to payroll vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void NavigateToPayrollVesselLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SearchText, searchText},
                {Constants.Action, selectedItemChanged},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PayrollAllVesselLookupView, navigationContext, parameter);
        }

        #region Inspection Maintainer

        /// <summary>
        /// Navigates map the questions view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateMapQuestionsView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapQuestionView, context, parameter);
        }

        /// <summary>
        /// Navigates the questions library view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateQuestionsLibraryView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.QuestionLibraryView, context, parameter);
        }

        /// <summary>
        /// Navigates the add edit question view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddEditQuestionView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditQuestionView, context, parameter);
        }

        /// <summary>
        /// Navigates the image viewer.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateImageViewer(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ImageViewerDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the add edit user defined List view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAddEditUserDefinedListView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditUserDefinedListView, context, parameter);
        }

        #endregion

        /// <summary>
        /// Navigates to allocate spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAllocateSpareView(INavigationContext navigationContext, PMSNavigationParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BlockSpareView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to allocated spare detail view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToAllocatedSpareDetailView(INavigationContext navigationContext, PMSNavigationParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewBlockedSpareDetail, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to entity order search dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToEntityOrderSearchDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityOrderSearchNavigationView, navigationContext);
        }

        /// <summary>
        /// Navigates to link spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToLinkSpareView(INavigationContext navigationContext, PMSNavigationParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkSpareNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to defect work orders view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToDefectWorkOrdersView(INavigationContext navigationContext, CommonViewNavigationParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectWorkOrdersView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to order deliveries view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToOrderDeliveriesView(INavigationContext navigationContext, CommonViewNavigationParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OrderDeliveriesView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the create memo.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="createMemoParameter">The create memo parameter.</param>
        public void NavigateCreateEntityMemo(INavigationContext navigationContext, CreateEntityMemoNavigationParameter createMemoParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreateEntityMemoView, navigationContext, createMemoParameter);
        }

        /// <summary>
        /// Navigates the common link spare.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="addedPartIds">The added part ids.</param>
        /// <param name="isLinkStore">if set to <c>true</c> [is link store].</param>
        /// <param name="isMapSpare">if set to <c>true</c> [is map spare].</param>
        public void NavigateCommonLinkSpare(INavigationContext navigationContext, string vesselId, string componentId, string parentId, List<string> addedPartIds, bool isLinkStore, bool isMapSpare = false)
        {
            var addPartParameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.ComponentId, componentId } ,
                { NavigationParameterConstant.ParentId, parentId },
                { NavigationParameterConstant.IsStoreKey, isLinkStore },
                { NavigationParameterConstant.PartListKey, addedPartIds },
                { NavigationParameterConstant.IsMapSpareKey,isMapSpare}

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonLinkSpareView, navigationContext, addPartParameter);
        }


        /// <summary>
        /// Navigates to defect required spares view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToDefectRequiredSparesView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.DefectRequiredSparesView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the vessel inspection never done view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateVesselInspectionNeverDoneView(INavigationContext context, InspectionsStartParameters parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselInspectionNeverDoneDetailView, context, parameters);
        }

        /// <summary>
        /// Navigates the add port call activity against inspection view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddPortCallActivityAgainstInspectionView(INavigationContext context, CommonViewNavigationParameter parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddPortCallActivityAgainstInspectionView, context, parameters);
        }

        /// <summary>
        /// Navigates the map spares dailogue.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateMapSparesDailogue(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonMapSpareNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the map component.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="componentIds">The component ids.</param>
        /// <param name="isCalendar">if set to <c>true</c> [is calendar].</param>
        /// <param name="isRunningHours">if set to <c>true</c> [is running hours].</param>
        /// <param name="isRevolution">if set to <c>true</c> [is revolution].</param>
        /// <param name="isEvents">if set to <c>true</c> [is events].</param>
        /// <param name="isJobDetails">if set to <c>true</c> [is job details].</param>
        public void NavigateMapComponent(INavigationContext navigationContext, string vesselId, string vesselName, string parentId, List<string> componentIds, bool isCalendar, bool isRunningHours, bool isRevolution, bool isEvents, bool isJobDetails = true)
        {
            var parameter = new Dictionary<string, object>
            {
                { NavigationParameterConstant.VesselId, vesselId },
                { NavigationParameterConstant.VesselName, vesselName },
                { NavigationParameterConstant.ParentId, parentId},
                { NavigationParameterConstant.ComponentIdListKey, componentIds},
                { NavigationParameterConstant.IsCalendarKey, isCalendar},
                { NavigationParameterConstant.IsRunningHoursKey, isRunningHours},
                { NavigationParameterConstant.IsRevolutionsKey, isRevolution},
                { NavigationParameterConstant.IsEventsKey, isEvents},
                {NavigationParameterConstant.IsJobDetailsKey, isJobDetails}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonMapComponentView, navigationContext, parameter);
        }
        /// <summary>
		/// Navigats to vessel location map view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameter">The parameter.</param>
		/// <returns></returns>
		public void NavigatToVesselLocationMapView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselLocationMapView, navigationContext, parameter);
        }
        /// <summary>
        /// Navigates the link work order history navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateLinkWorkOrderHistoryNavigationView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkWorkOrderHistoryNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the link landing port dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateLinkLandingPortDialog(INavigationContext navigationContext, LandingFormNavigationParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonLinkLandingPortDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the entity order create invoice manually.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateEntityOrderCreateInvoiceManually(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityPOCreateInvoiceDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the entity po edit recharge dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateEntityPOEditRechargeDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityPOEditRechargeDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the entity po add edit recovery dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateEntityPOAddEditRecoveryDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityPOAddEditRecoveryDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the entity invoice comparator.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateEntityInvoiceComparator(object parameter)
        {
            NavigationService.NavigateExisting(Invoicing.Constants.ModuleName, Invoicing.Constants.EntityInvoiceComparatorNavigationView, parameter);
        }

        /// <summary>
        /// Navigates to add edit osa job approvers view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        public void NavigateToAddEditOsaJobApproversView(INavigationContext context, OsaNavigationParameter osaParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditOsaJobApproversView, context, osaParameter);
        }

        /// <summary>
        /// Navigates to add to landing basket view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateToAddToLandingBasketView(INavigationContext context, LandingBasketNavigationParameter navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddToLandingBasketView, context, navigationParameter);
        }

        /// <summary>
        /// Navigates to landing basket view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateToLandingBasketView(INavigationContext context, LandingBasketNavigationParameter navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LandingBasketNavigationView, context, navigationParameter);
        }

        /// <summary>
        /// Navigates the entity service lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameterd">The parameterd.</param>
        public void NavigateEntityServiceLookupView(INavigationContext navigationContext, Dictionary<string, object> parameterd)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityServiceLookupView, navigationContext, parameterd);
        }

        /// <summary>
        /// Navigates to add new landing basket item view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateToAddNewLandingBasketItemView(INavigationContext context, LandingBasketNavigationParameter navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddNewLandingBasketItemView, context, navigationParameter);
        }

        /// <summary>
        /// Navigates to reject landing view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateToRejectLandingView(INavigationContext context, LandingBasketNavigationParameter navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RejectLandingView, context, navigationParameter);
        }

        /// <summary>
        /// Navigates to copy agent detail view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateToCopyAgentDetailView(INavigationContext context, CommonViewNavigationParameter navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyAgentDetailView, context, navigationParameter);
        }

        /// <summary>
        /// Commons the navigation map company ports.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="refreshParent">The refresh parent.</param>
        public void CommonNavigationMapCompanyPorts(INavigationContext navigationContext, string companyId, Action refreshParent)
        {
            var parameter = new Dictionary<string, object>
            {
                {Common.Constants.SelectedId, companyId},
                {Common.Constants.Action, refreshParent}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapPortsView, navigationContext, parameter);
        }

        /// <summary>
        /// Commons the navigate add attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="CertificateIdentifier">The certificate identifier.</param>
        public void CommonNavigateAddAttachments(INavigationContext navigationContext, string companyId, IEnumerable<string> fileNames, string CertificateIdentifier, Action refresh)
        {
            var p = new Dictionary<string, object>
            {
                { Constants.CompanyId, companyId },
                { Constants.Files, fileNames !=null ?  fileNames.ToList() : null },
                {  Constants.CompanyCertificateId, CertificateIdentifier },
                { Constants.Action, refresh}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonAddAttachmentsView, navigationContext, p);
        }

        /// <summary>
        /// Companies the maintainer navigate common add edit delivery address view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="deaId">The dea identifier.</param>
        /// <param name="cmpID">The CMP identifier.</param>
        /// <param name="refresh">The refresh.</param>
        public void CompanyMaintainerNavigateCommonAddEditDeliveryAddressView(INavigationContext navigationContext, string deaId, string cmpID, Action refresh)
        {
            var parameter = new Dictionary<string, object>
            {
                {Common.Constants.DeaId,deaId },
                {Common.Constants.CmpId,cmpID },
                {Common.Constants.Action, refresh }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAddEditDeliveryAddressView, navigationContext, parameter);
        }

        /// <summary>
        /// Companies the maintainer navigate add edit contact view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="ccoId">The cco identifier.</param>
        /// <param name="cmpID">The CMP identifier.</param>
        /// <param name="refresh">The refresh.</param>
        public void CompanyMaintainerNavigateAddEditContactView(INavigationContext navigationContext, string ccoId, string cmpID, Action refresh)
        {
            var parameter = new Dictionary<string, object>
            {
                {Common.Constants.CcoId,ccoId },
                {Common.Constants.CmpId,cmpID },
                {Common.Constants.Action, refresh }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAddEditContactsView, navigationContext, parameter);
        }

        /// <summary>
        /// Companies the maintainer navigate associate supplier view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CompanyMaintainerNavigateAssociateSupplierView(INavigationContext navigationContext, ParameterOverrides parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAssociatedNewSupplierView, navigationContext, parameters);
        }

        /// <summary>
        /// Companies the maintainer navigate service view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        public void CompanyMaintainerNavigateServiceView(INavigationContext navigationContext, ParameterOverrides parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAddEditServiceView, navigationContext, parameters);
        }

        /// <summary>
        /// Companies the maintainer navigate currency view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        public void CompanyMaintainerNavigateCurrencyView(INavigationContext navigationContext, ParameterOverrides parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAddEditCurrenciesView, navigationContext, parameters);
        }

        /// <summary>
        /// Companies the maintainer navigate contract view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        public void CompanyMaintainerNavigateContractView(INavigationContext navigationContext, ParameterOverrides parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAddEditContractsView, navigationContext, parameters);
        }

        /// <summary>
        /// Companies the maintainer navigate commodity view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        public void CompanyMaintainerNavigateCommodityView(INavigationContext navigationContext, ParameterOverrides parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerCommonAddEditCommoditiesView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates to add edit manage discounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="discountDetail">The discount detail.</param>
        /// <param name="onSave">The on save.</param>
        /// <param name="fromAdd"></param>
        public void NavigateToAddEditManageDiscountsDialogView(INavigationContext navigationContext, object discountDetail, Action<object, object> onSave, bool fromAdd)
        {
            var parameter = new Dictionary<string, object>();
            parameter.Add(NavigationParameterConstant.DiscountDetail, discountDetail);
            parameter.Add(NavigationParameterConstant.IsAdd, fromAdd);
            parameter.Add(NavigationParameterConstant.ActionDetail, onSave);
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditManageCommonDiscountsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to view manage discounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToViewManageDiscountsDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewManageDiscountsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to manage discounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="onSave">The on save.</param>
        public void NavigateToManageDiscountsDialogView(INavigationContext navigationContext, string companyId, Action onSave)
        {
            var parameter = new Dictionary<string, object>();
            parameter.Add(Constants.CompanyId, companyId);
            parameter.Add(NavigationParameterConstant.ActionDetail, onSave);
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ManageCommonDiscountsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Companies the maintainer navigate add edit bank details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CompanyMaintainerNavigateAddEditBankDetailsView(INavigationContext navigationContext, object parameter, Action Refresh)
        {
            var p = parameter as Dictionary<string, object>;
            p.Add(Constants.Action, Refresh);

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BankDetailsCommonAddEditNavigationView, navigationContext, p);
        }

        /// <summary>
        /// Companies the maintainer navigate bank details iban view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="Iban">The iban.</param>
        /// <param name="SetBankDetails">The set bank details.</param>
        /// <param name="isNavigationFromAdd">if set to <c>true</c> [is navigation from add].</param>
        public void CompanyMaintainerNavigateBankDetailsIbanView(INavigationContext navigation, string Iban, Action SetBankDetails, bool isNavigationFromAdd)
        {
            var parameter = new Dictionary<string, object>()
            {
                {Constant.Action, SetBankDetails },
                {Constants.Iban, Iban },
                {Constants.IsNavigationFromAdd, isNavigationFromAdd }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BankDetailsIBanView, navigation, parameter);
        }

        /// <summary>
        /// Companies the maintainer navigate add edit bank details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CompanyMaintainerNavigateViewBankDetailsView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BankDetailsCommonAddEditNavigationView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to map ods gas landed items view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToMapOdsGasLandedItemsView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapOdsGasLandedItemsView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to get working list type from user view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToGetWorkingListTypeFromUserView(INavigationContext context, WorkingListParameters parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GetWorkingListTypeFromUserView, context, parameter);
        }

        /// <summary>
        /// Navigates to management date guide lines view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToManagementDateGuideLinesView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ManagementDateGuidelinesNavigationView, navigationContext);
        }

        /// <summary>
        /// Cancels the service dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CancelServiceDialogView(INavigationContext navigationContext, Dictionary<string, object> parameter, Action refreshServiceList)
        {
            if (parameter != null)
            {
                parameter.Add(Constants.RefreshList, refreshServiceList);
            }

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CancelServiceDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Closes the service dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void CloseServiceDialogView(INavigationContext navigationContext, Dictionary<string, object> parameter, Action refreshServiceList)
        {
            if (parameter != null)
            {
                parameter.Add(Constants.RefreshList, refreshServiceList);
            }

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CloseServiceDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to upload guidance document view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToUploadGuidanceDocumentView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UploadGuidanceDocumentView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the preview document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigatePreviewDocument(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerDocumentPreviewDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the add edit document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddEditDocument(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerAttachmentAddDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the management company detail dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="managementId">The management identifier.</param>
        public void NavigateManagementCompanyDetailDialogView(INavigationContext context, string managementId)
        {
            Dictionary<string, object> managementParameter = new Dictionary<string, object>
            {
                 { NavigationParameterConstant.ManagementId, managementId },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ManagementCompanyDetailDialogView, context, managementParameter);
        }

        /// <summary>
        /// Navigates the marine rank lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        public void NavigateMarineRankLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.SearchText, searchText},
                {Constants.Action, selectedItemChanged},
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MarineRankLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the add invoice order line tax delivery dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddInvoiceOrderLineTaxDeliveryDialogView(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddInvoiceOrderLineTaxOrDeliveryView, context, parameters);
        }

        /// <summary>
        /// Navigates to entity po order lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="paramters">The parameter.</param>
        public void NavigateToEntityPOOrderLookupDialogView(INavigationContext navigationContext, Dictionary<string, object> paramters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityPOOrderLookupView, navigationContext, paramters);
        }

        /// <summary>
        /// Navigates to export crew list to fidelio dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToCommonExportCrewListToFidelioDialog(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonCrewListExportToFidelioView, context, parameters);
        }

        /// <summary>
        /// Navigates to common attach supplier navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="supplierIds">The supplier ids.</param>
        public void NavigateToCommonAttachSupplierNavigationView(INavigationContext context, object supplierIds)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonAttachSupplierNavigationView, context, supplierIds);
        }

        /// <summary>
        /// Navigates to management date guide lines view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateToPortAlertGuidelinesDialog(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PortAlertGuidelinesDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the pending certificate dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigatePendingCertificateDialogView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Common.Constants.ViewPendingCertificateDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to port alert logs dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters"></param>
        public void NavigateToPortAlertLogsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PortServicesLogDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the entity recovery lines view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateEntityRecoveryLinesView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityRecoveryLinesDialogView, navigationContext, parameter);
        }


        /// <summary>
        /// Navigates to dispute memo dialog.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        /// <param name="parameter">
        /// The parameter.
        /// </param>
        public void NavigateToAddDisputeMemoDialog(INavigationContext navigationContext, CrewNavParam parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddDisputeMemoDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates the vessel sentinel rating detail view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        public void NavigateVesselSentinelRatingDetailView(INavigationContext navigationContext, object navigationParameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselSentinelRatingDetailView, navigationContext, navigationParameter);
        }

        #region Common Module Navigation

        /// <summary>
        /// Navigates to selected view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="moduleName">Name of the module.</param>
        /// <param name="viewName">Name of the view.</param>
        /// <param name="isDialog">if set to <c>true</c> [is dialog].</param>
        /// <param name="isNavigateExisting">if set to <c>true</c> [is navigate existing].</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToSelectedView(INavigationContext navigationContext, string moduleName, string viewName, bool isDialog, bool isNavigateExisting, object parameter)
        {
            if (isDialog)
            {
                if (navigationContext == null)
                {
                    navigationContext = ServiceLocator.Current.GetInstance<INavigationService>().ActiveContext;
                }

                NavigationService.NavigateDialog(moduleName, viewName, navigationContext, parameter);
            }
            else if (isNavigateExisting)
            {
                NavigationService.NavigateExisting(moduleName, viewName, parameter, navigationContext);
            }
            else
            {
                NavigationService.NavigateNew(moduleName, viewName, parameter, navigationContext);
            }
        }

        #endregion

        /// <summary>
        /// Navigates to common search spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToCommonSearchSpareView(INavigationContext navigationContext, PMSNavigationParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonSearchSparePartView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigates to common search spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateToCommonPostponeToNextPortCallDialog(INavigationContext navigationContext, CommonViewNavigationParameter parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommonPostponeToNextPortCallView, navigationContext, parameter);
        }
    }
}
