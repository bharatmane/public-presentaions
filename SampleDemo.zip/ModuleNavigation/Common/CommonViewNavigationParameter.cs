﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Common;
using VShips.Contracts.Custom.PortPlanning;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// 
    /// </summary>
    public class CommonViewNavigationParameter
    {
        /// <summary>
        /// Gets or sets the defect list request.
        /// </summary>
        /// <value>
        /// The defect list request.
        /// </value>
        public DefectWorkOrderDetailRequest DefectListRequest { get; set; }

        /// <summary>
        /// Gets or sets the popup origin.
        /// </summary>
        /// <value>
        /// The popup origin.
        /// </value>
        public string PopupOrigin { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is final save.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is final save; otherwise, <c>false</c>.
        /// </value>
        public bool IsFinalSave { get; set; }

        /// <summary>
        /// Gets or sets the header detail.
        /// </summary>
        /// <value>
        /// The header detail.
        /// </value>
        public BaseViewModel HeaderDetail { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the component identifier.
        /// </summary>
        /// <value>
        /// The component identifier.
        /// </value>
        public string ComponentId { get; set; }

        /// <summary>
        /// Gets or sets the order delivery request.
        /// </summary>
        /// <value>
        /// The order delivery request.
        /// </value>
        public OrderDeliveryDetailRequest OrderDeliveryRequest { get; set; }

        /// <summary>
        /// Gets or sets the important note.
        /// </summary>
        /// <value>
        /// The important note.
        /// </value>
        public string ImportantNote { get; set; }
        /// <summary>
        /// Gets or sets the shared object.
        /// </summary>
        /// <value>
        /// The shared object.
        /// </value>
        public object SharedObject { get; set; }

        /// <summary>
        /// Gets or sets the selected vessel.
        /// </summary>
        /// <value>
        /// The selected vessel.
        /// </value>
        public UserMenuItem SelectedVessel { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets the position identifier.
        /// </summary>
        /// <value>
        /// The position identifier.
        /// </value>
        public string PosId { get; set; }

        /// <summary>
        /// Gets or sets the port identifier.
        /// </summary>
        /// <value>
        /// The port identifier.
        /// </value>
        public string PortId { get; set; }

        /// <summary>
        /// Gets or sets the port activity detail.
        /// </summary>
        /// <value>
        /// The port activity detail.
        /// </value>
        public PortPlanningHeaderDetail PortActivityDetail { get; set; }

        /// <summary>
        /// Gets or sets the existing ids.
        /// </summary>
        /// <value>
        /// The existing ids.
        /// </value>
        public List<string> ExistingIds { get; set; }

        /// <summary>
        /// Gets or sets the ppa identifier.
        /// </summary>
        /// <value>
        /// The ppa identifier.
        /// </value>
        public string PpaId { get; set; }
    }
}
