using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Accounts;
using VShips.Contracts.Custom.Document;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.Model;
using VShips.Framework.Common.ModuleNavigation.Crew;
using VShips.Framework.Common.ModuleNavigation.CrewRiskAssessment;
using VShips.Framework.Common.ModuleNavigation.Inspection;
using VShips.Framework.Common.ModuleNavigation.InventoryLandingForm;
using VShips.Framework.Common.ModuleNavigation.Invoicing;
using VShips.Framework.Common.ModuleNavigation.PlannedMaintenance;
using VShips.Framework.Common.ModuleNavigation.VoyageReporting;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// Navigation for the common module.
    /// </summary>
    public interface ICommonNavigation
    {
        /// <summary>
        /// Navigates to the upload cloud documents dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="files">The files.</param>
        /// <param name="matchedId">The matched identifier.</param>
        /// <param name="category">The category.</param>
        /// <param name="fileType">The file type.</param>
        /// <param name="crewId">The crew identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="cmpId">The CMP identifier.</param>
        /// <param name="coyId">The coy identifier.</param>
        void UploadCloudDocuments(INavigationContext context, List<string> files, string matchedId, DocumentCategory category, DocumentFileCategory? fileType = null, string crewId = null, string vesselId = null, string cmpId = null, string coyId = null);

        /// <summary>
        /// Edits a cloud document.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="cloudDocumentIdentifier">The cloud document identifier.</param>
        /// <param name="category">The category.</param>
        void EditCloudDocument(INavigationContext context, string cloudDocumentIdentifier, DocumentCategory category);

        /// <summary>
        /// Vessels the order create invoice manually.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void VesselOrderCreateInvoiceManually(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the vessel lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselLookupParameter">The vessel lookup parameter.</param>
        void NavigateVesselLookup(INavigationContext navigationContext, object vesselLookupParameter);

        /// <summary>
        /// Navigates the common vessel lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselLookupParameter">The vessel lookup parameter.</param>
        void NavigateCommonVesselLookup(INavigationContext navigationContext, object vesselLookupParameter);

        /// <summary>
        /// Navigates the inspection reference no lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateInspectionRefNoLookup(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates all posting account code lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedAccountCodeChange">The selected account code change.</param>
        void NavigateAllPostingAccountCodeLookup(INavigationContext navigationContext, Action<object> selectedAccountCodeChange);

        /// <summary>
        /// Navigates the voyage lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedVoyageChange">The selected voyage change.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="isFromSeaPassage">if set to <c>true</c> [is from sea passage].</param>
        /// <param name="recordContainingSearchText">if set to <c>true</c> [record containing search text].</param>
        /// <param name="isAdvancePortPlanning">if set to <c>true</c> [is advance port planning].</param>
        /// <param name="parentNaigationContext">The parent naigation context.</param>
        void NavigateVoyageLookup(INavigationContext navigationContext, Action<object> selectedVoyageChange, string vesselId, string parentId, bool isFromSeaPassage = false, bool recordContainingSearchText = false, bool isAdvancePortPlanning = false, INavigationContext parentNaigationContext = null);

        /// <summary>
        /// Navigates the chart detail account lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="request">The request.</param>
        /// <param name="listnerToken">The listner token.</param>
        /// <param name="selectedAccountChange">The selected account change.</param>
        void NavigateChartDetailAccountLookup(INavigationContext navigationContext, ChartAccountDetailRequest request, string listnerToken, Action<object> selectedAccountChange);

        /// <summary>
        /// Navigates the maker lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateMakerLookup(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the designer lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentCategoryId">The component category identifier.</param>
        void NavigateDesignerLookup(INavigationContext navigationContext, string componentCategoryId);

        /// <summary>
        /// Navigates the moc lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateMocLookup(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the jsa lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        void NavigateJsaLookup(INavigationContext navigationContext, string vesselId);

        /// <summary>
        /// Navigates the model lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="componentCategoryId">The component category identifier.</param>
        void NavigateModelLookup(INavigationContext navigationContext, string componentCategoryId);

        /// <summary>
        /// Navigates the oil grade type lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateOilGradeTypeLookup(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the order search.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateOrderSearch(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the invoice comparator.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateInvoiceComparator(InvoiceComparatorFilter parameter);

        /// <summary>
        /// Navigates the create memo.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="createMemoParameter">The create memo parameter.</param>
        void NavigateCreateMemo(INavigationContext navigationContext, CreateMemoParameter createMemoParameter);

        /// <summary>
        /// Navigates the account code lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountCodeLookupParamater">The account code lookup paramater.</param>
        void NavigateAccountCodeLookup(INavigationContext navigationContext, object accountCodeLookupParamater);

        /// <summary>
        /// Navigates the order accruals report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateOrderAccrualsReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the outstanding delivery information report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateOutstandingDeliveryInformationReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the outstanding order by account report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateOutstandingOrderByAccountReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the supplier purchase orders report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateSupplierPurchaseOrdersReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the comparison invoice report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateComparisonInvoiceReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the vessel order status report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateVesselOrderStatusReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the vessel stored orders report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateVesselStoredOrdersReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the vessel defect list report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateVesselDefectListReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the vessel Inspection List report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateVesselInspectionListReport(INavigationContext navigationContext, ParameterOverrides parameters);

        /// <summary>
        /// Invoices the main dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        /// <param name="allowToCreateOrReplyToMemo">if set to <c>true</c> [allow to create or reply to memo].</param>
        /// <param name="isForEntityAccountingCompany">if set to <c>true</c> [is for entity accounting company].</param>
        void InvoiceMainDialogView(INavigationContext navigationContext, string accountingCompanyId, string voucherNo, string invoiceHeaderId, bool allowToCreateOrReplyToMemo, bool isForEntityAccountingCompany);

        /// <summary>
        /// Entities the invoice main dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        void EntityInvoiceMainDialogView(INavigationContext navigationContext, string accountingCompanyId, string voucherNo, string invoiceHeaderId);

        /// <summary>
        /// Entities the ar invoice main dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="voucherNo">The voucher no.</param>
        /// <param name="invoiceHeaderId">The invoice header identifier.</param>
        void EntityARInvoiceMainDialogView(INavigationContext navigationContext, string accountingCompanyId, string voucherNo, string invoiceHeaderId);

        /// <summary>
        /// Entities the invoice create memo dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void EntityInvoiceCreateMemoDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the attach invoice document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="multiAttachmentPath">The attachment path.</param>
        void NavigateEmailDialog(INavigationContext navigationContext, string subject, List<string> multiAttachmentPath);

        /// <summary>
        /// Navigates the rank lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void NavigateRankLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged);

        /// <summary>
        /// Navigates the site lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void NavigateSiteLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged);

        /// <summary>
        /// Navigates the crew lookup view.
        /// </summary>
        /// <param name="naviagtionContext">The naviagtion context.</param>
        /// <param name="crewDetails">The crew details.</param>
        void NavigateCrewLookupView(INavigationContext naviagtionContext, object crewDetails);
        /// <summary>
        /// Navigates the on board crew lookup view.
        /// </summary>
        /// <param name="naviagtionContext">The naviagtion context.</param>
        /// <param name="crewRequest">The crew request.</param>
        /// <param name="parentID">The parent identifier.</param>
        void NavigateOnBoardCrewLookupView(INavigationContext naviagtionContext, object crewRequest, string parentID);

        /// <summary>
        /// Navigates the disputed invoice report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateDisputedInvoiceReport(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the create order memo view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="createMemoParameter">The create memo parameter.</param>
        void NavigateCreateOrderMemoView(INavigationContext navigationContext, CreateMemoParameter createMemoParameter);

        /// <summary>
        /// Navigates the system area component TreeView.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateSystemAreaComponentTreeView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add supporting document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddSupportingDocument(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the accounting company lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedAccountingCompanyChange">The selected accounting company change.</param>
        void NavigateAccountingCompanyLookup(INavigationContext navigationContext, Action<object> selectedAccountingCompanyChange);


        /// <summary>
        /// Navigates the category lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isActive">The is active.</param>
        /// <param name="level">The level.</param>
        /// <param name="selectedCategory">The selected category.</param>
        void NavigateCategoryLookupView(INavigationContext navigationContext, bool? isActive, int? level, Action<object> selectedCategory);

        /// <summary>
        /// Navigates the type lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isActive">The is active.</param>
        /// <param name="selectedType">Type of the selected.</param>
        void NavigateTypeLookupView(INavigationContext navigationContext, bool? isActive, Action<object> selectedType);

        /// <summary>
        /// Navigates the tom system area lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedSystemArea">The selected system area.</param>
        void NavigateTOMSystemAreaLookupView(INavigationContext navigationContext, Action<object> selectedSystemArea);

        /// <summary>
        /// Navigates the add attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        void NavigateAddAttachments(INavigationContext navigationContext, AttachmentParameters parameters, IEnumerable<string> fileNames, string parentId, string documentId);

        /// <summary>
        /// Adds the edit recharge lines dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="rechargeCompanyCode">The recharge company code.</param>
        /// <param name="rechargeCompanyType">Type of the recharge company.</param>
        /// <param name="allowRecharge">if set to <c>true</c> [allow recharge].</param>
        /// <param name="customerCompany">The customer company.</param>
        void AddEditRechargeLinesDialogView(INavigationContext navigationContext, string rechargeCompanyCode, string rechargeCompanyType, bool allowRecharge, string customerCompany);

        /// <summary>
        /// Navigates the company lookup view model.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateCompanyLookupView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates Company lookup Mapping ViewModel
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="parameter"></param>
        void NavigateCompanyChildMappingView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the hierarchy explorer.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateHierarchyExplorer(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the hierarchy system area.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateHierarchySystemArea(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the global search.
        /// </summary>
        /// <param name="moduleName">Name of the module.</param>
        /// <param name="viewName">Name of the view.</param>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="isDialog">if set to <c>true</c> [is dialog].</param>
        /// <param name="isNavigateExisting">if set to <c>true</c> [is navigate existing].</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateGlobalSearch(string moduleName, string viewName, INavigationContext navigationContext, bool isDialog, bool isNavigateExisting, string parameter);

        /// <summary>
        /// Navigates the bank detail view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="supplierId">The supplier identifier.</param>
        /// <param name="supplierName">Name of the supplier.</param>
        void NavigateBankDetailView(INavigationContext navigationContext, string supplierId, string supplierName);

        /// <summary>
        /// Navigates the user login.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        void NavigateUserLogin(INavigationContext navigationContext);

        /// <summary>
        /// Seas the routes weather detail navigation.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="seaRoutesWeather">The sea routes weather.</param>
        /// <param name="top">The top.</param>
        /// <param name="left">The left.</param>
        void SeaRoutesWeatherDetailNavigation(INavigationContext navigationContext, SeaRoutesWeatherFeatures seaRoutesWeather, double top, double left);

        /// <summary>
        /// Navigates the vessel service lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="selectedServiceChange">The selected service change.</param>
        void NavigateVesselServiceLookupView(INavigationContext navigationContext, string vesselId, Action<object> selectedServiceChange);

        /// <summary>
        /// Navigates the payroll client vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="clientId">The client identifier.</param>
        /// <param name="checkTimesheetApplicableFlag">if set to <c>true</c> [check timesheet applicable flag].</param>
        /// <param name="selectedVesselChange">The selected vessel change.</param>
        void NavigatePayrollClientVesselLookupView(INavigationContext navigationContext, string clientId, bool checkTimesheetApplicableFlag, Action<object> selectedVesselChange);

        /// <summary>
        /// Navigates the form template preview.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="formTemplateId">The form template identifier.</param>
        void NavigateFormTemplatePreview(INavigationContext navigationContext, string formTemplateId);

        /// <summary>
        /// Navigates the map spares dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="addedPartIds">The added part ids.</param>
        void NavigateMapSparesDialog(INavigationContext navigationContext, string vesselId, string parentId, string componentId, List<object> addedPartIds);

        /// <summary>
        /// Navigates the adjust inventory stock.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="selectedSpare">The selected spare.</param>
        void NavigateAdjustStock(INavigationContext navigationContext, string vesselId, string parentId, object selectedSpare);

        /// <summary>
        /// Navigates the add inventory location.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        void NavigateAddInventoryLocation(INavigationContext navigationContext, string vesselId, string parentId);

        /// <summary>
        /// Navigates to add edit staff.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="staffParameter">The staff parameter.</param>
        void NavigateToAddEditStaff(INavigationContext navigationContext, Dictionary<string, object> staffParameter);

        /// <summary>
        /// Auxiliaries the list lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="auxiliaryName">Name of the auxiliary.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="parentNavigationId">The parent navigation identifier.</param>
        void AuxiliaryListLookupView(INavigationContext navigationContext, Auxiliary auxiliaryName, string accountingCompanyId, string searchText, string parentNavigationId);

        /// <summary>
        /// Fixeds the asset project lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="searchText">The search text.</param>
        void FixedAssetProjectLookupView(INavigationContext navigationContext, string accountingCompanyId, string searchText);

        /// <summary>
        /// Crewings the user vessel lookup view navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void CrewingUserVesselLookupViewNavigate(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged);

        /// <summary>
        /// Generals the parameter value multi select dialog navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="rrpId">The RRP identifier.</param>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="mappedIds">The mapped ids.</param>
        void GeneralParameterValueMultiSelectDialogNavigate(INavigationContext navigationContext, string parameterName, string rrpId, string reportId, Action<object> selectedItemChanged, List<string> mappedIds);

        /// <summary>
        /// Navigates the link hazocc dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateLinkHazoccDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Reports the fleet tree dialog navigate.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="userMenuItemTypes">The user menu item types.</param>
        /// <param name="selectedItem">The selected item.</param>
        void ReportFleetTreeDialogNavigate(INavigationContext navigationContext, Action<object> selectedItemChanged, string userMenuItemTypes, object selectedItem);

        /// <summary>
        /// Navigates the usage history.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateUsageHistory(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the duplicate spare detail.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateDuplicateSpareDetail(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the add link.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="childItemId">The child item identifier.</param>
        /// <param name="selectedDocument">The selected document.</param>
        void NavigateAddLink(INavigationContext navigationContext, AttachmentParameters parameters, string parentId, string documentId, string childItemId, DocumentDetail selectedDocument);

        /// <summary>
        /// Navigates the haz occ lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="fromDate">From date.</param>
        /// <param name="reportId">The report identifier.</param>
        void NavigateHazOccLookup(INavigationContext navigationContext, string vesselId, DateTime fromDate, string reportId);

        /// <summary>
        /// Navigates to port call agents details.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToPortCallAgentsDetails(INavigationContext context, VoyageListParameter parameter);

        /// <summary>
        /// Navigates the HDM crew lookup view.
        /// </summary>
        /// <param name="naviagtionContext">The naviagtion context.</param>
        /// <param name="crewRequest">The crew request.</param>
        /// <param name="parentID">The parent identifier.</param>
        void NavigateHDMCrewLookupView(INavigationContext naviagtionContext, object crewRequest, string parentID);

        /// <summary>
        /// Navigates the search location dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateSearchLocationDialog(INavigationContext context, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to map associated jobs.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToMapAssociatedJobs(INavigationContext context, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the map risk assessment view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateMapRiskAssessmentView(INavigationContext context, object parameters);

        /// <summary>
        /// Navigations the add edit hazard.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigationAddEditHazard(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates to add furter control measure view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToAddFurterControlMeasureView(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates to mapped risk assessment.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToMappedRiskAssessment(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates the document history request.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="documentId">The document identifier.</param>
        void NavigateDocumentHistoryRequest(INavigationContext context, string documentId);

        /// <summary>
        /// Navigates to dynamic report listing view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToDynamicReportListingView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to dynamic report parameters view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToDynamicReportParametersView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates to maker details view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="makerId">The maker identifier.</param>
        void NavigateToMakerDetailsView(INavigationContext context, string makerId);

        /// <summary>
        /// Navigates to document preview view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="prameter">The prameter.</param>
        void NavigateToDocumentPreviewView(INavigationContext context, object prameter);

        /// <summary>
        /// Navigates to automatic scan pc view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="prameter">The prameter.</param>
        void NavigateToAutoScanPCView(INavigationContext context, object prameter);

        /// <summary>
        /// Navigates to export to PDF and excel view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="title">The title.</param>
        /// <param name="reportTypes">The repor types.</param>
        /// <param name="actionToBePerformed">The action to be performed.</param>
        void NavigateToExportToPdfAndExcelView(INavigationContext navigationContext, string title, List<ReportExportTypes> reportTypes, Action<ReportExportTypes> actionToBePerformed);

        /// <summary>
        /// Navigates to port services dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToPortServicesDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to acknowledge alert dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToAcknowledgeAlertDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to pending acknowledgements dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToPendingAcknowledgementsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to vessel lookup for insurance view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="CurrentSearhText">The current searh text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void NavigateToVesselLookupForInsuranceView(INavigationContext navigationContext, string CurrentSearhText, Action<object> selectedItemChanged);


        /// <summary>
        /// Navigates the report crew multi select dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewChanged">The selected crew changed.</param>
        /// <param name="selectedCrews">The selected crews.</param>
        /// <param name="reportId">The report identifier.</param>
        void NavigateReportCrewMultiSelectDialog(INavigationContext navigationContext, Action<object> selectedCrewChanged, object selectedCrews, string reportId);

        /// <summary>
        /// Navigates the report crew single select dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="selectedCrewChanged">The selected crew changed.</param>
        /// <param name="selectedCrew">The selected crew.</param>
        void NavigateReportCrewSingleSelectDialog(INavigationContext navigationContext, Action<object> selectedCrewChanged, object selectedCrew);

        /// <summary>
        /// Navigates to order details report.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="orderNumber">The order number.</param>
        void NavigateToOrderDetailsReport(INavigationContext navigationContext, string accountingCompanyId, string orderNumber);

        /// <summary>
        /// Navigates the view attachments dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateViewAttachmentsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the common attachments dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateCommonAttachmentsDialog(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates the link jsa dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateLinkJSADialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the link vessel defects dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateLinkVesselDefectsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the link vessel requisition dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateLinkVesselRequisitionDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the link work orders dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateLinkWorkOrdersDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the link generic spares dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateLinkGenericSparesDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the map generic ranks dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateMapGenericRanksDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to payroll vessel lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void NavigateToPayrollVesselLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged);

        #region Inspection Maintainer

        /// <summary>
        /// Navigates map the questions view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateMapQuestionsView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the questions library view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateQuestionsLibraryView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the add edit question view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddEditQuestionView(INavigationContext context, object parameter);

        /// <summary>
        /// Navigates the image viewer.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateImageViewer(INavigationContext context, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the add edit user defined List view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAddEditUserDefinedListView(INavigationContext context, object parameter);

        #endregion

        /// <summary>
        /// Navigates to allocate spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToAllocateSpareView(INavigationContext navigationContext, PMSNavigationParameter parameters);

        /// <summary>
        /// Navigates to allocated spare detail view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToAllocatedSpareDetailView(INavigationContext navigationContext, PMSNavigationParameter parameters);

        /// <summary>
        /// Navigates to entity order search dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateToEntityOrderSearchDialogView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates to link spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToLinkSpareView(INavigationContext navigationContext, PMSNavigationParameter parameters);

        /// <summary>
        /// Navigates to defect work orders view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToDefectWorkOrdersView(INavigationContext navigationContext, CommonViewNavigationParameter parameters);

        /// <summary>
        /// Navigates to order deliveries view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToOrderDeliveriesView(INavigationContext navigationContext, CommonViewNavigationParameter parameters);

        /// <summary>
        /// Navigates the create entity memo.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="createMemoParameter">The create memo parameter.</param>
        void NavigateCreateEntityMemo(INavigationContext navigationContext, CreateEntityMemoNavigationParameter createMemoParameter);

        /// <summary>
        /// Navigates the common link spare.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="componentId">The component identifier.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="addedPartIds">The added part ids.</param>
        /// <param name="isLinkStore">if set to <c>true</c> [is link store].</param>
        /// <param name="isMapSpare">if set to <c>true</c> [is map spare].</param>
        void NavigateCommonLinkSpare(INavigationContext navigationContext, string vesselId, string componentId, string parentId, List<string> addedPartIds, bool isLinkStore, bool isMapSpare = false);

        /// <summary>
        /// Navigates to defect required spares view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToDefectRequiredSparesView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the vessel inspection never done view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateVesselInspectionNeverDoneView(INavigationContext context, InspectionsStartParameters parameters);

        /// <summary>
        /// Navigates the add port call activity against inspection view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddPortCallActivityAgainstInspectionView(INavigationContext context, CommonViewNavigationParameter parameters);
        /// <summary>
        /// Navigates the map spares dailogue.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateMapSparesDailogue(INavigationContext navigationContext, object parameter);
        /// <summary>
        /// Navigates the link work order history navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateLinkWorkOrderHistoryNavigationView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the link landing port dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateLinkLandingPortDialog(INavigationContext navigationContext, LandingFormNavigationParameter parameter);

        /// <summary>
        /// Navigates the map component.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        /// <param name="parentId">The parent identifier.</param>
        /// <param name="componentIds">The component ids.</param>
        /// <param name="isCalendar">if set to <c>true</c> [is calendar].</param>
        /// <param name="isRunningHours">if set to <c>true</c> [is running hours].</param>
        /// <param name="isRevolution">if set to <c>true</c> [is revolution].</param>
        /// <param name="isEvents">if set to <c>true</c> [is events].</param>
        /// <param name="isJobDetails">if set to <c>true</c> [is job details].</param>
        void NavigateMapComponent(INavigationContext navigationContext, string vesselId, string vesselName, string parentId, List<string> componentIds, bool isCalendar, bool isRunningHours, bool isRevolution, bool isEvents, bool isJobDetails = true);

        /// <summary>
        /// Navigats to vessel location map view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigatToVesselLocationMapView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates the entity order create invoice manually.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateEntityOrderCreateInvoiceManually(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the entity po edit recharge dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateEntityPOEditRechargeDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the entity po add edit recovery dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateEntityPOAddEditRecoveryDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the invoice comparator.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateEntityInvoiceComparator(object parameter);

        /// <summary>
        /// Navigates to add edit osa job approvers view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="osaParameter">The osa parameter.</param>
        void NavigateToAddEditOsaJobApproversView(INavigationContext context, OsaNavigationParameter osaParameter);

        /// <summary>
        /// Navigates to add to landing basket view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateToAddToLandingBasketView(INavigationContext context, LandingBasketNavigationParameter navigationParameter);

        /// <summary>
        /// Navigates to landing basket view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateToLandingBasketView(INavigationContext context, LandingBasketNavigationParameter navigationParameter);

        /// <summary>
        /// Navigates the entity service lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameterd">The parameterd.</param>
        void NavigateEntityServiceLookupView(INavigationContext navigationContext, Dictionary<string, object> parameterd);

        /// <summary>
        /// Navigates to add new landing basket item view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateToAddNewLandingBasketItemView(INavigationContext context, LandingBasketNavigationParameter navigationParameter);

        /// <summary>
        /// Navigates to reject landing view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateToRejectLandingView(INavigationContext context, LandingBasketNavigationParameter navigationParameter);

        /// <summary>
        /// Navigates to copy agent detail view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateToCopyAgentDetailView(INavigationContext context, CommonViewNavigationParameter navigationParameter);

        /// <summary>
        /// Commons the navigation map company ports.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="refreshParent">The refresh parent.</param>
        void CommonNavigationMapCompanyPorts(INavigationContext navigationContext, string companyId, Action refreshParent);

        /// <summary>
        /// Commons the navigate add attachments.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="fileNames">The file names.</param>
        /// <param name="CertificateIdentifier">The certificate identifier.</param>
        void CommonNavigateAddAttachments(INavigationContext navigationContext, string companyId, IEnumerable<string> fileNames, string CertificateIdentifier, Action refresh);

        /// <summary>
        /// Companies the maintainer navigate common add edit delivery address view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="deaId">The dea identifier.</param>
        /// <param name="cmpId">The CMP identifier.</param>
        /// <param name="refresh">The refresh.</param>
        void CompanyMaintainerNavigateCommonAddEditDeliveryAddressView(INavigationContext navigationContext, string deaId, string cmpId, Action refresh);

        /// <summary>
        /// Companies the maintainer navigate add edit contact view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="ccoId">The cco identifier.</param>
        /// <param name="cmpId">The CMP identifier.</param>
        /// <param name="refresh">The refresh.</param>
        void CompanyMaintainerNavigateAddEditContactView(INavigationContext navigationContext, string ccoId, string cmpId, Action refresh);

        /// <summary>
        /// Companies the maintainer navigate associate supplier view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void CompanyMaintainerNavigateAssociateSupplierView(INavigationContext navigationContext, ParameterOverrides parameters);

        /// <summary>
        /// Companies the maintainer navigate service view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        void CompanyMaintainerNavigateServiceView(INavigationContext navigationContext, ParameterOverrides parameters);

        /// <summary>
        /// Companies the maintainer navigate currency view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        void CompanyMaintainerNavigateCurrencyView(INavigationContext navigationContext, ParameterOverrides parameters);

        /// <summary>
        /// Companies the maintainer navigate contract view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        void CompanyMaintainerNavigateContractView(INavigationContext navigationContext, ParameterOverrides parameters);

        /// <summary>
        /// Companies the maintainer navigate commodity view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">parameters for the constructor</param>
        void CompanyMaintainerNavigateCommodityView(INavigationContext navigationContext, ParameterOverrides parameters);

        /// <summary>
        /// Navigates to add edit manage discounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="discountDetail">The discount detail.</param>
        /// <param name="onSave">The on save.</param>
        /// <param name="fromAdd">if set to <c>true</c> [from add].</param>
        void NavigateToAddEditManageDiscountsDialogView(INavigationContext navigationContext, object discountDetail, Action<object, object> onSave, bool fromAdd);

        /// <summary>
        /// Navigates to view manage discounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToViewManageDiscountsDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to manage discounts dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="onSave">The on save.</param>
        void NavigateToManageDiscountsDialogView(INavigationContext navigationContext, string companyId, Action onSave);

        /// <summary>
        /// Companies the maintainer navigate add edit bank details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void CompanyMaintainerNavigateAddEditBankDetailsView(INavigationContext navigationContext, object parameter, Action Refresh);

        /// <summary>
        /// Companies the maintainer navigate bank details iban view.
        /// </summary>
        /// <param name="navigation">The navigation.</param>
        /// <param name="Iban">The iban.</param>
        /// <param name="SetBankDetails">The set bank details.</param>
        /// <param name="isNavigationFromAdd">if set to <c>true</c> [is navigation from add].</param>
        void CompanyMaintainerNavigateBankDetailsIbanView(INavigationContext navigation, string Iban, Action SetBankDetails, bool isNavigationFromAdd);

        /// <summary>
        /// Navigates to map ods gas landed items view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToMapOdsGasLandedItemsView(INavigationContext navigationContext, object parameter);
        /// <summary>
        /// Navigates to management date guide lines view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToManagementDateGuideLinesView(INavigationContext navigationContext);
        /// Companies the maintainer navigate add edit bank details view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="Refresh">The refresh.</param>
        void CompanyMaintainerNavigateViewBankDetailsView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to get working list type from user view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToGetWorkingListTypeFromUserView(INavigationContext context, WorkingListParameters parameter);
        /// <summary>
        /// Sends the back to vix dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void CancelServiceDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters, Action refreshServiceList);

        /// <summary>
        /// Closes the service dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void CloseServiceDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters, Action refreshServiceList);

        /// <summary>
        /// Navigates to upload guidance document view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToUploadGuidanceDocumentView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates the preview document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigatePreviewDocument(INavigationContext navigationContext, Dictionary<string, object> parameters);


        /// <summary>
        /// Navigates the add edit document.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddEditDocument(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the management company detail dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="managementId">The management identifier.</param>
        void NavigateManagementCompanyDetailDialogView(INavigationContext context, string managementId);

        /// <summary>
        /// Navigates the marine rank lookup view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        void NavigateMarineRankLookupView(INavigationContext navigationContext, string searchText, Action<object> selectedItemChanged);

        /// <summary>
        /// Navigates the add invoice order line tax delivery dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddInvoiceOrderLineTaxDeliveryDialogView(INavigationContext context, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to entity po order lookup dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="paramters">The parameter.</param>
        void NavigateToEntityPOOrderLookupDialogView(INavigationContext navigationContext, Dictionary<string, object> paramters);

        /// <summary>
        /// Navigates to export crew list to fidelio dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToCommonExportCrewListToFidelioDialog(INavigationContext context, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates to common attach supplier navigation view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="supplierIds">The supplier ids.</param>
        void NavigateToCommonAttachSupplierNavigationView(INavigationContext context, object supplierIds);

        /// <summary>
        /// Navigates to port alert guidelines dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateToPortAlertGuidelinesDialog(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the pending certificate dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigatePendingCertificateDialogView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Navigates to port alert logs dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToPortAlertLogsDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Navigates the entity recovery lines view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateEntityRecoveryLinesView(INavigationContext navigationContext, object parameter);
        /// <summary>
        /// Navigates to dispute memo dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToAddDisputeMemoDialog(INavigationContext navigationContext, CrewNavParam parameters);

        /// <summary>
        /// Navigates the vessel sentinel rating detail view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="navigationParameter">The navigation parameter.</param>
        void NavigateVesselSentinelRatingDetailView(INavigationContext navigationContext, object navigationParameter);

        #region Common Module Navigation

        /// <summary>
        /// Navigates to selected view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="moduleName">Name of the module.</param>
        /// <param name="viewName">Name of the view.</param>
        /// <param name="isDialog">if set to <c>true</c> [is dialog].</param>
        /// <param name="isNavigateExisting">if set to <c>true</c> [is navigate existing].</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToSelectedView(INavigationContext navigationContext, string moduleName, string viewName, bool isDialog, bool isNavigateExisting, object parameter);

        #endregion

        /// <summary>
        /// Navigates to common search spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToCommonSearchSpareView(INavigationContext navigationContext, PMSNavigationParameter parameter);


        /// <summary>
        /// Navigates to common search spare view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateToCommonPostponeToNextPortCallDialog(INavigationContext navigationContext, CommonViewNavigationParameter parameter);
    }
}