﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Enumerations.Common;
using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// Class to hold the parameters for attach ments
    /// </summary>
    public class AttachmentParameters : BaseViewModel
    {
        #region Func Properties

        /// <summary>
        /// The can add function
        /// </summary>
        private Func<object, bool> _canAddFunc;

        /// <summary>
        /// Gets or sets the can add function.
        /// </summary>
        /// <value>
        /// The can add function.
        /// </value>
        public Func<object, bool> CanAddFunc
        {
            get { return _canAddFunc; }
            set { Set(() => CanAddFunc, ref _canAddFunc, value); }
        }

        /// <summary>
        /// The can edit function
        /// </summary>
        private Func<object, bool> _canEditFunc;

        /// <summary>
        /// Gets or sets the can edit function.
        /// </summary>
        /// <value>
        /// The can edit function.
        /// </value>
        public Func<object, bool> CanEditFunc
        {
            get { return _canEditFunc; }
            set { Set(() => CanEditFunc, ref _canEditFunc, value); }
        }

        /// <summary>
        /// The can delete function
        /// </summary>
        private Func<object, bool> _canDeleteFunc;

        /// <summary>
        /// Gets or sets the can delete function.
        /// </summary>
        /// <value>
        /// The can delete function.
        /// </value>
        public Func<object, bool> CanDeleteFunc
        {
            get { return _canDeleteFunc; }
            set { Set(() => CanDeleteFunc, ref _canDeleteFunc, value); }
        }

        /// <summary>
        /// The can view function
        /// </summary>
        private Func<object, bool> _canViewFunc;

        /// <summary>
        /// Gets or sets the can view function.
        /// </summary>
        /// <value>
        /// The can view function.
        /// </value>
        public Func<object, bool> CanViewFunc
        {
            get { return _canViewFunc; }
            set { Set(() => CanViewFunc, ref _canViewFunc, value); }
        }

        #endregion

        #region Properties

        /// <summary>
        /// The maximum attachment size in kb
        /// </summary>
        private int? _maxAttachmentSizeInKb;

        /// <summary>
        /// Gets or sets the maximum attachment size in kb.
        /// </summary>
        /// <value>
        /// The maximum attachment size in kb.
        /// </value>
        public int? MaxAttachmentSizeInKb
        {
            get { return _maxAttachmentSizeInKb; }
            set { Set(() => MaxAttachmentSizeInKb, ref _maxAttachmentSizeInKb, value); }
        }


        /// <summary>
        /// The show applicable to office
        /// </summary>
        private bool _showApplicableToOffice;

        /// <summary>
        /// Gets or sets a value indicating whether [show applicable to office].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show applicable to office]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowApplicableToOffice
        {
            get { return _showApplicableToOffice; }
            set { Set(() => ShowApplicableToOffice, ref _showApplicableToOffice, value); }
        }

        /// <summary>
        /// The vessel identifier
        /// </summary>
        private string _vesselId;

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId
        {
            get { return _vesselId; }
            set { Set(() => VesselId, ref _vesselId, value); }
        }

        /// <summary>
        /// The source identifier
        /// </summary>
        private string _sourceId;

        /// <summary>
        /// Gets or sets the source identifier.
        /// </summary>
        /// <value>
        /// The source identifier.
        /// </value>
        public string SourceId
        {
            get { return _sourceId; }
            set { Set(() => SourceId, ref _sourceId, value); }
        }

        /// <summary>
        /// The is category input required
        /// </summary>
        private bool _isCategoryInputRequired = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is category input required.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is category input required; otherwise, <c>false</c>.
        /// </value>
        public bool IsCategoryInputRequired
        {
            get { return _isCategoryInputRequired; }
            set { Set(() => IsCategoryInputRequired, ref _isCategoryInputRequired, value); }
        }

        /// <summary>
        /// The document sub module
        /// </summary>
        private SubModule _documentSubModule;

        /// <summary>
        /// Gets or sets the document sub module.
        /// </summary>
        /// <value>
        /// The document sub module.
        /// </value>
        public SubModule DocumentSubModule
        {
            get { return _documentSubModule; }
            set { Set(() => DocumentSubModule, ref _documentSubModule, value); }
        }

        /// <summary>
        /// The search tag
        /// </summary>
        private DocumentTypeSearchTag? _searchTag;

        /// <summary>
        /// Gets or sets the search tag.
        /// </summary>
        /// <value>
        /// The search tag.
        /// </value>
        public DocumentTypeSearchTag? SearchTag
        {
            get { return _searchTag; }
            set { Set(() => SearchTag, ref _searchTag, value); }
        }

        /// <summary>
        /// The DCT identifier
        /// </summary>
        private string _dctId;

        /// <summary>
        /// Gets or sets the DCT identifier.
        /// </summary>
        /// <value>
        /// The DCT identifier.
        /// </value>
        public string DctId
        {
            get { return _dctId; }
            set { Set(() => DctId, ref _dctId, value); }
        }

        /// <summary>
        /// The exclude DCT identifier
        /// </summary>
        private List<string> _excludeDctId;

        /// <summary>
        /// Gets or sets the exclude DCT identifier.
        /// </summary>
        /// <value>
        /// The exclude DCT identifier.
        /// </value>
        public List<string> ExcludeDctId
        {
            get { return _excludeDctId; }
            set { Set(() => ExcludeDctId, ref _excludeDctId, value); }
        }

        /// <summary>
        /// The uploaded file count
        /// </summary>
        private int _uploadedFileCount;

        /// <summary>
        /// Gets or sets the uploaded file count.
        /// </summary>
        /// <value>
        /// The uploaded file count.
        /// </value>
        public int UploadedFileCount
        {
            get { return _uploadedFileCount; }
            set { Set(() => UploadedFileCount, ref _uploadedFileCount, value); }
        }

        /// <summary>
        /// The maximum upload file count
        /// </summary>
        private int _maxUploadFileCount;

        /// <summary>
        /// Gets or sets the maximum upload file count.
        /// </summary>
        /// <value>
        /// The maximum upload file count.
        /// </value>
        public int MaxUploadFileCount
        {
            get { return _maxUploadFileCount; }
            set { Set(() => MaxUploadFileCount, ref _maxUploadFileCount, value); }
        }
        
        /// <summary>
        /// The file filter
        /// </summary>
        private string _fileFilter;

        /// <summary>
        /// Gets or sets the file filter.
        /// </summary>
        /// <value>
        /// The file filter.
        /// </value>
        public string FileFilter
        {
            get { return _fileFilter; }
            set { Set(() => FileFilter, ref _fileFilter, value); }
        }

        /// <summary>
        /// The category
        /// </summary>
        private DocumentCategory _category;

        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        public DocumentCategory Category
        {
            get { return _category; }
            set { Set(() => Category, ref _category, value); }
        }

        /// <summary>
        /// The is final save
        /// </summary>
        private bool _isFinalSave;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is final save.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is final save; otherwise, <c>false</c>.
        /// </value>
        public bool IsFinalSave
        {
            get { return _isFinalSave; }
            set { Set(() => IsFinalSave, ref _isFinalSave, value); }
        }

        /// <summary>
        /// The transfer to office status
        /// </summary>
        private int? _transferToOfficeStatus;

        /// <summary>
        /// Gets or sets the transfer to office status.
        /// </summary>
        /// <value>
        /// The transfer to office status.
        /// </value>
        public int? TransferToOfficeStatus
        {
            get { return _transferToOfficeStatus; }
            set { Set(() => TransferToOfficeStatus, ref _transferToOfficeStatus, value); }
        }

        /// <summary>
        /// Show Success Message.
        /// </summary>
        private bool _showSuccessMessage = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance Shows Success Message.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance Shows Success Message; otherwise, <c>false</c>.
        /// </value>
        public bool ShowSuccessMessage
        {
            get { return _showSuccessMessage; }
            set { Set(() => ShowSuccessMessage, ref _showSuccessMessage, value); }
        }

        /// <summary>
        /// The is inline editing
        /// </summary>
        private bool _isInlineEditing = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is inline editing.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is inline editing; otherwise, <c>false</c>.
        /// </value>
        public bool IsInlineEditing
        {
            get { return _isInlineEditing; }
            set { Set(() => IsInlineEditing, ref _isInlineEditing, value); }
        }

        /// <summary>
        /// The is link button visible
        /// </summary>
        private bool _isLinkButtonVisible = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is link button visible.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is link button visible; otherwise, <c>false</c>.
        /// </value>
        public bool IsLinkButtonVisible
        {
            get { return _isLinkButtonVisible; }
            set { Set(() => IsLinkButtonVisible, ref _isLinkButtonVisible, value); }
        }

        /// <summary>
        /// The get thumbnail data.
        /// </summary>
        private bool _getThumbnailData = true;

        /// <summary>
        /// Gets or sets a value indicating whether [get thumbnail data].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [get thumbnail data]; otherwise, <c>false</c>.
        /// </value>
        public bool GetThumbnailData
        {
            get { return _getThumbnailData; }
            set { Set(() => GetThumbnailData, ref _getThumbnailData, value); }
        }

        #endregion

        #region Security Properties

        /// <summary>
        /// The module name
        /// </summary>
        private string _moduleName;

        /// <summary>
        /// Gets or sets the name of the module.
        /// </summary>
        /// <value>
        /// The name of the module.
        /// </value>
        public string ModuleName
        {
            get { return _moduleName; }
            set { Set(() => ModuleName, ref _moduleName, value); }
        }

        /// <summary>
        /// The add attachment security identifier
        /// </summary>
        private string _addAttachmentSecurityId;

        /// <summary>
        /// Gets or sets the add attachment security identifier.
        /// </summary>
        /// <value>
        /// The add attachment security identifier.
        /// </value>
        public string AddAttachmentSecurityId
        {
            get { return _addAttachmentSecurityId; }
            set { Set(() => AddAttachmentSecurityId, ref _addAttachmentSecurityId, value); }
        }

        /// <summary>
        /// The edit attachment security identifier
        /// </summary>
        private string _editAttachmentSecurityId;

        /// <summary>
        /// Gets or sets the edit attachment security identifier.
        /// </summary>
        /// <value>
        /// The edit attachment security identifier.
        /// </value>
        public string EditAttachmentSecurityId
        {
            get { return _editAttachmentSecurityId; }
            set { Set(() => EditAttachmentSecurityId, ref _editAttachmentSecurityId, value); }
        }

        /// <summary>
        /// The delete attachment security identifier
        /// </summary>
        private string _deleteAttachmentSecurityId;

        /// <summary>
        /// Gets or sets the delete attachment security identifier.
        /// </summary>
        /// <value>
        /// The delete attachment security identifier.
        /// </value>
        public string DeleteAttachmentSecurityId
        {
            get { return _deleteAttachmentSecurityId; }
            set { Set(() => DeleteAttachmentSecurityId, ref _deleteAttachmentSecurityId, value); }
        }

        /// <summary>
        /// The view attachment security identifier
        /// </summary>
        private string _viewAttachmentSecurityId;

        /// <summary>
        /// Gets or sets the view attachment security identifier.
        /// </summary>
        /// <value>
        /// The view attachment security identifier.
        /// </value>
        public string ViewAttachmentSecurityId
        {
            get { return _viewAttachmentSecurityId; }
            set { Set(() => ViewAttachmentSecurityId, ref _viewAttachmentSecurityId, value); }
        }

        /// <summary>
        /// The is audit log.
        /// </summary>
        private bool _isAuditLog;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is capturing audit log.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is capturing audit log; otherwise, <c>false</c>.
        /// </value>
        public bool IsAuditLog
        {
            get { return _isAuditLog; }
            set { Set(() => IsAuditLog, ref _isAuditLog, value); }
        }

        #endregion
    }
}