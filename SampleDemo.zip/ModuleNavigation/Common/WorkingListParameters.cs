﻿using System;
using VShips.DataServices.Shared.Enumerations.Crew;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// WorkingListParameters Class
    /// </summary>
    public class WorkingListParameters
    {
        /// <summary>
        /// Gets or sets the type of the on apply.
        /// </summary>
        /// <value>
        /// The type of the on apply.
        /// </value>
        public Action<CrewWorkingListType?> OnApplyType { get; set; }

        /// <summary>
        /// Gets or sets the default type selection on load.
        /// </summary>
        /// <value>
        /// The default type selection on load.
        /// </value>
        public CrewWorkingListType DefaultTypeSelectionOnLoad { get; set; }
    }
}
