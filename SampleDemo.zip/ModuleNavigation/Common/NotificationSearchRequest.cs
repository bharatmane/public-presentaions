﻿using System;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// Notificatin Search Request Class
    /// </summary>
    [Serializable]
    public class NotificationSearchRequest
    {
        /// <summary>
        /// Gets or sets the application identifier.
        /// </summary>
        /// <value>
        /// The application identifier.
        /// </value>
        public int ApplicationId { get; set; }

        /// <summary>
        /// Gets or sets the notification JWT token.
        /// </summary>
        /// <value>
        /// The notification JWT token.
        /// </value>
        public string NotificationJwtToken { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserId { get; set; }
    }
}
