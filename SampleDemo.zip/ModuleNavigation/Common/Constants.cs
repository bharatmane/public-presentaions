﻿#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// Names of accessible views and regions related to the common module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "Common";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "CommonGeometry";

        //Views

        /// <summary>
        /// The vessel inspection never done detail view
        /// </summary>
        public const string VesselInspectionNeverDoneDetailView = "VesselInspectionNeverDoneDetailView";
        /// <summary>
        /// The add port call activity against inspection view
        /// </summary>
        public const string AddPortCallActivityAgainstInspectionView = "AddPortCallActivityAgainstInspectionView";
        /// <summary>
        /// The auxiliary list lookup view dialog
        /// </summary>
        public const string AuxiliaryListLookupViewDialog = "AuxiliaryListLookupView";

        /// <summary>
        /// The fixed asset project lookup view
        /// </summary>
        public const string FixedAssetProjectLookupView = "FixedAssetProjectLookupView";

        /// <summary>
        /// The transfer files login view
        /// </summary>
        public const string TransferFilesLoginView = "TransferFilesLoginView";

        /// <summary>
        /// The destination path
        /// </summary>
        public const string DestinationPath = "DestinationPath";

        /// <summary>
        /// The source path
        /// </summary>
        public const string SourcePath = "SourcePath";

        /// <summary>Dialog used to lookup and find a port.</summary>
        public const string PortLookupDialog = "PortLookupDialog";

        /// <summary>
        /// The airport lookup dialog
        /// </summary>
        public const string AirportLookupDialog = "AirportLookupDialog";

        /// <summary>
        /// The vessel lookup dialog
        /// </summary>
        public const string VesselLookupDialog = "VesselLookupDialog";

        /// <summary>
        /// The account code lookup dialog
        /// </summary>
        public const string AccountCodeLookupDialog = "AccountCodeLookupDialog";

        /// <summary>
        /// The account code lookup dialog
        /// </summary>
        public const string VoyageLookupDialog = "VoyageLookupDialog";

        /// <summary>
        /// The company lookup dialog
        /// </summary>
        public const string CompanyLookupDialog = "CompanyLookupView";

        /// <summary>
        /// The company child mapping dialog
        /// </summary>
        public const string CompanyChildMappingViewDialog = "CompanyChildMappingView";

        /// <summary>
        /// The Company Finder lookup dialog
        /// </summary>
        public const string UserLookupDialog = "UserLookupDialog";

        /// <summary>
        /// The vessel order create invoice manually view
        /// </summary>
        public const string VesselOrderCreateInvoiceManuallyView = "VesselOrderCreateInvoiceManuallyView";

        /// <summary>
        /// The company general lookup dialog
        /// </summary>
        public const string CompanyGeneralLookupDialog = "CompanyGeneralLookupDialog";

        /// <summary>
        /// The account list lookup view dialog
        /// </summary>
        public const string ChartDetailAccountLookupView = "ChartDetailAccountLookupView";

        /// <summary>
        /// The user lookup view
        /// </summary>
        public const string UserLookupView = "UserLookupView";

        /// <summary>
        /// The accounting company lookup view
        /// </summary>
        public const string AccountingCompanyLookupView = "AccountingCompanyLookupView";
        /// <summary>
        /// The order search view
        /// </summary>
        public const string OrderSearchView = "OrderSearchView";

        /// <summary>
        /// The component lookup view
        /// </summary>
        public const string ComponentLookupView = "ComponentLookupView";

        /// <summary>
        /// The rank lookup view dialog
        /// </summary>
        public const string RankLookupViewDialog = "RankLookupView";

        /// <summary>
        /// Upload cloud documents.
        /// </summary>
        public const string UploadCloudDocuments = "UploadCloudDocuments";

        /// <summary>
        /// The invoice detail view
        /// </summary>
        public const string InvoiceMainView = "InvoiceMainDialogView";

        /// <summary>
        /// The entity invoice main dialog view
        /// </summary>
        public const string EntityInvoiceMainDialogView = "EntityInvoiceMainDialogView";

        /// <summary>
        /// The entity ar invoice main dialog view
        /// </summary>
        public const string EntityARInvoiceMainDialogView = "EntityARInvoiceMainDialogView";

        /// <summary>
        /// All vessel lookup view dialog
        /// </summary>
        public const string AllVesselLookupViewDialog = "AllVesselLookupView";

        /// <summary>
        /// The bank lookup view dialog
        /// </summary>
        public const string BankLookupViewDialog = "BankAccountLookupView";

        /// <summary>
        /// The voyage lookup view
        /// </summary>
        public const string VoyageLookupView = "VoyageLookupView";

        /// <summary>
        /// The create memorandum view
        /// </summary>
        public const string CreateMemoView = "CreateMemoView";

        /// <summary>
        /// The map spares dialog view
        /// </summary>
        public const string MapSparesDialogView = "MapSparesDialogView";

        // Constants for Dictionary Parameters

        /// <summary>
        /// The vessel identifier
        /// </summary>
        public const string VesselId = "VesselId";

        /// <summary>
        /// The order status name
        /// </summary>
        public const string OrderStatusName = "OrderStatusName";

        /// <summary>
        /// The account code
        /// </summary>
        public const string AccountCode = "AccountCode";

        /// <summary>
        /// The bank validation status
        /// </summary>
        public const string BankValidationStatus = "BankValidationStatus";

        /// <summary>
        /// The office identifier
        /// </summary>
        public const string OfficeId = "OfficeId";

        /// <summary>
        /// The component identifier
        /// </summary>
        public const string ComponentId = "ComponentId";

        /// <summary>
        /// The coy identifier
        /// </summary>
        public const string CoyId = "CoyId";

        /// <summary>
        /// The makers reference
        /// </summary>
        public const string MakersReference = "MakersReference";

        /// <summary>
        /// The is makers refence editable
        /// </summary>
        public const string IsMakersRefenceEditable = "IsMakersRefenceEditable";

        /// <summary>
        /// The port identifier
        /// </summary>
        public const string PortId = "PortId";

        /// <summary>
        /// The vessel management identifier
        /// </summary>
        public const string VesselManagementId = "VesselManagementId";

        /// <summary>
        /// The order preview
        /// </summary>
        public const string OrderPreview = "OrderPreview";

        /// <summary>
        /// The is change order status
        /// </summary>
        public const string IsChangeOrderStatus = "IsChangeOrderStatus";

        /// <summary>
        /// To order status
        /// </summary>
        public const string ToOrderStatus = "ToOrderStatus";

        /// <summary>
        /// The order number
        /// </summary>
        public const string OrderNumber = "OrderNumber";

        /// <summary>
        /// The selected supplier
        /// </summary>
        public const string SelectedSupplier = "SelectedSupplier";

        /// <summary>
        /// The deliver to company type
        /// </summary>
        public const string DeliverToCompanyType = "DeliverToCompanyType";

        /// <summary>
        /// The selected supplier
        /// </summary>
        public const string SelectedCompanyType = "SelectedCompanyType";

        /// <summary>
        /// The communication email source
        /// </summary>
        public const string CommunicationEmailSource = "CommunicationEmailSource";

        /// <summary>
        /// The is parent closed
        /// </summary>
        public const string IsParentClosed = "IsParentClosed";

        /// <summary>
        /// The preferred supplier
        /// </summary>
        public const string PreferredSupplier = "PreferredSupplier";

        /// <summary>
        /// The order stage
        /// </summary>
        public const string OrderStage = "OrderStage";

        /// <summary>
        /// The order identifier
        /// </summary>
        public const string OrderId = "OrderId";

        /// <summary>
        /// The freight detail identifier
        /// </summary>
        public const string FreightDetailId = "FreightDetailId";

        /// <summary>
        /// The freight header identifier
        /// </summary>
        public const string FreightHeaderId = "FreightHeaderId";

        /// <summary>
        /// The is edit
        /// </summary>
        public const string IsEdit = "IsEdit";

        /// <summary>
        /// The selected invoice detail
        /// </summary>
        public const string SelectedInvoiceDetail = "SelectedInvoiceDetail";

        /// <summary>
        /// The is authorised
        /// </summary>
        public const string IsAuthorised = "IsAuthorised";

        /// <summary>
        /// The is dispute resolved
        /// </summary>
        public const string IsDisputeResolved = "IsDisputeResolved";

        /// <summary>
        /// The vessel lookup view
        /// </summary>
        public const string VesselLookupView = "VesselLookupView";

        /// <summary>
        /// The common vessel lookup view
        /// </summary>
        public const string CommonVesselLookupView = "CommonVesselLookupView";

        /// <summary>
        /// The inspection reference no lookup view
        /// </summary>
        public const string InspectionRefNoLookupView = "InspectionRefNoLookupView";

        /// <summary>
        /// The site lookup view
        /// </summary>
        public const string SiteLookupView = "SiteLookupView";

        /// <summary>
        /// The hazOcc lookup view.
        /// </summary>
        public const string HazOccLookupView = "HazOccLookupView";

        /// <summary>
        /// The Select forms view
        /// </summary>
        public const string SelectFormsView = "SelectFormsView";

        /// <summary>
        /// The Edit form template view
        /// </summary>
        public const string EditFormTemplateView = "EditFormTemplateView";

        /// <summary>
        /// the select form allocation view
        /// </summary>
        public const string SelectFormAllocationView = "SelectFormAllocationView";

        /// <summary>
        /// The Edit form template view
        /// </summary>
        public const string EditFormView = "EditFormView";

        /// <summary>
        /// the Edit Form Template GridView Control View
        /// </summary>
        public const string EditFormTemplateGridViewControlView = "EditFormTemplateGridViewControlView";

        /// <summary>
        /// the Edit Form Template Dropdown Control View
        /// </summary>
        public const string EditFormTemplateDropdownControlView = "EditFormTemplateDropdownControlView";

        /// <summary>
        /// The Select Form Group view
        /// </summary>
        public const string SelectFormGroupView = "SelectFormGroupView";

        /// <summary>
        /// The is vessels currently in management
        /// </summary>
        public const string IsVesselsCurrentlyInManagement = "IsVesselsCurrentlyInManagement";

        /// <summary>
        /// The fetch only activated accounting companies
        /// </summary>
        public const string FetchOnlyActivatedAccountingCompanies = "FetchOnlyActivatedAccountingCompanies";

        /// <summary>
        /// The show purchasing date columns
        /// </summary>
        public const string ShowPurchasingDateColumns = "ShowPurchasingDateColumns";

        /// <summary>
        /// The maker lookup view
        /// </summary>
        public const string MakerLookupView = "MakerLookupView";

        /// <summary>
        /// The designer lookup view.
        /// </summary>
        public const string DesignerLookupView = "DesignerLookupView";

        /// <summary>
        /// The designer lookup token.
        /// </summary>
        public const string DesignerLookupToken = "DesignerLookupToken";

        /// <summary>
        /// The jsa lookup view
        /// </summary>
        public const string JSALookupView = "JSALookupView";

        /// <summary>
        /// The jsa lookup token
        /// </summary>
        public const string JSALookupToken = "JSALookupToken";

        /// <summary>
        /// The moc lookup token
        /// </summary>
        public const string MocLookupToken = "MocLookupToken";

        /// <summary>
        /// The moc lookup view
        /// </summary>
        public const string MocLookupView = "MocLookupView";

        /// <summary>
        /// The model lookup token.
        /// </summary>
        public const string ModelLookupToken = "ModelLookupToken";

        /// <summary>
        /// The on deleted catalog supplier mapped
        /// </summary>
        public const string OnDeletedCatalogSupplierMapped = "OnDeletedCatalogSupplierMapped";

        /// <summary>
        /// The model lookup view.
        /// </summary>
        public const string ModelLookupView = "ModelLookupView";

        /// <summary>
        /// The oil grade type lookup view.
        /// </summary>
        public const string OilGradeTypeLookupView = "OilGradeTypeLookupView";

        /// <summary>
        /// The oil grade type lookup token.
        /// </summary>
        public const string OilGradeTypeLookupToken = "OilGradeTypeLookupToken";

        /// <summary>
        /// The order status
        /// </summary>
        public const string OrderStatus = "OrderStatus";

        /// <summary>
        /// The selected suppliers
        /// </summary>
        public const string SelectedSuppliers = "SelectedSuppliers";

        /// <summary>
        /// The supplier order identifier
        /// </summary>
        public const string SupplierOrderId = "SupplierOrderId";

        /// <summary>
        /// The selected vessel change
        /// </summary>
        public const string SelectedVesselChange = "SelectedVesselChange";

        /// <summary>
        /// The selected voyage change
        /// </summary>
        public const string SelectedVoyageChange = "SelectedVoyageChange";
        /// <summary>
        /// The selected user change
        /// </summary>
        public const string SelectedUserChange = "SelectedUserChange";

        /// <summary>
        /// The selected account code change
        /// </summary>
        public const string SelectedAccountCodeChange = "SelectedAccountCodeChange";

        /// <summary>
        /// The selected service change
        /// </summary>
        public const string SelectedServiceChange = "selectedServiceChange";

        /// <summary>
        /// The selected accounting company change
        /// </summary>
        public const string SelectedAccountingCompanyChange = "SelectedAccountingCompanyChange";

        /// <summary>
        /// The create invoice memo dialog view
        /// </summary>
        public const string CreateInvoiceMemoDialogView = "CreateInvoiceMemoDialogView";

        /// <summary>
        /// The entity invoice create memo dialog view
        /// </summary>
        public const string EntityInvoiceCreateMemoDialogView = "EntityInvoiceCreateMemoDialogView";

        /// <summary>
        /// The action
        /// </summary>
        public const string Action = "Action";

        /// <summary>
        /// The has recovery lines
        /// </summary>
        public const string HasRecoveryLines = "HasRecoveryLines";

        /// <summary>
        /// The title
        /// </summary>
        public const string Title = "Title";


        /// <summary>
        /// The supplier identifier
        /// </summary>
        public const string SupplierId = "SupplierId";


        /// <summary>
        /// The warehouse identifier
        /// </summary>
        public const string WarehouseId = "WarehouseId";

        /// <summary>
        /// The create memo parameter
        /// </summary>
        public const string CreateMemoParameter = "CreateMemoParameter";

        /// <summary>
        /// The order currency
        /// </summary>
        public const string OrderCurrency = "OrderCurrency";


        /// <summary>
        /// The selected identifier
        /// </summary>
        public const string SelectedId = "SelectedId";

        /// <summary>
        /// The selected parameter name
        /// </summary>
        public const string SelectedParameterName = "SelectedParameterName";

        /// <summary>
        /// The report identifier
        /// </summary>
        public const string ReportId = "ReportId";

        /// <summary>
        /// The report name
        /// </summary>
        public const string ReportName = "ReportName";

        /// <summary>
        /// The selected fleet name
        /// </summary>
        public const string SelectedFleetName = "SelectedFleetName";

        /// <summary>
        /// The vessel name
        /// </summary>
        public const string VesselName = "VesselName";

        /// <summary>
        /// The invoice title
        /// </summary>
        public const string InvoiceTitle = "InvoiceTitle";

        /// <summary>
        /// The is entity
        /// </summary>
        public const string IsEntity = "IsEntity";

        /// <summary>
        /// The selected module name
        /// </summary>
        public const string SelectedModuleName = "SelectedModuleName";

        /// <summary>
        /// The invoice identifier
        /// </summary>
        public const string InvoiceId = "InvoiceId";

        /// <summary>
        /// The is order tracking
        /// </summary>
        public const string IsOrderTracking = "IsOrderTracking";

        /// <summary>
        /// The Entity outstanding delivery information report view
        /// </summary>
        public const string EntityOutstandingDeliveryInformationReportView = "EntityOutstandingDeliveryInformationReportView";

        /// <summary>
        /// The Entity supplier purchase orders report view
        /// </summary>
        public const string EntitySupplierPurchaseOrdersReportView = "EntitySupplierPurchaseOrdersReportView";

        /// <summary>
        /// The Entity orders status report view
        /// </summary>
        public const string EntityOrderStatusReportView = "EntityOrderStatusReportView";

        /// <summary>
        /// The Entity stored order report view
        /// </summary>
        public const string EntityStoredOrdersReportView = "EntityStoredOrdersReportView";

        /// <summary>
        /// The Entity outstanding order by account report view
        /// </summary>
        public const string EntityOutstandingOrderByAccountReportView = "EntityOutstandingOrderByAccountReportView";

        /// <summary>
        /// The entity order accruals report view
        /// </summary>
        public const string EntityOrderAccrualsReportView = "EntityOrderAccrualsReportView";

        /// <summary>
        /// The Entity disputed invoice report view
        /// </summary>
        public const string EntityDisputedInvoiceReportView = "EntityDisputedInvoiceReportView";

        /// <summary>
        /// The order accruals report view
        /// </summary>
        public const string OrderAccrualsReportView = "OrderAccrualsReportView";

        /// <summary>
        /// The outstanding delivery information report view
        /// </summary>
        public const string OutstandingDeliveryInformationReportView = "OutstandingDeliveryInformationReportView";

        /// <summary>
        /// The outstanding order by account report view
        /// </summary>
        public const string OutstandingOrderByAccountReportView = "OutstandingOrderByAccountReportView";

        /// <summary>
        /// The supplier purchase orders report view
        /// </summary>
        public const string SupplierPurchaseOrdersReportView = "SupplierPurchaseOrdersReportView";

        /// <summary>
        /// The vessel order status report view
        /// </summary>
        public const string VesselOrderStatusReportView = "VesselOrderStatusReportView";

        public const string VesselDefectListReportView = "VesselDefectListReportView";

        public const string VesselInspectionListReportView = "VesselInspectionListReportView";

        /// <summary>
        /// The vessel stored orders report view
        /// </summary>
        public const string VesselStoredOrdersReportView = "VesselStoredOrdersReportView";

        /// <summary>
        /// The comparison invoice report view
        /// </summary>
        public const string ComparisonInvoiceReportView = "ComparisonInvoiceReportView";

        /// <summary>
        /// The disputed invoice report view
        /// </summary>
        public const string DisputedInvoiceReportView = "DisputedInvoiceReportView";

        /// <summary>
        /// The common adjust stock view
        /// </summary>
        public const string CommonAdjustStockView = "CommonAdjustStockView";

        /// <summary>
        /// The view model name
        /// </summary>
        public const string ViewModelName = "ViewModelName";

        /// <summary>
        /// The role 
        /// </summary>
        public const string Role = "Role";

        /// <summary>
        /// The invoice details
        /// </summary>
        public const string InvoiceDetails = "Invoice Details";

        /// <summary>
        /// The accounting company identifier
        /// </summary>
        public const string AccountingCompanyId = "AccountingCompanyId";

        /// <summary>
        /// The voucher no
        /// </summary>
        public const string VoucherNo = "VoucherNo";

        /// <summary>
        /// The invoice header identifier
        /// </summary>
        public const string InvoiceHeaderId = "InvoiceHeaderId";

        /// <summary>
        /// The email subject
        /// </summary>
        public const string EmailSubject = "EmailSubject";

        /// <summary>
        /// The attachment path
        /// </summary>
        public const string AttachmentPath = "AttachmentPath";

        /// <summary>
        /// The email dialog view
        /// </summary>
        public const string EmailDialogView = "EmailDialogView";

        /// <summary>
        /// The order line selected
        /// </summary>
        public const string OrderLineSelected = "OrderLineSelected";

        /// <summary>
        /// The create order memo view
        /// </summary>
        public const string CreateOrderMemoView = "CreateOrderMemoView";

        /// <summary>
        /// The system area component TreeView.
        /// </summary>
        public const string SystemAreaComponentTreeView = "SystemAreaComponentTreeView";

        /// <summary>
        /// The search text
        /// </summary>
        public const string SearchText = "SearchText";

        /// <summary>
        /// The po supporting document navigation view
        /// </summary>
        public const string POSupportingDocNavigationView = "POSupportingDocNavigationView";

        /// <summary>
        /// The is release configuration
        /// </summary>
        public const string IsReleaseConfiguration = "IsReleaseConfiguration";

        /// <summary>
        /// The is vessel application
        /// </summary>
        public const string IsVesselApplication = "IsVesselApplication";

        /// <summary>
        /// The selected user identifier
        /// </summary>
        public const string SelectedUserId = "SelectedUserId";

        /// <summary>
        /// The multi vessel to show in case of multi vessels accounting company.
        /// </summary>
        public const string MultiVessel = "Multi vessel";

        /// <summary>
        /// The short code for multi management type
        /// </summary>
        public const string ShortCodeForMultiManagementType = "M";
        /// <summary>
        /// The vessel management type to check
        /// </summary>
        public const string VesselManagementTypeToCheck = "Crew";

        /// <summary>
        /// The default crew symbol
        /// </summary>
        public const string DefaultCrewSymbol = "C";

        /// <summary>
        /// The edit user
        /// </summary>
        public const string EditUser = "Edit User";

        /// <summary>
        /// The add user
        /// </summary>
        public const string AddUser = "Add User";

        /// <summary>
        /// The crew lookup view
        /// </summary>
        public const string CrewLookupView = "CrewLookupView";
        /// <summary>
        /// The on board crew lookup view
        /// </summary>
        public const string OnBoardCrewLookupView = "OnBoardCrewLookupView";

        /// <summary>
        /// The role identifier
        /// </summary>
        public const string RoleId = "RoleId";

        /// <summary>
        /// The role name
        /// </summary>
        public const string RoleName = "RoleName";

        /// <summary>
        /// The type identifier - type maintainer
        /// </summary>
        public const string TypeId = "TypeId";

        /// <summary>
        /// The inventories
        /// </summary>
        public const string Inventories = "Inventories";

        /// <summary>
        /// The category identifier
        /// </summary>
        public const string CategoryId = "CategoryId";

        /// <summary>
        /// The dea identifier
        /// </summary>
        public const string DeaId = "DeaId";

        /// <summary>
        /// The cco identifier
        /// </summary>
        public const string CcoId = "CcoId";

        /// <summary>
        /// The CMP identifier
        /// </summary>
        public const string CmpId = "CmpId";

        /// <summary>
        /// The tom category lookup view
        /// </summary>
        public const string TOMCategoryLookupView = "TOMCategoryLookupView";

        /// <summary>
        /// The tom category lookup view
        /// </summary>
        public const string TOMTypeLookupView = "TOMTypeLookupView";

        /// <summary>
        /// The tom system area lookup view
        /// </summary>
        public const string TOMSystemAreaLookupView = "TOMSystemAreaLookupView";

        /// <summary>
        /// The add attachments navigation view
        /// </summary>
        public const string AddAttachmentsNavigationView = "AddAttachmentsNavigationView";

        /// <summary>
        /// The client chart header
        /// </summary>
        public const string ClientChartHeader = "ClientChartHeader";

        /// <summary>
        /// The chart header identifier
        /// </summary>
        public const string ChartHeaderId = "ChartHeaderId";
        /// <summary>
        /// The service by component lookup view
        /// </summary>
        public const string VesselServiceLookupView = "VesselServiceLookupView";

        /// <summary>
        /// The payroll client vessel lookup view
        /// </summary>
        public const string PayrollClientVesselLookupView = "PayrollClientVesselLookupView";

        /// <summary>
        /// The client identifier
        /// </summary>
        public const string ClientId = "ClientId";

        /// <summary>
        /// The check timesheet applicable flag
        /// </summary>
        public const string CheckTimesheetApplicableFlag = "CheckTimesheetApplicableFlag";

        /// <summary>
        /// The vessel entity type
        /// </summary>
        public const string VesselEntityType = "VesselEntityType";

        /// <summary>
        /// The recharge company type
        /// </summary>
        public const string RechargeCompanyType = "RechargeCompanyType";

        /// <summary>
        /// The recharge company code
        /// </summary>
        public const string RechargeCompanyCode = "RechargeCompanyCode";

        /// <summary>
        /// The recovery lines
        /// </summary>
        public const string SelectedDetailLineId = "SelectedDetailLineId";

        /// <summary>
        /// The recovery lines
        /// </summary>
        public static string RecoveryLines = "RecoveryLines";

        /// <summary>
        /// The Selected Voucher Line
        /// </summary>
        public static string SelectedVoucherLine = "SelectedVoucherLine";

        /// <summary>
        /// The invoice currency identifier
        /// </summary>
        public static string InvoiceCurrencyId = "InvoiceCurrencyId";

        /// <summary>
        /// The deleted recovery lines identifier
        /// </summary>
        public static string DeletedRecoveryLinesId = "DeletedRecoveryLinesId";

        /// <summary>
        /// The add edit recharge lines dialog view
        /// </summary>
        public const string AddEditRechargeLinesDialogView = "AddEditRechargeLinesDialogView";

        /// <summary>
        /// The hierarchy explorer view
        /// </summary>
        public const string HierarchyExplorerView = "HierarchyExplorerView";

        /// <summary>
        /// The hierarchy system area view
        /// </summary>
        public const string HierarchySystemAreaView = "HierarchySystemAreaView";

        /// <summary>
        /// The allow to create or reply to memo
        /// </summary>
        public const string AllowToCreateOrReplyToMemo = "AllowToCreateOrReplyToMemo";

        /// <summary>
        /// The allow recharge
        /// </summary>
        public const string AllowRecharge = "AllowRecharge";

        /// <summary>
        /// The customer company
        /// </summary>
        public const string CustomerCompany = "CustomerCompany";

        /// <summary>
        /// The sea routes weather detail view
        /// </summary>
        public const string SeaRoutesWeatherDetailView = "SeaRoutesWeatherDetailView";

        /// <summary>
        /// The is for entity accounting company
        /// </summary>
        public const string IsForEntityAccountingCompany = "IsForEntityAccountingCompany";

        /// <summary>
        /// The bank detail view
        /// </summary>
        public const string BankDetailDialogView = "BankDetailDialogView";

        /// <summary>
        /// The form template preview view
        /// </summary>
        public const string FormTemplatePreviewView = "FormTemplatePreviewView";


        /// <summary>
        /// All posting account code lookup view
        /// </summary>
        public const string AllPostingAccountCodeLookupView = "AllPostingAccountCodeLookupView";

        /// <summary>
        /// The common add location view
        /// </summary>
        public const string CommonAddLocationView = "CommonAddLocationView";

        /// <summary>
        /// The crew user vessel lookup view
        /// </summary>
        public const string CrewUserVesselLookupView = "CrewUserVesselLookupView";

        /// <summary>
        /// The common add edit staff dialog view
        /// </summary>
        public const string CommonAddEditStaffDialogView = "CommonAddEditStaffDialogView";

        /// <summary>
        /// The general parameter value multi select dialog view
        /// </summary>
        public const string GeneralParameterValueMultiSelectDialogView = "GeneralParameterValueMultiSelectDialogView";

        /// <summary>
        /// The report fleet tree dialog view
        /// </summary>
        public const string ReportFleetTreeDialogView = "ReportFleetTreeDialogView";

        /// <summary>
        /// The link hazocc navigation view
        /// </summary>
        public const string LinkHazoccNavigationView = "LinkHazoccNavigationView";

        /// <summary>
        /// The common spares usage history view
        /// </summary>
        public const string CommonSparesUsageHistoryView = "CommonSparesUsageHistoryView";

        /// <summary>
        /// The supplier name
        /// </summary>
        public const string SupplierName = "SupplierName";

        /// <summary>
        /// The description
        /// </summary>
        public const string Description = "Description";

        /// <summary>
        /// The amount
        /// </summary>
        public const string Amount = "Amount";

        /// <summary>
        /// All vessels filter
        /// </summary>
        public const string AllVesselsFilter = "All Vessels";

        /// <summary>
        /// My vessels filter
        /// </summary>
        public const string MyVesselsFilter = "My Responsibilities";

        /// <summary>
        /// My vessels filter
        /// </summary>
        public const string MyFavouritesFilter = "Favourites";

        /// <summary>
        /// My offices filter
        /// </summary>
        public const string MyOfficesFilter = "Offices";

        /// <summary>
        /// All offices filter
        /// </summary>
        public const string AllOfficesFilter = "All Offices";

        /// <summary>
        /// Per Vessel filter
        /// </summary>
        public const string ByOfficeFilter = "Per Office";

        /// <summary>
        /// Per Region filter
        /// </summary>
        public const string ByRegionFilter = "Per Region";

        /// <summary>
        /// The is freight order
        /// </summary>
        public const string isFreightOrder = "isFreightOrder";

        /// <summary>
        /// The duplicate spare detail view
        /// </summary>
        public const string DuplicateSpareDetailView = "DuplicateSpareDetailView";

        /// <summary>
        /// The add link navigation view
        /// </summary>
        public const string AddLinkNavigationView = "AddLinkNavigationView";

        /// <summary>
        /// The port call agents details view
        /// </summary>
        public const string PortCallAgentsDetailsView = "PortCallAgentsDetailsView";

        /// <summary>
        /// The hazocc lookup token.
        /// </summary>
        public const string HazoccLookupToken = "HazoccLookupToken";

        /// <summary>
        /// The HDM crew lookup view.
        /// </summary>
        public const string HDMCrewLookupView = "HDMCrewLookupView";

        /// <summary>
        /// The folder path
        /// </summary>
        public const string FolderPath = "FolderPath";

        /// <summary>
        /// The purchase order type
        /// </summary>
        public const string PurchaseOrderType = "PurchaseOrderType";

        /// <summary>
        /// The cat identifier
        /// </summary>
        public const string CatId = "CatId";

        /// <summary>
        /// The search location dialog view
        /// </summary>
        public const string SearchLocationDialogView = "SearchLocationDialogView";

        /// <summary>
        /// The map associated job view.
        /// </summary>
        public const string MapAssociatedJobView = "MapAssociatedJobView";

        /// <summary>
        /// The map risk assessment view.
        /// </summary>
        public const string MapRiskAssessmentView = "MapRiskAssessmentView";

        /// <summary>
        /// The add edit hazard navigation view.
        /// </summary>
        public const string AddEditHazardNavigationView = "AddEditHazardNavigationView";

        /// <summary>
        /// The add further control measure view.
        /// </summary>
        public const string AddFurtherControlMeasureView = "AddFurtherControlMeasureView";

        /// <summary>
        /// The mapped risk assessment view.
        /// </summary>
        public const string MappedRiskAssessmentView = "MappedRiskAssessmentView";

        /// <summary>
        /// The document request history view
        /// </summary>
        public const string DocumentRequestHistoryView = "DocumentRequestHistoryView";

        /// <summary>
        /// The dynamic report listing view
        /// </summary>
        public const string DynamicReportListingView = "DynamicReportListingView";

        /// <summary>
        /// The dynamic report parameters view
        /// </summary>
        public const string DynamicReportParametersView = "DynamicReportParametersView";

        /// <summary>
        /// The maker details navigation view
        /// </summary>
        public const string MakerDetailsNavigationView = "MakerDetailsNavigationView";

        /// <summary>
        /// The fleet type
        /// </summary>
        public const string FleetType = "FleetType";

        /// <summary>
        /// The document preview view
        /// </summary>
        public const string DocumentPreviewView = "DocumentPreviewView";

        /// <summary>
        /// The mapped ids
        /// </summary>
        public const string MappedIds = "MappedIds";

        /// <summary>
        /// The result
        /// </summary>
        public const string Result = "Result";

        /// <summary>
        /// The is view
        /// </summary>
        public const string IsView = "IsView";

        /// <summary>
        /// The automatic scan pc view
        /// </summary>
        public const string AutoScanPCView = "AutoScanPCView";

        /// <summary>
        /// The map question view.
        /// </summary>
        public const string MapQuestionView = "MapQuestionView";

        /// <summary>
        /// The question library view.
        /// </summary>
        public const string QuestionLibraryView = "QuestionLibraryView";

        /// <summary>
        /// The add edit question view.
        /// </summary>
        public const string AddEditQuestionView = "AddEditQuestionView";

        /// <summary>
        /// The image viewer dialog view
        /// </summary>
        public const string ImageViewerDialogView = "ImageViewerDialogView";

        /// <summary>
        /// The selected fleet
        /// </summary>
        public const string SelectedFleet = "SelectedFleet";

        /// <summary>
        /// The required types
        /// </summary>
        public const string RequiredTypes = "RequiredTypes";

        /// <summary>
        /// The export to PDF and excel view
        /// </summary>
        public const string ExportToPdfAndExcelView = "ExportToPdfAndExcelView";

        /// <summary>
        /// The port services dialog view
        /// </summary>
        public const string PortServicesDialogView = "PortServicesDialogView";

        /// <summary>
        /// The acknowledge alert dialog view
        /// </summary>
        public const string AcknowledgeAlertDialogView = "AcknowledgeAlertDialogView";

        /// <summary>
        /// The pending acknowledgement dialog view
        /// </summary>
        public const string PendingAcknowledgementDialogView = "PendingAcknowledgementDialogView";

        /// <summary>
        /// The vessel lookup for insurance view
        /// </summary>
        public const string VesselLookupForInsuranceView = "VesselLookupForInsuranceView";

        /// <summary>
        /// The report crew multi select dialog view
        /// </summary>
        public const string ReportCrewMultiSelectDialogView = "ReportCrewMultiSelectDialogView";

        /// <summary>
        /// The report crew single select dialog view
        /// </summary>
        public const string ReportCrewSingleSelectDialogView = "ReportCrewSingleSelectDialogView";

        /// <summary>
        /// The selected crews
        /// </summary>
        public const string SelectedCrews = "SelectedCrews";

        /// <summary>
        /// The crew identifier
        /// </summary>
        public const string CrewId = "CrewId";

        /// <summary>
        /// The crew name
        /// </summary>
        public const string CrewName = "CrewName";

        /// <summary>
        /// The order details report view
        /// </summary>
        public const string OrderDetailsReportView = "OrderDetailsReportView";

        /// <summary>
        /// The view attachments dialog view
        /// </summary>
        public const string ViewAttachmentsDialogView = "ViewAttachmentsDialogView";

        /// <summary>
        /// The common attachments dialog view
        /// </summary>
        public const string CommonAttachmentsDialogView = "CommonAttachmentsDialogView";

        /// <summary>
        /// The payroll vessel lookup view
        /// </summary>
        public const string PayrollAllVesselLookupView = "PayrollAllVesselLookupView";

        /// <summary>
        /// The link jsa dialog view
        /// </summary>
        public const string LinkVesselJSADialogView = "LinkVesselJSADialogView";

        /// <summary>
        /// The link vessel defect view
        /// </summary>
        public const string LinkVesselDefectView = "LinkVesselDefectView";

        /// <summary>
        /// The link vessel requisition dialog view
        /// </summary>
        public const string LinkVesselRequisitionDialogView = "LinkVesselRequisitionDialogView";

        /// <summary>
        /// The link work orders dialog view
        /// </summary>
        public const string LinkWorkOrdersDialogView = "LinkWorkOrdersDialogView";

        /// <summary>
        /// The link generic spares dialog view
        /// </summary>
        public const string LinkGenericSparesDialogView = "LinkGenericSparesDialogView";

        /// <summary>
        /// The generic map ranks dialog view
        /// </summary>
        public const string GenericMapRanksDialogView = "GenericMapRanksDialogView";

        /// <summary>
        /// The order notes
        /// </summary>
        public const string OrderNotes = "OrderNotes";

        /// <summary>
        /// The selected item
        /// </summary>
        public const string SelectedItem = "SelectedItem";

        /// <summary>
        /// The block spare view.
        /// </summary>
        public const string BlockSpareView = "BlockSpareView";

        /// <summary>
        /// The view blocked spare detail.
        /// </summary>
        public const string ViewBlockedSpareDetail = "ViewBlockedSpareDetail";

        /// <summary>
        /// The entity order search navigation view
        /// </summary>
        public const string EntityOrderSearchNavigationView = "EntityOrderSearchNavigationView";

        /// <summary>
        /// The link spare navigation view.
        /// </summary>
        public const string LinkSpareNavigationView = "LinkSpareNavigationView";

        /// <summary>
        /// The defect work orders view.
        /// </summary>
        public const string DefectWorkOrdersView = "DefectWorkOrdersView";

        /// <summary>
        /// The order deliveries view.
        /// </summary>
        public const string OrderDeliveriesView = "OrderDeliveriesView";

        /// <summary>
        /// The create entity memo
        /// </summary>
        public const string CreateEntityMemoView = "CreateEntityMemoView";

        /// <summary>
        /// The common link spare view
        /// </summary>
        public const string CommonLinkSpareView = "CommonLinkSpareView";

        /// <summary>
        /// The defect required spares view
        /// </summary>
        public const string DefectRequiredSparesView = "DefectRequiredSparesView";

        /// <summary>
        /// The common map spare navigation view
        /// </summary>
        public const string CommonMapSpareNavigationView = "CommonMapSpareNavigationView";
        /// <summary>
        /// The common map component view
        /// </summary>
        public const string CommonMapComponentView = "CommonMapComponentView";

        /// <summary>
        /// The vessel location map view
        /// </summary>
        public const string VesselLocationMapView = "VesselLocationMapView";

        /// <summary>
        /// The entity order create invoice manually view
        /// </summary>
        public const string EntityOrderCreateInvoiceManuallyView = "EntityOrderCreateInvoiceManuallyView";

        /// <summary>
        /// The invoice
        /// </summary>
        public const string Invoice = "Invoice";
        /// <summary>
        /// The link work order history navigation view
        /// </summary>
        public const string LinkWorkOrderHistoryNavigationView = "LinkWorkOrderHistoryNavigationView";

        /// <summary>
        /// The common link landing port dialog view
        /// </summary>
        public const string CommonLinkLandingPortDialogView = "CommonLinkLandingPortDialogView";

        /// <summary>
        /// The add edit user defined List view.
        /// </summary>
        public const string AddEditUserDefinedListView = "AddEditUserDefinedListView";

        /// <summary>
        /// The add edit osa job approvers view
        /// </summary>
        public const string AddEditOsaJobApproversView = "AddEditOsaJobApproversView";

        /// <summary>
        /// The vessel weather alerts view
        /// </summary>
        public const string VesselWeatherAlertsView = "VesselWeatherAlertsView";

        /// <summary>
        /// The add to landing basket view.
        /// </summary>
        public const string AddToLandingBasketView = "AddToLandingBasketView";

        /// <summary>
        /// The entity invoice comparison report view
        /// </summary>
        public const string EntityInvoiceComparisonReportView = "EntityInvoiceComparisonReportView";

        /// <summary>
        /// The IHM extract report view
        /// </summary>
        public const string IHMExtractReportView = "IHMExtractReportView";

        /// <summary>
        /// The landing basket navigation view.
        /// </summary>
        public const string LandingBasketNavigationView = "LandingBasketDialogView";

        /// <summary>
        /// The entity service lookup view
        /// </summary>
        public const string EntityServiceLookupView = "EntityServiceLookupView";

        /// <summary>
        /// The add new landing basket item view.
        /// </summary>
        public const string AddNewLandingBasketItemView = "AddNewLandingBasketItemView";

        /// <summary>
        /// The reject landing view.
        /// </summary>
        public const string RejectLandingView = "RejectLandingView";

        /// <summary>
        /// The copy agent detail view.
        /// </summary>
        public const string CopyAgentDetailView = "CopyAgentDetailView";

        /// <summary>
        /// The map ports view
        /// </summary>
        public const string MapPortsView = "MapPortsView";

        /// <summary>
        /// The common documents add view
        /// </summary>
        public const string CommonDocumentsAddView = "CommonDocumentsAddView";

        /// <summary>
        /// The company identifier
        /// </summary>
        public const string CompanyId = "CompanyId";

        /// <summary>
        /// The files
        /// </summary>
        public const string Files = "Files";

        /// <summary>
        /// The company certificate identifier
        /// </summary>
        public const string CompanyCertificateId = "CceId";

        /// <summary>
        /// Add Attachments
        /// </summary>
        public const string CommonAddAttachmentsView = "CommonDocumentsAddView";

        /// <summary>
        /// The company maintainer common add edit delivery address view
        /// </summary>
        public const string CompanyMaintainerCommonAddEditDeliveryAddressView = "CompanyMaintainerCommonAddEditDeliveryAddressView";

        /// <summary>
        /// The company maintainer common add edit contacts view
        /// </summary>
        public const string CompanyMaintainerCommonAddEditContactsView = "CompanyMaintainerCommonAddEditContactsView";

        /// <summary>
        /// The company maintainer common associated new supplier view
        /// </summary>
        public const string CompanyMaintainerCommonAssociatedNewSupplierView = "CompanyMaintainerCommonAssociatedNewSupplierView";

        /// <summary>
        /// The company maintainer common add edit commodities view
        /// </summary>
        public const string CompanyMaintainerCommonAddEditCommoditiesView = "CompanyMaintainerCommonAddEditCommoditiesView";

        /// <summary>
        /// The company maintainer common add edit contracts view
        /// </summary>
        public const string CompanyMaintainerCommonAddEditContractsView = "CompanyMaintainerCommonAddEditContractsView";

        /// <summary>
        /// The company maintainer common add edit currencies view
        /// </summary>
        public const string CompanyMaintainerCommonAddEditCurrenciesView = "CompanyMaintainerCommonAddEditCurrenciesView";

        /// <summary>
        /// The company maintainer common add edit service view
        /// </summary>
        public const string CompanyMaintainerCommonAddEditServiceView = "CompanyMaintainerCommonAddEditServiceView";


        /// <summary>
        /// The add edit manage discounts dialog view
        /// </summary>
        public const string AddEditManageCommonDiscountsDialogView = "AddEditManageCommonDiscountsDialogView";

        /// <summary>
        /// The view manage discounts dialog view
        /// </summary>
        public const string ViewManageDiscountsDialogView = "ViewManageDiscountsDialogView";

        /// <summary>
        /// The manage common discounts dialog view
        /// </summary>
        public const string ManageCommonDiscountsDialogView = "ManageCommonDiscountsDialogView";

        /// <summary>
        /// The bank details common add edit navigation view
        /// </summary>
        public const string BankDetailsCommonAddEditNavigationView = "BankDetailsCommonAddEditNavigationView";

        /// <summary>
        /// The map ods gas landed items view
        /// </summary>
        public const string MapOdsGasLandedItemsView = "MapOdsGasLandedItemsView";

        /// <summary>
        /// The coy currency identifier
        /// </summary>
        public static string CoyCurrencyId = "CoyCurrencyId";

        /// <summary>
        /// The get working list type from user view
        /// </summary>
        public const string GetWorkingListTypeFromUserView = "GetWorkingListTypeFromUserView";
        /// <summary>
        /// The management date guidelines navigation view
        /// </summary>
        public const string ManagementDateGuidelinesNavigationView = "ManagementDateGuidelinesNavigationView";

        /// <summary>
        /// The cancel service dialog view
        /// </summary>
        public const string CancelServiceDialogView = "CancelServiceDialogView";

        /// <summary>
        /// The close service dialog view
        /// </summary>
        public const string CloseServiceDialogView = "CloseServiceDialogView";
        /// <summary>
        /// The refresh list
        /// </summary>
        public const string RefreshList = "RefreshList";

        /// <summary>
        /// The upload guidance document view.
        /// </summary>
        public const string UploadGuidanceDocumentView = "UploadGuidanceDocumentView";

        /// <summary>
        /// The document preview dialog view
        /// </summary>
        public const string CompanyMaintainerDocumentPreviewDialogView = "CompanyMaintainerDocumentPreviewDialogView";


        /// <summary>
        /// The company maintainer attachment add dialog view
        /// </summary>
        public const string CompanyMaintainerAttachmentAddDialogView = "CompanyMaintainerAttachmentAddDialogView";

        /// <summary>
        /// The management company detail dialog view
        /// </summary>
        public const string ManagementCompanyDetailDialogView = "ManagementCompanyDetailDialogView";

        /// <summary>
        /// The marine rank lookup view.
        /// </summary>
        public const string MarineRankLookupView = "MarineRankLookupView";

        /// <summary>
        /// The entity po create invoice dialog view
        /// </summary>
        public const string EntityPOCreateInvoiceDialogView = "EntityPOCreateInvoiceDialogView";

        /// <summary>
        /// The Entity PO Edit Recharge Dialog View
        /// </summary>
        public const string EntityPOEditRechargeDialogView = "EntityPOEditRechargeDialogView";

        public const string EntityPOAddEditRecoveryDialogView = "EntityPOAddEditRecoveryDialogView";

        /// <summary>
        /// The add invoice order line tax or delivery view
        /// </summary>
        public const string AddInvoiceOrderLineTaxOrDeliveryView = "AddInvoiceOrderLineTaxOrDeliveryView";

        /// <summary>
        /// The entity PO received not received report view
        /// </summary>
        public const string EntityPOReceivedNotReceivedReportView = "EntityPOReceivedNotReceivedReportView";

        /// <summary>
        /// The entity po order lookup view
        /// </summary>
        public const string EntityPOOrderLookupView = "EntityPOOrderLookupView";
        /// <summary>
        /// The common crew list export to fidelio view
        /// </summary>
        public const string CommonCrewListExportToFidelioView = "CommonCrewListExportToFidelioView";

        /// <summary>
        /// The common attach supplier navigation view
        /// </summary>
        public const string CommonAttachSupplierNavigationView = "CommonAttachSupplierNavigationView";

        /// <summary>
        /// The port alert guidelines dialog view
        /// </summary>
        public const string PortAlertGuidelinesDialogView = "PortAlertGuidelinesDialogView";

        /// <summary>
        /// The port services log dialog view
        /// </summary>
        public const string PortServicesLogDialogView = "PortServicesLogDialogView";

        /// <summary>
        /// The show new chat view
        /// </summary>
        public const string ShowNewChatView = "ShowNewChatView";

        /// <summary>
        /// The create chat channel view
        /// </summary>
        public const string CreateChatChannelView = "CreateChatChannelView";

        /// <summary>
        /// The is navigation from add
        /// </summary>
        public const string IsNavigationFromAdd = "isNavigationFromAdd";

        /// <summary>
        /// The iban
        /// </summary>
        public const string Iban = "Iban";

        /// <summary>
        /// The bank details i ban view
        /// </summary>
        public const string BankDetailsIBanView = "BankDetailsIBanView";

        /// <summary>
        /// The iban validation status valid
        /// </summary>
        public const string IbanValidationStatusValid = "VGRP000002";

        /// <summary>
        /// The iban validation status in valid
        /// </summary>
        public const string IbanValidationStatusInValid = "VGRP000003";

        /// <summary>
        /// The iban validation status pending
        /// </summary>
        public const string IbanValidationStatusPending = "VGRP000001";

        /// <summary>
        /// The yes
        /// </summary>
        public const string Yes = "Yes";

        /// <summary>
        /// The no
        /// </summary>
        public const string No = "No";

        /// <summary>
        /// The bankdet
        /// </summary>
        public const string Bankdet = "BANKDET";

        /// <summary>
        /// The view pending certificate dialog view
        /// </summary>
        public const string ViewPendingCertificateDialogView = "ViewPendingCertificateDialogView";

        /// <summary>
        /// The entity recovery lines dialog view
        /// </summary>
        public const string EntityRecoveryLinesDialogView = "EntityRecoveryLinesDialogView";

        /// <summary>
        /// The add dispute memo dialog view
        /// </summary>
        public const string AddDisputeMemoDialogView = "AddDisputeMemoDialogView";

        /// <summary>
        /// The vessel sentinel rating detail view.
        /// </summary>
        public const string VesselSentinelRatingDetailView = "VesselSentinelRatingDetailView";

        /// <summary>
        /// The common search spare part view
        /// </summary>
        public const string CommonSearchSparePartView = "CommonSearchSparePartView";

        /// <summary>
        /// The Odr Recd Not Inv And Open Pur Odr Dialog View
        /// </summary>
        public const string OdrRecdNotInvAndOpenPurOdrDialogView = "OdrRecdNotInvAndOpenPurOdrDialogView";

        /// <summary>
        /// The common postpone to next port call view
        /// </summary>
        public const string CommonPostponeToNextPortCallView = "CommonPostponeToNextPortCallView";
    }
}