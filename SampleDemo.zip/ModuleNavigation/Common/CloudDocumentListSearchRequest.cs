﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VShips.DataServices.Shared.Enumerations.Document;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    ///   <br />
    /// </summary>
    public class CloudDocumentListSearchRequest
    {
        /// <summary>Gets or sets the document ids.</summary>
        /// <value>The document ids.</value>
        public List<string> DocumentIds { get; set; }

        /// <summary>Gets or sets the matched ids.</summary>
        /// <value>The matched ids.</value>
        public List<string> MatchedIds { get; set; }

        /// <summary>Gets or sets the document categories.</summary>
        /// <value>The document categories.</value>
        public List<DocumentCategory> DocumentCategories { get; set; }

        /// <summary>Gets or sets a value indicating whether this instance is vessel view.</summary>
        /// <value>
        ///   <c>true</c> if this instance is vessel view; otherwise, <c>false</c>.</value>
        public bool IsVesselView { get; set; }
        /// <summary>Gets or sets a value indicating whether this instance is vessel module.</summary>
        /// <value>
        ///   <c>true</c> if this instance is vessel module; otherwise, <c>false</c>.</value>
        public bool IsVesselModule { get; set; }
    }
}
