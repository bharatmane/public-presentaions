﻿using VShips.DataServices.Shared.Enumerations.Common;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// Navigation parameter for create entity memo.
    /// </summary>
    public class CreateEntityMemoNavigationParameter
    {
        /// <summary>
        /// Gets or sets the accounting company identifier.
        /// </summary>
        /// <value>
        /// The accounting company identifier.
        /// </value>
        public string AccountingCompanyId { get; set; }

        /// <summary>
        /// Gets or sets the order no.
        /// </summary>
        /// <value>
        /// The order no.
        /// </value>
        public string OrderNo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is reply pending.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is reply pending; otherwise, <c>false</c>.
        /// </value>
        public bool IsReplyPending { get; set; }

        /// <summary>
        /// Gets or sets the replied to memo identifier.
        /// </summary>
        /// <value>
        /// The replied to memo identifier.
        /// </value>
        public string RepliedToMemoId { get; set; }

        /// <summary>
        /// Gets or sets the selected memo to.
        /// </summary>
        /// <value>
        /// The selected memo to.
        /// </value>
        public string SelectedMemoTo { get; set; }

        /// <summary>
        /// Gets or sets the selectedcategory.
        /// </summary>
        /// <value>
        /// The selectedcategory.
        /// </value>
        public string Selectedcategory { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the eos identifier.
        /// </summary>
        /// <value>
        /// The eos identifier.
        /// </value>
        public string EosId { get; set; }
    }
}
