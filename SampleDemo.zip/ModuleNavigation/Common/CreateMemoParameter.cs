﻿using System;
using VShips.DataServices.Shared.Enumerations.Purchasing;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// This class is use for parameter of create memo
    /// </summary>
    public class CreateMemoParameter : BaseViewModel
    {
         #region Properties               

        /// <summary>
        /// The accounting company identifier
        /// </summary>
        private string _accountingCompanyId;
        /// <summary>
        /// Gets the accounting company identifier.
        /// </summary>
        /// <value>
        /// The accounting company identifier.
        /// </value>
        public string AccountingCompanyId
        {
            get { return _accountingCompanyId; }
            set { Set(() => AccountingCompanyId, ref _accountingCompanyId, value); }
        }

        /// <summary>
        /// The order number
        /// </summary>
        private  string _orderNumber;
        /// <summary>
        /// Gets the order number.
        /// </summary>
        /// <value>
        /// The order number.
        /// </value>
        public string OrderNumber
        {
            get { return _orderNumber; }
            set { Set(() => OrderNumber, ref _orderNumber, value); }
        }

        /// <summary>
        /// The order stager
        /// </summary>
        private PurchaseOrderStage _orderStage;
        /// <summary>
        /// Gets the order stager.
        /// </summary>
        /// <value>
        /// The order stager.
        /// </value>
        public PurchaseOrderStage OrderStage
        {
            get { return _orderStage; }
            set { Set(() => OrderStage, ref _orderStage, value); }
        }

        /// <summary>
        /// The is replied
        /// </summary>
        private bool _isReplied;
        /// <summary>
        /// Gets a value indicating whether this instance is replied.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is replied; otherwise, <c>false</c>.
        /// </value>
        public bool IsReplied
        {
            get { return _isReplied; }
            set { Set(() => IsReplied, ref _isReplied, value); }
        }

        /// <summary>
        /// The recipient type
        /// </summary>
        private RecipientType? _recipientType;
        /// <summary>
        /// Gets the type of the recipient.
        /// </summary>
        /// <value>
        /// The type of the recipient.
        /// </value>
        public RecipientType? RecipientType
        {
            get { return _recipientType; }
            set { Set(() => RecipientType, ref _recipientType, value);}
        }

        /// <summary>
        /// The replied to memo identifier
        /// </summary>
        private string _repliedToMemoId;
        /// <summary>
        /// Gets the replied to memo identifier.
        /// </summary>
        /// <value>
        /// The replied to memo identifier.
        /// </value>
        public string RepliedToMemoId
        {
            get { return _repliedToMemoId; }
            set { Set(() => RepliedToMemoId, ref _repliedToMemoId, value); }
        }

        /// <summary>
        /// The parent action
        /// </summary>
        private Action _parentAction;
        /// <summary>
        /// Gets or sets the parent action.
        /// </summary>
        /// <value>
        /// The parent action.
        /// </value>
        public Action ParentAction
        {
            get { return _parentAction; }
            set { Set(() => ParentAction, ref _parentAction, value); }
        } 

        /// <summary>
        /// The on memo sent action
        /// </summary>
        private Action _onMemoSentAction;

        /// <summary>
        /// Gets or sets the on memo sent action.
        /// </summary>
        /// <value>
        /// The on memo sent action.
        /// </value>
        public Action OnMemoSentAction
        {
            get { return _onMemoSentAction; }
            set { Set(() => OnMemoSentAction, ref _onMemoSentAction, value); }
        }

        /// <summary>
        /// The supplier identifier
        /// </summary>
        private string _supplierId;

        /// <summary>
        /// Gets or sets the supplier identifier.
        /// </summary>
        /// <value>
        /// The supplier identifier.
        /// </value>
        public string SupplierId
        {
            get { return _supplierId; }
            set { Set(() => SupplierId, ref _supplierId, value); }
        }

        /// <summary>
        /// The is from office
        /// </summary>
        private bool _isFromOffice = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is from office.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is from office; otherwise, <c>false</c>.
        /// </value>
        public bool IsFromOffice
        {
            get { return _isFromOffice; }
            set { Set(() => IsFromOffice, ref _isFromOffice, value); }
        }
        
        #endregion
    }
}