﻿using System.Collections.Generic;

namespace VShips.Framework.Common.ModuleNavigation.Common
{
    /// <summary>
    /// 
    /// </summary>
    public class LandingBasketNavigationParameter
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the viv ids.
        /// </summary>
        /// <value>
        /// The viv ids.
        /// </value>
        public List<string> VivIds { get; set; }

        /// <summary>
        /// Gets or sets the serial number ids.
        /// </summary>
        /// <value>
        /// The serial number ids.
        /// </value>
        public List<string> SerialNumberIds { get; set; }

        /// <summary>
        /// Gets or sets the mla identifier UI source.
        /// </summary>
        /// <value>
        /// The mla identifier UI source.
        /// </value>
        public string MlaIdUISource { get; set; }

        /// <summary>
        /// Gets or sets the mla identifier source.
        /// </summary>
        /// <value>
        /// The mla identifier source.
        /// </value>
        public string MlaIdSource { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [create landing form flag].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [create landing form flag]; otherwise, <c>false</c>.
        /// </value>
        public bool CreateLandingFormFlag { get; set; }

        /// <summary>
        /// Gets or sets the reject landing items.
        /// </summary>
        /// <value>
        /// The reject landing items.
        /// </value>
        public object RejectLandingItems { get; set; }

        /// <summary>
        /// Gets or sets the added viv ids.
        /// </summary>
        /// <value>
        /// The added viv ids.
        /// </value>
        public List<string> AddedVivIds { get; set; }

        /// <summary>
        /// Gets or sets the added serial numbers.
        /// </summary>
        /// <value>
        /// The added serial numbers.
        /// </value>
        public List<string> AddedSerialNumbers { get; set; }

        /// <summary>
        /// Gets or sets the added damaged goods order lines.
        /// </summary>
        /// <value>
        /// The added damaged goods order lines.
        /// </value>
        public List<string> AddedDamagedGoodsOrderLines { get; set; }

        /// <summary>
        /// Gets or sets the added incorrect item order lines.
        /// </summary>
        /// <value>
        /// The added incorrect item order lines.
        /// </value>
        public List<string> AddedIncorrectItemOrderLines { get; set; }

        /// <summary>
        /// Gets or sets the added components.
        /// </summary>
        /// <value>
        /// The added components.
        /// </value>
        public List<string> AddedComponents { get; set; }
    }
}
