﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.AccountsReceivable
{
    /// <summary>
    /// Navigation service for the budget module.
    /// </summary>
    public interface IAccountsReceivableNavigation
    {
        #region Methods

        /// <summary>
        /// Creates the entity receivable accounts.
        /// </summary>
        void CreateEntityReceivableAccounts();

        /// <summary>
        /// Creates the vessel receivable accounts.
        /// </summary>
        /// <param name="accId">The acc identifier.</param>
        void CreateVesselReceivableAccounts(object accId);

        /// <summary>
        /// Finalises the receivable payment dailog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="functionalCurrency">The function currency.</param>
        /// <param name="salesLedgerCutoffDate">The sales ledger cutoff date.</param>
        /// <param name="isPaid">if set to <c>true</c> [is paid].</param>
        void FinaliseReceivablePaymentDialog(INavigationContext context, object parameter, string coyId, string functionalCurrency, DateTime? salesLedgerCutoffDate, bool isPaid);

        /// <summary>
        /// Finalises the receivable payment entity dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void FinaliseReceivablePaymentEntityDialog(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Navigates to the match entity AR Payments.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateMatchEntityARPayment(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Navigates the unallocate cash dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateUnallocateCashDialogView(INavigationContext context, Dictionary<string, object> parameter);

        #endregion
    }
}