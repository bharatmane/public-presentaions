﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.AccountsReceivable
{
    /// <summary>
    /// Default implementation of the <see cref="IAccountsReceivableNavigation"/> service.
    /// </summary>
    public class AccountsReceivableNavigation : BaseModuleNavigationService, IAccountsReceivableNavigation
    {
        #region Constructors

        /// <summary>
        /// The default contructor for the Acc Receivable.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public AccountsReceivableNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Creates the entity receivable accounts.
        /// </summary>
        public void CreateEntityReceivableAccounts()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.AccountsReceivableEntityNavigationView);
        }

        /// <summary>
        /// Creates the vessel receivable accounts.
        /// </summary>
        /// <param name="accId"></param>
        public void CreateVesselReceivableAccounts(object accId)
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.AccountsReceivableNavigationView, accId);
        }

        /// <summary>
        /// Finalises the receivable payment dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="functionalCurrency">The function currency.</param>
        /// <param name="salesLedgerCutoffDate">The sales ledger cutoff date.</param>
        /// <param name="isPaid">if set to <c>true</c> [is paid].</param>
        public void FinaliseReceivablePaymentDialog(INavigationContext context, object parameter, string coyId, string functionalCurrency, DateTime? salesLedgerCutoffDate, bool isPaid)
        {
            var parameters = new Dictionary<string, object>
            {          
                {"Invoices", parameter},   
                {"AccountingCompanyId", coyId}, 
                {"FunctionalCurrency", functionalCurrency},
                {"SalesLedgerCutoffDate",salesLedgerCutoffDate},
                {"IsPaid", isPaid}                
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FinaliseReceivablePaymentDialogView, context, parameters);
        }

        /// <summary>
        /// Finalises the receivable payment entity dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void FinaliseReceivablePaymentEntityDialog(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FinaliseReceivablePaymentEntityDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates to the match entity AR Payments.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateMatchEntityARPayment(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityMatchARPaymentDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates the unallocate cash dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateUnallocateCashDialogView(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityUnallocatedCashDialogView, context, parameter);
        }

        #endregion
    }
}