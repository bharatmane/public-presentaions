﻿
namespace VShips.Framework.Common.ModuleNavigation.AccountsReceivable
{
    /// <summary>
    /// Start parameters for Accounts Receivable module
    /// </summary>
    public class AccountsReceivableStartParameter
    {
        #region Properties
        /// <summary>
        /// The filter
        /// </summary>
        private AccountsReceivableFilters _filter;

        /// <summary>
        /// Gets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        public AccountsReceivableFilters Filter
        {
            get { return _filter; }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountsReceivableStartParameter"/> class.
        /// </summary>
        public AccountsReceivableStartParameter()
        {
            if (_filter == null)
            {
                _filter = new AccountsReceivableFilters();
            }
        }
        #endregion

    }
}
