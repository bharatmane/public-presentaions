﻿namespace VShips.Framework.Common.ModuleNavigation.AccountsReceivable
{
    /// <summary>
    /// Names of accessible views and regions related to the AccountsReceivable module.
    /// </summary>
    public static class Constants
    {
        /// <summary>The name of the module.</summary>
        public const string ModuleName = "AccountsReceivable";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "AccountsReceivableGeometry";

        /// <summary>
        /// The module title
        /// </summary>
        public const string ModuleTitle = "Accounts Receivable";        

        //Views

        /// <summary>
        /// The landing or start view of Accounts Receivable module
        /// </summary>
        public const string AccountsReceivableStartView = "AccountsReceivableStartView";

        /// <summary>
        /// The accounts receivable navigation view
        /// </summary>
        public const string AccountsReceivableNavigationView = "AccountsReceivableNavigationView";

        /// <summary>
        /// The accounts receivable entity navigation view
        /// </summary>
        public const string AccountsReceivableEntityNavigationView = "AccountsReceivableEntityNavigationView";

        /// <summary>
        /// The finalise receivable payment dialog view
        /// </summary>
        public const string FinaliseReceivablePaymentDialogView = "FinaliseReceivablePaymentDialogView";

        /// <summary>
        /// The finalise receivable payment entity dialog view
        /// </summary>
        public const string FinaliseReceivablePaymentEntityDialogView = "FinaliseReceivablePaymentEntityDialogView";

        /// <summary>
        /// The entity account receivable
        /// </summary>
        public const string EntityAccountReceivable = "Entity Account Receivable";

        /// <summary>
        /// The accounts receivable overview start view
        /// </summary>
        public const string AccountsReceivableOverviewStartView = "AccountsReceivableOverviewStartView";

        /// <summary>
        /// The entity match AR payment dialog view
        /// </summary>
        public const string EntityMatchARPaymentDialogView = "EntityMatchARPaymentDialogView";

        /// <summary>
        /// The entity unallocated cash dialog view
        /// </summary>
        public const string EntityUnallocatedCashDialogView = "EntityUnallocatedCashDialogView";

        /// <summary>
        /// The unmatch
        /// </summary>
        public const string Unmatch = "Unmatch";

        /// <summary>
        /// The post invoice geometry
        /// </summary>
        public const string PostInvoiceGeometry = "PostInvoiceGeometry";

        /// <summary>
        /// The match
        /// </summary>
        public const string Match = "Match";

        /// <summary>
        /// The finalise geometry
        /// </summary>
        public const string FinaliseGeometry = "FinaliseGeometry";
    }
}
