﻿using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.ModuleNavigation.AccountsReceivable
{
    /// <summary>
    /// Left side tree filter for accounts receivable
    /// </summary>
    public class AccountsReceivableFilters
    {
        #region Properties
        /// <summary>
        /// The search string
        /// </summary>
        private string _searchString;

        /// <summary>
        /// Gets or sets the search string.
        /// </summary>
        /// <value>
        /// The search string.
        /// </value>
        public string SearchString
        {
            get { return _searchString; }
            set
            {
                _searchString = value;
            }
        }

        /// <summary>
        /// Gets or sets the menu item.
        /// </summary>
        /// <value>
        /// The menu item.
        /// </value>
        public UserMenuItem MenuItem { get; set; }
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountsReceivableFilters"/> class.
        /// </summary>
        public AccountsReceivableFilters()
        {

        }
        #endregion
    }
}
