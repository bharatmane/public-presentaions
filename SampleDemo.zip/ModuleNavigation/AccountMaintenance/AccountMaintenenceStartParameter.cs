﻿namespace VShips.Framework.Common.ModuleNavigation.AccountMaintenance
{
    /// <summary>
    /// Start parameters for Accounting maintenance module
    /// </summary>
    public class AccountMaintenenceStartParameter
    {
        #region Properties
        
        /// <summary>
        /// The filter
        /// </summary>
        private AccountMaintenenceFilters _filter;

        /// <summary>
        /// Gets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        public AccountMaintenenceFilters Filter
        {
            get { return _filter; }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountMaintenenceStartParameter"/> class.
        /// </summary>
        public AccountMaintenenceStartParameter()
        {
            if (_filter == null)
            {
                _filter = new AccountMaintenenceFilters();
            }
        }

        #endregion

    }
}
