﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Contracts.Custom.Accounts;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.Framework.Common.Services;


namespace VShips.Framework.Common.ModuleNavigation.AccountMaintenance
{
    /// <summary>
    /// Default implementation of the <see cref="IAccountMaintenanceNavigation" /> service.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.BaseModuleNavigationService" />
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.AccountMaintenance.IAccountMaintenanceNavigation" />
    public class AccountMaintenanceNavigation : BaseModuleNavigationService, IAccountMaintenanceNavigation
    {
        /// <summary>
        /// The default contructor for the AccountMaintenance.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public AccountMaintenanceNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Adds the single tax code dialog navigation.
        /// </summary>
        /// <param name="NavigationContext">The navigation context.</param>
        /// <param name="isAddSingleTax">if set to <c>true</c> [is add single tax].</param>
        /// <param name="refresh">The refresh.</param>
        public void AddSingleTaxCodeDialogNavigation(INavigationContext NavigationContext , bool isAddSingleTax, Action refresh)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.IsAddSingleTax, isAddSingleTax },
                { Constants.RefreshList, refresh }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddSingleTaxCodeView, NavigationContext, parameters);
        }

        /// <summary>
        /// Maps the bank accounts dialog navigation.
        /// </summary>
        /// <param name="NavigationContext">The navigation context.</param>
        /// <param name="chhId">The CHH identifier.</param>
        /// <param name="listOfAccId"></param>
        public void MapBankAccountsDialogNavigation(INavigationContext NavigationContext,string chhId,List<string> listOfAccId)
        {
            Dictionary<string, Object> parameters = new Dictionary<string, object>()
            {
                {Constants.ChartHeaderId,chhId },
                {Constants.ListOfAccId,listOfAccId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MapBankAccountsView, NavigationContext, parameters);
        }

        /// <summary>
        /// Open view to create the entity account company.
        /// </summary>
        public void CreateEntityAccountCompany()
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.CreateEntityStartView);
        }

        /// <summary>
        /// Navigates the invoice accrual.
        /// </summary>
        public void NavigateInvoiceAccrual()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VesselInvoiceAccrualStartView);
        }

        /// <summary>
        /// Navigates the purchase order and invoice accrual.
        /// </summary>
        public void NavigatePurchaseOrderAndInvoiceAccrual()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PurchaseOrderAccrualsStartView);
        }

        /// <summary>
        /// Navigates the client report definition.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateClientReportDefinition(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ReportsDefinitionClientStartView, parameter);
        }

        /// <summary>
        /// Navigates the standard report definition.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateStandardReportDefinition(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ReportsDefinitionStandardStartView , parameter);
        }

        /// <summary>
        /// Open view to create the vessel account company.
        /// </summary>
        public void CreateVesselAccountCompany()
        {
            NavigationService.NavigateNew(Constants.ModuleName, Constants.CreateStartView);
        }

        /// <summary>
        /// Opes view to edits the vessel account company.
        /// </summary>
        public void EditVesselAccountCompany()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.AccountingCompanyStartView);
        }

        /// <summary>
        /// Opens the view to edit the entity account company.
        /// </summary>
        public void EditEntityAccountCompany()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.EntityCompanyAccountStartView);
        }

        /// <summary>
        /// Creates the Currency Rate Maintainer.
        /// </summary>
        public void CreateCurrencyMaintenance()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.CurrencyMain);
        }

        /// <summary>
        /// Opens the batch update.
        /// </summary>
        public void OpenBatchUpdate()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.BatchUpdateMain);
        }

        /// <summary>
        /// Opens the approve currency.
        /// </summary>
        public void OpenApproveCurrency()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.ApproveCurrencyMain);
        }

        /// <summary>
        /// Accounts the company navigate add attachment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="fileNames">The file names.</param>
        public void AccountCompanyNavigateAddAttachment(INavigationContext navigationContext, string coyId, IEnumerable<string> fileNames)
        {
            var parameters = new Dictionary<string, object>
            {
                { "CoyId", coyId }, { "Files", fileNames.ToList() }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccountCompanyDocumentAddView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the out standing invoice report dialog view.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateOutStandingInvoiceReportDialogView(INavigationContext parentContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.OutstandingInvoiceDialogView, parentContext, parameter);
        }

        /// <summary>
        /// Opens the Vessel Maintenance.
        /// </summary>
        public void ChartOfAccountsVesselMaintenance()
        {
            NavigationService.Navigate(Constants.ModuleName, Constants.ChartOfAccountsVesselStartView);
        }



        /// <summary>
        /// Opens the Vessel Operational Maintenance.
        /// </summary>
        public void CreateChartOfAccountsVesselOperationalMaintenance()
        {

            NavigationService.Navigate(Constants.ModuleName, Constants.OperationalChartStartItemView);
        }

        /// <summary>
        /// Clients the chart lookup dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="searchedText">The searched text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="accCompanyType">Type of the acc company.</param>
        /// <param name="chartStatus">The chart status.</param>
        public void ClientChartLookupDialogView(INavigationContext context, string searchedText, Action<object> selectedItemChanged, AccountUsedBy accCompanyType, ChartHeaderStatus chartStatus)
        {
            var parameters = new Dictionary<string, object>
            {
                { "SearchedText", searchedText },
                { "SelectedItemChanged", selectedItemChanged },
                { "AccCompanyType", accCompanyType },
                { "ChartStatus", chartStatus },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientChartDialogLookupView, context, parameters);
        }

        /// <summary>
        /// Opens the unassigned vessel dialog view.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="vesselManagementOfficeTypeId">The vessel management office type identifier.</param>
        public void OpenUnassignedVesselDialogView(INavigationContext parentContext, string searchText, string vesselManagementOfficeTypeId)
        {
            Dictionary<string, string> parameter = new Dictionary<string, string>
            {
                { "SearchedText", searchText },
                { "VesselManagementOfficeTypeId", vesselManagementOfficeTypeId }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BasicVesselLookUp, parentContext, parameter);
        }


        /// <summary>Adds the currency rate dialog navigation.</summary>
        /// <param name="NavigationContext">The navigation context.</param>
        /// <param name="Parameter">The parameter.</param>
        /// <param name="isEditApprovedCurrency">if set to <c>true</c> [is edit approved currency].</param>
        /// <param name="containsHistory"></param>
        public void AddCurrencyRateDialogNavigation(INavigationContext NavigationContext, object Parameter,bool isEditApprovedCurrency, bool containsHistory)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                { Constants.CurrencyPreview , Parameter },
                { Constants.IsEditApprovedCurrency, isEditApprovedCurrency },
                { Constants.ContainsHistory, containsHistory }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCurrencyRateDialogView, NavigationContext, parameter);
        }

        /// <summary>
        /// Adds the edit reversal reason.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="titleName">Name of the title.</param>
        /// <param name="selectedItem">The selected item.</param>
        public void AddEditReversalReason(INavigationContext navigationContext, string titleName, object selectedItem)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.TitleName, titleName },
                {Constants.SelectedCategory, selectedItem }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddReversalReasonView, navigationContext, parameter);
        }


        /// <summary>Adds the edit tax code.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taxId">The tax identifier.</param>
        public void AddEditTaxCode(INavigationContext navigationContext, string taxId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.TaxId, taxId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditTaxCodeView, navigationContext, parameter);
        }

        /// <summary>Adds the tax rate.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taxId">The tax identifier.</param>
        public void AddTaxRate(INavigationContext navigationContext, string taxId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.TaxId, taxId }
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddTaxRateView, navigationContext, parameter);
            
        }

		/// <summary>
		/// Navigates the add edit fin position map account dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameter">The parameter.</param>
		public void NavigateAddEditFinPosMapAccountDialogView(INavigationContext navigationContext, object parameter)
		{
			NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditFinPosMapAccountDialogView, navigationContext, parameter);
		}

		/// <summary>
		/// Requests the posting summary dialog.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="selectedChart">The selected chart.</param>
		/// <param name="vesselEntityType">Type of the vessel entity.</param>
		public void RequestPostingSummaryDialog(INavigationContext context, object selectedChart, AccountUsedBy vesselEntityType)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {"VesselEntityType", vesselEntityType },
                {"SelectedChart", selectedChart }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RequestPostingSummaryDialogView, context, parameter);
        }

        /// <summary>
        /// Postings the summary list dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedChart">The selected chart.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        public void PostingSummaryListDialogView(INavigationContext context, object selectedChart,AccountUsedBy vesselEntityType)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {"VesselEntityType", vesselEntityType },
                {"SelectedChart", selectedChart }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PostingSummaryListDialogView, context, parameter);
        }

        /// <summary>
        /// Accounts the library ListView.
        /// </summary>
        /// <param name="context">The context.</param>
        public void AccountLibraryListView(INavigationContext context)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.AccountLibraryListView, context);
        }

        /// <summary>
        /// Adds the chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeader">The chart header.</param>
        /// <param name="ClearSearch">The clear search.</param>
        public void AddEditChartOfAccountDialogView(INavigationContext context, object chartHeader, Action ClearSearch)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.chartHeader, chartHeader },
                {Constants.ClearSearch, ClearSearch }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditChartOfAccountDialogView, context, parameter);
        }

        /// <summary>
        /// Adds the Client chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void AddClientChartOfAccountDialogView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddClientChartOfAccountDialogView, context);
        }


        /// <summary>
        /// Adds to account library dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="Parameter">The parameter.</param>
        public void AddToAccountLibraryDialogView(INavigationContext context, object Parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddToAccountLibraryDialogView, context, Parameter);
        }
        /// <summary>
        /// Adds to account summary library dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="Parameter">The parameter.</param>
        public void AddToAccountLibrarySummaryDialogView(INavigationContext context, object Parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddToAccountLibrarySummaryDialogView, context, Parameter);
        }
        /// <summary>
        /// Rejects the account request dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="Parameter">The parameter.</param>
        public void RejectAccountRequestDialogView(INavigationContext context, object Parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RejectAccountRequestDialogView, context, Parameter);
        }

        /// <summary>
        /// Master Chart of Accounts Start view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void MasterChartOfAccountsStartView(INavigationContext context)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.MasterChartOfAccountsStartView, context);
        }

        /// <summary>
        /// Copies the chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedChart">The selected chart.</param>
        /// <param name="chartCoyType">Type of the chart coy.</param>
        public void CopyChartOfAccountDialogView(INavigationContext context, object selectedChart, string chartCoyType)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.SelectedChart, selectedChart },
                {Constants.ChartType,chartCoyType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyChartOfAccountDialogView, context, parameters);
        }

        /// <summary>
        /// Charts the mapping export dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartDetailListForExport">The chart detail list for export.</param>
        /// <param name="chartDescription">The chart description.</param>
        public void ChartMappingExportDialogView(INavigationContext context, object chartDetailListForExport, string chartDescription)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.ChartDetailListForExport, chartDetailListForExport },
                { Constants.ChartDescription, chartDescription }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ChartMappingExportDialogView, context, parameters);
        }

        /// <summary>
        /// Master Chart Add Summary Account dialog View.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="accountSelected">The account selected.</param>
        /// <param name="chartMasterHeaderId">The chart master identifier.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        public void MasterChartAddSummaryAccountDialogView(INavigationContext context,object parameter, AccountType? accountSelected, string chartMasterHeaderId,bool isInEditMode)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.AccountSelected,accountSelected },
                { Constants.SelectedMasterTreeItem,parameter},
                { Constants.ChartMasterHeaderId, chartMasterHeaderId},
                { Constants.IsInEditMode,isInEditMode}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MasterChartAddSummaryAccountDialogView, context, parameters);
        }

        /// <summary>
        /// Vessels the operational add posting node view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parent">The parent.</param>
        /// <param name="vesselChartType">Type of the vessel chart.</param>
        public void VesselOperationalAddPostingNodeView(INavigationContext context, object parent, VesselTypeAttribute? vesselChartType)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.ParentObject,parent },
                { Constants.VesselChartType, vesselChartType}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselOperationalAddPostingNodeView, context, parameters);
        }

        /// <summary>
        /// Vessel Operational AddSummary NodeView
        /// </summary>
        /// <param name="context">context</param>
        /// <param name="parent">The parent.</param>
        /// <param name="chartType">Type of the chart.</param>
        /// <param name="vesselChartType">Type of the vessel chart.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        /// <param name="parentAccDesc"></param>
        public void VesselOperationalAddSummaryNodeView(INavigationContext context, object parent, VesselEntityType? chartType, VesselTypeAttribute? vesselChartType, bool isEdit, string parentAccDesc)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.ParentObject,parent },
                { Constants.VesselEntityChartType,chartType},
                { Constants.VesselChartType, vesselChartType},
                { Constants.IsInEditMode, isEdit},
                { Constants.parentDescription, parentAccDesc}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselOperationalAddSummaryNodeView, context, parameters);
        }


        /// <summary>
        /// Vessels the operational edit posting node view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountCode">The account code.</param>
        /// <param name="parentChart">The parent chart.</param>
        /// <param name="vesselChartType">Type of the vessel chart.</param>
        /// <param name="activateAccount">if set to <c>true</c> [activate account].</param>
        public void VesselOperationalEditPostingNodeView(INavigationContext context, string accountCode, object parentChart, VesselTypeAttribute? vesselChartType, bool activateAccount)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.AccountCode, accountCode},
                {Constants.ParentObject, parentChart},
                { Constants.VesselChartType, vesselChartType},
                {Constants.ActivateAccount, activateAccount}
            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselOperationEditPostingNodeView, context, parameters);
        }

        /// <summary>
        /// Entities the account master start view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void EntityAccountMasterStartView(INavigationContext context)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityAccountMasterStartView, context);
        }
        
        /// <summary>
        /// Master Chart of Accounts Start view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void ClientChartOfAccountsStartView(INavigationContext context)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.ClientChartOfAccountsStartView, context);
        }

        /// <summary>
        /// Navigates the chart master lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="chartType">Type of the chart.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedChartMatserChange">The selected chart matser change.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        public void NavigateChartMasterLookup(INavigationContext navigationContext, VesselTypeAttribute? chartType, string searchText, Action<object> selectedChartMatserChange, string chartHeaderId)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>
            {
                {Constants.ChartType, chartType},
                {Constants.SearchText, searchText},
                {Constants.SelectedChartMatserChange, selectedChartMatserChange},
                {Constants.ChartHeaderId, chartHeaderId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ChartMasterLookupView, navigationContext, parameter);
        }

        /// <summary>
        /// Client Chart Add Summary Account dialog View.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isRootSelected">if set to <c>true</c> [is root selected].</param>
        public void ClientChartAddSummaryAccountDialogView(INavigationContext context, object parameter, bool isRootSelected)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.IsRootSelected,isRootSelected },
                { Constants.SelectedClientTreeItem,parameter}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientChartAddSummaryAccountDialogView, context, parameters);
        }

        /// <summary>
        /// Client Chart Add Posting Account dialog View.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        /// <param name="clientAccountNo">The client account no.</param>
        /// <param name="parentclinetAccountNumber">The parentclinet account number.</param>
        /// <param name="postingType">Type of the posting.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        /// <param name="refreshParent">The refresh parent.</param>
        public void ClientChartAddPostingAccountDialogView(INavigationContext context, string chartHeaderId, string clientAccountNo, string parentclinetAccountNumber, string postingType, string vesselEntityType, Action<ClientChartDetailMain> refreshParent)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.ChartHeaderId,chartHeaderId },
                { Constants.AccountCode,clientAccountNo},
                {Constants.ParentAccountCode ,parentclinetAccountNumber },
                {Constants.PostingType ,postingType },
                {Constants.VesselEntityType ,vesselEntityType },
                {Constants.Action ,refreshParent }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientChartAddPostingAccountDialogView, context, parameters);
        }

        /// <summary>
        /// Ends the agreement for accounting company.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyType">Type of the accounting company.</param>
        /// <param name="runningCostEndDate">The running cost end date.</param>
        /// <param name="maxManagementStartDate">The maximum management start date.</param>
        /// <param name="maxRCStartDate">The maximum rc start date.</param>
        public void EndAgreementForAccountingCompany(INavigationContext context, AccountUsedBy accountingCompanyType, DateTime? runningCostEndDate, DateTime? maxManagementStartDate, DateTime? maxRCStartDate)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.AccCoyType, accountingCompanyType },
                { Constants.RunningCostEndDate, runningCostEndDate },
                { Constants.MaxManagementStartDate, maxManagementStartDate },
                { Constants.MaxRCStartDate, maxRCStartDate }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccountCompanyAgreementEndView, context, parameters);
        }

        /// <summary>
        /// Entities the chart of accounts add posting dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parent">The parent.</param>
        public void EntityChartOfAccountsAddPostingDialogView(INavigationContext context, object parent)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityChartOfAccountsAddPostingDialogView, context, parent);
        }

        /// <summary>
        /// Adds the Master chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartMaster">The chart master.</param>
        public void AddMasterChartOfAccountDialogView(INavigationContext context, object chartMaster)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddMasterChartOfAccountDialogView, context, chartMaster);
        }

        /// <summary>
        /// Copys the Master chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ChhCoyType"></param>
        /// <param name="ChhDesc"></param>
        public void CopyMasterChartOfAccountDialogView(INavigationContext context, string ChhCoyType, string ChhDesc)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.ChhCoyType, ChhCoyType },
                { Constants.ChhDesc, ChhDesc }

            };

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyMasterChartOfAccountDialogView, context, parameters);
        }



        /// <summary>
        /// Add edits the client chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="clientChartHeader">The client chart header.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        public void AddEditClientChartOfAccountDialogView(INavigationContext context, object clientChartHeader, VesselEntityType? vesselEntityType)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.ClientChartHeader, clientChartHeader },
                { Constants.VesselEntityType, vesselEntityType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditClientChartOfAccountDialogView, context,parameters);
        }

        /// <summary>Exports the client chart of account dialog view.</summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        public void ExportClientChartOfAccountDialogView(INavigationContext context, VesselEntityType? vesselEntityType)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { Constants.VesselEntityType, vesselEntityType }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExportClientChartOfAccountDialogView, context, parameters);
        }
        

        /// <summary>
        /// Copies the client chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="clientChartHeader">The client chart header.</param>
        public void CopyClientChartOfAccountDialogView(INavigationContext context, object clientChartHeader)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
               { Constants.ClientChartHeader, clientChartHeader },

            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyClientChartOfAccountDialogView, context, parameters);
        }

        /// <summary>
        /// Entities the chart of accounts edit posting dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountCode">The account code.</param>
        /// <param name="parentChart">The parent chart.</param>
        /// <param name="activateAccount"></param>
        public void EntityChartOfAccountsEditPostingDialogView(INavigationContext context, string accountCode, object parentChart, bool activateAccount)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.AccountCode, accountCode},
                {Constants.ParentObject, parentChart},
                {Constants.ActivateAccount, activateAccount}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityChartOfAccountsEditPostingDialogView, context, parameters);
        }

        /// <summary>
        /// Searches the summary posting account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        public void SearchSummaryPostingAccountDialogView(INavigationContext context, string chartHeaderId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.ChartHeaderId,chartHeaderId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SearchSummaryPostingAccountDialogView, context, parameters);
            
        }

        /// <summary>
        /// Searches the client summary posting account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="clientChartHeaderId">The client chart header identifier.</param>
        public void SearchClientSummaryPostingAccountDialogView(INavigationContext context, string clientChartHeaderId)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.ClientChartHeaderId,clientChartHeaderId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SearchClientSummaryPostingAccountDialogView, context, parameters);

        }

        /// <summary>
        /// Accountings the company create memo view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="repliedToMemoId">The replied to memo identifier.</param>
        /// <param name="isEntity">if set to <c>true</c> [is entity].</param>
        /// <param name="entityOrVesselName">Name of the entity or vessel.</param>
        public void AccountingCompanyCreateMemoView(INavigationContext context, string accountingCompanyId, string repliedToMemoId, bool isEntity, string entityOrVesselName)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.AccountingCompanyId, accountingCompanyId},
                {Constants.RepliedToMemoId, repliedToMemoId},
                {Constants.IsEntity, isEntity},
                {Constants.EntityOrVesselName,entityOrVesselName }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccountingCompanyCreateMemoView, context, parameters);
        }

        /// <summary>
        /// Clients the chart add posting account selection dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="addSelectedAccount">The add selected account.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        /// <param name="accountType">Type of the account.</param>
        public void ClientChartAddPostingAccountSelectionDialogView(INavigationContext context, Action<List<AccountMasterResponse>> addSelectedAccount, VesselEntityType? vesselEntityType, AccountType? accountType)
        { 
            var parameter = new Dictionary<string, object>
            {
                {Constants.Action, addSelectedAccount },
                {Constants.VesselEntityType, vesselEntityType },
                {Constants.ChartType, accountType },
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientChartAddPostingAccountSelectionDialogView, context, parameter);
        }

        /// <summary>
        /// Adds the or edit vessel auxiliary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="CodeTypeId">The code type identifier.</param>
        /// <param name="AuxId">The AuxId.</param>
        /// <param name="RefreshAuxiliaryDetail">The refresh auxiliary detail.</param>
        public void AddOrEditVesselAuxiliaryDialogView(INavigationContext context, string CodeTypeId, object AuxId, Action<VesselGeneralAuxiliaryMain> RefreshAuxiliaryDetail)
        {
            var refreshAuxiliaryDetail = new Dictionary<string, object>
            {
                {Constants.AuxId, AuxId },
                {Constants.Action, RefreshAuxiliaryDetail },
                {Constants.CodeTypeId, CodeTypeId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddOrEditVesselAuxiliaryDialogView, context, refreshAuxiliaryDetail);
        }

        /// <summary>
        /// Adds the or edit entity auxiliary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="codeTypeId">The code type identifier.</param>
        /// <param name="auxId">The aux identifier.</param>
        /// <param name="refreshAuxiliaryDetail">The refresh auxiliary detail.</param>
        public void AddOrEditEntityAuxiliaryDialogView(INavigationContext context, string codeTypeId, string auxId, Action<EntityGeneralAuxiliaryMain> refreshAuxiliaryDetail)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.EntityCodeTypeId, codeTypeId},
                {Constants.EntityId, auxId},
                {Constants.Action, refreshAuxiliaryDetail }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddOrEditEntityAuxiliaryDialogView, context, parameters);
        }

        /// <summary>
        /// Adds the or edit fixed asset project dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="fapId">The fap identifier.</param>
        /// <param name="refreshFixedAssetProjects">The refresh fixed asset projects.</param>
        public void AddOrEditFixedAssetProjectDialogView(INavigationContext context, string fapId,  Action<FixedAssetProjectCodeResponse> refreshFixedAssetProjects)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.FapId, fapId},
                {Constants.Action, refreshFixedAssetProjects }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddOrEditFixedAssetProjectDialogView, context, parameters);
        }

        /// <summary>
        /// Adds the report client dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isViewOnly">if set to <c>true</c> [is view only].</param>
        /// <param name="chartCoyType">Type of the chart coy.</param>
        /// <param name="parentId">The parent identifier.</param>
        public void AddReportClientDialogView(INavigationContext context, object parameter, bool isViewOnly, object chartCoyType, string parentId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.ParentObject, parameter},
                {Constants.IsInViewMode, isViewOnly},
                {Constants.ChhCoyType,chartCoyType },
                { NavigationParameterConstant.ParentNavigationIdKey, parentId}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddReportClientDialogView, context, parameters);
        }


        /// <summary>
        /// Adds the account line dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void AddAccountLineDialogView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddAccountLineDialogView, context,parameter);
        }

        /// <summary>
        /// Revals the batch status dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="isVessel">if set to <c>true</c> [is vessel].</param>
        public void RevalBatchStatusDialog(INavigationContext context , bool isVessel)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RevalBatchStatusDialogView, context , isVessel);
        }

        /// <summary>
        /// Purchases the order accruals start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void PurchaseOrderAccrualsStartView(INavigationContext navigationContext)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PurchaseOrderAccrualsStartView, navigationContext);
        }

        /// <summary>
        /// Revals the coy summary dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void RevalCoySummaryDialog(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RevalCoySummaryDialogView, context, parameter);
        }

        /// <summary>
        /// Adds the customize or ad hoc summary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void AddCustomizeOrAdHocSummaryDialogView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddCustomizeOrAdHocSummaryDialogView, context, parameter);
        }

        /// <summary>
        /// Currencies the yearly report dialog view.
        /// </summary>
        /// <param name="context">The context.</param> 
        public void CurrencyYearlyReportDialogView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CurrencyYearlyReportView, context, null);
        }

        /// <summary>
        /// Copies the report definition dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="chartName">Name of the chart.</param>
        public void CopyReportDefinitionDialogView(INavigationContext context, object parameter,string chartName)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>()
            {
                {Constants.ParentObject, parameter},
                {Constants.ChartName, chartName},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CopyReportDefinitionDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the running cost recalculation dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateRunningCostRecalculationDialogView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RunningCostRecalculationDialogView, context);
        }

        /// <summary>
        /// Navigates the general ledger open transaction dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateGeneralLedgerOpenTransactionDialogView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GeneralLedgerOpenTransactionDialogView, context);
        }

        /// <summary>
        /// Navigates the auxiliary code analysis dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void NavigateAuxiliaryCodeAnalysisDialogView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AuxiliaryCodeAnalysisDialogView, context);
        }

        /// <summary>
        /// Navigates the expenditure statement dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateExpenditureStatementDialogView(INavigationContext context, object parameter = null)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExpenditureStatementDialogView, context, parameter);
        }

        /// <summary>
        /// Balanceses the selected company dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="cutOffDate">The cut off date.</param>
        public void BalancesSelectedCompanyDialogView(INavigationContext context, object entity,DateTime cutOffDate)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>()
            {
                {Constants.SeletedSettlementCompanyDetails, entity},
                {Constants.CutOffDate, cutOffDate},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BalancesSelectedCompanyDialogView, context, parameters);
        }

        /// <summary>
        /// Accounts the receivable payable dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="cutOffDate">The cut off date.</param>
        /// <param name="isAr"></param>
        /// <param name="coyName"></param>
        public void AccountReceivablePayableDialogView(INavigationContext context, object entity, DateTime? cutOffDate, bool isAr, string coyName)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>()
            {
                {Constants.SeletedSettlementCompanyDetails, entity},
                {Constants.CutOffDate, cutOffDate},
                {Constants.IsAR, isAr},
                {Constants.CoyName, coyName},
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccountReceivablePayableDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the edit assets dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateEditAssetsDialogView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditAssetsDialogView, context, parameters);
        }


        /// <summary>Navigates the print fixed assets dialog view.</summary>
        /// <param name="context">The context.</param>
        /// <param name="printSuccessfulAction">The print successful action.</param>
        public void NavigatePrintFixedAssetsDialogView(INavigationContext context, Action<bool, bool> printSuccessfulAction)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                 {Constants.ActionAfterPrint, printSuccessfulAction}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.PrintFixedAssetsDailogView, context, parameters);
        }

        /// <summary>
        /// Navigates to the add to register view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateAddToRegisterView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddToRegisterView, context, parameters);
        }

        /// <summary>
        /// Searches the master summary posting account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        /// <param name="vesselTypeAttribute">The vessel type attribute.</param>
        public void SearchMasterSummaryPostingAccountDialogView(INavigationContext context, string chartHeaderId, VesselTypeAttribute? vesselTypeAttribute)
        {
            var parameters = new Dictionary<string, object>
            {
                {Constants.ChartHeaderId,chartHeaderId},
                {Constants.VesselTypeAttribute,vesselTypeAttribute }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SearchMasterSummaryPostingAccountDialogView, context, parameters);

        }

        /// <summary>
        /// Navigates the fixed assets header details dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateFixedAssetsHeaderDetailsDialogView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedAssetsHeaderDetailsDialogView, context, parameter);
        }

        /// <summary>
        /// Edits the asset detail view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameter.</param>
        public void EditAssetDetailView(INavigationContext context, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EditAssetDetailView, context, parameters);
        }

        /// <summary>
        /// Settlements the request dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        public void SettlementRequestDialogView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SettlementRequestDialogView, context);
        }

        /// <summary>
        /// Settlements the validation errors dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="request">The request.</param>
        public void SettlementValidationErrorsDialogView(INavigationContext context, object request)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SettlementValidationErrorsDialogView, context, request);
        }

        /// <summary>
        /// Navigates the vessel account controller.
        /// </summary>
        /// <param name="paramater">The paramater.</param>
        public void NavigateVesselAccountController(object paramater)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VesselAccountControllerStartView, paramater);
        }

        /// <summary>
        /// Navigates the entity account controller.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateEntityAccountController(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityAccountControllerStartView, parameter);
        }

        /// <summary>
        /// Navigates the entity roll n clear.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateEntityRollNClear(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityRollNClearStartView, parameter);
        }

        /// <summary>
        /// Navigates to the roll and clear dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        public void NavigateRollAndClearDialogView(INavigationContext context, object paramater)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RollAndClearDialogView, context, paramater);
        }

        /// <summary>
        /// Navigates the vessel exchange revaluation.
        /// </summary>
        /// <param name="paramater">The paramater.</param>
        public void NavigateVesselExchangeRevaluation(object paramater)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.VesselExchangeRevaluationStartView, paramater);
        }

        /// <summary>
        /// Navigates the entity exchange revaluation.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateEntityExchangeRevaluation(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityExchangeRevaluationStartView, parameter);
        }

        /// <summary>
        /// Navigates to the previous year dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="isForJournal">if set to <c>true</c> [is for journal].</param>
        public void NavigatePreviousYearDialogView(INavigationContext context, bool isForJournal)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.NavigatePreviousYearDialogView, context, isForJournal);
        }

        /// <summary>
        /// Fixeds the assets error listing dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        public void FixedAssetsErrorListingDialogView(INavigationContext context, object paramater)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedAssetsErrorListingDialogView, context, paramater);
        }
        /// <summary>
        /// Fixed asset depreciation history view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        public void FixedAssetDepreciationHistoryView(INavigationContext context, object paramater)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedAssetDepreciationHistoryView, context, paramater);
        }

        /// <summary>
        /// Entities the invoice accrual history view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        public void EntityInvoiceAccrualHistoryView(INavigationContext context, object paramater)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityInvoiceAccrualHistoryView, context, paramater);
        }

        /// <summary>
        /// Updates the accrual dates dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        public void UpdateAccrualDatesDialogView(INavigationContext context, object paramater)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.UpdateAccrualDatesDialogView, context, paramater);
        }

        /// <summary>
        /// Vessels the general ledger report navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accoutingCompanyDetails">The accouting company details.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        public void VesselGeneralLedgerReportNavigationView(INavigationContext navigationContext, object accoutingCompanyDetails, string vesselName)
        {
            var parameters = new Dictionary<string, object>
            {
                { Constants.AccountingCompanyDetails, accoutingCompanyDetails },
                {Constants.VesselName,vesselName}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VesselGeneralLedgerReportNavigationView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the commitments listing dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateCommitmentsListingDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CommitmentsListingDialogView, navigationContext);
        }

        /// <summary>
        /// Runnings the cost report navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateRunningCostReportNavigationView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RunningCostReportNavigationView, navigationContext);
        }

        /// <summary>
        /// Navigates the trial balance dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateTrialBalanceDialogView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TrialBalanceDialogView, navigationContext);
        }

        /// <summary>
        /// Views the budget dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void ViewBudgetDialogView(INavigationContext navigationContext, object parameters)
        {
            //parameters is dictionary<string,object>
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ViewBudgetDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Rcs the drill down analysis transaction view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void RCDrillDownAnalysisTransactionView(INavigationContext navigationContext, object parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.RCDrillDownAnalysisTransactionView, parameters, navigationContext);
        }

        /// <summary>
        /// Periods the end process overview start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigatePeriodEndProcessOverviewStartView(INavigationContext navigationContext)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.PeriodEndProcessOverviewStartView);
        }

        /// <summary>
        /// Navigates the crew budget variance report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateCrewBudgetVarianceReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BudgetCrewVarianceReportDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the opex forecasting report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateOpexForecastingReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CashForecastingReportDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the voyage results report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateVoyageResultsReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VoyageResultsDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the invoice reconciliation report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateInvoiceReconciliationReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.InvoiceReconciliationReportDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the creditor analysis report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateCreditorAnalysisReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CreditorAnalysisReportDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the group paid invoices report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateGroupPaidInvoicesReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GroupInvoicesPaidDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the gl audit list report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateGLAuditListReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GLAuditListReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the profit and loss report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateProfitAndLossReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ProfitLossReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the balance sheet report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateBalanceSheetReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.BalanceSheetReportView, navigationContext);
        }

        /// <summary>
        /// Navigates the general ledger text report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateGeneralLedgerTextReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GeneralLedgerTextReportDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the client account legder report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateClientAccountLegderReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientAccountsLedgerDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the client trial balance report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateClientTrialBalanceReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientTrialBalanceDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the running cost fleet report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateRunningCostFleetReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RunningCostFleetReportNavigationView, navigationContext);
        }

        /// <summary>
        /// Navigates the gl analysis report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateGLAnalysisReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.GeneralLedgerAnalysisReportNavigationView, navigationContext);
        }

        /// <summary>
        /// Navigates the funding position report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        public void NavigateFundingPositionReportView(INavigationContext navigationContext)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FundingPositionReportDialogView, navigationContext);
        }

        /// <summary>
        /// Navigates the Running Cost Drill Down Analysis StartView
        /// </summary>
        /// <param name="navigationContext"></param>
        public void NavigateRunningCostDrillDownAnalysisStartView(INavigationContext navigationContext)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.RunningCostDrillDownAnalysisStartView, navigationContext);
        }

        /// <summary>
        /// Navigates the rc recalc logs.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateRCRecalcLogsView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.RCRecalcLogsDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Adds the master report definition dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void AddMasterReportDefDialogView(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddMasterReportDefDialogView, context, parameter);
        }

        /// <summary>
        /// Adds the master rep definition line dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void AddMasterRepDefLineDialogView(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddMasterRepDefLineDialogView, context, parameter);
        }

        /// <summary>
        /// Navigates the acc company standard chart validation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void NavigateAccCompanyStdChartValidationView(INavigationContext navigationContext, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AccCompanyStdChartValidationView, navigationContext, parameter);
        }

        /// <summary>
        /// Entities the auxiliary override reason dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void EntityAuxiliaryOverrideReasonDialogView(INavigationContext navigationContext, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityAuxiliaryOverrideReasonDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigate to fixed asset maintenance start view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateFixedAssetMaintenanceStartView(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.FixedAssetsMaintenanceStartView, parameter);
        }

        /// <summary>
        /// Navigate to fixed asset depreciation start view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateFixedAssetDepreciationStartView(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.FixedAssetDepreciationStartView, parameter);
        }

        /// <summary>
        /// Navigates the inter company settlement start view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void NavigateInterCompanySettlementStartView(object parameter)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.InterCompanySettlementStartView, parameter);
        }

        /// <summary>
        /// Masters the chart of account add operating chart dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void MasterChartOfAccountAddOperatingChartDialogView(INavigationContext navigationContext, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MasterChartOfAccountAddOperatingChartDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Masters the chart of account update parent dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void MasterChartOfAccountUpdateParentDialogView(INavigationContext navigationContext, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MasterChartOfAccountUpdateParentDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Fixeds the asset audit log dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        public void FixedAssetAuditLogDialogView(INavigationContext navigationContext, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedAssetAuditLogDialogView, navigationContext, parameter);
        }

        /// <summary>
        /// Navigate to Centralized Close Ledger View
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ledgerType"></param>
        /// <param name="action"></param>
        public void NavigateCentralizedCloseLedgerView(INavigationContext context, LedgerType ledgerType, Action<string> action)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CentralizedCloseLedgerView, context, 
                new Dictionary<string, object>() {
                    { Constants.LedgerType, ledgerType },
                    { Constants.Action, action }
                });
        }

        /// <summary>
        /// Client Chart print Mapping dialog view
        /// </summary>
        /// <param name="context"></param>
        /// <param name="printSuccessfulAction"></param>
        public void ClientChartPrintMappingDialogView(INavigationContext context, Action<bool, bool> printSuccessfulAction)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                 {Constants.ActionAfterPrint, printSuccessfulAction}
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ClientChartPrintMappingDialogView, context, parameters);
        }

        /// <summary>
        /// Navigate to Entity RollNClear History View
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        public void NavigateEntityRollNClearHistoryView(INavigationContext context, object parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.EntityRollNClearHistoryView, context, parameter);
        }

        /// <summary>
        /// Adds the or edit fixed asset subclass dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="faSubclassId">The fa subclass identifier.</param>
        /// <param name="refreshFixedAssetSubclass">The refresh fixed asset subclass.</param>
        public void AddOrEditFixedAssetSubclassDialogView(INavigationContext context, string faSubclassId, Action<FixedAssetSubclassResponse> refreshFixedAssetSubclass)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {Constants.FaSubclassId, faSubclassId},
                {Constants.Action, refreshFixedAssetSubclass }
            };
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddOrEditFixedAssetSubclassDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates the entity chart of accounts start view.
        /// </summary>
        public void NavigateEntityChartOfAccountsStartView()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.EntityChartOfAccountsStartView);
        }

        /// <summary>Navigates to HFM accenture view.</summary>
        /// <param name="context">The context.</param>
        public void NavigateToHFMAccentureView(INavigationContext context)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.HFMAccentureView, context);
        }

        /// <summary>
        /// Navigates the link to fixed asset.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateLinkToFixedAsset(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.LinkFixedAssetCreditNoteDialogView, context, parameters);
        }

        /// <summary>
        /// Navigates to excluded fixed asset view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateToExcludedAssetView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ExcludedAssetView, context, parameters);
        }

        /// <summary>
        /// Navigates the fixed assets report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="isDisposal">if set to <c>true</c> [is disposal].</param>
        public void NavigateFixedAssetsReport(INavigationContext context, bool isDisposal)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.FixedAssetsReportDialogView, context, isDisposal);
        }

        /// <summary>
        /// Navigates the trvel interface company edit dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        public void NavigateTravelInterfaceCompanyEditDialogView(INavigationContext context, object parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.TravelInterfaceCompanyDetailEditView, context, parameters);
        }

        /// <summary>
        /// Navigate the income statement edit dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        public void IncomeStatementEditDialogView(INavigationContext context, Dictionary<string, object> parameter)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.IncomeStmtEditView, context, parameter);
        }
    }
}
