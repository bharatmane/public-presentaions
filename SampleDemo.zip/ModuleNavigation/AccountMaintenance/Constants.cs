﻿namespace VShips.Framework.Common.ModuleNavigation.AccountMaintenance
{
    /// <summary>
    /// Names of accessible views and regions related to the AccountMaintenance module.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The entities not revalued view
        /// </summary>
        public const string EntitiesNotRevaluedView = "EntitiesNotRevaluedView";

        /// <summary>
        /// The EntityTrialBalanceByAuxiliaryReportView
        /// </summary>
        public const string EntityTrialBalanceByAuxiliaryReportView = "EntityTrialBalanceByAuxiliaryReportView";

        /// <summary>
        /// The invoice accrual geometry
        /// </summary>
        public const string InvoiceAccrualGeometry = "InvoiceAccrualGeometry";

        /// <summary>
        /// The po accrual geometry
        /// </summary>
        public const string POAccrualGeometry = "POAccrualGeometry";

        /// <summary>
        /// The report definition standard geometry
        /// </summary>
        public const string ReportDefinitionStandardGeometry = "ReportDefinitionStandardGeometry";

        /// <summary>
        /// The report definition client geometry
        /// </summary>
        public const string ReportDefinitionClientGeometry = "ReportDefinitionClientGeometry";

        /// <summary>
        /// The reval batch status
        /// </summary>
        public const string RevalBatchStatus = "Reval Batch Status";

        /// <summary>
        /// The alternate rate geometry
        /// </summary>
        public const string AlternateRateGeometry = "AlternateRateGeometry";
        /// <summary>
        /// The is called for entity roll and clear
        /// </summary>
        public const string IsCalledForEntityRollAndClear = "IsCalledForEntityRollAndClear";

        /// <summary>
        /// The is called for vessel exchange revaluation
        /// </summary>
        public const string IsCalledForVesselExchangeRevaluation = "IsCalledForVesselExchangeRevaluation";

        /// <summary>
        /// The country uk code
        /// </summary>
        public const string CountryUkCode = "GBR";

        /// <summary>
        /// The entity code type identifier
        /// </summary>
        public const string EntityCodeTypeId = "EntityCodeTypeId";
        /// <summary>
        /// The code type identifier
        /// </summary>
        public const string CodeTypeId = "CodeTypeId";

        /// <summary>
        /// The entity identifier
        /// </summary>
        public const string EntityId = "EntityId";

        /// <summary>
        /// The is commit
        /// </summary>
        public const string IsCommit = "IsCommit";

        /// <summary>The name of the module.</summary>
        public const string ModuleName = "AccountMaintenance";

        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "AccountMaintenanceGeometry";

        /// <summary>
        /// The period end overview geometry
        /// </summary>
        public const string PeriodEndOverviewGeometry = "PeriodEndOverviewGeometry";

        /// <summary>
        /// The controller geometry
        /// </summary>
        public const string ControllerGeometry = "ControllerGeometry";

        /// <summary> The vessel accounting company module display name </summary>
        public const string VesselAccountingCompanyModuleDisplayName = "Vessel Accounting Company";

        /// <summary>
        /// The entity accounting company geometry
        /// </summary>
        public const string EntityAccountingCompanyGeometry = "EntityAccountingCompanyGeometry";

        /// <summary>
        /// The currency rate maintainer icon
        /// </summary>
        public const string CurrencyRateMaintainerIcon = "CurrencyRateMaintainerGeometry";

        /// <summary>
        /// The vessel accounting company icon
        /// </summary>
        public const string VesselAccountingCompanyIcon = "VesselAccountingCompanyGeometry";


        /// <summary>
        /// The vessel chart of accounts geometry
        /// </summary>
        public const string VesselChartOfAccountsGeometry = "VesselChartOfAccountsGeometry";

        /// <summary>
        /// The master chart of accounts geometry
        /// </summary>
        public const string MasterChartOfAccountsGeometry = "MasterChartOfAccountsGeometry";
        /// <summary>
        /// The Client chart of accounts geometry
        /// </summary>
        public const string ClientChartOfAccountsGeometry = "ClientChartOfAccountsGeometry";

        /// <summary>
        /// The maintain tax code geometry
        /// </summary>
        public const string MaintainTaxCodeGeometry = "MaintainTaxCodeGeometry";

        /// <summary>
        /// The display bank detail geometry
        /// </summary>
        public const string DisplayBankDetailGeometry = "DisplayBankDetailGeometry";

        /// <summary>
        /// The controller lock geometry
        /// </summary>
        public const string ControllerLockGeometry = "ControllerLockGeometry";

        /// <summary>
        /// The controller un lock geometry
        /// </summary>
        public const string ControllerUnLockGeometry = "ControllerUnLockGeometry";

        /// <summary>
        /// The approve currency icon
        /// </summary>
        public const string ApproveCurrencyIcon = "CheckGeometry";

        /// <summary>
        /// The batch update rate icon
        /// </summary>
        public const string BatchUpdateRateIcon = "BulkEntryGeometry";

        /// <summary>
        /// The chart of accounts
        /// </summary>
        public const string ChartOfAccountsIcon = "ChartOfAccountsGeometry";

        //Views
        /// <summary>
        /// The account maintenance module display name
        /// </summary>
        public const string AccountMaintenanceModuleDisplayName = "Account Maintenance";

        /// <summary>
        /// The chart of accounts vessel module name
        /// </summary>
        public const string ChartOfAccountsVesselModuleName = "Vessel Chart Of Accounts";

        /// <summary>The landing or start view for Invoicing.</summary>
        public const string AccountMaintenanceStartView = "AccountMaintenanceStartView";

        /// <summary>
        /// The running cost drill down analysis start view
        /// </summary>
        public const string RunningCostDrillDownAnalysisStartView = "RunningCostDrillDownAnalysisStartView";

        /// <summary>
        /// The account company basic information tab view
        /// </summary>
        public const string AccountCompanyBasicInfoTabView = "AccountCompanyBasicInfoTabView";

        /// <summary>
        /// The account company configuration tab view
        /// </summary>
        public const string AccountCompanyConfigurationTabView = "AccountCompanyConfigurationTabView";

        /// <summary>
        /// The account company contacts tab view
        /// </summary>
        public const string AccountCompanyContactsTabView = "AccountCompanyContactsTabView";

        /// <summary>
        /// The account company documents tab view
        /// </summary>
        public const string AccountCompanyDocumentsTabView = "AccountCompanyDocumentsTabView";

        /// <summary>
        /// The account company bank accounts tab view
        /// </summary>
        public const string AccountCompanyBankAccountsTabView = "AccountCompanyBankAccountsTabView";

        /// <summary>
        /// The chart lookup view dialog
        /// </summary>
        public const string ChartLookupViewDialog = "ChartLookupView";

        /// <summary>
        /// The client chart lookup view dialog
        /// </summary>
        public const string ClientChartLookupViewDialog = "ClientChartLookupView";

        /// <summary>
        /// The payment account lookup view dialog
        /// </summary>
        public const string PaymentAccountLookupViewDialog = "PaymentAccountLookupView";

        /// <summary>
        /// The account company document add view
        /// </summary>
        public const string AccountCompanyDocumentAddView = "AccountCompanyDocumentAddView";

        /// <summary>
        /// The start view
        /// </summary>
        public const string AccountingCompanyStartView = "AccountingCompanyStartView";

        /// <summary>
        /// The entity account master start view
        /// </summary>
        public const string EntityAccountMasterStartView = "EntityAccountMasterStartView";

        /// <summary>
        /// The entity company account start view
        /// </summary>
        public const string EntityCompanyAccountStartView = "EntityCompanyAccountStartView";

        /// <summary>
        /// The create start view
        /// </summary>
        public const string CreateStartView = "CreateStartView";

        /// <summary>
        /// The create entity start view
        /// </summary>
        public const string CreateEntityStartView = "CreateEntityStartView";

        /// <summary>
        /// The Unassigned vessel look up
        /// </summary>
        public const string BasicVesselLookUp = "UnassignedVesselLookupView";

        /// <summary>
        /// The deactivate vessel company account view
        /// </summary>
        public const string AccountCompanyAgreementEndView = "AccountCompanyAgreementEndView";

        /// <summary>
        /// The currency main
        /// </summary>
        public const string CurrencyMain = "CurrencyMaintenanceMainView";

        /// <summary>
        /// The add currency rate
        /// </summary>
        public const string AddCurrencyRate = "AddCurrencyRateDialogView";

        /// <summary>
        /// The currency item
        /// </summary>
        public const string CurrencyItem = "CurrencyMaintenanceItem";

        /// <summary>
        /// The currency items
        /// </summary>
        public const string CurrencyItems = "CurrencyMaintenanceItems";

        /// <summary>
        /// The currency details view
        /// </summary>
        public const string CurrencyDetails = "CurrencyDetailsTabView";


        /// <summary>
        /// The currency audit log
        /// </summary>
        public const string CurrencyAuditLog = "CurrencyAuditLLogTabView";

        /// <summary>
        /// The batch update main
        /// </summary>
        public const string BatchUpdateMain = "Batch Update";

        /// <summary>
        /// The batch update exchange rate
        /// </summary>
        public const string BatchUpdateExchangeRate = "BatchUpdateExchangeRateView";

        /// <summary>
        /// The batch update exchange summary
        /// </summary>
        public const string BatchUpdateExchangeSummary = "BatchUpdateExchangeSummaryView";


        /// <summary>
        /// The approve currency main
        /// </summary>
        public const string ApproveCurrencyMain = "Approve Currency";

        /// <summary>
        /// The create memo view
        /// </summary>
        public const string AccountingCompanyCreateMemoView = "AccountingCompanyCreateMemoView";


        /// <summary>
        /// The Chart Of Accounts Entity StartView
        /// </summary>

        //public const string ChartOfAccountsEntityStartView = "ChartOfAccountsEntityStartView";

        /// <summary>
        /// The Chart Of Accounts Vessel Start View
        /// </summary>

        public const string ChartOfAccountsVesselStartView = "ChartOfAccountsVesselStartView";


        /// <summary>
        /// The Chart Of Accounts Operational View
        /// </summary>

        public const string OperationalChartStartItemView = "OperationalChartStartItemView";

        /// <summary>
        /// The Chart Of Accounts Operational Items View
        /// </summary>
        /// 
        public const string ChartHeaderItemsView = "ChartHeaderItemsView";

        /// <summary>
        /// The Chart Of Accounts Operational Item View
        /// </summary>
        /// 
        public const string ChartHeaderItemView = "ChartHeaderItemView";

        /// <summary>
        /// The Chart Of Accounts Operational Header View
        /// </summary>
        /// 
        public const string ChartHeaderTabView = "ChartHeaderTabView";

        /// <summary>
        /// The Chart Of Accounts Operational Detail View
        /// </summary>
        /// 
        public const string ChartDetailTabView = "ChartDetailTabView";

        /// <summary>
        /// The Chart Of Accounts Operational Used By View
        /// </summary>
        /// 
        public const string ChartUsedByTabView = "ChartUsedByTabView";

        /// <summary>
        /// The Chart Of Accounts Operational Audit Tab View
        /// </summary>
        public const string ChartAuditTabView = "ChartAuditTabView";

        /// <summary>
        /// The Chart Of Accounts Operational Edit Summary Node Dialog View
        /// </summary>
        /// 
        public const string ChartOfAccountsVesselOperationalEditSummaryNodeView = "ChartOfAccountsVesselOperationalEditSummaryNodeView";

        /// <summary>
        ///  /// The Chart Of Accounts Operational Add Summary Node Dialog View
        /// </summary>
        /// 
        public const string VesselOperationalAddSummaryNodeView = "VesselOperationalAddSummaryNodeView";

        /// <summary>
        /// The Chart Of Accounts Operational Edit Posting Node Dialog View
        /// </summary>
        /// 
        public const string ChartOfAccountsVesselOperationalEditPostingNodeView = "VesselOperationalEditPostingNodeView";

        /// <summary>
        /// The Chart Of Accounts Operational Add Posting Node Dialog View
        /// </summary>
        /// 
        public const string VesselOperationalAddPostingNodeView = "VesselOperationalAddPostingNodeView";

        /// <summary>
        /// The vessel operation edit posting node view
        /// </summary>
        public const string VesselOperationEditPostingNodeView = "VesselOperationEditPostingNodeView";

        /// <summary>
        /// The client chart dialog lookup view
        /// </summary>
        public const string ClientChartDialogLookupView = "ClientChartLookupView";
        /// <summary>
        /// The add currency rate dialog view
        /// </summary>
        public const string AddCurrencyRateDialogView = "AddCurrencyRateDialogView";


        /// <summary>
        /// The chart lookup view
        /// </summary>
        public const string ChartLookupView = "ChartLookupView";

        /// <summary>
        /// The add reversal reason view
        /// </summary>
        public const string AddReversalReasonView = "AddReversalReasonView";

        /// <summary>The add edit tax code view</summary>
        public const string AddEditTaxCodeView = "AddEditTaxCodeView";

        /// <summary>The add tax rate view</summary>
        public const string AddTaxRateView = "AddTaxRateView";

        /// <summary>
        /// The edit reversal reason category view
        /// </summary>
        public const string EditReversalReasonCategoryView = "EditReversalReasonCategoryView";

        /// <summary>
        /// The title name
        /// </summary>
        public const string TitleName = "TitleName";

        /// <summary>The tax identifier</summary>
        public const string TaxId= "TaxId";

        /// <summary>
        /// The selected category
        /// </summary>
        public const string SelectedCategory = "SelectedCategory";

        /// <summary>
        /// The request posting summary dialog view
        /// </summary>
        public const string RequestPostingSummaryDialogView = "RequestPostingSummaryDialogView";

        /// <summary>
        /// The add single tax code view
        /// </summary>
        public const string AddSingleTaxCodeView = "AddSingleTaxCodeView";

        /// <summary>
        /// The map bank accounts view
        /// </summary>
        public const string MapBankAccountsView = "MapBankAccountsView";

        /// <summary>
        /// The is add single tax
        /// </summary>
        public const string IsAddSingleTax = "IsAddSingleTax";

        /// <summary>
        /// The refresh list
        /// </summary>
        public const string RefreshList = "RefreshList";

        /// <summary>
        /// The maintain tax code start view
        /// </summary>
        public const string MaintainTaxCodeStartView = "MaintainTaxCodeStartView";

        /// <summary>
        /// The vessel company bank detail start view
        /// </summary>
        public const string VesselCompanyBankDetailStartView = "VesselCompanyBankDetailStartView";

        /// <summary>
        /// The entity company bank detail start view
        /// </summary>
        public const string EntityCompanyBankDetailStartView = "EntityCompanyBankDetailStartView";

        /// <summary>
        /// The fixed assets maintenance start view
        /// </summary>
        public const string FixedAssetsMaintenanceStartView = "FixedAssetsMaintenanceStartView";

        /// <summary>
        /// The vessel account controller start view
        /// </summary>
        public const string VesselAccountControllerStartView = "VesselAccountControllerStartView";

        /// <summary>
        /// The entity account controller start view
        /// </summary>
        public const string EntityAccountControllerStartView = "EntityAccountControllerStartView";

        /// <summary>
        /// The posting summary list dialog view
        /// </summary>
        public const string PostingSummaryListDialogView = "PostingSummaryListDialogView";

        /// <summary>
        /// The account library ListView
        /// </summary>
        public const string AccountLibraryListView = "AccountLibraryListView";

        /// <summary>
        /// The add edit chart of account dialog view
        /// </summary>
        public const string AddEditChartOfAccountDialogView = "AddEditChartOfAccountDialogView";

        /// <summary>
        /// The add chart of account dialog view
        /// </summary>
        public const string AddClientChartOfAccountDialogView = "AddClientChartOfAccountDialogView";

        /// <summary>
        /// The add to account library dialog view
        /// </summary>
        public const string AddToAccountLibraryDialogView = "AddToAccountLibraryDialogView";

        /// <summary>
        /// The add to account library summary dialog view
        /// </summary>
        public const string AddToAccountLibrarySummaryDialogView = "AddToAccountLibrarySummaryDialogView";
        /// <summary>
        /// The reject account request dialog view
        /// </summary>
        public const string RejectAccountRequestDialogView = "RejectAccountRequestDialogView";

        /// <summary>
        /// The Master Chart Of Accounts Start View
        /// </summary>
        public const string MasterChartOfAccountsStartView = "MasterChartOfAccountsStartView";

        /// <summary>
        /// The Master Chart Of Accounts Start Items View
        /// </summary>
        public const string MasterChartOfAccountsStartItemsView = "MasterChartOfAccountsStartItemsView";

        /// <summary>
        /// The Master Chart Of Accounts Start Item View
        /// </summary>
        public const string MasterChartOfAccountsStartItemView = "MasterChartOfAccountsStartItemView";

        /// <summary>
        /// The Master Chart Tab View
        /// </summary>
        public const string MasterChartTabView = "MasterChartTabView";

        /// <summary>
        /// The Master Chart Rules Tab View
        /// </summary>
        public const string MasterChartRulesTabView = "MasterChartRulesTabView";

        /// <summary>
        /// The Master Chart Audit Tab View
        /// </summary>
        public const string MasterChartAuditTabView = "MasterChartAuditTabView";

        /// <summary>
        /// The copy chart of account dialog view
        /// </summary>
        public const string CopyChartOfAccountDialogView = "CopyChartOfAccountDialogView";

        /// <summary>
        /// The chart mapping export dialog view
        /// </summary>
        public const string ChartMappingExportDialogView = "ChartMappingExportDialogView";

        /// <summary>
        /// The chart header identifier
        /// </summary>
        public const string ChartHeaderId = "Chart Header Id";

        /// <summary>
        /// The client chart header identifier
        /// </summary>
        public const string ClientChartHeaderId = "Client Chart Header Id";

        /// <summary>
        /// The chart description
        /// </summary>
        public const string ChartDescription = "Chart Description";

        /// <summary>
        /// The selected chart
        /// </summary>
        public const string SelectedChart = "Selected Chart";

        /// <summary>
        /// The Master Chart Add Summary Account DialogView
        /// </summary>
        public const string MasterChartAddSummaryAccountDialogView = "MasterChartAddSummaryAccountDialogView";

        /// <summary>
        /// The Client Chart Add Summary Account DialogView
        /// </summary>
        public const string ClientChartAddSummaryAccountDialogView = "ClientChartAddSummaryAccountDialogView";

        /// <summary>
        /// The Client Chart Add Posting Account DialogView
        /// </summary>
        public const string ClientChartAddPostingAccountDialogView = "ClientChartAddPostingAccountDialogView";

        /// <summary>
        /// The Is Root Selected.
        /// </summary>
        public const string AccountSelected = "AccountSelected";

        /// <summary>
        /// The is root selected
        /// </summary>
        public const string IsRootSelected = "IsRootSelected";

        /// <summary>
        /// The Selected Master Tree Item
        /// </summary>
        public const string SelectedMasterTreeItem = "SelectedMasterTreeItem";

        /// <summary>
        /// The Selected Client Tree Item
        /// </summary>
        public const string SelectedClientTreeItem = "SelectedClientTreeItem";

        /// <summary>
        /// Parent Id
        /// </summary>
        public const string parentId = "parentId";

        /// <summary>
        /// Parent Description
        /// </summary>
        public const string parentDescription = "parentDescription";

        /// <summary>
        /// The entity account master start item view
        /// </summary>
        public const string EntityAccountMasterStartItemView = "EntityAccountMasterStartItemView";

        /// <summary>
        /// The entity account master start items view
        /// </summary>
        public const string EntityAccountMasterStartItemsView = "EntityAccountMasterStartItemsView";

        /// <summary>
        /// The entity account master basic information tab view
        /// </summary>
        public const string EntityAccountMasterBasicInfoTabView = "EntityAccountMasterBasicInfoTabView";

        /// <summary>
        /// The entity account contacts tab view
        /// </summary>
        public const string EntityAccountContactsTabView = "EntityAccountContactsTabView";

        /// <summary>
        /// The entity account setting tab view
        /// </summary>
        public const string EntityAccountSettingTabView = "EntityAccountSettingTabView";

        /// <summary>
        /// The chart detail list for export
        /// </summary>
        public const string ChartDetailListForExport = "ChartDetailListForExport";


        /// <summary>
        /// The account identifier
        /// </summary>
        public const string AccountId = "AccountId";

        /// <summary>
        /// The memo identifier
        /// </summary>
        public const string MemoId = "MemoId";

        /// <summary>
        /// The is entity flag set
        /// </summary>
        public const string isEntityFlagSet = "isEntityFlagSet";
        /// <summary>
        /// The Client Chart Of Accounts Start View 
        /// </summary>
        public const string ClientChartOfAccountsStartView = "ClientChartOfAccountsStartView";

        /// <summary>
        /// The selected chart matser change
        /// </summary>
        public const string SelectedChartMatserChange = "SelectedChartMatserChange";

        /// <summary>
        /// The chart master lookup view
        /// </summary>
        public const string ChartMasterLookupView = "ChartMasterLookupView";

        /// <summary>
        /// The chart type
        /// </summary>
        public const string ChartType = "ChartType";

        /// <summary>
        /// The search text
        /// </summary>
        public const string SearchText = "SearchText";

        /// <summary>
        /// The running cost end date
        /// </summary>
        public const string RunningCostEndDate = "RunningCostEndDate";
        /// <summary>
        /// The maximum management start date
        /// </summary>
        public const string MaxManagementStartDate = "MaxManagementStartDate";
        /// <summary>
        /// The maximum rc start date
        /// </summary>
        public const string MaxRCStartDate = "MaxRCStartDate";
        /// <summary>
        /// The acc coy type
        /// </summary>
        public const string AccCoyType = "AccCoyType";

        /// <summary>
        /// The entity chart of accounts start view
        /// </summary>
        public const string EntityChartOfAccountsStartView = "EntityChartOfAccountsStartView";

        /// <summary>
        /// The entity client chart of accounts start view
        /// </summary>
        public const string EntityClientChartOfAccountsStartView = "EntityClientChartOfAccountsStartView";

        /// <summary>
        /// The entity chart of accounts add posting dialog view
        /// </summary>
        public const string EntityChartOfAccountsAddPostingDialogView = "EntityChartOfAccountsAddPostingDialogView";

        /// <summary>
        /// The entity chart of accounts add summary dialog view
        /// </summary>
        public const string EntityChartOfAccountsAddSummaryDialogView = "EntityChartOfAccountsAddSummaryDialogView";

        /// <summary>
        /// The add Master chart of account dialog view
        /// </summary>
        public const string AddMasterChartOfAccountDialogView = "AddMasterChartOfAccountDialogView";

        /// <summary>
        /// The Copy Master chart of account dialog view
        /// </summary>
        public const string CopyMasterChartOfAccountDialogView = "CopyMasterChartOfAccountDialogView";

        /// <summary>
        /// The chh coy type
        /// </summary>
        public const string ChhCoyType = "ChhCoyType";
        /// <summary>
        /// The Chh Desc type
        /// </summary>
        public const string ChhDesc = "ChhDesc";

        /// <summary>
        /// The entity chart detail edit view
        /// </summary>
        public const string EntityChartDetailEditView = "EntityChartDetailEditView";

        /// <summary>
        /// The entity chart of accounts edit posting dialog view
        /// </summary>
        public const string EntityChartOfAccountsEditPostingDialogView = "EntityChartOfAccountsEditPostingDialogViewModel";



        /// <summary>
        /// The profit loss report view
        /// </summary>
        public const string ProfitLossReportView = "ProfitAndLossReportView";

        /// <summary>The entity trail balance view</summary>
        public const string EntityTrialBalanceView = "EntityTrialBalanceReportView";


        /// <summary>
        /// The user role details report dialog view
        /// </summary>
        public const string UserRoleDetailsReportDialogView = "UserRoleDetailsReportDialogView";

        /// <summary>
        /// The control permissions report dialog view
        /// </summary>
        public const string ControlPermissionsReportDialogView = "ControlPermissionsReportDialogView";

        /// <summary>
        /// The accounting company identifier
        /// </summary>
        public const string AccountingCompanyId = "AccountingCompanyId";

        /// <summary>
        /// The replied to memo identifier
        /// </summary>
        public const string RepliedToMemoId = "RepliedToMemoId";

        /// <summary>
        /// The is entity
        /// </summary>
        public const string IsEntity = "IsEntity";

        /// <summary>
        /// The entity or vessel name
        /// </summary>
        public const string EntityOrVesselName = "EntityOrVesselName";

        /// <summary>
        /// The add edit client chart of account dialog view
        /// </summary>
        public const string AddEditClientChartOfAccountDialogView = "AddEditClientChartOfAccountDialogView";

        /// <summary>
        /// The export client chart of account dialog view
        /// </summary>
        public const string ExportClientChartOfAccountDialogView = "ExportClientChartOfAccountDialogView";
        /// <summary>
        /// The copy client chart of account dialog view
        /// </summary>
        public const string CopyClientChartOfAccountDialogView = "CopyClientChartOfAccountDialogView";

        /// <summary>
        /// The client chart add posting account selection dialog view
        /// </summary>
        public const string ClientChartAddPostingAccountSelectionDialogView = "ClientChartAddPostingAccountSelectionDialogView";

        /// <summary>
        /// The vessel auxiliary miantainer start view
        /// </summary>
        public const string VesselAuxiliaryMaintainerStartView = "VesselAuxiliaryMaintainerStartView";

        /// <summary>
        /// The add or edit vessel auxiliary dialog view
        /// </summary>
        public const string AddOrEditVesselAuxiliaryDialogView = "AddOrEditVesselAuxiliaryDialogView";



        /// <summary>
        /// The chart master header identifier
        /// </summary>
        public const string ChartMasterHeaderId = "ChartMasterHeaderId";

        /// <summary>
        /// The entity auxiliary maintainer start view
        /// </summary>
        public const string EntityAuxiliaryMaintainerStartView = "EntityAuxiliaryMaintainerStartView";

        /// <summary>
        /// The fixed asset project code start view
        /// </summary>
        public const string FixedAssetProjectCodeStartView = "FixedAssetProjectCodeStartView";

        /// <summary>
        /// Entity Auxiliary override start view.
        /// </summary>
        public const string EntityAuxiliaryOverrideStartView = "EntityAuxiliaryOverrideStartView";

        /// <summary>
        /// The add or edit entity auxiliary dialog view
        /// </summary>
        public const string AddOrEditEntityAuxiliaryDialogView = "AddOrEditEntityAuxiliaryDialogView";

        /// <summary>
        /// The auxiliary maintenance geometry
        /// </summary>
        public const string AuxiliaryMaintenanceGeometry = "AuxiliaryMaintenanceGeometry";

        /// <summary>
        /// The fixed asset project code geometry
        /// </summary>
        public const string FixedAssetProjectCodeGeometry = "FixedAssetProjectCodeGeometry";

        /// <summary>
        /// The is in edit mode
        /// </summary>
        public const string IsInEditMode = "IsInEditMode";

        /// <summary>
        /// The balance sheet report view
        /// </summary>
        public const string BalanceSheetReportView = "BalanceSheetReportView";

        /// <summary>
        /// The roll and clear dialog view
        /// </summary>
        public const string RollAndClearDialogView = "RollAndClearDialogView";

        /// <summary>
        /// The navigate previous year dialog view
        /// </summary>
        public const string NavigatePreviousYearDialogView = "NavigatePreviousYearDialogView";

        /// <summary>
        /// The invoice reconciliation report dialog view
        /// </summary>
        public const string InvoiceReconciliationReportDialogView = "InvoiceReconciliationReportDialogView";

        /// <summary>
        /// The exchange revaluation dialog view
        /// </summary>
        public const string ExchangeRevaluationDialogView = "ExchangeRevaluationDialogView";

        /// <summary>
        /// The entity exchange revaluation start view
        /// </summary>
        public const string EntityExchangeRevaluationStartView = "EntityExchangeRevaluationStartView";

        /// <summary>
        /// The inter company settlement start view
        /// </summary>
        public const string InterCompanySettlementStartView = "InterCompanySettlementStartView";

        /// <summary>
        /// The fixed asset depreciation start view
        /// </summary>
        public const string FixedAssetDepreciationStartView = "FixedAssetDepreciationStartView";

        /// <summary>
        /// The vessel exchange revaluation start view
        /// </summary>
        public const string VesselExchangeRevaluationStartView = "VesselExchangeRevaluationStartView";

        /// <summary>
        /// The vessel invoice accrual start view
        /// </summary>
        public const string VesselInvoiceAccrualStartView = "VesselInvoiceAccrualStartView";

        /// <summary>
        /// The entity invoice accrual start view
        /// </summary>
        public const string EntityInvoiceAccrualStartView = "EntityInvoiceAccrualStartView";

        /// <summary>
        /// The AuxId
        /// </summary>
        public const string AuxId = "AuxId";
        /// <summary>
        /// The action
        /// </summary>
        public const string Action = "Action";


        /// <summary>
        /// The chart detail
        /// </summary>
        public const string ChartDetail = "ChartDetail";

        /// <summary>
        /// The client chart header
        /// </summary>
        public const string ClientChartHeader = "ClientChartHeader";


        /// <summary>
        /// The vessel entity type
        /// </summary>
        public const string VesselEntityType = "VesselEntityType";

        /// <summary>
        /// The search summary posting account dialog view
        /// </summary>
        public const string SearchSummaryPostingAccountDialogView = "SearchSummaryPostingAccountDialogView";

        /// <summary>
        /// The search client summary posting account dialog view
        /// </summary>
        public const string SearchClientSummaryPostingAccountDialogView = "SearchClientSummaryPostingAccountDialogView";

        /// <summary>
        /// The parent object
        /// </summary>
        public const string ParentObject = "ParentObject";
        /// <summary>
        /// The vessel entity chart type
        /// </summary>
        public const string VesselEntityChartType = "VesselEntityChartType";
        /// <summary>
        /// The vessel chart type
        /// </summary>
        public const string VesselChartType = "VesselChartType";
        /// <summary>
        /// The account code
        /// </summary>
        public const string AccountCode = "AccountCode";
        /// <summary>
        /// The active status description
        /// </summary>
        public const string ActiveStatusDescription = "Active";

        /// <summary>
        /// The in active status description
        /// </summary>
        public const string InActiveStatusDescription = "Inactive";

        /// <summary>
        /// The entity auxiliary flag maintenance icon
        /// </summary>
        public const string EntityAuxiliaryFlagMaintenanceIcon = "EntityAuxiliaryFlagMaintenanceGeometry";

        /// <summary>
        /// The chart header
        /// </summary>
        public const string chartHeader = "chartHeader";

        /// <summary>
        /// The clear search
        /// </summary>
        public const string ClearSearch = "ClearSearch";

        /// <summary>
        /// The parent account code
        /// </summary>
        public const string ParentAccountCode = "ParentAccountCode";

        /// <summary>
        /// The posting type
        /// </summary>
        public const string PostingType = "PostingType";

        /// <summary>
        /// The list of acc identifier
        /// </summary>
        public const string ListOfAccId = "ListOfAccId";

        /// <summary>
        /// The running cost drill down analysis view
        /// </summary>
        public const string RunningCostDrillDownAnalysisView = "RunningCostDrillDownAnalysisView";

        /// <summary>
        /// The reports definition standard start view
        /// </summary>
        public const string ReportsDefinitionStandardStartView = "ReportsDefinitionStandardStartView";

        /// <summary>
        /// The reports definition client start view
        /// </summary>
        public const string ReportsDefinitionClientStartView = "ReportsDefinitionClientStartView";

        /// <summary>
        /// The add report client dialog view
        /// </summary>
        public const string AddReportClientDialogView = "AddReportClientDialogView";

        /// <summary>
        /// The add account line dialog view
        /// </summary>
        public const string AddAccountLineDialogView = "AddAccountLineDialogView";

        /// <summary>
        /// The is in view mode
        /// </summary>
        public const string IsInViewMode = "IsInViewMode";


        /// <summary>
        /// The selected invoice detail
        /// </summary>
        public const string SelectedInvoiceDetail = "SelectedInvoiceDetail";

        /// <summary>
        /// The is dispute resolved
        /// </summary>
        public const string IsDisputeResolved = "IsDisputeResolved";

        /// <summary>
        /// The vessel name
        /// </summary>
        public const string VesselName = "VesselName";

        /// <summary>
        /// The invoice title
        /// </summary>
        public const string InvoiceTitle = "InvoiceTitle";

        /// <summary>
        /// The is edit approved currency
        /// </summary>
        public const string IsEditApprovedCurrency = "IsEditApprovedCurrency";

        /// <summary>
        /// The currency preview
        /// </summary>
        public const string CurrencyPreview = "CurrencyPreview";

        /// <summary>
        /// The inter company settlement geometry
        /// </summary>
        public const string InterCompanySettlementGeometry = "InterCompanySettlementGeometry";


        /// <summary>
        /// The clipper extract report navigation view
        /// </summary>
        public const string ClipperExtractReportNavigationView = "ClipperExtractReportNavigationView";

        /// <summary>
        /// The dania extract report navigation view
        /// </summary>
        public const string DaniaExtractReportNavigationView = "DaniaExtractReportNavigationView";

        /// <summary>
        /// The osg data extract report view
        /// </summary>
        public const string OSGDataExtractReportView = "OSGDataExtractReportView";

        /// <summary>
        /// The inter ocean tb extract report dialog view
        /// </summary>
        public const string InterOceanTBExtractReportDialogView = "InterOceanTBExtractReportDialogView";

        /// <summary>
        /// The reval batch status dialog view
        /// </summary>
        public const string RevalBatchStatusDialogView = "RevalBatchStatusDialogView";

        /// <summary>
        /// The purchase order accruals start view
        /// </summary>
        public const string PurchaseOrderAccrualsStartView = "PurchaseOrderAccrualsStartView";

        /// <summary>
        /// The purchase order accruals tab view
        /// </summary>
        public const string PurchaseOrderAccrualsTabView = "PurchaseOrderAccrualsTabView";

        /// <summary>
        /// The vessel invoice accrual tab view
        /// </summary>
        public const string VesselInvoiceAccrualTabView = "VesselInvoiceAccrualTabView";

        /// <summary>
        /// The reval coy summary dialog view
        /// </summary>
        public const string RevalCoySummaryDialogView = "RevalCoySummaryDialogView";

        /// <summary>
        /// The add customize or ad hoc summary dialog view
        /// </summary>
        public const string AddCustomizeOrAdHocSummaryDialogView = "AddCustomizeOrAdHocSummaryDialogView";
        /// <summary>
        /// The chart name
        /// </summary>
        public const string ChartName = "ChartName";
        /// <summary>
        /// The report definition type
        /// </summary>
        public const string ReportDefinitionType = "ReportDefinitionType";
        /// <summary>
        /// The is adhoc
        /// </summary>
        public const string IsAdhoc = "IsAdhoc";
        /// <summary>
        /// The summary acc no
        /// </summary>
        public const string SummaryAccNo = "SummaryAccNo";
        /// <summary>
        /// The summary acc desc
        /// </summary>
        public const string SummaryAccDesc = "SummaryAccDesc";
        /// <summary>
        /// The report definition details identifier
        /// </summary>
        public const string ReportDefDetailsId = "ReportDefDetailsId";

        /// <summary>
        /// The currency yearly report view
        /// </summary>
        public const string CurrencyYearlyReportView = "CurrencyYearlyReportView";

        /// <summary>
        /// The contains history
        /// </summary>
        public const string ContainsHistory = "ContainsHistory";

        /// <summary>
        /// The copy report definition dialog view
        /// </summary>
        public const string CopyReportDefinitionDialogView = "CopyReportDefinitionDialogView";

        /// <summary>
        /// The running cost recalculation dialog view
        /// </summary>
        public const string RunningCostRecalculationDialogView = "RunningCostRecalculationDialogView";

        /// <summary>
        /// The general ledger open transaction dialog view
        /// </summary>
        public const string GeneralLedgerOpenTransactionDialogView = "GeneralLedgerOpenTransactionDialogView";

        /// <summary>
        /// The auxiliary code analysis dialog view
        /// </summary>
        public const string AuxiliaryCodeAnalysisDialogView = "AuxiliaryCodeAnalysisDialogView";

        /// <summary>
        /// The expenditure statement dialog view
        /// </summary>
        public const string ExpenditureStatementDialogView = "ExpenditureStatementDialogView";

        /// <summary>
        /// The search master summary posting account dialog view
        /// </summary>
        public const string SearchMasterSummaryPostingAccountDialogView = "SearchMasterSummaryPostingAccountDialogView";

        /// <summary>
        /// The vessel type attribute
        /// </summary>
        public const string VesselTypeAttribute = "VesselTypeAttribute";

        /// <summary>
        /// The settlement request dialog view
        /// </summary>
        public const string SettlementRequestDialogView = "SettlementRequestDialogView";

        /// <summary>
        /// The settlement validation errors dialog view
        /// </summary>
        public const string SettlementValidationErrorsDialogView = "SettlementValidationErrorsDialogView";

        /// <summary>
        /// The period end process overview start view model
        /// </summary>
        public const string PeriodEndProcessOverviewStartView = "PeriodEndProcessOverviewStartView";

        /// <summary>
        /// The fixed assets error listing dialog view
        /// </summary>
        public const string FixedAssetsErrorListingDialogView = "FixedAssetsErrorListingDialogView";

        /// <summary>
        /// The fixed asset depreciation history view
        /// </summary>
        public const string FixedAssetDepreciationHistoryView = "FixedAssetDepreciationHistoryView";

        /// <summary>
        /// The entity invoice accrual history view
        /// </summary>
        public const string EntityInvoiceAccrualHistoryView = "EntityInvoiceAccrualHistoryView";

        /// <summary>
        /// The fixed asset depreciation geometry
        /// </summary>
        public const string FixedAssetDepreciationGeometry = "FixedAssetDepreciationGeometry";

        /// <summary>
        /// The update accrual dates dialog view
        /// </summary>
        public const string UpdateAccrualDatesDialogView = "UpdateAccrualDatesDialogView";

        /// <summary>
        /// The refresh report definition audit logs
        /// </summary>
        public const string RefreshReportDefinitionAuditLogs = "RefreshReportDefinitionAuditLogs";
        
        /// <summary>
        /// The accouting company details
        /// </summary>
        public const string AccountingCompanyDetails = "AccountingCompanyDetails";

        /// <summary>
        /// The budget analysis navigation view
        /// </summary>
        public const string BudgetAnalysisNavigationView = "BudgetAnalysisNavigationView";

        /// <summary>
        /// The view budget dialog view
        /// </summary>
        public const string ViewBudgetDialogView = "ViewBudgetDialogView";
        /// <summary>
        /// The rc drill down analysis transaction view
        /// </summary>
        public const string RCDrillDownAnalysisTransactionView = "RCDrillDownAnalysisTransactionView";

        /// <summary>
        /// The rc recalc logs dialog view
        /// </summary>
        public const string RCRecalcLogsDialogView = "RCRecalcLogsDialogView";

        /// <summary>
        /// The activate account
        /// </summary>
        public const string ActivateAccount = "ActivateAccount";

        /// <summary>
        /// The theresa vessel spent report view
        /// </summary>
        public const string TheresaVesselSpentReportView = "TheresaVesselSpentReportView";

        /// <summary>
        /// The reports definition master start view
        /// </summary>
        public const string ReportsDefinitionMasterStartView = "ReportsDefinitionMasterStartView";

        /// <summary>
        /// The add master report definition dialog view
        /// </summary>
        public const string AddMasterReportDefDialogView = "AddMasterReportDefDialogView";

        /// <summary>
        /// The add master rep definition line dialog view
        /// </summary>
        public const string AddMasterRepDefLineDialogView = "AddMasterRepDefLineDialogView";

        /// <summary>
        /// The refresh master report definition audit
        /// </summary>
        public const string RefreshMasterReportDefinitionAudit = "RefreshMasterReportDefinitionAudit";

        /// <summary>
        /// The refresh master report definition tab
        /// </summary>
        public const string RefreshMasterReportDefinitionTab = "RefreshMasterReportDefinitionTab";

        /// <summary>
        /// The acc company standard chart validation view
        /// </summary>
        public const string AccCompanyStdChartValidationView = "AccCompanyStdChartValidationView";

        /// <summary>
        /// The Centralized Close Ledger View
        /// </summary>
        public const string CentralizedCloseLedgerView = "CentralizedCloseLedgerView";

        /// <summary>
        /// The Entity Roll And Clear Start View
        /// </summary>
        public const string EntityRollNClearStartView = "EntityRollNClearStartView";

        /// <summary>
        /// The Entity Roll And Clear History View
        /// </summary>
        public const string EntityRollNClearHistoryView = "EntityRollNClearHistoryView";

        /// <summary>
        /// The Ledger Type
        /// </summary>
        public const string LedgerType = "LedgerType";

        /// <summary>
        /// The entity cash forecast output dialog view
        /// </summary>
        public const string EntityCashForecastOutputDialogView = "EntityCashForecastOutputDialogView";

        #region ReportsViewName

        /// <summary>
        /// The group invoices paid dialog view
        /// </summary>
        public const string GroupInvoicesPaidDialogView = "GroupInvoicesPaidDialogView";

        /// <summary>
        /// The client trial balance dialog view
        /// </summary>
        public const string ClientTrialBalanceDialogView = "ClientTrialBalanceDialogView";

        /// <summary>
        /// The outstanding invoice dialog view
        /// </summary>
        public const string OutstandingInvoiceDialogView = "OutstandingInvoiceDialogView";

        /// <summary>
        /// The trial balance dialog view
        /// </summary>
        public const string TrialBalanceDialogView = "TrialBalanceDialogView";

        /// <summary>
        /// The voyage results dialog view
        /// </summary>
        public const string VoyageResultsDialogView = "VoyageResultsDialogView";

        /// <summary>
        /// The commitments listing dialog view
        /// </summary>
        public const string CommitmentsListingDialogView = "CommitmentsListingDialogView";

        /// <summary>
        /// The client accounts ledger dialog view
        /// </summary>
        public const string ClientAccountsLedgerDialogView = "ClientAccountsLedgerDialogView";

        /// <summary>
        /// The creditor analysis report dialog view
        /// </summary>
        public const string CreditorAnalysisReportDialogView = "CreditorAnalysisReportDialogView";

        /// <summary>
        /// The funding position report dialog view
        /// </summary>
        public const string FundingPositionReportDialogView = "FundingPositionReportDialogView";

        /// <summary>
        /// The cash forecasting report dialog view
        /// </summary>
        public const string CashForecastingReportDialogView = "CashForecastingReportDialogView";

        /// <summary>
        /// The vessel general ledger report navigation view
        /// </summary>
        public const string VesselGeneralLedgerReportNavigationView = "VesselGeneralLedgerReportNavigationView";

        /// <summary>
        /// The company
        /// </summary>
        public const string SeletedSettlementCompanyDetails = "SeletedSettlementCompanyDetails";

        /// <summary>
        /// The cut off date
        /// </summary>
        public const string CutOffDate = "CutOffDate";

        /// <summary>
        /// The is ar
        /// </summary>
        public const string IsAR = "IsAR";

        /// <summary>
        /// The coy name
        /// </summary>
        public const string CoyName = "CoyName";

        /// <summary>
        /// The balances selected company dialog view
        /// </summary>
        public const string BalancesSelectedCompanyDialogView = "BalancesSelectedCompanyDialogView";

        /// <summary>
        /// The account receivable payable dialog view
        /// </summary>
        public const string AccountReceivablePayableDialogView = "AccountReceivablePayableDialogView";

        /// <summary>
        /// The chembulk extract report navigation view
        /// </summary>
        public const string ChembulkExtractReportNavigationView = "ChembulkExtractReportNavigationView";

        /// <summary>
        /// The currency report dialog view
        /// </summary>
        public const string CurrencyReportDialogView = "CurrencyReportDialogView";

        /// <summary>
        /// The vessels left account management report dialog view
        /// </summary>
        public const string VesselsLeftAccountManagementReportDialogView = "VesselsLeftAccountManagementReportDialogView";

        /// <summary>
        /// The CSL europe extract report navigation view
        /// </summary>
        public const string CSLEuropeExtractReportNavigationView = "CSLEuropeExtractReportNavigationView";

        /// <summary>
        /// The edit assets dialog view
        /// </summary>
        public const string EditAssetsDialogView = "EditAssetsDialogView";

        /// <summary>
        /// The print fixed assets dialog view
        /// </summary>
        public const string PrintFixedAssetsDailogView = "PrintFixedAssetsDailogView";

        /// <summary>
        /// The add to register view
        /// </summary>
        public const string AddToRegisterView = "AddToRegisterView";

        /// <summary>
        /// The fixed assets header details dialog view
        /// </summary>
        public const string FixedAssetsHeaderDetailsDialogView = "FixedAssetsHeaderDetailsDialogView";

        /// <summary>
        /// The fixed assets geometry
        /// </summary>
        public const string FixedAssetsGeometry = "FixedAssetsGeometry";

        /// <summary>
        /// The can edit
        /// </summary>
        public const string CanEdit = "CanEdit";

        /// <summary>
        /// The fixed asset detail identifier
        /// </summary>
        public const string FixedAssetDetailId = "FixedAssetDetailId";

        /// <summary>
        /// The edit asset detail view
        /// </summary>
        public const string EditAssetDetailView = "EditAssetDetailView";

        /// <summary>
        /// The CMM extract report navigation view
        /// </summary>
        public const string CMMExtractReportNavigationView = "CMMExtractReportNavigationView";

        /// <summary>
        /// The CSL data extract australia boston report navigation view
        /// </summary>
        public const string CSLDataExtractAustraliaBostonReportNavigationView = "CSLDataExtractAustraliaBostonReportNavigationView";

        /// <summary>
        /// The running cost fleet report navigation view
        /// </summary>
        public const string RunningCostFleetReportNavigationView = "RunningCostFleetReportNavigationView";

        /// <summary>
        /// The general ledger analysis report navigation view
        /// </summary>
        public const string GeneralLedgerAnalysisReportNavigationView = "GeneralLedgerAnalysisReportNavigationView";

        /// <summary>
        /// The asset error list
        /// </summary>
        public const string AssetErrorList = "AssetErrorList";

        /// <summary>
        /// The accounting company name
        /// </summary>
        public const string AccountingCompanyName = "AccountingCompanyName";

        /// <summary>
        /// The running cost report navigation view
        /// </summary>
        public const string RunningCostReportNavigationView = "RunningCostReportNavigationView";

        /// <summary>
        /// The dania data extract report navigation view
        /// </summary>
        public const string DaniaDataExtractReportNavigationView = "DaniaDataExtractReportNavigationView";

        /// <summary>
        /// The union data extract report navigation view
        /// </summary>
        public const string UnionDataExtractReportNavigationView = "UnionDataExtractReportNavigationView";

        /// <summary>
        /// The selandia data extract report navigation view
        /// </summary>
        public const string SelandiaDataExtractReportNavigationView = "SelandiaDataExtractReportNavigationView";

        /// <summary>
        /// The trans petro data extract report navigation view
        /// </summary>
        public const string TransPetroDataExtractReportNavigationView = "TransPetroDataExtractReportNavigationView";

        /// <summary>
        /// The CSL data extract report navigation view
        /// </summary>
        public const string CSLDataExtractReportNavigationView = "CSLDataExtractReportNavigationView";

        /// <summary>
        /// The north sea data extract report navigation view
        /// </summary>
        public const string NorthSeaDataExtractReportNavigationView = "NorthSeaDataExtractReportNavigationView";

        /// <summary>
        /// The saga data extract report navigation view
        /// </summary>
        public const string SagaDataExtractReportNavigationView = "SagaDataExtractReportNavigationView";

        /// <summary>
        /// The union maritime extract report navigation view
        /// </summary>
        public const string UnionMaritimeExtractReportNavigationView = "UnionMaritimeExtractReportNavigationView";

        /// <summary>
        /// The team tanker extract report dialog view
        /// </summary>
        public const string TeamTankerExtractReportDialogView = "TeamTankerExtractReportDialogView";

        /// <summary>
        /// The general ledger text report dialog view
        /// </summary>
        public const string GeneralLedgerTextReportDialogView = "GeneralLedgerTextReportDialogView";

        /// <summary>
        /// The budget crew variance report dialog view
        /// </summary>
        public const string BudgetCrewVarianceReportDialogView = "BudgetCrewVarianceReportDialogView";

        /// <summary>
        /// The parameter report type
        /// </summary>
        public const string ParameterReportType = "ReportType";

        /// <summary>
        /// The cash forecast report
        /// </summary>
        public const string CashForecastReport = "CashForecast";

        /// <summary>
        /// The gl audit list report view
        /// </summary>
        public const string GLAuditListReportView = "GLAuditListReportView";

        /// <summary>
        /// The outstanding sales invoice report view
        /// </summary>
        public const string OutstandingSalesInvoiceReportView = "OutstandingSalesInvoiceReportView";

        /// <summary>
        /// The Master Running Cost Report Dialog View
        /// </summary>
        public const string MasterRunningCostReportDialogView = "MasterRunningCostReportDialogView";

        /// <summary>
        /// The entity auxiliary override reason dialog view
        /// </summary>
        public const string EntityAuxiliaryOverrideReasonDialogView = "EntityAuxiliaryOverrideReasonDialogView";

        /// <summary>
        /// The master chart of account add operating chart dialog view
        /// </summary>
        public const string MasterChartOfAccountAddOperatingChartDialogView = "MasterChartOfAccountAddOperatingChartDialogView";

        /// <summary>
        /// The master chart of account update parent dialog view model
        /// </summary>
        public const string MasterChartOfAccountUpdateParentDialogView = "MasterChartOfAccountUpdateParentDialogView";

        /// <summary>
        /// The fixed asset audit log dialog view
        /// </summary>
        public const string FixedAssetAuditLogDialogView = "FixedAssetAuditLogDialogView";

        /// <summary>
        /// The excluded asset view
        /// </summary>
        public const string ExcludedAssetView = "ExcludedAssetView";

		/// <summary>
		/// The income statement report view
		/// </summary>
		public const string IncomeStatementReportView = "IncomeStatementReportView";

        #endregion

        #region Entity Reports

        /// <summary>
        /// The entity commitments listing view
        /// </summary>
        public const string EntityCommitmentsListingView = "EntityCommitmentsListingView";

        /// <summary>
        /// The entity balance sheet report view
        /// </summary>
        public const string EntityBalanceSheetReportView = "EntityBalanceSheetReportView";

        /// <summary>
        /// The entity profit and loss report view
        /// </summary>
        public const string EntityProfitAndLossReportView = "EntityProfitAndLossReportView";

        /// <summary>
        /// Nordic data extrect GMBHD report
        /// </summary>
        public const string NordicDataExtractGMBHDialogView = "NordicDataExtractGMBHDialogView";

        /// <summary>
        /// The agent invoices dailog view
        /// </summary>
        public const string AgentInvoicesDailogView = "AgentInvoicesDailogView";

        /// <summary>
        /// The entity cash receipt report dialog view
        /// </summary>
        public const string EntityCashReceiptReportDialogView = "EntityCashReceiptReportDialogView";

        /// <summary>
        /// The Unallocated Cash Dialog View
        /// </summary>
        public const string UnallocatedCashDialogView = "UnallocatedCashDialogView";

        #endregion

        /// <summary>
        /// The Client Chart Print Mapping DialogView
        /// </summary>
        public const string ClientChartPrintMappingDialogView = "ClientChartPrintMappingDialogView";

        /// <summary>
        /// The action after save
        /// </summary>
        public const string ActionAfterPrint = "ActionAfterPrint";


        /// <summary>The entity open transactions view</summary>
        public const string EntityOpenTransactionsView = "EntityOpenTransactionsView";


        /// <summary>
        /// The entity general ledger audit list View
        /// </summary>
        public const string EntityGeneralLedgerAuditListView = "EntityGeneralLedgerAuditListView";


        /// <summary>
        /// The HFM accenture view
        /// </summary>
        public const string HFMAccentureView = "HFMAccentureView";

		/// <summary>
		/// The financial position statement start view
		/// </summary>
		public const string FinancialPosStatementStartView = "FinancialPosStatementStartView";

		/// <summary>
		/// The add edit fin position map account dialog view
		/// </summary>
		public const string AddEditFinPosMapAccountDialogView = "AddEditFinPosMapAccountDialogView";

        /// <summary>
        /// The gross margin report catering view
        /// </summary>
        public const string GrossMarginReportCateringView = "GrossMarginReportCateringView";

        /// <summary>The Entity Auxiliary Code Analysis View </summary>
        public const string EntityAuxiliaryCodeAnalysisView = "EntityAuxiliaryCodeAnalysisView";

        /// <summary>
        /// The gross margin report catering new view
        /// </summary>
        public const string GrossMarginReportCateringNewView = "GrossMarginReportCateringNewView";

        /// <summary>The Entity Outstanding Purchase Invoice Report View/summary>
        public const string EntityOutstandingPurchaseInvoiceReportView = "EntityOutstandingPurchaseInvoiceReportView";

        /// <summary>
        /// The entity outstanding sales invoice view
        /// </summary>
        public const string EntityOutstandingSalesInvoiceView = "EntityOutstandingSalesInvoiceView";

        /// <summary>
        /// The open transactions aged summary dialog view
        /// </summary>
        public const string OpenTransactionsAgedSummaryDialogView = "OpenTransactionsAgedSummaryDialogView";

        /// <summary>
        /// The account type
        /// </summary>
        public const string AccountType = "AccountType";

        /// <summary>
        /// The Journal Listing Dialog View
        /// </summary>
        public const string JournalListingDialogView = "JournalListingDialogView";

        /// <summary>
        /// The fap identifier
        /// </summary>
        public const string FapId = "FapId";

        /// <summary>
        /// The add or edit fixed asset project dialog view
        /// </summary>
        public const string AddOrEditFixedAssetProjectDialogView = "AddOrEditFixedAssetProjectDialogView";

        /// <summary>
        /// The fixed asset subclass geometry
        /// </summary>
        public const string FixedAssetSubclassGeometry = "FixedAssetSubclassGeometry";

        /// <summary>
        /// The fixed asset subclass start view
        /// </summary>
        public const string FixedAssetSubclassStartView = "FixedAssetSubclassStartView";

        /// <summary>
        /// The add or edit fixed asset subclass dialog view
        /// </summary>
        public const string AddOrEditFixedAssetSubclassDialogView = "AddOrEditFixedAssetSubclassDialogView";

        /// <summary>
        /// The fa subclass identifier
        /// </summary>
        public const string FaSubclassId = "FaSubclassId";

		/// <summary>
		/// The HFM start view
		/// </summary>
		public const string HfmStartView = "HfmStartView";

        /// <summary>
        /// The entity general ledger day book dialog view
        /// </summary>
        public const string EntityGeneralLedgerDayBookDialogView = "EntityGeneralLedgerDayBookDialogView";

        /// <summary>
        /// The HFM aged outstanding dialog view
        /// </summary>
        public const string HFMAgedOutstandingDialogView = "HFMAgedOutstandingDialogView";

        /// <summary>
        /// The invoice tax analysis dialog view
        /// </summary>
        public const string InvoiceTaxAnalysisDialogView = "InvoiceTaxAnalysisDialogView";

        /// <summary>
        /// The link fixed asset credit note dialog view
        /// </summary>
        public const string LinkFixedAssetCreditNoteDialogView = "LinkFixedAssetCreditNoteDialogView";

        /// <summary>
        /// The fixed assets report dialog view
        /// </summary>
        public const string FixedAssetsReportDialogView = "FixedAssetsReportDialogView";

        /// <summary>
        /// The Entity Aged Recharges Dialog View
        /// </summary>
        public const string EntityAgedRechargesDialogView = "EntityAgedRechargesDialogView";

        /// <summary>
        /// The outstanding customer credit report dialog view
        /// </summary>
        public const string OutstandingCustomerCreditReportDialogView = "OutstandingCustomerCreditReportDialogView";

        /// <summary>
        /// The audit listing report view
        /// </summary>
        public const string AuditListingReportView = "AuditListingReportDialogView";

        /// <summary>
        /// Is Called For Due Date
        /// </summary>
        public const string IsCalledForDueDate = "IsCalledForDueDate";

        /// <summary>
        /// The entity sales payment receipt report view
        /// </summary>
        public const string EntitySalesPaymentReceiptReportView = "EntitySalesPaymentReceiptReportView";

        /// <summary>
        /// The general ledger transaction detail dialog view
        /// </summary>
        public const string GeneralLedgerTransactionDetailDialogView = "GeneralLedgerTransactionDetailDialogView";

        /// <summary>
        /// The entity trial balance variance analysis dialog view
        /// </summary>
        public const string EntityTrialBalanceVarianceAnalysisDialogView = "EntityTrialBalanceVarianceAnalysisDialogView";

        /// <summary>
        /// The Revised Trial Balance Dialog View
        /// </summary>
        public const string RevisedTrialBalanceDialogView = "RevisedTrialBalanceDialogView";

        /// <summary>
        /// General Ledger Enquiry Dialog View
        /// </summary>
        public const string GeneralLedgerEnquiryDialogView = "GeneralLedgerEnquiryDialogView";

        /// <summary>
        /// Entity Trial Balance Summery Level Report View
        /// </summary>
        public const string EntityTrialBalanceSummeryLevelReportView = "EntityTrialBalanceSummeryLevelReportView";

        /// <summary>
        /// The entity sales invoice tax dialog view
        /// </summary>
        public const string EntitySalesInvoiceTaxDialogView = "EntitySalesInvoiceTaxDialogView";

        /// <summary>
        /// Entity Currency Mix Report View
        /// </summary>
        public const string EntityCurrencyMixReportView = "EntityCurrencyMixReportView";

        /// <summary>
        /// Purchase Register Report Dialog View
        /// </summary>
        public const string PurchaseRegisterReportDialogView = "PurchaseRegisterReportDialogView";

        /// <summary>
        /// Is Called For Sales
        /// </summary>
        public const string IsCalledForSales = "IsCalledForSales";

        /// <summary>
        /// The travel interface start view
        /// </summary>
        public const string TravelInterfaceStartView = "TravelInterfaceStartView";

        /// <summary>
        /// The travel interface company detail edit view
        /// </summary>
        public const string TravelInterfaceCompanyDetailEditView = "TravelInterfaceCompanyDetailEditView";

        /// <summary>
        /// The income statement edit view
        /// </summary>
        public const string IncomeStmtEditView = "IncomeStmtEditView";

        /// <summary>
        /// The MTS interface start view
        /// </summary>
        public const string MtsInterfaceStartView = "MtsInterfaceStartView";

        /// <summary>
        /// The MTS interface geometry
        /// </summary>
        public const string MtsInterfaceGeometry = "MtsInterfaceGeometry";

        /// <summary>
        /// The travel interface geometry
        /// </summary>
        public const string TravelInterfaceGeometry = "TravelInterfaceGeometry";

        /// <summary>
        /// The entity statistics report dialog view
        /// </summary>
        public const string EntityStatisticsReportDialogView = "EntityStatisticsReportDialogView";
    }
}