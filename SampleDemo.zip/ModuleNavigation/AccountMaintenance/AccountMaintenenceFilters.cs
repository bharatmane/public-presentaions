﻿
namespace VShips.Framework.Common.ModuleNavigation.AccountMaintenance
{
    /// <summary>
    /// This is an accounting maintenance filter class used to filter based on CoyId or vessel name
    /// </summary>
    public class AccountMaintenenceFilters
    {
        #region Properties

        /// <summary>
        /// The search string
        /// </summary>
        private string _searchString;

        /// <summary>
        /// Gets or sets the search string.
        /// </summary>
        /// <value>
        /// The search string.
        /// </value>
        public string SearchString
        {
            get { return _searchString; }
            set
            {
                _searchString = value;
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountMaintenenceFilters"/> class.
        /// </summary>
        public AccountMaintenenceFilters()
        {
        }

        #endregion
    }
}
