﻿using System;
using System.Collections.Generic;
using VShips.Contracts.Custom.Accounts;
using VShips.Contracts.DtoClasses;
using VShips.DataServices.Shared.Enumerations.Accounts;
using VShips.Framework.Common.Services;
namespace VShips.Framework.Common.ModuleNavigation.AccountMaintenance
{
    /// <summary>
    /// Navigation service for the Account Maintenance module.
    /// </summary>
    public interface IAccountMaintenanceNavigation
    {
        /// <summary>
        /// Creates and opens the vessel account company.
        /// </summary>
        void CreateVesselAccountCompany();

        /// <summary>
        /// Creates and opens the entity account company.
        /// </summary>
        void CreateEntityAccountCompany();

        /// <summary>
        /// Opens the vessel account company screen for edit
        /// </summary>
        void EditVesselAccountCompany();

        /// <summary>
        /// Opens the entity account company screen for edit
        /// </summary>
        void EditEntityAccountCompany();

        /// <summary>
        /// Creates the Currency Rate Maintainer.
        /// </summary>
        void CreateCurrencyMaintenance();

        /// <summary>
        /// Opens the batch update.
        /// </summary>
        void OpenBatchUpdate();

        /// <summary>
        /// Navigates the invoice accrual.
        /// </summary>
        void NavigateInvoiceAccrual();


        /// <summary>
        /// Navigates the purchase order and invoice accrual.
        /// </summary>
        void NavigatePurchaseOrderAndInvoiceAccrual();

        /// <summary>
        /// Navigates the client report definition.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateClientReportDefinition(object parameter);

        /// <summary>
        /// Navigates the standard report definition.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateStandardReportDefinition(object parameter);

        /// <summary>
        /// Opens the approve currency.
        /// </summary>
        void OpenApproveCurrency();

        /// <summary>
        /// Accounts the company navigate add attachment.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="coyId">The coy identifier.</param>
        /// <param name="fileNames">The file names.</param>
        void AccountCompanyNavigateAddAttachment(INavigationContext navigationContext, string coyId, IEnumerable<string> fileNames);

        /// <summary>
        /// Opens the Vessel Maintenance.
        /// </summary>
        void ChartOfAccountsVesselMaintenance();


        /// <summary>
        /// Opens the Vessel Operational Maintenance.
        /// </summary>
        void CreateChartOfAccountsVesselOperationalMaintenance();

        /// <summary>
        /// Clients the chart lookup dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="searchedText">The searched text.</param>
        /// <param name="selectedItemChanged">The selected item changed.</param>
        /// <param name="accCompanyType">Type of the acc company.</param>
        /// <param name="chartStatus">The chart status.</param>
        void ClientChartLookupDialogView(INavigationContext context, string searchedText, Action<object> selectedItemChanged, AccountUsedBy accCompanyType, ChartHeaderStatus chartStatus);

        /// <summary>
        /// Opens the unassigned vessel dialog view.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="vesselManagementOfficeTypeId">The vessel management office type identifier.</param>
        void OpenUnassignedVesselDialogView(INavigationContext parentContext, string searchText, string vesselManagementOfficeTypeId);

        /// <summary>
        /// Navigates the out standing invoice report dialog view.
        /// </summary>
        /// <param name="parentContext">The parent context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateOutStandingInvoiceReportDialogView(INavigationContext parentContext, object parameter);

        /// <summary>Adds the currency rate dialog navigation.</summary>
        /// <param name="NavigationContext">The navigation context.</param>
        /// <param name="Parameter">The parameter.</param>
        /// <param name="isEditApprovedCurrency">if set to <c>true</c> [is edit approved currency].</param>
        /// <param name="containsHistory"></param>
        void AddCurrencyRateDialogNavigation(INavigationContext NavigationContext, object Parameter, bool isEditApprovedCurrency, bool containsHistory);

        /// <summary>
        /// Adds the edit reversal reason.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="titleName">Name of the title.</param>
        /// <param name="selectedItem">The selected item.</param>
        void AddEditReversalReason(INavigationContext navigationContext, string titleName, object selectedItem);

        /// <summary>Adds the edit tax code.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taxId">The tax identifier.</param>
        void AddEditTaxCode(INavigationContext navigationContext, string taxId);


        /// <summary>Adds the tax rate.</summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="taxId">The tax identifier.</param>
        void AddTaxRate(INavigationContext navigationContext, string taxId);

		/// <summary>
		/// Navigates the add edit fin position map account dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameter">The parameter.</param>
		void NavigateAddEditFinPosMapAccountDialogView(INavigationContext navigationContext, object parameter);

		/// <summary>
		/// Requests the posting summary dialog.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="selectedChart">The selected chart.</param>
		/// <param name="vesselEntityType">Type of the vessel entity.</param>
		void RequestPostingSummaryDialog(INavigationContext context, object selectedChart, AccountUsedBy vesselEntityType);

        /// <summary>
        /// Postings the summary list dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedChart">The selected chart.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        void PostingSummaryListDialogView(INavigationContext context, object selectedChart, AccountUsedBy vesselEntityType);

        /// <summary>
        /// Accounts the library ListView.
        /// </summary>
        /// <param name="context">The context.</param>
        void AccountLibraryListView(INavigationContext context);

        /// <summary>
        /// Adds the edit chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeader">The chart header.</param>
        /// <param name="ClearSearch">The clear search.</param>
        void AddEditChartOfAccountDialogView(INavigationContext context, object chartHeader, Action ClearSearch);

        /// <summary>
        /// Adds the Client chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        void AddClientChartOfAccountDialogView(INavigationContext context);

        /// <summary>
        /// Adds the single tax code dialog navigation.
        /// </summary>
        /// <param name="NavigationContext">The navigation context.</param>
        /// <param name="isAddSingleTax">if set to <c>true</c> [is add single tax].</param>
        /// <param name="refresh">The refresh.</param>
        void AddSingleTaxCodeDialogNavigation(INavigationContext NavigationContext, bool isAddSingleTax, Action refresh);

        /// <summary>
        /// Maps the bank accounts dialog navigation.
        /// </summary>
        /// <param name="NavigationContext">The navigation context.</param>
        /// <param name="chhId">The CHH identifier.</param>
        /// <param name="listOfAccId">List of Accid</param>
        void MapBankAccountsDialogNavigation(INavigationContext NavigationContext, string chhId, List<string> listOfAccId);

        /// <summary>
        /// Adds to account library dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedItem">The selected item.</param>
        void AddToAccountLibraryDialogView(INavigationContext context, object selectedItem);

        /// <summary>
        /// Adds to account summary library dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedItem">The selected item.</param>
        void AddToAccountLibrarySummaryDialogView(INavigationContext context, object selectedItem);

        /// <summary>
        /// Rejects the account request dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedItem">The selected item.</param>
        void RejectAccountRequestDialogView(INavigationContext context, object selectedItem);

        /// <summary>
        /// Master Chart Of Accounts Start View
        /// </summary>
        /// <param name="context">The Context.</param>
        void MasterChartOfAccountsStartView(INavigationContext context);

        /// <summary>
        /// Client Chart Of Accounts Start View
        /// </summary>
        /// <param name="context">The Context.</param>
        void ClientChartOfAccountsStartView(INavigationContext context);

        /// <summary>
        /// Copies the chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedChart">The selected chart.</param>
        /// <param name="chartCoyType">Type of the chart coy.</param>
        void CopyChartOfAccountDialogView(INavigationContext context, object selectedChart, string chartCoyType);

        /// <summary>
        /// Charts the mapping export dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartDetailListForExport">The chart detail list for export.</param>
        /// <param name="chartDescription">The chart description.</param>
        void ChartMappingExportDialogView(INavigationContext context, object chartDetailListForExport, string chartDescription);

        /// <summary>
        /// Master Chart Add Summary Account dialog View.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedItem">The selected item</param>
        /// <param name="accountSelected">The account selected.</param>
        /// <param name="chartMasterHeaderId">The chart master identifier.</param>
        /// <param name="isInEditMode">if set to <c>true</c> [is in edit mode].</param>
        void MasterChartAddSummaryAccountDialogView(INavigationContext context, object selectedItem, AccountType? accountSelected, string chartMasterHeaderId, bool isInEditMode);

        /// <summary>
        /// Client Chart Add Summary Account dialog View.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="selectedItem">The selected item</param>
        /// <param name="isRootSelected">Is Root Selected</param>
        void ClientChartAddSummaryAccountDialogView(INavigationContext context, object selectedItem, bool isRootSelected);


        /// <summary>
        /// Client Chart Add Posting Account dialog View.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        /// <param name="clientAccountNo">The client account no.</param>
        /// <param name="parentclinetAccountNumber">The parentclinet account number.</param>
        /// <param name="postingType">Type of the posting.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        /// <param name="refreshParent">The refresh parent.</param>
        void ClientChartAddPostingAccountDialogView(INavigationContext context, string chartHeaderId, string clientAccountNo, string parentclinetAccountNumber, string postingType, string vesselEntityType, Action<ClientChartDetailMain> refreshParent);

        /// <summary>
        /// Vessels the operational add posting node view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parent">The parent.</param>
        /// <param name="vesselChartType">Type of the vessel chart.</param>
        void VesselOperationalAddPostingNodeView(INavigationContext context, object parent, VesselTypeAttribute? vesselChartType);

        /// <summary>
        /// Vessel Operational Add Summary NodeView
        /// </summary>
        /// <param name="context">context</param>
        /// <param name="parent">The parent.</param>
        /// <param name="chartType">Type of the chart.</param>
        /// <param name="vesselChartType">Type of the vessel chart.</param>
        /// <param name="isEdit">if set to <c>true</c> [is edit].</param>
        /// <param name="parentAccDesc">The parent acc desc.</param>
        void VesselOperationalAddSummaryNodeView(INavigationContext context, object parent, VesselEntityType? chartType, VesselTypeAttribute? vesselChartType, bool isEdit, string parentAccDesc);

        /// <summary>
        /// Entities the account master start view.
        /// </summary>
        /// <param name="context">The context.</param>
        void EntityAccountMasterStartView(INavigationContext context);

        /// <summary>
        /// Vessels the operational edit posting node view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountCode">The account code.</param>
        /// <param name="parentChart">The parent chart.</param>
        /// <param name="vesselChartType">Type of the vessel chart.</param>
        /// <param name="activateAccount">if set to <c>true</c> [activate account].</param>
        void VesselOperationalEditPostingNodeView(INavigationContext context, string accountCode, object parentChart, VesselTypeAttribute? vesselChartType, bool activateAccount);

        /// <summary>
        /// Navigates the chart master lookup.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="chartType">Type of the chart.</param>
        /// <param name="searchText">The search text.</param>
        /// <param name="selectedChartMatserChange">The selected chart matser change.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        void NavigateChartMasterLookup(INavigationContext navigationContext, VesselTypeAttribute? chartType, string searchText, Action<object> selectedChartMatserChange, string chartHeaderId);

        /// <summary>
        /// Ends the agreement for accounting company.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyType">Type of the accounting company.</param>
        /// <param name="runningCostEndDate">The running cost end date.</param>
        /// <param name="maxManagementStartDate">The maximum management start date.</param>
        /// <param name="maxRCStartDate">The maximum rc start date.</param>
        void EndAgreementForAccountingCompany(INavigationContext context, AccountUsedBy accountingCompanyType, DateTime? runningCostEndDate, DateTime? maxManagementStartDate, DateTime? maxRCStartDate);

        /// <summary>
        /// Entities the chart of accounts add posting dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parent">The parent.</param>
        void EntityChartOfAccountsAddPostingDialogView(INavigationContext context, object parent);

        /// <summary>
        /// Adds the Master chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartMaster">The chart master.</param>
        void AddMasterChartOfAccountDialogView(INavigationContext context, object chartMaster);

        /// <summary>
        /// Copys the Master chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="ChhCoyType">Type of the CHH coy.</param>
        /// <param name="ChhDesc">The CHH desc.</param>

        void CopyMasterChartOfAccountDialogView(INavigationContext context, string ChhCoyType, string ChhDesc);

        /// <summary>
        /// Add edits the client chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="clientChartHeader">The desc.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        void AddEditClientChartOfAccountDialogView(INavigationContext context, object clientChartHeader, VesselEntityType? vesselEntityType);

        /// <summary>Exports the client chart of account dialog view.</summary>
        /// <param name="context">The context.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        void ExportClientChartOfAccountDialogView(INavigationContext context, VesselEntityType? vesselEntityType);

        /// <summary>
        /// Copies the client chart of account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="clientChartHeader">The client chart header.</param>
        void CopyClientChartOfAccountDialogView(INavigationContext context, object clientChartHeader);

        /// <summary>
        /// Entities the chart of accounts edit posting dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountCode">The account code.</param>
        /// <param name="parentChart">The parent chart.</param>
        /// <param name="activateAccount">if set to <c>true</c> [activate account].</param>
        void EntityChartOfAccountsEditPostingDialogView(INavigationContext context, string accountCode, object parentChart, bool activateAccount);


        /// <summary>
        /// Searches the summary posting account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        void SearchSummaryPostingAccountDialogView(INavigationContext context, string chartHeaderId);

        /// <summary>
        /// Searches the client summary posting account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="clientChartHeaderId">The client chart header identifier.</param>
        void SearchClientSummaryPostingAccountDialogView(INavigationContext context, string clientChartHeaderId);

        /// <summary>
        /// Accountings the company create memo view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="accountingCompanyId">The accounting company identifier.</param>
        /// <param name="repliedToMemoId">The replied to memo identifier.</param>
        /// <param name="isEntity">if set to <c>true</c> [is entity].</param>
        /// <param name="entityOrVesselName">Name of the entity or vessel.</param>
        void AccountingCompanyCreateMemoView(INavigationContext context, string accountingCompanyId, string repliedToMemoId, bool isEntity, string entityOrVesselName);

        /// <summary>
        /// Clients the chart add posting account selection dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="addSelectedAccount">The add selected account.</param>
        /// <param name="vesselEntityType">Type of the vessel entity.</param>
        /// <param name="accountType">Type of the account.</param>
        void ClientChartAddPostingAccountSelectionDialogView(INavigationContext context, Action<List<AccountMasterResponse>> addSelectedAccount, VesselEntityType? vesselEntityType, AccountType? accountType);


        /// <summary>
        /// Adds the or edit vessel auxiliary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="CodeTypeId">The code type identifier.</param>
        /// <param name="AuxId">The aux identifier.</param>
        /// <param name="RefreshAuxiliaryDetail">The refresh auxiliary detail.</param>
        void AddOrEditVesselAuxiliaryDialogView(INavigationContext context, string CodeTypeId, object AuxId, Action<VesselGeneralAuxiliaryMain> RefreshAuxiliaryDetail);

        /// <summary>
        /// Adds the or edit entity auxiliary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="codeTypeId">The code type identifier.</param>
        /// <param name="auxId">The aux identifier.</param>
        /// <param name="refreshAuxiliaryDetail">The refresh auxiliary detail.</param>
        void AddOrEditEntityAuxiliaryDialogView(INavigationContext context, string codeTypeId, string auxId, Action<EntityGeneralAuxiliaryMain> refreshAuxiliaryDetail);

        /// <summary>
        /// Adds the or edit fixed asset project dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="fapId">The fap identifier.</param>
        /// <param name="refreshFixedAssetProjects">The refresh fixed asset projects.</param>
        void AddOrEditFixedAssetProjectDialogView(INavigationContext context, string fapId, Action<FixedAssetProjectCodeResponse> refreshFixedAssetProjects);

        /// <summary>
        /// Adds the report client dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="isViewOnly">if set to <c>true</c> [is view only].</param>
        /// <param name="chartCoyType">Type of the chart coy.</param>
        /// <param name="parentId">The parent identifier.</param>
        void AddReportClientDialogView(INavigationContext context, object parameter, bool isViewOnly, object chartCoyType, string parentId);

        /// <summary>
        /// Adds the account line dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void AddAccountLineDialogView(INavigationContext context, object parameter);

        /// <summary>
        /// Revals the batch status dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="isVessel">if set to <c>true</c> [is vessel].</param>
        void RevalBatchStatusDialog(INavigationContext context, bool isVessel);

        /// <summary>
        /// Purchases the order accruals start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void PurchaseOrderAccrualsStartView(INavigationContext navigationContext);
        /// <summary>
        /// Revals the coy summary dialog.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void RevalCoySummaryDialog(INavigationContext context, object parameter);

        /// <summary>
        /// Adds the customize or ad hoc summary dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void AddCustomizeOrAdHocSummaryDialogView(INavigationContext context, object parameter);

        /// <summary>
        /// Currencies the yearly report dialog view.
        /// </summary>
        /// <param name="context">The context.</param> 
        void CurrencyYearlyReportDialogView(INavigationContext context);

        /// <summary>
        /// Copies the report definition dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        /// <param name="chartName">Name of the chart.</param>
        void CopyReportDefinitionDialogView(INavigationContext context, object parameter, string chartName);

        /// <summary>
        /// Navigates the running cost recalculation dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateRunningCostRecalculationDialogView(INavigationContext context);

        /// <summary>
        /// Navigates the general ledger open transaction dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateGeneralLedgerOpenTransactionDialogView(INavigationContext context);

        /// <summary>
        /// Navigates the auxiliary code analysis dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateAuxiliaryCodeAnalysisDialogView(INavigationContext context);

        /// <summary>
        /// Navigates the expenditure statement dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateExpenditureStatementDialogView(INavigationContext context, object parameter = null);

        /// <summary>
        /// Balanceses the selected company dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="cutOffDate">The cut off date.</param>
        void BalancesSelectedCompanyDialogView(INavigationContext context, object entity, DateTime cutOffDate);

        /// <summary>
        /// Accounts the receivable payable dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="entity">The entity.</param>
        /// <param name="cutOffDate">The cut off date.</param>
        /// <param name="isAr">if set to <c>true</c> [is ar].</param>
        /// <param name="coyName">Name of the coy.</param>
        void AccountReceivablePayableDialogView(INavigationContext context, object entity, DateTime? cutOffDate, bool isAr, string coyName);

        /// <summary>
        /// Navigates the edit assets dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateEditAssetsDialogView(INavigationContext context, object parameters);


        /// <summary>Navigates the print fixed assets dialog view.</summary>
        /// <param name="context">The context.</param>
        /// <param name="printSuccessfulAction">The print successful action.</param>
        void NavigatePrintFixedAssetsDialogView(INavigationContext context, Action<bool, bool> printSuccessfulAction);

        /// <summary>
        /// Navigate to the add to register view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateAddToRegisterView(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates the fixed assets header details dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateFixedAssetsHeaderDetailsDialogView(INavigationContext context, object parameter);

        /// <summary>
        /// Searches the master summary posting account dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="chartHeaderId">The chart header identifier.</param>
        /// <param name="vesselTypeAttribute">The vessel type attribute.</param>
        void SearchMasterSummaryPostingAccountDialogView(INavigationContext context, string chartHeaderId, VesselTypeAttribute? vesselTypeAttribute);

        /// <summary>
        /// Edits the asset detail view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void EditAssetDetailView(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Settlements the request dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        void SettlementRequestDialogView(INavigationContext context);

        /// <summary>
        /// Settlements the validation errors dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="request">The request.</param>
        void SettlementValidationErrorsDialogView(INavigationContext context, object request);

        /// <summary>
        /// Navigates the vessel account controller.
        /// </summary>
        /// <param name="paramater">The paramater.</param>
        void NavigateVesselAccountController(object paramater);

        /// <summary>
        /// Navigates the entity account controller.
        /// </summary>
        /// <param name="paramater">The paramater.</param>
        void NavigateEntityAccountController(object paramater);

        /// <summary>
        /// Navigates the entity roll n clear.
        /// </summary>
        /// <param name="paramater">The paramater.</param>
        void NavigateEntityRollNClear(object paramater);

        /// <summary>
        /// Navigates to the roll and clear dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        void NavigateRollAndClearDialogView(INavigationContext context, object paramater);

        /// <summary>
        /// Navigates the vessel exchange revaluation.
        /// </summary>
        /// <param name="paramater">The paramater.</param>
        void NavigateVesselExchangeRevaluation(object paramater);

        /// <summary>
        /// Navigates the entity exchange revaluation.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateEntityExchangeRevaluation(object parameter);

        /// <summary>
        /// Navigates to the previous year dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="isForJournal">if set to <c>true</c> [is for journal].</param>
        void NavigatePreviousYearDialogView(INavigationContext context, bool isForJournal);

        /// <summary>
        /// Fixeds the assets error listing dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        void FixedAssetsErrorListingDialogView(INavigationContext context, object paramater);

        /// <summary>
        /// Fixed asset depreciation history view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        void FixedAssetDepreciationHistoryView(INavigationContext context, object paramater);

        /// <summary>
        /// Entities the invoice accrual history view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        void EntityInvoiceAccrualHistoryView(INavigationContext context, object paramater);

        /// <summary>
        /// Updates the accrual dates dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="paramater">The paramater.</param>
        void UpdateAccrualDatesDialogView(INavigationContext context, object paramater);

        /// <summary>
        /// Vessels the general ledger report navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="accoutingCompanyDetails">The accouting company details.</param>
        /// <param name="vesselName">Name of the vessel.</param>
        void VesselGeneralLedgerReportNavigationView(INavigationContext navigationContext, object accoutingCompanyDetails, string vesselName);

        /// <summary>
        /// Navigates the commitments listing dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateCommitmentsListingDialogView(INavigationContext navigationContext);

        /// <summary>
        /// Runnings the cost report navigation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateRunningCostReportNavigationView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the trial balance dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateTrialBalanceDialogView(INavigationContext navigationContext);

        /// <summary>
        /// Views the budget dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void ViewBudgetDialogView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Rcs the drill down analysis transaction view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void RCDrillDownAnalysisTransactionView(INavigationContext navigationContext, object parameters);

        /// <summary>
        /// Navigates the period end process overview start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigatePeriodEndProcessOverviewStartView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the crew budget variance report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateCrewBudgetVarianceReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the opex forecasting report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateOpexForecastingReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the voyage results report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateVoyageResultsReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the invoice reconciliation report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateInvoiceReconciliationReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the creditor analysis report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateCreditorAnalysisReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the group paid invoices report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateGroupPaidInvoicesReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the gl audit list report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateGLAuditListReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the profit and loss report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateProfitAndLossReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the balance sheet report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateBalanceSheetReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the general ledger text report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateGeneralLedgerTextReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the client account legder report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateClientAccountLegderReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the client trial balance report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateClientTrialBalanceReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the running cost fleet report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateRunningCostFleetReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the gl analysis report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateGLAnalysisReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the funding position report view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        void NavigateFundingPositionReportView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the Running Cost Drill Down Analysis StartView
        /// </summary>
        /// <param name="navigationContext"></param>
        void NavigateRunningCostDrillDownAnalysisStartView(INavigationContext navigationContext);

        /// <summary>
        /// Navigates the rc recalc logs view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateRCRecalcLogsView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Adds the master report definition dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void AddMasterReportDefDialogView(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Adds the master rep definition line dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void AddMasterRepDefLineDialogView(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Navigates the acc company standard chart validation view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameter">The parameter.</param>
        void NavigateAccCompanyStdChartValidationView(INavigationContext navigationContext, object parameter);

        /// <summary>
        /// Entities the auxiliary override reason dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void EntityAuxiliaryOverrideReasonDialogView(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Navigate to fixed asset maintenance start view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateFixedAssetMaintenanceStartView(object parameter);

        /// <summary>
        /// Navigate to fixed asset depreciation start view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateFixedAssetDepreciationStartView(object parameter);

        /// <summary>
        /// Navigates the inter company settlement start view.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        void NavigateInterCompanySettlementStartView(object parameter);

        /// <summary>
        /// Masters the chart of account add operating chart dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void MasterChartOfAccountAddOperatingChartDialogView(INavigationContext context, Dictionary<string, object> parameter);
        /// <summary>
        /// Masters the chart of account update parent dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void MasterChartOfAccountUpdateParentDialogView(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Fixeds the asset audit log dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void FixedAssetAuditLogDialogView(INavigationContext context, Dictionary<string, object> parameter);

        /// <summary>
        /// Navigate to Centralized Close Ledger View
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ledgerType"></param>
        /// <param name="action"></param>
        void NavigateCentralizedCloseLedgerView(INavigationContext context, LedgerType ledgerType, Action<string> action);

        /// <summary>
        /// Client Chart print Mapping dialog view
        /// </summary>
        /// <param name="context"></param>
        /// <param name="printSuccessfulAction"></param>
        void ClientChartPrintMappingDialogView(INavigationContext context, Action<bool, bool> printSuccessfulAction);

        /// <summary>
        /// Navigate to Entity RollNClear History View
        /// </summary>
        /// <param name="context"></param>
        /// <param name="parameter"></param>
        void NavigateEntityRollNClearHistoryView(INavigationContext context, object parameter);

        /// <summary>
        /// Adds the or edit fixed asset subclass dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="faSubclassId">The fa subclass identifier.</param>
        /// <param name="refreshFixedAssetSubclass">The refresh fixed asset subclass.</param>
        void AddOrEditFixedAssetSubclassDialogView(INavigationContext context, string faSubclassId, Action<FixedAssetSubclassResponse> refreshFixedAssetSubclass);

        /// <summary>
        /// Navigates the entity chart of accounts start view.
        /// </summary>
        void NavigateEntityChartOfAccountsStartView();

        /// <summary>
        /// Navigates to HFM accenture view.
        /// </summary>
        /// <param name="context">The context.</param>
        void NavigateToHFMAccentureView(INavigationContext context);

        /// <summary>
        /// Navigates the link to fixed asset.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateLinkToFixedAsset(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates to excluded fixed asset view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateToExcludedAssetView(INavigationContext context, object parameters);

        /// <summary>
        /// Navigates the fixed assets report.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="isDisposal">if set to <c>true</c> [is disposal].</param>
        void NavigateFixedAssetsReport(INavigationContext context, bool isDisposal);

        /// <summary>
        /// Navigates the trvel interface company edit dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameters">The parameters.</param>
        void NavigateTravelInterfaceCompanyEditDialogView(INavigationContext context, object parameters);

        /// <summary>
        /// Navigate the income statement edit dialog view.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="parameter">The parameter.</param>
        void IncomeStatementEditDialogView(INavigationContext context, Dictionary<string, object> parameter);
    }
}