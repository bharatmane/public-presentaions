﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CompanyMaintainer
{
	/// <summary>
	///  Navigation service for the company maintainer
	/// </summary>
	public interface ICompanyMaintainerNavigation
    {
        /// <summary>
        /// Companies the maintainer view attachment dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void CompanyMaintainerViewAttachmentDialogView(INavigationContext navigationContext, Dictionary<string,object> parameters, Action<string> refreshOnDeleteDocument);
        /// <summary>
        /// Companies the maintainer add attachment dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void CompanyMaintainerAddAttachmentDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);
        /// <summary>
        /// Navigates the company vetting ListView.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void NavigateCompanyVettingListView(Dictionary<string, object> parameters);

        /// <summary>
        /// Companies the validation view.
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="isPageReadOnly">if set to <c>true</c> [is page read only].</param>
        /// <param name="isCalledFromSignOffPage">if set to <c>true</c> [is called from sign off page].</param>
        void CompanyValidationView(string companyId, string selectedStatus, bool isPageReadOnly, bool isCalledFromSignOffPage);

        /// <summary>
        /// Vettings the approver sign off approve dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void VettingApproverSignOffApproveDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Vettings the approver sign off reject dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void VettingApproverSignOffRejectDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);


        /// <summary>
        /// Sends the back to vix dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void SendBackToVixDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Templates the detail add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void TemplateDetailAddEditView(INavigationContext navigationContext, Dictionary<string, object> parameters, Action RefreshTemplateList);

        /// <summary>
        /// Questions the library view.
        /// </summary>
        void QuestionLibraryView();

        /// <summary>
        /// Adds the edit question dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void AddEditQuestionDialog(INavigationContext navigationContext, Dictionary<string, object> parameters, Action refreshList);

        /// <summary>
        /// Vettings the template dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void VettingTemplateDialog(INavigationContext navigationContext, Dictionary<string, object> parameters);

        /// <summary>
        /// Categorieses the add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="refresh">The refresh.</param>
        void CategoriesAddEditView(INavigationContext navigationContext, Dictionary<string, object> parameters, Action refresh);

        /// <summary>
        /// Categorieses the list start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        void CategoriesListStartView(INavigationContext navigationContext, Dictionary<string, object> parameters);

		/// <summary>
		/// Approvers the pass dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		void ApproverPassDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

		/// <summary>
		/// Approvers the fail dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		void ApproverFailDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

		/// <summary>
		/// Signs the off fail dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		void SignOffFailDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);

		/// <summary>
		/// MDMs the matched companies dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		void MDMMatchedCompaniesDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters);
    }
}
