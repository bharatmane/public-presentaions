﻿namespace VShips.Framework.Common.ModuleNavigation.CompanyMaintainer
{
    /// <summary>
    /// Constants for Company Maintainer
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The module name
        /// </summary>
        public const string ModuleName = "CompanyMaintainer";

        /// <summary>
        /// The MDM page
        /// </summary>
        public const string MDMPage = "MDM";

        /// <summary>
        /// The name of the common module.
        /// </summary>
        public const string CommonModuleName = "Common";


        /// <summary>The icon representing the module.</summary>
        public const string ModuleIcon = "CompanyMaintainer";

        /// <summary>
        /// The company maintainer start view
        /// </summary>
        public const string CompanyMaintainerStartView = "CompanyMaintainerStartView";

        /// <summary>
        /// The company maintainer view attachment dialog view
        /// </summary>
        public const string CompanyMaintainerViewAttachmentDialogView = "CompanyMaintainerViewAttachmentDialogView";

        /// <summary>
        /// The company identifier
        /// </summary>
        public const string CompanyId = "CompanyId";

        /// <summary>
        /// The company name
        /// </summary>
        public const string CompanyName = "CompanyName";

        /// <summary>
        /// The company maintainer add attachment dialog view
        /// </summary>
        public const string CompanyMaintainerAddAttachmentDialogView = "CompanyMaintainerAddAttachmentDialogViewModel";

        /// <summary>
        /// The company vetting ListView
        /// </summary>
        public const string CompanyVettingListView = "CompanyVettingListView";
        /// <summary>
        /// The MDM validator start view
        /// </summary>
        public const string MDMValidatorStartView = "MDMValidatorStartView";

        /// <summary>
        /// The company validation filter
        /// </summary>
        public const string CompanyValidationFilter = "CompanyValidationFilter";
        /// <summary>
        /// The inspection geometry
        /// </summary>
        public const string InspectionGeometry = "InspectionGeometry";
        /// <summary>
        /// The validation template list start view
        /// </summary>
        public const string ValidationTemplateListStartView = "ValidationTemplateListStartView";

        /// <summary>
        /// The is page read only text
        /// </summary>
        public const string IsPageReadOnlyText = "IsPageReadOnly";

        /// <summary>
        /// The company identifier text
        /// </summary>
        public const string CompanyIdText = "CompanyId";

        /// <summary>
        /// The is called from sign off page
        /// </summary>
        public const string IsCalledFromSignOffPage = "IsCalledFromSignOffPage";

        /// <summary>
        /// The vetting approver sign off approve dialog view
        /// </summary>
        public const string VettingApproverSignOffApproveDialogView = "VettingApproverSignOffApproveDialogView";

        /// <summary>
        /// The save button name
        /// </summary>
        public const string SaveButtonName = "SaveButtonName";

        /// <summary>
        /// The header
        /// </summary>
        public const string Header = "Header";


        /// <summary>
        /// The MDM validator add document dialog view name
        /// </summary>
        public const string MDMValidatorAddDocumentDialogViewName = "MDMValidatorAddDocumentDialogView";

        /// <summary>
        /// The vetting approver sign off reject dialog view
        /// </summary>
        public const string VettingApproverSignOffRejectDialogView = "VettingApproverSignOffRejectDialogView";

        /// <summary>
        /// The send back to vix dialog view name
        /// </summary>
        public const string SendBackToVIXDialogViewName = "SendBackToVIXDialogView";

        /// <summary>
        /// The template detail add edit view
        /// </summary>
        public const string TemplateDetailAddEditView = "TemplateDetailAddEditView";

        /// <summary>
        /// The question library view
        /// </summary>
        public const string QuestionLibraryView = "QuestionLibraryView";

        /// <summary>
        /// The add edit questions dialog view
        /// </summary>
        public const string AddEditQuestionsDialogView = "AddEditQuestionsDialogView";

        /// <summary>
        /// The vetting template dialog view
        /// </summary>
        public const string VettingTemplateDialogView = "VettingTemplateDialogView";

        /// <summary>
        /// All pending reviews geometry
        /// </summary>
        public const string AllPendingReviewsGeometry = "AllPendingReviewsGeometry";

        /// <summary>
        /// The categories list start view
        /// </summary>
        public const string CategoriesListStartView = "CategoriesListStartView";

        /// <summary>
        /// The categories add edit view
        /// </summary>
        public const string CategoriesAddEditView = "CategoriesAddEditView";

        /// <summary>
        /// The payment enquiry geometry
        /// </summary>
        public const string PaymentEnquiryGeometry = "PaymentEnquiryGeometry";

		/// <summary>
		/// The approver pass dialog view
		/// </summary>
		public const string ApproverPassDialogView = "ApproverPassDialogView";

        /// <summary>
        /// The approver fail dialog view
        /// </summary>
        public const string ApproverFailDialogView = "ApproverFailDialogView";

		/// <summary>
		/// The sign off fail dialog view
		/// </summary>
		public const string SignOffFailDialogView = "SignOffFailDialogView";

		/// <summary>
		/// The MDM matched company view
		/// </summary>
		public const string MDMMatchedCompanyView = "MDMMatchedCompanyView";

		/// <summary>
		/// The refresh list
		/// </summary>
		public const string RefreshList = "RefreshList";

		/// <summary>
		/// The title identifier
		/// </summary>
		public const string TitleId = "TitleId";
		/// <summary>
		/// The title name
		/// </summary>
		public const string TitleName = "TitleName";

		/// <summary>
		/// The vetting request identifier
		/// </summary>
		public const string VettingRequestId = "VettingRequestId";

		/// <summary>
		/// The is my responsibility
		/// </summary>
		public const string IsMyResponsibility = "IsMyResponsibility";


		/// <summary>
		/// The selected status for view
		/// </summary>
		public const string SelectedStatusForView = "SelectedStatusForView";
    }
}
