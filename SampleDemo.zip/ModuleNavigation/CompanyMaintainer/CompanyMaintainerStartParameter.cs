﻿using System.Collections.Generic;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.ModuleNavigation.CompanyMaintainer
{
    /// <summary>
    /// CompanyMaintainerStartParameter.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class CompanyMaintainerStartParameter : BaseViewModel
    {
        #region Properties
        /// <summary>
        /// The filter
        /// </summary>
        private CompanyValidationFilter _filter;

        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        public CompanyValidationFilter Filter
        {
            get { return _filter; }
            set { Set(() => Filter, ref _filter, value); }
        }

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyMaintainerStartParameter" /> class.
        /// </summary>
        public CompanyMaintainerStartParameter()
        {
            _filter = new CompanyValidationFilter();
        }
        #endregion


        #region Methods

        /// <summary>
        /// Clones the filter.
        /// This filter should be updated if any changes in the contract properties
        /// </summary>
        /// <returns>Single Obj of</returns>
        public CompanyValidationFilter CloneFilter()
        {
            CompanyValidationFilter newFilter = new CompanyValidationFilter();
            if (Filter != null)
            {
                newFilter.CategoryIds = Filter.CategoryIds;
                newFilter.CompanyStatusIds = Filter.CompanyStatusIds;
                newFilter.CompanyTypeIds = Filter.CompanyTypeIds;
                newFilter.VettingStatusRequest = Filter.VettingStatusRequest;
            }
            return newFilter;
        }

        #endregion

    }


    /// <summary>
    /// CompanyValidationFilter.
    /// </summary>
    public class CompanyValidationFilter
    {

        /// <summary>
        /// Gets or sets the vetting status request.
        /// </summary>
        /// <value>
        /// The vetting status request.
        /// </value>
        public string VettingStatusRequest { get; set; }
        /// <summary>
        /// Gets or sets the company type ids.
        /// </summary>
        /// <value>
        /// The company type ids.
        /// </value>
        public List<string> CompanyTypeIds { get; set; }
        /// <summary>
        /// Gets or sets the company status ids.
        /// </summary>
        /// <value>
        /// The company status ids.
        /// </value>
        public List<string> CompanyStatusIds { get; set; }
        /// <summary>
        /// Gets or sets the category ids.
        /// </summary>
        /// <value>
        /// The category ids.
        /// </value>
        public List<string> CategoryIds { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is count clicked.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is count clicked; otherwise, <c>false</c>.
		/// </value>
		public bool IsCountClicked { get; set; }
    }
}
