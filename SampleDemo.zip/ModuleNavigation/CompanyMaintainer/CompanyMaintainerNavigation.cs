﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.ModuleNavigation.CompanyMaintainer
{
    /// <summary>
    /// Navigation service for the company maintainer
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ModuleNavigation.CompanyMaintainer.ICompanyMaintainerNavigation" />
    public class CompanyMaintainerNavigation : BaseModuleNavigationService, ICompanyMaintainerNavigation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyMaintainerNavigation"/> class.
        /// </summary>
        /// <param name="navigationService">The navigation service.</param>
        public CompanyMaintainerNavigation(INavigationService navigationService)
            : base(navigationService)
        {
        }

        /// <summary>
        /// Companies the maintainer view attachment dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CompanyMaintainerViewAttachmentDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters, Action<string> refreshOnDeleteDocument)
        {
            if (parameters != null)
            {
                parameters.Add(Constants.RefreshList, refreshOnDeleteDocument);
            }
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerViewAttachmentDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Companies the maintainer add attachment dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CompanyMaintainerAddAttachmentDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CompanyMaintainerAddAttachmentDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Navigates the company vetting ListView.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void NavigateCompanyVettingListView(Dictionary<string, object> parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CompanyVettingListView, parameters);
        }

        /// <summary>
        /// Companies the validation view.
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="isPageReadOnly">if set to <c>true</c> [is page read only].</param>
        /// <param name="isCalledFromSignOffPage">if set to <c>true</c> [is called from sign off page].</param>
        public void CompanyValidationView(string companyId, string selectedStatus, bool isPageReadOnly, bool isCalledFromSignOffPage)
        {
            var companyValidationEntityParameters = new Dictionary<string, object>
            {
                {Constants.IsPageReadOnlyText, isPageReadOnly},
                {Constants.CompanyId, companyId},
                {Constants.IsCalledFromSignOffPage, isCalledFromSignOffPage},
                { Constants.SelectedStatusForView, selectedStatus}
            };
            if (isCalledFromSignOffPage)
            {
                NavigationService.NavigateNew(Constants.ModuleName, Constants.CompanyMaintainerStartView, companyValidationEntityParameters);
            }
            else
            {
                NavigationService.Navigate(Constants.ModuleName, Constants.CompanyMaintainerStartView, companyValidationEntityParameters);
            }
        }

        /// <summary>
        /// Vettings the approver sign off approve dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void VettingApproverSignOffApproveDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VettingApproverSignOffApproveDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Vettings the approver sign off reject dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void VettingApproverSignOffRejectDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VettingApproverSignOffRejectDialogView, navigationContext, parameters);
        }

        /// <summary>
        /// Sends the back to vix dialog view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void SendBackToVixDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SendBackToVIXDialogViewName, navigationContext, parameters);
        }

        /// <summary>
        /// Templates the detail add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void TemplateDetailAddEditView(INavigationContext navigationContext, Dictionary<string, object> parameters, Action RefreshTemplateList)
        {
            if (parameters != null)
            {
                parameters.Add(Constants.RefreshList, RefreshTemplateList);
            }
            NavigationService.Navigate(Constants.ModuleName, Constants.TemplateDetailAddEditView, parameters);
        }

        /// <summary>
        /// Questions the library view.
        /// </summary>
        public void QuestionLibraryView()
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.QuestionLibraryView);
        }

        /// <summary>
        /// Adds the edit question dialog.
        /// </summary>
        /// <param name="navigationContext"></param>
        /// <param name="parameters">The parameters.</param>
        public void AddEditQuestionDialog(INavigationContext navigationContext, Dictionary<string, object> parameters, Action refreshList)
        {
            parameters.Add(NavigationParameterConstant.RefreshList, refreshList);

            NavigationService.NavigateDialog(Constants.ModuleName, Constants.AddEditQuestionsDialogView, navigationContext,  parameters);
        }

        /// <summary>
        /// Vettings the template dialog.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void VettingTemplateDialog(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.VettingTemplateDialogView, navigationContext, parameters);
        }


        /// <summary>
        /// Categorieses the add edit view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="refresh">The refresh.</param>
        public void CategoriesAddEditView(INavigationContext navigationContext, Dictionary<string, object> parameters,Action refresh)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.CategoriesAddEditView, navigationContext, parameters);
        }

        /// <summary>
        /// Categorieses the list start view.
        /// </summary>
        /// <param name="navigationContext">The navigation context.</param>
        /// <param name="parameters">The parameters.</param>
        public void CategoriesListStartView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateExisting(Constants.ModuleName, Constants.CategoriesListStartView, parameters);
        }

		/// <summary>
		/// Approvers the pass dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		public void ApproverPassDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ApproverPassDialogView, navigationContext, parameters);
        }

		/// <summary>
		/// Approvers the fail dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		public void ApproverFailDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.ApproverFailDialogView, navigationContext, parameters);
        }

		/// <summary>
		/// Signs the off fail dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		public void SignOffFailDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.SignOffFailDialogView, navigationContext, parameters);
        }

		/// <summary>
		/// MDMs the matched companies dialog view.
		/// </summary>
		/// <param name="navigationContext">The navigation context.</param>
		/// <param name="parameters">The parameters.</param>
		public void MDMMatchedCompaniesDialogView(INavigationContext navigationContext, Dictionary<string, object> parameters)
        {
            NavigationService.NavigateDialog(Constants.ModuleName, Constants.MDMMatchedCompanyView, navigationContext, parameters);
        }
    }
}
