﻿using System;
using System.Runtime.Serialization;
using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.Model.Chat
{
    /// <summary>
    /// Notification DTO
    /// </summary>
    [DataContract]
    public class Notification
    {
        /// <summary>
        /// Gets or sets the channel identifier.
        /// </summary>
        /// <value>
        /// The channel identifier.
        /// </value>
        [DataMember]
        public int ChannelId { get; set; }

        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        [DataMember]
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets the notification identifier.
        /// </summary>
        /// <value>
        /// The notification identifier.
        /// </value>
        [DataMember]
        public string NotificationId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [DataMember]
        public Guid Identifier { get; set; }

        /// <summary>
        /// Gets or sets the content of the message.
        /// </summary>
        /// <value>
        /// The content of the message.
        /// </value>
        [DataMember]
        public string MessageContent { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        [DataMember]
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the display name of the user.
        /// </summary>
        /// <value>
        /// The display name of the user.
        /// </value>
        [DataMember]
        public string UserDisplayName { get; set; }

        /// <summary>
        /// Gets or sets the message date.
        /// </summary>
        /// <value>
        /// The message date.
        /// </value>
        [DataMember]
        public DateTime MessageDate { get; set; }

        /// <summary>
        /// Gets or sets the message target.
        /// </summary>
        /// <value>
        /// The message target.
        /// </value>
        [DataMember]
        public MessageTarget MessageTarget { get; set; }
    }
}
