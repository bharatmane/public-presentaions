﻿using System;
using System.Runtime.Serialization;
using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.Model.Chat
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class Channel
    {
        /// <summary>
        /// Gets or sets the channel identifier.
        /// </summary>
        /// <value>
        /// The channel identifier.
        /// </value>
        [DataMember]
        public int ChannelId { get; set; }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        [DataMember]
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets the cat identifier.
        /// </summary>
        /// <value>
        /// The cat identifier.
        /// </value>
        [DataMember]
        public int? CatId { get; set; }
        /// <summary>
        /// Gets or sets the context payload.
        /// </summary>
        /// <value>
        /// The context payload.
        /// </value>
        [DataMember]
        public string ContextPayload { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [DataMember]
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        [DataMember]
        public int? CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the modified on.
        /// </summary>
        /// <value>
        /// The modified on.
        /// </value>
        [DataMember]
        public DateTime? ModifiedOn { get; set; }
        /// <summary>
        /// Gets or sets the modified by.
        /// </summary>
        /// <value>
        /// The modified by.
        /// </value>
        [DataMember]
        public int? ModifiedBy { get; set; }
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [DataMember]
        public int? Status { get; set; }

        /// <summary>
        /// Gets or sets the message target.
        /// </summary>
        /// <value>
        /// The message target.
        /// </value>
        [DataMember]
        public MessageTarget MessageTarget { get; set; }
    }
}
