﻿using Telerik.Windows.Controls.Map;

#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class VesselPlotPinPoint
    {
        public Location Location { get; set; }
        public int Heading { get; set; }
        public string ToolTip { get; set; }
        public string FillColour { get; set; }
        public object Tag { get; set; }
    }
}
