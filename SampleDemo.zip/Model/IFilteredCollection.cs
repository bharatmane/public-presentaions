﻿using System.Collections;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// interface for view models of grids that can be filtered
    /// </summary>
    public interface IFilteredCollection
    {
        /// <summary>
        /// Filtereds the specified removed items.
        /// </summary>
        /// <param name="filteredItems">The filtered items.</param>
        void Filtered(IList filteredItems);
    }
}
