﻿#pragma warning disable CS1591

namespace VShips.Framework.Common.Model
{
    public class VesselRoutesVesselDetails
    {
        public string VesselType { get; set; }
        public string VesselId { get; set; }
    }
}
