﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Use this interface when you want to implement Reset grouping on load.
    /// </summary>
    public interface IResetGroup
    {
        /// <summary>
        /// Set this property to true before service call, If you want to reset group on service call.
        /// Gets or sets a value indicating whether this instance is reset group.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is reset group; otherwise, <c>false</c>.
        /// </value>
        bool IsResetGroup
        {
            get;
            set;
        }
    }
}
