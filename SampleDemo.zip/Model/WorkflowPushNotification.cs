﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model
{
    public class WorkflowPushNotification
    {

        public string ClientId { get; set; }

        public string NotificationId { get; set; }

        public string MessageContent { get; set; }

        public string NavigationDetail { get; set; }

        public DateTime MessageDate { get; set; }

        public string WorkflowStepId { get; set; }

        public string VesselId { get; set; }

        public DesktopNavigationDetail NavigationDetails
        {
            get { return GetNavigationDetails(); }
        }

        private DesktopNavigationDetail GetNavigationDetails()
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(NavigationDetail))
                {
                    return JsonConvert.DeserializeObject<DesktopNavigationDetail>(NavigationDetail);
                }
            }
            catch
            {
            }

            return new DesktopNavigationDetail();
        }
    }

    public class DesktopNavigationDetail
    {
        public string ModuleName { get; set; }

        public string ViewName { get; set; }

        public string Parameters { get; set; }

        public List<StepDataItem> DataParameters
        {
            get { return GetDataParameters(); }
        }

        private List<StepDataItem> GetDataParameters()
        {
            var dataParameters = new List<StepDataItem>();

            try
            {
                if (!string.IsNullOrWhiteSpace(Parameters))
                {
                    var parameters = JsonConvert.DeserializeObject<Dictionary<string, string>>(Parameters);

                    foreach (var item in parameters)
                    {
                        dataParameters.Add(new StepDataItem() { Name = item.Key, Value = item.Value });
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return dataParameters;
        }

    }

    public class StepDataItem
    {
        public string Name { get; set; }

        public string Value { get; set; }

    }

}
