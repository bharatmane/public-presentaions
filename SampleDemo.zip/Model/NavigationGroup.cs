﻿using System.Collections.Generic;
using System.Xml.Serialization;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Represents a navigation group.
    /// </summary>
    [XmlType(TypeName = "Group")]
    public class NavigationGroup
    {
        /// <summary>
        /// The default constructor for group.
        /// </summary>
        public NavigationGroup()
        {
            Modules = new List<NavigationItem>();
        }

        /// <summary>
        /// The name of the group.
        /// </summary>
        [XmlElement(ElementName = "GroupName")]
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// The image of the group.
        /// </summary>
        [XmlElement(ElementName = "GroupImage")]
        public string Image
        {
            get;
            set;
        }

        /// <summary>
        /// The modules in the group.
        /// </summary>
        public List<NavigationItem> Modules
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is visible.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is visible; otherwise, <c>false</c>.
        /// </value>
        public bool IsVisible
        {
            get;
            set;
        }
                
        /// <summary>
        /// Gets or sets the quick links.
        /// </summary>
        /// <value>
        /// The quick links.
        /// </value>
        public SpecialisedObservableCollection<NavigationItem> QuickLinks
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is nested.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is nested; otherwise, <c>false</c>.
        /// </value>
        public bool IsNested
        {
            get;
            set;
        }
    }
}
