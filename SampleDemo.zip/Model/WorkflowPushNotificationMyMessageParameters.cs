﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model
{
    public class WorkflowPushNotificationMyMessageParameters
    {
        public string clientId { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }

        public WorkflowPushNotificationMyMessageParameters()
        {

        }

        public WorkflowPushNotificationMyMessageParameters(string clientId, DateTime startDate, DateTime endDate)
        {
            this.clientId = clientId;
            this.startDate = startDate;
            this.endDate = endDate;
        }
    }
}
