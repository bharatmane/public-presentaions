﻿using System;

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{
    public class Journey
    {
        public float charterSpeed { get; set; }
        public DateTime dateRecorded { get; set; }
        public string endPortCode { get; set; }
        public string endPortCoordinate { get; set; }
        public string endPortCountry { get; set; }
        public string endPortName { get; set; }
        public string imo { get; set; }
        public bool journeyCompleted { get; set; }
        public DateTime? journeyCompletedDate { get; set; }
        public string journeyId { get; set; }
        public DateTime journeyStartDate { get; set; }
        public bool loaded { get; set; }
        public string startPortCode { get; set; }
        public string startPortCoordinate { get; set; }
        public string startPortCountry { get; set; }
        public string startPortName { get; set; }
        public string vesselName { get; set; }
    }

}
