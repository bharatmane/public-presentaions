﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{
    public class InsightInfo
    {
        public int subscriptionId { get; set; }
        public string imo { get; set; }
        public Location location { get; set; }
        public float cog { get; set; }
        public float sog { get; set; }
        public string dateReported { get; set; }
        public InsightWeather weather { get; set; }
    }

    //public class Location
    //{
    //    public float latitude { get; set; }
    //    public float longitude { get; set; }
    //}

    public class InsightWeather
    {
        public Meta meta { get; set; }
        public Object[] objects { get; set; }
    }

    public class Meta
    {
        public string nearest_time { get; set; }
        public Nearest_Coord nearest_coord { get; set; }
    }

    public class Nearest_Coord
    {
        public string lat { get; set; }
        public string lon { get; set; }
    }

    public class Object
    {
        public string desc { get; set; }
        public string name { get; set; }
        public string unit { get; set; }
        public string value { get; set; }
    }

}

