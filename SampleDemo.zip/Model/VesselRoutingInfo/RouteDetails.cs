﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{

    public class RouteDetails
    {
        public double? averageNoonReportFuelOil { get; set; }
        public double? averageNoonReportSpeed { get; set; }
        public double? charterFuelOil { get; set; }
        public double? charterSpeed { get; set; }
        public DateTime dateRecorded { get; set; }
        public string endPortCode { get; set; }
        public string endPortCoordinate { get; set; }
        public string endPortCountry { get; set; }
        public string endPortName { get; set; }
        public DateTime? eta { get; set; }
        public string imo { get; set; }
        public bool journeyCompleted { get; set; }
        public DateTime? journeyCompletedDate { get; set; }
        public string journeyId { get; set; }
        public DateTime? journeyStartDate { get; set; }
        public bool loaded { get; set; }
        public object startPortCode { get; set; }
        public string startPortCoordinate { get; set; }
        public string startPortCountry { get; set; }
        public string startPortName { get; set; }
        public string vesselName { get; set; }
    }

}
