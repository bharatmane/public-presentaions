﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{
    public class NoonReport
    {
        public string spaId { get; set; }
        public DateTime spaDate { get; set; }
        public string description { get; set; }
        public string steamTime { get; set; }
        public float steamDistance { get; set; }
        public float speed { get; set; }
        public float fuelOilME { get; set; }
        public int latDegree { get; set; }
        public int latMin { get; set; }
        public string latIndicator { get; set; }
        public int longDegree { get; set; }
        public int longMin { get; set; }
        public string longIndicator { get; set; }
        public string coordinates { get; set; }
    }

}
