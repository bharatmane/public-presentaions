﻿
using System;

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{
    public class VisitedPoints
    {
        public int subscriptionId { get; set; }
        public string imo { get; set; }
        public Location location { get; set; }
        public float cog { get; set; }
        public float sog { get; set; }
        public DateTime dateReported { get; set; }
        public float windDirection { get; set; }
        public float windSpeed { get; set; }
        public float pressure { get; set; }
        public float primaryWaveDirection { get; set; }
        public float windWaveHeight { get; set; }
        public Performance performance { get; set; }
    }

    public class Location
    {
        public float latitude { get; set; }
        public float longitude { get; set; }
    }

    public class Performance
    {
        public object noDataReason { get; set; }
        public float charterSpeed { get; set; }
        public float averageSpeed { get; set; }
        public float outcomePercentage { get; set; }
        public float distanceTravelledSinceLastPoint { get; set; }
        public float timeElapsedSinceLastPoint { get; set; }
        public string outcomeText { get; set; }
        public bool charterPerformance { get; set; }
    }


}