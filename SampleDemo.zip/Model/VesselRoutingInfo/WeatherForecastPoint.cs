﻿using System;

#pragma warning disable 1591

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{
    public class WeatherForecastPoint
    {
        public int EcdisWaypointId { get; set; }
        public DateTime WeatherDate { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public decimal SpeedMS { get; set; }
        public int SpeedBeaufort { get; set; }
        public int Direction { get; set; }
        public long TrackDistance { get; set; }
        public long Duration { get; set; }
    }
}
