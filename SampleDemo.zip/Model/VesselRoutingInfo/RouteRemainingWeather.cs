﻿using Newtonsoft.Json;
using System.Collections.Generic;

#pragma warning disable 1591

namespace VShips.Framework.Common.Model.VesselRoutingInfo
{
    public class RouteRemainingWeather
	{
		public string EndPortCountry { get; set; }
		public string EndPortName { get; set; }
		public string Imo { get; set; }
		public string RemainingTripWeather { get; set; }
		public string StartPortCountry { get; set; }
		public string StartPortName { get; set; }
		public string VesselName { get; set; }

		public List<WeatherForecastPoint> RemainingTripWeatherList
        {
			get { return JsonConvert.DeserializeObject<List<WeatherForecastPoint>>(RemainingTripWeather); }
        }
	}
}
