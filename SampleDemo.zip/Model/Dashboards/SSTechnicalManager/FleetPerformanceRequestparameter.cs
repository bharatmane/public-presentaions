﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This is input request parameter
    /// </summary>
    public class FleetPerformanceRequestparameter
    {
        #region Properties
        /// <summary>
        /// Gets or sets the type of the report output.
        /// </summary>
        /// <value>
        /// The type of the report output.
        /// </value>
        public int ReportOutputType { get; set; }
        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        public string OfficeId { get; set; }
        /// <summary>
        /// Gets or sets the fleet identifier.
        /// </summary>
        /// <value>
        /// The fleet identifier.
        /// </value>
        public string FleetId { get; set; }
        /// <summary>
        /// Gets or sets the customer identifier.
        /// </summary>
        /// <value>
        /// The customer identifier.
        /// </value>
        public string CustomerId { get; set; }
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the selected month.
        /// </summary>
        /// <value>
        /// The selected month.
        /// </value>
        public DateTime? SelectedMonth { get; set; }

        /// <summary>
        /// Gets or sets the key account identifier.
        /// </summary>
        /// <value>
        /// The key account identifier.
        /// </value>
        public string KeyAccountId { get; set; }

        #endregion

    }
}
