﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This is output contract class for report details for fleet performance.
    /// </summary>
    public class FPReportDetails:BaseViewModel
    {
        /// <summary>
        /// The identifier
        /// </summary>
        private string _identifier;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Identifier
        {
            get { return _identifier; }
            set { Set(()=>Identifier,ref _identifier , value); }
        }

        /// <summary>
        /// The description
        /// </summary>
        private string _description;

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description
        {
            get { return _description; }
            set { Set(()=>Description,ref _description , value); }
        }

        /// <summary>
        /// The score value
        /// </summary>
        private decimal? _scoreValue;

        /// <summary>
        /// Gets or sets the score value.
        /// </summary>
        /// <value>
        /// The score value.
        /// </value>
        public decimal? ScoreValue
        {
            get { return _scoreValue; }
            set { Set(()=>ScoreValue,ref _scoreValue , value); }
        }

        /// <summary>
        /// The score rayg value
        /// </summary>
        private int? _scoreRAYGValue;

        /// <summary>
        /// Gets or sets the score rayg value.
        /// </summary>
        /// <value>
        /// The score rayg value.
        /// </value>
        public int? ScoreRAYGValue
        {
            get { return _scoreRAYGValue; }
            set { Set(()=> ScoreRAYGValue,ref _scoreRAYGValue , value); }
        }

        /// <summary>
        /// The short description
        /// </summary>
        private string _shortDescription;

        /// <summary>
        /// Gets or sets the short description.
        /// </summary>
        /// <value>
        /// The short description.
        /// </value>
        public string ShortDescription
        {
            get { return _shortDescription; }
            set { Set(() => ShortDescription,ref _shortDescription , value); }
        }

    }
}
