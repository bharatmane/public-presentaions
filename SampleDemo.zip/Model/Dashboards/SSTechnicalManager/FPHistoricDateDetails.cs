﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This is an output class of Fleet performance history date details.
    /// </summary>
    public class FPHistoricDateDetails:BaseViewModel
    {
        #region ApiProperties

        /// <summary>Gets or sets the RowIndex field.</summary>
        public int RowIndex { get; set; }
        /// <summary>Gets or sets the MonthDate field.</summary>
        public DateTime? MonthDate { get; set; }
        /// <summary>Gets or sets the MonthDescription field.</summary>
        public string MonthDescription { get; set; }

        /// <summary>
        /// Gets the month display.
        /// </summary>
        /// <value>
        /// The month display.
        /// </value>
        public string MonthDisplay
        {
            get
            {
                return MonthDate.HasValue ? MonthDate.Value.ToString("dd-MMM-yyyy"): string.Empty;
            }
        }
        #endregion
    }
}
