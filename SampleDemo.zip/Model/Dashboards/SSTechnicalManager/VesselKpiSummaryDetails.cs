﻿using Newtonsoft.Json;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This class is VesselKpiSummaryDetails.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class VesselKpiSummaryDetails : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        [JsonProperty("VesId")]
        public string VesId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        [JsonProperty("VesselName")]
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the imo number.
        /// </summary>
        /// <value>
        /// The imo number.
        /// </value>
        [JsonProperty("IMONumber")]
        public string IMONumber { get; set; }

        /// <summary>
        /// Gets or sets the name of the fleet.
        /// </summary>
        /// <value>
        /// The name of the fleet.
        /// </value>
        [JsonProperty("FleetName")]
        public string FleetName { get; set; }

        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        [JsonProperty("OfficeName")]
        public string OfficeName { get; set; }

        /// <summary>
        /// Gets or sets the is serious incidents excluded.
        /// </summary>
        /// <value>
        /// The is serious incidents excluded.
        /// </value>
        [JsonProperty("IsSeriousIncidentsExcluded")]
        public bool? IsSeriousIncidentsExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is PSC detentions excluded.
        /// </summary>
        /// <value>
        /// The is PSC detentions excluded.
        /// </value>
        [JsonProperty("IsPscDetentionsExcluded")]
        public bool? IsPscDetentionsExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is PSC deficiencies excluded.
        /// </summary>
        /// <value>
        /// The is PSC deficiencies excluded.
        /// </value>
        [JsonProperty("IsPscDeficienciesExcluded")]
        public bool? IsPscDeficienciesExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is ltif excluded.
        /// </summary>
        /// <value>
        /// The is ltif excluded.
        /// </value>
        [JsonProperty("IsLtifExcluded")]
        public bool? IsLtifExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is off hire excluded.
        /// </summary>
        /// <value>
        /// The is off hire excluded.
        /// </value>
        [JsonProperty("IsOffHireExcluded")]
        public bool? IsOffHireExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is rightship excluded.
        /// </summary>
        /// <value>
        /// The is rightship excluded.
        /// </value>
        [JsonProperty("IsRightshipExcluded")]
        public bool? IsRightshipExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is omv findings excluded.
        /// </summary>
        /// <value>
        /// The is omv findings excluded.
        /// </value>
        [JsonProperty("IsOmvFindingsExcluded")]
        public bool? IsOmvFindingsExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is opex excluded.
        /// </summary>
        /// <value>
        /// The is opex excluded.
        /// </value>
        [JsonProperty("IsOpexExcluded")]
        public bool? IsOpexExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is overdue inspection excluded.
        /// </summary>
        /// <value>
        /// The is overdue inspection excluded.
        /// </value>
        [JsonProperty("IsOverdueInspectionExcluded")]
        public bool? IsOverdueInspectionExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is experience matrix excluded.
        /// </summary>
        /// <value>
        /// The is experience matrix excluded.
        /// </value>
        [JsonProperty("IsExperienceMatrixExcluded")]
        public bool? IsExperienceMatrixExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is officer retention excluded.
        /// </summary>
        /// <value>
        /// The is officer retention excluded.
        /// </value>
        [JsonProperty("IsOfficerRetentionExcluded")]
        public bool? IsOfficerRetentionExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is critical PMS excluded.
        /// </summary>
        /// <value>
        /// The is critical PMS excluded.
        /// </value>
        [JsonProperty("IsCriticalPmsExcluded")]
        public bool? IsCriticalPmsExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is fuel efficiency excluded.
        /// </summary>
        /// <value>
        /// The is fuel efficiency excluded.
        /// </value>
        [JsonProperty("IsFuelEfficiencyExcluded")]
        public bool? IsFuelEfficiencyExcluded { get; set; }

        /// <summary>
        /// Gets or sets the is oil spill excluded.
        /// </summary>
        /// <value>
        /// The is oil spill excluded.
        /// </value>
        [JsonProperty("IsOilSpillExcluded")]
        public bool? IsOilSpillExcluded { get; set; }

        public bool? IsSeriousIncidents { get; set; }
        public bool? IsPscDetentions { get; set; }
        public bool? IsPscDeficiencies { get; set; }
        public bool? IsLtif { get; set; }
        public bool? IsOffHire { get; set; }
        public bool? IsRightship { get; set; }
        public bool? IsOmvFindings { get; set; }
        public bool? IsOpex { get; set; }
        public bool? IsOverdueInspection { get; set; }
        public bool? IsExperienceMatrix { get; set; }
        public bool? IsOfficerRetention { get; set; }
        public bool? IsCriticalPms { get; set; }
        public bool? IsFuelEfficiency { get; set; }
        public bool? IsOilSpill { get; set; }

        public bool? IsVesselSelected { get; set; }
    }
}
