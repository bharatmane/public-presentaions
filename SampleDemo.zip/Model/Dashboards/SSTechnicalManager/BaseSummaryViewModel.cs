﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
	/// <summary>
	/// The common class for left side filter in Technical manager Dashboard
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class BaseSummaryViewModel : BaseViewModel
	{
		/// <summary>
		/// The view to navigate
		/// </summary>
		private string _viewToNavigate;

		/// <summary>
		/// Gets or sets the view to navigate.
		/// </summary>
		/// <value>
		/// The view to navigate.
		/// </value>
		public string ViewToNavigate
		{
			get { return _viewToNavigate; }
			set { Set(() => ViewToNavigate, ref _viewToNavigate, value); }
		}


		/// <summary>
		/// The vessel count
		/// </summary>
		private int _vesselCount;

		/// <summary>
		/// Gets or sets the vessel count.
		/// </summary>
		/// <value>
		/// The vessel count.
		/// </value>
		public int VesselCount
		{
			get { return _vesselCount; }
			set { Set(() => VesselCount, ref _vesselCount, value); }
		}

		/// <summary>
		/// The display text
		/// </summary>
		private string _displayText;

		/// <summary>
		/// Gets or sets the display text.
		/// </summary>
		/// <value>
		/// The display text.
		/// </value>
		public string DisplayText
		{
			get { return _displayText; }
			set { Set(() => DisplayText, ref _displayText, value); }
		}

		/// <summary>
		/// The key value
		/// </summary>
		private string _keyValue;

		/// <summary>
		/// Gets or sets the key value.
		/// </summary>
		/// <value>
		/// The key value.
		/// </value>
		public string KeyValue
		{
			get { return _keyValue; }
			set {Set(()=>KeyValue, ref _keyValue, value); }
		}

		/// <summary>
		/// The office identifier
		/// </summary>
		private string _officeId;

		/// <summary>
		/// Gets or sets the office identifier.
		/// </summary>
		/// <value>
		/// The office identifier.
		/// </value>
		public string OfficeId
		{
			get { return _officeId; }
			set {Set(()=>OfficeId, ref _officeId , value); }
		}

        /// <summary>
        /// The is selected
        /// </summary>
        private bool _isSelected;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelected
        {
            get { return _isSelected; }
            set { Set(() => IsSelected, ref _isSelected, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is critical.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is critical; otherwise, <c>false</c>.
        /// </value>
        public bool IsCritical { get; set; }
    }
}
