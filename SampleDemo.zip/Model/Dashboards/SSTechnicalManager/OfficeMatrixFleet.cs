﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// The contract to fetch office matrix data.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class OfficeMatrixFleet : BaseViewModel// BaseWrapper<OfficeMatrixFleet>
    {
        #region Proc Fields

        /// <summary>
        /// Gets or sets the Office field.
        /// </summary>
        /// <value>
        /// The office.
        /// </value>
        public string Office { get; set; }
        /// <summary>
        /// Gets or sets the GeneralManager field.
        /// </summary>
        /// <value>
        /// The general manager.
        /// </value>
		public string GeneralManager { get; set; }
        /// <summary>
        /// Gets or sets the OrgRegion field.
        /// </summary>
        /// <value>
        /// The org region.
        /// </value>
        public string OrgRegion { get; set; }
        /// <summary>
        /// Gets or sets the Id field.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the Month field.
        /// </summary>
        /// <value>
        /// The month.
        /// </value>
        public int? Month { get; set; }
        /// <summary>
        /// Gets or sets the Year field.
        /// </summary>
        /// <value>
        /// The year.
        /// </value>
        public int? Year { get; set; }
        /// <summary>
        /// Gets or sets the MonthName field.
        /// </summary>
        /// <value>
        /// The name of the month.
        /// </value>
        public string MonthName { get; set; }
        /// <summary>
        /// Gets or sets the MonthYear field.
        /// </summary>
        /// <value>
        /// The month year.
        /// </value>
        public string MonthYear { get; set; }
        /// <summary>
        /// Gets or sets the YearMonth field.
        /// </summary>
        /// <value>
        /// The year month.
        /// </value>
        public DateTime? YearMonth { get; set; }
        /// <summary>
        /// Gets or sets the VimLm field.
        /// </summary>
        /// <value>
        /// The vim lm.
        /// </value>
        public int? VimLm { get; set; }
        /// <summary>
        /// Gets or sets the VimPm field.
        /// </summary>
        /// <value>
        /// The vim pm.
        /// </value>
        public int? VimPm { get; set; }
        /// <summary>
        /// Gets or sets the VimCargoLm field.
        /// </summary>
        /// <value>
        /// The vim cargo lm.
        /// </value>
        public int? VimCargoLm { get; set; }
        /// <summary>
        /// Gets or sets the VimCargoPm field.
        /// </summary>
        /// <value>
        /// The vim cargo pm.
        /// </value>
        public int? VimCargoPm { get; set; }
        /// <summary>
        /// Gets or sets the OffHireDays field.
        /// </summary>
        /// <value>
        /// The off hire days.
        /// </value>
        public decimal? OffHireDays { get; set; }
        /// <summary>
        /// Gets or sets the OffHireDaysPrior field.
        /// </summary>
        /// <value>
        /// The off hire days prior.
        /// </value>
        public decimal? OffHireDaysPrior { get; set; }
        /// <summary>
        /// Gets or sets the OffHireDaysR3MWv field.
        /// </summary>
        /// <value>
        /// The off hire days r3 m wv.
        /// </value>
        public decimal? OffHireDaysR3MWv { get; set; }
        /// <summary>
        /// Gets or sets the OffhireRed field.
        /// </summary>
        /// <value>
        /// The offhire red.
        /// </value>
        public Int16? OffhireRed { get; set; }
        /// <summary>
        /// Gets or sets the RightShip field.
        /// </summary>
        /// <value>
        /// The right ship.
        /// </value>
        public decimal? RightShip { get; set; }
        /// <summary>
        /// Gets or sets the RightShipPrior field.
        /// </summary>
        /// <value>
        /// The right ship prior.
        /// </value>
        public decimal? RightShipPrior { get; set; }
        /// <summary>
        /// Gets or sets the RightShipWv field.
        /// </summary>
        /// <value>
        /// The right ship wv.
        /// </value>
        public decimal? RightShipWv { get; set; }
        /// <summary>
        /// Gets or sets the RightShipR3M field.
        /// </summary>
        /// <value>
        /// The right ship r3 m.
        /// </value>
        public decimal? RightShipR3M { get; set; }
        /// <summary>
        /// Gets or sets the RightShipR3MPrior field.
        /// </summary>
        /// <value>
        /// The right ship r3 m prior.
        /// </value>
        public decimal? RightShipR3MPrior { get; set; }
        /// <summary>
        /// Gets or sets the RightShipRed field.
        /// </summary>
        /// <value>
        /// The right ship red.
        /// </value>
        public Int16? RightShipRed { get; set; }
        /// <summary>
        /// Gets or sets the OmvFindingsRatioR6MWv field.
        /// </summary>
        /// <value>
        /// The omv findings ratio r6 m wv.
        /// </value>
        public decimal? OmvFindingsRatioR6MWv { get; set; }
        /// <summary>
        /// Gets or sets the OmvFindingsRatioR6MFleet field.
        /// </summary>
        /// <value>
        /// The omv findings ratio r6 m fleet.
        /// </value>
        public decimal? OmvFindingsRatioR6MFleet { get; set; }
        /// <summary>
        /// Gets or sets the OmvFindingsRatioR6MFleetPrior field.
        /// </summary>
        /// <value>
        /// The omv findings ratio r6 m fleet prior.
        /// </value>
        public decimal? OmvFindingsRatioR6MFleetPrior { get; set; }
        /// <summary>
        /// Gets or sets the OmvfindingsRed field.
        /// </summary>
        /// <value>
        /// The omvfindings red.
        /// </value>
        public Int16? OmvfindingsRed { get; set; }
        /// <summary>
        /// Gets or sets the OmvRejections field.
        /// </summary>
        /// <value>
        /// The omv rejections.
        /// </value>
        public decimal? OmvRejections { get; set; }
        /// <summary>
        /// Gets or sets the OmvRejectionsR3M field.
        /// </summary>
        /// <value>
        /// The omv rejections r3 m.
        /// </value>
        public decimal? OmvRejectionsR3M { get; set; }
        /// <summary>
        /// Gets or sets the OmvRejectionsR6M field.
        /// </summary>
        /// <value>
        /// The omv rejections r6 m.
        /// </value>
        public decimal? OmvRejectionsR6M { get; set; }
        /// <summary>
        /// Gets or sets the OmvRejectionsPrior field.
        /// </summary>
        /// <value>
        /// The omv rejections prior.
        /// </value>
        public decimal? OmvRejectionsPrior { get; set; }
        /// <summary>
        /// Gets or sets the OmvrejectionsRed field.
        /// </summary>
        /// <value>
        /// The omvrejections red.
        /// </value>
        public Int16? OmvrejectionsRed { get; set; }
        /// <summary>
        /// Gets or sets the Opex field.
        /// </summary>
        /// <value>
        /// The opex.
        /// </value>
        public decimal? Opex { get; set; }
        /// <summary>
        /// Gets or sets the OpexPrior field.
        /// </summary>
        /// <value>
        /// The opex prior.
        /// </value>
        public decimal? OpexPrior { get; set; }
        /// <summary>
        /// Gets or sets the OpexWv field.
        /// </summary>
        /// <value>
        /// The opex wv.
        /// </value>
        public decimal? OpexWv { get; set; }
        /// <summary>
        /// Gets or sets the OpexRed field.
        /// </summary>
        /// <value>
        /// The opex red.
        /// </value>
        public Int16? OpexRed { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspection05 field.
        /// </summary>
        /// <value>
        /// The overdue technical inspection05.
        /// </value>
        public int? OverdueTechnicalInspection05 { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspection04 field.
        /// </summary>
        /// <value>
        /// The overdue technical inspection04.
        /// </value>
        public int? OverdueTechnicalInspection04 { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspection46 field.
        /// </summary>
        /// <value>
        /// The overdue technical inspection46.
        /// </value>
        public int? OverdueTechnicalInspection46 { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspection56 field.
        /// </summary>
        /// <value>
        /// The overdue technical inspection56.
        /// </value>
        public int? OverdueTechnicalInspection56 { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspection6Plus field.
        /// </summary>
        /// <value>
        /// The overdue technical inspection6 plus.
        /// </value>
        public int? OverdueTechnicalInspection6Plus { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspection6PlusPrior field.
        /// </summary>
        /// <value>
        /// The overdue technical inspection6 plus prior.
        /// </value>
        public int? OverdueTechnicalInspection6PlusPrior { get; set; }
        /// <summary>
        /// Gets or sets the OverdueTechnicalInspectionsRed field.
        /// </summary>
        /// <value>
        /// The overdue technical inspections red.
        /// </value>
        public Int16? OverdueTechnicalInspectionsRed { get; set; }
        /// <summary>
        /// Gets or sets the CrewRetention field.
        /// </summary>
        /// <value>
        /// The crew retention.
        /// </value>
        public decimal? CrewRetention { get; set; }
        /// <summary>
        /// Gets or sets the CrewRetentionR3M field.
        /// </summary>
        /// <value>
        /// The crew retention r3 m.
        /// </value>
        public decimal? CrewRetentionR3M { get; set; }
        /// <summary>
        /// Gets or sets the CrewRetentionR3MPrior field.
        /// </summary>
        /// <value>
        /// The crew retention r3 m prior.
        /// </value>
        public decimal? CrewRetentionR3MPrior { get; set; }
        /// <summary>
        /// Gets or sets the CrewOnboard field.
        /// </summary>
        /// <value>
        /// The crew onboard.
        /// </value>
        public decimal? CrewOnboard { get; set; }
        /// <summary>
        /// Gets or sets the CrewOnboardL3M field.
        /// </summary>
        /// <value>
        /// The crew onboard l3 m.
        /// </value>
        public decimal? CrewOnboardL3M { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefs1530 field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs1530.
        /// </value>
        public decimal? CrewOverdueReliefs1530 { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefs30Plus field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs30 plus.
        /// </value>
        public decimal? CrewOverdueReliefs30Plus { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefs30PlusL3M field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs30 plus l3 m.
        /// </value>
        public double? CrewOverdueReliefs30PlusL3M { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefsRed field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs red.
        /// </value>
        public Int16? CrewOverdueReliefsRed { get; set; }
        /// <summary>
        /// Gets or sets the CrewOnboardPrior field.
        /// </summary>
        /// <value>
        /// The crew onboard prior.
        /// </value>
        public decimal? CrewOnboardPrior { get; set; }
        /// <summary>
        /// Gets or sets the CrewOnboardL3MPrior field.
        /// </summary>
        /// <value>
        /// The crew onboard l3 m prior.
        /// </value>
        public decimal? CrewOnboardL3MPrior { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefs1530Prior field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs1530 prior.
        /// </value>
        public decimal? CrewOverdueReliefs1530Prior { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefs30PlusPrior field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs30 plus prior.
        /// </value>
        public decimal? CrewOverdueReliefs30PlusPrior { get; set; }
        /// <summary>
        /// Gets or sets the CrewOverdueReliefs30PlusL3MPrior field.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs30 plus l3 m prior.
        /// </value>
        public double? CrewOverdueReliefs30PlusL3MPrior { get; set; }
        /// <summary>
        /// Gets or sets the FundingDaysUnderfunding field.
        /// </summary>
        /// <value>
        /// The funding days underfunding.
        /// </value>
        public int? FundingDaysUnderfunding { get; set; }
        /// <summary>
        /// Gets or sets the FundingDaysUnderfundingPrior field.
        /// </summary>
        /// <value>
        /// The funding days underfunding prior.
        /// </value>
        public int? FundingDaysUnderfundingPrior { get; set; }
        /// <summary>
        /// Gets or sets the LtifRatioR3MFleet field.
        /// </summary>
        /// <value>
        /// The ltif ratio r3 m fleet.
        /// </value>
        public decimal? LtifRatioR3MFleet { get; set; }
        /// <summary>
        /// Gets or sets the LtifRatioR3MFleetPrior field.
        /// </summary>
        /// <value>
        /// The ltif ratio r3 m fleet prior.
        /// </value>
        public decimal? LtifRatioR3MFleetPrior { get; set; }
        /// <summary>
        /// Gets or sets the Ltifred field.
        /// </summary>
        /// <value>
        /// The ltifred.
        /// </value>
        public Int16? Ltifred { get; set; }
        /// <summary>
        /// Gets or sets the MedicalIllnessRateR3MFleet field.
        /// </summary>
        /// <value>
        /// The medical illness rate r3 m fleet.
        /// </value>
        public decimal? MedicalIllnessRateR3MFleet { get; set; }
        /// <summary>
        /// Gets or sets the MedicalIllnessRateR3MFleetPrior field.
        /// </summary>
        /// <value>
        /// The medical illness rate r3 m fleet prior.
        /// </value>
        public decimal? MedicalIllnessRateR3MFleetPrior { get; set; }
        /// <summary>
        /// Gets or sets the TrcfRatioR3MFleet field.
        /// </summary>
        /// <value>
        /// The TRCF ratio r3 m fleet.
        /// </value>
        public decimal? TrcfRatioR3MFleet { get; set; }
        /// <summary>
        /// Gets or sets the TrcfRatioR3MFleetPrior field.
        /// </summary>
        /// <value>
        /// The TRCF ratio r3 m fleet prior.
        /// </value>
        public decimal? TrcfRatioR3MFleetPrior { get; set; }
        /// <summary>
        /// Gets or sets the Trcfred field.
        /// </summary>
        /// <value>
        /// The trcfred.
        /// </value>
        public Int16? Trcfred { get; set; }
        /// <summary>
        /// Gets or sets the PscDetentions field.
        /// </summary>
        /// <value>
        /// The PSC detentions.
        /// </value>
        public int? PscDetentions { get; set; }
        /// <summary>
        /// Gets or sets the PscDetentionsR3M field.
        /// </summary>
        /// <value>
        /// The PSC detentions r3 m.
        /// </value>
        public int? PscDetentionsR3M { get; set; }
        /// <summary>
        /// Gets or sets the PscDetentionsPrior field.
        /// </summary>
        /// <value>
        /// The PSC detentions prior.
        /// </value>
        public int? PscDetentionsPrior { get; set; }
        /// <summary>
        /// Gets or sets the PscdetentionsRed field.
        /// </summary>
        /// <value>
        /// The pscdetentions red.
        /// </value>
        public Int16? PscdetentionsRed { get; set; }
        /// <summary>
        /// Gets or sets the PscDeficienciesRatioR3MWv field.
        /// </summary>
        /// <value>
        /// The PSC deficiencies ratio r3 m wv.
        /// </value>
        public decimal? PscDeficienciesRatioR3MWv { get; set; }
        /// <summary>
        /// Gets or sets the PscDeficienciesRatioR3MFleet field.
        /// </summary>
        /// <value>
        /// The PSC deficiencies ratio r3 m fleet.
        /// </value>
        public decimal? PscDeficienciesRatioR3MFleet { get; set; }
        /// <summary>
        /// Gets or sets the PscDeficienciesRatioR3MFleetPrior field.
        /// </summary>
        /// <value>
        /// The PSC deficiencies ratio r3 m fleet prior.
        /// </value>
        public decimal? PscDeficienciesRatioR3MFleetPrior { get; set; }
        /// <summary>
        /// Gets or sets the PscdeficienciesRed field.
        /// </summary>
        /// <value>
        /// The pscdeficiencies red.
        /// </value>
        public Int16? PscdeficienciesRed { get; set; }
        /// <summary>
        /// Gets or sets the SeriousIncidents field.
        /// </summary>
        /// <value>
        /// The serious incidents.
        /// </value>
        public int? SeriousIncidents { get; set; }
        /// <summary>
        /// Gets or sets the SeriousIncidentsR3M field.
        /// </summary>
        /// <value>
        /// The serious incidents r3 m.
        /// </value>
        public int? SeriousIncidentsR3M { get; set; }
        /// <summary>
        /// Gets or sets the SeriousIncidentsPrior field.
        /// </summary>
        /// <value>
        /// The serious incidents prior.
        /// </value>
        public int? SeriousIncidentsPrior { get; set; }
        /// <summary>
        /// Gets or sets the SeriousIncidentsRed field.
        /// </summary>
        /// <value>
        /// The serious incidents red.
        /// </value>
        public Int16? SeriousIncidentsRed { get; set; }
        /// <summary>
        /// Gets or sets the OpexTotal field.
        /// </summary>
        /// <value>
        /// The opex total.
        /// </value>
        public decimal? OpexTotal { get; set; }
        /// <summary>
        /// Gets or sets the OpexBudget field.
        /// </summary>
        /// <value>
        /// The opex budget.
        /// </value>
        public decimal? OpexBudget { get; set; }
        /// <summary>
        /// Gets or sets the OpexVariance field.
        /// </summary>
        /// <value>
        /// The opex variance.
        /// </value>
        public decimal? OpexVariance { get; set; }
        /// <summary>
        /// Gets or sets the OpexMonth field.
        /// </summary>
        /// <value>
        /// The opex month.
        /// </value>
        public string OpexMonth { get; set; }
        /// <summary>
        /// Gets or sets the OpexRedThreshold field.
        /// </summary>
        /// <value>
        /// The opex red threshold.
        /// </value>
        public int? OpexRedThreshold { get; set; }
        /// <summary>
        /// Gets or sets the CriticalPms field.
        /// </summary>
        /// <value>
        /// The critical PMS.
        /// </value>
        public decimal? CriticalPms { get; set; }
        /// <summary>
        /// Gets or sets the CriticalPmsLm field.
        /// </summary>
        /// <value>
        /// The critical PMS lm.
        /// </value>
        public decimal? CriticalPmsLm { get; set; }
        /// <summary>
        /// Gets or sets the CriticalPmsLmPrior field.
        /// </summary>
        /// <value>
        /// The critical PMS lm prior.
        /// </value>
        public decimal? CriticalPmsLmPrior { get; set; }
        /// <summary>
        /// Gets or sets the FuelEfficiencyL3M field.
        /// </summary>
        /// <value>
        /// The fuel efficiency l3 m.
        /// </value>
        public decimal? FuelEfficiencyL3M { get; set; }
        /// <summary>
        /// Gets or sets the FuelEfficiencyPrior field.
        /// </summary>
        /// <value>
        /// The fuel efficiency prior.
        /// </value>
        public decimal? FuelEfficiencyPrior { get; set; }
        /// <summary>
        /// Gets or sets the EmissionsLm field.
        /// </summary>
        /// <value>
        /// The emissions lm.
        /// </value>
        public decimal? EmissionsLm { get; set; }
        /// <summary>
        /// Gets or sets the EmissionsPrior field.
        /// </summary>
        /// <value>
        /// The emissions prior.
        /// </value>
        public decimal? EmissionsPrior { get; set; }
        /// <summary>
        /// Gets or sets the EmissionsEfficiencyIndex field.
        /// </summary>
        /// <value>
        /// The index of the emissions efficiency.
        /// </value>
        public decimal? EmissionsEfficiencyIndex { get; set; }
        /// <summary>
        /// Gets or sets the EmissionsRag field.
        /// </summary>
        /// <value>
        /// The emissions rag.
        /// </value>
        public int? EmissionsRag { get; set; }
        /// <summary>
        /// Gets or sets the EmissionsR12M field.
        /// </summary>
        /// <value>
        /// The emissions R12 m.
        /// </value>
        public decimal? EmissionsR12M { get; set; }
        /// <summary>
        /// Gets or sets the SeriousIncidentsRed field.
        /// </summary>
        /// <value>
        /// The serious incidents rag.
        /// </value>
        public int SeriousIncidentsRag { get; set; }
        /// <summary>
        /// Gets or sets the PscDetentionsRag field.
        /// </summary>
        /// <value>
        /// The PSC detentions rag.
        /// </value>
        public int PscDetentionsRag { get; set; }
        /// <summary>
        /// Gets or sets the OffHireRag field.
        /// </summary>
        /// <value>
        /// The off hire rag.
        /// </value>
        public int OffHireRag { get; set; }
        /// <summary>
        /// Gets or sets the OmvRejectionsRag field.
        /// </summary>
        /// <value>
        /// The omv rejections rag.
        /// </value>
        public int OmvRejectionsRag { get; set; }
        /// <summary>
        /// Gets or sets the OverdueInspectionsRag field.
        /// </summary>
        /// <value>
        /// The overdue inspections rag.
        /// </value>
        public int OverdueInspectionsRag { get; set; }
        /// <summary>
        /// Gets or sets the TotalKpiredCount field.
        /// </summary>
        /// <value>
        /// The total kpired count.
        /// </value>
        public int? TotalKpiredCount { get; set; }
        /// <summary>
        /// Gets or sets the OfficeFleetSize field.
        /// </summary>
        /// <value>
        /// The size of the office fleet.
        /// </value>
        public int? OfficeFleetSize { get; set; }
        /// <summary>
        /// Gets or sets the TankersInFleet field.
        /// </summary>
        /// <value>
        /// The tankers in fleet.
        /// </value>
        public int? TankersInFleet { get; set; }
        /// <summary>
        /// Gets or sets the RsvesselsInFleet field.
        /// </summary>
        /// <value>
        /// The rsvessels in fleet.
        /// </value>
        public int? RsvesselsInFleet { get; set; }
        /// <summary>
        /// Gets or sets the PreviousScore field.
        /// </summary>
        /// <value>
        /// The previous score.
        /// </value>
        public decimal? PreviousScore { get; set; }
        /// <summary>
        /// Gets or sets the ScoreRatio field.
        /// </summary>
        /// <value>
        /// The score ratio.
        /// </value>
        public decimal? ScoreRatio { get; set; }
        /// <summary>
        /// Gets or sets the Trend field.
        /// </summary>
        /// <value>
        /// The trend.
        /// </value>
        public int Trend { get; set; }
        /// <summary>
        /// Gets or sets the Variance field.
        /// </summary>
        /// <value>
        /// The variance.
        /// </value>
        public decimal? Variance { get; set; }
        /// <summary>
        /// Gets or sets the AverageScore field.
        /// </summary>
        /// <value>
        /// The average score.
        /// </value>
        public double? AverageScore { get; set; }
        /// <summary>
        /// Gets or sets the AverageIndicator field.
        /// </summary>
        /// <value>
        /// The average indicator.
        /// </value>
        public int AverageIndicator { get; set; }
        /// <summary>
        /// Gets or sets the Ltmscore field.
        /// </summary>
        /// <value>
        /// The ltmscore.
        /// </value>
        public double? Ltmscore { get; set; }
        /// <summary>
        /// Gets or sets the NumAffectedKpi field.
        /// </summary>
        /// <value>
        /// The number affected kpi.
        /// </value>
        public int? NumAffectedKpi { get; set; }


        /// <summary>
        /// The is expanded
        /// </summary>
        private bool _isExpanded = false;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is expanded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is expanded; otherwise, <c>false</c>.
        /// </value>
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set { Set(() => IsExpanded, ref _isExpanded, value); }
        }


        /// <summary>
        /// Gets the score ratio display.
        /// </summary>
        /// <value>
        /// The score ratio display.
        /// </value>
        public decimal? ScoreRatioDisplay
        {
            get { return Math.Round(ScoreRatio.GetValueOrDefault(), 2); }
        }

        /// <summary>
        /// Gets or sets the omv inspections r6 m.
        /// </summary>
        /// <value>
        /// The omv inspections r6 m.
        /// </value>
        public decimal? OmvInspectionsR6M { get; set; }

        /// <summary>
        /// Gets or sets the exp hours r3 m.
        /// </summary>
        /// <value>
        /// The exp hours r3 m.
        /// </value>
        public decimal? ExpHoursR3M { get; set; }
        #endregion


        /*
        /// <summary>
        /// The office child items
        /// </summary>
        private List<FleetLevelDetails> _officeChildItems;

        /// <summary>
        /// Gets or sets the office child items.
        /// </summary>
        /// <value>
        /// The office child items.
        /// </value>
        public List<FleetLevelDetails> OfficeChildItems
        {
            get { return _officeChildItems; }
            set { Set(() => OfficeChildItems, ref _officeChildItems, value); }
        }

		*/

        #region Mine

        /// <summary>
        /// Gets or sets the monthly score previous.
        /// </summary>
        /// <value>
        /// The monthly score previous.
        /// </value>
        public double MonthlyScorePrev { get; set; }

        /// <summary>
        /// Gets or sets the total red kpi count previous.
        /// </summary>
        /// <value>
        /// The total red kpi count previous.
        /// </value>
        public decimal? TotalRedKpiCountPrev { get; set; }

        /// <summary>
        /// Gets or sets the variance calculate.
        /// </summary>
        /// <value>
        /// The variance calculate.
        /// </value>
        public double? VarianceCalc { get; set; }
        /// <summary>
        /// Gets or sets the size of the fleet.
        /// </summary>
        /// <value>
        /// The size of the fleet.
        /// </value>
        public int FleetSize { get; set; }
        //public double NumAffectedKpi { get; set; }
        /// <summary>
        /// Gets or sets the number affected kpi grpah.
        /// </summary>
        /// <value>
        /// The number affected kpi grpah.
        /// </value>
        public double NumAffectedKpiGrpah { get { return Convert.ToDouble(NumAffectedKpi.GetValueOrDefault()); } set { } }
        /// <summary>
        /// Gets or sets the LTM score.
        /// </summary>
        /// <value>
        /// The LTM score.
        /// </value>
        public double LTMScore { get; set; }
        /// <summary>
        /// Gets or sets the total red kpi count.
        /// </summary>
        /// <value>
        /// The total red kpi count.
        /// </value>
        public decimal? TotalRedKpiCount { get; set; }
        /// <summary>
        /// Gets or sets the monthly score.
        /// </summary>
        /// <value>
        /// The monthly score.
        /// </value>
        public decimal MonthlyScore { get; set; }
        /// <summary>
        /// Gets or sets the monthly score graph.
        /// </summary>
        /// <value>
        /// The monthly score graph.
        /// </value>
        public double MonthlyScoreGraph { get; set; }

        /// <summary>
        /// Gets or sets the manager.
        /// </summary>
        /// <value>
        /// The manager.
        /// </value>
        public string Manager { get; set; }

        /// <summary>
        /// Gets or sets the trend percent.
        /// </summary>
        /// <value>
        /// The trend percent.
        /// </value>
        public decimal TrendPercent
        {  get
            {
                decimal? val = CalculateVariance(ScoreRatio.GetValueOrDefault(), PreviousScore.GetValueOrDefault());
                return
                    PreviousScore.HasValue && PreviousScore.Value != 0 ? Math.Round(val.GetValueOrDefault()/ PreviousScore.GetValueOrDefault() * 100,0)
                    : Math.Round(val.GetValueOrDefault() *100);// return Math.Round(Variance.GetValueOrDefault() * 100); 
            }
        }

        /// <summary>
        /// Gets or sets the type of the trend.
        /// </summary>
        /// <value>
        /// The type of the trend.
        /// </value>
        public int TrendType { get; set; }

        /// <summary>
        /// Gets or sets the name of the manager.
        /// </summary>
        /// <value>
        /// The name of the manager.
        /// </value>
        public string ManagerName { get; set; }

        #endregion

        #region Tooltip fields

        //S n C
        /// <summary>
        /// Gets the serious incidents tool tip.
        /// </summary>
        /// <value>
        /// The serious incidents tool tip.
        /// </value>
        public string SeriousIncidentsToolTip
        {
            get
            {
                return SeriousIncidents + " Serious Incidents last month, \n" + SeriousIncidentsR3M + " Serious Incidents last 3 months";
            }
        }
        /// <summary>
        /// Gets the serious incidents trend.
        /// </summary>
        /// <value>
        /// The serious incidents trend.
        /// </value>
        public decimal? SeriousIncidentsTrend
        {
            get
            {
                return CalculateVariance(VimLm > 0 ? SeriousIncidents / VimLm : 0, VimPm > 0 ? SeriousIncidentsPrior / VimPm : 0);
            }
        }

        /// <summary>
        /// Gets the PSC detentions tool tip.
        /// </summary>
        /// <value>
        /// The PSC detentions tool tip.
        /// </value>
        public string PSCDetentionsToolTip
        {
            get
            {
                return PscDetentions + " Detentions last month \n" + PscDetentionsR3M + " Detentions last 3 months";
            }
        }
        /// <summary>
        /// Gets the PSC detentions trend.
        /// </summary>
        /// <value>
        /// The PSC detentions trend.
        /// </value>
        public decimal? PSCDetentionsTrend { get { return CalculateVariance(PscDetentions, PscDetentionsPrior); } }
        /// <summary>
        /// Gets the PSC deficiencies tool tip.
        /// </summary>
        /// <value>
        /// The PSC deficiencies tool tip.
        /// </value>
        public string PSCDeficienciesToolTip
        {
            get
            {
                return "PSC Deficiency Ratio L3M = " + PscDeficienciesRatioR3MFleet;
            }
        }
        /// <summary>
        /// Gets the PSC deficiencies trend.
        /// </summary>
        /// <value>
        /// The PSC deficiencies trend.
        /// </value>
        public decimal? PSCDeficienciesTrend { get { return CalculateVariance(PscDeficienciesRatioR3MFleet, PscDeficienciesRatioR3MFleetPrior); } }
        /// <summary>
        /// Gets the ltif tool tip.
        /// </summary>
        /// <value>
        /// The ltif tool tip.
        /// </value>
        public string LTIFToolTip
        {
            get
            {
                return "Fleet(Lost Time Injury Frequency) L3M = " + LtifRatioR3MFleet;
            }
        }
        /// <summary>
        /// Gets the ltif trend.
        /// </summary>
        /// <value>
        /// The ltif trend.
        /// </value>
        public decimal? LTIFTrend { get { return CalculateVariance(LtifRatioR3MFleet, LtifRatioR3MFleetPrior); } }


        //Commercial
        /// <summary>
        /// Gets the off hire days tool tip.
        /// </summary>
        /// <value>
        /// The off hire days tool tip.
        /// </value>
        public string OffHireDaysToolTip
        {
            get
            {
                return "OffHire Ratio to Vessels = " + (OfficeFleetSize.HasValue && OffHireDays.HasValue && OfficeFleetSize.Value > 0 ? OffHireDays / OfficeFleetSize : 0.00M).Value.ToString("0.##") + " hours";
            }
        }

        /// <summary>
        /// Gets the off hire days kpi.
        /// </summary>
        /// <value>
        /// The off hire days kpi.
        /// </value>
        public decimal? OffHireDaysKPI
        {
            get
            {
                return (OfficeFleetSize.HasValue && OffHireDays.HasValue && OfficeFleetSize.Value > 0 ? OffHireDays / OfficeFleetSize : 0.00M);
            }
        }

        /// <summary>
        /// Gets the off hire days trend.
        /// </summary>
        /// <value>
        /// The off hire days trend.
        /// </value>
        public decimal? OffHireDaysTrend { get { return CalculateVariance(VimLm.GetValueOrDefault() > 0 ? OffHireDays / VimLm : 0, VimPm.GetValueOrDefault() > 0 ? OffHireDaysPrior / VimPm : 0); } }

        //Rightship missing

        /// <summary>
        /// Gets or sets the right ship tool tip.
        /// </summary>
        /// <value>
        /// The right ship tool tip.
        /// </value>
        public string RightShipToolTip { get { return "Average RightShip = " + RightShip; } } //pending

        /// <summary>
        /// Gets the right ship trend.
        /// </summary>
        /// <value>
        /// The right ship trend.
        /// </value>
        public decimal? RightShipTrend { get { return CalculateVariance(VimCargoLm.GetValueOrDefault() > 0 ? RightShipR3M / VimCargoLm : 0, VimCargoPm.GetValueOrDefault() > 0 ? RightShipR3M / VimCargoPm : 0); } }
        /// <summary>
        /// Gets the omv findings tool tip.
        /// </summary>
        /// <value>
        /// The omv findings tool tip.
        /// </value>
        public string OmvFindingsToolTip
        {
            get
            {
                return "OM Findings ratio L6M = " + OmvFindingsRatioR6MFleet;
            }
        }
        /// <summary>
        /// Gets the omv findings trend.
        /// </summary>
        /// <value>
        /// The omv findings trend.
        /// </value>
        public decimal? OmvFindingsTrend { get { return CalculateVariance(OmvFindingsRatioR6MFleet, OmvFindingsRatioR6MFleetPrior); } }
        /// <summary>
        /// Gets the omv rejections tool tip.
        /// </summary>
        /// <value>
        /// The omv rejections tool tip.
        /// </value>
        public string OmvRejectionsToolTip
        {
            get
            {
                return "OM Rejections LM = " + OmvRejections
                    + "\nOM Rejections L3M = " + OmvRejectionsR3M
                + "\n OM Rejections L6M = " + OmvRejectionsR6M;
            }
        }
        /// <summary>
        /// Gets the omv rejections trend.
        /// </summary>
        /// <value>
        /// The omv rejections trend.
        /// </value>
        public decimal? OmvRejectionsTrend { get { return CalculateVariance(OmvRejections, OmvRejectionsPrior); } }

        //Technical
        /// <summary>
        /// Gets or sets the opex tool tip.
        /// </summary>
        /// <value>
        /// The opex tool tip.
        /// </value>
        public string OpexToolTip
        {
            get

            {
                return "Opex budget = " + Math.Round(OpexBudget.GetValueOrDefault(), 2);// "Opex = " + OpexRAG;
            }
        }

        /// <summary>
        /// Gets the opex trend.
        /// </summary>
        /// <value>
        /// The opex trend.
        /// </value>
        public decimal? OpexTrend { get { return CalculateVariance(Opex, OpexPrior); } }

        /// <summary>
        /// Gets the overdue technical inspection tool tip.
        /// </summary>
        /// <value>
        /// The overdue technical inspection tool tip.
        /// </value>
        public string OverdueTechnicalInspectionToolTip
        {
            get
            {
                return OverdueTechnicalInspection05 + " Vessels last Insp between 0 - 5 months,\n"
                   + OverdueTechnicalInspection56 + " Vessels last Insp between 5 - 6 months,\n"
                + OverdueTechnicalInspection6Plus + " Vessels last Insp over 6 months";
            }
        }

        /// <summary>
        /// Gets the overdue technical inspection trend.
        /// </summary>
        /// <value>
        /// The overdue technical inspection trend.
        /// </value>
        public decimal? OverdueTechnicalInspectionTrend { get { return CalculateVariance(OverdueTechnicalInspection6Plus, OverdueTechnicalInspection6PlusPrior); } }

        /// <summary>
        /// Gets or sets the budget.
        /// </summary>
        /// <value>
        /// The budget.
        /// </value>
        public string OverUnderBudget { get { return OpexVariance.HasValue && OpexVariance < 0 ? "over Budget" : "under Budget"; } }

        /// <summary>
        /// Gets the over under worstvessel opex.
        /// </summary>
        /// <value>
        /// The over under worstvessel opex.
        /// </value>
        public string OverUnderWorstvesselOpex { get { return OpexWv.HasValue && OpexWv < 0 ? "over Budget" : "under Budget"; } }
        //Crew

        /// <summary>
        /// Gets or sets the crew retention tool tip.
        /// </summary>
        /// <value>
        /// The crew retention tool tip.
        /// </value>
        public string CrewRetentionToolTip { get { return "Crew retention =" + CrewRetention + "%"; } }
        /// <summary>
        /// Gets the crew retention trend.
        /// </summary>
        /// <value>
        /// The crew retention trend.
        /// </value>
        public decimal? CrewRetentionTrend { get { return CalculateVariance(CrewRetentionR3M, CrewRetentionR3MPrior); } }
        /// <summary>
        /// Gets the crew overdue tool tip.
        /// </summary>
        /// <value>
        /// The crew overdue tool tip.
        /// </value>
        public string CrewOverdueToolTip
        {
            get
            {
                return ((!CrewOnboard.HasValue) || (CrewOnboard.HasValue && CrewOnboard.Value == 0)) ?  string.Format("Crew Overdue Eoc +30Days = 0%") : 
                            string.Format("Crew Overdue Eoc +30Days = {0}%", Math.Round(Convert.ToDecimal(CrewOverdueReliefs30Plus/ CrewOnboard *100),2));
            }
        }
        /// <summary>
        /// Gets the crew overdue trend.
        /// </summary>
        /// <value>
        /// The crew overdue trend.
        /// </value>
        public decimal? CrewOverdueTrend
        {
            get
            {
                var crewOnboardResult = ((!CrewOnboard.HasValue) || (CrewOnboard.HasValue && CrewOnboard.Value == 0)) ? CrewOverdueReliefs30Plus / 1 : CrewOverdueReliefs30Plus / CrewOnboard;
                var crewOnboardPriorResult = ((!CrewOnboardL3MPrior.HasValue) || (CrewOnboardL3MPrior.HasValue && CrewOnboardL3MPrior.Value == 0)) ? Convert.ToDecimal(CrewOverdueReliefs30PlusL3MPrior) / 1 : Convert.ToDecimal(CrewOverdueReliefs30PlusL3MPrior) / CrewOnboardL3MPrior;

                return crewOnboardResult - crewOnboardPriorResult > 0 ? 1 : crewOnboardResult - crewOnboardPriorResult == 0 ? 0 : -1;
            }
        }


        // H nWB

        /// <summary>
        /// Gets the medical illness tool tip.
        /// </summary>
        /// <value>
        /// The medical illness tool tip.
        /// </value>
        public string MedicalIllnessToolTip
        {
            get
            {
                return "Medical Illness Rate L3M = " + MedicalIllnessRateR3MFleet;
            }
        }

        /// <summary>
        /// Gets the medical illness trend.
        /// </summary>
        /// <value>
        /// The medical illness trend.
        /// </value>
        public decimal? MedicalIllnessTrend
        {
            get
            {
                return MedicalIllnessRateR3MFleet < MedicalIllnessRateR3MFleetPrior ? -1 :
                        MedicalIllnessRateR3MFleet == MedicalIllnessRateR3MFleetPrior.GetValueOrDefault() ? 0 : 1;
            }
        }

        //Environment

        /// <summary>
        /// Gets the emissions tool tip.
        /// </summary>
        /// <value>
        /// The emissions tool tip.
        /// </value>
        public string EmissionsToolTip
        {
            get
            {
                return string.Format("CO2 Emissions last  month versus 12 month average ={0}%", EmissionsEfficiencyIndex);// + EmissionsR12M; // Missing
            }
        }
        /// <summary>
        /// Gets the emissions trend.
        /// </summary>
        /// <value>
        /// The emissions trend.
        /// </value>
        public decimal? EmissionsTrend { get { return CalculateVariance(EmissionsLm, EmissionsPrior); } }

        //Asset
        /// <summary>
        /// Gets the critical PMS tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS tool tip.
        /// </value>
        public string CriticalPmsToolTip
        {
            get
            {
                return "Critical PMS last month = " + CriticalPmsLm + "%";
            }
        }
        /// <summary>
        /// Gets the critical PMS trend.
        /// </summary>
        /// <value>
        /// The critical PMS trend.
        /// </value>
        public decimal? CriticalPmsTrend
        {
            get
            {
                return CriticalPmsLm == CriticalPmsLmPrior.GetValueOrDefault() ? 0 :
                    CriticalPmsLm < CriticalPmsLmPrior ? -1 : 1;
            }
        }

        /// <summary>
        /// Gets the fuel efficiency tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency tool tip.
        /// </value>
        public string FuelEfficiencyToolTip
        {
            get
            {
                return "Fuel Efficiency L3M = " + FuelEfficiencyL3M + "%";
            }
        }

        /// <summary>
        /// Gets the fuel efficiency trend.
        /// </summary>
        /// <value>
        /// The fuel efficiency trend.
        /// </value>
        public decimal? FuelEfficiencyTrend { get { return CalculateVariance(FuelEfficiencyL3M, FuelEfficiencyPrior); } }

        #endregion

        #region TooltipForValue Fields

        /// <summary>
        /// Gets the pscdetentions red tooltip.
        /// </summary>
        /// <value>
        /// The pscdetentions red tooltip.
        /// </value>
        public string PscdetentionsRedTooltip
        {
            get { return PscdetentionsRed.HasValue ? PscdetentionsRed > 1 ? string.Format("{0} vessels with Red KPI", PscdetentionsRed) : string.Format("{0} vessel with Red KPI", PscdetentionsRed) : null; }
        }

        /// <summary>
        /// Gets the pscdeficiencies red tooltip.
        /// </summary>
        /// <value>
        /// The pscdeficiencies red tooltip.
        /// </value>
        public string PscdeficienciesRedTooltip
        {
            get { return PscdeficienciesRed.HasValue ? PscdeficienciesRed > 1 ? string.Format("{0} vessels with Red KPI", PscdeficienciesRed) : string.Format("{0} vessel with Red KPI", PscdeficienciesRed) : null; }
        }

        /// <summary>
        /// Gets the ltifrag tooltip.
        /// </summary>
        /// <value>
        /// The ltifrag tooltip.
        /// </value>
        public string LTIFRedTooltip
        {
            get { return Ltifred.HasValue ? Ltifred > 1 ? string.Format("{0} vessels with Red KPI", Ltifred) : string.Format("{0} vessel with Red KPI", Ltifred) : null; }
        }

        /// <summary>
        /// Gets the offhire red tooltip.
        /// </summary>
        /// <value>
        /// The offhire red tooltip.
        /// </value>
        public string OffhireRedTooltip
        {
            get { return OffhireRed.HasValue ? OffhireRed > 1 ? string.Format("{0} vessels with Red KPI", OffhireRed) : string.Format("{0} vessel with Red KPI", OffhireRed) : null; }
        }

        /// <summary>
        /// Gets the right ship red tooltip.
        /// </summary>
        /// <value>
        /// The right ship red tooltip.
        /// </value>
        public string RightShipRedTooltip
        {
            get { return RightShipRed.HasValue ? RightShipRed > 1 ? string.Format("{0} vessels with Red KPI", RightShipRed) : string.Format("{0} vessel with Red KPI", RightShipRed) : null; }
        }

        /// <summary>
        /// Gets the omvfindings red tooltip.
        /// </summary>
        /// <value>
        /// The omvfindings red tooltip.
        /// </value>
        public string OmvfindingsRedTooltip
        {
            get { return OmvfindingsRed.HasValue ? OmvfindingsRed > 1 ? string.Format("{0} vessels with Red KPI", OmvfindingsRed) : string.Format("{0} vessel with Red KPI", OmvfindingsRed) : null; }
        }
        /// <summary>
        /// Gets the omvrejections red tooltip.
        /// </summary>
        /// <value>
        /// The omvrejections red tooltip.
        /// </value>
        public string OmvrejectionsRedTooltip
        {
            get { return OmvrejectionsRed.HasValue ? OmvrejectionsRed > 1 ? string.Format("{0} vessels with Red KPI", OmvrejectionsRed) : string.Format("{0} vessel with Red KPI", OmvrejectionsRed) : null; }
        }

        /// <summary>
        /// Gets the opex red tooltip.
        /// </summary>
        /// <value>
        /// The opex red tooltip.
        /// </value>
        public string OpexRedTooltip
        {
            get { return OpexRed.HasValue ? OpexRed > 1 ? string.Format("{0} vessels with Red KPI", OpexRed) : string.Format("{0} vessel with Red KPI", OpexRed) : null; }
        }

        /// <summary>
        /// Gets the overdue technical inspections red tooltip.
        /// </summary>
        /// <value>
        /// The overdue technical inspections red tooltip.
        /// </value>
        public string OverdueTechnicalInspectionsRedTooltip
        {
            get { return OverdueTechnicalInspectionsRed.HasValue ? OverdueTechnicalInspectionsRed > 1 ? string.Format("{0} vessels with Red KPI", OverdueTechnicalInspectionsRed) : string.Format("{0} vessel with Red KPI", OverdueTechnicalInspectionsRed) : null; }
        }
        /// <summary>
        /// Gets the crew overdue reliefs red tooltip.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs red tooltip.
        /// </value>
        public string CrewOverdueReliefsRedTooltip
        {
            get { return CrewOverdueReliefsRed.HasValue ? CrewOverdueReliefsRed > 1 ? string.Format("{0} vessels with Red KPI", CrewOverdueReliefsRed) : string.Format("{0} vessel with Red KPI", CrewOverdueReliefsRed) : null; }
        }
        #endregion


        #region Trend Tool Tip Fields

        public string SeriousIncidentsTrendToolTip { get { return GetCombinedTrendToolTip("(Serious Incidents Ratio)", SeriousIncidentsTrend); } }

        public string PSCDetentionsTrendToolTip { get { return GetCombinedTrendToolTip("(PSC Detentions)", PSCDetentionsTrend); } }
        public string PSCDeficienciesTrendToolTip { get { return GetCombinedTrendToolTip("(PSC Deficiency Ratio L3M)", PSCDeficienciesTrend); } }

        public string LTIFTrendToolTip { get { return GetCombinedTrendToolTip("(Lost Time Injuriy Frequency L3M)", LTIFTrend); } }

        //Commercial

        public string OffHireDaysTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("(Offire Ratio to Vessels)", OffHireDaysTrend);
            }
        }

        /// <summary>
        /// Gets or sets the right ship tool tip.
        /// </summary>
        /// <value>
        /// The right ship tool tip.
        /// </value>
        public string RightShipTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("Right Ship", RightShipTrend, false);
            }
        }

        /// <summary>
        /// Gets the omv findings tool tip.
        /// </summary>
        /// <value>
        /// The omv findings tool tip.
        /// </value>
        public string OmvFindingsTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("OM Findings ratio L6M", OmvFindingsTrend, false);
            }
        }

        /// <summary>
        /// Gets the omv rejections tool tip.
        /// </summary>
        /// <value>
        /// The omv rejections tool tip.
        /// </value>
        public string OmvRejectionsTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("(OM Rejections LM)", OmvRejectionsTrend);
            }
        }



        //Technical
        /// <summary>
        /// Gets or sets the opex tool tip.
        /// </summary>
        /// <value>
        /// The opex tool tip.
        /// </value>
        public string OpexTrendToolTip
        {
            get
            {
                return string.Format(GetCombinedTrendToolTip("OPEX%", OpexTrend, true)+ "%");
            }
        }


        /// <summary>
        /// Gets the overdue technical inspection tool tip.
        /// </summary>
        /// <value>
        /// The overdue technical inspection tool tip.
        /// </value>
        public string OverdueTechnicalInspectionTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("(Overdue 6Mth + Tech Inspection)", OverdueTechnicalInspectionTrend);
            }
        }

        //Crew

        /// <summary>
        /// Gets or sets the crew retention tool tip.
        /// </summary>
        /// <value>
        /// The crew retention tool tip.
        /// </value>
        public string CrewRetentionTrendToolTip
        {
            get
            {
                return string.Format(GetCombinedTrendToolTip(" (Crew Senior Officer Retention) ", CrewRetentionTrend, true)+"%");
            }
        }

        /// <summary>
        /// Gets the crew overdue tool tip.
        /// </summary>
        /// <value>
        /// The crew overdue tool tip.
        /// </value>
        public string CrewOverdueTrendToolTip
        {
            get
            {
                // return GetCombinedTrendToolTip(" (Crew Overdue EOC +30 days) Trend", CalculateVariance(CrewOnboardPrior, CrewOnboardL3MPrior), true);
                return GetCombinedTrendToolTip("Crew Overdue EOC +30 days", CalculateVariance(Convert.ToDecimal(CrewOverdueReliefs30PlusL3M), Convert.ToDecimal(CrewOverdueReliefs30PlusL3MPrior)), false);
            }
        }

        // H nWB

        /// <summary>
        /// Gets the medical illness tool tip.
        /// </summary>
        /// <value>
        /// The medical illness tool tip.
        /// </value>
        public string MedicalIllnessTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("Medical Illness Rate", CalculateVariance(MedicalIllnessRateR3MFleet, MedicalIllnessRateR3MFleetPrior), false);
            }
        }

        //Environment

        /// <summary>
        /// Gets the emissions tool tip.
        /// </summary>
        /// <value>
        /// The emissions tool tip.
        /// </value>
        public string EmissionsTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("CO2 Emissions", EmissionsTrend, false);
            }
        }

        //Asset
        /// <summary>
        /// Gets the critical PMS tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS tool tip.
        /// </value>
        public string CriticalPmsTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("Critical PMS", CalculateVariance(CriticalPmsLm, CriticalPmsLmPrior), false) + "%";
            }
        }

        /// <summary>
        /// Gets the fuel efficiency tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency tool tip.
        /// </value>
        public string FuelEfficiencyTrendToolTip
        {
            get
            {
                return GetCombinedTrendToolTip("Fuel Efficiency", FuelEfficiencyTrend, false) + "%";
            }
        }

        /// <summary>
        /// Gets the trend percent tooltip.
        /// </summary>
        /// <value>
        /// The trend percent tooltip.
        /// </value>
        public string TrendPercentTooltip
        {
            get
            {
                return string.Format("This month's score (TM) ={0} Last Months score (LM) = {1}.Difference is calculated as (TM-LM)/LM", Math.Round(ScoreRatio.GetValueOrDefault(), 2), Math.Round(PreviousScore.GetValueOrDefault(), 2));
            }
        }
        #endregion

        #region Rag Variables

        /// <summary>
        /// Gets the PSC deficiencies rag.
        /// </summary>
        /// <value>
        /// The PSC deficiencies rag.
        /// </value>
        public decimal? PSCDeficienciesRAG { get { return PscDeficienciesRatioR3MFleet; } }
        /// <summary>
        /// Gets the ltifrag.
        /// </summary>
        /// <value>
        /// The ltifrag.
        /// </value>
        public decimal? LTIFRAG { get { return LtifRatioR3MFleet; } }
        /// <summary>
        /// Gets the right ship rag.
        /// </summary>
        /// <value>
        /// The right ship rag.
        /// </value>
        public decimal? RightShipRAG { get { return RightShip; } }
        /// <summary>
        /// Gets the omv findings rag.
        /// </summary>
        /// <value>
        /// The omv findings rag.
        /// </value>
        public decimal? OmvFindingsRAG { get { return OmvFindingsRatioR6MFleet; } }
        /// <summary>
        /// Gets the opex rag.
        /// </summary>
        /// <value>
        /// The opex rag.
        /// </value>
        public decimal? OpexRAG { get { return (OpexBudget.GetValueOrDefault() > 0 ? OpexVariance / OpexBudget : 0) * 100; } }
        //overdue technical missing
        /// <summary>
        /// Gets the crew retention rag.
        /// </summary>
        /// <value>
        /// The crew retention rag.
        /// </value>
        public decimal? CrewRetentionRAG { get { return CrewRetention; } }

        /// <summary>
        /// Gets the crew overdue rag.
        /// </summary>
        /// <value>
        /// The crew overdue rag.
        /// </value>
        public decimal? CrewOverdueRAG { get { return CrewOverdueReliefs30Plus / CrewOnboard; } }
        /// <summary>
        /// Gets the medical illness rag.
        /// </summary>
        /// <value>
        /// The medical illness rag.
        /// </value>
        public decimal? MedicalIllnessRAG { get { return MedicalIllnessRateR3MFleet; } }
        /// <summary>
        /// Gets the critical PMS rag.
        /// </summary>
        /// <value>
        /// The critical PMS rag.
        /// </value>
        public decimal? CriticalPmsRAG { get { return CriticalPmsLm; } }
        /// <summary>
        /// Gets the fuel efficiency rag.
        /// </summary>
        /// <value>
        /// The fuel efficiency rag.
        /// </value>
        public decimal? FuelEfficiencyRAG { get { return FuelEfficiencyL3M; } }



        #endregion

        #region Methods

        /// <summary>
        /// Calculates the variance.
        /// </summary>
        /// <param name="currentValue">The current value.</param>
        /// <param name="previousValue">The previous value.</param>
        /// <returns></returns>
        private decimal? CalculateVariance(decimal? currentValue, decimal? previousValue)
        {
            //to be confirmed
            decimal? ret = currentValue - previousValue.GetValueOrDefault();
            return ret;
        }

        private string GetCombinedTrendToolTip(string Text, decimal? value, bool isUsePrefix = true)
        {
            value = Math.Round(value.GetValueOrDefault(), 2);
            string prefix = "Fleet ";
            if (isUsePrefix)
            {
                return prefix + Text + " Trend = " + value;
            }
            return Text + " Trend = " + value;

        }

        #endregion


        #region Footer Level Properties
        /// <summary>Gets or sets the VgroupSeriousIncidentsLastMonthTotal field.</summary>
        public int? VgroupSeriousIncidentsLastMonthTotal { get; set; }
        /// <summary>Gets or sets the VgroupSeriousIncidentsLast3MonthsTotal field.</summary>
        public int? VgroupSeriousIncidentsLast3MonthsTotal { get; set; }
        /// <summary>Gets or sets the VgroupSeriousIncidentsTrend field.</summary>
        public decimal? VgroupSeriousIncidentsTrend { get; set; }
        /// <summary>Gets or sets the VgroupSeriousIncidentsTrendPrior field.</summary>
        public decimal? VgroupSeriousIncidentsTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupSeriousIncidentsRedTotal field.</summary>
        public int? VgroupSeriousIncidentsRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupPscDetentionsLastMonthTotal field.</summary>
        public int? VgroupPscDetentionsLastMonthTotal { get; set; }
        /// <summary>Gets or sets the VgroupPscDetentionsLast3MonthsTotal field.</summary>
        public int? VgroupPscDetentionsLast3MonthsTotal { get; set; }
        /// <summary>Gets or sets the VgroupPscDetentionsTrend field.</summary>
        public decimal? VgroupPscDetentionsTrend { get; set; }
        /// <summary>Gets or sets the VgroupPscDetentionsTrendPrior field.</summary>
        public decimal? VgroupPscDetentionsTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupPscDetentionsRedTotal field.</summary>
        public int? VgroupPscDetentionsRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupPscDeficienciesAverage field.</summary>
        public decimal? VgroupPscDeficienciesAverage { get; set; }
        /// <summary>Gets or sets the VgroupPscDeficienciesTrend field.</summary>
        public decimal? VgroupPscDeficienciesTrend { get; set; }
        /// <summary>Gets or sets the VgroupPscDeficienciesTrendPrior field.</summary>
        public decimal? VgroupPscDeficienciesTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupPscDeficienciesRedTotal field.</summary>
        public int? VgroupPscDeficienciesRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupLtifAverage field.</summary>
        public decimal? VgroupLtifAverage { get; set; }
        /// <summary>Gets or sets the VgroupLtifTrend field.</summary>
        public decimal? VgroupLtifTrend { get; set; }
        /// <summary>Gets or sets the VgroupLtifTrendPrior field.</summary>
        public decimal? VgroupLtifTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupLtifRedTotal field.</summary>
        public int? VgroupLtifRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupOffHireAverage field.</summary>
        public decimal? VgroupOffHireAverage { get; set; }
        /// <summary>Gets or sets the VgroupOffHireTrend field.</summary>
        public decimal? VgroupOffHireTrend { get; set; }
        /// <summary>Gets or sets the VgroupOffHireTrendPrior field.</summary>
        public decimal? VgroupOffHireTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOffHireRedTotal field.</summary>
        public int? VgroupOffHireRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupRightShipAverage field.</summary>
        public decimal? VgroupRightShipAverage { get; set; }
        /// <summary>Gets or sets the VgroupRightShipTrend field.</summary>
        public decimal? VgroupRightShipTrend { get; set; }
        /// <summary>Gets or sets the VgroupRightShipTrendPrior field.</summary>
        public decimal? VgroupRightShipTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupRightShipRedTotal field.</summary>
        public int? VgroupRightShipRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupOmFindingsAverage field.</summary>
        public decimal? VgroupOmFindingsAverage { get; set; }
        /// <summary>Gets or sets the VgroupOmFindingsTrend field.</summary>
        public decimal? VgroupOmFindingsTrend { get; set; }
        /// <summary>Gets or sets the VgroupOmFindingsTrendPrior field.</summary>
        public decimal? VgroupOmFindingsTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOmFindingsRedTotal field.</summary>
        public int? VgroupOmFindingsRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupOmRejectionsLastMonthTotal field.</summary>
        public int? VgroupOmRejectionsLastMonthTotal { get; set; }
        /// <summary>Gets or sets the VgroupOmRejectionsLast3MonthsTotal field.</summary>
        public int? VgroupOmRejectionsLast3MonthsTotal { get; set; }
        /// <summary>Gets or sets the VgroupOmRejectionsLast6MonthsTotal field.</summary>
        public int? VgroupOmRejectionsLast6MonthsTotal { get; set; }

        /// <summary>Gets or sets the VgroupOmRejectionsTrend field.</summary>
        public decimal? VgroupOmRejectionsTrend { get; set; }
        /// <summary>Gets or sets the VgroupOmRejectionsTrendPrior field.</summary>
        public decimal? VgroupOmRejectionsTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOmRejectionsRedTotal field.</summary>
        public int? VgroupOmRejectionsRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupOpexActualTotal field.</summary>
        public decimal? VgroupOpexActualTotal { get; set; }
        /// <summary>Gets or sets the VgroupOpexBudgetTotal field.</summary>
        public decimal? VgroupOpexBudgetTotal { get; set; }
        /// <summary>Gets or sets the VgroupOpexVarianceTotal field.</summary>
        public decimal? VgroupOpexVarianceTotal { get; set; }
        /// <summary>Gets or sets the VgroupOpexOfficeAverage field.</summary>
        public decimal? VgroupOpexOfficeAverage { get; set; }
        /// <summary>Gets or sets the VgroupOpexWorstVesselOpenAverage field.</summary>
        public decimal? VgroupOpexWorstVesselOpenAverage { get; set; }
        /// <summary>Gets or sets the VgroupOpexAverage field.</summary>
        public decimal? VgroupOpexAverage { get; set; }
        /// <summary>Gets or sets the VgroupOpexTrend field.</summary>
        public decimal? VgroupOpexTrend { get; set; }
        /// <summary>Gets or sets the VgroupOpexTrendPrior field.</summary>
        public decimal? VgroupOpexTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOpexRedTotal field.</summary>
        public int? VgroupOpexRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspection04Total field.</summary>
        public int? VgroupOverdueInspection04Total { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspection46Total field.</summary>
        public int? VgroupOverdueInspection46Total { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspection05Total field.</summary>
        public int? VgroupOverdueInspection05Total { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspection56Total field.</summary>
        public int? VgroupOverdueInspection56Total { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspection6PlusTotal field.</summary>
        public int? VgroupOverdueInspection6PlusTotal { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspectionTrend field.</summary>
        public decimal? VgroupOverdueInspectionTrend { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspectionTrendPrior field.</summary>
        public decimal? VgroupOverdueInspectionTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOverdueInspectionRedTotal field.</summary>
        public int? VgroupOverdueInspectionRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupRetentionAverage field.</summary>
        public decimal? VgroupRetentionAverage { get; set; }
        /// <summary>Gets or sets the VgroupRetentionTrend field.</summary>
        public decimal? VgroupRetentionTrend { get; set; }
        /// <summary>Gets or sets the VgroupRetentionTrendPrior field.</summary>
        public decimal? VgroupRetentionTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOverdueReliefsAverage field.</summary>
        public decimal? VgroupOverdueReliefsAverage { get; set; }
        /// <summary>Gets or sets the VgroupOverdueReliefsTrend field.</summary>
        public decimal? VgroupOverdueReliefsTrend { get; set; }
        /// <summary>Gets or sets the VgroupOverdueReliefsTrendPrior field.</summary>
        public decimal? VgroupOverdueReliefsTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupOverdueReliefsRedTotal field.</summary>
        public int? VgroupOverdueReliefsRedTotal { get; set; }
        /// <summary>Gets or sets the VgroupMedicalIllnessRateAverage field.</summary>
        public decimal? VgroupMedicalIllnessRateAverage { get; set; }
        /// <summary>Gets or sets the VgroupMedicalIllnessRateTrend field.</summary>
        public decimal? VgroupMedicalIllnessRateTrend { get; set; }
        /// <summary>Gets or sets the VgroupMedicalIllnessRateTrendPrior field.</summary>
        public decimal? VgroupMedicalIllnessRateTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupCriticalPmsAverage field.</summary>
        public decimal? VgroupCriticalPmsAverage { get; set; }
        /// <summary>Gets or sets the VgroupCriticalPmsTrend field.</summary>
        public decimal? VgroupCriticalPmsTrend { get; set; }
        /// <summary>Gets or sets the VgroupCriticalPmsTrendPrior field.</summary>
        public decimal? VgroupCriticalPmsTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupFuelEfficiencyAverage field.</summary>
        public decimal? VgroupFuelEfficiencyAverage { get; set; }
        /// <summary>Gets or sets the VgroupFuelEfficiencyTrend field.</summary>
        public decimal? VgroupFuelEfficiencyTrend { get; set; }
        /// <summary>Gets or sets the VgroupFuelEfficiencyTrendPrior field.</summary>
        public decimal? VgroupFuelEfficiencyTrendPrior { get; set; }
        /// <summary>Gets or sets the VgroupEmissionsAverage field.</summary>
        public decimal? VgroupEmissionsAverage { get; set; }
        /// <summary>Gets or sets the VgroupEmissionsRag field.</summary>
        public int? VgroupEmissionsRag { get; set; }
        /// <summary>Gets or sets the VgroupEmissionsTrend field.</summary>
        public decimal? VgroupEmissionsTrend { get; set; }
        /// <summary>Gets or sets the VgroupEmissionsTrendPrior field.</summary>
        public decimal? VgroupEmissionsTrendPrior { get; set; }
        /// <summary>
        /// Gets or sets the vgroup serious incidents rag.
        /// </summary>
        /// <value>
        /// The vgroup serious incidents rag.
        /// </value>
        public int VgroupSeriousIncidentsRAG { get; set; }
        /// <summary>
        /// Gets or sets the vgroup PSC detentions rag.
        /// </summary>
        /// <value>
        /// The vgroup PSC detentions rag.
        /// </value>
        public int VgroupPSCDetentionsRAG { get; set; }
        /// <summary>
        /// Gets or sets the vgroup om rejections rag.
        /// </summary>
        /// <value>
        /// The vgroup om rejections rag.
        /// </value>
        public int VgroupOMRejectionsRAG { get; set; }
        /// <summary>
        /// Gets or sets the vgroup overdue inspection rag.
        /// </summary>
        /// <value>
        /// The vgroup overdue inspection rag.
        /// </value>
        public int VgroupOverdueInspectionRAG { get; set; }
        #endregion

    }
}
