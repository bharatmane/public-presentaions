﻿namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// A class for representing the operational expenditure details.
    /// </summary>
    public class OperationalExpenditureDetails
    {
        #region Properties

        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        public string OfficeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        public string OfficeName { get; set; }

        /// <summary>
        /// Gets or sets the fleet cell identifier.
        /// </summary>
        /// <value>
        /// The fleet cell identifier.
        /// </value>
        public string FleetCellId { get; set; }

        /// <summary>
        /// Gets or sets the fleet cell desc.
        /// </summary>
        /// <value>
        /// The fleet cell desc.
        /// </value>
        public string FleetCellDesc { get; set; }

        /// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets the name of the client.
        /// </summary>
        /// <value>
        /// The name of the client.
        /// </value>
        public string ClientName { get; set; }

        /// <summary>
        /// Gets or sets the current budget.
        /// </summary>
        /// <value>
        /// The current budget.
        /// </value>
        public decimal CurrentBudget { get; set; }

        /// <summary>
        /// Gets or sets the current spending.
        /// </summary>
        /// <value>
        /// The current spending.
        /// </value>
        public decimal CurrentSpending { get; set; }

        /// <summary>
        /// Gets or sets the variance.
        /// </summary>
        /// <value>
        /// The variance.
        /// </value>
        public decimal Variance { get; set; }

        #endregion
    }
}
