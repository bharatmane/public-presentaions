﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This class is GhgRatingReportDetails.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class GhgRatingReportDetails : BaseViewModel
    {
        #region API Properties
        /// <summary>
        /// Gets or sets the ghgrating.
        /// </summary>
        /// <value>
        /// The ghgrating.
        /// </value>
        public string Ghgrating { get; set; }

        /// <summary>
        /// Gets or sets the vessel count.
        /// </summary>
        /// <value>
        /// The vessel count.
        /// </value>
        public int? VesselCount { get; set; }

        /// <summary>
        /// Gets or sets the vessel count percentage.
        /// </summary>
        /// <value>
        /// The vessel count percentage.
        /// </value>
        public decimal? VesselCountPercentage { get; set; }

        /// <summary>
        /// Gets or sets the sort order.
        /// </summary>
        /// <value>
        /// The sort order.
        /// </value>
        public int? SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the color code.
        /// </summary>
        /// <value>
        /// The color code.
        /// </value>
        public string ColorCode { get; set; }

        /// <summary>
        /// Gets or sets the ghgrating value.
        /// </summary>
        /// <value>
        /// The ghgrating value.
        /// </value>
        public string GhgratingValue { get; set; }

        #endregion
    }
}
