﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This is an output class for fleet performance vessel details.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class VesselDetailMatrix : BaseViewModel
    {
        #region Api Properties
        /// <summary>Gets or sets the VesselId field.</summary>
        public string VesselId { get; set; }
        /// <summary>Gets or sets the Vessel field.</summary>
        public string Vessel { get; set; }
        /// <summary>Gets or sets the VesTypeChild field.</summary>
        public string VesTypeChild { get; set; }
        /// <summary>Gets or sets the GrossTonnage field.</summary>
        public int? GrossTonnage { get; set; }
        /// <summary>Gets or sets the VesAge field.</summary>
        public int? VesAge { get; set; }
        /// <summary>Gets or sets the SeriousIncidents field.</summary>
        public int? SeriousIncidents { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsR3M field.</summary>
        public int? SeriousIncidentsR3M { get; set; }
        /// <summary>Gets or sets the SeriousincidentRag field.</summary>
        public int? SeriousincidentRag { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsRag field.</summary>
		public int? SeriousIncidentsRag { get; set; }
        /// <summary>Gets or sets the PscDetentions field.</summary>
        public int? PscDetentions { get; set; }
        /// <summary>Gets or sets the PscDetentionsR3M field.</summary>
        public int? PscDetentionsR3M { get; set; }
        /// <summary>Gets or sets the PscDetentionsRag field.</summary>
        public int? PscDetentionsRag { get; set; }
        /// <summary>Gets or sets the PscDeficienciesRatioR3M field.</summary>
        public decimal? PscDeficienciesRatioR3M { get; set; }
        /// <summary>Gets or sets the PscDeficiencies field.</summary>
        public decimal? PscDeficiencies { get; set; }
        /// <summary>Gets or sets the PscDeficienciesRag field.</summary>
        public int? PscDeficienciesRag { get; set; }
        /// <summary>Gets or sets the Ltis field.</summary>
        public decimal? Ltis { get; set; }
        /// <summary>Gets or sets the LtisRag field.</summary>
        public int? LtisRag { get; set; }
        /// <summary>Gets or sets the LtiR3M field.</summary>
        public decimal? LtiR3M { get; set; }
        /// <summary>Gets or sets the OverdueInspection field.</summary>
        public decimal? OverdueInspection { get; set; }
        /// <summary>Gets or sets the OverdueInspectionRag field.</summary>
        public int? OverdueInspectionRag { get; set; }
        /// <summary>Gets or sets the LtifRatioR3M field.</summary>
        public decimal? LtifRatioR3M { get; set; }
        /// <summary>Gets or sets the OmvFindingsRatioR6M field.</summary>
        public decimal? OmvFindingsRatioR6M { get; set; }
        /// <summary>Gets or sets the OmvFindings field.</summary>
        public decimal? OmvFindings { get; set; }
        /// <summary>Gets or sets the OmvFindingsRag field.</summary>
        public int? OmvFindingsRag { get; set; }
        /// <summary>Gets or sets the OpexBudget field.</summary>
        public decimal? OpexBudget { get; set; }
        /// <summary>Gets or sets the OpexVariance field.</summary>
        public decimal? OpexVariance { get; set; }
        /// <summary>Gets or sets the OverdueTechnicalInspection05 field.</summary>
        public int? OverdueTechnicalInspection05 { get; set; }
        /// <summary>Gets or sets the OverdueTechnicalInspection56 field.</summary>
        public int? OverdueTechnicalInspection56 { get; set; }
        /// <summary>Gets or sets the OverdueTechnicalInspection6Plus field.</summary>
        public int? OverdueTechnicalInspection6Plus { get; set; }
        /// <summary>Gets or sets the OffHireDaysR3M field.</summary>
        public decimal? OffHireDaysR3M { get; set; }
        /// <summary>Gets or sets the CriticalPmsLm field.</summary>
        public decimal? CriticalPmsLm { get; set; }
        /// <summary>Gets or sets the CriticalPmsLmRag field.</summary>
		public decimal? CriticalPmsLmRag { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyL3M field.</summary>
        public decimal? FuelEfficiencyL3M { get; set; }
        /// <summary>Gets or sets the RightShip field.</summary>
        public int? RightShip { get; set; }

        /// <summary>Gets or sets the CriticalPms field.</summary>
        public int? CriticalPms { get; set; }
        /// <summary>Gets or sets the CriticalPmsRag field.</summary>
        public int? CriticalPmsRag { get; set; }
        /// <summary>Gets or sets the OffHire field.</summary>
        public TimeSpan? OffHire { get; set; }
        /// <summary>Gets or sets the OffHireRag field.</summary>
        public int? OffHireRag { get; set; }
        /// <summary>Gets or sets the FuelEfficiency field.</summary>
        public decimal? FuelEfficiency { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyRag field.</summary>
        public int? FuelEfficiencyRag { get; set; }
        #endregion

        #region VesselLevelRAG Properties
        /// <summary>
        /// Gets or sets the SeriousIncidentsRed field.
        /// </summary>
        /// <value>
        /// The serious incidents rag.
        /// </value>
        //public int SeriousIncidentsRag { get; set; }

        /// <summary>
        /// Gets the PSC deficiencies rag.
        /// </summary>
        /// <value>
        /// The PSC deficiencies rag.
        /// </value>
        public int? PSCDeficienciesRAG { get { return PscDeficienciesRag; } }

        /// <summary>
        /// Gets the omv findings rag.
        /// </summary>
        /// <value>
        /// The omv findings rag.
        /// </value>
        public int? OmvFindingsRAG { get { return OmvFindingsRag; } }
        /// <summary>
        /// Gets or sets the OverdueInspectionsRag field.
        /// </summary>
        /// <value>
        /// The overdue inspections rag.
        /// </value>
        public int? OverdueInspectionsRag { get { return OverdueInspectionRag; } }

        /// <summary>
        /// Gets the ltifrag.
        /// </summary>
        /// <value>
        /// The ltifrag.
        /// </value>
        public int? LTIFRAG{ get { return LtisRag; }}

        #endregion

        #region OfficeCustomerFleetLevelRAG Tooltip Properties
        /// <summary>
        /// Gets the serious incidents tool tip.
        /// </summary>
        /// <value>
        /// The serious incidents tool tip.
        /// </value>
        public string SeriousIncidentsToolTip
        {
            get
            {
                return "Last 3 Months Serious Incidents: " + SeriousIncidents; 
            }
        }

        /// <summary>
        /// Gets the PSC detentions tool tip.
        /// </summary>
        /// <value>
        /// The PSC detentions tool tip.
        /// </value>
        public string PSCDetentionsToolTip
        {
            get
            {
                return "Last 3 Months Detentions: " + PscDetentions;
            }
        }

        /// <summary>
        /// Gets the PSC deficiencies tool tip.
        /// </summary>
        /// <value>
        /// The PSC deficiencies tool tip.
        /// </value>
        public string PSCDeficienciesToolTip
        {
            get
            {
                return "Last 3 Months Deficiencies: " + Convert.ToInt32(PscDeficiencies.GetValueOrDefault());
            }
        }

        /// <summary>
        /// Gets the ltif tooltip.
        /// </summary>
        /// <value>
        /// The ltif tooltip.
        /// </value>
        public string LTIFTooltip
        {
            get
            {
                return "Last 3 Months LTI: " + Convert.ToInt32(Ltis.GetValueOrDefault());
            }
        }

        /// <summary>
        /// Gets the omv findings tool tip.
        /// </summary>
        /// <value>
        /// The omv findings tool tip.
        /// </value>
        public string OmvFindingsToolTip
        {
            get
            {
                return "Last 6 Months OMV Findings: " + Convert.ToInt32(OmvFindings.GetValueOrDefault());
            }
        }

        /// <summary>
        /// Gets the overdue inspection tooltip.
        /// </summary>
        /// <value>
        /// The overdue inspection tooltip.
        /// </value>
        public string OverdueInspectionTooltip
        {
            get
            {
                return "Total Overdue Inspection Count: " + Convert.ToInt32(OverdueInspection.GetValueOrDefault());
            }
        }

        /// <summary>
        /// Gets or sets the critical PMS tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS tool tip.
        /// </value>
        public string CriticalPmsToolTip
        {
            get { return "Total Critical PMS Count: " + Convert.ToInt32(CriticalPmsLm.GetValueOrDefault()); }
        }

        /// <summary>
        /// Gets the off hire days tool tip.
        /// </summary>
        /// <value>
        /// The off hire days tool tip.
        /// </value>
        public string OffHireDaysToolTip
        {
            get
            {
                return "Last 3 Months Unplanned Offhire Average Time Ratio: " + OffHireHoursDisplayValue;
            }
        }

        /// <summary>
        /// Gets the fuel efficiency tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency tool tip.
        /// </value>
        public string FuelEfficiencyToolTip
        {
            get
            {
                return "Last 3 Months Fuel Efficiency: " + Math.Round(Convert.ToDouble(FuelEfficiency), 2) + "%";
            }
        }
        #endregion

        #region UserDefined Properties
        /// <summary>
        /// Gets the off hire hours display value.
        /// </summary>
        /// <value>
        /// The off hire hours display value.
        /// </value>
        public string OffHireHoursDisplayValue
        {
            get
            {
                decimal? val = OffHireDaysR3M;
                if (val.HasValue && val.Value != default(decimal))
                {
                    double valTime = Convert.ToDouble(val);

                    TimeSpan span = TimeSpan.FromMinutes(valTime);
                    int hh = span.Hours;
                    int mm = span.Minutes;
                    int ss = span.Seconds;

                    return string.Format("{0}:{1}:{2}", hh.ToString("00"), mm.ToString("00"), ss.ToString("00"));
                }
                else
                {
                    return string.Format("{0}:{1}:{2}", "00", "00", "00");
                }
            }
        }
        #endregion
    }
}
