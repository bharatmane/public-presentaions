﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class CustomersOverviewDetails:BaseViewModel
    {
        /// <summary>
        /// The customer identifier
        /// </summary>
        private string _customerId;
        /// <summary>
        /// Gets or sets the customer identifier.
        /// </summary>
        /// <value>
        /// The customer identifier.
        /// </value>
        public string CustomerId
        {
            get { return _customerId; }
            set { Set(() => CustomerId, ref _customerId, value); }
        }

        /// <summary>
        /// The customer description
        /// </summary>
        private string _customerDescription;
        /// <summary>
        /// Gets or sets the customer description.
        /// </summary>
        /// <value>
        /// The customer description.
        /// </value>
        public string CustomerDescription
        {
            get { return _customerDescription; }
            set { Set(() => CustomerDescription, ref _customerDescription, value); }
        }

        /// <summary>
        /// The is key customer
        /// </summary>
        public bool? _isKeyCustomer;
        /// <summary>
        /// Gets or sets the is key customer.
        /// </summary>
        /// <value>
        /// The is key customer.
        /// </value>
        public bool? IsKeyCustomer
        {
            get { return _isKeyCustomer; }
            set { Set(() => IsKeyCustomer, ref _isKeyCustomer, value); }
        }
    }
}
