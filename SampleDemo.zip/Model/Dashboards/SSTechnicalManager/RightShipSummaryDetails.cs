﻿using Newtonsoft.Json;
using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This class is RightShipSummaryDetails.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class RightShipSummaryDetails : BaseViewModel
    {

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        [JsonProperty("vesId")]
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        [JsonProperty("vesselName")]
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the vessel imo.
        /// </summary>
        /// <value>
        /// The vessel imo.
        /// </value>
        [JsonProperty("imonumber")]
        public string VesselImo { get; set; }

        /// <summary>
        /// Gets or sets the right ship date.
        /// </summary>
        /// <value>
        /// The right ship date.
        /// </value>
        [JsonProperty("righShipMonth")]
        public DateTime? RightShipDate { get; set; }

        /// <summary>
        /// Gets or sets the right ship value.
        /// </summary>
        /// <value>
        /// The right ship value.
        /// </value>
        [JsonProperty("righShipValue")]
        public double? RightShipValue { get; set; }

        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        [JsonProperty("OfficeName")]
        public string OfficeName { get; set; }

        /// <summary>
        /// Gets or sets the GHG rating.
        /// </summary>
        /// <value>
        /// The GHG rating.
        /// </value>
        [JsonProperty("GHGRating")]
        public string GHGRating { get; set; }
    }
}
