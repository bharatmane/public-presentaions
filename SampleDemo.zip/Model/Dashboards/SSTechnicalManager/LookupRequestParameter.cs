﻿namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This class is LookupRequestParameter.
    /// </summary>
    public class LookupRequestParameter
    {
        #region Properties

        /// <summary>
        /// Gets or sets the search text.
        /// </summary>
        /// <value>
        /// The search text.
        /// </value>
        public string SearchText { get; set; }

        /// <summary>
        /// Gets or sets the type of the date filter.
        /// </summary>
        /// <value>
        /// The type of the date filter.
        /// </value>
        public int DateFilterType { get; set; }

        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        public string OfficeId { get; set; }

        #endregion
    }
}
