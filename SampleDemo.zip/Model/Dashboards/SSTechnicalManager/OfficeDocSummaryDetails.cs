﻿using Newtonsoft.Json;
using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>This class is OfficeDocSummaryDetails.</summary>
    public class OfficeDocSummaryDetails : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        [JsonProperty("OfficeId")]
        public string OfficeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the office friendly.
        /// </summary>
        /// <value>
        /// The name of the office friendly.
        /// </value>
        [JsonProperty("OfficeFriendlyName")]
        public string OfficeFriendlyName { get; set; }

        /// <summary>
        /// Gets or sets the short name of the office friendly.
        /// </summary>
        /// <value>
        /// The short name of the office friendly.
        /// </value>
        [JsonProperty("OfficeFriendlyShortName")]
        public string OfficeFriendlyShortName { get; set; }

        /// <summary>
        /// Gets or sets the parent office identifier.
        /// </summary>
        /// <value>
        /// The parent office identifier.
        /// </value>
        [JsonProperty("ParentOfficeID")]
        public string ParentOfficeID { get; set; }

        /// <summary>
        /// Gets or sets the document value.
        /// </summary>
        /// <value>
        /// The document value.
        /// </value>
        [JsonProperty("DOCValue")]
        public decimal? DOCValue { get; set; }

        /// <summary>
        /// Gets or sets the office document date.
        /// </summary>
        /// <value>
        /// The office document date.
        /// </value>
        public DateTime? OfficeDocDate { get; set; }
    }
}
