﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This class is GhgRatingReportRequestParameter.
    /// </summary>
    public class GhgRatingReportRequestParameter
    {
        #region Properties

        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        public string OfficeId { get; set; }

        /// <summary>
        /// Gets or sets the fleet identifier.
        /// </summary>
        /// <value>
        /// The fleet identifier.
        /// </value>
        public string FleetId { get; set; }

        /// <summary>
        /// Gets or sets the customer identifier.
        /// </summary>
        /// <value>
        /// The customer identifier.
        /// </value>
        public string CustomerId { get; set; }

        /// <summary>
        /// Gets or sets the key account identifier.
        /// </summary>
        /// <value>
        /// The key account identifier.
        /// </value>
        public string KeyAccountId { get; set; }

        /// <summary>
        /// Gets or sets the month date.
        /// </summary>
        /// <value>
        /// The month date.
        /// </value>
        public DateTime? MonthDate { get; set; }

        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        public string OfficeName { get; set; }

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the name of the fleet.
        /// </summary>
        /// <value>
        /// The name of the fleet.
        /// </value>
        public string FleetName { get; set; }

        /// <summary>
        /// Gets or sets the name of the key account.
        /// </summary>
        /// <value>
        /// The name of the key account.
        /// </value>
        public string KeyAccountName { get; set; }

        #endregion
    }
}
