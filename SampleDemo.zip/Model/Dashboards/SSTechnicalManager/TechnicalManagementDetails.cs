﻿using System;
using VShips.Framework.Common.ViewModel;


namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// A class to represent the Business and Commercial node - In Technical Management and Leaving Technical Management
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class TechnicalManagementDetails : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string OfficeName { get; set; }

        /// <summary>
        /// Gets or sets the fleet identifier.
        /// </summary>
        /// <value>
        /// The fleet identifier.
        /// </value>
        public string FleetCellId { get; set; }

        /// <summary>
        /// Gets or sets the fleet description.
        /// </summary>
        /// <value>
        /// The fleet description.
        /// </value>
        public string FleetCellDesc { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesName { get; set; }

        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets the name of the client.
        /// </summary>
        /// <value>
        /// The name of the client.
        /// </value>
        public string ClientName { get; set; }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is leaving in current month.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is leaving in current month; otherwise, <c>false</c>.
        /// </value>
        public bool IsLeavingInCurrentMonth { get; set; }

        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the marine superintendent.
        /// </summary>
        /// <value>
        /// The marine superintendent.
        /// </value>
        public string MarineSuperintendent { get; set; }

        /// <summary>
        /// Gets or sets the fleet manager.
        /// </summary>
        /// <value>
        /// The fleet manager.
        /// </value>
        public string FleetManager { get; set; }

        /// <summary>
        /// Gets or sets the fleet superintendent.
        /// </summary>
        /// <value>
        /// The fleet superintendent.
        /// </value>
        public string FleetSuperintendent { get; set; }

        /// <summary>
        /// Gets or sets the vessel management identifier.
        /// </summary>
        /// <value>
        /// The  vessel management identifier.
        /// </value>
        public string VmdId { get; set; }
    }
}
