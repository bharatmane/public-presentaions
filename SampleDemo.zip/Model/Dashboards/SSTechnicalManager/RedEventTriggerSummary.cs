﻿using VShips.Framework.Common.ViewModel;
using Newtonsoft.Json;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This is an output contract class for red event trigger
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class RedEventTriggerSummary:BaseViewModel
    {
        /// <summary>
        /// Gets or sets the kpi header display order.
        /// </summary>
        /// <value>
        /// The kpi header display order.
        /// </value>
        [JsonProperty("KPIHeader_DisplayOrder")]
        public int KPIHeaderDisplayOrder { get; set; }

        /// <summary>
        /// Gets or sets the kpi header rag.
        /// </summary>
        /// <value>
        /// The kpi header rag.
        /// </value>
        [JsonProperty("KPIHeader_RAG")]
        public int KPIHeaderRAG { get; set; }

        /// <summary>
        /// Gets or sets the kpi header value.
        /// </summary>
        /// <value>
        /// The kpi header value.
        /// </value>
        [JsonProperty("KPIHeader_Value")]
        public string KPIHeaderValue { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is last record.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is last record; otherwise, <c>false</c>.
        /// </value>
        public bool IsLastRecord { get; set; }
    }
}
