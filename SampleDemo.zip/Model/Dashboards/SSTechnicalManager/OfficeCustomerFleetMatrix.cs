﻿using Newtonsoft.Json;
using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// This is an output class for fleet performance overview.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class OfficeCustomerFleetMatrix : BaseViewModel
    {
        #region Api Properties

        /// <summary>Gets or sets the GroupTypeId field.</summary>
        public int? GroupTypeId { get; set; }
        /// <summary>Gets or sets the OfficeId field.</summary>
        public string OfficeId { get; set; }
        /// <summary>Gets or sets the Office field.</summary>
        public string Office { get; set; }
        /// <summary>Gets or sets the FleetCellId field.</summary>
        public string FleetCellId { get; set; }
        /// <summary>Gets or sets the FleetCell field.</summary>
        public string FleetCell { get; set; }
        /// <summary>Gets or sets the CustomerId field.</summary>
        public string CustomerId { get; set; }
        /// <summary>Gets or sets the CustomerDescription field.</summary>
        public string CustomerDescription { get; set; }
        /// <summary>Gets or sets the VesselId field.</summary>
        public string VesselId { get; set; }
        /// <summary>Gets or sets the Vessel field.</summary>
        public string Vessel { get; set; }
        /// <summary>Gets or sets the VesType field.</summary>
		public System.String VesType { get; set; }
        /// <summary>Gets or sets the VesAge field.</summary>
        public int? VesAge { get; set; }
        /// <summary>Gets or sets the VesGrossTonnage field.</summary>
        public int? VesGrossTonnage { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsRag field.</summary>
        public int? SeriousIncidentsRag { get; set; }
        /// <summary>Gets or sets the SeriousIncidents field.</summary>
        public int? SeriousIncidents { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsRatio field.</summary>
        public decimal? SeriousIncidentsRatio { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsRed field.</summary>
        public int? SeriousIncidentsRed { get; set; }

        /// <summary>Gets or sets the PscDetentions field.</summary>
        public int? PscDetentions { get; set; }
        /// <summary>Gets or sets the PscDetentionsR3M field.</summary>
        ///public int? PscDetentionsR3M { get; set; }
        /// <summary>Gets or sets the PscDetentionsRed field.</summary>
        public int? PscDetentionsRed { get; set; }
        /// <summary>Gets or sets the PscDetentionsRatio field.</summary>
        public decimal? PscDetentionsRatio { get; set; }
        /// <summary>Gets or sets the PscDetentionsRag field.</summary>
        public int? PscDetentionsRag { get; set; }
        /// <summary>Gets or sets the PscDeficiencies field.</summary>
        public int? PscDeficiencies { get; set; }
        /// <summary>Gets or sets the PscDeficienciesRatio field.</summary>
        public decimal? PscDeficienciesRatio { get; set; }
        /// <summary>Gets or sets the PscDeficienciesRag field.</summary>
        public int? PscDeficienciesRag { get; set; }
        /// <summary>Gets or sets the PscDeficienciesRed field.</summary>
        public int? PscDeficienciesRed { get; set; }
        /// <summary>Gets or sets the Ltis field.</summary>
        public int? Ltis { get; set; }
        /// <summary>Gets or sets the LtisRatio field.</summary>
        public decimal? LtisRatio { get; set; }
        /// <summary>Gets or sets the LtisRag field.</summary>
        public int? LtisRag { get; set; }
        /// <summary>Gets or sets the LtisRed field.</summary>
        public int? LtisRed { get; set; }
        /// <summary>Gets or sets the OmvFindings field.</summary>
        public int? OmvFindings { get; set; }
        /// <summary>Gets or sets the OmvFindingsRatio field.</summary>
        public decimal? OmvFindingsRatio { get; set; }
        /// <summary>Gets or sets the OmvFindingsRag field.</summary>
        public int? OmvFindingsRag { get; set; }
        /// <summary>Gets or sets the OmvFindingsRed field.</summary>
        public int? OmvFindingsRed { get; set; }
        /// <summary>Gets or sets the OverdueInspections field.</summary>
        public int? OverdueInspections { get; set; }
        /// <summary>Gets or sets the OverdueInspectionRag field.</summary>
        public int? OverdueInspectionRag { get; set; }
        /// <summary>Gets or sets the OverdueInspectionRed field.</summary>
        public int? OverdueInspectionRed { get; set; }
        /// <summary>Gets or sets the OpexBudget field.</summary>
        public decimal? OpexBudget { get; set; }
        /// <summary>Gets or sets the OpexVariance field.</summary>
        public decimal? OpexVariance { get; set; }
        /// <summary>Gets or sets the OpexTotal field.</summary>
        public decimal? OpexTotal { get; set; }
        /// <summary>Gets or sets the OpexWv field.</summary>
        public decimal? OpexWv { get; set; }
        /// <summary>Gets or sets the OpexMonth field.</summary>
        [JsonProperty("opexMonth")]
        public decimal? OpexMonth { get; set; }
        /// <summary>Gets or sets the Opexmonth field.</summary>
		public DateTime? OpexmonthYearDate { get; set; }
        /// <summary>Gets or sets the OpexRed field.</summary>
        public int? OpexRed { get; set; }
        /// <summary>Gets or sets the Opex field.</summary>
        public decimal? Opex { get; set; }
        /// <summary>Gets or sets the OffHireDays field.</summary>
        public decimal? OffHireDays { get; set; }
        /// <summary>Gets or sets the CriticalPmsLm field.</summary>
        public decimal? CriticalPmsLm { get; set; }
        /// <summary>Gets or sets the RightShip field.</summary>
        public Decimal? RightShip { get; set; }
        /// <summary>Gets or sets the RightShipR3M field.</summary>
        public decimal? RightShipR3M { get; set; }
        /// <summary>Gets or sets the RightShipRed field.</summary>
        public int? RightShipRed { get; set; }
        /// <summary>Gets or sets the RightShipRag field.</summary>
        public int? RightShipRag { get; set; }

        /// <summary>Gets or sets the PreviousScore field.</summary>
        public decimal? PreviousScore { get; set; }
        /// <summary>Gets or sets the Ltmscore field.</summary>
        public decimal? Ltmscore { get; set; }
        /// <summary>Gets or sets the NumAffectedKpi field.</summary>
        public int? NumAffectedKpi { get; set; }
        /// <summary>Gets or sets the CriticalPms field.</summary>
        public int? CriticalPms { get; set; }
        /// <summary>Gets or sets the CriticalPmsRed field.</summary>
        public int? CriticalPmsRed { get; set; }
        /// <summary>Gets or sets the CriticalPmsRag field.</summary>
        public int? CriticalPmsRag { get; set; }
        /// <summary>Gets or sets the OffHire field.</summary>
        public decimal? OffHire { get; set; }
        /// <summary>Gets or sets the OffHireRed field.</summary>
        public int? OffHireRed { get; set; }
        /// <summary>Gets or sets the OffHireRag field.</summary>
        public int? OffHireRag { get; set; }
        /// <summary>Gets or sets the FuelEfficiency field.</summary>
        public decimal? FuelEfficiency { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyRed field.</summary>
        public int? FuelEfficiencyRed { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyRag field.</summary>
        public int? FuelEfficiencyRag { get; set; }
        /// <summary>Gets or sets the ExperienceMatrix field.</summary>
		public int? ExperienceMatrix { get; set; }
        /// <summary>Gets or sets the ExperienceMatrixRed field.</summary>
        public int? ExperienceMatrixRed { get; set; }
        /// <summary>Gets or sets the ExperienceMatrixRag field.</summary>
        public int? ExperienceMatrixRag { get; set; }
        /// <summary>Gets or sets the OilSpillToWater field.</summary>
		public int? OilSpillToWater { get; set; }
        /// <summary>Gets or sets the OilSpillToWaterRed field.</summary>
        public int? OilSpillToWaterRed { get; set; }
        /// <summary>Gets or sets the OilSpillToWaterRag field.</summary>
        public int? OilSpillToWaterRag { get; set; }
        /// <summary>Gets or sets the OpexRag field.</summary>
        public int? OpexRag { get; set; }
        /// <summary>Gets or sets the OpexBudgetedDays field.</summary>
		public int? OpexBudgetedDays { get; set; }
        /// <summary>Gets or sets the TotalCharter field.</summary>
        public int? TotalCharter { get; set; }
        /// <summary>Gets or sets the CrewRetention field.</summary>
		public decimal? CrewRetention { get; set; }
        /// <summary>Gets or sets the CrewRetentionRag field.</summary>
        public int? CrewRetentionRag { get; set; }
        /// <summary>Gets or sets the MatrixFailDepartment field.</summary>
		public string MatrixFailDepartment { get; set; }
        /// <summary>Gets or sets the DeckVmsyrs field.</summary>
        public decimal? DeckVmsyrs { get; set; }
        /// <summary>Gets or sets the EngnrgVmsyrs field.</summary>
        public decimal? EngnrgVmsyrs { get; set; }
        /// <summary>Gets or sets the IsKeyCustomer field.</summary>
		public bool? IsKeyCustomer { get; set; }
        /// <summary>Gets or sets the OfficeTarget field.</summary>
		public decimal? OfficeTarget { get; set; }
        /// <summary>Gets or sets the OfficeTargetToDate field.</summary>
        public DateTime? OfficeTargetToDate { get; set; }
        /// <summary>Gets or sets the ManagementDays field.</summary>
		public int? ManagementDays { get; set; }
        /// <summary>Gets or sets the PscInspections field.</summary>
        public int? PscInspections { get; set; }
        /// <summary>Gets or sets the ExpHours field.</summary>
        public decimal? ExpHours { get; set; }
        /// <summary>Gets or sets the OmvInspections field.</summary>
        public int? OmvInspections { get; set; }
        /// <summary>Gets or sets the OffSummaryTotalKpimeasureAffectedNames field.</summary>
		public string OffSummaryTotalKpimeasureAffectedNames { get; set; }
        /// <summary>Gets or sets the LastDataRefreshDate field.</summary>
        public DateTime? LastDataRefreshDate { get; set; }
        /// <summary>Gets or sets the LastThreeMonthDate field.</summary>
		public DateTime? LastThreeMonthDate { get; set; }
        /// <summary>Gets or sets the LastSixMonthDate field.</summary>
        public DateTime? LastSixMonthDate { get; set; }
        /// <summary>Gets or sets the management start date.</summary>
        public DateTime? ManagementStartDate { get; set; }
        /// <summary>Gets or sets the ManagementEndDate field.</summary>
        public DateTime? ManagementEndDate { get; set; }
        /// <summary>Gets or sets the LeftManagementVessel field.</summary>
        public bool? LeftManagementVessel { get; set; }

        /// <summary>
        /// Gets or sets the right ship ghgrating.
        /// </summary>
        /// <value>
        /// The right ship ghgrating.
        /// </value>
        public string RightShipGhgrating { get; set; }

        /// <summary>Gets or sets the In90DaysValidVesCnt field.</summary>
		public int? In90DaysValidVesCnt { get; set; }
        /// <summary>Gets or sets the InLast3MonthsValidVesCnt field.</summary>
        public int? InLast3MonthsValidVesCnt { get; set; }
        /// <summary>Gets or sets the InLast6MonthsValidVesCnt field.</summary>
        public int? InLast6MonthsValidVesCnt { get; set; }
        /// <summary>Gets or sets the AsofYesterdayValidVesCnt field.</summary>
        public int? AsofYesterdayValidVesCnt { get; set; }
        /// <summary>Gets or sets the LastMonthValidVesCnt field.</summary>
        public int? LastMonthValidVesCnt { get; set; }
        /// <summary>Gets or sets the LastPriorMonthValidVesCnt field.</summary>
        public int? LastPriorMonthValidVesCnt { get; set; }
        /// <summary>Gets or sets the RightShipValidVessels field.</summary>
        public int? RightShipValidVessels { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsScore field.</summary>
        public decimal? SeriousIncidentsScore { get; set; }
        /// <summary>Gets or sets the PscDetentionsScore field.</summary>
        public decimal? PscDetentionsScore { get; set; }
        /// <summary>Gets or sets the PscDeficienciesScore field.</summary>
        public decimal? PscDeficienciesScore { get; set; }
        /// <summary>Gets or sets the LtisScore field.</summary>
        public decimal? LtisScore { get; set; }
        /// <summary>Gets or sets the OmvScore field.</summary>
        public decimal? OmvScore { get; set; }
        /// <summary>Gets or sets the OverueInspectionScore field.</summary>
        public decimal? OverueInspectionScore { get; set; }
        /// <summary>Gets or sets the OpexScore field.</summary>
        public decimal? OpexScore { get; set; }
        /// <summary>Gets or sets the OffhireScore field.</summary>
        public decimal? OffhireScore { get; set; }
        /// <summary>Gets or sets the CriticalPmsScore field.</summary>
        public decimal? CriticalPmsScore { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyScore field.</summary>
        public decimal? FuelEfficiencyScore { get; set; }
        /// <summary>Gets or sets the ExperienceMatrixScore field.</summary>
        public decimal? ExperienceMatrixScore { get; set; }
        /// <summary>Gets or sets the RightshipScore field.</summary>
        public decimal? RightshipScore { get; set; }
        /// <summary>Gets or sets the OilSpillToWaterScore field.</summary>
        public decimal? OilSpillToWaterScore { get; set; }
        /// <summary>Gets or sets the CrewRetentionScore field.</summary>
        public decimal? CrewRetentionScore { get; set; }
        /// <summary>
        /// Gets or sets the key account customer identifier.
        /// </summary>
        /// <value>
        /// The key account customer identifier.
        /// </value>
        public string KeyAccountCustomerId { get; set; }
        /// <summary>
        /// Gets or sets the name of the key account customer.
        /// </summary>
        /// <value>
        /// The name of the key account customer.
        /// </value>
        public string KeyAccountCustomerName { get; set; }
        /// <summary>
        /// Gets or sets the last prior month end date.
        /// </summary>
        /// <value>
        /// The last prior month end date.
        /// </value>
        public DateTime? LastPriorMonthEndDate { get; set; }

        /// <summary>Gets or sets the SeriousIncidentsValidVesselsCnt field.</summary>
		public int? SeriousIncidentsValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the PscdetentionsValidVesselsCnt field.</summary>
        public int? PscdetentionsValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the PscdeficienciesValidVesselsCnt field.</summary>
        public int? PscdeficienciesValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the LtifvalidVesselsCnt field.</summary>
        public int? LtifvalidVesselsCnt { get; set; }
        /// <summary>Gets or sets the OffHireValidVesselsCnt field.</summary>
        public int? OffHireValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the RightshipValidVesselsCnt field.</summary>
        public int? RightshipValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the OmvfindingsValidVesselsCnt field.</summary>
        public int? OmvfindingsValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the OpexvalidVesselsCnt field.</summary>
        public int? OpexvalidVesselsCnt { get; set; }
        /// <summary>Gets or sets the OverdueInspectionValidVesselsCnt field.</summary>
        public int? OverdueInspectionValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the ExperienceMatrixValidVesselsCnt field.</summary>
        public int? ExperienceMatrixValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the OfficerRetentionValidVesselsCnt field.</summary>
        public int? OfficerRetentionValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the CriticalPmsvalidVesselsCnt field.</summary>
        public int? CriticalPmsvalidVesselsCnt { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyValidVesselsCnt field.</summary>
        public int? FuelEfficiencyValidVesselsCnt { get; set; }
        /// <summary>Gets or sets the OilSpillsToWaterValidVesselsCnt field.</summary>
        public int? OilSpillsToWaterValidVesselsCnt { get; set; }

        /// <summary>
        /// This is Doc value.
        /// </summary>
        public decimal? DocValue { get; set; }
        #endregion

        #region SummaryPageProperties
        /// <summary>Gets or sets the OffSummaryTotalRedEvents field.</summary>
        public int? OffSummaryTotalRedEvents { get; set; }
        /// <summary>Gets or sets the OffSummaryTotalFleetSize field.</summary>
        public int? OffSummaryTotalFleetSize { get; set; }
        /// <summary>Gets or sets the OffSummaryMonthlyScore field.</summary>
        public decimal? OffSummaryMonthlyScore { get; set; }
        /// <summary>Gets or sets the OffSummaryLastMonthScore field.</summary>
		public decimal? OffSummaryLastMonthScore { get; set; }
        /// <summary>Gets or sets the OffSummaryMonthlyScoreRayg field.</summary>
        public int? OffSummaryMonthlyScoreRayg { get; set; }
        /// <summary>Gets or sets the OffSummaryRank field.</summary>
        public int? OffSummaryRank { get; set; }
        /// <summary>Gets or sets the OffSummaryMdorGm field.</summary>
        public string OffSummaryMdorGm { get; set; }
        /// <summary>Gets or sets the OffSummaryTrends field.</summary>
        public int? OffSummaryTrends { get; set; }
        /// <summary>Gets or sets the OffSummaryTotalTwelveMonthScore field.</summary>
        public decimal? OffSummaryTotalTwelveMonthScore { get; set; }
        /// <summary>Gets or sets the OffSummaryTotalKpimeasureAffected field.</summary>
        public int? OffSummaryTotalKpimeasureAffected { get; set; }
        /// <summary>Gets or sets Total Fleet Size</summary>
        public int? SixMonthTotalFleetSize { get; set; }
        #endregion

        #region Summary Page Tooltip        
        /// <summary>
        /// Gets or sets the off summary monthly score tooltip.
        /// </summary>
        /// <value>
        /// The off summary monthly score tooltip.
        /// </value>
        public string OffSummaryMonthlyScoreTooltip
        {
            get
            {
                return string.Format("Total Red Events ({0}) / Fleet Size ({1}) = {2}", OffSummaryTotalRedEvents.GetValueOrDefault(), OffSummaryTotalFleetSize.GetValueOrDefault(), OffSummaryMonthlyScore);
            }
        }

        /// <summary>
        /// Gets or sets the no of kpi affected tooltip.
        /// </summary>
        /// <value>
        /// The no of kpi affected tooltip.
        /// </value>
        public string NoOfKPIAffectedTooltip
        {
            get
            {
                return !string.IsNullOrWhiteSpace(OffSummaryTotalKpimeasureAffectedNames) ? OffSummaryTotalKpimeasureAffectedNames.Replace(",", "\n") : null;
            }
        }
        #endregion

        #region Trends Properties
        /// <summary>Gets or sets the SeriousIncidentsTrendRag field.</summary>
        public int? SeriousIncidentsTrendRag { get; set; }
        /// <summary>Gets or sets the SeriousIncidentsTrendRatio field.</summary>
        public decimal? SeriousIncidentsTrendRatio { get; set; }
        /// <summary>Gets or sets the PscDetentionsTrendRatio field.</summary>
        public decimal? PscDetentionsTrendRatio { get; set; }
        /// <summary>Gets or sets the PscDetentionsTrendRag field.</summary>
        public int? PscDetentionsTrendRag { get; set; }
        /// <summary>Gets or sets the PscDeficienciesTrendRatio field.</summary>
        public decimal? PscDeficienciesTrendRatio { get; set; }
        /// <summary>Gets or sets the PscDeficienciesTrendRag field.</summary>
        public int? PscDeficienciesTrendRag { get; set; }
        /// <summary>Gets or sets the LtisTrendRatio field.</summary>
        public decimal? LtisTrendRatio { get; set; }
        /// <summary>Gets or sets the LtisTrendRag field.</summary>
        public int? LtisTrendRag { get; set; }
        /// <summary>Gets or sets the OffHireTrendRatio field.</summary>
        public decimal? OffHireTrendRatio { get; set; }
        /// <summary>Gets or sets the OffHireTrendRag field.</summary>
        public int? OffHireTrendRag { get; set; }
        /// <summary>Gets or sets the RightShipTrend field.</summary>
        public decimal? RightShipTrend { get; set; }
        /// <summary>Gets or sets the RightShipTrendRag field.</summary>
        public int? RightShipTrendRag { get; set; }
        /// <summary>Gets or sets the OmvFindingsTrendRatio field.</summary>
        public decimal? OmvFindingsTrendRatio { get; set; }
        /// <summary>Gets or sets the OmvFindingsTrendRag field.</summary>
        public int? OmvFindingsTrendRag { get; set; }
        /// <summary>Gets or sets the OpexTrendRag field.</summary>
        public int? OpexTrendRag { get; set; }
        /// <summary>Gets or sets the OpexTrendPercentage field.</summary>
        public decimal? OpexTrendPercentage { get; set; }
        /// <summary>Gets or sets the OverdueInspectionsTrend field.</summary>
        public int? OverdueInspectionsTrend { get; set; }
        /// <summary>Gets or sets the OverdueInspectionTrendRag field.</summary>
        public int? OverdueInspectionTrendRag { get; set; }
        /// <summary>Gets or sets the CrewRetentionTrendPercentage field.</summary>
        public decimal? CrewRetentionTrendPercentage { get; set; }
        /// <summary>Gets or sets the CrewRetentionTrendRag field.</summary>
        public int? CrewRetentionTrendRag { get; set; }
        /// <summary>Gets or sets the ExperienceMatrixTrend field.</summary>
        public int? ExperienceMatrixTrend { get; set; }
        /// <summary>Gets or sets the ExperienceMatrixTrendRag field.</summary>
        public int? ExperienceMatrixTrendRag { get; set; }
        /// <summary>Gets or sets the CriticalPmsTrendPercentage field.</summary>
        public decimal? CriticalPmsTrendPercentage { get; set; }
        /// <summary>Gets or sets the CriticalPmsTrendRag field.</summary>
        public int? CriticalPmsTrendRag { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyTrendPercentage field.</summary>
        public decimal? FuelEfficiencyTrendPercentage { get; set; }
        /// <summary>Gets or sets the FuelEfficiencyTrendRag field.</summary>
        public int? FuelEfficiencyTrendRag { get; set; }
        /// <summary>Gets or sets the OilSpillToWaterTrend field.</summary>
        public int? OilSpillToWaterTrend { get; set; }
        /// <summary>Gets or sets the OilSpillToWaterTrendRag field.</summary>
        public int? OilSpillToWaterTrendRag { get; set; }
        #endregion

        #region OfficeCustomerFleetLevelRAG Properties
        /// <summary>
        /// Gets the PSC deficiencies rag.
        /// </summary>
        /// <value>
        /// The PSC deficiencies rag.
        /// </value>
        public int? PSCDeficienciesRAG { get { return PscDeficienciesRag; } }

        /// <summary>
        /// Gets the ltifrag.
        /// </summary>
        /// <value>
        /// The ltifrag.
        /// </value>
        public int? LTIFRAG { get { return LtisRag; } }

        /// <summary>
        /// Gets or sets the OmvRejectionsRag field.
        /// </summary>
        /// <value>
        /// The omv rejections rag.
        /// </value>
        public int? OmvFindingsRAG { get { return OmvFindingsRag; } }
        /// <summary>
        /// Gets or sets the OverdueInspectionsRag field.
        /// </summary>
        /// <value>
        /// The overdue inspections rag.
        /// </value>
        public int? OverdueInspectionsRag { get { return OverdueInspectionRag; } }

        #endregion

        #region OfficeCustomerFleetLevelRAG Tooltip Properties
        /// <summary>
        /// Gets the serious incidents tool tip.
        /// </summary>
        /// <value>
        /// The serious incidents tool tip.
        /// </value>
        public string SeriousIncidentsToolTip
        {
            get
            {
                return string.Format("(No. of Incidents ({0}) x 1000) / (No. of Management Days ({1})) = Last 3 Months Serious Incidents Ratio: {2}", SeriousIncidents.GetValueOrDefault(), ManagementDays.GetValueOrDefault(), Math.Round(SeriousIncidentsRatio.GetValueOrDefault(), 2));
            }
        }

        /// <summary>
        /// Gets the PSC detentions tool tip.
        /// </summary>
        /// <value>
        /// The PSC detentions tool tip.
        /// </value>
        public string PSCDetentionsToolTip
        {
            get
            {
                return string.Format("Last 3 Months Total Detentions ({0}) / Last 3 Months Total PSC Inspections ({1})= Last 3 Months Detentions Ratio: {2}", PscDetentions.GetValueOrDefault(), PscInspections.GetValueOrDefault(), Math.Round(PscDetentionsRatio.GetValueOrDefault(), 4));
            }
        }

        /// <summary>
        /// Gets the PSC deficiencies tool tip.
        /// </summary>
        /// <value>
        /// The PSC deficiencies tool tip.
        /// </value>
        public string PSCDeficienciesToolTip
        {
            get
            {
                return string.Format("Last 3 Months Total Deficiencies ({0}) / Last 3 Months Total PSC Inspections ({1}) = Last 3 Months Deficiencies Ratio: {2}", PscDeficiencies.GetValueOrDefault(), PscInspections.GetValueOrDefault(), Math.Round(PscDeficienciesRatio.GetValueOrDefault(), 2));
            }
        }

        /// <summary>
        /// Gets the ltif tool tip.
        /// </summary>
        /// <value>
        /// The ltif tool tip.
        /// </value>
        public string LTIFToolTip
        {
            get
            {
                return string.Format("Last 3 Months Total LTI ({0}) / Last 3 Months Total Exp. Hours ({1}) = Last 3 Months LTI Ratio: {2}", Ltis.GetValueOrDefault(), Math.Round(ExpHours.GetValueOrDefault(), 2), Math.Round(LtisRatio.GetValueOrDefault(), 2));
            }
        }

        /// <summary>
        /// Gets the omv findings tool tip.
        /// </summary>
        /// <value>
        /// The omv findings tool tip.
        /// </value>
        public string OmvFindingsToolTip
        {
            get
            {
                return string.Format("Last 6 Months Total OMV Findings ({0}) / Last 6 Months Total OMV Inspections ({1}) = Last 6 Months OMV Findings Ratio: {2}",
                    OmvFindings.GetValueOrDefault(), OmvInspections.GetValueOrDefault(), Math.Round(OmvFindingsRatio.GetValueOrDefault(), 2));
            }
        }


        /// <summary>
        /// Gets the overdue technical inspection tool tip.
        /// </summary>
        /// <value>
        /// The overdue technical inspection tool tip.
        /// </value>
        public string OverdueTechnicalInspectionToolTip
        {
            get
            {
                return "Total Overdue Inspection Count: " + OverdueInspections;
            }
        }

        /// <summary>
        /// Gets or sets the critical PMS tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS tool tip.
        /// </value>
        public string CriticalPmsToolTip
        {
            get { return "Total Overdue Critical PMS Last Month Count: " + CriticalPms; }
        }

        /// <summary>
        /// Gets the off hire days tool tip.
        /// </summary>
        /// <value>
        /// The off hire days tool tip.
        /// </value>
        public string OffHireDaysToolTip
        {
            get
            {
                return "Last 3 Months Unplanned Offhire Average Time: " + OffHireHoursDisplayValue;
            }
        }

        /// <summary>
        /// Gets the fuel efficiency tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency tool tip.
        /// </value>
        public string FuelEfficiencyToolTip
        {
            get
            {
                return "Last 3 Months Fuel Efficiency Ratio: " + Math.Round(Convert.ToDecimal(FuelEfficiency), 2) + "%";
            }
        }

        /// <summary>
        /// Gets the right ship tool tip.
        /// </summary>
        /// <value>
        /// The right ship tool tip.
        /// </value>
        public string RightShipToolTip
        {
            get
            {
                return "Current RS Score: " + Math.Round(RightShip.GetValueOrDefault(), 2);
            }
        }

        /// <summary>
        /// Gets the experience matrix tool tip.
        /// </summary>
        /// <value>
        /// The experience matrix tool tip.
        /// </value>
        public string ExperienceMatrixToolTip
        {
            get
            {
                return ExperienceMatrixRag == 1 ? "VMS Requirement Pass" : "VMS Requirement Fail";
            }
        }

        /// <summary>
        /// Gets the oil spill to water tooltip.
        /// </summary>
        /// <value>
        /// The oil spill to water tooltip.
        /// </value>
        public string OilSpillToWaterTooltip
        {
            get { return "Last 3 Months Oil Spills To Water: " + OilSpillToWater; }
        }

        /// <summary>
        /// Gets the opex budget tooltip.
        /// </summary>
        /// <value>
        /// The opex budget tooltip.
        /// </value>
        public string OpexBudgetTooltip
        {
            get { return ""; }
        }

        /// <summary>
        /// Gets the trend percent tooltip.
        /// </summary>
        /// <value>
        /// The trend percent tooltip.
        /// </value>
        public string TrendPercentTooltip
        {
            get
            {
                return string.Format("Current score (CS) ={0}, Last Months score (LMS) = {1}. Difference is calculated as (CS-LMS)/LMS", Math.Round(OffSummaryMonthlyScore.GetValueOrDefault(), 2), Math.Round(OffSummaryLastMonthScore.GetValueOrDefault(), 2));
            }
        }
        #endregion

        #region OfficeCustomerFleetLevel RED Value Tooltip Properties        
        /// <summary>
        /// Gets the serious incidents red tooltip.
        /// </summary>
        /// <value>
        /// The serious incidents red tooltip.
        /// </value>
        public string SeriousIncidentsRedTooltip
        {
            get { return GetRedVesselCountTooltip(SeriousIncidentsRed, SeriousIncidentsValidVesselsCnt, SeriousIncidentsScore); }
        }

        /// <summary>
        /// Gets the pscdetentions red tooltip.
        /// </summary>
        /// <value>
        /// The pscdetentions red tooltip.
        /// </value>
        public string PscdetentionsRedTooltip
        {
            get { return GetRedVesselCountTooltip(PscDetentionsRed, PscdetentionsValidVesselsCnt, PscDetentionsScore); }
        }

        /// <summary>
        /// Gets the pscdeficiencies red tooltip.
        /// </summary>
        /// <value>
        /// The pscdeficiencies red tooltip.
        /// </value>
        public string PscdeficienciesRedTooltip
        {
            get { return GetRedVesselCountTooltip(PscDeficienciesRed, PscdeficienciesValidVesselsCnt, PscDeficienciesScore); }
        }

        /// <summary>
        /// Gets the ltifrag tooltip.
        /// </summary>
        /// <value>
        /// The ltifrag tooltip.
        /// </value>
        public string LTIFRedTooltip
        {
            get { return GetRedVesselCountTooltip(LtisRed, LtifvalidVesselsCnt, LtisScore); }
        }

        /// <summary>
        /// Gets the omvfindings red tooltip.
        /// </summary>
        /// <value>
        /// The omvfindings red tooltip.
        /// </value>
        public string OmvfindingsRedTooltip
        {
            get { return GetRedVesselCountTooltip(OmvFindingsRed, OmvfindingsValidVesselsCnt, OmvScore); }
        }

        /// <summary>
        /// Gets the overdue technical inspections red tooltip.
        /// </summary>
        /// <value>
        /// The overdue technical inspections red tooltip.
        /// </value>
        public string OverdueTechnicalInspectionsRedTooltip
        {
            get { return GetRedVesselCountTooltip(OverdueInspectionRed, OverdueInspectionValidVesselsCnt, OverueInspectionScore); }
        }

        /// <summary>
        /// Gets the critical PMS red tooltip.
        /// </summary>
        /// <value>
        /// The critical PMS red tooltip.
        /// </value>
        public string CriticalPmsRedTooltip
        {
            get { return GetRedVesselCountTooltip(CriticalPmsRed, CriticalPmsvalidVesselsCnt, CriticalPmsScore); }
        }

        /// <summary>
        /// Gets the offhire red tooltip.
        /// </summary>
        /// <value>
        /// The offhire red tooltip.
        /// </value>
        public string OffhireRedTooltip
        {
            get { return GetRedVesselCountTooltip(OffHireRed, OffHireValidVesselsCnt, OffhireScore); }
        }

        /// <summary>
        /// Gets the fuel efficiency red tooltip.
        /// </summary>
        /// <value>
        /// The fuel efficiency red tooltip.
        /// </value>
        public string FuelEfficiencyRedTooltip
        {
            get { return GetRedVesselCountTooltip(FuelEfficiencyRed, FuelEfficiencyValidVesselsCnt, FuelEfficiencyScore); }
        }

        /// <summary>
        /// Gets the right ship red tool tip.
        /// </summary>
        /// <value>
        /// The right ship red tool tip.
        /// </value>
        public string RightShipRedToolTip
        {
            get { return GetRedVesselCountTooltip(RightShipRed, RightshipValidVesselsCnt, RightshipScore); }
        }

        /// <summary>
        /// Gets the experience matrix red tool tip.
        /// </summary>
        /// <value>
        /// The experience matrix red tool tip.
        /// </value>
        public string ExperienceMatrixRedToolTip
        {
            get { return GetRedVesselCountTooltip(ExperienceMatrixRed, ExperienceMatrixValidVesselsCnt, ExperienceMatrixScore); }
        }

        /// <summary>
        /// Gets the oil spills to water red tool tip.
        /// </summary>
        /// <value>
        /// The oil spills to water red tool tip.
        /// </value>
        public string OilSpillsToWaterRedToolTip
        {
            get { return GetRedVesselCountTooltip(OilSpillToWaterRed, OilSpillsToWaterValidVesselsCnt, OilSpillToWaterScore); }
        }

        /// <summary>
        /// Gets the opex budget red tool tip.
        /// </summary>
        /// <value>
        /// The opex budget red tool tip.
        /// </value>
        public string OpexRedTooltip
        {
            get { return GetRedVesselCountTooltip(OpexRed, OpexvalidVesselsCnt, OpexScore); }
        }
        #endregion

        #region VesselRAG Value Tooltip Properties        
        /// <summary>
        /// Gets the serious incidents vessel tool tip.
        /// </summary>
        /// <value>
        /// The serious incidents vessel tool tip.
        /// </value>
        public string SeriousIncidentsVesselToolTip
        {
            get
            {
                return "Last 3 Months Serious Incidents: " + SeriousIncidents;
            }
        }

        /// <summary>
        /// Gets the PSC detentions vessel tool tip.
        /// </summary>
        /// <value>
        /// The PSC detentions vessel tool tip.
        /// </value>
        public string PSCDetentionsVesselToolTip
        {
            get
            {
                return "Last 3 Months Detentions: " + PscDetentions;
            }
        }

        /// <summary>
        /// Gets the PSC deficiencies vessel tool tip.
        /// </summary>
        /// <value>
        /// The PSC deficiencies vessel tool tip.
        /// </value>
        public string PSCDeficienciesVesselToolTip
        {
            get
            {
                return "Last 3 Months Deficiencies: " + PscDeficiencies;
            }
        }

        /// <summary>
        /// Gets the ltif tool vessel tip.
        /// </summary>
        /// <value>
        /// The ltif tool vessel tip.
        /// </value>
        public string LTIFToolVesselTip
        {
            get
            {
                return "Last 3 Months LTI: " + Ltis;
            }
        }

        /// <summary>
        /// Gets the omv findings vessel tool tip.
        /// </summary>
        /// <value>
        /// The omv findings vessel tool tip.
        /// </value>
        public string OmvFindingsVesselToolTip
        {
            get
            {
                return string.Format("Last 6 Months Total OMV Findings ({0}) / Last 6 Months Total OMV Inspections ({1}) = Last 6 Months OMV Findings Ratio: {2}",
                   OmvFindings.GetValueOrDefault(), OmvInspections.GetValueOrDefault(), Math.Round(OmvFindingsRatio.GetValueOrDefault(), 2));

            }
        }

        /// <summary>
        /// Gets the overdue technical inspection vessel tool tip.
        /// </summary>
        /// <value>
        /// The overdue technical inspection vessel tool tip.
        /// </value>
        public string OverdueTechnicalInspectionVesselToolTip
        {
            get
            {
                return "Total Overdue Inspection Count: " + OverdueInspections;
            }
        }

        /// <summary>
        /// Gets the critical PMS vessel tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS vessel tool tip.
        /// </value>
        public string CriticalPmsVesselToolTip
        {
            get { return "Total Overdue Critical PMS Last Month Count: " + CriticalPms; }
        }

        /// <summary>
        /// Gets the off hire days vessel tool tip.
        /// </summary>
        /// <value>
        /// The off hire days vessel tool tip.
        /// </value>
        public string OffHireDaysVesselToolTip
        {
            get
            {
                return "Last 3 Months Unplanned Offhire Average Time Ratio: " + OffHireHoursDisplayValue;
            }
        }

        /// <summary>
        /// Gets the fuel efficiency vessel tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency vessel tool tip.
        /// </value>
        public string FuelEfficiencyVesselToolTip
        {
            get
            {
                return "Last 3 Months Fuel Efficiency: " + Math.Round(Convert.ToDecimal(FuelEfficiency), 2) + "%";
            }
        }

        /// <summary>
        /// Gets the right ship vessel tool tip.
        /// </summary>
        /// <value>
        /// The right ship vessel tool tip.
        /// </value>
        public string RightShipVesselToolTip
        {
            get
            {
                return "Current RS Score: " + Math.Round(RightShip.GetValueOrDefault(), 2);
            }
        }

        /// <summary>
        /// Gets the experience matrix vessel tool tip.
        /// </summary>
        /// <value>
        /// The experience matrix vessel tool tip.
        /// </value>
        public string ExperienceMatrixVesselToolTip
        {
            get
            {
                return ExperienceMatrixRag == -1 ? "VMS Requirement Fail For " + MatrixFailDepartment : "VMS Requirement For Deck\\Navigation and Engineering Pass";
            }
        }

        /// <summary>
        /// Gets the oil spill to water vessel tooltip.
        /// </summary>
        /// <value>
        /// The oil spill to water vessel tooltip.
        /// </value>
        public string OilSpillToWaterVesselTooltip
        {
            get { return "Last 3 Months Oil Spills To Water: " + OilSpillToWater; }
        }

        /// <summary>
        /// Gets the opex vessel tooltip.
        /// </summary>
        /// <value>
        /// The opex vessel tooltip.
        /// </value>
        public string OpexVesselTooltip
        {
            get { return ""; }
        }

        /// <summary>
        /// Gets the crew retention tool tip.
        /// </summary>
        /// <value>
        /// The crew retention tool tip.
        /// </value>
        public string CrewRetentionToolTip
        {
            get
            {
                if (CrewRetentionScore.GetValueOrDefault() > 0)
                {
                    string toolTip = "Office Retention Last 3 Month Prior Average Value: " + Math.Round(CrewRetention.GetValueOrDefault(), 2);
                    toolTip += "\nKPI Score: " + Math.Round(CrewRetentionScore.GetValueOrDefault(), 2);

                    return toolTip;
                }
                return "Office Retention Last 3 Month Prior Average Value: " + Math.Round(CrewRetention.GetValueOrDefault(), 2);
            }
        }
        #endregion

        #region TrendsTooltip        
        /// <summary>
        /// Gets or sets the serious incidents trend tool tip.
        /// </summary>
        /// <value>
        /// The serious incidents trend tool tip.
        /// </value>
        public string SeriousIncidentsTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Serious Incident Trend = (Serious incident ratio In Current Month) - (Serious incident ratio In Previous Month)\nSerious Incident Ratio", SeriousIncidentsTrendRatio.GetValueOrDefault()); }
        }

        /// <summary>
        /// Gets the PSC detentions trend tool tip.
        /// </summary>
        /// <value>
        /// The PSC detentions trend tool tip.
        /// </value>
        public string PSCDetentionsTrendToolTip
        {
            get { return GetCombinedTrendTooltip("PSC Detentions Trend = (Total PSC Detentions in last month) - (Total PSC Detentions in prior month)\nPSC Detentions", PscDetentionsTrendRatio.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the PSC deficiencies trend tool tip.
        /// </summary>
        /// <value>
        /// The PSC deficiencies trend tool tip.
        /// </value>
        public string PSCDeficienciesTrendToolTip
        {
            get { return GetCombinedTrendTooltip("PSC Deficiencies Trend = (PSC Deficiencies ratio for current month) - (PSC Deficiencies ratio for previous month)\nPSC Deficiency Ratio", PscDeficienciesTrendRatio.GetValueOrDefault()); }
        }

        /// <summary>
        /// Gets the ltif trend tool tip.
        /// </summary>
        /// <value>
        /// The ltif trend tool tip.
        /// </value>
        public string LTIFTrendToolTip
        {
            get { return GetCombinedTrendTooltip("LTIF Trend = (LTIF ratio for current month) - (LTIF ratio for previous month)\nLost Time Injury Frequency", LtisTrendRatio.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the off hire days trend tool tip.
        /// </summary>
        /// <value>
        /// The off hire days trend tool tip.
        /// </value>
        public string OffHireDaysTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Offhire Trend = (Offhire ratio for current month) - (Offhire ratio for previous month)\nOffhire Ratio to Vessels", OffHireTrendRatio.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the right ship trend tool tip.
        /// </summary>
        /// <value>
        /// The right ship trend tool tip.
        /// </value>
        public string RightShipTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Right Ship Trend = (Right Ship Ratio for current month) - (Right Ship Ratio for previous month)\nRight Ship", RightShipTrend.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the omv findings trend tool tip.
        /// </summary>
        /// <value>
        /// The omv findings trend tool tip.
        /// </value>
        public string OmvFindingsTrendToolTip
        {
            get { return GetCombinedTrendTooltip("OMV Trend = (OMV Ratio for current month) - (OMV Ratio for previous month)\nOMV Findings Ratio", OmvFindingsTrendRatio.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the opex trend tool tip.
        /// </summary>
        /// <value>
        /// The opex trend tool tip.
        /// </value>
        public string OpexTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Opex Trend = (Opex percentage in the current month) - (Opex percentage in the previous month)\nOPEX%", OpexTrendPercentage.GetValueOrDefault()) + "%"; }
        }
        /// <summary>
        /// Gets the overdue technical inspection trend tool tip.
        /// </summary>
        /// <value>
        /// The overdue technical inspection trend tool tip.
        /// </value>
        public string OverdueTechnicalInspectionTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Overdue Inspection Trend = (Total overdue inspection at last month end) - (Total overdue inspection at prior month end)\nOverdue Inspection", OverdueInspectionsTrend.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the experience matrix trend tool tip.
        /// </summary>
        /// <value>
        /// The experience matrix trend tool tip.
        /// </value>
        public string ExperienceMatrixTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Experience Matrix", ExperienceMatrixTrend.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the crew retention trend tool tip.
        /// </summary>
        /// <value>
        /// The crew retention trend tool tip.
        /// </value>
        public string CrewRetentionTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Crew Senior Officer Retention Trend = (Average Office Retention value in the last month) - (Average Office Retention value in the prior month)\nCrew Senior Officer Retention", CrewRetentionTrendPercentage.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the critical PMS trend tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS trend tool tip.
        /// </value>
        public string CriticalPmsTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Critical PMS Trend = (Critical PMS at last month end) - (Critical PMS at prior month end)\nCritical PMS", CriticalPmsTrendPercentage.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the fuel efficiency trend tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency trend tool tip.
        /// </value>
        public string FuelEfficiencyTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Fuel Efficiency Trend = (Fuel Efficiency ratio in last month) - (Fuel Efficiency ratio in prior month)\nFuel Efficiency", FuelEfficiencyTrendPercentage.GetValueOrDefault()); }
        }
        /// <summary>
        /// Gets the oil spill to water trend tool tip.
        /// </summary>
        /// <value>
        /// The oil spill to water trend tool tip.
        /// </value>
        public string OilSpillToWaterTrendToolTip
        {
            get { return GetCombinedTrendTooltip("Oil Spills to Water Trend = (Oil Spills to Water ratio in last month) - (Oil Spills to Water ratio in prior month)\nOil Spills To Water", OilSpillToWaterTrend.GetValueOrDefault()); }
        }

        #endregion

        #region UserDefined Properties
        /// <summary>
        /// Gets or sets the Id field.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// The is expanded
        /// </summary>
        private bool _isExpanded = false;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is expanded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is expanded; otherwise, <c>false</c>.
        /// </value>
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set { Set(() => IsExpanded, ref _isExpanded, value); }
        }

        /// <summary>
        /// Gets the off hire hours display value.
        /// </summary>
        /// <value>
        /// The off hire hours display value.
        /// </value>
        public string OffHireHoursDisplayValue
        {
            get
            {
                decimal? val = OffHireDays;
                if (val.HasValue && val.Value != default(decimal))
                {
                    double valTime = Convert.ToDouble(val);
                    try
                    {
                        TimeSpan span = TimeSpan.FromMinutes(valTime);
                        int hh = span.Hours;//Convert.ToInt32(valTime/60);
                        int mm = span.Minutes;//Convert.ToInt32(valTime % 60);//
                        int ss = span.Seconds;
                        if (span.Days > 0)
                        {
                            hh = hh + (span.Days * 24);
                        }

                        return string.Format("{0}:{1}:{2}", hh.ToString("00"), mm.ToString("00"), ss.ToString("00"));
                    }
                    catch (Exception ex) { }
                    return string.Format("{0}:{1}:{2}", "00", "00", "00");
                }
                else
                {
                    return string.Format("{0}:{1}:{2}", "00", "00", "00");
                }
            }
        }

        /// <summary>
        /// Gets the opex ytd percentage.
        /// </summary>
        /// <value>
        /// The opex ytd percentage.
        /// </value>
        public decimal? OpexYTDPercentage { get { return (OpexBudget.GetValueOrDefault() > 0 ? OpexVariance / OpexBudget : 0) * 100; } }

        /// <summary>
        /// Gets the over under budget.
        /// </summary>
        /// <value>
        /// The over under budget.
        /// </value>
        public string OverUnderBudget { get { return OpexVariance.HasValue && OpexVariance < 0 ? "over Budget" : "under Budget"; } }

        /// <summary>
        /// Gets the score ratio display.
        /// </summary>
        /// <value>
        /// The score ratio display.
        /// </value>
        public double? ScoreRatioDisplay
        {
            get { return Math.Round(ScoreRatio.GetValueOrDefault(), 2); }
        }

        /// <summary>
        /// Gets the score ratio.
        /// </summary>
        /// <value>
        /// The score ratio.
        /// </value>
        public double? ScoreRatio
        {
            get
            {
                return OffSummaryTotalFleetSize.HasValue ? Math.Round(Convert.ToDouble(OffSummaryTotalRedEvents.GetValueOrDefault() / OffSummaryTotalFleetSize), 2) : default(double); ;
            }
        }

        /// <summary>
        /// Gets or sets the trend percent.
        /// </summary>
        /// <value>
        /// The trend percent.
        /// </value>
        public decimal TrendPercent
        {
            get
            {
                decimal? val = CalculateVariance(Convert.ToDecimal(OffSummaryMonthlyScore.GetValueOrDefault()), OffSummaryLastMonthScore.GetValueOrDefault());
                return
                    OffSummaryLastMonthScore.HasValue && OffSummaryLastMonthScore.Value != 0 ? Math.Round(val.GetValueOrDefault() / OffSummaryLastMonthScore.GetValueOrDefault() * 100, 0)
                    : Math.Round(val.GetValueOrDefault() * 100);
            }
        }

        /// <summary>
        /// Gets or sets the number affected kpi grpah.
        /// </summary>
        /// <value>
        /// The number affected kpi grpah.
        /// </value>
        public double NumAffectedKpiGrpah { get { return Convert.ToDouble(OffSummaryTotalKpimeasureAffected.GetValueOrDefault()); } }

        /// <summary>
        /// Gets the trend geometry.
        /// </summary>
        /// <value>
        /// The trend geometry.
        /// </value>
        public int TrendGeometry
        {
            get
            {
                if (OffSummaryMonthlyScore.GetValueOrDefault() > OffSummaryLastMonthScore.GetValueOrDefault())
                {
                    return -1;
                }
                else if (OffSummaryMonthlyScore.GetValueOrDefault() < OffSummaryLastMonthScore.GetValueOrDefault())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is summary average record.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is summary average record; otherwise, <c>false</c>.
        /// </value>
        public bool IsSummaryAverageRecord { get; set; }

        /// <summary>
        /// Gets the opex month diplay.
        /// </summary>
        /// <value>
        /// The opex month diplay.
        /// </value>
        public string OpexMonthDiplay
        {
            get
            {
                return OpexmonthYearDate.HasValue ? OpexmonthYearDate.Value.Date.ToString("MMM-yyyy") : null;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is opex visible.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is opex visible; otherwise, <c>false</c>.
        /// </value>
        public bool IsOpexVisible
        {
            get
            {
                return (!OpexRag.HasValue || OpexRag.GetValueOrDefault() == -3) ? false : (LeftManagementVessel.GetValueOrDefault() == true && Opex == null) ? false : true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is fuel efficiency visible.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is fuel efficiency visible; otherwise, <c>false</c>.
        /// </value>
        public bool IsFuelEfficiencyVisible
        {
            get
            {
                return (!FuelEfficiencyRag.HasValue || FuelEfficiencyRag.GetValueOrDefault() == -3) ? false : (LeftManagementVessel.GetValueOrDefault() == true && FuelEfficiency == null) ? false : true;
            }
        }
        #endregion

        #region Methods                        
        /// <summary>
        /// Gets the red vessel count tooltip.
        /// </summary>
        /// <param name="totalRedKpi">The total red kpi.</param>
        /// <param name="totalValidVessel">The total valid vessel.</param>
        /// <param name="kpiScore">The kpi score.</param>
        /// <returns>Single string.</returns>
        private string GetRedVesselCountTooltip(int? totalRedKpi, int? totalValidVessel, decimal? kpiScore)
        {
            string toolTip = string.Empty;

            toolTip = string.Format("Total Red KPIs: {0}\n", totalRedKpi.GetValueOrDefault());
            toolTip += string.Format("Total Applicable Vessels: {0}\n", totalValidVessel.GetValueOrDefault());

            if (kpiScore.HasValue)
            {
                toolTip += string.Format("KPI Score: {0}", Math.Round(kpiScore.Value, 2));
            }
            else
            {
                toolTip += "KPI Score: N/A";
            }

            return toolTip;
        }

        /// <summary>
        /// Calculates the variance.
        /// </summary>
        /// <param name="currentValue">The current value.</param>
        /// <param name="previousValue">The previous value.</param>
        /// <returns></returns>
        private decimal? CalculateVariance(decimal? currentValue, decimal? previousValue)
        {
            //to be confirmed
            decimal? ret = currentValue - previousValue.GetValueOrDefault();
            return ret;
        }

        /// <summary>
        /// Gets the combined trend tooltip.
        /// </summary>
        /// <param name="trendTooltip">The trend tooltip.</param>
        /// <param name="ratio">The ratio.</param>
        /// <returns></returns>
        public string GetCombinedTrendTooltip(string trendTooltip, decimal ratio)
        {
            return trendTooltip + " Trend = " + Math.Round(ratio, 2);
        }
        #endregion
    }
}
