﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.SSTechnicalManager
{
    /// <summary>
    /// Output contract for Historic Trends details
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class HistoricTrendsDetails : BaseViewModel
    {
        /// <summary>Gets or sets the Identifier field.</summary>
		public string Identifier { get; set; }
        /// <summary>Gets or sets the Descritption field.</summary>
        public string Descritption { get; set; }
        /// <summary>Gets or sets the ShortDescription field.</summary>
        public string ShortDescription { get; set; }
        /// <summary>Gets or sets the MonthDate field.</summary>
        public DateTime? MonthDate { get; set; }
        /// <summary>Gets or sets the MonthScore field.</summary>
        public Decimal? MonthScore { get; set; }
        /// <summary>Gets or sets the ColorRayg field.</summary>
        public Int32? ColorRayg { get; set; }
    }
}
