﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// 
    /// </summary>
    public class VesselUnderperformanceSpeedDetails
    {
        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
        /// <summary>
        /// Gets or sets the name of the CMP.
        /// </summary>
        /// <value>
        /// The name of the CMP.
        /// </value>
        public string CmpName { get; set; }
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }
        /// <summary>
        /// Gets or sets the fleet cell identifier.
        /// </summary>
        /// <value>
        /// The fleet cell identifier.
        /// </value>
        public string FleetCellId { get; set; }
        /// <summary>
        /// Gets or sets the fleet cell desc.
        /// </summary>
        /// <value>
        /// The fleet cell desc.
        /// </value>
        public string FleetCellDesc { get; set; }
        /// <summary>
        /// Gets or sets the charter number.
        /// </summary>
        /// <value>
        /// The charter number.
        /// </value>
        public string CharterNumber { get; set; }
        /// <summary>
        /// Gets or sets the charter voyage.
        /// </summary>
        /// <value>
        /// The charter voyage.
        /// </value>
        public string CharterVoyage { get; set; }
        /// <summary>
        /// Gets or sets the position identifier.
        /// </summary>
        /// <value>
        /// The position identifier.
        /// </value>
        public string PositionId { get; set; }
        /// <summary>
        /// Gets or sets the charter identifier.
        /// </summary>
        /// <value>
        /// The charter identifier.
        /// </value>
        public string CharterId { get; set; }
        /// <summary>
        /// Gets or sets the charter speed.
        /// </summary>
        /// <value>
        /// The charter speed.
        /// </value>
        public decimal? CharterSpeed { get; set; }
        /// <summary>
        /// Gets or sets the average speed.
        /// </summary>
        /// <value>
        /// The average speed.
        /// </value>
        public decimal? AvgSpeed { get; set; }
        /// <summary>
        /// Gets or sets the order fo fuel consumption.
        /// </summary>
        /// <value>
        /// The order fo fuel consumption.
        /// </value>
        public decimal? OrderFOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the average fo fuel consumption.
        /// </summary>
        /// <value>
        /// The average fo fuel consumption.
        /// </value>
        public decimal? AverageFOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the order lsfo fuel consumption.
        /// </summary>
        /// <value>
        /// The order lsfo fuel consumption.
        /// </value>
        public decimal? OrderLSFOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the average lsfo fuel consumption.
        /// </summary>
        /// <value>
        /// The average lsfo fuel consumption.
        /// </value>
        public decimal? AverageLSFOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the order do fuel consumption.
        /// </summary>
        /// <value>
        /// The order do fuel consumption.
        /// </value>
        public decimal? OrderDOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the average do fuel consumption.
        /// </summary>
        /// <value>
        /// The average do fuel consumption.
        /// </value>
        public decimal? AverageDOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the order go fuel consumption.
        /// </summary>
        /// <value>
        /// The order go fuel consumption.
        /// </value>
        public decimal? OrderGOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the average go fuel consumption.
        /// </summary>
        /// <value>
        /// The average go fuel consumption.
        /// </value>
        public decimal? AverageGOFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the order LNG fuel consumption.
        /// </summary>
        /// <value>
        /// The order LNG fuel consumption.
        /// </value>
        public decimal? OrderLNGFuelConsumption { get; set; }
        /// <summary>
        /// Gets or sets the average LNG fuel consumption.
        /// </summary>
        /// <value>
        /// The average LNG fuel consumption.
        /// </value>
        public decimal? AverageLNGFuelConsumption { get; set; }

        /// <summary>
        /// Gets the average speed display.
        /// </summary>
        /// <value>
        /// The average speed display.
        /// </value>
        public string AvgSpeedDisplay
        {
            get { return Math.Round((decimal)AvgSpeed, 3).ToString(); }
        }

        /// <summary>
        /// Gets the charter speed display.
        /// </summary>
        /// <value>
        /// The charter speed display.
        /// </value>
        public string CharterSpeedDisplay
        {
            get { return Math.Round((decimal)CharterSpeed, 3).ToString(); }
        }
    }
}
