﻿namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    public class FleetSuperintendentInvoiceRequestParameter
    {
        /// <summary>
        /// Gets or sets the type identifier.
        /// </summary>
        /// <value>
        /// The type identifier.
        /// </value>
        public int TypeId { get; set; }
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Identifier { get; set; }
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }
        /// <summary>
        /// The is entering MGMT
        /// </summary>
        public bool IsEnteringMgmt { get; set; }
        /// <summary>
        /// The is left MGMT
        /// </summary>
        public bool IsLeftMgmt { get; set; }
        /// <summary>
        /// The is leaving MGMT
        /// </summary>
        public bool IsLeavingMgmt { get; set; }
    }
}
