﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// 
    /// </summary>
    public class PurchaseInvoiceDetails
    {
        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        public string OfficeName { get; set; }
        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
        /// <summary>
        /// Gets or sets the vessel responsible office.
        /// </summary>
        /// <value>
        /// The vessel responsible office.
        /// </value>
        public string VesselResponsibleOffice { get; set; }
        /// <summary>
        /// Gets or sets the inc identifier.
        /// </summary>
        /// <value>
        /// The inc identifier.
        /// </value>
        public string IncId { get; set; }
        /// <summary>
        /// Gets or sets the po number.
        /// </summary>
        /// <value>
        /// The po number.
        /// </value>
        public string PONumber { get; set; }
        /// <summary>
        /// Gets or sets the order status.
        /// </summary>
        /// <value>
        /// The order status.
        /// </value>
        public string OrderStatus { get; set; }
        /// <summary>
        /// Gets or sets the name of the supplier.
        /// </summary>
        /// <value>
        /// The name of the supplier.
        /// </value>
        public string SupplierName { get; set; }
        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        public string Currency { get; set; }
        /// <summary>
        /// Gets or sets the total amount.
        /// </summary>
        /// <value>
        /// The total amount.
        /// </value>
        public decimal? TotalAmount { get; set; }
        /// <summary>
        /// Gets or sets the total usd amount.
        /// </summary>
        /// <value>
        /// The total usd amount.
        /// </value>
        public decimal? TotalUSDAmount { get; set; }
        /// <summary>
        /// Gets or sets the freight amount.
        /// </summary>
        /// <value>
        /// The freight amount.
        /// </value>
        public decimal? FreightAmount { get; set; }
        /// <summary>
        /// Gets or sets the order amount.
        /// </summary>
        /// <value>
        /// The order amount.
        /// </value>
        public decimal? OrderAmount { get; set; }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>
        /// The created date.
        /// </value>
        public DateTime? CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the allocated user.
        /// </summary>
        /// <value>
        /// The allocated user.
        /// </value>
        public string AllocatedUser { get; set; }
        /// <summary>
        /// Gets or sets the purchase contact.
        /// </summary>
        /// <value>
        /// The purchase contact.
        /// </value>
        public string PurchaseContact { get; set; }
        /// <summary>
        /// Gets or sets the tech contact.
        /// </summary>
        /// <value>
        /// The tech contact.
        /// </value>
        public string TechContact { get; set; }
        /// <summary>
        /// Gets or sets the invoice date.
        /// </summary>
        /// <value>
        /// The invoice date.
        /// </value>
        public DateTime? InvoiceDate { get; set; }
        /// <summary>
        /// Gets or sets the due date.
        /// </summary>
        /// <value>
        /// The due date.
        /// </value>
        public DateTime? DueDate { get; set; }
        /// <summary>
        /// Gets or sets the invoice number.
        /// </summary>
        /// <value>
        /// The invoice number.
        /// </value>
        public string InvoiceNumber { get; set; }
        /// <summary>
        /// Gets or sets the name of the po supplier.
        /// </summary>
        /// <value>
        /// The name of the po supplier.
        /// </value>
        public string POSupplierName { get; set; }

        /// <summary>
        /// Gets the total amount display.
        /// </summary>
        /// <value>
        /// The total amount display.
        /// </value>
        public string TotalAmountDisplay
        {
            get { return string.Format("{0}" + "(" + "{1}" + ")", Math.Round((decimal)TotalAmount, 2).ToString(), Currency); }
        }

        /// <summary>
        /// Gets the total usd amount display.
        /// </summary>
        /// <value>
        /// The total usd amount display.
        /// </value>
        public string TotalUSDAmountDisplay
        {
            get { return Math.Round((decimal)TotalUSDAmount, 2).ToString(); }
        }
    }
}
