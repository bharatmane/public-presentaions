﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// This class is OSAPendingForApprovalResponseDetails.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class OSAPendingForApprovalResponseDetails : BaseViewModel
    {
        #region API Properties

        /// <summary>
        /// Gets or sets the pending approval count.
        /// </summary>
        /// <value>
        /// The pending approval count.
        /// </value>
        public int? PendingApprovalCount { get; set; }

        /// <summary>
        /// Gets or sets the over due count.
        /// </summary>
        /// <value>
        /// The over due count.
        /// </value>
        public int OverDueCount { get; set; }

        /// <summary>
        /// Gets or sets the reschedule count.
        /// </summary>
        /// <value>
        /// The reschedule count.
        /// </value>
        public int RescheduleCount { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the job details identifier.
        /// </summary>
        /// <value>
        /// The job details identifier.
        /// </value>
        public string JobDetailsId { get; set; }

        /// <summary>
        /// Gets or sets the name of the osa.
        /// </summary>
        /// <value>
        /// The name of the osa.
        /// </value>
        public string OSAName { get; set; }

        /// <summary>
        /// Gets or sets the osa date.
        /// </summary>
        /// <value>
        /// The osa date.
        /// </value>
        public DateTime? OSADate { get; set; }

        /// <summary>
        /// Gets or sets the name of the port.
        /// </summary>
        /// <value>
        /// The name of the port.
        /// </value>
        public string PortName { get; set; }

        /// <summary>
        /// Gets or sets the crew count.
        /// </summary>
        /// <value>
        /// The crew count.
        /// </value>
        public int? CrewCount { get; set; }

        /// <summary>
        /// Gets or sets the submitted on.
        /// </summary>
        /// <value>
        /// The submitted on.
        /// </value>
        public DateTime? SubmittedOn { get; set; }

        /// <summary>
        /// Gets or sets the submitted to.
        /// </summary>
        /// <value>
        /// The submitted to.
        /// </value>
        public string SubmittedTo { get; set; }

        /// <summary>
        /// Gets or sets the osa status.
        /// </summary>
        /// <value>
        /// The osa status.
        /// </value>
        public string OsaStatus { get; set; }

        /// <summary>
        /// Gets or sets the osa approved on.
        /// </summary>
        /// <value>
        /// The osa approved on.
        /// </value>
        public DateTime? OsaApprovedOn { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the approval date.
        /// </summary>
        /// <value>
        /// The approval date.
        /// </value>
        public DateTime? ApprovalDate { get; set; }

        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="OSAPendingForApprovalResponseDetails"/> class.
        /// </summary>
        public OSAPendingForApprovalResponseDetails()
        {

        }

        #endregion
    }
}
