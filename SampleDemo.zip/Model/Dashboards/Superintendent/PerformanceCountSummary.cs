﻿namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{   /// <summary>
    /// 
    /// </summary>
    public class PerformanceCountSummary
    {
        /// <summary>
        /// Gets or sets the display name.
        /// </summary>
        /// <value>
        /// The display name.
        /// </value>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the total count.
        /// </summary>
        /// <value>
        /// The total count.
        /// </value>
        public string TotalCount { get; set; }
    }
}
