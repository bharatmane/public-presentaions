﻿using System;
using VShips.DataServices.Shared.Enumerations;
using VShips.DataServices.Shared.Enumerations.Vessel;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// This is details entity for drills and campaign
    /// </summary>
    public class DrillsAndCampaignOverviewResponseDetails : BaseViewModel
    {
        #region Api Properties
        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
        /// <summary>
        /// Gets or sets the DCD identifier.
        /// </summary>
        /// <value>
        /// The DCD identifier.
        /// </value>
        public string DcdId { get; set; }
        /// <summary>
        /// Gets or sets the VDC identifier.
        /// </summary>
        /// <value>
        /// The VDC identifier.
        /// </value>
        public string VdcId { get; set; }
        /// <summary>
        /// Gets or sets the refno.
        /// </summary>
        /// <value>
        /// The refno.
        /// </value>
        public string Refno { get; set; }
        /// <summary>
        /// Gets or sets the campaign reference no.
        /// </summary>
        /// <value>
        /// The campaign reference no.
        /// </value>
        public string CampaignRefNo { get; set; }
        /// <summary>
        /// Gets or sets the group description.
        /// </summary>
        /// <value>
        /// The group description.
        /// </value>
        public string GroupDescription
        {
            get
            {
                return !string.IsNullOrWhiteSpace(CategoryId) ? EnumsHelper.GetDescription((DrillCampaignCategory)Enum.Parse(typeof(DrillCampaignCategory),
                                                                                                EnumsHelper.GetEnumItemFromKeyValue(typeof(DrillCampaignCategory), CategoryId))) : null;
            }
        }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId { get; set; }
        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        public string Category { get; set; }
        /// <summary>
        /// Gets or sets the sub category.
        /// </summary>
        /// <value>
        /// The sub category.
        /// </value>
        public string SubCategory { get; set; }
        /// <summary>
        /// Gets or sets the due date.
        /// </summary>
        /// <value>
        /// The due date.
        /// </value>
        public DateTime? DueDate { get; set; }
        /// <summary>
        /// Gets or sets the interval value.
        /// </summary>
        /// <value>
        /// The interval value.
        /// </value>
        public int IntervalValue { get; set; }
        /// <summary>
        /// Gets or sets the short name of the interval.
        /// </summary>
        /// <value>
        /// The short name of the interval.
        /// </value>
        public string IntervalShortName { get; set; }
        /// <summary>
        /// Gets or sets the name of the interval.
        /// </summary>
        /// <value>
        /// The name of the interval.
        /// </value>
        public string IntervalName { get; set; }
        /// <summary>
        /// Gets or sets the RNK identifier responsibility.
        /// </summary>
        /// <value>
        /// The RNK identifier responsibility.
        /// </value>
        public string RnkIdResponsibility { get; set; }
        /// <summary>
        /// Gets or sets the RNK description.
        /// </summary>
        /// <value>
        /// The RNK description.
        /// </value>
        public string RnkDescription { get; set; }
        /// <summary>
        /// Gets or sets the RNK short code.
        /// </summary>
        /// <value>
        /// The RNK short code.
        /// </value>
        public string RnkShortCode { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [allow navigation].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [allow navigation]; otherwise, <c>false</c>.
        /// </value>
        public bool AllowNavigation { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is standing.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is standing; otherwise, <c>false</c>.
        /// </value>
        public bool IsStanding { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is critical.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is critical; otherwise, <c>false</c>.
        /// </value>
        public bool IsCritical { get; set; }
        /// <summary>
        /// Gets or sets the DCL identifier status.
        /// </summary>
        /// <value>
        /// The DCL identifier status.
        /// </value>
        public string DclIdStatus { get; set; }
        /// <summary>
        /// Gets or sets the is not planned.
        /// </summary>
        /// <value>
        /// The is not planned.
        /// </value>
        public bool? IsNotPlanned { get; set; }

        /// <summary>
        /// Gets or sets the is due.
        /// </summary>
        /// <value>
        /// The is due.
        /// </value>
        public bool? IsDue { get; set; }

        /// <summary>
        /// Gets or sets the is overdue.
        /// </summary>
        /// <value>
        /// The is overdue.
        /// </value>
        public bool? IsOverdue { get; set; }

        /// <summary>
        /// Gets the reference no display.
        /// </summary>
        /// <value>
        /// The reference no display.
        /// </value>
        public string RefNoDisplay
        {
            get
            {
                return !string.IsNullOrWhiteSpace(CampaignRefNo) ? CampaignRefNo : string.IsNullOrWhiteSpace(DcdId) ? string.Format("{0}{1}", "V\\", !string.IsNullOrWhiteSpace(Refno) ? Refno : "0") : string.Format("{0}{1}", "O\\", Refno);
            }
        }

        /// <summary>
        /// Gets or sets the interval display.
        /// </summary>
        /// <value>
        /// The interval display.
        /// </value>
        public string IntervalDisplay
        {
            get
            {
                return !string.IsNullOrWhiteSpace(IntervalName) && IntervalValue != 0 ? string.Format("{0} {1}", IntervalValue, IntervalName) : null;
            }
        }

        /// <summary>
        /// Gets the status display.
        /// </summary>
        /// <value>
        /// The status display.
        /// </value>
        public string StatusDisplay
        {
            get
            {
                //EnumsHelper.GetEnumItemFromKeyValue(typeof(DrillCampaignStatus), DclIdStatus)
                return !string.IsNullOrWhiteSpace(DclIdStatus) ? EnumsHelper.GetDescription((DrillCampaignStatus)Enum.Parse(typeof(DrillCampaignStatus),
                                                                                                EnumsHelper.GetEnumItemFromKeyValue(typeof(DrillCampaignStatus), DclIdStatus))) : null;
            }
        }
        #endregion
    }
}
