﻿using VShips.Framework.Common.ViewModel;
using Sdcontracts.Enums.Common;
using Newtonsoft.Json;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// This is request parameter for drills and campaign
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class DrillAndCampaignDetailsRequestParameter:BaseViewModel
    {
        /// <summary>
        /// Gets or sets the type of the parameter.
        /// </summary>
        /// <value>
        /// The type of the parameter.
        /// </value>
        [JsonProperty("ParameterType")]
        public QueryParameterType ParameterType { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [JsonProperty("Identifier")]
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is show not planned.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is show not planned; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("IsShowNotPlanned")]
        public bool IsShowNotPlanned { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is show due.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is show due; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("IsShowDue")]
        public bool IsShowDue { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is show over due.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is show over due; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("IsShowOverDue")]
        public bool IsShowOverDue { get; set; }

        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        [JsonProperty("CategoryId")]
        public string CategoryId { get; set; }

        /// <summary>
        /// The is entering MGMT
        /// </summary>
        [JsonProperty("IsEnteringMgmt")]
        public bool IsEnteringMgmt { get; set; }

        /// <summary>
        /// The is left MGMT
        /// </summary>
        [JsonProperty("IsLeftMgmt")]
        public bool IsLeftMgmt { get; set; }

        /// <summary>
        /// The is leaving MGMT
        /// </summary>
        [JsonProperty("IsLeavingMgmt")]
        public bool IsLeavingMgmt { get; set; }

        /// <summary>
        /// Gets or sets the type identifier.
        /// </summary>
        /// <value>
        /// The type identifier.
        /// </value>
        [JsonProperty("TypeId")]
        public int TypeId { get; set; }
    }
}
