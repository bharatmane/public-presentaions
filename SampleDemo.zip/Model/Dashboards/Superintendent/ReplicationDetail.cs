﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// This class is ReplicationDetail.
    /// </summary>
    public class ReplicationDetail
    {
        /// <summary>
        /// Gets or sets the last replicated date.
        /// </summary>
        /// <value>
        /// The last replicated date.
        /// </value>
        public DateTime LastReplicatedDate { get; set; }

        /// <summary>Gets or sets the overdue replication days.</summary>
        /// <value>The overdue replication days.</value>
        public int OverdueReplicationDays { get; set; }

        /// <summary>Gets or sets the transport desc.</summary>
        /// <value>The transport desc.</value>
        public string TransportDesc { get; set; }

        /// <summary>Gets or sets the ves identifier.</summary>
        /// <value>The ves identifier.</value>
        public string VesId { get; set; }

        /// <summary>Gets or sets the name of the ves.</summary>
        /// <value>The name of the ves.</value>
        public string VesName { get; set; }

        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
    }
}
