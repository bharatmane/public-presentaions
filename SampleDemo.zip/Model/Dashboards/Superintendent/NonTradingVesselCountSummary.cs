﻿namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// This class is NonTradingVesselCountSummary for return type of left side count.
    /// </summary>
    public class NonTradingVesselCountSummary
    {
        #region Properties

        /// <summary>Gets or sets the display name.</summary>
        /// <value>The display name.</value>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the non trading vessel count.
        /// </summary>
        /// <value>
        /// The non trading vessel count.
        /// </value>
        public int NonTradingVesselCount { get; set; }

        #endregion
    }
}
