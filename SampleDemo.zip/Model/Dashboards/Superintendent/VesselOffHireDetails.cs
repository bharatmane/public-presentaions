﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// 
    /// </summary>
    public class VesselOffHireDetails
    {

        #region Properties

        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
        /// <summary>
        /// Gets or sets the name of the CMP.
        /// </summary>
        /// <value>
        /// The name of the CMP.
        /// </value>
        public string CmpName { get; set; }
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }
        /// <summary>
        /// Gets or sets the fleet cell identifier.
        /// </summary>
        /// <value>
        /// The fleet cell identifier.
        /// </value>
        public string FleetCellId { get; set; }
        /// <summary>
        /// Gets or sets the fleet cell desc.
        /// </summary>
        /// <value>
        /// The fleet cell desc.
        /// </value>
        public string FleetCellDesc { get; set; }
        /// <summary>
        /// Gets or sets the type of the off hire.
        /// </summary>
        /// <value>
        /// The type of the off hire.
        /// </value>
        public string OffHireType { get; set; }
        /// <summary>
        /// Gets or sets the duration hours.
        /// </summary>
        /// <value>
        /// The duration hours.
        /// </value>
        public decimal DurationHours { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [more than24 hour].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [more than24 hour]; otherwise, <c>false</c>.
        /// </value>
        public bool MoreThan24Hour { get; set; }
        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }
        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime? ToDate { get; set; }
        /// <summary>
        /// Gets or sets the position identifier.
        /// </summary>
        /// <value>
        /// The position identifier.
        /// </value>
        public string PositionId { get; set; }
        /// <summary>
        /// Gets or sets the position from date.
        /// </summary>
        /// <value>
        /// The position from date.
        /// </value>
        public DateTime? PositionFromDate { get; set; }
        /// <summary>
        /// Gets or sets the position to date.
        /// </summary>
        /// <value>
        /// The position to date.
        /// </value>
        public DateTime? PositionToDate { get; set; }

        /// <summary>
        /// Gets the duration hours display.
        /// </summary>
        /// <value>
        /// The duration hours display.
        /// </value>
        public string DurationHoursDisplay
        {
            get
            {
                return Math.Round((decimal)DurationHours, 2).ToString();
            }
        }

        /// <summary>
        /// Gets the more than24 hours display.
        /// </summary>
        /// <value>
        /// The more than24 hours display.
        /// </value>
        public string MoreThan24HoursDisplay
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the duration.
        /// </summary>
        /// <value>
        /// The duration.
        /// </value>
        //public decimal Duration { get; set; }

        /// <summary>
        /// Gets the duration of the formatted.
        /// </summary>
        /// <value>
        /// The duration of the formatted.
        /// </value>
        public string FormattedDuration
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the name of the activity.
        /// </summary>
        /// <value>
        /// The name of the activity.
        /// </value>
        public string ActivityName { get; set; }

        /// <summary>
        /// Gets or sets the type of the offhire activity.
        /// </summary>
        /// <value>
        /// The type of the offhire activity.
        /// </value>
        public string OffhireActivityType { get; set; }

        /// <summary>
        /// Gets or sets the type of the PLK identifier off hire.
        /// </summary>
        /// <value>
        /// The type of the PLK identifier off hire.
        /// </value>
        public string PlkIdOffHireType { get; set; }

        #endregion

        #region Constructor        
        /// <summary>
        /// Initializes a new instance of the <see cref="VesselOffHireDetails"/> class.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public VesselOffHireDetails(VesselOffHireDetails entity)
        {
            if (entity != null)
            {
                PositionId = entity.PositionId;
                VesId = entity.VesId;
                VesselName = entity.VesselName;
                TechFleetName = entity.TechFleetName;
                FleetCellId = entity.FleetCellId;
                FleetCellDesc = entity.FleetCellDesc;
                CmpName = entity.CmpName;
                OffHireType = entity.OffHireType;
                FromDate = entity.FromDate;
                ToDate = entity.ToDate;
                PositionFromDate = entity.PositionFromDate;
                PositionToDate = entity.PositionToDate;
                MoreThan24HoursDisplay = entity.MoreThan24Hour ? "Yes" : "No";
                ActivityName = entity.ActivityName;
                OffhireActivityType = entity.OffhireActivityType;
                PlkIdOffHireType = entity.PlkIdOffHireType;
                if (FromDate.HasValue && ToDate.HasValue)
                {

                    //FormattedDuration = duration.ToString(@"hh\:mm");
                    TimeSpan duration = ToDate.Value.Subtract(FromDate.Value);

                    long durationTicks = Math.Abs(duration.Ticks / TimeSpan.TicksPerMillisecond);
                    long hours = durationTicks / (1000 * 60 * 60);
                    long minutes = (durationTicks - (hours * 60 * 60 * 1000)) / (1000 * 60);
                    //Duration = Convert.ToDecimal(hours) + Convert.ToDecimal(minutes / 100.00);
                    FormattedDuration = hours.ToString("00") + ":" + minutes.ToString("00");

                }
            }
        }
        #endregion

    }
}
