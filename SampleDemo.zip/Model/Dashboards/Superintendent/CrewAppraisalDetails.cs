﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// The Crew Appraisal Details 
    /// </summary>
    public class CrewAppraisalDetails
    {
        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
        /// <summary>
        /// Gets or sets the CRW identifier.
        /// </summary>
        /// <value>
        /// The CRW identifier.
        /// </value>
        public string CrwId { get; set; }
        /// <summary>
        /// Gets or sets the full name of the CRW.
        /// </summary>
        /// <value>
        /// The full name of the CRW.
        /// </value>
        public string CrwFullName { get; set; }
        /// <summary>
        /// Gets or sets the CRW PCN number.
        /// </summary>
        /// <value>
        /// The CRW PCN number.
        /// </value>
        public string CrwPCNNumber { get; set; }
        /// <summary>
        /// Gets or sets the CRW rank.
        /// </summary>
        /// <value>
        /// The CRW rank.
        /// </value>
        public string CrwRank { get; set; }
        /// <summary>
        /// Gets or sets the planning cell.
        /// </summary>
        /// <value>
        /// The planning cell.
        /// </value>
        public string PlanningCell { get; set; }
        /// <summary>
        /// Gets or sets the planning cell MGR.
        /// </summary>
        /// <value>
        /// The planning cell MGR.
        /// </value>
        public string PlanningCellMgr { get; set; }
        /// <summary>
        /// Gets or sets the mobilisation cell.
        /// </summary>
        /// <value>
        /// The mobilisation cell.
        /// </value>
        public string MobilisationCell { get; set; }
        /// <summary>
        /// Gets or sets the mobilisation cell MGR.
        /// </summary>
        /// <value>
        /// The mobilisation cell MGR.
        /// </value>
        public string MobilisationCellMgr { get; set; }
        /// <summary>
        /// Gets or sets the crew sign on date.
        /// </summary>
        /// <value>
        /// The crew sign on date.
        /// </value>
        public DateTime? CrewSignOnDate { get; set; }
        /// <summary>
        /// Gets or sets the crew sign off date.
        /// </summary>
        /// <value>
        /// The crew sign off date.
        /// </value>
        public DateTime? CrewSignOffDate { get; set; }
        /// <summary>
        /// Gets or sets the CRW rank sequence number.
        /// </summary>
        /// <value>
        /// The CRW rank sequence number.
        /// </value>
        public string CrwRankSequenceNumber { get; set; }
        /// <summary>
        /// Gets or sets the name of the superintendent.
        /// </summary>
        /// <value>
        /// The name of the superintendent.
        /// </value>
        public string SuperintendentName { get; set; }
        /// <summary>
        /// Gets or sets the note.
        /// </summary>
        /// <value>
        /// The note.
        /// </value>
        public string Note { get; set; }
        /// <summary>
        /// Gets or sets the nationality.
        /// </summary>
        /// <value>
        /// The nationality.
        /// </value>
        public string Nationality { get; set; }
        /// <summary>
        /// Gets or sets the appraisal due date.
        /// </summary>
        /// <value>
        /// The appraisal due date.
        /// </value>
        public DateTime? AppraisalDueDate { get; set; }
        /// <summary>
        /// Gets or sets the last appraisal date.
        /// </summary>
        /// <value>
        /// The last appraisal date.
        /// </value>
        public DateTime? LastAppraisalDate { get; set; }
        /// <summary>
        /// Gets or sets the appraisal count.
        /// </summary>
        /// <value>
        /// The appraisal count.
        /// </value>
        public int? AppraisalCount { get; set; }
        /// <summary>
        /// Gets or sets the appraisal reason identifier.
        /// </summary>
        /// <value>
        /// The appraisal reason identifier.
        /// </value>
        public string AppraisalReasonId { get; set; }
        /// <summary>
        /// Gets or sets the appraisal reason.
        /// </summary>
        /// <value>
        /// The appraisal reason.
        /// </value>
        public string AppraisalReason { get; set; }
        /// <summary>
        /// Gets or sets the appraisal reason short code.
        /// </summary>
        /// <value>
        /// The appraisal reason short code.
        /// </value>
        public string AppraisalReasonShortCode { get; set; }
    }
}
