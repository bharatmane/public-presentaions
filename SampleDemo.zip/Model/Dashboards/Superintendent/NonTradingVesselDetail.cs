﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// This class is NonTradingVesselDetail which is output contract for non-trading vessel details.
    /// </summary>
    public class NonTradingVesselDetail
    {
        #region Properties

        /// <summary>Gets or sets the ves identifier.</summary>
        /// <value>The ves identifier.</value>
        public string VesId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets the activated on.
        /// </summary>
        /// <value>
        /// The activated on.
        /// </value>
        public DateTime? ActivatedOn { get; set; }

        /// <summary>
        /// Gets or sets the postponement days.
        /// </summary>
        /// <value>
        /// The postponement days.
        /// </value>
        public int? PostponementDays { get; set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="NonTradingVesselDetail"/> class.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public NonTradingVesselDetail(NonTradingVesselDetail entity)
        {
            if (entity != null)
            {
                VesId = entity.VesId;
                VesselName = entity.VesselName;
                TechFleetName = entity.TechFleetName;
                StartDate = entity.StartDate;
                ActivatedOn = entity.ActivatedOn;
                PostponementDays = entity.PostponementDays;
            }
        }

        #endregion
    }
}
