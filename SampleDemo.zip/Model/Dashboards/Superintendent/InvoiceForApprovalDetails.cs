﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.Superintendent
{
    /// <summary>
    /// The Invoice For Approval Details
    /// </summary>
    public class InvoiceForApprovalDetails
    {
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }
        /// <summary>
        /// Gets or sets the inh voucher.
        /// </summary>
        /// <value>
        /// The inh voucher.
        /// </value>
        public string InhVoucher { get; set; }
        /// <summary>
        /// Gets or sets the inh identifier.
        /// </summary>
        /// <value>
        /// The inh identifier.
        /// </value>
        public string InhId { get; set; }
        /// <summary>
        /// Gets or sets the inh vessel.
        /// </summary>
        /// <value>
        /// The inh vessel.
        /// </value>
        public string InhVessel { get; set; }
        /// <summary>
        /// Gets or sets the name of the CMP.
        /// </summary>
        /// <value>
        /// The name of the CMP.
        /// </value>
        public string CmpName { get; set; }
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
        /// <summary>
        /// Gets or sets the inh sup inv.
        /// </summary>
        /// <value>
        /// The inh sup inv.
        /// </value>
        public string InhSupInv { get; set; }
        /// <summary>
        /// Gets or sets the inh text.
        /// </summary>
        /// <value>
        /// The inh text.
        /// </value>
        public string InhText { get; set; }
        /// <summary>
        /// Gets or sets the inh date sup pay.
        /// </summary>
        /// <value>
        /// The inh date sup pay.
        /// </value>
        public DateTime? InhDateSupPay { get; set; }
        /// <summary>
        /// Gets or sets the inh total curr.
        /// </summary>
        /// <value>
        /// The inh total curr.
        /// </value>
        public Decimal? InhTotalCurr { get; set; }
        /// <summary>
        /// Gets or sets the current identifier.
        /// </summary>
        /// <value>
        /// The current identifier.
        /// </value>
        public string CurId { get; set; }
        /// <summary>
        /// Gets or sets the inh total usd.
        /// </summary>
        /// <value>
        /// The inh total usd.
        /// </value>
        public Decimal? InhTotalUsd { get; set; }
        /// <summary>
        /// Gets or sets the maxacc.
        /// </summary>
        /// <value>
        /// The maxacc.
        /// </value>
        public string maxacc { get; set; }
        /// <summary>
        /// Gets or sets the cntacc.
        /// </summary>
        /// <value>
        /// The cntacc.
        /// </value>
        public int cntacc { get; set; }
        /// <summary>
        /// Gets or sets the ast origin.
        /// </summary>
        /// <value>
        /// The ast origin.
        /// </value>
        public string AstOrigin { get; set; }
        /// <summary>
        /// Gets or sets the inh status.
        /// </summary>
        /// <value>
        /// The inh status.
        /// </value>
        public int InhStatus { get; set; }
        /// <summary>
        /// Gets or sets the inh date sup inv.
        /// </summary>
        /// <value>
        /// The inh date sup inv.
        /// </value>
        public DateTime? InhDateSupInv { get; set; }
        /// <summary>
        /// Gets or sets the previous inh identifier.
        /// </summary>
        /// <value>
        /// The previous inh identifier.
        /// </value>
        public string PreviousInhId { get; set; }
        /// <summary>
        /// Gets or sets the attribute.
        /// </summary>
        /// <value>
        /// The attribute.
        /// </value>
        public int Attribute { get; set; }
        /// <summary>
        /// Gets or sets the inh indid.
        /// </summary>
        /// <value>
        /// The inh indid.
        /// </value>
        public string InhIndid { get; set; }
        /// <summary>
        /// Gets or sets the type of the inh journal.
        /// </summary>
        /// <value>
        /// The type of the inh journal.
        /// </value>
        public string InhJournalType { get; set; }
        /// <summary>
        /// Gets or sets the inh order.
        /// </summary>
        /// <value>
        /// The inh order.
        /// </value>
        public string InhOrder { get; set; }
        /// <summary>
        /// Gets or sets the JRN short desc.
        /// </summary>
        /// <value>
        /// The JRN short desc.
        /// </value>
        public string JrnShortDesc { get; set; }
        /// <summary>
        /// Gets or sets the ast identifier.
        /// </summary>
        /// <value>
        /// The ast identifier.
        /// </value>
        public string AstId { get; set; }
        /// <summary>
        /// Gets or sets the inh origin.
        /// </summary>
        /// <value>
        /// The inh origin.
        /// </value>
        public string InhOrigin { get; set; }

        /// <summary>
        /// Gets the account number.
        /// </summary>
        /// <value>
        /// The account number.
        /// </value>
        public string AccountNumber
        {
            get
            {
                if (cntacc == 1)
                {
                    return maxacc;
                }
                else if (cntacc == 0)
                {
                    return null;
                }
                return "<Multiple>";
            }
        }
        /// <summary>
        /// Gets the invoice aged days.
        /// </summary>
        /// <value>
        /// The invoice aged days.
        /// </value>
        public int InvoiceAgedDays
        {
            get
            {
                if (InhDateSupInv.HasValue && InhDateSupInv.Value < DateTime.Now.Date)
                {
                    return DateTime.Now.Date.Subtract(InhDateSupInv.Value).Days;
                }
                return 0;
            }
        }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the name of the tech fleet.
        /// </summary>
        /// <value>
        /// The name of the tech fleet.
        /// </value>
        public string TechFleetName { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is started as commitment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is started as commitment; otherwise, <c>false</c>.
        /// </value>
        public bool IsStartedAsCommitment { get; set; }

        /// <summary>
        /// Gets the invoice total amount display.
        /// </summary>
        /// <value>
        /// The invoice total amount display.
        /// </value>
        public string InvoiceTotalAmountDisplay
        {
            get { return Math.Round((decimal)InhTotalCurr,2).ToString(); }
        }
        /// <summary>
        /// Gets the invoice total amount usd display.
        /// </summary>
        /// <value>
        /// The invoice total amount usd display.
        /// </value>
        public string InvoiceTotalAmountUSDDisplay
        {
            get { return Math.Round((decimal)InhTotalUsd,2).ToString(); }
        }
    }
}
