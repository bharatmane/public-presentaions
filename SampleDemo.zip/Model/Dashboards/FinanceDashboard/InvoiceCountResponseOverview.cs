﻿using System.Collections.Generic;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{   /// <summary>
    /// The class for Invoice Count Overview
    /// </summary>
    public class InvoiceCountResponseOverview : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyID { get; set; }
        /// <summary>
        /// Gets or sets the name of the coy.
        /// </summary>
        /// <value>
        /// The name of the coy.
        /// </value>
        public string CoyName { get; set; }
        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the pending invoice count.
        /// </summary>
        /// <value>
        /// The pending invoice count.
        /// </value>
        public int PendingInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the dispute invoice count.
        /// </summary>
        /// <value>
        /// The dispute invoice count.
        /// </value>
        public int DisputeInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the available for post invoice count.
        /// </summary>
        /// <value>
        /// The available for post invoice count.
        /// </value>
        public int AvailableForPostInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the posted invoice count.
        /// </summary>
        /// <value>
        /// The posted invoice count.
        /// </value>
        public int PostedInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the confirm invoice count.
        /// </summary>
        /// <value>
        /// The confirm invoice count.
        /// </value>
        public int ConfirmInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the finalize invoice count.
        /// </summary>
        /// <value>
        /// The finalize invoice count.
        /// </value>
        public int FinalizeInvoiceCount { get; set; }

        /// <summary>
        /// Gets or sets the Discount invoice count.
        /// </summary>
        public int DiscountInvoiceCount { get; set; }

        /// <summary>
        /// Gets or sets the pending invoice amount usd total.
        /// </summary>
        /// <value>
        /// The pending invoice amount usd total.
        /// </value>
        public decimal PendingInvoiceAmountUSDTotal { get; set; }
        /// <summary>
        /// Gets or sets the disputed invoice amount usd total.
        /// </summary>
        /// <value>
        /// The disputed invoice amount usd total.
        /// </value>
        public decimal DisputedInvoiceAmountUSDTotal { get; set; }
        /// <summary>
        /// Gets or sets the available for posting invoice amount usd total.
        /// </summary>
        /// <value>
        /// The available for posting invoice amount usd total.
        /// </value>
        public decimal AvailableForPostingInvoiceAmountUSDTotal { get; set; }
        /// <summary>
        /// Gets or sets the posted invoice amount usd total.
        /// </summary>
        /// <value>
        /// The posted invoice amount usd total.
        /// </value>
        public decimal PostedInvoiceAmountUSDTotal { get; set; }
        /// <summary>
        /// Gets or sets the confirm invoice amount usd total.
        /// </summary>
        /// <value>
        /// The confirm invoice amount usd total.
        /// </value>
        public decimal ConfirmInvoiceAmountUSDTotal { get; set; }
        /// <summary>
        /// Gets or sets the finalize invoice amount usd total.
        /// </summary>
        /// <value>
        /// The finalize invoice amount usd total.
        /// </value>
        public decimal FinalizeInvoiceAmountUSDTotal { get; set; }

        /// <summary>
        /// Gets or sets the discount invoice amount usd total.
        /// </summary>
        /// <value>
        /// The discount invoice amount usd total.
        /// </value>
        public decimal DiscountInvoiceAmountUSDTotal { get; set; }

        /// <summary>
        /// Gets or sets the journal awaiting approval.
        /// </summary>
        /// <value>
        /// The journal awaiting approval.
        /// </value>
        public int JournalAwaitingApproval { get; set; }

        /// <summary>
        /// The vessel invoice pie chart count summary
        /// </summary>
        private List<DashboardPiechartDetailsViewModel> _vesselInvoicePieChartCountSummary;

        /// <summary>
        /// Gets or sets the vessel invoice pie chart count summary.
        /// </summary>
        /// <value>
        /// The vessel invoice pie chart count summary.
        /// </value>
        public List<DashboardPiechartDetailsViewModel> VesselInvoicePieChartCountSummary
        {
            get { return _vesselInvoicePieChartCountSummary; }
            set { Set(() => VesselInvoicePieChartCountSummary, ref _vesselInvoicePieChartCountSummary, value); }
        }
    }
}
