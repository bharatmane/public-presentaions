﻿using Newtonsoft.Json;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// Request Parameter type for Invoice 
    /// </summary>
    public class InvoiceRequestParameters
    {
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        [JsonProperty("UserIdentifier")]
        public string UserIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [JsonProperty("Identifier")]
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets the type of the menu item.
        /// </summary>
        /// <value>
        /// The type of the menu item.
        /// </value>
        [JsonProperty("MenuItemType")]
        public string MenuItemType { get; set; }

        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        [JsonProperty("CoyId")]
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the invoice status.
        /// </summary>
        /// <value>
        /// The invoice status.
        /// </value>
        [JsonProperty("InvoiceStatus")]
        public string InvoiceStatus { get; set; }

        /// <summary>
        /// Gets or sets the type of the company priority.
        /// </summary>
        /// <value>
        /// The type of the company priority.
        /// </value>
        [JsonProperty("CompanyPriorityType")]
        public int? CompanyPriorityType { get; set; }

        /// <summary>
        /// Gets or sets the Is For Discount Invoice
        /// </summary>
        [JsonProperty("IsForDiscountedInvoice")]
        public bool IsForDiscountedInvoice { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is for disputed invoice.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is for disputed invoice; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("IsForDisputedInvoice")]
        public bool IsForDisputedInvoice { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is show all awaiting approval.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is show all awaiting approval; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("IsShowAllAwaitingApproval")]
        public bool IsShowAllAwaitingApproval { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is credit note.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is credit note; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("IsCreditNote")]
        public bool IsCreditNote { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [journal detail type].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [journal detail type]; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty("JournalDetailType")]
        public int JournalDetailType { get; set; }
    }
}
