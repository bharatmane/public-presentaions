﻿using System;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// class for pending activities details
    /// </summary>
    public class PendingActivitiesOverviewDetails
    {
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }
        /// <summary>
        /// Gets or sets the name of the accounting company.
        /// </summary>
        /// <value>
        /// The name of the accounting company.
        /// </value>
        public string AccountingCompanyName { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is coy inactive.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is coy inactive; otherwise, <c>false</c>.
        /// </value>
        public bool IsCoyInactive { get; set; }

        /// <summary>
        /// Gets or sets the genereal ledger cut of date.
        /// </summary>
        /// <value>
        /// The genereal ledger cut of date.
        /// </value>
        public DateTime? GenerealLedgerCutOfDate { get; set; }
        /// <summary>
        /// Gets or sets the purchase ledger cut of date.
        /// </summary>
        /// <value>
        /// The purchase ledger cut of date.
        /// </value>
        public DateTime? PurchaseLedgerCutOfDate { get; set; }
        /// <summary>
        /// Gets or sets the agent ledger cut of date.
        /// </summary>
        /// <value>
        /// The agent ledger cut of date.
        /// </value>
        public DateTime? AgentLedgerCutOfDate { get; set; }
        /// <summary>
        /// Gets or sets the sales ledger cut off date.
        /// </summary>
        /// <value>
        /// The sales ledger cut off date.
        /// </value>
        public DateTime? SalesLedgerCutOffDate { get; set; }
        /// <summary>
        /// Gets or sets the financial year start date.
        /// </summary>
        /// <value>
        /// The financial year start date.
        /// </value>
        public DateTime? FinancialYearStartDate { get; set; }
        /// <summary>
        /// Gets or sets the financial year end date.
        /// </summary>
        /// <value>
        /// The financial year end date.
        /// </value>
        public DateTime? FinancialYearEndDate { get; set; }
        /// <summary>
        /// Gets or sets the last reval date.
        /// </summary>
        /// <value>
        /// The last reval date.
        /// </value>
        public DateTime? LastRevalDate { get; set; }
        /// <summary>
        /// Gets or sets the last depreciation date.
        /// </summary>
        /// <value>
        /// The last depreciation date.
        /// </value>
        public DateTime? LastDepreciationDate { get; set; }
        /// <summary>
        /// Gets or sets the unrecorded assets invoice count.
        /// </summary>
        /// <value>
        /// The unrecorded assets invoice count.
        /// </value>
        public int? UnrecordedAssetsInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the unrecorded assets ledger count.
        /// </summary>
        /// <value>
        /// The unrecorded assets ledger count.
        /// </value>
        public int? UnrecordedAssetsLedgerCount { get; set; }
        /// <summary>
        /// Gets or sets the purchase order count.
        /// </summary>
        /// <value>
        /// The purchase order count.
        /// </value>
        public int? PurchaseOrderCount { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [unrecorded assets invoice selected].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [unrecorded assets invoice selected]; otherwise, <c>false</c>.
        /// </value>
        public bool UnrecordedAssetsInvoiceSelected { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [unrecorded assets ledger selected].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [unrecorded assets ledger selected]; otherwise, <c>false</c>.
        /// </value>
        public bool UnrecordedAssetsLedgerSelected { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [purchase order selected].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [purchase order selected]; otherwise, <c>false</c>.
        /// </value>
        public bool PurchaseOrderSelected { get; set; }
    }
}
