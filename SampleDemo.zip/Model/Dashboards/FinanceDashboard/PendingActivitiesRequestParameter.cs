﻿namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// Class to set input request of pending activities 
    /// </summary>
    public class PendingActivitiesRequestParameter
    {
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets the type of the menu item.
        /// </summary>
        /// <value>
        /// The type of the menu item.
        /// </value>
        public string MenuItemType { get; set; }

        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the type of the pending activity.
        /// </summary>
        /// <value>
        /// The type of the pending activity.
        /// </value>
        public string PendingActivityType { get; set; }

        /// <summary>
        /// Gets or sets the type of the pending activity sub.
        /// </summary>
        /// <value>
        /// The type of the pending activity sub.
        /// </value>
        public string PendingActivitySubType { get; set; }

        /// <summary>
        /// Gets or sets the type identifier.
        /// </summary>
        /// <value>
        /// The type identifier.
        /// </value>
        public int TypeId { get; set; }
    }
}
