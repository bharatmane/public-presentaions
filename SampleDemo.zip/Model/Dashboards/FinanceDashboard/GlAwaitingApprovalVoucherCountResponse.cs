﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// Gl Awaiting Approval Voucher Count Response
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class GlAwaitingApprovalVoucherCountResponse : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the voucher count.
        /// </summary>
        /// <value>
        /// The voucher count.
        /// </value>
        public int? VoucherCount { get; set; }
    }
}
