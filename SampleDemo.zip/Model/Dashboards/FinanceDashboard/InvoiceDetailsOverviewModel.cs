﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{   /// <summary>
    /// Invoice Line Details
    /// </summary>
    public class InvoiceDetailsOverviewModel : BaseViewModel
    {
        #region API Properties
        
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }

        /// <summary>
        /// Gets or sets the name of the supplier company.
        /// </summary>
        /// <value>
        /// The name of the supplier company.
        /// </value>
        public string SupplierCompanyName { get; set; }

        /// <summary>
        /// Gets or sets the inh identifier.
        /// </summary>
        /// <value>
        /// The inh identifier.
        /// </value>
        public string InhId { get; set; }

        /// <summary>
        /// Gets or sets the inh status.
        /// </summary>
        /// <value>
        /// The inh status.
        /// </value>
        public int? InhStatus { get; set; }

        /// <summary>
        /// Gets or sets the invoice supply date.
        /// </summary>
        /// <value>
        /// The invoice supply date.
        /// </value>
        public DateTime? InvoiceSupplyDate { get; set; }

        /// <summary>
        /// Gets or sets the invoice due date.
        /// </summary>
        /// <value>
        /// The invoice due date.
        /// </value>
        public DateTime? InvoiceDueDate { get; set; }

        /// <summary>
        /// Gets or sets the invoice current identifier.
        /// </summary>
        /// <value>
        /// The invoice current identifier.
        /// </value>
        public string InvoiceCurId { get; set; }

        /// <summary>
        /// Gets or sets the invoice amount.
        /// </summary>
        /// <value>
        /// The invoice amount.
        /// </value>
        public decimal? InvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets the invoice amount usd.
        /// </summary>
        /// <value>
        /// The invoice amount usd.
        /// </value>
        public decimal? InvoiceAmountUsd { get; set; }

        /// <summary>
        /// Gets or sets the invoice voucher number.
        /// </summary>
        /// <value>
        /// The invoice voucher number.
        /// </value>
        public string InvoiceVoucherNumber { get; set; }

        /// <summary>
        /// Gets or sets the invoice supplier reference number.
        /// </summary>
        /// <value>
        /// The invoice supplier reference number.
        /// </value>
        public string InvoiceSupplierRefNumber { get; set; }

        /// <summary>
        /// Gets or sets the type of the invoice pay.
        /// </summary>
        /// <value>
        /// The type of the invoice pay.
        /// </value>
        public string InvoicePayType { get; set; }

        /// <summary>
        /// Gets or sets the invoice pay method.
        /// </summary>
        /// <value>
        /// The invoice pay method.
        /// </value>
        public string InvoicePayMethod { get; set; }

        /// <summary>
        /// Gets or sets the invoice pay run number.
        /// </summary>
        /// <value>
        /// The invoice pay run number.
        /// </value>
        public string InvoicePayRunNumber { get; set; }

        /// <summary>
        /// Gets or sets the invoice pay note number.
        /// </summary>
        /// <value>
        /// The invoice pay note number.
        /// </value>
        public string InvoicePayNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the ast identifier.
        /// </summary>
        /// <value>
        /// The ast identifier.
        /// </value>
        public string AstId { get; set; }

        /// <summary>
        /// Gets or sets the invoice post date.
        /// </summary>
        /// <value>
        /// The invoice post date.
        /// </value>
        public DateTime? InvoicePostDate { get; set; }


        /// <summary>
        /// Gets or sets the discounted payment amount.
        /// </summary>
        /// <value>
        /// The discounted payment amount.
        /// </value>
        public decimal DiscountedPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets the discounted bank amount.
        /// </summary>
        /// <value>
        /// The discounted bank amount.
        /// </value>
        public decimal DiscountedBankAmount { get; set; }

        /// <summary>
        /// Gets or sets the BankAmount field.
        /// </summary>
		public decimal? BankAmount { get; set; }

        /// <summary>
        /// Gets or sets the BankCurrency field.
        /// </summary>
        public string BankCurrency { get; set; }

        /// <summary>
        /// Gets or sets the IsMultiCurrency field.
        /// </summary>
		public bool? IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets the InvoiceDatePaymentSelected field.
        /// </summary>
		public DateTime? InvoiceDatePaymentSelected { get; set; }

        /// <summary>
        /// Gets or sets the Aged Days
        /// </summary>
        public int AgedDays { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets the name of the coy.
        /// </summary>
        /// <value>
        /// The name of the coy.
        /// </value>
        public string CoyName { get; set; }
    }
}
