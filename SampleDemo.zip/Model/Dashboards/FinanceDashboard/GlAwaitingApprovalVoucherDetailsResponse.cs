﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// Gl Awaiting Approval Voucher Details Response 
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class GlAwaitingApprovalVoucherDetailsResponse : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the GLT voucher.
        /// </summary>
        /// <value>
        /// The GLT voucher.
        /// </value>
        public string GltVoucher { get; set; }

        /// <summary>
        /// Gets or sets the type of the JRN.
        /// </summary>
        /// <value>
        /// The type of the JRN.
        /// </value>
        public string JrnType { get; set; }

        /// <summary>
        /// Gets or sets the JRN desc.
        /// </summary>
        /// <value>
        /// The JRN desc.
        /// </value>
        public string JrnDesc { get; set; }

        /// <summary>
        /// Gets or sets the GLT date entered.
        /// </summary>
        /// <value>
        /// The GLT date entered.
        /// </value>
        public DateTime? GltDateEntered { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the ledger lines.
        /// </summary>
        /// <value>
        /// The ledger lines.
        /// </value>
        public int? LedgerLines { get; set; }
    }
}
