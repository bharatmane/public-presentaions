﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class PendingActivitiesOverviewCount : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the controller one month count.
        /// </summary>
        /// <value>
        /// The controller one month count.
        /// </value>
        public int ControllerOneMonthCount { get; set; }
        /// <summary>
        /// Gets or sets the controller three months count.
        /// </summary>
        /// <value>
        /// The controller three months count.
        /// </value>
        public int ControllerThreeMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the controller six months count.
        /// </summary>
        /// <value>
        /// The controller six months count.
        /// </value>
        public int ControllerSixMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the controller no date count.
        /// </summary>
        /// <value>
        /// The controller no date count.
        /// </value>
        public int ControllerNoDateCount { get; set; }
        /// <summary>
        /// Gets or sets the roll and clear one month count.
        /// </summary>
        /// <value>
        /// The roll and clear one month count.
        /// </value>
        public int RollAndClearOneMonthCount { get; set; }
        /// <summary>
        /// Gets or sets the roll and clear three months count.
        /// </summary>
        /// <value>
        /// The roll and clear three months count.
        /// </value>
        public int RollAndClearThreeMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the roll and clear six months count.
        /// </summary>
        /// <value>
        /// The roll and clear six months count.
        /// </value>
        public int RollAndClearSixMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the roll and clear twelve months count.
        /// </summary>
        /// <value>
        /// The roll and clear twelve months count.
        /// </value>
        public int RollAndClearTwelveMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the exchange reval one month count.
        /// </summary>
        /// <value>
        /// The exchange reval one month count.
        /// </value>
        public int ExchangeRevalOneMonthCount { get; set; }
        /// <summary>
        /// Gets or sets the exchange reval three months count.
        /// </summary>
        /// <value>
        /// The exchange reval three months count.
        /// </value>
        public int ExchangeRevalThreeMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the exchange reval six months count.
        /// </summary>
        /// <value>
        /// The exchange reval six months count.
        /// </value>
        public int ExchangeRevalSixMonthsCount { get; set; }
        /// <summary>
        /// Gets or sets the exchange reval no date count.
        /// </summary>
        /// <value>
        /// The exchange reval no date count.
        /// </value>
        public int ExchangeRevalNoDateCount { get; set; }
        /// <summary>
        /// Gets or sets the po accrual count.
        /// </summary>
        /// <value>
        /// The po accrual count.
        /// </value>
        public int PoAccrualCount { get; set; }
        /// <summary>
        /// Gets or sets the invoice order accrual count.
        /// </summary>
        /// <value>
        /// The invoice order accrual count.
        /// </value>
        public int InvoiceOrderAccrualCount { get; set; }
        /// <summary>
        /// Gets or sets the other accrual count.
        /// </summary>
        /// <value>
        /// The other accrual count.
        /// </value>
        public int OtherAccrualCount { get; set; }

        /// <summary>
        /// Gets or sets the fixed asset depreciation one month count.
        /// </summary>
        /// <value>
        /// The fixed asset depreciation one month count.
        /// </value>
        public int FixedAssetDepreciationOneMonthCount { get; set; }
        /// <summary>
        /// Gets or sets the fixed asset depreciation three month count.
        /// </summary>
        /// <value>
        /// The fixed asset depreciation three month count.
        /// </value>
        public int FixedAssetDepreciationThreeMonthCount { get; set; }
        /// <summary>
        /// Gets or sets the fixed asset depreciation six month count.
        /// </summary>
        /// <value>
        /// The fixed asset depreciation six month count.
        /// </value>
        public int FixedAssetDepreciationSixMonthCount { get; set; }
        /// <summary>
        /// Gets or sets the fixed asset depreciation no date count.
        /// </summary>
        /// <value>
        /// The fixed asset depreciation no date count.
        /// </value>
        public int FixedAssetDepreciationNoDateCount { get; set; }

        // Total Counts for ProgressBar

        /// <summary>
        /// Gets or sets the controller total count.
        /// </summary>
        /// <value>
        /// The controller total count.
        /// </value>
        public int ControllerTotalCount
        {
            get
            {
                return ControllerNoDateCount + ControllerSixMonthsCount + ControllerThreeMonthsCount + ControllerOneMonthCount;
            }
        }

        /// <summary>
        /// Gets or sets the exchange reval total count.
        /// </summary>
        /// <value>
        /// The exchange reval total count.
        /// </value>
        public int ExchangeRevalTotalCount
        {
            get
            {
                return ExchangeRevalSixMonthsCount + ExchangeRevalNoDateCount + ExchangeRevalOneMonthCount + ExchangeRevalThreeMonthsCount;
            }
        }

        /// <summary>
        /// Gets or sets the roll and clear total count.
        /// </summary>
        /// <value>
        /// The roll and clear total count.
        /// </value>
        public int RollAndClearTotalCount
        {
            get
            {
                return RollAndClearOneMonthCount + RollAndClearSixMonthsCount + RollAndClearThreeMonthsCount + RollAndClearTwelveMonthsCount;
            }
        }

        /// <summary>
        /// Gets or sets the accrual total count.
        /// </summary>
        /// <value>
        /// The accrual total count.
        /// </value>
        public int AccrualTotalCount
        {
            get
            {
                return InvoiceOrderAccrualCount + OtherAccrualCount + PoAccrualCount;
            }
        }

        /// <summary>
        /// Gets or sets the fixed asset depreciation total count.
        /// </summary>
        /// <value>
        /// The fixed asset depreciation total count.
        /// </value>
        public int FixedAssetDepreciationTotalCount
        {
            get
            {
                return FixedAssetUnrecordedInvoiceCount + FixedAssetUnrecordedLedgerCount + FixedAssetPurchaseOrderCount;
            }
        }

        /// <summary>Gets or sets the acc comp ar posted.</summary>
        /// <value>The acc comp ar posted.</value>
        public decimal? AccCompARPosted { get; set; }

        /// <summary>
        ///   <para>Gets or sets the acc comp ap posted.
        /// </para>
        /// </summary>
        /// <value>The acc comp ap posted.</value>
        public decimal? AccCompAPPosted { get; set; }

        /// <summary>Gets or sets the acc comp ap unposted.</summary>
        /// <value>The acc comp ap unposted.</value>
        public decimal? AccCompAPUnposted { get; set; }

        /// <summary>Gets or sets the un acc comp ar posted.</summary>
        /// <value>The un acc comp ar posted.</value>
        public decimal? UnAccCompARPosted { get; set; }

        /// <summary>
        ///   <para>
        /// Gets or sets the un acc comp ap posted.
        /// </para>
        /// </summary>
        /// <value>The un acc comp ap posted.</value>
        public decimal? UnAccCompAPPosted { get; set; }

        /// <summary>Gets or sets the un acc comp ap unposted.</summary>
        /// <value>The un acc comp ap unposted.</value>
        public decimal? UnAccCompAPUnposted { get; set; }

        /// <summary>
        /// Gets or sets the fixed asset unrecorded invoice count.
        /// </summary>
        /// <value>
        /// The fixed asset unrecorded invoice count.
        /// </value>
        public int FixedAssetUnrecordedInvoiceCount { get; set; }
        /// <summary>
        /// Gets or sets the fixed asset unrecorded ledger count.
        /// </summary>
        /// <value>
        /// The fixed asset unrecorded ledger count.
        /// </value>
        public int FixedAssetUnrecordedLedgerCount { get; set; }
        /// <summary>
        /// Gets or sets the fixed asset purchase order count.
        /// </summary>
        /// <value>
        /// The fixed asset purchase order count.
        /// </value>
        public int FixedAssetPurchaseOrderCount { get; set; }
    }
}
