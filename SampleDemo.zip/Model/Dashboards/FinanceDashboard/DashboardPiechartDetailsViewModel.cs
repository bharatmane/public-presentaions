﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.FinanceDashboard
{
    /// <summary>
    /// This class is used for Pie charts detail
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class DashboardPiechartDetailsViewModel : BaseViewModel
    {
        #region Properties

        /// <summary>
        /// The value data
        /// </summary>
        private double _valueData;

        /// <summary>
        /// Gets or sets the value data.
        /// </summary>
        /// <value>
        /// The value data.
        /// </value>
        public double ValueData
        {
            get { return _valueData; }
            set { Set(() => ValueData, ref _valueData, value); }
        }

        /// <summary>
        /// The description
        /// </summary>
        private string _description;

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description
        {
            get { return _description; }
            set { Set(() => Description, ref _description, value); }
        }

        #endregion
    }
}
