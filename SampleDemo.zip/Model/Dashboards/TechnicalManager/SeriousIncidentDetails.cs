﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.TechnicalManager
{
	/// <summary>
	/// The class SeriousIncidentDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class SeriousIncidentDetails : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }

		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellName { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string TechnicalOfficeId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string TechnicalOfficeName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the ims status.
		/// </summary>
		/// <value>
		/// The ims status.
		/// </value>
		public string ImsStatus { get; set; }
		/// <summary>
		/// Gets or sets the close date.
		/// </summary>
		/// <value>
		/// The close date.
		/// </value>
		public DateTime? IncidentCloseDate { get; set; }
		/// <summary>
		/// Gets or sets the severity.
		/// </summary>
		/// <value>
		/// The severity.
		/// </value>
		public string Severity { get; set; }
		/// <summary>
		/// Gets or sets the report date.
		/// </summary>
		/// <value>
		/// The report date.
		/// </value>
		public DateTime? ReportDate { get; set; }
		/// <summary>
		/// Gets or sets the incident date.
		/// </summary>
		/// <value>
		/// The incident date.
		/// </value>
		public DateTime? IncidentDate { get; set; }
		/// <summary>
		/// Gets or sets the reference number.
		/// </summary>
		/// <value>
		/// The reference number.
		/// </value>
		public string ReferenceNumber { get; set; }
		/// <summary>
		/// Gets or sets the incident identifier.
		/// </summary>
		/// <value>
		/// The incident identifier.
		/// </value>
		public string IncidentId { get; set; }

		/// <summary>
		/// Gets or sets the severity identifier.
		/// </summary>
		/// <value>
		/// The severity identifier.
		/// </value>
		public string SeverityId { get; set; }

		/// <summary>
		/// Gets or sets the ims status identifier.
		/// </summary>
		/// <value>
		/// The ims status identifier.
		/// </value>
		public string IncidentStatusId { get; set; }

		/// <summary>
		/// Gets or sets the name of the incident status.
		/// </summary>
		/// <value>
		/// The name of the incident status.
		/// </value>
		public string IncidentStatusName { get; set; }

		/// <summary>
		/// Gets or sets the category identifier.
		/// </summary>
		/// <value>
		/// The category identifier.
		/// </value>
		public string CategoryId { get; set; }

		/// <summary>
		/// Gets or sets the name of the category.
		/// </summary>
		/// <value>
		/// The name of the category.
		/// </value>
		public string CategoryName { get; set; }

		/// <summary>
		/// Gets or sets the name of the class.
		/// </summary>
		/// <value>
		/// The name of the class.
		/// </value>
		public string ClassName { get; set; }

		/// <summary>
		/// Gets or sets the imd parent identifier.
		/// </summary>
		/// <value>
		/// The imd parent identifier.
		/// </value>
		public string ImdParentId { get; set; }

		/// <summary>
		/// The class category
		/// </summary>
		private string _classCategory;

		/// <summary>
		/// Gets or sets the class category.
		/// </summary>
		/// <value>
		/// The class category.
		/// </value>
		public string ClassCategory
		{
			get { return CategoryName + " - " + ClassName; }
			set
			{
				ClassCategory = CategoryName + " - " + ClassName;
			}
		}
	}

	/// <summary>
	/// The class InspectionAndVettingDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class InspectionAndVettingDetails : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }
		/// <summary>
		/// Gets or sets the fleet identifier.
		/// </summary>
		/// <value>
		/// The fleet identifier.
		/// </value>
		public string FleetId { get; set; }
		/// <summary>
		/// Gets or sets the fleet desc.
		/// </summary>
		/// <value>
		/// The fleet desc.
		/// </value>
		public string FleetDesc { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellDesc { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string CompanyName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the due date.
		/// </summary>
		/// <value>
		/// The due date.
		/// </value>
		public DateTime? DueDate { get; set; }
		/// <summary>
		/// Gets or sets the interval.
		/// </summary>
		/// <value>
		/// The interval.
		/// </value>
		public int Interval { get; set; }
		/// <summary>
		/// Gets or sets the issue date.
		/// </summary>
		/// <value>
		/// The issue date.
		/// </value>
		public DateTime? IssueDate { get; set; }
		/// <summary>
		/// Gets or sets from date.
		/// </summary>
		/// <value>
		/// From date.
		/// </value>
		public DateTime? FromDate { get; set; }
		/// <summary>
		/// Gets or sets to date.
		/// </summary>
		/// <value>
		/// To date.
		/// </value>
		public DateTime? ToDate { get; set; }
		/// <summary>
		/// Gets or sets the close date.
		/// </summary>
		/// <value>
		/// The close date.
		/// </value>
		public DateTime? CloseDate { get; set; }
		/// <summary>
		/// Gets or sets the days passed.
		/// </summary>
		/// <value>
		/// The days passed.
		/// </value>
		public int DaysPassed { get; set; }
		/// <summary>
		/// Gets or sets the type of the visit.
		/// </summary>
		/// <value>
		/// The type of the visit.
		/// </value>
		public string VisitType { get; set; }
		/// <summary>
		/// Gets or sets the inspection identifier.
		/// </summary>
		/// <value>
		/// The inspection identifier.
		/// </value>
		public string InspectionId { get; set; }
        /// <summary>
        /// Gets or sets the number findings.
        /// </summary>
        /// <value>
        /// The number findings.
        /// </value>
        public int NumFindings { get; set; }
    }

	/// <summary>
	/// The class CertificateDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class CertificateDetails : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }

		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellDesc { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string TechnicalOfficeId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string TechnicalOfficeName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the certificate.
		/// </summary>
		/// <value>
		/// The certificate.
		/// </value>
		public string Certificate { get; set; }
		/// <summary>
		/// Gets or sets the issue date.
		/// </summary>
		/// <value>
		/// The issue date.
		/// </value>
		public DateTime? IssueDate { get; set; }
		/// <summary>
		/// Gets or sets the expiry date.
		/// </summary>
		/// <value>
		/// The expiry date.
		/// </value>
		public DateTime? ExpiryDate { get; set; }
		/// <summary>
		/// Gets or sets the validity.
		/// </summary>
		/// <value>
		/// The validity.
		/// </value>
		public int Validity { get; set; }
		/// <summary>
		/// Gets or sets the certificate identifier.
		/// </summary>
		/// <value>
		/// The certificate identifier.
		/// </value>
		public string CertificateId { get; set; }

		/// <summary>
		/// Gets or sets the certificate impact.
		/// </summary>
		/// <value>
		/// The certificate impact.
		/// </value>
		public string CertificateImpact { get; set; }

		/// <summary>
		/// Gets or sets the days passed.
		/// </summary>
		/// <value>
		/// The days passed.
		/// </value>
		public int DaysPassed { get; set; }
	}

	/// <summary>
	/// The class PMSTechAndInspOverdueDefectsDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class PMSTechAndInspOverdueDefectsDetails : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }
		/// <summary>
		/// Gets or sets the fleet identifier.
		/// </summary>
		/// <value>
		/// The fleet identifier.
		/// </value>
		public string FleetId { get; set; }
		/// <summary>
		/// Gets or sets the fleet desc.
		/// </summary>
		/// <value>
		/// The fleet desc.
		/// </value>
		public string FleetDesc { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellDesc { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string CompanyName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the defect.
		/// </summary>
		/// <value>
		/// The name of the defect.
		/// </value>
		public string DefectName { get; set; }
		/// <summary>
		/// Gets or sets the due date.
		/// </summary>
		/// <value>
		/// The due date.
		/// </value>
		public DateTime? DueDate { get; set; }
		/// <summary>
		/// Gets or sets the days passed.
		/// </summary>
		/// <value>
		/// The days passed.
		/// </value>
		public int DaysPassed { get; set; }
		/// <summary>
		/// Gets or sets the defect identifier.
		/// </summary>
		/// <value>
		/// The defect identifier.
		/// </value>
		public string DefectId { get; set; }

		/// <summary>
		/// The days pass
		/// </summary>
		private int _daysPass;

		/// <summary>
		/// Gets or sets the days pass.
		/// </summary>
		/// <value>
		/// The days pass.
		/// </value>
		public int DaysPass
		{
			get { return DaysPassed * -1; }
			set { _daysPass = DaysPassed * -1; }
		}

		/// <summary>
		/// Gets or sets the planned for.
		/// </summary>
		/// <value>
		/// The planned for.
		/// </value>
		public string PlannedFor { get; set; }

		/// <summary>
		/// Gets or sets the impact.
		/// </summary>
		/// <value>
		/// The impact.
		/// </value>
		public string Impact { get; set; }

		/// <summary>
		/// Gets or sets the category.
		/// </summary>
		/// <value>
		/// The category.
		/// </value>
		public string Category { get; set; }

		/// <summary>
		/// Gets or sets the system area.
		/// </summary>
		/// <value>
		/// The system area.
		/// </value>
		public string SystemArea { get; set; }
	}

	/// <summary>
	/// The class PMSTechnicalDryDockDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class PMSTechnicalDryDockDetails : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }
		/// <summary>
		/// Gets or sets the fleet identifier.
		/// </summary>
		/// <value>
		/// The fleet identifier.
		/// </value>
		public string FleetId { get; set; }
		/// <summary>
		/// Gets or sets the fleet desc.
		/// </summary>
		/// <value>
		/// The fleet desc.
		/// </value>
		public string FleetDesc { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellDesc { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string CompanyName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the due date.
		/// </summary>
		/// <value>
		/// The due date.
		/// </value>
		public DateTime? DueDate { get; set; }
		/// <summary>
		/// Gets or sets the months.
		/// </summary>
		/// <value>
		/// The months.
		/// </value>
		public int Months { get; set; }
		/// <summary>
		/// Gets or sets the days.
		/// </summary>
		/// <value>
		/// The days.
		/// </value>
		public int Days { get; set; }

		/// <summary>
		/// The time remaining
		/// </summary>
		private string timeRemaining;
		/// <summary>
		/// Gets or sets the time remaining.
		/// </summary>
		/// <value>
		/// The time remaining.
		/// </value>
		public string TimeRemaining
		{
			get { return Convert.ToString(Months) + ',' + Convert.ToString(Days); }
			set { timeRemaining = Convert.ToString(Months) + ',' + Convert.ToString(Days); }
		}

        /// <summary>
        /// Gets or sets the VLK description.
        /// </summary>
        /// <value>
        /// The VLK description.
        /// </value>
        public string VlkDescription { get; set; }

    }

	/// <summary>
	/// The class PMSTechnicalDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class PMSTechnicalDetails : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }
		/// <summary>
		/// Gets or sets the fleet identifier.
		/// </summary>
		/// <value>
		/// The fleet identifier.
		/// </value>
		public string FleetId { get; set; }
		/// <summary>
		/// Gets or sets the fleet desc.
		/// </summary>
		/// <value>
		/// The fleet desc.
		/// </value>
		public string FleetDesc { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellDesc { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string CompanyName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the job.
		/// </summary>
		/// <value>
		/// The name of the job.
		/// </value>
		public string JobName { get; set; }
		/// <summary>
		/// Gets or sets the name of the component.
		/// </summary>
		/// <value>
		/// The name of the component.
		/// </value>
		public string ComponentName { get; set; }
		/// <summary>
		/// Gets or sets the due date.
		/// </summary>
		/// <value>
		/// The due date.
		/// </value>
		public DateTime DueDate { get; set; }
		/// <summary>
		/// Gets or sets the status.
		/// </summary>
		/// <value>
		/// The status.
		/// </value>
		public string Status { get; set; }
		/// <summary>
		/// Gets or sets the type.
		/// </summary>
		/// <value>
		/// The type.
		/// </value>
		public string Type { get; set; }
		/// <summary>
		/// Gets or sets the interval.
		/// </summary>
		/// <value>
		/// The interval.
		/// </value>
		public string Interval { get; set; }
		/// <summary>
		/// Gets or sets the days passed.
		/// </summary>
		/// <value>
		/// The days passed.
		/// </value>
		public int DaysPassed { get; set; }
		/// <summary>
		/// Gets or sets the work order identifier.
		/// </summary>
		/// <value>
		/// The work order identifier.
		/// </value>
		public string WorkOrderId { get; set; }

		/// <summary>
		/// Gets or sets the overdue maintenance count.
		/// </summary>
		/// <value>
		/// The overdue maintenance count.
		/// </value>
		public string OverdueMaintenanceCount { get; set; }

        /// <summary>
		/// The work order count
		/// </summary>
		private int workOrderCount;
        /// <summary>
        /// Gets or sets the work order count.
        /// </summary>
        /// <value>
        /// The work order count.
        /// </value>
        public int WorkOrderCount
        {
            get { return !string.IsNullOrWhiteSpace(OverdueMaintenanceCount) ? int.Parse(OverdueMaintenanceCount) : 0; }
            set { workOrderCount = !string.IsNullOrWhiteSpace(OverdueMaintenanceCount) ? int.Parse(OverdueMaintenanceCount) : 0; }
        }
    }

	/// <summary>
	/// The class BusinessAndCommercial
	/// </summary>
	public class BusinessAndCommercial
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }
		/// <summary>
		/// Gets or sets the fleet identifier.
		/// </summary>
		/// <value>
		/// The fleet identifier.
		/// </value>
		public string FleetId { get; set; }
		/// <summary>
		/// Gets or sets the fleet desc.
		/// </summary>
		/// <value>
		/// The fleet desc.
		/// </value>
		public string FleetDesc { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell identifier.
		/// </summary>
		/// <value>
		/// The fleet cell identifier.
		/// </value>
		public string FleetCellId { get; set; }
		/// <summary>
		/// Gets or sets the fleet cell desc.
		/// </summary>
		/// <value>
		/// The fleet cell desc.
		/// </value>
		public string FleetCellDesc { get; set; }
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string CompanyName { get; set; }
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		
		/// <summary>
		/// Gets or sets from date.
		/// </summary>
		/// <value>
		/// From date.
		/// </value>
		public DateTime? FromDate { get; set; }
		/// <summary>
		/// Gets or sets to date.
		/// </summary>
		/// <value>
		/// To date.
		/// </value>
		public DateTime? ToDate { get; set; }
		
		/// <summary>
		/// Gets or sets the type of the visit.
		/// </summary>
		/// <value>
		/// The type of the visit.
		/// </value>
		public string VisitType { get; set; }
		/// <summary>
		/// Gets or sets the inspection identifier.
		/// </summary>
		/// <value>
		/// The inspection identifier.
		/// </value>
		public string InspectionId { get; set; }

		/// <summary>
		/// Gets or sets the inspecting company.
		/// </summary>
		/// <value>
		/// The inspecting company.
		/// </value>
		public string InspectingCompany { get; set; }

		/// <summary>
		/// Gets or sets the findings.
		/// </summary>
		/// <value>
		/// The findings.
		/// </value>
		public int Findings { get; set; }
	}
}
