﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.TechnicalManager
{
    /// <summary>
    /// A data class to represent an Under Performance (Speed / Fuel) details.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class UnderPerformanceDetails : BaseViewModel
    {
        #region Properties

        /// <summary>
        /// The identifier
        /// </summary>
        public string Identifier;

        /// <summary>
        /// Gets or sets the position identifier.
        /// </summary>
        /// <value>
        /// The position identifier.
        /// </value>
        public string PositionId { get; set; }

		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesName { get; set; }

        /// <summary>
        /// Gets or sets the fleet identifier.
        /// </summary>
        /// <value>
        /// The fleet identifier.
        /// </value>
        public string FleetCellId { get; set; }

        /// <summary>
        /// Gets or sets the fleet description.
        /// </summary>
        /// <value>
        /// The fleet description.
        /// </value>
        public string FleetCellDesc { get; set; }

        /// <summary>
        /// Gets or sets the office description.
        /// </summary>
        /// <value>
        /// The office description.
        /// </value>
        public string CmpName { get; set; }

        /// <summary>
        /// Gets or sets the voyage number.
        /// </summary>
        /// <value>
        /// The voyage number.
        /// </value>
        public string CharterVoyage { get; set; }

        /// <summary>
        /// Gets or sets the charter number.
        /// </summary>
        /// <value>
        /// The charter number.
        /// </value>
        public string CharterNumber { get; set; }

        /// <summary>
        /// Gets or sets the ordered speed.
        /// </summary>
        /// <value>
        /// The ordered speed.
        /// </value>
        public decimal CharterSpeed { get; set; }

        /// <summary>
        /// Gets or sets the average speed.
        /// </summary>
        /// <value>
        /// The average speed.
        /// </value>
        public decimal AvgSpeed { get; set; }


		/// <summary>
		/// Gets or sets the charter identifier.
		/// </summary>
		/// <value>
		/// The charter identifier.
		/// </value>
		public string CharterId { get; set; }

        /// <summary>
        /// Gets or sets the order fo fuel consumption.
        /// </summary>
        /// <value>
        /// The order fo fuel consumption.
        /// </value>
        public decimal OrderFOFuelConsumption { get; set; }

        /// <summary>
        /// Gets or sets the average fo fuel consumption.
        /// </summary>
        /// <value>
        /// The average fo fuel consumption.
        /// </value>
        public decimal AverageFOFuelConsumption  { get; set; }

        /// <summary>
        /// Gets or sets the order lsfo fuel consumption.
        /// </summary>
        /// <value>
        /// The order lsfo fuel consumption.
        /// </value>
        public decimal OrderLSFOFuelConsumption { get; set; }

        /// <summary>
        /// Gets or sets the average lsfo fuel consumption.
        /// </summary>
        /// <value>
        /// The average lsfo fuel consumption.
        /// </value>
        public decimal AverageLSFOFuelConsumption  { get; set; }

        /// <summary>
        /// Gets or sets the order do fuel consumption.
        /// </summary>
        /// <value>
        /// The order do fuel consumption.
        /// </value>
        public decimal OrderDOFuelConsumption  { get; set; }

        /// <summary>
        /// Gets or sets the average do fuel consumption.
        /// </summary>
        /// <value>
        /// The average do fuel consumption.
        /// </value>
        public decimal AverageDOFuelConsumption  { get; set; }

        /// <summary>
        /// Gets or sets the order go fuel consumption.
        /// </summary>
        /// <value>
        /// The order go fuel consumption.
        /// </value>
        public decimal OrderGOFuelConsumption  { get; set; }

        /// <summary>
        /// Gets or sets the average go fuel consumption.
        /// </summary>
        /// <value>
        /// The average go fuel consumption.
        /// </value>
        public decimal AverageGOFuelConsumption  { get; set; }

        /// <summary>
        /// Gets or sets the order LNG fuel consumption.
        /// </summary>
        /// <value>
        /// The order LNG fuel consumption.
        /// </value>
        public decimal OrderLNGFuelConsumption { get; set; }

        /// <summary>
        /// Gets or sets the average LNG fuel consumption.
        /// </summary>
        /// <value>
        /// The average LNG fuel consumption.
        /// </value>
        public decimal AverageLNGFuelConsumption { get; set; }

        /// <summary>
        /// Gets a value indicating whether this instance is fo consumption exceeded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is fo consumption exceeded; otherwise, <c>false</c>.
        /// </value>
        public bool IsFoConsumptionExceeded
        {
            get { return ValueComparator(AverageFOFuelConsumption, OrderFOFuelConsumption); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is lsfo consumption exceeded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is lsfo consumption exceeded; otherwise, <c>false</c>.
        /// </value>
        public bool IsLsfoConsumptionExceeded
        {
            get { return ValueComparator(AverageLSFOFuelConsumption, OrderLSFOFuelConsumption); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is do consumption exceeded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is do consumption exceeded; otherwise, <c>false</c>.
        /// </value>
        public bool IsDoConsumptionExceeded
        {
            get { return ValueComparator(AverageDOFuelConsumption, OrderDOFuelConsumption); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is go consumption exceeded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is go consumption exceeded; otherwise, <c>false</c>.
        /// </value>
        public bool IsGoConsumptionExceeded
        {
            get { return ValueComparator(AverageGOFuelConsumption, OrderGOFuelConsumption); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is LNG consumption exceeded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is LNG consumption exceeded; otherwise, <c>false</c>.
        /// </value>
        public bool IsLngConsumptionExceeded
        {
            get { return ValueComparator(AverageLNGFuelConsumption, OrderLNGFuelConsumption); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The value comparator. Compares the two value.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns>
        /// A bool value.
        /// </returns>
        private bool ValueComparator(decimal value1, decimal value2)
        {
            return value1 > value2 ? true : false;
        }

        #endregion
    }
}
