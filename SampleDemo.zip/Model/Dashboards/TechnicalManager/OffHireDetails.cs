﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.TechnicalManager
{
	/// <summary>
	/// A data class to represent an Off Hire details.
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class OffHireDetails : BaseViewModel
	{
        #region Properties

        /// <summary>
        /// The identifier
        /// </summary>
        public string Identifier;

        /// <summary>
        /// The position identifier
        /// </summary>
        public string PositionId;

		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesId { get; set; }

		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesName { get; set; }

		/// <summary>
		/// Gets or sets the fleet identifier.
		/// </summary>
		/// <value>
		/// The fleet identifier.
		/// </value>
		public string FleetCellId { get; set; }

		/// <summary>
		/// Gets or sets the fleet description.
		/// </summary>
		/// <value>
		/// The fleet description.
		/// </value>
		public string FleetCellDesc { get; set; }

		/// <summary>
		/// Gets or sets the office description.
		/// </summary>
		/// <value>
		/// The office description.
		/// </value>
		public string CmpName { get; set; }

		/// <summary>
		/// Gets or sets the type of the off hire.
		/// </summary>
		/// <value>
		/// The type of the off hire.
		/// </value>
		public string OffHireType { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is duration more than one day.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is duration more than one day; otherwise, <c>false</c>.
		/// </value>
		public bool MoreThan24Hour { get; set; }

        /// <summary>
        /// Gets or sets the duration of the formatted.
        /// </summary>
        /// <value>
        /// The duration of the formatted.
        /// </value>
        public string FormattedDuration { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }

		/// <summary>
		/// Gets or sets to date.
		/// </summary>
		/// <value>
		/// To date.
		/// </value>
		public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets position from date.
        /// </summary>
        /// <value>
        /// position from date.
        /// </value>
        public DateTime? PositionFromDate { get; set; }

        /// <summary>
        /// Gets or sets position to date.
        /// </summary>
        /// <value>
        /// Position to date.
        /// </value>
        public DateTime? PositionToDate { get; set; }

        /// <summary>
        /// Gets or sets the duration.
        /// </summary>
        /// <value>
        /// The duration.
        /// </value>
        public decimal Duration { get; set; }

        /// <summary>
        /// Gets or sets the name of the activity.
        /// </summary>
        /// <value>
        /// The name of the activity.
        /// </value>
        public string ActivityName { get; set; }

        /// <summary>
        /// Gets or sets the type of the offhire activity.
        /// </summary>
        /// <value>
        /// The type of the offhire activity.
        /// </value>
        public string OffhireActivityType { get; set; }
        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="OffHireDetails"/> class.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public OffHireDetails(OffHireDetails entity)
		{
			if (entity != null)
			{
				PositionId = entity.PositionId;
				VesId = entity.VesId;
				VesName = entity.VesName;
				FleetCellId = entity.FleetCellId;
				FleetCellDesc = entity.FleetCellDesc;
				CmpName = entity.CmpName;
				OffHireType = entity.OffHireType;
                ActivityName = entity.ActivityName;
                OffhireActivityType = entity.OffhireActivityType;
				FromDate = entity.FromDate;
				ToDate = entity.ToDate;
                PositionFromDate = entity.PositionFromDate;
                PositionToDate = entity.PositionToDate;
                MoreThan24Hour = entity.MoreThan24Hour;
                if (FromDate.HasValue && ToDate.HasValue)
                {

                    //FormattedDuration = duration.ToString(@"hh\:mm");
                    TimeSpan duration = ToDate.Value.Subtract(FromDate.Value);

                    long durationTicks = Math.Abs(duration.Ticks / TimeSpan.TicksPerMillisecond);
                    long hours = durationTicks / (1000 * 60 * 60);
                    long minutes = (durationTicks - (hours * 60 * 60 * 1000)) / (1000 * 60);
                    Duration = Convert.ToDecimal(hours) + Convert.ToDecimal(minutes / 100.00);
                    FormattedDuration = hours.ToString("00") + ":" + minutes.ToString("00");

                }       
            }
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="OffHireDetails"/> class.
		/// The default construcor.
		/// </summary>
		public OffHireDetails()
		{

		}

		#endregion

	}
}
