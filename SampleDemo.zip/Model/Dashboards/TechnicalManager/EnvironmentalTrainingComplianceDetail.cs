﻿using Newtonsoft.Json;
using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.TechnicalManager
{
    /// <summary>
    /// A class for representing the details of the Environmental Training Compliance records.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EnvironmentalTrainingComplianceDetail : BaseViewModel
    {
        #region Properties

        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        [JsonProperty("officeId")]
        public string OfficeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        [JsonProperty("officeName")]
        public string OfficeName { get; set; }

        /// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
        [JsonProperty("vesId")]
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        [JsonProperty("vesselName")]
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the fleet cell identifier.
        /// </summary>
        /// <value>
        /// The fleet cell identifier.
        /// </value>
        [JsonProperty("fltId")]
        public string FleetCellId { get; set; }

        /// <summary>
        /// Gets or sets the fleet cell desc.
        /// </summary>
        /// <value>
        /// The fleet cell desc.
        /// </value>
        [JsonProperty("fltDesc")]
        public string FleetCellDesc { get; set; }

        /// <summary>
        /// Gets or sets the set identifier.
        /// </summary>
        /// <value>
        /// The set identifier.
        /// </value>
        //[JsonProperty("officeName")]
        //public string SetId { get; set; }

        /// <summary>
        /// Gets or sets the crewing office.
        /// </summary>
        /// <value>
        /// The crewing office.
        /// </value>
        [JsonProperty("vesCrewingOffice")]
        public string CrewingOffice { get; set; }

        /// <summary>
        /// Gets or sets the technical office.
        /// </summary>
        /// <value>
        /// The technical office.
        /// </value>
        [JsonProperty("vesTechnicalOffice")]
        public string TechnicalOffice { get; set; }

        /// <summary>
        /// Gets or sets the name of the crew.
        /// </summary>
        /// <value>
        /// The name of the crew.
        /// </value>
        [JsonProperty("crwFirstName")]  
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        [JsonProperty("crwMiddleName")]
        public string MiddleName { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        [JsonProperty("crwSurname")]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the name of the crew.
        /// </summary>
        /// <value>
        /// The name of the crew.
        /// </value>
        public string CrewName { get { return LastName + "," + FirstName + " " + MiddleName; } }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        [JsonProperty("crwId")]
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the rank.
        /// </summary>
        /// <value>
        /// The rank.
        /// </value>
        [JsonProperty("crwRankDescription")]
        public string Rank { get; set; }

        /// <summary>
        /// Gets or sets the sign on date.
        /// </summary>
        /// <value>
        /// The sign on date.
        /// </value>
        [JsonProperty("crwSignOnDate")]
        public DateTime? SignOnDate { get; set; }

        /// <summary>
        /// Gets or sets the due relief.
        /// </summary>
        /// <value>
        /// The due relief.
        /// </value>
        [JsonProperty("crwDueRelief")]
        public DateTime? DueRelief { get; set; }

        /// <summary>
        /// Gets or sets the name of the document.
        /// </summary>
        /// <value>
        /// The name of the document.
        /// </value>
        [JsonProperty("crwDocument")]
        public string DocumentName { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty("crwDocStatusDescription")]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        [JsonProperty("crwDocNotes")]
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the CrdId field.
        /// </summary>
        [JsonProperty("CrdId")]
        public string CrdId { get; set; }

        /// <summary>
        /// Gets or sets the document issue date.
        /// </summary>
        /// <value>
        /// The document issue date.
        /// </value>
        [JsonProperty("DocumentIssueDate")]
        public DateTime? DocumentIssueDate { get; set; }

        /// <summary>
        /// Gets or sets the validity period.
        /// </summary>
        /// <value>
        /// The validity period.
        /// </value>
        [JsonProperty("ValidityPeriod")]
        public int? ValidityPeriod { get; set; }
        #endregion
    }
}
