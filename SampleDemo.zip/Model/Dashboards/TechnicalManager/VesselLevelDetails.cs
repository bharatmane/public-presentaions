﻿using System;
using System.Globalization;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.TechnicalManager
{

    /// <summary>
    /// The contract to fetch Vessel level detials.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class VesselLevelDetails : BaseViewModel
    {
        #region Default Fields
        /// <summary>
        /// Gets or sets the client.
        /// </summary>
        /// <value>
        /// The client.
        /// </value>
        public string Client { get; set; }


        /// <summary>
        /// Gets or sets the crew onboard.
        /// </summary>
        /// <value>
        /// The crew onboard.
        /// </value>
        public decimal? CrewOnboard { get; set; }


        /// <summary>
        /// Gets or sets the crew overdue ratio.
        /// </summary>
        /// <value>
        /// The crew overdue ratio.
        /// </value>
        public decimal? CrewOverdueRatio { get; set; }


        /// <summary>
        /// Gets or sets the crew overdue reliefs1530.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs1530.
        /// </value>
        public decimal? CrewOverdueReliefs1530 { get; set; }


        /// <summary>
        /// Gets or sets the crew overdue reliefs30 plus.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs30 plus.
        /// </value>
        public decimal? CrewOverdueReliefs30Plus { get; set; }


        /// <summary>
        /// Gets or sets the crew overdue reliefs30 plus worst vessel.
        /// </summary>
        /// <value>
        /// The crew overdue reliefs30 plus worst vessel.
        /// </value>
        public bool? CrewOverdueReliefs30PlusWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the crew retention.
        /// </summary>
        /// <value>
        /// The crew retention.
        /// </value>
        public decimal? CrewRetention { get; set; }


        /// <summary>
        /// Gets or sets the crew retention r3 m.
        /// </summary>
        /// <value>
        /// The crew retention r3 m.
        /// </value>
        public decimal? CrewRetentionR3M { get; set; }


        /// <summary>
        /// Gets or sets the critical PMS.
        /// </summary>
        /// <value>
        /// The critical PMS.
        /// </value>
        public decimal? CriticalPms { get; set; }


        /// <summary>
        /// Gets or sets the critical PMS lm.
        /// </summary>
        /// <value>
        /// The critical PMS lm.
        /// </value>
        public decimal? CriticalPmsLm { get; set; }


        /// <summary>
        /// Gets or sets the critical PMS lm prior.
        /// </summary>
        /// <value>
        /// The critical PMS lm prior.
        /// </value>
        public decimal? CriticalPmsLmPrior { get; set; }


        /// <summary>
        /// Gets or sets the index of the emissions efficiency.
        /// </summary>
        /// <value>
        /// The index of the emissions efficiency.
        /// </value>
        public decimal? EmissionsEfficiencyIndex { get; set; }


        /// <summary>
        /// Gets or sets the emissions lm.
        /// </summary>
        /// <value>
        /// The emissions lm.
        /// </value>
        public decimal? EmissionsLm { get; set; }


        /// <summary>
        /// Gets or sets the emissions prior.
        /// </summary>
        /// <value>
        /// The emissions prior.
        /// </value>
        public decimal? EmissionsPrior { get; set; }


        /// <summary>
        /// Gets or sets the emissions R12 m.
        /// </summary>
        /// <value>
        /// The emissions R12 m.
        /// </value>
        public decimal? EmissionsR12M { get; set; }


        /// <summary>
        /// Gets or sets the emissions rag.
        /// </summary>
        /// <value>
        /// The emissions rag.
        /// </value>
        public int? EmissionsRag { get; set; }


        /// <summary>
        /// Gets or sets the exp hours.
        /// </summary>
        /// <value>
        /// The exp hours.
        /// </value>
        public decimal? ExpHours { get; set; }


        /// <summary>
        /// Gets or sets the exp hours r3 m.
        /// </summary>
        /// <value>
        /// The exp hours r3 m.
        /// </value>
        public decimal? ExpHoursR3M { get; set; }


        /// <summary>
        /// Gets or sets the fleet cell.
        /// </summary>
        /// <value>
        /// The fleet cell.
        /// </value>
        public string FleetCell { get; set; }


        /// <summary>
        /// Gets or sets the fleet cell identifier.
        /// </summary>
        /// <value>
        /// The fleet cell identifier.
        /// </value>
        public string FleetCellId { get; set; }


        /// <summary>
        /// Gets or sets the fleet manager.
        /// </summary>
        /// <value>
        /// The fleet manager.
        /// </value>
        public string FleetManager { get; set; }


        /// <summary>
        /// Gets or sets the fleet manager identifier.
        /// </summary>
        /// <value>
        /// The fleet manager identifier.
        /// </value>
        public string FleetManagerId { get; set; }


        /// <summary>
        /// Gets or sets the fuel efficiency l3 m.
        /// </summary>
        /// <value>
        /// The fuel efficiency l3 m.
        /// </value>
        public decimal? FuelEfficiencyL3M { get; set; }


        /// <summary>
        /// Gets or sets the fuel efficiency prior.
        /// </summary>
        /// <value>
        /// The fuel efficiency prior.
        /// </value>
        public decimal? FuelEfficiencyPrior { get; set; }


        /// <summary>
        /// Gets or sets the funding days underfunding.
        /// </summary>
        /// <value>
        /// The funding days underfunding.
        /// </value>
        public int? FundingDaysUnderfunding { get; set; }


        /// <summary>
        /// Gets or sets the funding total excl.
        /// </summary>
        /// <value>
        /// The funding total excl.
        /// </value>
        public decimal? FundingTotalExcl { get; set; }


        /// <summary>
        /// Gets or sets the gross tonnage.
        /// </summary>
        /// <value>
        /// The gross tonnage.
        /// </value>
        public int? GrossTonnage { get; set; }


        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }


        /// <summary>
        /// Gets or sets the imo.
        /// </summary>
        /// <value>
        /// The imo.
        /// </value>
        public string Imo { get; set; }


        /// <summary>
        /// Gets or sets the last tech inspection.
        /// </summary>
        /// <value>
        /// The last tech inspection.
        /// </value>
        public DateTime? LastTechInspection { get; set; }


        /// <summary>
        /// Gets or sets the last tech inspection weeks.
        /// </summary>
        /// <value>
        /// The last tech inspection weeks.
        /// </value>
        public int? LastTechInspectionWeeks { get; set; }


        /// <summary>
        /// Gets or sets the lti.
        /// </summary>
        /// <value>
        /// The lti.
        /// </value>
        public decimal? Lti { get; set; }


        /// <summary>
        /// Gets or sets the ltif ratio r3 m.
        /// </summary>
        /// <value>
        /// The ltif ratio r3 m.
        /// </value>
        public decimal? LtifRatioR3M { get; set; }


        /// <summary>
        /// Gets or sets the ltif ratio r3 m worst vessel.
        /// </summary>
        /// <value>
        /// The ltif ratio r3 m worst vessel.
        /// </value>
        public bool? LtifRatioR3MWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the lti r3 m.
        /// </summary>
        /// <value>
        /// The lti r3 m.
        /// </value>
        public decimal? LtiR3M { get; set; }


        /// <summary>
        /// Gets or sets the medical fatalities.
        /// </summary>
        /// <value>
        /// The medical fatalities.
        /// </value>
        public int? MedicalFatalities { get; set; }


        /// <summary>
        /// Gets or sets the medical fatalities r3 m.
        /// </summary>
        /// <value>
        /// The medical fatalities r3 m.
        /// </value>
        public int? MedicalFatalitiesR3M { get; set; }


        /// <summary>
        /// Gets or sets the medical illness rate r3 m.
        /// </summary>
        /// <value>
        /// The medical illness rate r3 m.
        /// </value>
        public decimal? MedicalIllnessRateR3M { get; set; }


        /// <summary>
        /// Gets or sets the medical sign offs.
        /// </summary>
        /// <value>
        /// The medical sign offs.
        /// </value>
        public int? MedicalSignOffs { get; set; }


        /// <summary>
        /// Gets or sets the medical sign offs r3 m.
        /// </summary>
        /// <value>
        /// The medical sign offs r3 m.
        /// </value>
        public int? MedicalSignOffsR3M { get; set; }


        /// <summary>
        /// Gets or sets the month.
        /// </summary>
        /// <value>
        /// The month.
        /// </value>
        public int? Month { get; set; }


        /// <summary>
        /// Gets or sets the name of the month.
        /// </summary>
        /// <value>
        /// The name of the month.
        /// </value>
        public string MonthName { get; set; }


        /// <summary>
        /// Gets or sets the month year.
        /// </summary>
        /// <value>
        /// The month year.
        /// </value>
        public string MonthYear { get; set; }


        /// <summary>
        /// Gets or sets the off hire days.
        /// </summary>
        /// <value>
        /// The off hire days.
        /// </value>
        public decimal? OffHireDays { get; set; }


        /// <summary>
        /// Gets or sets the off hire days r3 m.
        /// </summary>
        /// <value>
        /// The off hire days r3 m.
        /// </value>
        public decimal? OffHireDaysR3M { get; set; }


        /// <summary>
        /// Gets or sets the off hire worst vessel.
        /// </summary>
        /// <value>
        /// The off hire worst vessel.
        /// </value>
        public bool? OffHireWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the office.
        /// </summary>
        /// <value>
        /// The office.
        /// </value>
        public string Office { get; set; }


        /// <summary>
        /// Gets or sets the omv findings.
        /// </summary>
        /// <value>
        /// The omv findings.
        /// </value>
        public decimal? OmvFindings { get; set; }


        /// <summary>
        /// Gets or sets the omv findings r6 m.
        /// </summary>
        /// <value>
        /// The omv findings r6 m.
        /// </value>
        public decimal? OmvFindingsR6M { get; set; }


        /// <summary>
        /// Gets or sets the omv findings ratio r6 m.
        /// </summary>
        /// <value>
        /// The omv findings ratio r6 m.
        /// </value>
        public decimal? OmvFindingsRatioR6M { get; set; }


        /// <summary>
        /// Gets or sets the omv findings worst vessel.
        /// </summary>
        /// <value>
        /// The omv findings worst vessel.
        /// </value>
        public bool? OmvFindingsWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the omv inspections.
        /// </summary>
        /// <value>
        /// The omv inspections.
        /// </value>
        public decimal? OmvInspections { get; set; }


        /// <summary>
        /// Gets or sets the omv inspections r3 m.
        /// </summary>
        /// <value>
        /// The omv inspections r3 m.
        /// </value>
        public decimal? OmvInspectionsR3M { get; set; }


        /// <summary>
        /// Gets or sets the omv inspections r6 m.
        /// </summary>
        /// <value>
        /// The omv inspections r6 m.
        /// </value>
        public decimal? OmvInspectionsR6M { get; set; }


        /// <summary>
        /// Gets or sets the omv rejections.
        /// </summary>
        /// <value>
        /// The omv rejections.
        /// </value>
        public decimal? OmvRejections { get; set; }


        /// <summary>
        /// Gets or sets the omv rejections na.
        /// </summary>
        /// <value>
        /// The omv rejections na.
        /// </value>
        public bool? OmvRejectionsNa { get; set; }


        /// <summary>
        /// Gets or sets the omv rejections r3 m.
        /// </summary>
        /// <value>
        /// The omv rejections r3 m.
        /// </value>
        public decimal? OmvRejectionsR3M { get; set; }


        /// <summary>
        /// Gets or sets the omv rejections r6 m.
        /// </summary>
        /// <value>
        /// The omv rejections r6 m.
        /// </value>
        public decimal? OmvRejectionsR6M { get; set; }


        /// <summary>
        /// Gets or sets the omv rejections ratio r3 m.
        /// </summary>
        /// <value>
        /// The omv rejections ratio r3 m.
        /// </value>
        public decimal? OmvRejectionsRatioR3M { get; set; }


        /// <summary>
        /// Gets or sets the opex.
        /// </summary>
        /// <value>
        /// The opex.
        /// </value>
        public decimal? Opex { get; set; }


        /// <summary>
        /// Gets or sets the opex budget.
        /// </summary>
        /// <value>
        /// The opex budget.
        /// </value>
        public decimal? OpexBudget { get; set; }


        /// <summary>
        /// Gets or sets the opex total.
        /// </summary>
        /// <value>
        /// The opex total.
        /// </value>
        public decimal? OpexTotal { get; set; }


        /// <summary>
        /// Gets or sets the opex variance.
        /// </summary>
        /// <value>
        /// The opex variance.
        /// </value>
        public decimal? OpexVariance { get; set; }

        //Mine
        /// <summary>
        /// Gets or sets the fleet vessel red.
        /// </summary>
        /// <value>
        /// The fleet vessel red.
        /// </value>
        public int FleetVesselRed { get; set; }


        /// <summary>
        /// Gets or sets the opex worst vessel.
        /// </summary>
        /// <value>
        /// The opex worst vessel.
        /// </value>
        public bool? OpexWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the overdue technical inspection04.
        /// </summary>
        /// <value>
        /// The overdue technical inspection04.
        /// </value>
        public int? OverdueTechnicalInspection04 { get; set; }


        /// <summary>
        /// Gets or sets the overdue technical inspection05.
        /// </summary>
        /// <value>
        /// The overdue technical inspection05.
        /// </value>
        public int? OverdueTechnicalInspection05 { get; set; }


        /// <summary>
        /// Gets or sets the overdue technical inspection46.
        /// </summary>
        /// <value>
        /// The overdue technical inspection46.
        /// </value>
        public int? OverdueTechnicalInspection46 { get; set; }


        /// <summary>
        /// Gets or sets the overdue technical inspection56.
        /// </summary>
        /// <value>
        /// The overdue technical inspection56.
        /// </value>
        public int? OverdueTechnicalInspection56 { get; set; }


        /// <summary>
        /// Gets or sets the overdue technical inspection6 plus.
        /// </summary>
        /// <value>
        /// The overdue technical inspection6 plus.
        /// </value>
        public int? OverdueTechnicalInspection6Plus { get; set; }


        /// <summary>
        /// Gets or sets the overdue technical inspection wv.
        /// </summary>
        /// <value>
        /// The overdue technical inspection wv.
        /// </value>
        public bool? OverdueTechnicalInspectionWv { get; set; }


        /// <summary>
        /// Gets or sets the PSC deficiencies.
        /// </summary>
        /// <value>
        /// The PSC deficiencies.
        /// </value>
        public decimal? PscDeficiencies { get; set; }


        /// <summary>
        /// Gets or sets the PSC deficiencies r3 m.
        /// </summary>
        /// <value>
        /// The PSC deficiencies r3 m.
        /// </value>
        public decimal? PscDeficienciesR3M { get; set; }


        /// <summary>
        /// Gets or sets the PSC deficiencies ratio r3 m.
        /// </summary>
        /// <value>
        /// The PSC deficiencies ratio r3 m.
        /// </value>
        public decimal? PscDeficienciesRatioR3M { get; set; }


        /// <summary>
        /// Gets or sets the PSC deficiencies worst vessel.
        /// </summary>
        /// <value>
        /// The PSC deficiencies worst vessel.
        /// </value>
        public bool? PscDeficienciesWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the PSC detentions.
        /// </summary>
        /// <value>
        /// The PSC detentions.
        /// </value>
        public int? PscDetentions { get; set; }


        /// <summary>
        /// Gets or sets the PSC detentions r3 m.
        /// </summary>
        /// <value>
        /// The PSC detentions r3 m.
        /// </value>
        public int? PscDetentionsR3M { get; set; }


        /// <summary>
        /// Gets or sets the PSC inspections.
        /// </summary>
        /// <value>
        /// The PSC inspections.
        /// </value>
        public decimal? PscInspections { get; set; }


        /// <summary>
        /// Gets or sets the PSC inspections r3 m.
        /// </summary>
        /// <value>
        /// The PSC inspections r3 m.
        /// </value>
        public decimal? PscInspectionsR3M { get; set; }


        /// <summary>
        /// Gets or sets the right ship.
        /// </summary>
        /// <value>
        /// The right ship.
        /// </value>
        public decimal? RightShip { get; set; }


        /// <summary>
        /// Gets or sets the rightship na.
        /// </summary>
        /// <value>
        /// The rightship na.
        /// </value>
        public bool? RightshipNa { get; set; }


        /// <summary>
        /// Gets or sets the right ship r3 m.
        /// </summary>
        /// <value>
        /// The right ship r3 m.
        /// </value>
        public decimal? RightShipR3M { get; set; }


        /// <summary>
        /// Gets or sets the right ship worst vessel.
        /// </summary>
        /// <value>
        /// The right ship worst vessel.
        /// </value>
        public bool? RightShipWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the serious incidents.
        /// </summary>
        /// <value>
        /// The serious incidents.
        /// </value>
        public int? SeriousIncidents { get; set; }


        /// <summary>
        /// Gets or sets the serious incidents r3 m.
        /// </summary>
        /// <value>
        /// The serious incidents r3 m.
        /// </value>
        public int? SeriousIncidentsR3M { get; set; }


        /// <summary>
        /// Gets or sets the serious incidents worst vessel.
        /// </summary>
        /// <value>
        /// The serious incidents worst vessel.
        /// </value>
        public bool? SeriousIncidentsWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the total overdue critical tasks.
        /// </summary>
        /// <value>
        /// The total overdue critical tasks.
        /// </value>
        public int? TotalOverdueCriticalTasks { get; set; }


        /// <summary>
        /// Gets or sets the total overdue critical tasks lm.
        /// </summary>
        /// <value>
        /// The total overdue critical tasks lm.
        /// </value>
        public int? TotalOverdueCriticalTasksLm { get; set; }


        /// <summary>
        /// Gets or sets the total overdue critical tasks lm prior.
        /// </summary>
        /// <value>
        /// The total overdue critical tasks lm prior.
        /// </value>
        public int? TotalOverdueCriticalTasksLmPrior { get; set; }


        /// <summary>
        /// Gets or sets the total planned critical tasks.
        /// </summary>
        /// <value>
        /// The total planned critical tasks.
        /// </value>
        public int? TotalPlannedCriticalTasks { get; set; }


        /// <summary>
        /// Gets or sets the total planned critical tasks lm.
        /// </summary>
        /// <value>
        /// The total planned critical tasks lm.
        /// </value>
        public int? TotalPlannedCriticalTasksLm { get; set; }


        /// <summary>
        /// Gets or sets the total planned critical tasks lm prior.
        /// </summary>
        /// <value>
        /// The total planned critical tasks lm prior.
        /// </value>
        public int? TotalPlannedCriticalTasksLmPrior { get; set; }


        /// <summary>
        /// Gets or sets the TRC.
        /// </summary>
        /// <value>
        /// The TRC.
        /// </value>
        public decimal? Trc { get; set; }


        /// <summary>
        /// Gets or sets the TRCF ratio r3 m.
        /// </summary>
        /// <value>
        /// The TRCF ratio r3 m.
        /// </value>
        public decimal? TrcfRatioR3M { get; set; }


        /// <summary>
        /// Gets or sets the TRCF ratio r3 m worst vessel.
        /// </summary>
        /// <value>
        /// The TRCF ratio r3 m worst vessel.
        /// </value>
        public bool? TrcfRatioR3MWorstVessel { get; set; }


        /// <summary>
        /// Gets or sets the TRC r3 m.
        /// </summary>
        /// <value>
        /// The TRC r3 m.
        /// </value>
        public decimal? TrcR3M { get; set; }


        /// <summary>
        /// Gets or sets the ves age.
        /// </summary>
        /// <value>
        /// The ves age.
        /// </value>
        public int? VesAge { get; set; }


        /// <summary>
        /// Gets or sets the vessel.
        /// </summary>
        /// <value>
        /// The vessel.
        /// </value>
        public string Vessel { get; set; }


        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }


        /// <summary>
        /// Gets or sets the ves type child.
        /// </summary>
        /// <value>
        /// The ves type child.
        /// </value>
        public string VesTypeChild { get; set; }


        /// <summary>
        /// Gets or sets the year.
        /// </summary>
        /// <value>
        /// The year.
        /// </value>
        public int? Year { get; set; }


        /// <summary>
        /// Gets or sets the year month.
        /// </summary>
        /// <value>
        /// The year month.
        /// </value>
        public DateTime? YearMonth { get; set; }

        /// <summary>
        /// Gets the tankers in fleet.
        /// </summary>
        /// <value>
        /// The tankers in fleet.
        /// </value>
        public int? TankersInFleet
        {
            get { return !string.IsNullOrWhiteSpace(VesTypeChild) && (VesTypeChild.ToUpper().Contains("TANKER") || VesTypeChild.ToUpper().Contains("L.P.G.")) ? 1 : 0; }
        }
        #endregion

        #region Tooltip fields

        //S n PSCDetentionsToolTip
        /// Gets the serious incidents tool tip.
        /// </summary>
        /// <value>
        /// The serious incidents tool tip.
        /// </value>
        public string SeriousIncidentsToolTip
        {
            get
            {
                return SeriousIncidents + " Serious incidents last month, \n" + SeriousIncidentsR3M + " Serious Incidents last 3 months";
            }
        }

        /// <summary>
        /// Gets the PSC detentions tool tip.
        /// </summary>
        /// <value>
        /// The PSC detentions tool tip.
        /// </value>
        public string PSCDetentionsToolTip
        {
            get
            {
                return PscDetentions + " Detentions last month \n" + PscDetentionsR3M + " Detentions last 3 months";
            }
        }

        /// <summary>
        /// Gets the PSC deficiencies tool tip.
        /// </summary>
        /// <value>
        /// The PSC deficiencies tool tip.
        /// </value>
        public string PSCDeficienciesToolTip
        {
            get
            {
                return "PSC Deficiency Ratio L3M = " + PscDeficienciesRatioR3M; //fleet
            }
        }

        /// <summary>
        /// Gets the PSC deficiencies trend.
        /// </summary>
        /// <value>
        /// The PSC deficiencies trend.
        /// </value>
        public decimal? PSCDeficienciesTrend { get { return CalculateVariance(PscDeficienciesRatioR3M, PscDeficiencies); } } //fleet

        /// <summary>
        /// Gets the ltif tool tip.
        /// </summary>
        /// <value>
        /// The ltif tool tip.
        /// </value>
        public string LTIFToolTip
        {
            get
            {
                return string.Format("{0} LTIs Last Month,\n", Convert.ToInt32(Lti))
                    + string.Format("{0} LTIs Last 3 Month,\n", Convert.ToInt32(LtiR3M))
                    + string.Format("LTIF R3M = {0}", LtifRatioR3M);
            }
        }



        //Commercial
        /// <summary>
        /// Gets the off hire days tool tip.
        /// </summary>
        /// <value>
        /// The off hire days tool tip.
        /// </value>
        public string OffHireDaysToolTip
        {
            get
            {
                return "OffHire Ratio to Vessels = " + OffHireDaysR3M + " hours";
            }
        }

        /// <summary>
        /// Gets or sets the right ship tool tip.
        /// </summary>
        /// <value>
        /// The right ship tool tip.
        /// </value>
        public string RightShipToolTip { get { return "RightShip last month = " + RightShip; } } //pending

        /// <summary>
        /// Gets the omv findings tool tip.
        /// </summary>
        /// <value>
        /// The omv findings tool tip.
        /// </value>
        public string OmvFindingsToolTip
        {
            get
            {
                return "OM Findings ratio L6M = " + OmvFindingsRatioR6M;
            }
        }

        /// <summary>
        /// Gets the omv rejections tool tip.
        /// </summary>
        /// <value>
        /// The omv rejections tool tip.
        /// </value>
        public string OmvRejectionsToolTip
        {
            get
            {
                return "OM Rejections LM = " + OmvRejections
                    + "\nOM Rejections L3M = " + OmvRejectionsR3M
                + "\n OM Rejections L6M = " + OmvRejectionsR6M;
            }
        }


        //Technical
        /// <summary>
        /// Gets or sets the opex tool tip.
        /// </summary>
        /// <value>
        /// The opex tool tip.
        /// </value>
        public string OpexToolTip
        {
            get

            {
                return "Opex budget = " + (Math.Round(OpexBudget.GetValueOrDefault(), 2)).ToString("N2", CultureInfo.InvariantCulture);// "Opex = " + OpexRAG;
            }
        }

        /// <summary>
        /// Gets the overdue technical inspection tool tip.
        /// </summary>
        /// <value>
        /// The overdue technical inspection tool tip.
        /// </value>
        public string OverdueTechnicalInspectionToolTip
        {
            get
            {
                return string.Format("Last Insp between 0 - 5 months = {0}\n", (OverdueTechnicalInspection05 == 0 && OverdueTechnicalInspection6Plus == 0) ? "Yes" : "No")
                  + string.Format("Last Insp between 5 - 6 months = {0}\n", OverdueTechnicalInspection56 > 0 ? "Yes" : "No")
                 + string.Format("Last Insp over 6 months = {0}", OverdueTechnicalInspection6Plus > 0 ? "Yes" : "No");
            }
        }

        //Crew

        /// <summary>
        /// Gets the crew overdue tool tip.
        /// </summary>
        /// <value>
        /// The crew overdue tool tip.
        /// </value>
        public string CrewOverdueToolTip
        {
            get
            {
                //return "Crew Overdue EOC +30 days = " + CrewOverdueReliefs30Plus;
                return ((!CrewOnboard.HasValue) || (CrewOnboard.HasValue && CrewOnboard.Value == 0)) ? string.Format("Crew Overdue EOC +30 days = 0.00%") :
                           string.Format("Crew Overdue EOC +30 days = {0}%", Math.Round(Convert.ToDecimal(CrewOverdueReliefs30Plus / CrewOnboard * 100), 2));
            }
        }

        // H nWB

        /// <summary>
        /// Gets the medical illness tool tip.
        /// </summary>
        /// <value>
        /// The medical illness tool tip.
        /// </value>
        public string MedicalIllnessToolTip
        {
            get
            {
                return "Medical Illness Rate L3M = " + MedicalIllnessRateR3M;
            }
        }

        //Environment

        /// <summary>
        /// Gets the emissions tool tip.
        /// </summary>
        /// <value>
        /// The emissions tool tip.
        /// </value>
        public string EmissionsToolTip
        {
            get
            {
                return string.Format("CO2 Emissions last  month versus 12 month average ={0}%", EmissionsEfficiencyIndex);// + EmissionsR12M; // Missing
            }
        }

        //Asset
        /// <summary>
        /// Gets the critical PMS tool tip.
        /// </summary>
        /// <value>
        /// The critical PMS tool tip.
        /// </value>
        public string CriticalPmsToolTip
        {
            get
            {
                return "Critical PMS last month = " + CriticalPmsLm + "%";
            }
        }

        /// <summary>
        /// Gets the fuel efficiency tool tip.
        /// </summary>
        /// <value>
        /// The fuel efficiency tool tip.
        /// </value>
        public string FuelEfficiencyToolTip
        {
            get
            {
                return "Fuel Efficiency L3M = " + FuelEfficiencyL3M + "%";
            }
        }

        /// <summary>
        /// Gets or sets the budget.
        /// </summary>
        /// <value>
        /// The budget.
        /// </value>
        public string OverUnderBudget { get { return OpexVariance.HasValue && OpexVariance < 0 ? "over Budget" : "under Budget"; } }

        /// <summary>
        /// Gets the opex month.
        /// </summary>
        /// <value>
        /// The opex month.
        /// </value>
        public string OpexMonth { get { return Month.HasValue ? DateTime.Now.AddMonths(-2).ToString("MMM") + "-" + DateTime.Now.AddMonths(-2).ToString("yy") : string.Empty; } }
        #endregion

        #region Rag Variables


        /// <summary>
        /// Gets the serious incidents rag.
        /// </summary>
        /// <value>
        /// The serious incidents rag.
        /// </value>
        public int SeriousIncidentsRag
        {
            get
            {
                int retval = 1;
                if (SeriousIncidents > 0) retval = -1;
                if (SeriousIncidentsR3M > 0 && SeriousIncidents == 0) retval = 0;
                return retval;
            }
        }

        /// <summary>
        /// Gets the PSC detentions rag.
        /// </summary>
        /// <value>
        /// The PSC detentions rag.
        /// </value>
        public int PscDetentionsRag
        {
            get
            {
                int retval = 1;
                if (PscDetentions > 0) retval = -1;
                if (PscDetentionsR3M > 0 && PscDetentions == 0) retval = 0;
                return retval;
            }
        }

        /// <summary>
        /// Gets the off hire rag.
        /// </summary>
        /// <value>
        /// The off hire rag.
        /// </value>
        public int OffHireRag
        {
            //pending column missing
            get
            {
                return 1;
            }

        }

        /// <summary>
        /// Gets the omv rejections rag.
        /// </summary>
        /// <value>
        /// The omv rejections rag.
        /// </value>
        public int OmvRejectionsRag
        {
            get
            {
                int retval = 1;
                if (OmvRejections > 0) retval = -1;
                if (OmvRejectionsR6M > 0 && OmvRejections == 0) retval = 0;
                return retval;
            }
        }

        /// <summary>
        /// Gets the overdue inspections rag.
        /// </summary>
        /// <value>
        /// The overdue inspections rag.
        /// </value>
        public int OverdueInspectionsRag
        {
            get
            {
                int retval = 1;
                if (OverdueTechnicalInspection6Plus > 0) retval = -1;
                if (OverdueTechnicalInspection56 > 0) retval = 0;
                return retval;
            }
        }
        //old rags

        /// <summary>
        /// Gets the PSC deficiencies rag.
        /// </summary>
        /// <value>
        /// The PSC deficiencies rag.
        /// </value>
        public decimal? PSCDeficienciesRAG { get { return PscDeficienciesRatioR3M; } }
        /// <summary>
        /// Gets the ltifrag.
        /// </summary>
        /// <value>
        /// The ltifrag.
        /// </value>
        public decimal? LTIFRAG
        {
            get
            {
                decimal? retval = null; //green
                if (Lti.GetValueOrDefault() > 0) retval = -1; //red
                if (Lti.GetValueOrDefault() == 0 && LtiR3M.GetValueOrDefault() > 0) retval = 1; //amber
                if (LtiR3M.HasValue && LtiR3M.Value == 0) retval = 0;
                if (!LtifRatioR3M.HasValue) retval = null;
                return retval;
            }
        }

        /// <summary>
        /// Gets the right ship rag.
        /// </summary>
        /// <value>
        /// The right ship rag.
        /// </value>
        public decimal? RightShipRAG { get { return RightShip; } }
        /// <summary>
        /// Gets the omv findings rag.
        /// </summary>
        /// <value>
        /// The omv findings rag.
        /// </value>
        public decimal? OmvFindingsRAG { get { return OmvFindingsRatioR6M; } }
        /// <summary>
        /// Gets the opex rag.
        /// </summary>
        /// <value>
        /// The opex rag.
        /// </value>
        public decimal? OpexRAG { get { return (OpexBudget.GetValueOrDefault() > 0 ? OpexVariance / OpexBudget : 0) * 100; } }
        //overdue technical missing
        /// <summary>
        /// Gets the crew retention rag.
        /// </summary>
        /// <value>
        /// The crew retention rag.
        /// </value>
        public decimal? CrewRetentionRAG { get { return CrewRetention; } }

        /// <summary>
        /// Gets the crew overdue rag.
        /// </summary>
        /// <value>
        /// The crew overdue rag.
        /// </value>
        public decimal? CrewOverdueRAG { get { return CrewOverdueReliefs30Plus / CrewOnboard; } }
        /// <summary>
        /// Gets the medical illness rag.
        /// </summary>
        /// <value>
        /// The medical illness rag.
        /// </value>
        public decimal? MedicalIllnessRAG { get { return MedicalIllnessRateR3M; } }
        /// <summary>
        /// Gets the critical PMS rag.
        /// </summary>
        /// <value>
        /// The critical PMS rag.
        /// </value>
        public decimal? CriticalPmsRAG { get { return CriticalPmsLm; } }
        /// <summary>
        /// Gets the fuel efficiency rag.
        /// </summary>
        /// <value>
        /// The fuel efficiency rag.
        /// </value>
        public decimal? FuelEfficiencyRAG { get { return FuelEfficiencyL3M; } }

        #endregion

        #region Methods

        /// <summary>
        /// Calculates the variance.
        /// </summary>
        /// <param name="currentValue">The current value.</param>
        /// <param name="previousValue">The previous value.</param>
        /// <returns></returns>
        private decimal? CalculateVariance(decimal? currentValue, decimal? previousValue)
        {
            return previousValue != null && previousValue.Value > 0 ? (currentValue - previousValue) / previousValue : 0;
        }

        #endregion
    }
}
