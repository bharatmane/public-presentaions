﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntitySrMgmtNonPOInvoiceDetailViewModel.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntitySrMgmtNonPOInvoiceDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string EntityName
        {
            get
            {
                return CoyName + " - " + CoyId;
            }
        }
        public string SupplierName { get; set; }
        public string Cur { get; set; }
        public decimal? Amount { get; set; }
        public decimal? AmountUSD { get; set; }
        public string VoucherNumber { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? DueDate { get; set; }
        public DateTime? SupplierDate { get; set; }

        public string AuthLevel { get; set; }
    }
}
