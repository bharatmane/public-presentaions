﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntitySrMgmtPurchaseOrderDetailViewModel.
    /// </summary>
    /// <seealso cref="BaseViewModel" />
    public class EntitySrMgmtPurchaseOrderDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string EntityName
        {
            get
            {
                return CoyName + " - " + CoyId;
            }
        }
        public string OrderNumber { get; set; }
        public string OrderId { get; set; }
        public string OrderTitle { get; set; }
        public DateTime? EnteredDate { get; set; }
        public DateTime? ExpDate { get; set; }
        public string Type { get; set; }
        public string AccountCode { get; set; }
        public string AuthLevel { get; set; }
    }
}
