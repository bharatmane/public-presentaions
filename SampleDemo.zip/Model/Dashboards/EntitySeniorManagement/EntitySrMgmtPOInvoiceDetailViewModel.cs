﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntitySrMgmtPOInvoiceDetailViewModel.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntitySrMgmtPOInvoiceDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string EntityName
        {
            get
            {
                return CoyName + " - " + CoyId;
            }
        }
        public string InvoiceNumber { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public string PONumber { get; set; }
        public string Supplier { get; set; }
        public string Cur { get; set; }
        public decimal? Goods { get; set; }
        public decimal? Freight { get; set; }
        public decimal? Tax { get; set; }
        public decimal? Amount { get; set; }
        public string OrderId { get; set; }
        public string AuthLevel { get; set; }

        public string EicId { get; set; }
    }
}
