﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntitySrMgmtJournalDetailViewModel.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntitySrMgmtJournalDetailViewModel : BaseViewModel
    {
        #region Properties
        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the name of the coy.
        /// </summary>
        /// <value>
        /// The name of the coy.
        /// </value>
        public string CoyName { get; set; }

        /// <summary>
        /// Gets the name of the entity.
        /// </summary>
        /// <value>
        /// The name of the entity.
        /// </value>
        public string EntityName
        {
            get
            {
                return CoyName + " - " + CoyId;
            }
        }

        /// <summary>Gets or sets the voucher number.</summary>
        /// <value>The voucher number.</value>
        public string VoucherNumber { get; set; }

        /// <summary>Gets or sets the type of the journal.</summary>
        /// <value>The type of the journal.</value>
        public string JournalType { get; set; }

        /// <summary>Gets or sets the ledger lines.</summary>
        /// <value>The ledger lines.</value>
        public int LedgerLines { get; set; }

        /// <summary>
        /// Gets or sets the transaction date.
        /// </summary>
        /// <value>
        /// The transaction date.
        /// </value>
        public DateTime? TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>Gets or sets the authentication level.</summary>
        /// <value>The authentication level.</value>
        public string AuthLevel { get; set; }

        /// <summary>
        /// The is rejected journal
        /// </summary>
        private bool _isRejectedJournal;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is rejected journal.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is rejected journal; otherwise, <c>false</c>.
        /// </value>
        public bool IsRejectedJournal
        {
            get { return _isRejectedJournal; }
            set { Set(() => IsRejectedJournal, ref _isRejectedJournal, value); }
        }

        #endregion
    }
}
