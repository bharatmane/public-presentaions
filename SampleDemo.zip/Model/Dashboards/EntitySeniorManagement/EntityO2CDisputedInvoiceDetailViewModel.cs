﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntityO2CDisputedInvoiceDetailViewModel.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntityO2CDisputedInvoiceDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string CmpId { get; set; }
        public string SupplierCompanyName { get; set; }
        public int? SupplierCompanyPriorityType { get; set; }
        public string SupplierCompanyPriorityTypeName { get; set; }
        public string InhId { get; set; }
        public int? InhStatus { get; set; }
        public DateTime? InvoiceSupplyDate { get; set; }
        public DateTime? InvoiceDueDate { get; set; }
        public string InvoiceCurId { get; set; }
        public decimal? InvoiceAmount { get; set; }
        public decimal? InvoiceAmountUSD { get; set; }
        public string InvoiceVoucherNumber { get; set; }
        public string InvoiceSupplierRefNumber { get; set; }
        public string AstId { get; set; }
    }
}
