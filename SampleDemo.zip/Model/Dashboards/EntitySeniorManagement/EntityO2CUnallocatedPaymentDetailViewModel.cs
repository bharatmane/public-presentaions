﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntityO2CUnallocatedPaymentDetailViewModel
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntityO2CUnallocatedPaymentDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string VoucherNo { get; set; }
        public DateTime? DateSupInv { get; set; }
        public string InvoiceNo { get; set; }
        public string Customer { get; set; }
        public string CustCoy { get; set; }
        public string Currency { get; set; }
        public decimal? InvoiceAmount { get; set; }
        public decimal? OutstandingAmount { get; set; }
        public decimal? FunctionalAmount { get; set; }
        public string ApType { get; set; }
        public int InvoiceStatus { get; set; }
    }
}
