﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntityO2CSalesInvoiceApprovedDetailViewModel.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntityO2CSalesInvoiceApprovedDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string InvId { get; set; }
        public string SrcCmpId { get; set; }
        public string DstCmpId { get; set; }
        public string CmpName { get; set; }
        public decimal? Amount { get; set; }
        public decimal? AmountUSD { get; set; }
        public string CurId { get; set; }
        public bool? IsCreditNote { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public int? Attribute { get; set; }
        public string DepId { get; set; }
        public string DepName { get; set; }
        public string Note { get; set; }
        public int? PaymentTerm { get; set; }
    }
}
