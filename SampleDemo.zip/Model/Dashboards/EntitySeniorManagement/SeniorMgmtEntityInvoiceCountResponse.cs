﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is output response for Entity Senior Management Dashboard count summary.
    /// </summary>
    public class SeniorMgmtEntityInvoiceCountResponse : BaseViewModel
    {
        /// <summary>
        /// The coy identifier
        /// </summary>
        private string _coyId;

        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId
        {
            get { return _coyId; }
            set { Set(() => CoyId, ref _coyId, value); }
        }

        /// <summary>
        /// The coy name
        /// </summary>
        private string _coyName;

        /// <summary>
        /// Gets or sets the name of the coy.
        /// </summary>
        /// <value>
        /// The name of the coy.
        /// </value>
        public string CoyName
        {
            get { return _coyName; }
            set { Set(() => CoyName, ref _coyName, value); }
        }

        /// <summary>
        /// The sales invoice awaiting approval count
        /// </summary>
        private int _salesInvoiceAwaitingApprovalCnt;

        /// <summary>
        /// Gets or sets the sales invoice awaiting approval count.
        /// </summary>
        /// <value>
        /// The sales invoice awaiting approval count.
        /// </value>
        public int SalesInvoiceAwaitingApprovalCnt
        {
            get { return _salesInvoiceAwaitingApprovalCnt; }
            set { Set(() => SalesInvoiceAwaitingApprovalCnt, ref _salesInvoiceAwaitingApprovalCnt, value); }
        }

        /// <summary>
        /// The sales invoice awaiting approval amt usd.
        /// </summary>
        private decimal? _salesInvoiceAwaitingApprovalAmtUSD;

        /// <summary>
        /// Gets or sets the sales invoice awaiting approval amt usd.
        /// </summary>
        /// <value>
        /// The sales invoice awaiting approval amt usd.
        /// </value>
        public decimal? SalesInvoiceAwaitingApprovalAmtUSD
        {
            get { return _salesInvoiceAwaitingApprovalAmtUSD; }
            set { Set(() => SalesInvoiceAwaitingApprovalAmtUSD, ref _salesInvoiceAwaitingApprovalAmtUSD, value); }
        }

        /// <summary>
        /// The sales credit note awaiting approval count
        /// </summary>
        private int _salesCreditNoteAwaitingApprovalCnt;

        /// <summary>
        /// Gets or sets the sales credit note awaiting approval count.
        /// </summary>
        /// <value>
        /// The sales credit note awaiting approval count.
        /// </value>
        public int SalesCreditNoteAwaitingApprovalCnt
        {
            get { return _salesCreditNoteAwaitingApprovalCnt; }
            set { Set(() => SalesCreditNoteAwaitingApprovalCnt, ref _salesCreditNoteAwaitingApprovalCnt, value); }
        }

        /// <summary>
        /// The sales credit note awaiting approval amt usd
        /// </summary>
        private decimal? _salesCreditNoteAwaitingApprovalAmtUSD;

        /// <summary>
        /// Gets or sets the sales credit note awaiting approval amt usd.
        /// </summary>
        /// <value>
        /// The sales credit note awaiting approval amt usd.
        /// </value>
        public decimal? SalesCreditNoteAwaitingApprovalAmtUSD
        {
            get { return _salesCreditNoteAwaitingApprovalAmtUSD; }
            set { Set(() => SalesCreditNoteAwaitingApprovalAmtUSD, ref _salesCreditNoteAwaitingApprovalAmtUSD, value); }
        }

        /// <summary>
        /// The sales invoice disputed count
        /// </summary>
        private int _salesInvoiceDisputedCnt;

        /// <summary>
        /// Gets or sets the sales invoice disputed count.
        /// </summary>
        /// <value>
        /// The sales invoice disputed count.
        /// </value>
        public int SalesInvoiceDisputedCnt
        {
            get { return _salesInvoiceDisputedCnt; }
            set { Set(() => SalesInvoiceDisputedCnt, ref _salesInvoiceDisputedCnt, value); }
        }

        /// <summary>
        /// The sales invoice disputed amt usd.
        /// </summary>
        private decimal? _salesInvoiceDisputedAmtUSD;

        /// <summary>
        /// Gets or sets the sales invoice disputed amt usd.
        /// </summary>
        /// <value>
        /// The sales invoice disputed amt usd.
        /// </value>
        public decimal? SalesInvoiceDisputedAmtUSD
        {
            get { return _salesInvoiceDisputedAmtUSD; }
            set { Set(() => SalesInvoiceDisputedAmtUSD, ref _salesInvoiceDisputedAmtUSD, value); }
        }

        /// <summary>
        /// The non po awaiting approval count
        /// </summary>
        private int _nonPOAwaitingApprovalCnt;

        /// <summary>
        /// Gets or sets the non po awaiting approval count.
        /// </summary>
        /// <value>
        /// The non po awaiting approval count.
        /// </value>
        public int NonPOAwaitingApprovalCnt
        {
            get { return _nonPOAwaitingApprovalCnt; }
            set { Set(() => NonPOAwaitingApprovalCnt, ref _nonPOAwaitingApprovalCnt, value); }
        }

        /// <summary>
        /// The non po awaiting approval amt usd
        /// </summary>
        private decimal? _nonPOAwaitingApprovalAmtUSD;

        /// <summary>
        /// Gets or sets the non po awaiting approval amt usd.
        /// </summary>
        /// <value>
        /// The non po awaiting approval amt usd.
        /// </value>
        public decimal? NonPOAwaitingApprovalAmtUSD
        {
            get { return _nonPOAwaitingApprovalAmtUSD; }
            set { Set(() => NonPOAwaitingApprovalAmtUSD, ref _nonPOAwaitingApprovalAmtUSD, value); }
        }

        /// <summary>
        /// The non po credit note awaiting approval count
        /// </summary>
        private int _nonPOCreditNoteAwaitingApprovalCnt;

        /// <summary>
        /// Gets or sets the non po credit note awaiting approval count.
        /// </summary>
        /// <value>
        /// The non po credit note awaiting approval count.
        /// </value>
        public int NonPOCreditNoteAwaitingApprovalCnt
        {
            get { return _nonPOCreditNoteAwaitingApprovalCnt; }
            set { Set(() => NonPOCreditNoteAwaitingApprovalCnt, ref _nonPOCreditNoteAwaitingApprovalCnt, value); }
        }

        /// <summary>
        /// The non po credit note awaiting approval amt usd
        /// </summary>
        private decimal? _nonPOCreditNoteAwaitingApprovalAmtUSD;

        /// <summary>
        /// Gets or sets the non po credit note awaiting approval amt usd.
        /// </summary>
        /// <value>
        /// The non po credit note awaiting approval amt usd.
        /// </value>
        public decimal? NonPOCreditNoteAwaitingApprovalAmtUSD
        {
            get { return _nonPOCreditNoteAwaitingApprovalAmtUSD; }
            set { Set(() => NonPOCreditNoteAwaitingApprovalAmtUSD, ref _nonPOCreditNoteAwaitingApprovalAmtUSD, value); }
        }

        /// <summary>
        /// The non po disputed count
        /// </summary>
        private int _nonPODisputedCnt;

        /// <summary>
        /// Gets or sets the non po disputed count.
        /// </summary>
        /// <value>
        /// The non po disputed count.
        /// </value>
        public int NonPODisputedCnt
        {
            get { return _nonPODisputedCnt; }
            set { Set(() => NonPODisputedCnt, ref _nonPODisputedCnt, value); }
        }

        /// <summary>
        /// The non po disputed amt usd
        /// </summary>
        private decimal? _nonPODisputedAmtUSD;

        /// <summary>
        /// Gets or sets the non po disputed amt usd.
        /// </summary>
        /// <value>
        /// The non po disputed amt usd.
        /// </value>
        public decimal? NonPODisputedAmtUSD
        {
            get { return _nonPODisputedAmtUSD; }
            set { Set(() => NonPODisputedAmtUSD, ref _nonPODisputedAmtUSD, value); }
        }

        /// <summary>
        /// The purchase invoice awaiting approval count
        /// </summary>
        private int _purchaseInvoiceAwaitingApprovalCnt;

        /// <summary>
        /// Gets or sets the purchase invoice awaiting approval count.
        /// </summary>
        /// <value>
        /// The purchase invoice awaiting approval count.
        /// </value>
        public int PurchaseInvoiceAwaitingApprovalCnt
        {
            get { return _purchaseInvoiceAwaitingApprovalCnt; }
            set { Set(() => PurchaseInvoiceAwaitingApprovalCnt, ref _purchaseInvoiceAwaitingApprovalCnt, value); }
        }

        /// <summary>
        /// The purchase invoice awaiting approval amt usd
        /// </summary>
        private decimal? _purchaseInvoiceAwaitingApprovalAmtUSD;

        /// <summary>
        /// Gets or sets the purchase invoice awaiting approval amt usd.
        /// </summary>
        /// <value>
        /// The purchase invoice awaiting approval amt usd.
        /// </value>
        public decimal? PurchaseInvoiceAwaitingApprovalAmtUSD
        {
            get { return _purchaseInvoiceAwaitingApprovalAmtUSD; }
            set { Set(() => PurchaseInvoiceAwaitingApprovalAmtUSD, ref _purchaseInvoiceAwaitingApprovalAmtUSD, value); }
        }

        /// <summary>
        /// The purchase credit note awaiting approval count
        /// </summary>
        private int _purchaseCreditNoteAwaitingApprovalCnt;

        /// <summary>
        /// Gets or sets the purchase credit note awaiting approval count.
        /// </summary>
        /// <value>
        /// The purchase credit note awaiting approval count.
        /// </value>
        public int PurchaseCreditNoteAwaitingApprovalCnt
        {
            get { return _purchaseCreditNoteAwaitingApprovalCnt; }
            set { Set(() => PurchaseCreditNoteAwaitingApprovalCnt, ref _purchaseCreditNoteAwaitingApprovalCnt, value); }
        }

        /// <summary>
        /// The purchase credit note awaiting approval amt usd.
        /// </summary>
        private decimal? _purchaseCreditNoteAwaitingApprovalAmtUSD;

        /// <summary>
        /// Gets or sets the purchase credit note awaiting approval amt usd.
        /// </summary>
        /// <value>
        /// The purchase credit note awaiting approval amt usd.
        /// </value>
        public decimal? PurchaseCreditNoteAwaitingApprovalAmtUSD
        {
            get { return _purchaseCreditNoteAwaitingApprovalAmtUSD; }
            set { Set(() => PurchaseCreditNoteAwaitingApprovalAmtUSD, ref _purchaseCreditNoteAwaitingApprovalAmtUSD, value); }
        }

        /// <summary>
        /// The purchase invoice disputed count
        /// </summary>
        private int _purchaseInvoiceDisputedCnt;

        /// <summary>
        /// Gets or sets the purchase invoice disputed count.
        /// </summary>
        /// <value>
        /// The purchase invoice disputed count.
        /// </value>
        public int PurchaseInvoiceDisputedCnt
        {
            get { return _purchaseInvoiceDisputedCnt; }
            set { Set(() => PurchaseInvoiceDisputedCnt, ref _purchaseInvoiceDisputedCnt, value); }
        }

        /// <summary>
        /// The purchase invoice disputed amt usd
        /// </summary>
        private decimal? _purchaseInvoiceDisputedAmtUSD;

        /// <summary>
        /// Gets or sets the purchase invoice disputed amt usd.
        /// </summary>
        /// <value>
        /// The purchase invoice disputed amt usd.
        /// </value>
        public decimal? PurchaseInvoiceDisputedAmtUSD
        {
            get { return _purchaseInvoiceDisputedAmtUSD; }
            set { Set(() => PurchaseInvoiceDisputedAmtUSD, ref _purchaseInvoiceDisputedAmtUSD, value); }
        }

        /// <summary>
        /// The purchase order awaiting authorisation count
        /// </summary>
        private int _purchaseOrderAwaitingAuthorisationCnt;

        /// <summary>
        /// Gets or sets the purchase order awaiting authorisation count.
        /// </summary>
        /// <value>
        /// The purchase order awaiting authorisation count.
        /// </value>
        public int PurchaseOrderAwaitingAuthorisationCnt
        {
            get { return _purchaseOrderAwaitingAuthorisationCnt; }
            set { Set(() => PurchaseOrderAwaitingAuthorisationCnt, ref _purchaseOrderAwaitingAuthorisationCnt, value); }
        }

        /// <summary>
        /// The purchase order awaiting authorisation amt usd
        /// </summary>
        private decimal? _purchaseOrderAwaitingAuthorisationAmtUSD;

        /// <summary>
        /// Gets or sets the purchase order awaiting authorisation amt usd.
        /// </summary>
        /// <value>
        /// The purchase order awaiting authorisation amt usd.
        /// </value>
        public decimal? PurchaseOrderAwaitingAuthorisationAmtUSD
        {
            get { return _purchaseOrderAwaitingAuthorisationAmtUSD; }
            set { Set(() => PurchaseOrderAwaitingAuthorisationAmtUSD, ref _purchaseOrderAwaitingAuthorisationAmtUSD, value); }
        }

        /// <summary>
        /// The journal awaiting authorisation
        /// </summary>
        private int _journalAwaitingAuthorisation;

        /// <summary>
        /// Gets or sets the journal awaiting authorisation.
        /// </summary>
        /// <value>
        /// The journal awaiting authorisation.
        /// </value>
        public int JournalAwaitingAuthorisation
        {
            get { return _journalAwaitingAuthorisation; }
            set { Set(() => JournalAwaitingAuthorisation, ref _journalAwaitingAuthorisation, value); }
        }

        /// <summary>
        /// The journal rejected count.
        /// </summary>
        private int _journalRejectedCnt;

        /// <summary>
        /// Gets or sets the journal rejected count.
        /// </summary>
        /// <value>
        /// The journal rejected count.
        /// </value>
        public int JournalRejectedCnt
        {
            get { return _journalRejectedCnt; }
            set { Set(() => JournalRejectedCnt, ref _journalRejectedCnt, value); }
        }

        /// <summary>
        /// The journal disputed count.
        /// </summary>
        private int _journalDisputedCnt;

        /// <summary>
        /// Gets or sets the journal disputed count.
        /// </summary>
        /// <value>
        /// The journal disputed count.
        /// </value>
        public int JournalDisputedCnt
        {
            get { return _journalDisputedCnt; }
            set { Set(() => JournalDisputedCnt, ref _journalDisputedCnt, value); }
        }

        /// <summary>
        /// The sales invoice approved count
        /// </summary>
        private int _salesInvoiceApprovedCnt;

        /// <summary>
        /// Gets or sets the sales invoice approved count.
        /// </summary>
        /// <value>
        /// The sales invoice approved count.
        /// </value>
        public int SalesInvoiceApprovedCnt
        {
            get { return _salesInvoiceApprovedCnt; }
            set { Set(() => SalesInvoiceApprovedCnt, ref _salesInvoiceApprovedCnt, value); }
        }

        /// <summary>
        /// The sales invoice approved amt usd.
        /// </summary>
        private decimal? _salesInvoiceApprovedAmtUSD;

        /// <summary>
        /// Gets or sets the sales invoice approved amt usd.
        /// </summary>
        /// <value>
        /// The sales invoice approved amt usd.
        /// </value>
        public decimal? SalesInvoiceApprovedAmtUSD
        {
            get { return _salesInvoiceApprovedAmtUSD; }
            set { Set(() => SalesInvoiceApprovedAmtUSD, ref _salesInvoiceApprovedAmtUSD, value); }
        }

        /// <summary>
        /// The dispute invoice count
        /// </summary>
        private int _disputedInvoiceCount;

        /// <summary>
        /// Gets or sets the dispute invoice count.
        /// </summary>
        /// <value>
        /// The dispute invoice count.
        /// </value>
        public int DisputedInvoiceCount
        {
            get { return _disputedInvoiceCount; }
            set { Set(() => DisputedInvoiceCount, ref _disputedInvoiceCount, value); }
        }

        /// <summary>
        /// The disputed invoice amount usd
        /// </summary>
        private decimal? _disputedInvoiceAmountUSD;

        /// <summary>
        /// Gets or sets the disputed invoice amount usd.
        /// </summary>
        /// <value>
        /// The disputed invoice amount usd.
        /// </value>
        public decimal? DisputedInvoiceAmountUSD
        {
            get { return _disputedInvoiceAmountUSD; }
            set { Set(() => DisputedInvoiceAmountUSD, ref _disputedInvoiceAmountUSD, value); }
        }

        /// <summary>
        /// The sales credit note approved count
        /// </summary>
        private int _salesCreditNoteApprovedCnt;

        /// <summary>
        /// Gets or sets the sales credit note approved count.
        /// </summary>
        /// <value>
        /// The sales credit note approved count.
        /// </value>
        public int SalesCreditNoteApprovedCnt
        {
            get { return _salesCreditNoteApprovedCnt; }
            set { Set(() => SalesCreditNoteApprovedCnt, ref _salesCreditNoteApprovedCnt, value); }
        }

        /// <summary>
        /// The sales credit note approved amt usd
        /// </summary>
        private decimal? _salesCreditNoteApprovedAmtUSD;

        /// <summary>
        /// Gets or sets the sales credit note approved amt usd.
        /// </summary>
        /// <value>
        /// The sales credit note approved amt usd.
        /// </value>
        public decimal? SalesCreditNoteApprovedAmtUSD
        {
            get { return _salesCreditNoteApprovedAmtUSD; }
            set { Set(() => SalesCreditNoteApprovedAmtUSD, ref _salesCreditNoteApprovedAmtUSD, value); }
        }

        /// <summary>
        /// The unallocated payment count
        /// </summary>
        private int _unallocatedPaymentCnt;

        /// <summary>
        /// Gets or sets the unallocated payment count.
        /// </summary>
        /// <value>
        /// The unallocated payment count.
        /// </value>
        public int UnallocatedPaymentCnt
        {
            get { return _unallocatedPaymentCnt; }
            set { Set(() => UnallocatedPaymentCnt, ref _unallocatedPaymentCnt, value); }
        }

        /// <summary>
        /// The unallocated payment amt usd.
        /// </summary>
        private decimal? _unallocatedPaymentAmtUsd;

        /// <summary>
        /// Gets or sets the unallocated payment amt usd.
        /// </summary>
        /// <value>
        /// The unallocated payment amt usd.
        /// </value>
        public decimal? UnallocatedPaymentAmtUsd
        {
            get { return _unallocatedPaymentAmtUsd; }
            set { Set(() => UnallocatedPaymentAmtUsd, ref _unallocatedPaymentAmtUsd, value); }
        }


    }
}
