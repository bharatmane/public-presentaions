﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.EntitySeniorManagement
{
    /// <summary>
    /// This class is EntitySrMgmtSalesInvoiceDetailViewModel.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class EntitySrMgmtSalesInvoiceDetailViewModel : BaseViewModel
    {
        public string CoyId { get; set; }
        public string CoyName { get; set; }
        public string EntityName
        {
            get
            {
                return CoyName + " - " + CoyId;
            }
        }
        public string InvoiceId { get; set; }
        public string Cur { get; set; }
        public decimal? Amount { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime? DueDate { get; set; }
        public string AuthLevel { get; set; }
        public bool IsCreditNote { get; set; }

        #region O2C - Disputed Invoice Details

        public string CmpId { get; set; }
        public string SupplierCompanyName { get; set; }
        public int? SupplierCompanyPriorityType { get; set; }
        public string SupplierCompanyPriorityTypeName { get; set; }
        public string InhId { get; set; }
        public int? InhStatus { get; set; }
        public DateTime? InvoiceSupplyDate { get; set; }
        public DateTime? InvoiceDueDate { get; set; }
        public string InvoiceCurId { get; set; }
        public decimal? InvoiceAmount { get; set; }
        public decimal? InvoiceAmountUSD { get; set; }
        public string InvoiceVoucherNumber { get; set; }
        public string InvoiceSupplierRefNumber { get; set; }
        public string AstId { get; set; }

        #endregion

        #region O2C - Sales Invoice Approved Details

        public string InvId { get; set; }
        public string SrcCmpId { get; set; }
        public string DstCmpId { get; set; }
        public string CmpName { get; set; }
        public decimal? AmountUSD { get; set; }
        public string CurId { get; set; }
        public int? Attribute { get; set; }
        public string DepId { get; set; }
        public string DepName { get; set; }
        public string Note { get; set; }
        public int? PaymentTerm { get; set; }
        #endregion

        #region O2C - Unallocated Payments

        public string VoucherNo { get; set; }
        public DateTime? DateSupInv { get; set; }
        public string InvoiceNo { get; set; }
        public string Customer { get; set; }
        public string CustCoy { get; set; }
        public string Currency { get; set; }
        public decimal? OutstandingAmount { get; set; }
        public decimal? FunctionalAmount { get; set; }
        public string ApType { get; set; }
        public int InvoiceStatus { get; set; }
        #endregion
    }
}
