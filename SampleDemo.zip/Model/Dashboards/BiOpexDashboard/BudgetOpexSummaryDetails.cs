﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.BiOpexDashboard
{
    /// <summary>
    /// This is contract that holds details of BI Opex dashboard.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class BudgetOpexSummaryDetails : BaseViewModel
    {
        #region Properties
        /// <summary>
        /// The office identifier
        /// </summary>
        private string _officeId;

        /// <summary>
        /// Gets or sets the office identifier.
        /// </summary>
        /// <value>
        /// The office identifier.
        /// </value>
        public string OfficeId
        {
            get { return _officeId; }
            set { Set(() => OfficeId, ref _officeId, value); }
        }

        /// <summary>
        /// The office name
        /// </summary>
        private string _officeName;

        /// <summary>
        /// Gets or sets the name of the office.
        /// </summary>
        /// <value>
        /// The name of the office.
        /// </value>
        public string OfficeName
        {
            get { return _officeName; }
            set { Set(() => OfficeName, ref _officeName, value); }
        }

        /// <summary>
        /// Gets or sets the fleet identifier.
        /// </summary>
        /// <value>
        /// The fleet identifier.
        /// </value>
        public string FleetId { get; set; }

        /// <summary>
        /// Gets or sets the fleet description.
        /// </summary>
        /// <value>
        /// The fleet description.
        /// </value>
        public string FleetDescription { get; set; }

        /// <summary>
        /// Gets or sets the coy identifier.
        /// </summary>
        /// <value>
        /// The coy identifier.
        /// </value>
        public string CoyId { get; set; }
        /// <summary>
        /// The ves identifier
        /// </summary>
        private string _vesId;

        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId
        {
            get { return _vesId; }
            set { Set(() => VesId, ref _vesId, value); }
        }

        /// <summary>
        /// The vessel name
        /// </summary>
        private string _vesselName;

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName
        {
            get { return _vesselName; }
            set { Set(() => VesselName, ref _vesselName, value); }
        }

        /// <summary>
        /// The client identifier
        /// </summary>
        private string _clientId;

        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public string ClientId
        {
            get { return _clientId; }
            set { Set(() => ClientId, ref _clientId, value); }
        }

        /// <summary>
        /// The client name
        /// </summary>
        private string _clientName;

        /// <summary>
        /// Gets or sets the name of the client.
        /// </summary>
        /// <value>
        /// The name of the client.
        /// </value>
        public string ClientName
        {
            get { return _clientName; }
            set { Set(() => ClientName, ref _clientName, value); }
        }

        /// <summary>
        /// The ves type identifier
        /// </summary>
        private string _vesTypeId;

        /// <summary>
        /// Gets or sets the ves type identifier.
        /// </summary>
        /// <value>
        /// The ves type identifier.
        /// </value>
        public string VesTypeId
        {
            get { return _vesTypeId; }
            set { Set(() => VesTypeId, ref _vesTypeId, value); }
        }

        /// <summary>
        /// The ves type description
        /// </summary>
        private string _vesTypeDescription;

        /// <summary>
        /// Gets or sets the ves type description.
        /// </summary>
        /// <value>
        /// The ves type description.
        /// </value>
        public string VesTypeDescription
        {
            get { return _vesTypeDescription; }
            set { Set(() => VesTypeDescription, ref _vesTypeDescription, value); }
        }

        /// <summary>
        /// The vessel age
        /// </summary>
        private int _vesselAge;

        /// <summary>
        /// Gets or sets the vessel age.
        /// </summary>
        /// <value>
        /// The vessel age.
        /// </value>
        public int VesselAge
        {
            get { return _vesselAge; }
            set { Set(() => VesselAge, ref _vesselAge, value); }
        }

        /// <summary>
        /// The vessel summer DWT
        /// </summary>
        private int _vesselSummerDWT;

        /// <summary>
        /// Gets or sets the vessel summer DWT.
        /// </summary>
        /// <value>
        /// The vessel summer DWT.
        /// </value>
        public int VesselSummerDWT
        {
            get { return _vesselSummerDWT; }
            set { Set(() => VesselSummerDWT, ref _vesselSummerDWT, value); }
        }

        /// <summary>
        /// The ves teu
        /// </summary>
        private string _vesTEU;

        /// <summary>
        /// Gets or sets the ves teu.
        /// </summary>
        /// <value>
        /// The ves teu.
        /// </value>
        public string VesTEU
        {
            get { return _vesTEU; }
            set { Set(() => VesTEU, ref _vesTEU, value); }
        }

        /// <summary>
        /// The vessel size identifier
        /// </summary>
        private string _vesselSizeIdentifier;

        /// <summary>
        /// Gets or sets the vessel size identifier.
        /// </summary>
        /// <value>
        /// The vessel size identifier.
        /// </value>
        public string VesselSizeIdentifier
        {
            get { return _vesselSizeIdentifier; }
            set { Set(() => VesselSizeIdentifier, ref _vesselSizeIdentifier, value); }
        }

        /// <summary>
        /// The vessel size description
        /// </summary>
        private string _vesselSizeDescription;

        /// <summary>
        /// Gets or sets the vessel size description.
        /// </summary>
        /// <value>
        /// The vessel size description.
        /// </value>
        public string VesselSizeDescription
        {
            get { return _vesselSizeDescription; }
            set { Set(() => VesselSizeDescription, ref _vesselSizeDescription, value); }
        }


        /// <summary>
        /// The vessel average compliment
        /// </summary>
        private int _vesselAVGCompliment;

        /// <summary>
        /// Gets or sets the vessel average compliment.
        /// </summary>
        /// <value>
        /// The vessel average compliment.
        /// </value>
        public int VesselAVGCompliment
        {
            get { return _vesselAVGCompliment; }
            set { Set(() => VesselAVGCompliment, ref _vesselAVGCompliment, value); }
        }

        /// <summary>
        /// The vessel officer nationality
        /// </summary>
        private string _vesselOfficerNationality;

        /// <summary>
        /// Gets or sets the vessel officer nationality.
        /// </summary>
        /// <value>
        /// The vessel officer nationality.
        /// </value>
        public string VesselOfficerNationality
        {
            get { return _vesselOfficerNationality; }
            set { Set(() => VesselOfficerNationality, ref _vesselOfficerNationality, value); }
        }

        /// <summary>
        /// The vessel rating nationality
        /// </summary>
        private string _vesselRatingNationality;

        /// <summary>
        /// Gets or sets the vessel rating nationality.
        /// </summary>
        /// <value>
        /// The vessel rating nationality.
        /// </value>
        public string VesselRatingNationality
        {
            get { return _vesselRatingNationality; }
            set { Set(() => VesselRatingNationality, ref _vesselRatingNationality, value); }
        }

        /// <summary>
        /// The ves budget start date
        /// </summary>
        private DateTime? _vesBudgetStartDate;

        /// <summary>
        /// Gets or sets the ves budget start date.
        /// </summary>
        /// <value>
        /// The ves budget start date.
        /// </value>
        public DateTime? VesBudgetStartDate
        {
            get { return _vesBudgetStartDate; }
            set { Set(() => VesBudgetStartDate, ref _vesBudgetStartDate, value); }
        }

        /// <summary>
        /// The vessel days in budget
        /// </summary>
        private int _vesselDaysInBudget;

        /// <summary>
        /// Gets or sets the vessel days in budget.
        /// </summary>
        /// <value>
        /// The vessel days in budget.
        /// </value>
        public int VesselDaysInBudget
        {
            get { return _vesselDaysInBudget; }
            set { Set(() => VesselDaysInBudget, ref _vesselDaysInBudget, value); }
        }

        /// <summary>
        /// The actual operating cost
        /// </summary>
        private decimal? _actualOperatingCost;

        /// <summary>
        /// Gets or sets the actual opearting cost.
        /// </summary>
        /// <value>
        /// The actual opearting cost.
        /// </value>
        public decimal? ActualOpeartingCost
        {
            get { return _actualOperatingCost; }
            set { Set(() => ActualOpeartingCost, ref _actualOperatingCost, value); }
        }

        /// <summary>
        /// The budget operating cost
        /// </summary>
        private decimal? _budgetOperatingCost;

        /// <summary>
        /// Gets or sets the budget operating cost.
        /// </summary>
        /// <value>
        /// The budget operating cost.
        /// </value>
        public decimal? BudgetOperatingCost
        {
            get { return _budgetOperatingCost; }
            set { Set(() => BudgetOperatingCost, ref _budgetOperatingCost, value); }
        }

        /// <summary>
        /// The budget other cost
        /// </summary>
        private decimal? _budgetOtherCost;

        /// <summary>
        /// Gets or sets the budget other cost.
        /// </summary>
        /// <value>
        /// The budget other cost.
        /// </value>
        public decimal? BudgetOtherCost
        {
            get { return _budgetOtherCost; }
            set { Set(() => BudgetOtherCost, ref _budgetOtherCost, value); }
        }

        /// <summary>
        /// The actual other cost
        /// </summary>
        private decimal? _actualOtherCost;

        /// <summary>
        /// Gets or sets the actual other cost.
        /// </summary>
        /// <value>
        /// The actual other cost.
        /// </value>
        public decimal? ActualOtherCost
        {
            get { return _actualOtherCost; }
            set { Set(() => ActualOtherCost, ref _actualOtherCost, value); }
        }

        /// <summary>
        /// The budget sundry cost
        /// </summary>
        private decimal? _budgetSundryCost;

        /// <summary>
        /// Gets or sets the budget sundry cost.
        /// </summary>
        /// <value>
        /// The budget sundry cost.
        /// </value>
        public decimal? BudgetSundryCost
        {
            get { return _budgetSundryCost; }
            set { Set(() => BudgetSundryCost, ref _budgetSundryCost, value); }
        }

        /// <summary>
        /// The actual sundry cost
        /// </summary>
        private decimal? _actualSundryCost;

        /// <summary>
        /// Gets or sets the actual sundry cost.
        /// </summary>
        /// <value>
        /// The actual sundry cost.
        /// </value>
        public decimal? ActualSundryCost
        {
            get { return _actualSundryCost; }
            set { Set(() => ActualSundryCost, ref _actualSundryCost, value); }
        }
        
        /// <summary>
        /// The total actual operating cost
        /// </summary>
        private decimal? _totalActualOperatingCost;

        /// <summary>
        /// Gets or sets the total actual opearting cost.
        /// </summary>
        /// <value>
        /// The total actual opearting cost.
        /// </value>
        public decimal? TotalActualOpeartingCost
        {
            get { return _totalActualOperatingCost; }
            set { Set(() => TotalActualOpeartingCost, ref _totalActualOperatingCost, value); }
        }

        /// <summary>
        /// The total budget operating cost
        /// </summary>
        private decimal? _totalBudgetOperatingCost;

        /// <summary>
        /// Gets or sets the total budget operating cost.
        /// </summary>
        /// <value>
        /// The total budget operating cost.
        /// </value>
        public decimal? TotalBudgetOperatingCost
        {
            get { return _totalBudgetOperatingCost; }
            set { Set(() => TotalBudgetOperatingCost, ref _totalBudgetOperatingCost, value); }
        }

        /// <summary>
        /// The total budget other cost
        /// </summary>
        private decimal? _totalBudgetOtherCost;

        /// <summary>
        /// Gets or sets the total budget other cost.
        /// </summary>
        /// <value>
        /// The total budget other cost.
        /// </value>
        public decimal? TotalBudgetOtherCost
        {
            get { return _totalBudgetOtherCost; }
            set { Set(() => TotalBudgetOtherCost, ref _totalBudgetOtherCost, value); }
        }

        /// <summary>
        /// The total actual other cost
        /// </summary>
        private decimal? _totalActualOtherCost;

        /// <summary>
        /// Gets or sets the total actual other cost.
        /// </summary>
        /// <value>
        /// The total actual other cost.
        /// </value>
        public decimal? TotalActualOtherCost
        {
            get { return _totalActualOtherCost; }
            set { Set(() => TotalActualOtherCost, ref _totalActualOtherCost, value); }
        }

        /// <summary>
        /// The total budget sundry cost
        /// </summary>
        private decimal? _totalBudgetSundryCost;

        /// <summary>
        /// Gets or sets the total budget sundry cost.
        /// </summary>
        /// <value>
        /// The total budget sundry cost.
        /// </value>
        public decimal? TotalBudgetSundryCost
        {
            get { return _totalBudgetSundryCost; }
            set { Set(() => TotalBudgetSundryCost, ref _totalBudgetSundryCost, value); }
        }

        /// <summary>
        /// The total actual sundry cost
        /// </summary>
        private decimal? _totalActualSundryCost;

        /// <summary>
        /// Gets or sets the total actual sundry cost.
        /// </summary>
        /// <value>
        /// The total actual sundry cost.
        /// </value>
        public decimal? TotalActualSundryCost
        {
            get { return _totalActualSundryCost; }
            set { Set(() => TotalActualSundryCost, ref _totalActualSundryCost, value); }
        }

        /// <summary>
        /// The total actual operating cost usd
        /// </summary>
        private decimal? _totalActualOperatingCostUSD;

        /// <summary>
        /// Gets or sets the total actual opearting cost usd.
        /// </summary>
        /// <value>
        /// The total actual opearting cost usd.
        /// </value>
        public decimal? TotalActualOpeartingCostUSD
        {
            get { return _totalActualOperatingCostUSD; }
            set { Set(() => TotalActualOpeartingCostUSD, ref _totalActualOperatingCostUSD, value); }
        }

        /// <summary>
        /// The total budget operating cost usd
        /// </summary>
        private decimal? _totalBudgetOperatingCostUSD;

        /// <summary>
        /// Gets or sets the total budget operating cost usd.
        /// </summary>
        /// <value>
        /// The total budget operating cost usd.
        /// </value>
        public decimal? TotalBudgetOperatingCostUSD
        {
            get { return _totalBudgetOperatingCostUSD; }
            set { Set(() => TotalBudgetOperatingCostUSD, ref _totalBudgetOperatingCostUSD, value); }
        }

        /// <summary>
        /// The total budget other cost usd
        /// </summary>
        private decimal? _totalBudgetOtherCostUSD;

        /// <summary>
        /// Gets or sets the total budget other cost usd.
        /// </summary>
        /// <value>
        /// The total budget other cost usd.
        /// </value>
        public decimal? TotalBudgetOtherCostUSD
        {
            get { return _totalBudgetOtherCostUSD; }
            set { Set(() => TotalBudgetOtherCostUSD, ref _totalBudgetOtherCostUSD, value); }
        }

        /// <summary>
        /// The total actual other cost usd
        /// </summary>
        private decimal? _totalActualOtherCostUSD;

        /// <summary>
        /// Gets or sets the total actual other cost usd.
        /// </summary>
        /// <value>
        /// The total actual other cost usd.
        /// </value>
        public decimal? TotalActualOtherCostUSD
        {
            get { return _totalActualOtherCostUSD; }
            set { Set(() => TotalActualOtherCostUSD, ref _totalActualOtherCostUSD, value); }
        }

        /// <summary>
        /// The total budget sundry cost usd
        /// </summary>
        private decimal? _totalBudgetSundryCostUSD;

        /// <summary>
        /// Gets or sets the total budget sundry cost usd.
        /// </summary>
        /// <value>
        /// The total budget sundry cost usd.
        /// </value>
        public decimal? TotalBudgetSundryCostUSD
        {
            get { return _totalBudgetSundryCostUSD; }
            set { Set(() => TotalBudgetSundryCostUSD, ref _totalBudgetSundryCostUSD, value); }
        }

        /// <summary>
        /// The total actual sundry cost usd
        /// </summary>
        private decimal? _totalActualSundryCostUSD;

        /// <summary>
        /// Gets or sets the total actual sundry cost usd.
        /// </summary>
        /// <value>
        /// The total actual sundry cost usd.
        /// </value>
        public decimal? TotalActualSundryCostUSD
        {
            get { return _totalActualSundryCostUSD; }
            set { Set(() => TotalActualSundryCostUSD, ref _totalActualSundryCostUSD, value); }
        }

        /// <summary>
        /// Gets the total planned budget usd.
        /// </summary>
        /// <value>
        /// The total planned budget usd.
        /// </value>
        public decimal? TotalPlannedBudgetUSD
        {
            get
            {
                return (TotalBudgetOperatingCostUSD ?? 0) + (TotalBudgetOtherCostUSD ?? 0) + (TotalBudgetSundryCostUSD ?? 0);
            }
        }

        /// <summary>
        /// Gets the total actual budget usd.
        /// </summary>
        /// <value>
        /// The total actual budget usd.
        /// </value>
        public decimal? TotalActualBudgetUSD
        {
            get
            {
                return (TotalActualOpeartingCostUSD ?? 0) + (TotalActualOtherCostUSD ?? 0) + (TotalActualSundryCostUSD ?? 0);
            }
        }

        /// <summary>
        /// Gets the variance usd.
        /// </summary>
        /// <value>
        /// The variance usd.
        /// </value>
        public decimal? VarianceUSD
        {
            get
            {
                return ((TotalBudgetOperatingCostUSD ?? 0) + (TotalBudgetOtherCostUSD ?? 0) + (TotalBudgetSundryCostUSD ?? 0))-
                    ((TotalActualOpeartingCostUSD ?? 0) + (TotalActualOtherCostUSD ?? 0) + (TotalActualSundryCostUSD ?? 0));
            }
        }
        #endregion
    }
}
