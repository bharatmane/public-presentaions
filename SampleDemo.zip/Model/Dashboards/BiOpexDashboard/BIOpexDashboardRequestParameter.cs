﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.BiOpexDashboard
{
    /// <summary>
    /// This is input contract for budget dashboard.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class BIOpexDashboardRequestParameter:BaseViewModel
    {
        /// <summary>
        /// Gets or sets the opex year.
        /// </summary>
        /// <value>
        /// The opex year.
        /// </value>
        public int OpexYear { get; set; }
        /// <summary>
        /// Gets or sets the client identifiers.
        /// </summary>
        /// <value>
        /// The client identifiers.
        /// </value>
        public string ClientIdentifiers { get; set; }
        /// <summary>
        /// Gets or sets the office identifiers.
        /// </summary>
        /// <value>
        /// The office identifiers.
        /// </value>
        public string OfficeIdentifiers { get; set; }
        /// <summary>
        /// Gets or sets the accounting company identifiers.
        /// </summary>
        /// <value>
        /// The accounting company identifiers.
        /// </value>
        public string AccountingCompanyIdentifiers { get; set; }
        /// <summary>
        /// Gets or sets the vessel teu minimum value.
        /// </summary>
        /// <value>
        /// The vessel teu minimum value.
        /// </value>
        public int? VesselTEUMinValue { get; set; }
        /// <summary>
        /// Gets or sets the vessel teu maximum value.
        /// </summary>
        /// <value>
        /// The vessel teu maximum value.
        /// </value>
        public int? VesselTEUMaxValue { get; set; }
        /// <summary>
        /// Gets or sets the vessel types.
        /// </summary>
        /// <value>
        /// The vessel types.
        /// </value>
        public string VesselTypes { get; set; }
        /// <summary>
        /// Gets or sets the vessel size identifier.
        /// </summary>
        /// <value>
        /// The vessel size identifier.
        /// </value>
        public string VesselSizeIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the vessel age identifier.
        /// </summary>
        /// <value>
        /// The vessel age identifier.
        /// </value>
        public string VesselAgeIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the fleet identifiers.
        /// </summary>
        /// <value>
        /// The fleet identifiers.
        /// </value>
        public string FleetIdentifiers { get; set; }
    }
}
