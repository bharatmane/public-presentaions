﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.Dashboards.HSEQManager
{
    /// <summary>
    /// Work And Rest Request parameter class.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class WorkAndRestRequestParameter : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the type identifier.
        /// </summary>
        /// <value>
        /// The type identifier.
        /// </value>
        public int TypeId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets the selected date.
        /// </summary>
        /// <value>
        /// The selected date.
        /// </value>
        public DateTime? SelectedDate { get; set; }

        /// <summary>
        /// The is entering MGMT
        /// </summary>
        public bool IsEnteringMgmt { get; set; }
        /// <summary>
        /// The is left MGMT
        /// </summary>
        public bool IsLeftMgmt { get; set; }
        /// <summary>
        /// The is leaving MGMT
        /// </summary>
        public bool IsLeavingMgmt { get; set; }
    }
}
