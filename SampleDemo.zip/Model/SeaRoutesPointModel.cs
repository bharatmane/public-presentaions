﻿using System.Collections.Generic;
using Newtonsoft.Json;

#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class SeaRoutesPointModel
    {
        public SeaRoutesPointModel()
        {
            RoutePoints = new List<RoutePoint>();
        }

        [JsonProperty("journeytime")]
        public double JourneyTime;

        [JsonProperty("eta")]
        public double ETA;

        [JsonProperty("routepoints")]
        public List<RoutePoint> RoutePoints { get; set; }
    }



    public class RoutePoint
    {
        [JsonProperty("lon")]
        public double Longitude { get; set; }

        [JsonProperty("lat")]
        public double Latitude { get; set; }

        [JsonProperty("trackDistance")]
        public double TrackDistance { get; set; }
    }
}
