﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Telerik.Windows.Controls.Map;
// ReSharper disable ArrangeAccessorOwnerBody

#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class RouteForecastAlert
    {
        [JsonProperty("charterSpeed")]
        public string CharterSpeed { get; set; }

        [JsonProperty("dateRecorded")]
        public string DateRecorded { get; set; }

        [JsonProperty("endPortCode")]
        public string EndPortCode { get; set; }

        [JsonProperty("endPortCoordinate")]
        public string EndPortCoordinate { get; set; }

        [JsonProperty("endPortCountry")]
        public string EndPortCountry { get; set; }

        [JsonProperty("endPortName")]
        public string EndPortName { get; set; }

        [JsonProperty("imo")]
        public string Imo { get; set; }

        [JsonProperty("journeyId")]
        public string JourneyId { get; set; }

        [JsonProperty("journeyStartDate")]
        public DateTime JourneyStartDate { get; set; }

        [JsonProperty("startPortCode")]
        public string StartPortCode { get; set; }

        [JsonProperty("startPortCoordinate")]
        public string StartPortCoordinate { get; set; }

        [JsonProperty("startPortCountry")]
        public string StartPortCountry { get; set; }

        [JsonProperty("startPortName")]
        public string StartPortName { get; set; }

        [JsonProperty("vesselName")]
        public string VesselName { get; set; }

        [JsonProperty("warningData")]
        public string WarningData { get; set; }

        [JsonProperty("warningForDate")]
        public DateTime WarningForDate { get; set; }

        [JsonProperty("warningId")]
        public long WarningId { get; set; }

        [JsonProperty("journeyCompletedDate")]
        public DateTime JourneyCompletedDate { get; set; }

        [JsonProperty("VesselDetails")]
        public string VesselDetails { get; set; }

        public JourneyRoutesWeather WeatherWarning { get { return JsonConvert.DeserializeObject<JourneyRoutesWeather>(WarningData); } }

        public List<JourneyRoutesWeather> RemainingTripWeather { get; set; }

        public Location StartPortLocation
        {
            get
            {
                var coordinate = JsonConvert.DeserializeObject<SeaRoutesCoordinates>(StartPortCoordinate);
                return new Location((double)coordinate.Latitude, (double)coordinate.Longitude);
            }
        }

        public Location EndPortLocation
        {
            get
            {
                var coordinate = JsonConvert.DeserializeObject<SeaRoutesCoordinates>(EndPortCoordinate);
                return new Location((double)coordinate.Latitude, (double)coordinate.Longitude);
            }
        }

        public Location CurrentLocation
        {
            get
            {
                if (RemainingTripWeather == null || !RemainingTripWeather.Any())
                {
                    return new Location();
                }
                var currentLocation = RemainingTripWeather.First();
                return new Location(currentLocation.Latitude, currentLocation.Longitude);
            }
        }

        public VesselRoutesVesselDetails VesselDetailsObj
        {
            get { return JsonConvert.DeserializeObject<VesselRoutesVesselDetails>(VesselDetails); }
        }
    }


    public class JourneyRoutesWeather
    {
        public string VesselImo { get; set; }
        public string VesselName { get; set; }
        public int EcdisWaypointId { get; set; }
        public DateTime WeatherDate { get; set; }
        public int SpeedBeaufort { get; set; }
        public int Direction { get; set; }
        public long TrackDistance { get; set; }
        public int Distance
        {
            get
            {
                return (int)(TrackDistance / 1852);
            }
        }
        public long Duration { get; set; }

        private decimal _speedMS;
        public decimal SpeedMS
        {
            get { return Math.Round(_speedMS, 2); }
            set { _speedMS = value; }
        }

        private double _latitude;
        public double Latitude
        {
            get { return Math.Round(_latitude, 2); }
            set { _latitude = value; }
        }

        private double _longitude;
        public double Longitude
        {
            get { return Math.Round(_longitude, 2); }
            set { _longitude = value; }
        }

        public string LocationStr
        {
            get { return string.Format("{0}° {1}, {2}° {3}", Math.Abs(Latitude), Latitude >= 0 ? "N":"S", Math.Abs(Longitude), Longitude >= 0 ? "E" : "W"); }
        }

        public string BeaufortColour
        {
            get
            {
                switch (SpeedBeaufort)
                {
                    case 0:
                        return "#FF73CBFD";
                    case 1:
                        return "#FFAEF1F9";
                    case 2:
                        return "#FF96F7DC";
                    case 3:
                        return "#FF96F7B4";
                    case 4:
                        return "#FF6FF46F";
                    case 5:
                        return "#FF73ED12";
                    case 6:
                        return "#FFA4ED12";
                    case 7:
                        return "#FFDAED12";
                    case 8:
                        return "#FFEDC212";
                    case 9:
                        return "#FFED8F12";
                    case 10:
                        return "#FFED6312";
                    case 11:
                        return "#FFED2912";
                    case 12:
                        return "#FFD5102D";
                    default:
                        return "#FFFFFFFF";
                }
            }
        }
    }


    public class JourneyRoutesWeatherWpf
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public DateTime WeatherDate { get;set; }
        public int Direction { get; set; }
        public decimal SpeedMS { get; set; }
        public int SpeedBeaufort { get; set; }
        public string ToolTip { get; set; }
        public bool IsBarbs { get; set; }
        public object Tag { get; set; }
        public string Imo { get; set; }

        public Location Location
        {
            get { return new Location(Latitude, Longitude); }
        }

        public RotateTransform RotateTransform
        {
            get { return new RotateTransform(Direction - 180, Image.Width / 2, Image.Height / 2); }
        }

        public ImageSource Image
        {
            get
            {
                return IsBarbs
                    ? new BitmapImage(new Uri(@"pack://application:,,,/VShips.Framework.Resource;component/Images/Weather/Barb" + Math.Round((double)SpeedMS * 1.944 / 5.0) * 5 + ".png"))
                    : new BitmapImage(new Uri(@"pack://application:,,,/VShips.Framework.Resource;component/Images/Weather/WindArrow" + SpeedBeaufort + ".png"));
            }
        }
    }


    public class RolledUpForecastAlert
    {
        public string VesselName { get; set; }
        public string Imo { get; set; }
        public int DistanceTravelled { get; set; }
        public string StartPortName { get; set; }
        public string StartPortCountry { get; set; }
        public DateTime JourneyStartDate { get; set; }
        public string StartCoordinate { get; set; }
        public string EndPortName { get; set; }
        public string EndPortCountry { get; set; }
        public DateTime JourneyCompletedDate { get; set; }
        public string EndCoordinate { get; set; }
        public string WindWarning { get; set; }
        public List<JourneyRoutesWeather> RouteForecastAlerts { get; set; }
        public string VesselDetails { get; set; }

        public VesselRoutesVesselDetails VesselDetailsObj
        {
            get { return JsonConvert.DeserializeObject<VesselRoutesVesselDetails>(VesselDetails); }
        }

        public string FormattedVesselName
        {
            get { return string.Format("{0} - ({1})", VesselName, Imo); }
        }

        public SeaRoutesCoordinates StartCoordinateObj
        {
            get { return JsonConvert.DeserializeObject<SeaRoutesCoordinates>(StartCoordinate); }
        }

        public SeaRoutesCoordinates EndCoordinateObj
        {
            get { return JsonConvert.DeserializeObject<SeaRoutesCoordinates>(EndCoordinate); }
        }
    }
}
