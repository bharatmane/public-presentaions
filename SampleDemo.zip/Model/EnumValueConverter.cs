﻿using System;
using System.Linq;
using VShips.DataServices.Shared.DataAttributes;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// A helper class that extracts the <see cref="EnumValueDataAttribute"/> 
    /// metadata from an enum value.
    /// </summary>
    public  static class EnumValueConverter
    {
        /// <summary>
        /// Returns the <see cref="EnumValueDataAttribute"/> from an enum value.
        /// </summary>
        /// <param name="value">The enum value.</param>
        /// <returns>The enum <see cref="EnumValueDataAttribute"/> metadata.</returns>
        public static EnumValueDataAttribute GetEnumMetadata(object value)
        {
            var type = value.GetType();
            if (!type.IsEnum)
            {
                throw new InvalidOperationException("Value must be an enum.");
            }

            return type.GetField(value.ToString()).GetCustomAttributes(typeof(EnumValueDataAttribute), false).Cast<EnumValueDataAttribute>().FirstOrDefault();
        }

        /// <summary>
        /// Gets the enum short code.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        /// <exception cref="System.InvalidOperationException">Value must be an enum.</exception>
        public static ShortCodeAttribute GetEnumShortCode(object value)
        {
            var type = value.GetType();
            if (!type.IsEnum)
            {
                throw new InvalidOperationException("Value must be an enum.");
            }

            return type.GetField(value.ToString()).GetCustomAttributes(typeof(ShortCodeAttribute), false).Cast<ShortCodeAttribute>().FirstOrDefault();
        }
    }
}
