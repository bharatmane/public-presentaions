﻿using System.Collections.Generic;
using VShips.Contracts.DtoClasses;
#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class EformTemplateHierarchy
    {
        public EformTemplate Entity { get; set; }
        public string Node { get; set; }
        public string EformTemplateId { get; set; }
        public string EformDescription { get; set; }
        public string EformName { get; set; }
        public string TemplateTitle { get; set; }
        public string TemplateKeyField { get; set; }
        public string TemplateInterval { get; set; }

        public List<EformTemplateHierarchy> Children { get; set; }
    }
}