﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.Reports
{ 
    /// <summary>
    /// A class used to handle procedure parameters.
    /// </summary>
    public class ProcedureParameter
    {
        /// <summary>
        /// The name
        /// </summary>
        public string Name;

        /// <summary>
        /// The data type
        /// </summary>
        public Type ParameterType;

        /// <summary>
        /// The value
        /// </summary>
        public List<object> Value;
    }
}
