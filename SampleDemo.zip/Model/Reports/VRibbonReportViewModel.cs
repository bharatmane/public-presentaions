﻿using GalaSoft.MvvmLight.Command;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Linq;
using VShips.Contracts.DtoClasses.ReportGroupLightTypes;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.Services.Default;
using VShips.Framework.Common.ViewModel.Menu;

namespace VShips.Framework.Common.Model.Reports
{
    /// <summary>
    /// This is view model class for VRibbon Report menu items.
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.Menu.MenuItem" />
    public class VRibbonReportViewModel : MenuItem
    {
        #region Private Properties

        /// <summary>
        /// The logger
        /// </summary>
        private ILoggerService _logger;

        /// <summary>
        /// The navigation service
        /// </summary>
        private INavigationService _navigationService;

        /// <summary>
        /// The current context
        /// </summary>
        private NavigationContext _currentContext;

        #endregion

        #region Properties

        /// <summary>
        /// The entity
        /// </summary>
        private Report _entity;

        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        public Report Entity
        {
            get { return _entity; }
            set { Set(() => Entity, ref _entity, value); }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="VRibbonReportViewModel"/> class.
        /// </summary>
        public VRibbonReportViewModel()
        {
            Command = new RelayCommand(NavigateToView);
            _logger = ServiceLocator.Current.GetInstance<ILoggerService>();
            _navigationService = ServiceLocator.Current.GetInstance<INavigationService>();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Navigates to view.
        /// </summary>
        public void NavigateToView()
        {
            var dialogService = ServiceLocator.Current.GetInstance<IDialogService>();
            if (_navigationService != null)
            {
                _currentContext = _navigationService.OpenContexts.OfType<NavigationContext>().FirstOrDefault(x => x.IsActive);
                if (_currentContext != null)
                {
                    if (!string.IsNullOrEmpty(Entity.NavigationModuleName) && !string.IsNullOrEmpty(Entity.NavigationViewName))
                    {
                        if (Entity.NavigationParameterJSon != null)
                        {
                            _navigationService.NavigateDialog(Entity.NavigationModuleName, Entity.NavigationViewName, _currentContext, Entity.NavigationParameterJSon);
                        }
                        else
                        {
                            _navigationService.NavigateDialog(Entity.NavigationModuleName, Entity.NavigationViewName, _currentContext);
                        }
                    }
                    else
                    {
                        NavigateToDynamicReport();
                    }
                }
                else
                {
                    _logger.ErrorWithoutAlert("Current context is null");
                }
            }
            else
            {
                _logger.ErrorWithoutAlert("Navigation Service is null");
            }
        }

        /// <summary>
        /// Navigates to dynamic report.
        /// </summary>
        private async void NavigateToDynamicReport()
        {            
            if (!string.IsNullOrWhiteSpace(Entity.ReportTypeId) && Entity.ReportTypeId.Equals(Constant.UIBound, StringComparison.CurrentCultureIgnoreCase))
            {
                var token = new System.Threading.CancellationToken();
                Contracts.DtoClasses.ReportLight parameter = await VMService.DataService.Shared.GetReportLightById(Entity.RptId, token);
                if (parameter != null)
                {
                    if (parameter.ReportParameters != null && parameter.ReportParameters.Any())
                    {
                        VMService.ModuleNavigationService.Common.NavigateToDynamicReportParametersView(NavigationContext, parameter);
                    }
                    else
                    {
                        VMService.ModuleNavigationService.Common.NavigateToDynamicReportListingView(NavigationContext, parameter);
                    }
                }
            }
            else
            {
                VMService.ModuleNavigationService.Reports.NavigateReport(Entity.RptId, _currentContext);
            }
        }
        #endregion

        #region CleanUp

        /// <summary>
        /// Used to cleanup the viewmodel.
        /// </summary>
        public override void Cleanup()
        {
            _logger = null;
            _currentContext = null;
            _navigationService = null;
            if (Entity != null)
            {
                Entity = null;
            }
        }
        #endregion
    }
}

