﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.Reports
{
    /// <summary>
    /// A class used for dynamic report parameter.
    /// </summary>
    public class DynamicReportParameter
    {
        /// <summary>
        /// The procedure name
        /// </summary>
        public string ProcedureName;

        /// <summary>
        /// The parameter list
        /// </summary>
        public List<ProcedureParameter> ParameterList;

        /// <summary>
        /// Clones this instance.
        /// </summary>
        /// <returns>
        /// Copy of current instance
        /// </returns>
        public DynamicReportParameter Clone()
        {
            return (DynamicReportParameter)this.MemberwiseClone();
        }
    }
}
