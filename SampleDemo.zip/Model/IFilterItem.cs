﻿using System;
using GalaSoft.MvvmLight;
using VShips.Framework.Common.Events;
using VShips.Framework.Common.Model.Icons;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An interface representing a class that allows filtering.
    /// </summary>
    public interface IFilterItem : ICleanup
    {
        /// <summary>
        /// Raised when the filter is selected.
        /// </summary>
        event EventHandler<EventArgs<IFilterItem>> ValueChanged;

        /// <summary>
        /// Gets the displayed name of the filter.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// The type of filter.
        /// </summary>
        FilterTypes FilterType { get; }

        /// <summary>
        /// Gets the icon for the filter.
        /// </summary>
        BaseIconViewModel Icon { get; }

        /// <summary>
        /// Gets the description of the filter.
        /// </summary>
        string Description { get; }
        
    }

    /// <summary>
    /// Defines the type of filter.
    /// </summary>
    public enum FilterTypes
    {
        /// <summary>
        /// A group of checkable filters
        /// </summary>
        CheckableGroup,

        /// <summary>
        /// A checkable filter.
        /// </summary>
        Checkable,

        /// <summary>
        /// A tree structured filter.
        /// </summary>
        Tree,

        /// <summary>
        /// An item in a tree.
        /// </summary>
        TreeItem,

        /// <summary>
        /// Used to seperate items.
        /// </summary>
        Seperator
    }
}
