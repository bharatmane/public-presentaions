﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class CompanyDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class CompanyDetails : BaseViewModel
    {
        /// <summary>
        /// The company identifier
        /// </summary>
        private string _companyId;
        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId
        {
            get { return _companyId; }
            set { Set(() => CompanyId, ref _companyId, value); }
        }

        /// <summary>
        /// The company name
        /// </summary>
        private string _companyName;
        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>
        /// The name of the company.
        /// </value>
        public string CompanyName
        {
            get { return _companyName; }
            set { Set(() => CompanyName, ref _companyName, value); }
        }

        /// <summary>
        /// The formal title
        /// </summary>
        private string _formalTitle;
        /// <summary>
        /// Gets or sets the formal title.
        /// </summary>
        /// <value>
        /// The formal title.
        /// </value>
        public string FormalTitle
        {
            get { return _formalTitle; }
            set { Set(() => FormalTitle, ref _formalTitle, value); }
        }
        /// <summary>
        /// The address
        /// </summary>
        private string _address;
        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address
        {
            get { return _address; }
            set { Set(() => Address, ref _address, value); }
        }

        /// <summary>
        /// The town
        /// </summary>
        private string _town;
        /// <summary>
        /// Gets or sets the town.
        /// </summary>
        /// <value>
        /// The town.
        /// </value>
        public string Town
        {
            get { return _town; }
            set { Set(() => Town, ref _town, value); }
        }
        /// <summary>
        /// The state
        /// </summary>
        private string _state;
        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>
        /// The state.
        /// </value>
        public string State
        {
            get { return _state; }
            set { Set(() => State, ref _state, value); }
        }
        /// <summary>
        /// The zip code
        /// </summary>
        private string _zipCode;
        /// <summary>
        /// Gets or sets the zip code.
        /// </summary>
        /// <value>
        /// The zip code.
        /// </value>
        public string ZipCode
        {
            get { return _zipCode; }
            set { Set(() => ZipCode, ref _zipCode, value); }
        }

        /// <summary>
        /// The country
        /// </summary>
        private string _country;
        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country
        {
            get { return _country; }
            set { Set(() => Country, ref _country, value); }
        }
    }
}
