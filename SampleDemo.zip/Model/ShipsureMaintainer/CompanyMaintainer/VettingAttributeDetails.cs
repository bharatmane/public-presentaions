﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// VettingAttributeDetails
    /// </summary>
    public class VettingAttributeDetails
    {
        /// <summary>
        /// Gets or sets the attribute identifier.
        /// </summary>
        /// <value>
        /// The attribute identifier.
        /// </value>
        public string AttributeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the attribute.
        /// </summary>
        /// <value>
        /// The name of the attribute.
        /// </value>
        public string AttributeName { get; set; }

        /// <summary>
        /// Gets or sets the attribute short code.
        /// </summary>
        /// <value>
        /// The attribute short code.
        /// </value>
        public string AttributeShortCode { get; set; }

        /// <summary>
        /// Gets or sets the attribute colorcode.
        /// </summary>
        /// <value>
        /// The attribute colorcode.
        /// </value>
        public string AttributeColorcode { get; set; }

        /// <summary>
        /// Gets or sets the attribute sort order.
        /// </summary>
        /// <value>
        /// The attribute sort order.
        /// </value>
        public decimal? AttributeSortOrder { get; set; }
    }
}
