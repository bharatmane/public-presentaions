﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class CompanyRequestCounts
    /// </summary>
    public class CompanyRequestCounts: BaseViewModel
    {
        /// <summary>
        /// The total request count
        /// </summary>
        private int _totalRequestCount;

        /// <summary>
        /// Gets or sets the total request count.
        /// </summary>
        /// <value>
        /// The total request count.
        /// </value>
        public int TotalRequestCount
        {
            get { return _totalRequestCount; }
            set { Set(() => TotalRequestCount, ref _totalRequestCount, value); }
        }

        /// <summary>
        /// The last5 days request count
        /// </summary>
        private int _last5DaysRequestCount;
        /// <summary>
        /// Gets or sets the last5 days request count.
        /// </summary>
        /// <value>
        /// The last5 days request count.
        /// </value>
        public int Last5DaysRequestCount 
        {
            get { return _last5DaysRequestCount; }
            set { Set(() => Last5DaysRequestCount, ref _last5DaysRequestCount, value); }
        }

        /// <summary>
        /// The before5 days request count
        /// </summary>
        private int _before5DaysRequestCount;

        /// <summary>
        /// Gets or sets the before5 days request count.
        /// </summary>
        /// <value>
        /// The before5 days request count.
        /// </value>
        public int Before5DaysRequestCount 
        { 
            get { return _before5DaysRequestCount; }
            set { Set(() => Before5DaysRequestCount, ref _before5DaysRequestCount, value); }
        }

        /// <summary>
        /// The total in progress request count
        /// </summary>
        private int _totalInProgressRequestCount;

        /// <summary>
        /// Gets or sets the total in progress request count.
        /// </summary>
        /// <value>
        /// The total in progress request count.
        /// </value>
        public int TotalInProgressRequestCount 
        { 
            get { return _totalInProgressRequestCount; }
            set { Set(()=>TotalInProgressRequestCount, ref _totalInProgressRequestCount, value); } 
        }

        /// <summary>
        /// The last5 days in progress request count
        /// </summary>
        private int _last5DaysInProgressRequestCount;
        /// <summary>
        /// Gets or sets the last5 days in progress request count.
        /// </summary>
        /// <value>
        /// The last5 days in progress request count.
        /// </value>
        public int Last5DaysInProgressRequestCount 
        {
            get { return _last5DaysInProgressRequestCount; } 
            set { Set(() => Last5DaysInProgressRequestCount, ref _last5DaysInProgressRequestCount, value); } 
        }

        /// <summary>
        /// The before5 days in progress request count
        /// </summary>
        private int _before5DaysInProgressRequestCount;
        /// <summary>
        /// Gets or sets the before5 days in progress request count.
        /// </summary>
        /// <value>
        /// The before5 days in progress request count.
        /// </value>
        public int Before5DaysInProgressRequestCount 
        { 
            get { return _before5DaysInProgressRequestCount; }
            set { Set(() => Before5DaysInProgressRequestCount, ref _before5DaysInProgressRequestCount, value); }
        }

        /// <summary>
        /// The total failed request count
        /// </summary>
        private int _totalFailedRequestCount;
        /// <summary>
        /// Gets or sets the total failed request count.
        /// </summary>
        /// <value>
        /// The total failed request count.
        /// </value>
        public int TotalFailedRequestCount 
        { 
            get { return _totalFailedRequestCount; }
            set { Set(() => TotalFailedRequestCount, ref _totalFailedRequestCount, value); } 
        }

        /// <summary>
        /// The total pending sign off request count
        /// </summary>
        private int _totalPendingSignOffRequestCount;
        /// <summary>
        /// Gets or sets the total pending sign off request count.
        /// </summary>
        /// <value>
        /// The total pending sign off request count.
        /// </value>
        public int TotalPendingSignOffRequestCount 
        { 
            get { return _totalPendingSignOffRequestCount; } 
            set { Set(() => TotalPendingSignOffRequestCount, ref _totalPendingSignOffRequestCount, value); } 
        }
    }

    /// <summary>
    /// Company Renewal Request Counts
    /// </summary>
    public class CompanyRenewalRequestCounts: BaseViewModel
    {
		/// <summary>
		/// The overdue renewal count
		/// </summary>
		private int _overdueRenewalCount;
		/// <summary>
		/// Gets or sets the overdue renewal count.
		/// </summary>
		/// <value>
		/// The overdue renewal count.
		/// </value>
		public int OverdueRenewalCount
        {
            get { return _overdueRenewalCount; }
            set { Set(() => OverdueRenewalCount, ref _overdueRenewalCount, value); }
        }

        /// <summary>
        /// The last30 days renewal request count
        /// </summary>
        private int _last30DaysRenewalRequestCount;
        /// <summary>
        /// Gets or sets the last30 days renewal request count.
        /// </summary>
        /// <value>
        /// The last30 days renewal request count.
        /// </value>
        public int Last30DaysRenewalRequestCount 
        {
            get { return _last30DaysRenewalRequestCount; }
            set { Set(() => Last30DaysRenewalRequestCount, ref _last30DaysRenewalRequestCount, value); } 
        }

        /// <summary>
        /// The last60 days renewal request count
        /// </summary>
        private int _last60DaysRenewalRequestCount;

        /// <summary>
        /// Gets or sets the last60 days renewal request count.
        /// </summary>
        /// <value>
        /// The last60 days renewal request count.
        /// </value>
        public int Last60DaysRenewalRequestCount 
        { 
            get { return _last60DaysRenewalRequestCount; }
            set { Set(() => Last60DaysRenewalRequestCount, ref _last60DaysRenewalRequestCount, value); } 
        }

        /// <summary>
        /// The last90 days renewal request count
        /// </summary>
        private int _last90DaysRenewalRequestCount;

        /// <summary>
        /// Gets or sets the last90 days renewal request count.
        /// </summary>
        /// <value>
        /// The last90 days renewal request count.
        /// </value>
        public int Last90DaysRenewalRequestCount
        {
            get { return _last90DaysRenewalRequestCount; }
            set { Set(() => Last90DaysRenewalRequestCount, ref _last90DaysRenewalRequestCount, value); }
        }
    }
}
