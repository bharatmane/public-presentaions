﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class ValidatorDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class ValidatorDetails : BaseViewModel
    {
        /// <summary>
        /// The validated by
        /// </summary>
        private string _validatedBy;
        /// <summary>
        /// Gets or sets the validated by.
        /// </summary>
        /// <value>
        /// The validated by.
        /// </value>
        public string ValidatedBy
        {
            get { return _validatedBy; }
            set { Set(() => ValidatedBy, ref _validatedBy, value); }
        }

        /// <summary>
        /// The validated date
        /// </summary>
        private DateTime? _validatedDate;
        /// <summary>
        /// Gets or sets the validated date.
        /// </summary>
        /// <value>
        /// The validated date.
        /// </value>
        public DateTime? ValidatedDate
        {
            get { return _validatedDate; }
            set { Set(() => ValidatedDate, ref _validatedDate, value); }
        }

        /// <summary>
        /// The template
        /// </summary>
        private string _template;
        /// <summary>
        /// Gets or sets the template.
        /// </summary>
        /// <value>
        /// The template.
        /// </value>
        public string Template
        {
            get { return _template; }
            set { Set(() => Template, ref _template, value); }
        }
    }
}
