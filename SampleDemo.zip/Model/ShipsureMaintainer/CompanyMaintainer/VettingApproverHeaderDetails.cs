﻿using System;
using System.Collections.Generic;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class VettingApproverHeaderDetails
	/// </summary>
	public class VettingApproverHeaderDetails:BaseViewModel
	{
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }

        /// <summary>
        /// The company name
        /// </summary>
        private string _companyName;

        /// <summary>Gets or sets the name of the company.</summary>
        /// <value>The name of the company.</value>
        public string CompanyName 
        {
            get { return _companyName; }
            set { Set(() => CompanyName, ref _companyName, value); } 
        }
        /// <summary>Gets or sets the vc identifier.</summary>
        /// <value>The vc identifier.</value>
        public string VcId { get; set; }

        /// <summary>
        /// The category description
        /// </summary>
        private string _categoryDescription;
        /// <summary>
        /// Gets or sets the category description.
        /// </summary>
        /// <value>
        /// The category description.
        /// </value>
        public string CategoryDescription
        {
            get { return _categoryDescription; }
            set { Set(() => CategoryDescription, ref _categoryDescription, value); }
        }
        /// <summary>
        /// Gets or sets the vetting status description.
        /// </summary>
        /// <value>
        /// The vetting status description.
        /// </value>
        public string VettingStatusDescription { get; set; }

        /// <summary>
        /// The vetting requested date
        /// </summary>
        private DateTime? _vettingRequestedDate;
        /// <summary>
        /// Gets or sets the vetting requested date.
        /// </summary>
        /// <value>
        /// The vetting requested date.
        /// </value>
        public DateTime? VettingRequestedDate 
        {
            get { return _vettingRequestedDate; }
            set { Set(() => VettingRequestedDate, ref _vettingRequestedDate, value); } 
        }

        /// <summary>
        /// The vetting requested by
        /// </summary>
        private string _vettingRequestedBy;
        /// <summary>
        /// Gets or sets the vetting requested by.
        /// </summary>
        /// <value>
        /// The vetting requested by.
        /// </value>
        public string VettingRequestedBy 
        {
            get { return _vettingRequestedBy; }
            set { Set(() => VettingRequestedBy, ref _vettingRequestedBy, value); }
        }

        /// <summary>
        /// The vetting request validate date
        /// </summary>
        private DateTime? _vettingRequestValidateDate;
        /// <summary>
        /// Gets or sets the vetting request validate date.
        /// </summary>
        /// <value>
        /// The vetting request validate date.
        /// </value>
        public DateTime? VettingRequestValidateDate 
        {
            get { return _vettingRequestValidateDate; }
            set { Set(() => VettingRequestValidateDate, ref _vettingRequestValidateDate, value); }
        }

        /// <summary>
        /// The vetting request validate by
        /// </summary>
        private string _vettingRequestValidateBy;
        /// <summary>
        /// Gets or sets the vetting request validate by.
        /// </summary>
        /// <value>
        /// The vetting request validate by.
        /// </value>
        public string VettingRequestValidateBy 
        {
            get { return _vettingRequestValidateBy; }
            set { Set(() => VettingRequestValidateBy, ref _vettingRequestValidateBy, value); }
        }
        /// <summary>
        /// Gets or sets the vetting sign off date.
        /// </summary>
        /// <value>
        /// The vetting sign off date.
        /// </value>
        public DateTime? VettingSignOffDate { get; set; }

        /// <summary>
        /// The vetting sign off user
        /// </summary>
        private string _vettingSignOffUser;
        /// <summary>
        /// Gets or sets the vetting sign off user.
        /// </summary>
        /// <value>
        /// The vetting sign off user.
        /// </value>
        public string VettingSignOffUser 
        {
            get { return _vettingSignOffUser; }
            set { Set(() => VettingSignOffUser, ref _vettingSignOffUser, value); }
        }
        /// <summary>
        /// Gets or sets the vetting sign off user role.
        /// </summary>
        /// <value>
        /// The vetting sign off user role.
        /// </value>
        public string VettingSignOffUserRole { get; set; }


        /// <summary>
        /// The vetting request type
        /// </summary>
        private string _vettingRequestType;

        /// <summary>
        /// Gets or sets the type of the vetting request.
        /// </summary>
        /// <value>
        /// The type of the vetting request.
        /// </value>
        public string VettingRequestType
        {
            get { return _vettingRequestType; }
            set { Set(() => VettingRequestType, ref _vettingRequestType, value); }
        }

        /// <summary>
        /// The template name
        /// </summary>
        private string _templateName;
        /// <summary>
        /// Gets or sets the name of the template.
        /// </summary>
        /// <value>
        /// The name of the template.
        /// </value>
        public string TemplateName 
        {
            get { return _templateName; }
            set { Set(() => TemplateName, ref _templateName, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time supplier.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time supplier; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeSupplier { get; set; }

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }

		/// <summary>
		/// Gets or sets the category list.
		/// </summary>
		/// <value>
		/// The category list.
		/// </value>
		public List<Lookup> CategoryList { get; set; }

        /// <summary>
        /// Gets or sets the sign off roles assigned to category.
        /// </summary>
        /// <value>
        /// The sign off roles assigned to category.
        /// </value>
        public List<string> SignOffRolesAssignedToCategory { get; set; }

		/// <summary>
		/// Gets or sets the effective renewal date.
		/// </summary>
		/// <value>
		/// The effective renewal date.
		/// </value>
		public DateTime? EffectiveRenewalDate { get; set; }

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="VettingApproverHeaderDetails"/> class.
        /// </summary>
        public VettingApproverHeaderDetails()
        {
            CategoryList = new List<Lookup>();
        }

		#endregion
	}
}
