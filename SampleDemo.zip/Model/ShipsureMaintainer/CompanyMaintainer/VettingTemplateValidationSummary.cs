﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class VettingTemplateValidationSummary
	/// </summary>
	public class VettingTemplateValidationSummary
	{
        /// <summary>
        /// Gets or sets the seq no.
        /// </summary>
        /// <value>
        /// The seq no.
        /// </value>
        public long? SeqNo { get; set; }
        /// <summary>
        /// Gets or sets the vt identifier.
        /// </summary>
        /// <value>
        /// The vt identifier.
        /// </value>
        public string VT_ID { get; set; }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; }
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public string Version { get; set; }
        /// <summary>
        /// Gets or sets the status identifier.
        /// </summary>
        /// <value>
        /// The status identifier.
        /// </value>
        public string StatusID { get; set; }
        /// <summary>
        /// Gets or sets the name of the status.
        /// </summary>
        /// <value>
        /// The name of the status.
        /// </value>
        public string StatusName { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the category names.
        /// </summary>
        /// <value>
        /// The category names.
        /// </value>
        public string CategoryNames { get; set; }
        /// <summary>
        /// Gets or sets the category i ds.
        /// </summary>
        /// <value>
        /// The category i ds.
        /// </value>
        public string CategoryIDs { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is default for category.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is default for category; otherwise, <c>false</c>.
        /// </value>
        public bool IsDefaultForCategory { get; set; }

        /// <summary>
        /// Gets or sets the mapped vetting titles.
        /// </summary>
        /// <value>
        /// The mapped vetting titles.
        /// </value>
        public List<string> MappedVettingTitles { get; set; }
    }
}
