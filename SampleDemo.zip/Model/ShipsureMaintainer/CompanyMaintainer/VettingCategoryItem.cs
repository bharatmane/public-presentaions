﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class VettingCategoryItem
	/// </summary>
	public class VettingCategoryItem
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="VettingCategoryItem"/> class.
		/// </summary>
		public VettingCategoryItem()
		{
			TemplateList = new List<string>();
			Services = new List<string>();
			FinalSignOffBy = new List<string>();
		}

		#endregion

		#region Properties

		/// <summary>
		/// Gets or sets the category identifier.
		/// </summary>
		/// <value>
		/// The category identifier.
		/// </value>
		public string CategoryId { get; set; }

		/// <summary>
		/// Gets or sets the name of the category.
		/// </summary>
		/// <value>
		/// The name of the category.
		/// </value>
		public string CategoryName { get; set; }

		/// <summary>
		/// Gets or sets the template list.
		/// </summary>
		/// <value>
		/// The template list.
		/// </value>
		public List<string> TemplateList { get; set; }

		/// <summary>
		/// Gets or sets the services.
		/// </summary>
		/// <value>
		/// The services.
		/// </value>
		public List<string> Services { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is status active.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is status active; otherwise, <c>false</c>.
		/// </value>
		public bool IsStatusActive { get; set; }

		/// <summary>
		/// Gets or sets the category created by user identifier.
		/// </summary>
		/// <value>
		/// The category created by user identifier.
		/// </value>
		public string CategoryCreatedByUserId { get; set; }
		/// <summary>
		/// Gets or sets the name of the category created by user.
		/// </summary>
		/// <value>
		/// The name of the category created by user.
		/// </value>
		public string CategoryCreatedByUserName { get; set; }
		/// <summary>
		/// Gets or sets the category created date.
		/// </summary>
		/// <value>
		/// The category created date.
		/// </value>
		public DateTime? CategoryCreatedDate { get; set; }
		/// <summary>
		/// Gets or sets the final sign off by.
		/// </summary>
		/// <value>
		/// The final sign off by.
		/// </value>
		public List<string> FinalSignOffBy { get; set; }

		/// <summary>
		/// Gets or sets the serial number.
		/// </summary>
		/// <value>
		/// The serial number.
		/// </value>
		public int SerialNumber { get; set; }

		/// <summary>
		/// Gets the templates.
		/// </summary>
		/// <value>
		/// The templates.
		/// </value>
		public string Templates
		{
			get { return (TemplateList != null && TemplateList.Any()) ? string.Join(", ", TemplateList) : string.Empty;  }
		}

		/// <summary>
		/// Gets the service.
		/// </summary>
		/// <value>
		/// The service.
		/// </value>
		public string Service
		{
			get { return (Services != null && Services.Any()) ? string.Join(", ", Services) : string.Empty; }
		}

		/// <summary>
		/// Gets the final sign offers.
		/// </summary>
		/// <value>
		/// The final sign offers.
		/// </value>
		public string FinalSignOffers
		{
			get { return (FinalSignOffBy != null && FinalSignOffBy.Any()) ? string.Join(", ", FinalSignOffBy) : string.Empty; }
		}
		#endregion
	}
}
