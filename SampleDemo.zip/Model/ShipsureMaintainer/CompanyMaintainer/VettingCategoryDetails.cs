﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingCategoryDetails
    /// </summary>
    public class VettingCategoryDetails
	{
        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId { get; set; }

        /// <summary>
        /// Gets or sets the name of the category.
        /// </summary>
        /// <value>
        /// The name of the category.
        /// </value>
        public string CategoryName { get; set; }

        /// <summary>
        /// Gets or sets the template ids.
        /// </summary>
        /// <value>
        /// The template ids.
        /// </value>
        public List<string> Templates { get; set; }

        /// <summary>
        /// Gets or sets the sign off role ids.
        /// </summary>
        /// <value>
        /// The sign off role ids.
        /// </value>
        public List<string> SignOffRoles { get; set; }

        /// <summary>
        /// Gets or sets the mapped services.
        /// </summary>
        /// <value>
        /// The mapped services.
        /// </value>
        public List<string> MappedServices { get; set; }
    }
}
