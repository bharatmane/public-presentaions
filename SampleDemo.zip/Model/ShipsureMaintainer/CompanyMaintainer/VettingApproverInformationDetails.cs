﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// Class VettingApproverInformationDetails
    /// </summary>
    public class VettingApproverInformationDetails
	{
        /// <summary>
        /// Gets or sets the author.
        /// </summary>
        /// <value>
        /// The author.
        /// </value>
        public string Author { get; set; }
        /// <summary>
        /// Gets or sets the type of the vetting.
        /// </summary>
        /// <value>
        /// The type of the vetting.
        /// </value>
        public string VettingType { get; set; }
        /// <summary>
        /// Gets or sets the type of the evidence.
        /// </summary>
        /// <value>
        /// The type of the evidence.
        /// </value>
        public string EvidenceType { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is document required.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is document required; otherwise, <c>false</c>.
		/// </value>
		public bool? IsDocumentRequired { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is self supplied.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is self supplied; otherwise, <c>false</c>.
		/// </value>
		public bool? IsSelfSupplied { get; set; }
        /// <summary>
        /// Gets or sets the approve details.
        /// </summary>
        /// <value>
        /// The approve details.
        /// </value>
        public List<VettingTitleUserApprovelDetails> ApproverDetails { get; set; }
    }
}
