﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingCategorySummaryDetails
    /// </summary>
    public class VettingCategorySummaryDetails
	{
        /// <summary>
        /// Gets or sets the serial number.
        /// </summary>
        /// <value>
        /// The serial number.
        /// </value>
        public int SerialNumber { get; set; }
        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId { get; set; }
        /// <summary>
        /// Gets or sets the category description.
        /// </summary>
        /// <value>
        /// The category description.
        /// </value>
        public string CategoryDescription { get; set; }
        /// <summary>
        /// Gets or sets the template list.
        /// </summary>
        /// <value>
        /// The template list.
        /// </value>
        public List<VettingTemplateDetails> TemplateList { get; set; }

        /// <summary>
        /// Gets the templateto display.
        /// </summary>
        /// <value>
        /// The templateto display.
        /// </value>
        public string TemplateToDisplay
        {
            get { return (TemplateList != null && TemplateList.Any()) ? string.Join(", ", TemplateList.Select(x => x.TemplateName)) : string.Empty; }
        }

        /// <summary>
        /// Gets or sets the services.
        /// </summary>
        /// <value>
        /// The services.
        /// </value>
        public List<Lookup> Services { get; set; }

        /// <summary>
        /// Gets the services to display.
        /// </summary>
        /// <value>
        /// The services to display.
        /// </value>
        public string ServicesToDisplay
        {
            get { return (Services != null && Services.Any()) ? string.Join(", ", Services.Select(x => x.Description).ToList()) : string.Empty; }
        }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is status active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is status active; otherwise, <c>false</c>.
        /// </value>
        public bool IsStatusActive { get; set; }
        /// <summary>
        /// Gets or sets the category created by user identifier.
        /// </summary>
        /// <value>
        /// The category created by user identifier.
        /// </value>
        public string CategoryCreatedByUserId { get; set; }
        /// <summary>
        /// Gets or sets the name of the category created by user.
        /// </summary>
        /// <value>
        /// The name of the category created by user.
        /// </value>
        public string CategoryCreatedByUserName { get; set; }
        /// <summary>
        /// Gets or sets the category created date.
        /// </summary>
        /// <value>
        /// The category created date.
        /// </value>
        public DateTime? CategoryCreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the final sign off by.
        /// </summary>
        /// <value>
        /// The final sign off by.
        /// </value>
        public List<string> FinalSignOffBy { get; set; }

        /// <summary>
        /// Gets the final sign off to display.
        /// </summary>
        /// <value>
        /// The final sign off to display.
        /// </value>
        public string FinalSignOffToDisplay
        {
            get { return (FinalSignOffBy != null && FinalSignOffBy.Any()) ? string.Join(", ", FinalSignOffBy.ToList()) : string.Empty; }
        }

        /// <summary>
        /// Gets or sets the vetting title type identifier.
        /// </summary>
        /// <value>
        /// The vetting title type identifier.
        /// </value>
        public string VettingTitleTypeId { get; set; }
        /// <summary>
        /// Gets or sets the vetting title type description.
        /// </summary>
        /// <value>
        /// The vetting title type description.
        /// </value>
        public string VettingTitleTypeDescription { get; set; }
    }
}
