﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingTemplateDetails
    /// </summary>
    public class VettingTemplateDetails: BaseViewModel
    {
        #region Action
        /// <summary>
        /// The raise command changes
        /// </summary>
        private Action _raiseCommandChanges;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is mark dirty.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is mark dirty; otherwise, <c>false</c>.
        /// </value>
        public bool IsMarkDirty { get; set; }
        /// <summary>
        /// Gets or sets the serial number.
        /// </summary>
        /// <value>
        /// The serial number.
        /// </value>
        public int SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets the template identifier.
        /// </summary>
        /// <value>
        /// The template identifier.
        /// </value>
        public string TemplateId { get; set; }


        /// <summary>
        /// The template name
        /// </summary>
        private string _templateName;

        /// <summary>
        /// Gets or sets the name of the template.
        /// </summary>
        /// <value>
        /// The name of the template.
        /// </value>
        public string TemplateName
        {
            get { return _templateName; }
            set 
            {
                if (Set(() => TemplateName, ref _templateName, value))
                {
                    if (IsMarkDirty)
                    {
                        AddIsDirty();
                        if (_raiseCommandChanges != null)
                        {
                            _raiseCommandChanges();
                        }
                    }
                }
            }
        }


        /// <summary>
        /// The version number
        /// </summary>
        private decimal? _versionNumber;
        /// <summary>
        /// Gets or sets the version number.
        /// </summary>
        /// <value>
        /// The version number.
        /// </value>
        public decimal? VersionNumber
        {
            get { return _versionNumber; }
            set
            {
                if (Set(() => VersionNumber, ref _versionNumber, value))
                {
                    if (IsMarkDirty)
                    {
                        AddIsDirty();
                        if (_raiseCommandChanges != null)
                        {
                            _raiseCommandChanges();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; }
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public VettingAttributeDetails Status { get; set; }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>
        /// The created date.
        /// </value>
        public DateTime? CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// The category list
        /// </summary>
        public List<VettingCategoryDetails> VettingCategories;

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <value>
        /// The categories.
        /// </value>
        public string Categories 
        {
            get { return (VettingCategories != null && VettingCategories.Any()) ? string.Join(", ", VettingCategories.Select(x => x.CategoryName)) : string.Empty; }
        }


        /// <summary>
        /// The is default
        /// </summary>
        public bool? _isDefault;

        /// <summary>
        /// Gets or sets the is default.
        /// </summary>
        /// <value>
        /// The is default.
        /// </value>
        public bool? IsDefault
        {
            get { return _isDefault; }
            set
            {
                if (Set(() => IsDefault, ref _isDefault, value))
                {
                    if (IsMarkDirty)
                    {
                        AddIsDirty();
                        if (_raiseCommandChanges != null)
                        {
                            _raiseCommandChanges();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the vetting title libraries.
        /// </summary>
        /// <value>
        /// The vetting title libraries.
        /// </value>
        public List<string> VettingTitleLibraries { get; set; }

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="VettingTemplateDetails"/> class.
        /// </summary>
        public VettingTemplateDetails(INavigationContext navigationContext, Action raiseCommandChanges) : base(navigationContext)
        {
            Status = new VettingAttributeDetails();
            VettingCategories = new List<VettingCategoryDetails>();
            VettingTitleLibraries = new List<string>();

            _raiseCommandChanges = raiseCommandChanges;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VettingTemplateDetails"/> class.
        /// </summary>
        public VettingTemplateDetails()
        {
            Status = new VettingAttributeDetails();
            VettingCategories = new List<VettingCategoryDetails>();
            VettingTitleLibraries = new List<string>();
        }
        #endregion

        #region CleanUp Methods

        /// <summary>
        /// Cleans up the instance resources.
        /// <para>
        /// To cleanup additional resources, override this method, clean up and then call base.Cleanup().
        /// </para>
        /// </summary>
        public override void Cleanup()
        {
            _raiseCommandChanges = null;

            base.Cleanup();
        }

        #endregion
    }
}
