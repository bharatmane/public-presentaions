﻿using System.Collections.Generic;
using System.Linq;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class MDMMatchingCompanyDetail
	/// </summary>
	public class MDMMatchingCompanyDetail
	{
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }

		/// <summary>
		/// Gets or sets the name of the company.
		/// </summary>
		/// <value>
		/// The name of the company.
		/// </value>
		public string CompanyName { get; set; }

		/// <summary>
		/// Gets or sets the address.
		/// </summary>
		/// <value>
		/// The address.
		/// </value>
		public string Address { get; set; }
		/// <summary>
		/// Gets or sets the town.
		/// </summary>
		/// <value>
		/// The town.
		/// </value>
		public string Town { get; set; }
		/// <summary>
		/// Gets or sets the country.
		/// </summary>
		/// <value>
		/// The country.
		/// </value>
		public string Country { get; set; }
		/// <summary>
		/// Gets or sets the type of the company.
		/// </summary>
		/// <value>
		/// The type of the company.
		/// </value>
		public List<string> CompanyType { get; set; }

		/// <summary>
		/// Gets the company types.
		/// </summary>
		/// <value>
		/// The company types.
		/// </value>
		public string CompanyTypes
		{
			get { return CompanyType != null && CompanyType.Any() ? string.Join(", ", CompanyType) : string.Empty; }
		}
		/// <summary>
		/// Gets or sets the email.
		/// </summary>
		/// <value>
		/// The email.
		/// </value>
		public string Email { get; set; }
		/// <summary>
		/// Gets or sets the telephone.
		/// </summary>
		/// <value>
		/// The telephone.
		/// </value>
		public string Telephone { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="MDMMatchingCompanyDetail"/> class.
		/// </summary>
		public MDMMatchingCompanyDetail()
		{
			CompanyType = new List<string>();
		}
	}
}
