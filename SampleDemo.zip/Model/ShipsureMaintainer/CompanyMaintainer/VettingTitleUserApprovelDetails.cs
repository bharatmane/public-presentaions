﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingTitleUserApprovelDetails
    /// </summary>
    public class VettingTitleUserApprovelDetails
	{
        /// <summary>
        /// Gets or sets the vetting title identifier.
        /// </summary>
        /// <value>
        /// The vetting title identifier.
        /// </value>
        public string VettingTitleId { get; set; }
        /// <summary>
        /// Gets or sets the level.
        /// </summary>
        /// <value>
        /// The level.
        /// </value>
        public int Level { get; set; }
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserId { get; set; }
        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string UserName { get; set; }
        /// <summary>
        /// Gets or sets the user role identifier.
        /// </summary>
        /// <value>
        /// The user role identifier.
        /// </value>
        public string UserRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the user role description.
        /// </summary>
        /// <value>
        /// The user role description.
        /// </value>
        public string UserRoleDescription { get; set; }
        /// <summary>
        /// Gets or sets the first apporval date.
        /// </summary>
        /// <value>
        /// The first apporval date.
        /// </value>
        public DateTime? CompletedDate { get; set; }

		/// <summary>
		/// Gets or sets the name of the level.
		/// </summary>
		/// <value>
		/// The name of the level.
		/// </value>
		public string LevelName { get; set; }
    }
}
