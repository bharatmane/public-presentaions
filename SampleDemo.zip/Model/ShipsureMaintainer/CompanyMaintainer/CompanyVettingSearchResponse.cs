﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class CompanyVettingSearchResponse
	/// </summary>
	public class CompanyVettingSearchResponse
	{
        /// <summary>
        /// Gets or sets the vr identifier.
        /// </summary>
        /// <value>
        /// The vr identifier.
        /// </value>
        public string VR_ID { get; set; }

        /// <summary>
        /// Gets or sets the vetting curr status identifier.
        /// </summary>
        /// <value>
        /// The vetting curr status identifier.
        /// </value>
        public string VettingCurrStatusId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vetting status.
        /// </summary>
        /// <value>
        /// The name of the vetting status.
        /// </value>
        public string VettingStatusName { get; set; }

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the color of the vetting status.
        /// </summary>
        /// <value>
        /// The color of the vetting status.
        /// </value>
        public string VettingStatusColor { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the type of the request.
        /// </summary>
        /// <value>
        /// The type of the request.
        /// </value>
        public string RequestType { get; set; }

    }
}
