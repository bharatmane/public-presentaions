﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class RequesterDetails
	/// </summary>
	/// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
	public class RequesterDetails : BaseViewModel
    {
        /// <summary>
        /// The requested by
        /// </summary>
        private string _requestedBy;
        /// <summary>
        /// Gets or sets the requested by.
        /// </summary>
        /// <value>
        /// The requested by.
        /// </value>
        public string RequestedBy
        {
            get { return _requestedBy; }
            set { Set(() => RequestedBy, ref _requestedBy, value); }
        }
        /// <summary>
        /// The requested date
        /// </summary>
        private DateTime? _requestedDate;
        /// <summary>
        /// Gets or sets the requested date.
        /// </summary>
        /// <value>
        /// The requested date.
        /// </value>
        public DateTime? RequestedDate
        {
            get { return _requestedDate; }
            set { Set(() => RequestedDate, ref _requestedDate, value); }
        }
    }

}
