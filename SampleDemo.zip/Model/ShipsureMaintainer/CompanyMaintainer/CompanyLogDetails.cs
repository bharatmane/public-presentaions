﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// The company log details
    /// </summary>
    public class CompanyLogDetails
    {
        /// <summary>
        /// Gets or sets the name of the user displya.
        /// </summary>
        /// <value>
        /// The name of the user displya.
        /// </value>
        public string UserDisplyaName { get; set; }
        /// <summary>
        /// Gets or sets the user role.
        /// </summary>
        /// <value>
        /// The user role.
        /// </value>
        public string UserRole { get; set; }
        /// <summary>
        /// Gets or sets the user action.
        /// </summary>
        /// <value>
        /// The user action.
        /// </value>
        public string UserAction { get; set; }
        /// <summary>
        /// Gets or sets the local date time.
        /// </summary>
        /// <value>
        /// The local date time.
        /// </value>
        public DateTime? LocalDateTime { get; set; }
        /// <summary>
        /// Gets or sets the UTC date time.
        /// </summary>
        /// <value>
        /// The UTC date time.
        /// </value>
        public DateTime? UTCDateTime { get; set; }
    }
}
