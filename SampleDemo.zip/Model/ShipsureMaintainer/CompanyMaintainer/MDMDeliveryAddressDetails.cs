﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class MDMDeliveryAddressDetails
	/// </summary>
	public class MDMDeliveryAddressDetails
	{
		/// <summary>
		/// Gets or sets the address identifier.
		/// </summary>
		/// <value>
		/// The address identifier.
		/// </value>
		public string AddressId { get; set; }
		/// <summary>
		/// Gets or sets a value indicating whether this instance is default.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is default; otherwise, <c>false</c>.
		/// </value>
		public bool IsDefault { get; set; }
		/// <summary>
		/// Gets or sets the address.
		/// </summary>
		/// <value>
		/// The address.
		/// </value>
		public string Address { get; set; }
		/// <summary>
		/// Gets or sets the town.
		/// </summary>
		/// <value>
		/// The town.
		/// </value>
		public string Town { get; set; }
		/// <summary>
		/// Gets or sets the state.
		/// </summary>
		/// <value>
		/// The state.
		/// </value>
		public string State { get; set; }
		/// <summary>
		/// Gets or sets the post code.
		/// </summary>
		/// <value>
		/// The post code.
		/// </value>
		public string PostCode { get; set; }
		/// <summary>
		/// Gets or sets the country.
		/// </summary>
		/// <value>
		/// The country.
		/// </value>
		public string Country { get; set; }
		/// <summary>
		/// Gets or sets the telephone.
		/// </summary>
		/// <value>
		/// The telephone.
		/// </value>
		public string Telephone { get; set; }
		/// <summary>
		/// Gets or sets the fax.
		/// </summary>
		/// <value>
		/// The fax.
		/// </value>
		public string Fax { get; set; }
		/// <summary>
		/// Gets or sets the email.
		/// </summary>
		/// <value>
		/// The email.
		/// </value>
		public string Email { get; set; }
		/// <summary>
		/// Gets or sets the lat degree.
		/// </summary>
		/// <value>
		/// The lat degree.
		/// </value>
		public decimal? LatDegree { get; set; }
		/// <summary>
		/// Gets or sets the lat minimum.
		/// </summary>
		/// <value>
		/// The lat minimum.
		/// </value>
		public decimal? LatMin { get; set; }
		/// <summary>
		/// Gets or sets the lat indicatoer.
		/// </summary>
		/// <value>
		/// The lat indicatoer.
		/// </value>
		public string LatIndicatoer { get; set; }

		/// <summary>
		/// Gets or sets the long degree.
		/// </summary>
		/// <value>
		/// The long degree.
		/// </value>
		public decimal? LongDegree { get; set; }
		/// <summary>
		/// Gets or sets the long minimum.
		/// </summary>
		/// <value>
		/// The long minimum.
		/// </value>
		public decimal? LongMin { get; set; }

		/// <summary>
		/// Gets or sets the long indicatoer.
		/// </summary>
		/// <value>
		/// The long indicatoer.
		/// </value>
		public string LongIndicatoer { get; set; }

		/// <summary>
		/// Gets a value indicating whether this instance is show latitude.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is show latitude; otherwise, <c>false</c>.
		/// </value>
		public bool IsShowLatitude
		{
			get { return LatDegree.HasValue && LatMin.HasValue && !string.IsNullOrWhiteSpace(LatIndicatoer); }
		}

		/// <summary>
		/// Gets a value indicating whether this instance is show longitude.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is show longitude; otherwise, <c>false</c>.
		/// </value>
		public bool IsShowLongitude
		{
			get { return LongDegree.HasValue && LongMin.HasValue && !string.IsNullOrWhiteSpace(LongIndicatoer); }
		}
	}
}
