﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// CompanyVettingTitleDocumentDetails
	/// </summary>
	public class CompanyVettingTitleDocumentDetails
	{
        /// <summary>
        /// Gets or sets the document metadata identifier.
        /// </summary>
        /// <value>
        /// The document metadata identifier.
        /// </value>
        public string DocumentMetadataId { get; set; }

        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the document type description.
        /// </summary>
        /// <value>
        /// The document type description.
        /// </value>
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the issue date.
        /// </summary>
        /// <value>
        /// The issue date.
        /// </value>
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>
        /// The source.
        /// </value>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the uploaded by.
        /// </summary>
        /// <value>
        /// The uploaded by.
        /// </value>
        public string UploadedBy { get; set; }

        /// <summary>
        /// Gets or sets the uploaded on.
        /// </summary>
        /// <value>
        /// The uploaded on.
        /// </value>
        public DateTime? UploadedOn { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is link from selft supplied.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is link from selft supplied; otherwise, <c>false</c>.
		/// </value>
		public bool CanUnlinkToSelfSupplied { get; set; }

		/// <summary>
		/// Gets or sets the thumnail identifier.
		/// </summary>
		/// <value>
		/// The thumnail identifier.
		/// </value>
		public string ThumnailId { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is show delete button.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is show delete button; otherwise, <c>false</c>.
		/// </value>
		public bool IsShowDeleteButton { get; set; }
    }
}
