﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// UpdateResponse
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class UpdateResponse<T>
    {
        //TODO - Pi - this property needs to be removed
        /// <summary>
        /// Gets or sets a value indicating whether [operation success].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [operation success]; otherwise, <c>false</c>.
        /// </value>
        public bool OperationSuccess
        {
            get; set;
        }
        /// <summary>
        /// Gets or sets the records affected.
        /// </summary>
        /// <value>
        /// The records affected.
        /// </value>
        public int? RecordsAffected { get; set; }
        /// <summary>
        /// Gets or sets the result.
        /// </summary>
        /// <value>
        /// The result.
        /// </value>
        public T Result { get; set; }
    }
}
