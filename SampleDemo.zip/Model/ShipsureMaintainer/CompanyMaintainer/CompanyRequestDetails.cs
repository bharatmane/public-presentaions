﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class CompanyRequestDetails
	/// </summary>
	public class CompanyRequestDetails:BaseViewModel
    {
		/// <summary>
		/// The company identifier
		/// </summary>
		private string _companyId;
        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId 
        {
            get { return _companyId; }
            set { Set(() => CompanyId, ref _companyId, value); }
        }

		/// <summary>
		/// The company name
		/// </summary>
		private string _companyName;
        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>
        /// The name of the company.
        /// </value>
        public string CompanyName 
        {
            get { return _companyName; }
            set { Set(() => CompanyName, ref _companyName, value); }
        }

		/// <summary>
		/// The formal title
		/// </summary>
		private string _formalTitle;
        /// <summary>
        /// Gets or sets the formal title.
        /// </summary>
        /// <value>
        /// The formal title.
        /// </value>
        public string FormalTitle 
        {
            get { return _formalTitle; }
            set { Set(() => FormalTitle, ref _formalTitle, value); }
        }

		/// <summary>
		/// The address
		/// </summary>
		private string _address;
        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address
        {
            get { return _address; }
            set { Set(() => Address, ref _address, value); }
        }

		/// <summary>
		/// The town
		/// </summary>
		private string _town;
        /// <summary>
        /// Gets or sets the town.
        /// </summary>
        /// <value>
        /// The town.
        /// </value>
        public string Town 
        {
            get { return _town; }
            set { Set(() => Town, ref _town, value); }
        }

		/// <summary>
		/// The state
		/// </summary>
		private string _state;
        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>
        /// The state.
        /// </value>
        public string State 
        {
            get { return _state; }
            set { Set(() => State, ref _state, value); }
        }

		/// <summary>
		/// The zip code
		/// </summary>
		private string _zipCode;
        /// <summary>
        /// Gets or sets the zip code.
        /// </summary>
        /// <value>
        /// The zip code.
        /// </value>
        public string ZipCode
        {
            get { return _zipCode; }
            set { Set(() => ZipCode, ref _zipCode, value); }
        }

		/// <summary>
		/// The country
		/// </summary>
		private string _country;
        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country
        {
            get { return _country; }
            set { Set(() => Country, ref _country, value); }
        }

		/// <summary>
		/// The requested by
		/// </summary>
		private string _requestedBy;
        /// <summary>
        /// Gets or sets the requested by.
        /// </summary>
        /// <value>
        /// The requested by.
        /// </value>
        public string RequestedBy 
        {
            get { return _requestedBy; }
            set { Set(() => RequestedBy, ref _requestedBy, value); }
        }

		/// <summary>
		/// The requested date
		/// </summary>
		private DateTime? _requestedDate;
        /// <summary>
        /// Gets or sets the requested date.
        /// </summary>
        /// <value>
        /// The requested date.
        /// </value>
        public DateTime? RequestedDate
        {
            get { return _requestedDate; }
            set { Set(() => RequestedDate, ref _requestedDate, value); }
        }
		/// <summary>
		/// The validated by
		/// </summary>
		private string _validatedBy;
        /// <summary>
        /// Gets or sets the validated by.
        /// </summary>
        /// <value>
        /// The validated by.
        /// </value>
        public string ValidatedBy 
        {
            get { return _validatedBy; }
            set { Set(() => ValidatedBy, ref _validatedBy, value); }
        }

		/// <summary>
		/// The validated date
		/// </summary>
		private DateTime? _validatedDate;
        /// <summary>
        /// Gets or sets the validated date.
        /// </summary>
        /// <value>
        /// The validated date.
        /// </value>
        public DateTime? ValidatedDate 
        {
            get { return _validatedDate; }
            set { Set(() => ValidatedDate, ref _validatedDate, value); }
        }

		/// <summary>
		/// The template
		/// </summary>
		private string _template;
        /// <summary>
        /// Gets or sets the template.
        /// </summary>
        /// <value>
        /// The template.
        /// </value>
        public string Template 
        {
            get { return _template; }
            set { Set(() => Template, ref _template, value); }
        }

		/// <summary>
		/// Gets or sets the sign off user.
		/// </summary>
		/// <value>
		/// The sign off user.
		/// </value>
		public string SignOffUserName { get; set; }

		/// <summary>
		/// Gets or sets the sign off date date.
		/// </summary>
		/// <value>
		/// The sign off date date.
		/// </value>
		public DateTime? SignOffDate { get; set; }


        /// <summary>
        /// Gets or sets the sign off user identifier.
        /// </summary>
        /// <value>
        /// The sign off user identifier.
        /// </value>
        public string SignOffUserId { get; set; }

        /// <summary>
        /// Gets the sign off roles details.
        /// </summary>
        /// <value>
        /// The sign off roles details.
        /// </value>
        public string SignOffUserRole
        {
            get { return (SignOffRoleDetails != null && SignOffRoleDetails.Any()) ? string.Join(", ", SignOffRoleDetails.ToList()) : string.Empty; }
        }

        /// <summary>
        /// Gets or sets the sign off role details.
        /// </summary>
        /// <value>
        /// The sign off role details.
        /// </value>
        public List<string> SignOffRoleDetails { get; set; }
    }
}
