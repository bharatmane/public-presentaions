﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// 
    /// </summary>
    public class IBANValidateResponse
    {
        /// <summary>
        /// Gets or sets the iban request history identifier.
        /// </summary>
        /// <value>
        /// The iban request history identifier.
        /// </value>
        public string IBANRequestHistoryId { get; set; }

        /// <summary>
        /// Gets or sets the iban no.
        /// </summary>
        /// <value>
        /// The iban no.
        /// </value>
        public string IBANNo { get; set; }

        /// <summary>
        /// Gets or sets the iban validation status identifier.
        /// </summary>
        /// <value>
        /// The iban validation status identifier.
        /// </value>
        public string IBANValidationStatusID { get; set; }

        /// <summary>
        /// Gets or sets the iban validation status.
        /// </summary>
        /// <value>
        /// The iban validation status.
        /// </value>
        public string IBANValidationStatus { get; set; }

        /// <summary>
        /// Gets or sets the iban validation req failed message.
        /// </summary>
        /// <value>
        /// The iban validation req failed message.
        /// </value>
        public List<IBANErrors> IBANReqFailedMessage { get; set; }

        /// <summary>
        /// Gets or sets the name of the bank.
        /// </summary>
        /// <value>
        /// The name of the bank.
        /// </value>
        public string BankName { get; set; }

        /// <summary>
        /// Gets or sets the bic.
        /// </summary>
        /// <value>
        /// The bic.
        /// </value>
        public string BIC { get; set; }

        /// <summary>
        /// Gets or sets the account no.
        /// </summary>
        /// <value>
        /// The account no.
        /// </value>
        public string AccountNo { get; set; }

        /// <summary>
        /// Gets or sets the branch.
        /// </summary>
        /// <value>
        /// The branch.
        /// </value>
        public string Branch { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the city.
        /// </summary>
        /// <value>
        /// The city.
        /// </value>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets the zip.
        /// </summary>
        /// <value>
        /// The zip.
        /// </value>
        public string Zip { get; set; }

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the country only.
        /// </summary>
        /// <value>
        /// The country only.
        /// </value>
        public string CountryOnly { get; set; }

        /// <summary>
        /// Gets or sets the iban validations.
        /// </summary>
        /// <value>
        /// The iban validations.
        /// </value>
        public List<IBANValidations> IBANValidations { get; set; }

        /// <summary>
        /// Gets or sets the ibansepa schemas.
        /// </summary>
        /// <value>
        /// The ibansepa schemas.
        /// </value>
        public List<IBANSEPASchemas> IBANSEPASchemas { get; set; }

        /// <summary>
        /// Gets or sets the iban validated by.
        /// </summary>
        /// <value>
        /// The iban validated by.
        /// </value>
        public string IBANValidatedBy { get; set; }

        /// <summary>
        /// Gets or sets the iban validated on.
        /// </summary>
        /// <value>
        /// The iban validated on.
        /// </value>
        public DateTime? IBANValidatedOn { get; set; }
    }
}
