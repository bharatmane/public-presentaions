﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// IBANSEPASchemas
    /// </summary>
    public class IBANSEPASchemas
    {
        /// <summary>
        /// Gets or sets the name of the sepa schema.
        /// </summary>
        /// <value>
        /// The name of the sepa schema.
        /// </value>
        public string SEPASchemaName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [sepa schema passed].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [sepa schema passed]; otherwise, <c>false</c>.
        /// </value>
        public bool SEPASchemaPassed { get; set; }
    }
}
