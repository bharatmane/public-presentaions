﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class VettingTitleActionResult
	/// </summary>
	public class VettingTitleActionResult
	{
		/// <summary>
		/// Gets or sets the vetting request identifier.
		/// </summary>
		/// <value>
		/// The vetting request identifier.
		/// </value>
		public string VettingRequestId { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is action success.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is action success; otherwise, <c>false</c>.
		/// </value>
		public bool IsActionSuccess { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is request status going to change.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is request status going to change; otherwise, <c>false</c>.
		/// </value>
		public bool IsRequestStatusGoingToChange { get; set; }

		/// <summary>
		/// Gets or sets the vetting request status identifier.
		/// </summary>
		/// <value>
		/// The vetting request status identifier.
		/// </value>
		public string VettingRequestStatusId { get; set; }

		/// <summary>
		/// Gets or sets the error message.
		/// </summary>
		/// <value>
		/// The error message.
		/// </value>
		public string ErrorMessage { get; set; }

		/// <summary>
		/// Gets or sets the company vetting title list.
		/// </summary>
		/// <value>
		/// The company vetting title list.
		/// </value>
		public List<CompanyVettingTitleResponse> CompanyVettingTitleList { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="VettingTitleActionResult"/> class.
		/// </summary>
		public VettingTitleActionResult()
		{
			CompanyVettingTitleList = new List<CompanyVettingTitleResponse>();
		}
	}

	/// <summary>
	/// The company vetting title action response
	/// </summary>
	public class CompanyVettingTitleResponse
	{
		public string CvtId { get; set; }
		public string ErrorMessage { get; set; }
		public bool IsTitlePassed { get; set; }
	}
}
