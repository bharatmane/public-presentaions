﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// VettingAttributeRequest
    /// </summary>
    public class VettingAttributeRequest
    {
        /// <summary>
        /// Gets or sets the type of the attribute.
        /// </summary>
        /// <value>
        /// The type of the attribute.
        /// </value>
        public string AttributeType { get; set; }
    }
}
