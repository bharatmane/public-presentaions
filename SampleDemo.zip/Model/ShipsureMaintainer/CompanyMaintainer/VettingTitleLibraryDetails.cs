﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{

    /// <summary>
    /// class VettingTitleLibraryDetails
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class VettingTitleLibraryDetails:BaseViewModel
	{
        /// The is selected
        /// </summary>
        private bool _isSelected;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelected
        {
            get { return _isSelected; }
            set { Set(() => IsSelected, ref _isSelected, value); }
        }

        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string VTL_ID { get; set; }
        /// <summary>
        /// Gets or sets the vetting identifier.
        /// </summary>
        /// <value>
        /// The vetting identifier.
        /// </value>
        public string VettingId { get; set; }
        /// <summary>
        /// Gets or sets the vetting title.
        /// </summary>
        /// <value>
        /// The vetting title.
        /// </value>
        public string VettingTitle { get; set; }
        /// <summary>
        /// Gets or sets the type of the vetting title.
        /// </summary>
        /// <value>
        /// The type of the vetting title.
        /// </value>
        [Obsolete]
        public VettingAttributeDetails VettingTitleType { get; set; }
        /// <summary>
        /// Gets or sets the is one time check.
        /// </summary>
        /// <value>
        /// The is one time check.
        /// </value>
        public bool? IsOneTimeCheck { get; set; }
        /// <summary>
        /// Gets or sets the validity in months.
        /// </summary>
        /// <value>
        /// The validity in months.
        /// </value>
        public int? ValidityInMonths { get; set; }
        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int? RenewalDays { get; set; }
        /// <summary>
        /// Gets or sets the vet identifier.
        /// </summary>
        /// <value>
        /// The vet identifier.
        /// </value>
        public string VET_ID { get; set; }
        /// <summary>
        /// Gets or sets the evidence.
        /// </summary>
        /// <value>
        /// The evidence.
        /// </value>
        public string Evidence { get; set; }
        /// <summary>
        /// Gets or sets the type of the evidence.
        /// </summary>
        /// <value>
        /// The type of the evidence.
        /// </value>
        public string EvidenceType { get; set; }
        /// <summary>
        /// Gets or sets the is self supplied.
        /// </summary>
        /// <value>
        /// The is self supplied.
        /// </value>
        public bool IsSelfSupplied { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is applicable for amendment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is applicable for amendment; otherwise, <c>false</c>.
        /// </value>
        public bool IsApplicableForAmendment { get; set; }
        /// <summary>
        /// Gets or sets the approval level1.
        /// </summary>
        /// <value>
        /// The approval level1.
        /// </value>
        public string ApprovalLevel1 { get; set; }
        /// <summary>
        /// Gets or sets the approval level2.
        /// </summary>
        /// <value>
        /// The approval level2.
        /// </value>
        public string ApprovalLevel2 { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>
        /// The created date.
        /// </value>
        public DateTime? CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="VettingTitleLibraryDetails"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the vetting title type identifier.
        /// </summary>
        /// <value>
        /// The vetting title type identifier.
        /// </value>
        public string VettingTitleTypeId { get; set; }
        /// <summary>
        /// Gets or sets the vetting title type description.
        /// </summary>
        /// <value>
        /// The vetting title type description.
        /// </value>
        public string VettingTitleTypeDescription { get; set; }
    }
}
