﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// 
    /// </summary>
    public class VettingTitleDetailsForRenewalsCompany
    {
        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string Vtl_Id { get; set; }

        /// <summary>
        /// Gets or sets the vetting identifier.
        /// </summary>
        /// <value>
        /// The vetting identifier.
        /// </value>
        public string VettingId { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the type of the vetting.
        /// </summary>
        /// <value>
        /// The type of the vetting.
        /// </value>
        public string VettingType { get; set; }

        /// <summary>
        /// Gets or sets the renewal date.
        /// </summary>
        /// <value>
        /// The renewal date.
        /// </value>
        public DateTime? RenewalDate { get; set; }

        /// <summary>
        /// Gets or sets the type of the document.
        /// </summary>
        /// <value>
        /// The type of the document.
        /// </value>
        public List<string> DocumentType { get; set; }

        /// <summary>
        /// Gets the document list.
        /// </summary>
        /// <value>
        /// The document list.
        /// </value>
        public string DocumentList
        {
            get { return string.Join(", ", DocumentType); }
        }
    }

}