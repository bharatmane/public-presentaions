﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class CompanyType
    /// </summary>
    public class CompanyType
	{
        /// <summary>
        /// Gets or sets the company type identifier.
        /// </summary>
        /// <value>
        /// The company type identifier.
        /// </value>
        public string CompanyTypeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the company type.
        /// </summary>
        /// <value>
        /// The name of the company type.
        /// </value>
        public string CompanyTypeName { get; set; }
    }
}
