﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class VettingTemplateValidationDetails
	/// </summary>
	public class VettingTemplateValidationDetails
	{
        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string VTL_ID { get; set; }
        /// <summary>
        /// Gets or sets the VTT identifier.
        /// </summary>
        /// <value>
        /// The VTT identifier.
        /// </value>
        public string VTT_ID { get; set; }
        /// <summary>
        /// Gets or sets the vetting identifier.
        /// </summary>
        /// <value>
        /// The vetting identifier.
        /// </value>
        public string VettingId { get; set; }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the name of the vetting tye.
        /// </summary>
        /// <value>
        /// The name of the vetting tye.
        /// </value>
        public string VettingTyeName { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time check.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time check; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeCheck { get; set; }
        /// <summary>
        /// Gets or sets the validity months.
        /// </summary>
        /// <value>
        /// The validity months.
        /// </value>
        public int? Validity_Months { get; set; }
        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int? Renewal_Days { get; set; }
        /// <summary>
        /// Gets or sets the is applicable for amendment.
        /// </summary>
        /// <value>
        /// The is applicable for amendment.
        /// </value>
        public bool? IsApplicableForAmendment { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is deleted; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleted { get; set; }
        /// <summary>
        /// Gets or sets the first level approval role identifier.
        /// </summary>
        /// <value>
        /// The first level approval role identifier.
        /// </value>
        public string FirstLevelApprovalRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the first name of the level approval role.
        /// </summary>
        /// <value>
        /// The first name of the level approval role.
        /// </value>
        public string FirstLevelApprovalRoleName { get; set; }
        /// <summary>
        /// Gets or sets the second level approval role identifier.
        /// </summary>
        /// <value>
        /// The second level approval role identifier.
        /// </value>
        public string SecondLevelApprovalRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the name of the second level approval role.
        /// </summary>
        /// <value>
        /// The name of the second level approval role.
        /// </value>
        public string SecondLevelApprovalRoleName { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="VettingTemplateValidationDetails"/> is mapped.
        /// </summary>
        /// <value>
        ///   <c>true</c> if mapped; otherwise, <c>false</c>.
        /// </value>
        public bool Mapped { get; set; }
        /// <summary>
        /// Gets or sets the document typ names.
        /// </summary>
        /// <value>
        /// The document typ names.
        /// </value>
        public string DocumentTypNames { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is self supplied.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is self supplied; otherwise, <c>false</c>.
		/// </value>
		public bool IsSelfSupplied { get; set; }
    }
}
