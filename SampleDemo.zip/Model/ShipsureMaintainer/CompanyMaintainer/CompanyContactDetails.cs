﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class CompanyContactDetails
	/// </summary>
	public class CompanyContactDetails
	{
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyContactId { get; set; }

		/// <summary>
		/// Gets or sets the default.
		/// </summary>
		/// <value>
		/// The default.
		/// </value>
		public bool Default { get; set; }

		/// <summary>
		/// Gets or sets the department identifier.
		/// </summary>
		/// <value>
		/// The department identifier.
		/// </value>
		public string DepartmentID { get; set; }

		/// <summary>
		/// Gets or sets the name of the department.
		/// </summary>
		/// <value>
		/// The name of the department.
		/// </value>
		public string DepartmentName { get; set; }
		/// <summary>
		/// Gets or sets the position.
		/// </summary>
		/// <value>
		/// The position.
		/// </value>
		public string Position { get; set; }

		/// <summary>
		/// Gets or sets the name of the fore.
		/// </summary>
		/// <value>
		/// The name of the fore.
		/// </value>
		public string ForeName { get; set; }

		/// <summary>
		/// Gets or sets the last name.
		/// </summary>
		/// <value>
		/// The last name.
		/// </value>
		public string LastName { get; set; }
		/// <summary>
		/// Gets or sets the email.
		/// </summary>
		/// <value>
		/// The email.
		/// </value>
		public string Email { get; set; }
		/// <summary>
		/// Gets or sets the fax.
		/// </summary>
		/// <value>
		/// The fax.
		/// </value>
		public string Fax { get; set; }
		/// <summary>
		/// Gets or sets the telephone.
		/// </summary>
		/// <value>
		/// The telephone.
		/// </value>
		public string Telephone { get; set; }
		/// <summary>
		/// Gets or sets the mobile.
		/// </summary>
		/// <value>
		/// The mobile.
		/// </value>
		public string Mobile { get; set; }
		/// <summary>
		/// Gets or sets the skype.
		/// </summary>
		/// <value>
		/// The skype.
		/// </value>
		public string Skype { get; set; }
		/// <summary>
		/// Gets or sets the remark.
		/// </summary>
		/// <value>
		/// The remark.
		/// </value>
		public string Remark { get; set; }

		/// <summary>
		/// Gets the name.
		/// </summary>
		/// <value>
		/// The name.
		/// </value>
		public string Name
		{
			get { return (string.Concat(ForeName, " ", LastName)); }
		}
	}
}
