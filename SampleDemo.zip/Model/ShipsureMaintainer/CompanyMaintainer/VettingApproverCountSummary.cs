﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingApproverCountSummary
    /// </summary>
    public class VettingApproverCountSummary : BaseViewModel
    {
        private int? _vettingRequestedCount;
        /// <summary>
        /// Gets or sets the vetting requested count.
        /// </summary>
        /// <value>
        /// The vetting requested count.
        /// </value>
        public int? VettingRequestedCount
        {
            get { return _vettingRequestedCount; }
            set { Set(() => VettingRequestedCount, ref _vettingRequestedCount, value); }
        }

        /// <summary>
        /// The vetting in progress count
        /// </summary>
        private int? _vettingInProgressCount;
        /// <summary>
        /// Gets or sets the vetting in progress count.
        /// </summary>
        /// <value>
        /// The vetting in progress count.
        /// </value>
        public int? VettingInProgressCount
        {
            get { return _vettingInProgressCount; }
            set { Set(() => VettingInProgressCount, ref _vettingInProgressCount, value); }
        }

        /// <summary>
        /// The vetting failed count
        /// </summary>
        private int? _vettingFailedCount;
        /// <summary>
        /// Gets or sets the vetting failed count.
        /// </summary>
        /// <value>
        /// The vetting failed count.
        /// </value>
        public int? VettingFailedCount
        {
            get { return _vettingFailedCount; }
            set { Set(() => VettingFailedCount, ref _vettingFailedCount, value); }
        }

        /// <summary>
        /// The total vetting count
        /// </summary>
        private int? _totalVettingCount;
        /// <summary>
        /// Gets or sets the total vetting count.
        /// </summary>
        /// <value>
        /// The total vetting count.
        /// </value>
        public int? TotalVettingCount
        {
            get { return _totalVettingCount; }
            set { Set(() => TotalVettingCount, ref _totalVettingCount, value); }
        }

        /// <summary>
        /// The vetting pending sign off count
        /// </summary>
        private int? _vettingSignOffCount;
        /// <summary>
        /// Gets or sets the vetting pending sign off count.
        /// </summary>
        /// <value>
        /// The vetting pending sign off count.
        /// </value>
        public int? VettingSignOffCount
        {
            get { return _vettingSignOffCount; }
            set
            {
                Set(() => VettingSignOffCount, ref _vettingSignOffCount, value);
            }
        }
    }
}
