﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// IBANValidations
    /// </summary>
    public class IBANValidations
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the name of the key.
        /// </summary>
        /// <value>
        /// The name of the key.
        /// </value>
        public string KeyName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is validation success.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is validation success; otherwise, <c>false</c>.
        /// </value>
        public bool IsValidationSuccess { get; set; }
    }
}
