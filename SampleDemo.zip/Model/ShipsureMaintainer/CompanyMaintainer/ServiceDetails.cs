﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class ServiceDetails
	/// </summary>
	public class ServiceDetails
	{
		/// <summary>
		/// Gets or sets the service identifier.
		/// </summary>
		/// <value>
		/// The service identifier.
		/// </value>
		public string ServiceId { get; set; }

		/// <summary>
		/// Gets or sets the name of the service.
		/// </summary>
		/// <value>
		/// The name of the service.
		/// </value>
		public string ServiceName { get; set; }

		/// <summary>
		/// Gets or sets the short code.
		/// </summary>
		/// <value>
		/// The short code.
		/// </value>
		public string ShortCode { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is vetting required.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is vetting required; otherwise, <c>false</c>.
		/// </value>
		public bool IsVettingRequired { get; set; }

		/// <summary>
		/// Gets or sets the start date.
		/// </summary>
		/// <value>
		/// The start date.
		/// </value>
		public DateTime? StartDate { get; set; }

		/// <summary>
		/// Gets or sets the end date.
		/// </summary>
		/// <value>
		/// The end date.
		/// </value>
		public DateTime? EndDate { get; set; }

		/// <summary>
		/// Gets or sets the category.
		/// </summary>
		/// <value>
		/// The category.
		/// </value>
		public string Category { get; set; }

		/// <summary>
		/// Gets or sets the status.
		/// </summary>
		/// <value>
		/// The status.
		/// </value>
		public string Status { get; set; }

		/// <summary>
		/// Gets or sets the added on.
		/// </summary>
		/// <value>
		/// The added on.
		/// </value>
		public DateTime? AddedOn { get; set; }

		/// <summary>
		/// Gets or sets the added by.
		/// </summary>
		/// <value>
		/// The added by.
		/// </value>
		public string AddedBy { get; set; }

		/// <summary>
		/// Gets or sets the closed on.
		/// </summary>
		/// <value>
		/// The closed on.
		/// </value>
		public DateTime? ClosedOn { get; set; }

		/// <summary>
		/// Gets or sets the closed by.
		/// </summary>
		/// <value>
		/// The closed by.
		/// </value>
		public string ClosedBy { get; set; }

		/// <summary>
		/// Gets or sets the remarks.
		/// </summary>
		/// <value>
		/// The remarks.
		/// </value>
		public string Remarks { get; set; }

		/// <summary>
		/// Gets or sets the close cancel reason.
		/// </summary>
		/// <value>
		/// The close cancel reason.
		/// </value>
		public string CloseCancelReason { get; set; }
	}
}
