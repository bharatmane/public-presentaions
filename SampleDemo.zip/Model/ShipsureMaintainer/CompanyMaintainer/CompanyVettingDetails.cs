﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class CompanyVettingDetails
    /// </summary>
    public class CompanyVettingDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyVettingDetails"/> class.
        /// </summary>
        public CompanyVettingDetails()
        {
            Categories = new List<VettingCategoryDetails>();
            CompanyTypes = new List<CompanyType>();
            CompanyVettingStatus = new VettingAttributeDetails();
            SignOffRolesAssignedToCategory = new List<string>();
        }

        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }
        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>
        /// The name of the company.
        /// </value>
        public string CompanyName { get; set; }

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the categories.
        /// </summary>
        /// <value>
        /// The categories.
        /// </value>
        public List<VettingCategoryDetails> Categories { get; set; }

        /// <summary>
        /// Gets or sets the company types.
        /// </summary>
        /// <value>
        /// The company types.
        /// </value>
        public List<CompanyType> CompanyTypes { get; set; }

        /// <summary>
        /// Gets or sets the existing company types.
        /// </summary>
        /// <value>
        /// The existing company types.
        /// </value>
        public List<CompanyType> ExistingCompanyTypes { get; set; }

        /// <summary>
        /// Gets or sets the company vetting status.
        /// </summary>
        /// <value>
        /// The company vetting status.
        /// </value>
        public VettingAttributeDetails CompanyVettingStatus { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is any title failed.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is any title failed; otherwise, <c>false</c>.
        /// </value>
        public bool IsAnyTitleFailed { get; set; }

		/// <summary>
		/// Gets or sets the request type identifier.
		/// </summary>
		/// <value>
		/// The request type identifier.
		/// </value>
		public string RequestTypeId { get; set; }
        /// <summary>
        /// Gets or sets the type of the request.
        /// </summary>
        /// <value>
        /// The type of the request.
        /// </value>
        public string RequestType { get; set; }

        /// <summary>
        /// Gets or sets the last updated on.
        /// </summary>
        /// <value>
        /// The last updated on.
        /// </value>
        public DateTime? LastUpdatedDate { get; set; }

        /// <summary>
        /// Gets or sets the requested date.
        /// </summary>
        /// <value>
        /// The requested date.
        /// </value>
        public DateTime? RequestedDate { get; set; }

        /// <summary>
        /// Gets or sets the requested by.
        /// </summary>
        /// <value>
        /// The requested by.
        /// </value>
        public string RequestedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string LastUpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the validated on.
        /// </summary>
        /// <value>
        /// The validated on.
        /// </value>
        public DateTime? ValidatedDate { get; set; }

        /// <summary>
        /// Gets or sets the validated by.
        /// </summary>
        /// <value>
        /// The validated by.
        /// </value>
        public string ValidatedBy { get; set; }

        /// <summary>
        /// Gets or sets the sign off date.
        /// </summary>
        /// <value>
        /// The sign off date.
        /// </value>
        public DateTime? SignOffDate { get; set; }

        /// <summary>
        /// Gets or sets the sign off by.
        /// </summary>
        /// <value>
        /// The sign off by.
        /// </value>
        public string SignOffBy { get; set; }

        /// <summary>
        /// Gets or sets the renewal date.
        /// </summary>
        /// <value>
        /// The renewal date.
        /// </value>
        public DateTime? RenewalDueDate { get; set; }

        /// <summary>
        /// Gets or sets the effective date.
        /// </summary>
        /// <value>
        /// The effective date.
        /// </value>
        public DateTime? EffectiveDate { get; set; }

		/// <summary>
		/// Gets or sets the sign off roles assigned to category.
		/// </summary>
		/// <value>
		/// The sign off roles assigned to category.
		/// </value>
		public List<string> SignOffRolesAssignedToCategory { get; set; }

		/// <summary>
		/// Gets the sign off role.
		/// </summary>
		/// <value>
		/// The sign off role.
		/// </value>
		public string SignOffRole
		{
            get { return (SignOffRolesAssignedToCategory != null && SignOffRolesAssignedToCategory.Any()) ? string.Join(", ",SignOffRolesAssignedToCategory.ToList()) : null; }
        }
    }
}
