﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// IBANMatchedKeyUpdateRequest
    /// </summary>
    public class IBANMatchedKeyUpdateRequest
    {
        /// <summary>
        /// Gets or sets the iban request history identifier.
        /// </summary>
        /// <value>
        /// The iban request history identifier.
        /// </value>
        public string IBANRequestHistoryId { get; set; }

        /// <summary>
        /// Gets or sets the request source matched identifier.
        /// </summary>
        /// <value>
        /// The request source matched identifier.
        /// </value>
        public string RequestSourceMatchedId { get; set; }
    }
}
