﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class VettingTitleUpdateRequest
    /// </summary>
    public class VettingTitleUpdateRequest
	{
        /// <summary>
        /// Gets or sets the cva identifier.
        /// </summary>
        /// <value>
        /// The cva identifier.
        /// </value>
        public string CvaId { get; set; }
        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }
        /// <summary>
        /// Gets or sets the vetting title identifier.
        /// </summary>
        /// <value>
        /// The vetting title identifier.
        /// </value>
        public string VettingTitleId { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is vetting title pass.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is vetting title pass; otherwise, <c>false</c>.
        /// </value>
        public bool IsVettingTitlePass { get; set; }
        /// <summary>
        /// Gets or sets the approver user role.
        /// </summary>
        /// <value>
        /// The approver user role.
        /// </value>
        public string ApproverUserRole { get; set; }
        /// <summary>
        /// Gets or sets the approver user identifier.
        /// </summary>
        /// <value>
        /// The approver user identifier.
        /// </value>
        public string ApproverUserId { get; set; }
        /// <summary>
        /// Gets or sets the vetting title identifier list.
        /// </summary>
        /// <value>
        /// The vetting title identifier list.
        /// </value>
        public List<string> VettingTitleIdList { get; set; }
        /// <summary>
        /// Gets or sets the level.
        /// </summary>
        /// <value>
        /// The level.
        /// </value>
        public int? Level { get; set; }
        /// <summary>
        /// Gets or sets the effective renewal date.
        /// </summary>
        /// <value>
        /// The effective renewal date.
        /// </value>
        public DateTime? EffectiveRenewalDate { get; set; }
        /// <summary>
        /// Gets or sets the reject reason.
        /// </summary>
        /// <value>
        /// The reject reason.
        /// </value>
        public string RejectReason { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is fail company vetting.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is fail company vetting; otherwise, <c>false</c>.
        /// </value>
        public bool IsFailCompanyVetting { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is reject company vetting.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is reject company vetting; otherwise, <c>false</c>.
        /// </value>
        public bool IsRejectCompanyVetting { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is approve company vetting.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is approve company vetting; otherwise, <c>false</c>.
        /// </value>
        public bool IsApproveCompanyVetting { get; set; }

		/// <summary>
		/// Gets or sets the note description.
		/// </summary>
		/// <value>
		/// The note description.
		/// </value>
		public string NoteDescription { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="VettingTitleUpdateRequest"/> class.
        /// </summary>
        public VettingTitleUpdateRequest()
		{
            VettingTitleIdList = new List<string>();
        }
    }
}
