﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// class CompanyNotesRequest
	/// </summary>
	public class CompanyNotesRequest
	{
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }

        /// <summary>
        /// Gets or sets the note identifier.
        /// </summary>
        /// <value>
        /// The note identifier.
        /// </value>
        public string NoteIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the notes descrption.
        /// </summary>
        /// <value>
        /// The notes descrption.
        /// </value>
        public string NotesDescrption { get; set; }
    }
}
