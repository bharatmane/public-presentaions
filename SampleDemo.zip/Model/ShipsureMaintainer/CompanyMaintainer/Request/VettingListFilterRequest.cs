﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class VettingListFilterRequest
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request.RenewalFilterRequest" />
    public class VettingListFilterRequest: RenewalFilterRequest
	{
        /// <summary>
        /// Gets or sets the company type ids.
        /// </summary>
        /// <value>
        /// The company type ids.
        /// </value>
        public List<string> CompanyTypeIds { get; set; }

        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }

        /// <summary>
        /// Gets or sets the category ids.
        /// </summary>
        /// <value>
        /// The category ids.
        /// </value>
        public List<string> CategoryIds { get; set; }

        /// <summary>
        /// Gets or sets the vatting status ids.
        /// </summary>
        /// <value>
        /// The vatting status ids.
        /// </value>
        public List<string> VattingStatusIds { get; set; }

        /// <summary>
        /// Gets or sets the show less than 5 days requests.
        /// </summary>
        /// <value>
        /// The show less than 5 days requests.
        /// </value>
        public bool ShowLessThan5DaysRequests { get; set; }

        /// <summary>
        /// Gets or sets the show greater than 5 days requests.
        /// </summary>
        /// <value>
        /// The show greater than 5 days requests.
        /// </value>
        public bool ShowGreaterThan5DaysRequests { get; set; }

        /// <summary>
        /// Gets or sets the show failed requests.
        /// </summary>
        /// <value>
        /// The show failed requests.
        /// </value>
        public bool ShowFailedRequests { get; set; }

        /// <summary>
        /// Gets or sets the show renewal request.
        /// </summary>
        /// <value>
        /// The show renewal request.
        /// </value>
        public bool ShowOverdueRenewalRequest { get; set; }

        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int? RenewalDays { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is show vettig sign off request.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is show vettig sign off request; otherwise, <c>false</c>.
        /// </value>
        public bool IsShowVettigSignOffRequest { get; set; }

		/// <summary>
		/// Gets or sets the searched text.
		/// </summary>
		/// <value>
		/// The searched text.
		/// </value>
		public string SearchedText { get; set; }
    }
}
