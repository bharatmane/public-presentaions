﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class RenewalFilterRequest
    /// </summary>
    public class RenewalFilterRequest
	{
        /// <summary>
        /// Gets or sets the renewal start date.
        /// </summary>
        /// <value>
        /// The renewal start date.
        /// </value>
        public DateTime? RenewalStartDate { get; set; }

        /// <summary>
        /// Gets or sets the renewal end date.
        /// </summary>
        /// <value>
        /// The renewal end date.
        /// </value>
        public DateTime? RenewalEndDate { get; set; }
    }
}
