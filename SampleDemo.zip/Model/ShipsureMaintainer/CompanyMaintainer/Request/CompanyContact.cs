﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class CompanyContact
	{
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }

		/// <summary>
		/// Gets or sets the default.
		/// </summary>
		/// <value>
		/// The default.
		/// </value>
		public bool Default { get; set; }
		/// <summary>
		/// Gets or sets the department.
		/// </summary>
		/// <value>
		/// The department.
		/// </value>
		public string Department { get; set; }
		/// <summary>
		/// Gets or sets the position.
		/// </summary>
		/// <value>
		/// The position.
		/// </value>
		public string Position { get; set; }
		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>
		/// The name.
		/// </value>
		public string Name { get; set; }
		/// <summary>
		/// Gets or sets the email.
		/// </summary>
		/// <value>
		/// The email.
		/// </value>
		public string Email { get; set; }
		/// <summary>
		/// Gets or sets the fax.
		/// </summary>
		/// <value>
		/// The fax.
		/// </value>
		public string Fax { get; set; }
		/// <summary>
		/// Gets or sets the telephone.
		/// </summary>
		/// <value>
		/// The telephone.
		/// </value>
		public string Telephone { get; set; }
		/// <summary>
		/// Gets or sets the mobile.
		/// </summary>
		/// <value>
		/// The mobile.
		/// </value>
		public string Mobile { get; set; }
		/// <summary>
		/// Gets or sets the skype.
		/// </summary>
		/// <value>
		/// The skype.
		/// </value>
		public string Skype { get; set; }
		/// <summary>
		/// Gets or sets the remark.
		/// </summary>
		/// <value>
		/// The remark.
		/// </value>
		public string Remark { get; set; }
	}
}
