﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class VettingTitleQuestionLibrarySaveRequest
    /// </summary>
    public class VettingTitleQuestionLibrarySaveRequest
    {
        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string VTL_ID { get; set; }
        /// <summary>
        /// Gets or sets the vetting identifier.
        /// </summary>
        /// <value>
        /// The vetting identifier.
        /// </value>
        public string VettingId { get; set; }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the vetting tye.
        /// </summary>
        /// <value>
        /// The vetting tye.
        /// </value>
        public string VettingTye { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time check.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time check; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeCheck { get; set; }
        /// <summary>
        /// Gets or sets the validity months.
        /// </summary>
        /// <value>
        /// The validity months.
        /// </value>
        public int Validity_Months { get; set; }
        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int Renewal_Days { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is applicable for amendment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is applicable for amendment; otherwise, <c>false</c>.
        /// </value>
        public bool IsApplicableForAmendment { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is deleted; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleted { get; set; }
        /// <summary>
        /// Gets or sets the first level approval role identifier.
        /// </summary>
        /// <value>
        /// The first level approval role identifier.
        /// </value>
        public string FirstLevelApprovalRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the second level approval role identifier.
        /// </summary>
        /// <value>
        /// The second level approval role identifier.
        /// </value>
        public string SecondLevelApprovalRoleIdentifier { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is b2 b.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is b2 b; otherwise, <c>false</c>.
        /// </value>
        public bool IsB2B { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is marcas.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is marcas; otherwise, <c>false</c>.
        /// </value>
        public bool IsMarcas { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is catering.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is catering; otherwise, <c>false</c>.
        /// </value>
        public bool IsCatering { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is document required.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is document required; otherwise, <c>false</c>.
        /// </value>
        public bool IsDocumentRequired { get; set; }

        /// <summary>
        /// Gets or sets the mapped documents.
        /// </summary>
        /// <value>
        /// The mapped documents.
        /// </value>
        public List<string> MappedDocuments { get; set; }
        /// <summary>
        /// Gets or sets the mapped templates.
        /// </summary>
        /// <value>
        /// The mapped templates.
        /// </value>
        public List<string> MappedTemplates { get; set; }

        /// <summary>
        /// Gets or sets the mapped company i ds.
        /// </summary>
        /// <value>
        /// The mapped company i ds.
        /// </value>
        public List<string> MappedCompanyIDs { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is self supply.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is self supply; otherwise, <c>false</c>.
        /// </value>
        public bool IsSelfSupply { get; set; }
    }
}
