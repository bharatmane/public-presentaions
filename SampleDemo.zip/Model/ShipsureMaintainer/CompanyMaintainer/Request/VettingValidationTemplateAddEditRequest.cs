﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	///  class VettingValidationTemplateAddEditRequest
	/// </summary>
	public class VettingValidationTemplateAddEditRequest
    {
        /// <summary>
        /// Gets or sets the vt identifier.
        /// </summary>
        /// <value>
        /// The vt identifier.
        /// </value>
        public string VT_ID { get; set; }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; }
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public decimal? Version { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is draft copy.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is draft copy; otherwise, <c>false</c>.
        /// </value>
        public bool IsDraftCopy { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is default for category.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is default for category; otherwise, <c>false</c>.
        /// </value>
        public bool IsDefaultForCategory { get; set; }
        /// <summary>
        /// Gets or sets the mapped categories.
        /// </summary>
        /// <value>
        /// The mapped categories.
        /// </value>
        public List<string> MappedCategories { get; set; }
        /// <summary>
        /// Gets or sets the mapped vetting titles.
        /// </summary>
        /// <value>
        /// The mapped vetting titles.
        /// </value>
        public List<string> MappedVettingTitles { get; set; }
    }
}
