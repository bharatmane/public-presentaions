﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class VettingApproverNotesRequest
    /// </summary>
    public class VettingApproverNotesRequest
	{
        /// <summary>
        /// Gets or sets the note identifier.
        /// </summary>
        /// <value>
        /// The note identifier.
        /// </value>
        public string NoteIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the vetting title identifier.
        /// </summary>
        /// <value>
        /// The vetting title identifier.
        /// </value>
        public string VettingTitleId { get; set; }
        /// <summary>
        /// Gets or sets the user role identifier.
        /// </summary>
        /// <value>
        /// The user role identifier.
        /// </value>
        public string UserRoleId { get; set; }
        /// <summary>
        /// Gets or sets the notes descrption.
        /// </summary>
        /// <value>
        /// The notes descrption.
        /// </value>
        public string NotesDescrption { get; set; }

		/// <summary>
		/// Gets or sets the level.
		/// </summary>
		/// <value>
		/// The level.
		/// </value>
		public int? Level { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string VtlId { get; set; }
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
    }
}
