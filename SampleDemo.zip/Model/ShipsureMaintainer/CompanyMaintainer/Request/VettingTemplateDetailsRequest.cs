﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class VettingTemplateDetailsRequest
    /// </summary>
    public class VettingTemplateDetailsRequest
    {
        /// <summary>
        /// Gets or sets the template identifier.
        /// </summary>
        /// <value>
        /// The template identifier.
        /// </value>
        public string TemplateId { get; set; }
        /// <summary>
        /// Gets or sets the name of the template.
        /// </summary>
        /// <value>
        /// The name of the template.
        /// </value>
        public string TemplateName { get; set; }
        /// <summary>
        /// Gets or sets the version number.
        /// </summary>
        /// <value>
        /// The version number.
        /// </value>
        public decimal? VersionNumber { get; set; }
        /// <summary>
        /// Gets or sets the categories.
        /// </summary>
        /// <value>
        /// The categories.
        /// </value>
        public List<string> Categories { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is default.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is default; otherwise, <c>false</c>.
        /// </value>
        public bool IsDefault { get; set; }
        /// <summary>
        /// Gets or sets the question list.
        /// </summary>
        /// <value>
        /// The question list.
        /// </value>
        public List<VettingTitleLibraryDetails> QuestionList { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is draft.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is draft; otherwise, <c>false</c>.
        /// </value>
        public bool IsDraft { get; set; }
        /// <summary>
        /// Gets or sets the submitted date.
        /// </summary>
        /// <value>
        /// The submitted date.
        /// </value>
        public DateTime? SubmittedDate { get; set; }
        /// <summary>
        /// Gets or sets the submitted by.
        /// </summary>
        /// <value>
        /// The submitted by.
        /// </value>
        public string SubmittedBy { get; set; }
        /// <summary>
        /// Gets or sets the submitted by role identifier.
        /// </summary>
        /// <value>
        /// The submitted by role identifier.
        /// </value>
        public string SubmittedByRoleId { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }
    }
}
