﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// class MDMCompanyNoteRequest
	/// </summary>
	public class MDMCompanyNoteRequest
	{
		/// <summary>
		/// Gets or sets the vetting request identifier.
		/// </summary>
		/// <value>
		/// The vetting request identifier.
		/// </value>
		public string VettingRequestId { get; set; }
		/// <summary>
		/// Gets or sets the CMP identifier.
		/// </summary>
		/// <value>
		/// The CMP identifier.
		/// </value>
		public string CmpId { get; set; }
		/// <summary>
		/// Gets or sets the vix identifier.
		/// </summary>
		/// <value>
		/// The vix identifier.
		/// </value>
		public string VixId { get; set; }
		/// <summary>
		/// Gets or sets the note identifier.
		/// </summary>
		/// <value>
		/// The note identifier.
		/// </value>
		public string NoteIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the notes descrption.
        /// </summary>
        /// <value>
        /// The notes descrption.
        /// </value>
        public string NotesDescrption { get; set; }
    }
}
