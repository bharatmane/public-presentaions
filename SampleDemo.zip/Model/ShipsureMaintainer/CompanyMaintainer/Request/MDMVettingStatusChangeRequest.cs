﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class MDMVettingStatusChangeRequest
    /// </summary>
    public class MDMVettingStatusChangeRequest
	{
        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
        /// <summary>
        /// Gets or sets the vix identifier.
        /// </summary>
        /// <value>
        /// The vix identifier.
        /// </value>
        public string VixId { get; set; }
        /// <summary>
        /// Gets or sets the reject reason.
        /// </summary>
        /// <value>
        /// The reject reason.
        /// </value>
        public string RejectReason { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is rejected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is rejected; otherwise, <c>false</c>.
        /// </value>
        public bool IsRejected { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is return to vix.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is return to vix; otherwise, <c>false</c>.
        /// </value>
        public bool IsReturnToVix { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is submit for vetting.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is submit for vetting; otherwise, <c>false</c>.
        /// </value>
        public bool IsSubmitForVetting { get; set; }
        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }
        /// <summary>
        /// Gets or sets the template identifier.
        /// </summary>
        /// <value>
        /// The template identifier.
        /// </value>
        public string TemplateId { get; set; }

        /// <summary>
        /// Gets or sets the role identifier.
        /// </summary>
        /// <value>
        /// The role identifier.
        /// </value>
        public string RoleIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the display name of the user.
        /// </summary>
        /// <value>
        /// The display name of the user.
        /// </value>
        public string UserDisplayName { get; set; }
    }
}
