﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	///  class VettingTemplateFilterRequest
	/// </summary>
	public class VettingTemplateFilterRequest
	{
		/// <summary>
		/// Gets or sets the is active.
		/// </summary>
		/// <value>
		/// The is active.
		/// </value>
		public bool? IsActive { get; set; }
	}
}
