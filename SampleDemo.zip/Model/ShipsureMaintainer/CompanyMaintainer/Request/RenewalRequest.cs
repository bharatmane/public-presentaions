﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// class RenewalRequest
	/// </summary>
	public class RenewalRequest
	{
		/// <summary>
		/// Gets or sets the CMP identifier.
		/// </summary>
		/// <value>
		/// The CMP identifier.
		/// </value>
		public string CmpId { get; set; }

		/// <summary>
		/// Gets or sets the start date.
		/// </summary>
		/// <value>
		/// The start date.
		/// </value>
		public DateTime StartDate { get; set; }

		/// <summary>
		/// Gets or sets the day count.
		/// </summary>
		/// <value>
		/// The day count.
		/// </value>
		public int? DayCount { get; set; }
	}
}
