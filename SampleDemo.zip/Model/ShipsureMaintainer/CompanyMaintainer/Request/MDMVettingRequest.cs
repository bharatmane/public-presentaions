﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// class MDMVettingRequest
	/// </summary>
	public class MDMVettingRequest
	{
		/// <summary>
		/// Gets or sets the vetting request identifier.
		/// </summary>
		/// <value>
		/// The vetting request identifier.
		/// </value>
		public string VettingRequestId { get; set; }
		/// <summary>
		/// Gets or sets the CMP identifier.
		/// </summary>
		/// <value>
		/// The CMP identifier.
		/// </value>
		public string CmpId { get; set; }
		/// <summary>
		/// Gets or sets the vix identifier.
		/// </summary>
		/// <value>
		/// The vix identifier.
		/// </value>
		public string VixId { get; set; }
	}
}
