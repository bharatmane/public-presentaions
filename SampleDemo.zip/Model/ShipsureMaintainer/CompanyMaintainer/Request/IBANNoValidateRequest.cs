﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// IBANNoValidateRequest
    /// </summary>
    public class IBANNoValidateRequest
    {
        /// <summary>
        /// Gets or sets the request source identifier.
        /// </summary>
        /// <value>
        /// The request source identifier.
        /// </value>
        public string RequestSource { get; set; }

        /// <summary>
        /// Gets or sets the request source table.
        /// </summary>
        /// <value>
        /// The request source table.
        /// </value>
        public string RequestSourceTable { get; set; }

        /// <summary>
        /// Gets or sets the iban no.
        /// </summary>
        /// <value>
        /// The iban no.
        /// </value>
        public string IBANNo { get; set; }

        /// <summary>
        /// Gets or sets the request source matched identifier.
        /// </summary>
        /// <value>
        /// The request source matched identifier.
        /// </value>
        public string RequestSourceMatchedId { get; set; }
    }
}
