﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// VettingTitleApprovalDetailsRequest
	/// </summary>
	public class VettingTitleApprovalDetailsRequest
	{
		/// <summary>
		/// Gets or sets the vetting request identifier.
		/// </summary>
		/// <value>
		/// The vetting request identifier.
		/// </value>
		public string VettingRequestId { get; set; }
		/// <summary>
		/// Gets or sets the CVT ids.
		/// </summary>
		/// <value>
		/// The CVT ids.
		/// </value>
		public List<string> CvtIds { get; set; }
	}
}
