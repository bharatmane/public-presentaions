﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// 
    /// </summary>
    public class VettingTitleDetailsForRenewalsRequest
    {
        /// <summary>
        /// Gets or sets the renewal start date.
        /// </summary>
        /// <value>
        /// The renewal start date.
        /// </value>
        public DateTime? RenewalStartDate { get; set; }

        /// <summary>
        /// Gets or sets the renewal end date.
        /// </summary>
        /// <value>
        /// The renewal end date.
        /// </value>
        public DateTime? RenewalEndDate { get; set; }

        /// <summary>
        /// Gets or sets the show overdue.
        /// </summary>
        /// <value>
        /// The show overdue.
        /// </value>
        public bool? ShowOverdue { get; set; }

        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int? RenewalDays { get; set; }

        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }

        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId { get; set; }
    }
}
