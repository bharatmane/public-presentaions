﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// 
	/// </summary>
	public class CompanyVettingSearchRequest
	{
		/// <summary>
		/// Gets or sets the company identifier.
		/// </summary>
		/// <value>
		/// The company identifier.
		/// </value>
		public string CompanyId { get; set; }
	}
}
