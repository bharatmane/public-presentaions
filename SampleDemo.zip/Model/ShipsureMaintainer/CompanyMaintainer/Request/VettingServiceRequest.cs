﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// 
    /// </summary>
    public class VettingServiceRequest
    {
        /// <summary>
        /// Gets or sets the vetting category identifier.
        /// </summary>
        /// <value>
        /// The vetting category identifier.
        /// </value>
        public string VettingCategoryId { get; set; }
        /// <summary>
        /// Gets or sets the vetting category service identifier.
        /// </summary>
        /// <value>
        /// The vetting category service identifier.
        /// </value>
        public string VettingCategoryServiceId { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is activate.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is activate; otherwise, <c>false</c>.
        /// </value>
        public bool IsActivate { get; set; }
    }
}
