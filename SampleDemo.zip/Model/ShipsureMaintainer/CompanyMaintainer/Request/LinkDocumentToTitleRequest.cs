﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
	/// <summary>
	/// LinkDocumentToTitleRequest
	/// </summary>
	public class LinkDocumentToTitleRequest
    {
        /// <summary>
        /// Gets or sets the document metadata identifier.
        /// </summary>
        /// <value>
        /// The document metadata identifier.
        /// </value>
        public List<string> DocumentMetadataId { get; set; }

        /// <summary>
        /// Gets or sets the company vetting title identifier.
        /// </summary>
        /// <value>
        /// The company vetting title identifier.
        /// </value>
        public string CompanyVettingTitleId { get; set; }
    }
}
