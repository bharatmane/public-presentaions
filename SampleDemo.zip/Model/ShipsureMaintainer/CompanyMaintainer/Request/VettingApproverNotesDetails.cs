﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer.Request
{
    /// <summary>
    /// class VettingApproverNotesDetails
    /// </summary>
    public class VettingApproverNotesDetails
	{
        /// <summary>
        /// Gets or sets the note identifier.
        /// </summary>
        /// <value>
        /// The note identifier.
        /// </value>
        public string NoteIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the note description.
        /// </summary>
        /// <value>
        /// The note description.
        /// </value>
        public string NoteDescription { get; set; }
        /// <summary>
        /// Gets or sets the CVT identifier.
        /// </summary>
        /// <value>
        /// The CVT identifier.
        /// </value>
        public string CvtId { get; set; }
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserId { get; set; }
        /// <summary>
        /// Gets or sets the display name of the user.
        /// </summary>
        /// <value>
        /// The display name of the user.
        /// </value>
        public string UserDisplayName { get; set; }
        /// <summary>
        /// Gets or sets the note created date.
        /// </summary>
        /// <value>
        /// The note created date.
        /// </value>
        public DateTime? NoteCreatedDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is edit visible.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is edit visible; otherwise, <c>false</c>.
        /// </value>
        public bool IsEditVisible { get; set; }

		/// <summary>
		/// Gets or sets the note updated date.
		/// </summary>
		/// <value>
		/// The note updated date.
		/// </value>
		public DateTime? NoteUpdatedDate { get; set; }
    }
}
