﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class RelatedCompanyResponse
    /// </summary>
    public class RelatedCompanyResponse
    {
        /// <summary>
        /// Gets or sets the CompanyId
        /// </summary>
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets the CompanyName
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// Gets or sets the ParentCompany
        /// </summary>
        public RelatedCompanyResponse ParentCompany { get; set; }

        /// <summary>
        /// Gets or sets the ChildrenCompanies
        /// </summary>
        public List<RelatedCompanyResponse> ChildrenCompanies { get; set; }

        /// <summary>
        /// Gets or sets the CompanyName
        /// </summary>
        public string Country { get; set; }

        /// <summary>
		/// Gets or sets the Address
		/// </summary>
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the  CoyId
        /// </summary>
        public string CoyId { get; set; }

        /// <summary>
        /// Gets or sets the CompanyName
        /// </summary>
        public string Type { get; set; }

    }
}
