﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingApproverDetails
    /// </summary>
    public class VettingApproverDetails:BaseViewModel
	{
        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }
        /// <summary>
        /// Gets or sets the vetting title identifier.
        /// </summary>
        /// <value>
        /// The vetting title identifier.
        /// </value>
        public string VettingTitleId { get; set; }
        /// <summary>
        /// Gets or sets the name of the vetting title.
        /// </summary>
        /// <value>
        /// The name of the vetting title.
        /// </value>
        public string VettingTitleName { get; set; }
        /// <summary>
        /// Gets or sets the vetting title description.
        /// </summary>
        /// <value>
        /// The vetting title description.
        /// </value>
        public string VettingTitleDescription { get; set; }

        /// <summary>
        /// The vetting title status identifier
        /// </summary>
        private string _vettingTitleStatusId;
        /// <summary>
        /// Gets or sets the vetting title status identifier.
        /// </summary>
        /// <value>
        /// The vetting title status identifier.
        /// </value>
        public string VettingTitleStatusId 
        {
            get { return _vettingTitleStatusId; }
            set { Set(() => VettingTitleStatusId, ref _vettingTitleStatusId, value); }
        }

        /// <summary>
        /// The vetting title status description
        /// </summary>
        private string _vettingTitleStatusDescription;
        /// <summary>
        /// Gets or sets the vetting title status description.
        /// </summary>
        /// <value>
        /// The vetting title status description.
        /// </value>
        public string VettingTitleStatusDescription 
        {
            get { return _vettingTitleStatusDescription; } 
            set { Set(() => VettingTitleStatusDescription, ref _vettingTitleStatusDescription, value); }
        }

        private string _vettingTitleStatusShortCode;
        /// <summary>
        /// Gets or sets the vetting title status short code.
        /// </summary>
        /// <value>
        /// The vetting title status short code.
        /// </value>
        public string VettingTitleStatusShortCode 
        { 
            get { return _vettingTitleStatusShortCode; }
            set { Set(() => VettingTitleStatusShortCode, ref _vettingTitleStatusShortCode, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time check required.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time check required; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeCheckRequired { get; set; }
        /// <summary>
        /// Gets or sets the vetting due date.
        /// </summary>
        /// <value>
        /// The vetting due date.
        /// </value>
        public DateTime? VettingDueDate { get; set; }
        /// <summary>
        /// Gets or sets the frequency.
        /// </summary>
        /// <value>
        /// The frequency.
        /// </value>
        public int? Frequency { get; set; }
        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int? RenewalDays { get; set; }
        /// <summary>
        /// Gets or sets the first approver responsibility.
        /// </summary>
        /// <value>
        /// The first approver responsibility.
        /// </value>
        public string FirstApproverResponsibility { get; set; }
        /// <summary>
        /// Gets or sets the first approver user identifier.
        /// </summary>
        /// <value>
        /// The first approver user identifier.
        /// </value>
        public string FirstApproverUserId { get; set; }
        /// <summary>
        /// Gets or sets the first name of the approver user.
        /// </summary>
        /// <value>
        /// The first name of the approver user.
        /// </value>
        public string FirstApproverUserName { get; set; }
        /// <summary>
        /// Gets or sets the second approver responsibility.
        /// </summary>
        /// <value>
        /// The second approver responsibility.
        /// </value>
        public string SecondApproverResponsibility { get; set; }
        /// <summary>
        /// Gets or sets the second approver user identifier.
        /// </summary>
        /// <value>
        /// The second approver user identifier.
        /// </value>
        public string SecondApproverUserId { get; set; }
        /// <summary>
        /// Gets or sets the name of the second approver user.
        /// </summary>
        /// <value>
        /// The name of the second approver user.
        /// </value>
        public string SecondApproverUserName { get; set; }
        /// <summary>
        /// Gets or sets the current approver role identifier.
        /// </summary>
        /// <value>
        /// The current approver role identifier.
        /// </value>
        public string CurrentApproverRoleId { get; set; }
        /// <summary>
        /// Gets or sets the current approver responsibility.
        /// </summary>
        /// <value>
        /// The current approver responsibility.
        /// </value>
        public string CurrentApproverRoleName { get; set; }
		/// <summary>
		/// Gets or sets the current approver user identifier.
		/// </summary>
		/// <value>
		/// The current approver user identifier.
		/// </value>
		public string CurrentApproverUserId { get; set; }
		/// <summary>
		/// Gets or sets the name of the current approver user.
		/// </summary>
		/// <value>
		/// The name of the current approver user.
		/// </value>
		public string CurrentApproverUserName { get; set; }
		/// <summary>
		/// Gets or sets the current apporval date.
		/// </summary>
		/// <value>
		/// The current apporval date.
		/// </value>
		public DateTime? CurrentApporvalDate { get; set; }


		/// <summary>
		/// Gets or sets the past approver role identifier.
		/// </summary>
		/// <value>
		/// The past approver role identifier.
		/// </value>
		public string PastApproverRoleId { get; set; }

		/// <summary>
		/// Gets or sets the name of the past approver role.
		/// </summary>
		/// <value>
		/// The name of the past approver role.
		/// </value>
		public string PastApproverRoleName { get; set; }

		/// <summary>
		/// Gets or sets the past approver user identifier.
		/// </summary>
		/// <value>
		/// The past approver user identifier.
		/// </value>
		public string PastApproverUserId { get; set; }

		/// <summary>
		/// Gets or sets the name of the past approver user.
		/// </summary>
		/// <value>
		/// The name of the past approver user.
		/// </value>
		public string PastApproverUserName { get; set; }

		/// <summary>
		/// Gets or sets the past apporval date.
		/// </summary>
		/// <value>
		/// The past apporval date.
		/// </value>
		public DateTime? PastApporvalDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is title marked as pass.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is title marked as pass; otherwise, <c>false</c>.
        /// </value>
        public bool IsTitleMarkedAsPass { get; set; }
        /// <summary>
        /// Gets or sets the first apporval date.
        /// </summary>
        /// <value>
        /// The first apporval date.
        /// </value>
        public DateTime? FirstApporvalDate { get; set; }
        /// <summary>
        /// Gets or sets the second apporval date.
        /// </summary>
        /// <value>
        /// The second apporval date.
        /// </value>
        public DateTime? SecondApporvalDate { get; set; }
        /// <summary>
        /// Gets or sets the cva identifier.
        /// </summary>
        /// <value>
        /// The cva identifier.
        /// </value>
        public string CvaId { get; set; } // title action id

        /// <summary>
        /// Gets or sets a value indicating whether [past approval details exists].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [past approval details exists]; otherwise, <c>false</c>.
        /// </value>
        public bool PastApprovalDetailsExists 
        { 
            get { return !string.IsNullOrEmpty(PastApproverUserId); } 
        }

        /// <summary>
        /// Gets or sets the past approver docs count.
        /// </summary>
        /// <value>
        /// The past approver docs count.
        /// </value>
        public int PastApproverDocsCount { get; set; }

        /// <summary>
        /// Gets or sets the past approver notes.
        /// </summary>
        /// <value>
        /// The past approver notes.
        /// </value>
        public string PastApproverNotes { get; set; }
        /// <summary>
        /// The notes
        /// </summary>
        private string _notes;

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes
        {
            get { return _notes; }
            set { Set(() => Notes, ref _notes, value); }
        }

		/// <summary>
		/// Gets or sets the current approver note identifier.
		/// </summary>
		/// <value>
		/// The current approver note identifier.
		/// </value>
		public string CurrentApproverNoteId { get; set; }
		/// <summary>
		/// Gets or sets the current approver note description.
		/// </summary>
		/// <value>
		/// The current approver note description.
		/// </value>
		public string CurrentApproverNoteDescription { get; set; }
		/// <summary>
		/// Gets or sets the past approver note identifier.
		/// </summary>
		/// <value>
		/// The past approver note identifier.
		/// </value>
		public string PastApproverNoteId { get; set; }
		/// <summary>
		/// Gets or sets the past approver note description.
		/// </summary>
		/// <value>
		/// The past approver note description.
		/// </value>
		public string PastApproverNoteDescription { get; set; }

        /// <summary>
        /// Gets or sets the first approver role identifier.
        /// </summary>
        /// <value>
        /// The first approver role identifier.
        /// </value>
        public string FirstApproverRoleId { get; set; }
        /// <summary>
        /// Gets or sets the second approver role identifier.
        /// </summary>
        /// <value>
        /// The second approver role identifier.
        /// </value>
        public string SecondApproverRoleId { get; set; }

        /// <summary>
        /// Gets or sets the vetting question identifier.
        /// </summary>
        /// <value>
        /// The vetting question identifier.
        /// </value>
        public string VettingQuestionId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is required only one approval.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is required only one approval; otherwise, <c>false</c>.
        /// </value>
        public bool IsRequiredOnlyOneApproval { get; set; }

        /// <summary>
        /// Gets or sets the current level.
        /// </summary>
        /// <value>
        /// The current level.
        /// </value>
        public int? CurrentLevel { get; set; }

        /// <summary>
        /// Gets or sets the second approver cva identifier.
        /// </summary>
        /// <value>
        /// The second approver cva identifier.
        /// </value>
        public string SecondApproverCvaId { get; set; }

        /// <summary>
        /// Gets or sets the first approver cva identifier.
        /// </summary>
        /// <value>
        /// The first approver cva identifier.
        /// </value>
        public string FirstApproverCvaId { get; set; }

		/// <summary>
		/// Gets or sets the vetting approver status.
		/// </summary>
		/// <value>
		/// The vetting approver status.
		/// </value>
		public string VettingApproverStatus { get; set; }
		/// <summary>
		/// Gets or sets the current user action is pass.
		/// </summary>
		/// <value>
		/// The current user action is pass.
		/// </value>
		public bool? CurrentUserActionIsPass { get; set; }
		/// <summary>
		/// Gets or sets the past user action is pass.
		/// </summary>
		/// <value>
		/// The past user action is pass.
		/// </value>
		public bool? PastUserActionIsPass { get; set; }

		/// <summary>
		/// Gets or sets the past approver level.
		/// </summary>
		/// <value>
		/// The past approver level.
		/// </value>
		public int? PastApproverLevel { get; set; }
		/// <summary>
		/// Gets or sets the current approver level.
		/// </summary>
		/// <value>
		/// The current approver level.
		/// </value>
		public int? CurrentApproverLevel { get; set; }
		/// <summary>
		/// Gets or sets the current approver reject reason.
		/// </summary>
		/// <value>
		/// The current approver reject reason.
		/// </value>
		public string CurrentApproverRejectReason { get; set; }
		/// <summary>
		/// Gets or sets the past approver reject reason.
		/// </summary>
		/// <value>
		/// The past approver reject reason.
		/// </value>
		public string PastApproverRejectReason { get; set; }

        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string VtlId { get; set; }

        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is document required.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is document required; otherwise, <c>false</c>.
		/// </value>
		public bool IsDocumentRequired { get; set; }

		/// <summary>
		/// Gets or sets the attachment counts.
		/// </summary>
		/// <value>
		/// The attachment counts.
		/// </value>
		public int AttachmentCount { get; set; }

        #region Properties Used to show Sign off details on Approver page in case on Fail Vetting
        /// <summary>
        /// Gets or sets the sign off user identifier.
        /// </summary>
        /// <value>
        /// The sign off user identifier.
        /// </value>
        public string SignOffUserId { get; set; }
		/// <summary>
		/// Gets or sets the name of the sign off user.
		/// </summary>
		/// <value>
		/// The name of the sign off user.
		/// </value>
		public string SignOffUserName { get; set; }
		/// <summary>
		/// Gets or sets the sign off user role description.
		/// </summary>
		/// <value>
		/// The sign off user role description.
		/// </value>
		public string SignOffUserRoleDescription { get; set; }
		/// <summary>
		/// Gets or sets the sign off status description.
		/// </summary>
		/// <value>
		/// The sign off status description.
		/// </value>
		public string SignOffStatusDescription { get; set; }
		/// <summary>
		/// Gets or sets the sign off reject reason.
		/// </summary>
		/// <value>
		/// The sign off reject reason.
		/// </value>
		public string SignOffRejectReason { get; set; }
		/// <summary>
		/// Gets or sets the sign off user notes.
		/// </summary>
		/// <value>
		/// The sign off user notes.
		/// </value>
		public string SignOffUserNotes { get; set; }
		/// <summary>
		/// Gets or sets the sign off user action date.
		/// </summary>
		/// <value>
		/// The sign off user action date.
		/// </value>
		public DateTime? SignOffUserActionDate { get; set; }
		#endregion

		#region For Vetting Sign off Approver
		/// <summary>
		/// Gets or sets the approver identifier.
		/// </summary>
		/// <value>
		/// The approver identifier.
		/// </value>
		public string ApproverId { get; set; }
        /// <summary>
        /// Gets or sets the approver.
        /// </summary>
        /// <value>
        /// The approver.
        /// </value>
        public string Approver { get; set; }
        /// <summary>
        /// Gets or sets the approver role identifier.
        /// </summary>
        /// <value>
        /// The approver role identifier.
        /// </value>
        public string ApproverRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the approver role description.
        /// </summary>
        /// <value>
        /// The approver role description.
        /// </value>
        public string ApproverRoleDescription { get; set; }
        /// <summary>
        /// Gets or sets the approver status description.
        /// </summary>
        /// <value>
        /// The approver status description.
        /// </value>
        public string ApproverStatusDescription { get; set; }
        /// <summary>
        /// Gets or sets the approver date.
        /// </summary>
        /// <value>
        /// The approver date.
        /// </value>
        public DateTime? ApproverDate { get; set; }
        /// <summary>
        /// Gets or sets the approver status status short code.
        /// </summary>
        /// <value>
        /// The approver status status short code.
        /// </value>
        public string ApproverStatusStatusShortCode { get; set; }
        #endregion
    }
}
