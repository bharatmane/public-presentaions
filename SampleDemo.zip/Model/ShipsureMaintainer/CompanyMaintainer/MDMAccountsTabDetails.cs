﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// 
    /// </summary>
    public class MDMAccountsTabDetails : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the name of the bank.
        /// </summary>
        /// <value>
        /// The name of the bank.
        /// </value>
        public string BankName { get; set; }
        /// <summary>
        /// Gets or sets the name of the beneficiary.
        /// </summary>
        /// <value>
        /// The name of the beneficiary.
        /// </value>
        public string BeneficiaryName { get; set; }
        /// <summary>
        /// Gets or sets the account number.
        /// </summary>
        /// <value>
        /// The account number.
        /// </value>
        public string AccountNumber { get; set; }
        /// <summary>
        /// Gets or sets the current identifier.
        /// </summary>
        /// <value>
        /// The current identifier.
        /// </value>
        public string CurId { get; set; }
        /// <summary>
        /// Gets or sets the sort code.
        /// </summary>
        /// <value>
        /// The sort code.
        /// </value>
        public string SortCode { get; set; }
        /// <summary>
        /// Gets or sets the swift code.
        /// </summary>
        /// <value>
        /// The swift code.
        /// </value>
        public string SwiftCode { get; set; }
        /// <summary>
        /// Gets or sets the iban.
        /// </summary>
        /// <value>
        /// The iban.
        /// </value>
        public string IBAN { get; set; }
        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address { get; set; }
        /// <summary>
        /// Gets or sets the town.
        /// </summary>
        /// <value>
        /// The town.
        /// </value>
        public string Town { get; set; }
        /// <summary>
        /// Gets or sets the post code.
        /// </summary>
        /// <value>
        /// The post code.
        /// </value>
        public string PostCode { get; set; }
        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the name of the iban validation status.
        /// </summary>
        /// <value>
        /// The name of the iban validation status.
        /// </value>
        public string IBANValidationStatusName { get; set; }

        /// <summary>
        /// Gets or sets the iban validation status identifier.
        /// </summary>
        /// <value>
        /// The iban validation status identifier.
        /// </value>
        public string IBANValidationStatusID { get; set; }

        /// <summary>
        /// Gets or sets the iban request history identifier.
        /// </summary>
        /// <value>
        /// The iban request history identifier.
        /// </value>
        public string IBANRequestHistoryId { get; set; }

        /// <summary>
        /// The bank group
        /// </summary>
        private BankGroupDescriptorData _bankGroup;

        /// <summary>
        /// Gets or sets the bank group.
        /// </summary>
        /// <value>
        /// The bank group.
        /// </value>
        public BankGroupDescriptorData BankGroup
        {
            get { return _bankGroup; }
            set { Set(()=>BankGroup, ref _bankGroup , value); }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MDMAccountsTabDetails"/> class.
        /// </summary>
        public MDMAccountsTabDetails()
        {
            BankGroup = new BankGroupDescriptorData() { 
                BankName = BankName,
                AddressTownPostCodeCountry = Address + ", " + Town + ", " + PostCode +
                                         ", " + Country
            };
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class BankGroupDescriptorData : BaseViewModel
    {
        /// <summary>
        /// The country list
        /// </summary>
        private string _bankName;
        /// <summary>
        /// Gets or sets the country list.
        /// </summary>
        /// <value>
        /// The country list.
        /// </value>
        public string BankName
        {
            get { return _bankName; }
            set { Set(() => BankName, ref _bankName, value); }
        }

        /// <summary>
        /// The country list
        /// </summary>
        private string _addressTownPostCodeCountry;
        /// <summary>
        /// Gets or sets the country list.
        /// </summary>
        /// <value>
        /// The country list.
        /// </value>
        public string AddressTownPostCodeCountry
        {
            get { return _addressTownPostCodeCountry; }
            set { Set(() => AddressTownPostCodeCountry, ref _addressTownPostCodeCountry, value); }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BankGroupDescriptorData"/> class.
        /// </summary>
        /// <param name="bankDetail">The bankDetail.</param>
        //public BankGroupDescriptorData(MDMAccountsTabDetails bankDetail)
        //{
        //    BankName = bankDetail.BankName;
        //    AddressTownPostCodeCountry = bankDetail.Address + ", " + bankDetail.Town + ", " + bankDetail.PostCode +
        //                                 ", " + bankDetail.Country;
        //}
    }
}
