﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// VettingDocumentTypeList
    /// </summary>
    public class VettingDocumentTypeList
    {
        /// <summary>
        /// Gets or sets the VDT identifier.
        /// </summary>
        /// <value>
        /// The VDT identifier.
        /// </value>
        public string VDT_ID { get; set; }
        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public string Type { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the issue date required.
        /// </summary>
        /// <value>
        /// The issue date required.
        /// </value>
        public bool? IssueDateRequired { get; set; }
        /// <summary>
        /// Gets or sets the expired date required.
        /// </summary>
        /// <value>
        /// The expired date required.
        /// </value>
        public bool? ExpiredDateRequired { get; set; }

        /// <summary>
        /// Gets or sets the is document upload required.
        /// </summary>
        /// <value>
        /// The is document upload required.
        /// </value>
        public bool? IsDocUploadRequired { get; set; }

    }
}
