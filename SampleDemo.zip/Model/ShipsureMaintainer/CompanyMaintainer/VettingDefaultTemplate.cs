﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class VettingDefaultTemplate
	/// </summary>
	public class VettingDefaultTemplate
	{
		/// <summary>
		/// Gets or sets the template identifier.
		/// </summary>
		/// <value>
		/// The template identifier.
		/// </value>
		public string TemplateId { get; set; }
		/// <summary>
		/// Gets or sets the name of the template.
		/// </summary>
		/// <value>
		/// The name of the template.
		/// </value>
		public string TemplateName { get; set; }
		/// <summary>
		/// Gets or sets a value indicating whether this instance is default.
		/// </summary>
		/// <value>
		/// <c>true</c> if this instance is default; otherwise, <c>false</c>.
		/// </value>
		public bool IsDefault { get; set; }
	}
}
