﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// class CompanyCertificateDocumentDetail
	/// </summary>
	public class CompanyCertificateDocumentDetail
	{
        /// <summary>
        /// Gets or sets the cce identifier.
        /// </summary>
        /// <value>
        /// The cce identifier.
        /// </value>
        public string CceId { get; set; }

        /// <summary>
        /// Gets or sets the name of the certificate.
        /// </summary>
        /// <value>
        /// The name of the certificate.
        /// </value>
        public string CertificateName { get; set; }

        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }

        /// <summary>
        /// Gets or sets the DCT identifier.
        /// </summary>
        /// <value>
        /// The DCT identifier.
        /// </value>
        public string DctId { get; set; }

        /// <summary>
        /// Gets or sets the name of the document category.
        /// </summary>
        /// <value>
        /// The name of the document category.
        /// </value>
        public string DocCategoryName { get; set; }

        /// <summary>
        /// Gets or sets the ett identifier.
        /// </summary>
        /// <value>
        /// The ett identifier.
        /// </value>
        public string EttId { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is deleted; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets the uploaded on.
        /// </summary>
        /// <value>
        /// The uploaded on.
        /// </value>
        public DateTime? UploadedOn { get; set; }

        /// <summary>
        /// Gets or sets the THB identifier.
        /// </summary>
        /// <value>
        /// The THB identifier.
        /// </value>
        public string ThbId { get; set; }

        /// <summary>
        /// Gets or sets the etx identifier.
        /// </summary>
        /// <value>
        /// The etx identifier.
        /// </value>
        public string EtxId { get; set; }
    }
}
