﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class VettingApproverSummary
    /// </summary>
    public class VettingApproverSummary:BaseViewModel
	{
		/// <summary>
		/// The CMP identifier
		/// </summary>
		private string _cmpId;

        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId 
        {
            get { return _cmpId; }
            set { Set(() => CmpId, ref _cmpId, value); }
        }

        /// <summary>
        /// The company name
        /// </summary>
        private string _companyName;

        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>
        /// The name of the company.
        /// </value>
        public string CompanyName
		{
            get { return _companyName; }
            set { Set(() => CompanyName, ref _companyName, value); }
        }

		/// <summary>
		/// The vetting request identifier
		/// </summary>
		private string _vettingRequestId;

        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId 
        {
            get { return _vettingRequestId; }
            set { Set(() => VettingRequestId, ref _vettingRequestId, value); }
        }

        /// <summary>
        /// The vetting status identifier
        /// </summary>
        private string _vettingStatusId;

        /// <summary>
        /// Gets or sets the vetting status identifier.
        /// </summary>
        /// <value>
        /// The vetting status identifier.
        /// </value>
        public string VettingStatusId 
        {
            get { return _vettingStatusId; } 
            set { Set(() => VettingStatusId, ref _vettingStatusId, value); } 
        }


        /// <summary>
        /// The vetting status description
        /// </summary>
        private string _vettingStatusDescription;

        /// <summary>
        /// Gets or sets the vetting status description.
        /// </summary>
        /// <value>
        /// The vetting status description.
        /// </value>
        public string VettingStatusDescription
        {
            get { return _vettingStatusDescription; }
            set { Set(() => VettingStatusDescription, ref _vettingStatusDescription, value); }
        }

        /// <summary>
        /// The vetting status short code
        /// </summary>
        private string _vettingStatusShortCode;

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode 
        {
            get { return _vettingStatusShortCode; }
            set { Set(() => VettingStatusShortCode, ref _vettingStatusShortCode, value); }
        }

        /// <summary>
        /// The vetting company failed short code
        /// </summary>
        private string _vettingCompanyFailedShortCode;

        /// <summary>
        /// Gets or sets the vetting company failed short code.
        /// </summary>
        /// <value>
        /// The vetting company failed short code.
        /// </value>
        public string VettingCompanyFailedShortCode 
        {
            get { return _vettingCompanyFailedShortCode; }
            set { Set(() => VettingCompanyFailedShortCode, ref _vettingCompanyFailedShortCode, value); }
        }

        /// <summary>
        /// The renewal date
        /// </summary>
        private DateTime? _renewalDate;

        /// <summary>
        /// Gets or sets the renewal data.
        /// </summary>
        /// <value>
        /// The renewal data.
        /// </value>
        public DateTime? RenewalDate 
        {
            get { return _renewalDate; }
            set { Set(() => RenewalDate, ref _renewalDate, value); }
        }

        /// <summary>
        /// The is vetting has failed title
        /// </summary>
        private bool _isVettingHasFailedTitle;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is vetting has failed title.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is vetting has failed title; otherwise, <c>false</c>.
        /// </value>
        public bool IsVettingHasFailedTitle 
        {
            get { return _isVettingHasFailedTitle; }
            set { Set(() => IsVettingHasFailedTitle, ref _isVettingHasFailedTitle, value); } 
        }

        /// <summary>
        /// The company request type
        /// </summary>
        private string _companyRequestType;

        /// <summary>
        /// Gets or sets the type of the company request.
        /// </summary>
        /// <value>
        /// The type of the company request.
        /// </value>
        public string CompanyRequestType 
        {
            get { return _companyRequestType; }
            set { Set(() => CompanyRequestType, ref _companyRequestType, value); }
        }

        /// <summary>
        /// The vetting company failed short code description
        /// </summary>
        private string _vettingCompanyFailedShortCodeDescription;

        /// <summary>
        /// Gets or sets the vetting company failed short code description.
        /// </summary>
        /// <value>
        /// The vetting company failed short code description.
        /// </value>
        public string VettingCompanyFailedShortCodeDescription 
        {
            get { return _vettingCompanyFailedShortCodeDescription; }
            set { Set(() => VettingCompanyFailedShortCodeDescription, ref _vettingCompanyFailedShortCodeDescription, value); }
        }

        /// <summary>
        /// The vetting request type
        /// </summary>
        private string _vettingRequestType;

        /// <summary>
        /// Gets or sets the type of the vetting request.
        /// </summary>
        /// <value>
        /// The type of the vetting request.
        /// </value>
        public string VettingRequestType 
        {
            get { return _vettingRequestType; }
            set { Set(() => VettingRequestType, ref _vettingRequestType, value); }
        }

        /// <summary>
        /// The is one time supplier
        /// </summary>
        private bool _isOneTimeSupplier;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time supplier.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time supplier; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeSupplier 
        {
            get { return _isOneTimeSupplier; }
            set { Set(() => IsOneTimeSupplier, ref _isOneTimeSupplier, value); }
        }


        /// <summary>
        /// The updated by
        /// </summary>
        private string _updatedBy;

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy 
        {
            get { return _updatedBy; }
            set { Set(() => UpdatedBy, ref _updatedBy, value); }
        }
    }
}
