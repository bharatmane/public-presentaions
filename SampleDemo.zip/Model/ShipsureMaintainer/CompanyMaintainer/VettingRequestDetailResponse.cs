﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
	/// <summary>
	/// VettingRequestDetailResponse
	/// </summary>
	public class VettingRequestDetailResponse
    {
        /// <summary>
        /// Gets or sets the vr identifier.
        /// </summary>
        /// <value>
        /// The vr identifier.
        /// </value>
        public string VR_ID { get; set; }

        /// <summary>
        /// Gets or sets the vetting status identifier.
        /// </summary>
        /// <value>
        /// The vetting status identifier.
        /// </value>
        public string VettingStatusId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vetting status.
        /// </summary>
        /// <value>
        /// The name of the vetting status.
        /// </value>
        public string VettingStatusName { get; set; }

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the vetting services.
        /// </summary>
        /// <value>
        /// The vetting services.
        /// </value>
        public List<string> VettingServices { get; set; }

        /// <summary>
        /// Gets or sets the vetting templates.
        /// </summary>
        /// <value>
        /// The vetting templates.
        /// </value>
        public List<string> VettingTemplates { get; set; }

		/// <summary>
		/// Gets or sets the assigned to.
		/// </summary>
		/// <value>
		/// The assigned to.
		/// </value>
		public List<string> AssignedTo { get; set; }
        /// <summary>
        /// Gets or sets the vetting status history.
        /// </summary>
        /// <value>
        /// The vetting status history.
        /// </value>
        public List<VettingRequestStatusHistory> VettingStatusHistory { get; set; }
    }

    /// <summary>
    /// VettingRequestStatusHistory
    /// </summary>
    public class VettingRequestStatusHistory
    {
        /// <summary>
        /// Gets or sets the vetting status identifier.
        /// </summary>
        /// <value>
        /// The vetting status identifier.
        /// </value>
        public string VettingStatusId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vetting status.
        /// </summary>
        /// <value>
        /// The name of the vetting status.
        /// </value>
        public string VettingStatusName { get; set; }

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the vetting status date.
        /// </summary>
        /// <value>
        /// The vetting status date.
        /// </value>
        public DateTime? VettingStatusDate { get; set; }

        /// <summary>
        /// Gets or sets the vetting status by.
        /// </summary>
        /// <value>
        /// The vetting status by.
        /// </value>
        public string VettingStatusBy { get; set; }

        /// <summary>
        /// Gets or sets the idle since days.
        /// </summary>
        /// <value>
        /// The idle since days.
        /// </value>
        public string IdleSinceDays { get; set; }

        /// <summary>
        /// Gets or sets the name of the role.
        /// </summary>
        /// <value>
        /// The name of the role.
        /// </value>
        public string RoleName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is any title failed.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is any title failed; otherwise, <c>false</c>.
        /// </value>
        public bool IsAnyTitleHasFailed { get; set; }

        /// <summary>
        /// Gets or sets the reject reason.
        /// </summary>
        /// <value>
        /// The reject reason.
        /// </value>
        public string RejectReason { get; set; }

        /// <summary>
        /// Gets or sets the sort order.
        /// </summary>
        /// <value>
        /// The sort order.
        /// </value>
        public int SortOrder { get; set; }
    }

    /// <summary>
    /// VettingRequestDetails
    /// </summary>
    public class VettingRequestDetails
    {
        /// <summary>
        /// Gets or sets the vr identifier.
        /// </summary>
        /// <value>
        /// The vr identifier.
        /// </value>
        public string VR_ID { get; set; }

        /// <summary>
        /// Gets or sets the vetting status identifier.
        /// </summary>
        /// <value>
        /// The vetting status identifier.
        /// </value>
        public string VettingStatusId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vetting status.
        /// </summary>
        /// <value>
        /// The name of the vetting status.
        /// </value>
        public string VettingStatusName { get; set; }

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the vetting templates.
        /// </summary>
        /// <value>
        /// The vetting templates.
        /// </value>
        public string VettingTemplates { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the sign off on.
        /// </summary>
        /// <value>
        /// The sign off on.
        /// </value>
        public DateTime? SignOffOn { get; set; }

        /// <summary>
        /// Gets or sets the sign off by.
        /// </summary>
        /// <value>
        /// The sign off by.
        /// </value>
        public string SignOffBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the reject reason.
        /// </summary>
        /// <value>
        /// The reject reason.
        /// </value>
        public string RejectReason { get; set; }

    }

    public class VettingAttributeLookupList
    {
        /// <summary>
        /// Gets or sets the vetting status identifier.
        /// </summary>
        /// <value>
        /// The vetting status identifier.
        /// </value>
        public string VettingStatusId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vetting status.
        /// </summary>
        /// <value>
        /// The name of the vetting status.
        /// </value>
        public string VettingStatusName { get; set; }

        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }

    }

    /// <summary>
    /// CmpVettingTitleList
    /// </summary>
    public class CmpVettingTitleList
    {
        /// <summary>
        /// Gets or sets the CVT identifier.
        /// </summary>
        /// <value>
        /// The CVT identifier.
        /// </value>
        public string CVT_ID { get; set; }

        /// <summary>
        /// Gets or sets the vetting status.
        /// </summary>
        /// <value>
        /// The vetting status.
        /// </value>
        public string VettingStatus { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
    }
}
