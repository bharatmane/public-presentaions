﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class MDMDCompanyDetails
    /// </summary>
    public class MDMCompanyDetails
	{
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; } // not sure about ui field
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>
        /// The name of the company.
        /// </value>
        public string CompanyName { get; set; }
        /// <summary>
        /// Gets or sets the vix identifier.
        /// </summary>
        /// <value>
        /// The vix identifier.
        /// </value>
        public string VixId { get; set; }
        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }
        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId { get; set; }
        /// <summary>
        /// Gets or sets the name of the category.
        /// </summary>
        /// <value>
        /// The name of the category.
        /// </value>
        public string CategoryName { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address { get; set; }
        /// <summary>
        /// Gets or sets the city.
        /// </summary>
        /// <value>
        /// The city.
        /// </value>
        public string City { get; set; }
        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>
        /// The state.
        /// </value>
        public string State { get; set; }
        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>
        /// The postal code.
        /// </value>
        public string PostalCode { get; set; }
        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country { get; set; }
        /// <summary>
        /// Gets or sets the type of the preferred contact.
        /// </summary>
        /// <value>
        /// The type of the preferred contact.
        /// </value>
        public string PreferredContactType { get; set; }
        /// <summary>
        /// Gets or sets the email identifier.
        /// </summary>
        /// <value>
        /// The email identifier.
        /// </value>
        public string EmailId { get; set; }
        /// <summary>
        /// Gets or sets the telephone.
        /// </summary>
        /// <value>
        /// The telephone.
        /// </value>
        public string Telephone { get; set; }
        /// <summary>
        /// Gets or sets the mobile number.
        /// </summary>
        /// <value>
        /// The mobile number.
        /// </value>
        public string MobileNumber { get; set; }
        /// <summary>
        /// Gets or sets the fax address.
        /// </summary>
        /// <value>
        /// The fax address.
        /// </value>
        public string FaxAddress { get; set; }
        /// <summary>
        /// Gets or sets the website address.
        /// </summary>
        /// <value>
        /// The website address.
        /// </value>
        public string WebsiteAddress { get; set; }
        /// <summary>
        /// Gets or sets the skype identifier.
        /// </summary>
        /// <value>
        /// The skype identifier.
        /// </value>
        public string SkypeId { get; set; }
        /// <summary>
        /// Gets or sets the facebook identifier.
        /// </summary>
        /// <value>
        /// The facebook identifier.
        /// </value>
        public string FacebookId { get; set; }
        /// <summary>
        /// Gets or sets the imo number.
        /// </summary>
        /// <value>
        /// The imo number.
        /// </value>
        public string IMONumber { get; set; }
        /// <summary>
        /// Gets or sets the company number.
        /// </summary>
        /// <value>
        /// The company number.
        /// </value>
        public string CompanyNumber { get; set; }
        /// <summary>
        /// Gets or sets the taxreference number.
        /// </summary>
        /// <value>
        /// The taxreference number.
        /// </value>
        public string TaxreferenceNumber { get; set; }
        /// <summary>
        /// Gets or sets the effective date.
        /// </summary>
        /// <value>
        /// The effective date.
        /// </value>
        public DateTime? EffectiveDate { get; set; }
        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime? ExpiryDate { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is non marine.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is non marine; otherwise, <c>false</c>.
        /// </value>
        public bool IsNonMarine { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time supplier.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time supplier; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeSupplier { get; set; }

        /// <summary>
        /// Gets or sets the support information.
        /// </summary>
        /// <value>
        /// The support information.
        /// </value>
        public string SupportInformation { get; set; }
        /// <summary>
        /// Gets or sets the reason.
        /// </summary>
        /// <value>
        /// The reason.
        /// </value>
        public string Reason { get; set; }
        /// <summary>
        /// Gets or sets the reason for inclusion.
        /// </summary>
        /// <value>
        /// The reason for inclusion.
        /// </value>
        public string ReasonForInclusion { get; set; }
        /// <summary>
        /// Gets or sets the rf qreference number.
        /// </summary>
        /// <value>
        /// The rf qreference number.
        /// </value>
        public string RFQreferenceNumber { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [b2 b access].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [b2 b access]; otherwise, <c>false</c>.
        /// </value>
        public bool B2BAccess { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [b2 b quotes].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [b2 b quotes]; otherwise, <c>false</c>.
        /// </value>
        public bool B2BQuotes { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [b2 b invoice].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [b2 b invoice]; otherwise, <c>false</c>.
        /// </value>
        public bool B2BInvoice { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [b2 b freight].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [b2 b freight]; otherwise, <c>false</c>.
        /// </value>
        public bool B2BFreight { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [b2 b catering].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [b2 b catering]; otherwise, <c>false</c>.
        /// </value>
        public bool B2BCatering { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is marcus member.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is marcus member; otherwise, <c>false</c>.
        /// </value>
        public bool IsMarcusMember { get; set; }
        /// <summary>
        /// Gets or sets the CMP invoice number.
        /// </summary>
        /// <value>
        /// The CMP invoice number.
        /// </value>
        public string CmpInvoiceNumber { get; set; }
        /// <summary>
        /// Gets or sets the other reason description.
        /// </summary>
        /// <value>
        /// The other reason description.
        /// </value>
        public string OtherReasonDescription { get; set; }

    }
}
