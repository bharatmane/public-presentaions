﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// IBANErrors
    /// </summary>
    public class IBANErrors
    {  /// <summary>
       /// Gets or sets the code.
       /// </summary>
       /// <value>
       /// The code.
       /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }

    }
}
