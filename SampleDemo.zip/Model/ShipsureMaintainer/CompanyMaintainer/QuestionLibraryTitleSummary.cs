﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class QuestionLibraryTitleSummary
    /// </summary>
    public class QuestionLibraryTitleSummary
	{
        /// <summary>
        /// Gets or sets the VTL identifier.
        /// </summary>
        /// <value>
        /// The VTL identifier.
        /// </value>
        public string VTL_ID { get; set; }
        /// <summary>
        /// Gets or sets the vetting identifier.
        /// </summary>
        /// <value>
        /// The vetting identifier.
        /// </value>
        public string VettingId { get; set; }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the vetting tye.
        /// </summary>
        /// <value>
        /// The vetting tye.
        /// </value>
        public string VettingTye { get; set; }
        /// <summary>
        /// Gets or sets the name of the vetting tye.
        /// </summary>
        /// <value>
        /// The name of the vetting tye.
        /// </value>
        public string VettingTyeName { get; set; }
        /// <summary>
        /// Gets or sets the is one time check.
        /// </summary>
        /// <value>
        /// The is one time check.
        /// </value>
        public bool? IsOneTimeCheck { get; set; }
        /// <summary>
        /// Gets or sets the validity months.
        /// </summary>
        /// <value>
        /// The validity months.
        /// </value>
        public int? Validity_Months { get; set; }
        /// <summary>
        /// Gets or sets the renewal days.
        /// </summary>
        /// <value>
        /// The renewal days.
        /// </value>
        public int? Renewal_Days { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is applicable for amendment.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is applicable for amendment; otherwise, <c>false</c>.
        /// </value>
        public bool IsApplicableForAmendment { get; set; }
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is deleted; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleted { get; set; }
        /// <summary>
        /// Gets or sets the first level approval role identifier.
        /// </summary>
        /// <value>
        /// The first level approval role identifier.
        /// </value>
        public string FirstLevelApprovalRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the first name of the level approval role.
        /// </summary>
        /// <value>
        /// The first name of the level approval role.
        /// </value>
        public string FirstLevelApprovalRoleName { get; set; }
        /// <summary>
        /// Gets or sets the second level approval role identifier.
        /// </summary>
        /// <value>
        /// The second level approval role identifier.
        /// </value>
        public string SecondLevelApprovalRoleIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the name of the second level approval role.
        /// </summary>
        /// <value>
        /// The name of the second level approval role.
        /// </value>
        public string SecondLevelApprovalRoleName { get; set; }
        /// <summary>
        /// Gets or sets the document type identifier list.
        /// </summary>
        /// <value>
        /// The document type identifier list.
        /// </value>
        public List<string> DocumentTypeIDList { get; set; }
        /// <summary>
        /// Gets or sets the document typ names.
        /// </summary>
        /// <value>
        /// The document typ names.
        /// </value>
        public string DocumentTypNames { get; set; }
        /// <summary>
        /// Gets or sets the mapped template i ds.
        /// </summary>
        /// <value>
        /// The mapped template i ds.
        /// </value>
        public List<string> MappedTemplateIDs { get; set; }
        /// <summary>
        /// Gets or sets the mapped template names.
        /// </summary>
        /// <value>
        /// The mapped template names.
        /// </value>
        public List<string> MappedTemplateNames { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is self supply.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is self supply; otherwise, <c>false</c>.
		/// </value>
		public bool IsSelfSupply { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is b2 b.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is b2 b; otherwise, <c>false</c>.
		/// </value>
		public bool IsB2B { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is marcas.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is marcas; otherwise, <c>false</c>.
		/// </value>
		public bool IsMarcas { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is catering.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is catering; otherwise, <c>false</c>.
		/// </value>
		public bool IsCatering { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether this instance is document required.
		/// </summary>
		/// <value>
		///   <c>true</c> if this instance is document required; otherwise, <c>false</c>.
		/// </value>
		public bool IsDocumentRequired { get; set; }

        /// <summary>
        /// Gets or sets the mapped company i ds.
        /// </summary>
        /// <value>
        /// The mapped company i ds.
        /// </value>
        public List<string> MappedCompanyIDs { get; set; }

        /// <summary>
        /// Gets or sets the mapped company names.
        /// </summary>
        /// <value>
        /// The mapped company names.
        /// </value>
        public List<string> MappedCompanyNames { get; set; }

        /// <summary>
        /// Gets the templates.
        /// </summary>
        /// <value>
        /// The templates.
        /// </value>
        public string Templates
		{
            get 
            {
                string temp = string.Empty;
                if (MappedTemplateNames != null && MappedTemplateNames.Any())
                {
                    int counter = 1;
                    if (MappedTemplateNames.Any(x => string.IsNullOrWhiteSpace(x)))
                    {
                        temp = "No Template Assigned";
                    }
                    else
                    {
                        MappedTemplateNames.Where(x => !string.IsNullOrWhiteSpace(x)).ToList().ForEach(x =>
                        {
                            string t = string.Concat((counter != 1) ? "\n" : string.Empty, counter.ToString(), ". ", x);
                            temp += t;
                            counter++;
                        });
                    }
                }
                return temp;
            }
        }
    }
}
