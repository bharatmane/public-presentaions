﻿using System;
using System.Collections.Generic;
using System.Linq;
using VShips.DataServices.Shared.Contracts.Common;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.CompanyMaintainer
{
    /// <summary>
    /// class MDMValidatorSummary
    /// </summary>
    public class MDMValidatorSummary
	{
        /// <summary>
        /// Gets or sets the CMP identifier.
        /// </summary>
        /// <value>
        /// The CMP identifier.
        /// </value>
        public string CmpId { get; set; }
        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>
        /// The name of the company.
        /// </value>
        public string CompanyName { get; set; }
        /// <summary>
        /// Gets or sets the vix identifier.
        /// </summary>
        /// <value>
        /// The vix identifier.
        /// </value>
        public string VixId { get; set; }
        /// <summary>
        /// Gets or sets the vetting request identifier.
        /// </summary>
        /// <value>
        /// The vetting request identifier.
        /// </value>
        public string VettingRequestId { get; set; }
        /// <summary>
        /// Gets or sets the vetting status identifier.
        /// </summary>
        /// <value>
        /// The vetting status identifier.
        /// </value>
        public string VettingStatusId { get; set; }
        /// <summary>
        /// Gets or sets the vetting status description.
        /// </summary>
        /// <value>
        /// The vetting status description.
        /// </value>
        public string VettingStatusDescription { get; set; }
        /// <summary>
        /// Gets or sets the vetting status short code.
        /// </summary>
        /// <value>
        /// The vetting status short code.
        /// </value>
        public string VettingStatusShortCode { get; set; }
        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId { get; set; }
        /// <summary>
        /// Gets or sets the name of the category.
        /// </summary>
        /// <value>
        /// The name of the category.
        /// </value>
        public string CategoryName 
        {
            get { return (CategoryList != null && CategoryList.Any()) ? string.Join(", ", CategoryList.Select(x => x.Description)) : string.Empty; } 
        }
        /// <summary>
        /// Gets or sets the display name of the user.
        /// </summary>
        /// <value>
        /// The display name of the user.
        /// </value>
        public string UserDisplayName { get; set; }
        /// <summary>
        /// Gets or sets the requested date.
        /// </summary>
        /// <value>
        /// The requested date.
        /// </value>
        public DateTime? RequestedDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is one time supplier.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is one time supplier; otherwise, <c>false</c>.
        /// </value>
        public bool IsOneTimeSupplier { get; set; }

		/// <summary>
		/// Gets or sets the category list.
		/// </summary>
		/// <value>
		/// The category list.
		/// </value>
		public List<Lookup> CategoryList { get; set; }
    }
}
