﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.VesselVersionMaintainer
{
    /// <summary>
    /// 
    /// </summary>
    public class VesselVersionDetails
    {
        /// <summary>
        /// Gets or sets the vaur identifier.
        /// </summary>
        /// <value>
        /// The vaur identifier.
        /// </value>
        public string VaurId { get; set; }

        /// <summary>
        /// Gets or sets the application identifier.
        /// </summary>
        /// <value>
        /// The application identifier.
        /// </value>
        public string AppId { get; set; }

        /// <summary>
        /// Gets or sets the name of the application.
        /// </summary>
        /// <value>
        /// The name of the application.
        /// </value>
        public string ApplicationName { get; set; }

        /// <summary>
        /// Gets or sets the version number.
        /// </summary>
        /// <value>
        /// The version number.
        /// </value>
        public string VersionNumber { get; set; }

        /// <summary>
        /// Gets or sets the released on.
        /// </summary>
        /// <value>
        /// The released on.
        /// </value>
        public DateTime? ReleasedOn { get; set; }

        /// <summary>
        /// Gets or sets the released notes.
        /// </summary>
        /// <value>
        /// The released notes.
        /// </value>
        public string ReleasedNotes { get; set; }

        /// <summary>
        /// Gets or sets the total number of packages.
        /// </summary>
        /// <value>
        /// The total number of packages.
        /// </value>
        public int TotalNumberOfPackages { get; set; }

        /// <summary>
        /// Gets or sets the update size kb.
        /// </summary>
        /// <value>
        /// The update size kb.
        /// </value>
        public decimal UpdateSizeKB { get; set; }

        /// <summary>
        /// Gets or sets the update size mb.
        /// </summary>
        /// <value>
        /// The update size mb.
        /// </value>
        public decimal UpdateSizeMB
        {
            get { return Math.Round(UpdateSizeKB / 1024,2); }
        }

        /// <summary>
        /// Gets or sets the is patch installable.
        /// </summary>
        /// <value>
        /// The is patch installable.
        /// </value>
        public bool? IsPatchInstallable { get; set; }

        /// <summary>
        /// Gets or sets the name of the executable file.
        /// </summary>
        /// <value>
        /// The name of the executable file.
        /// </value>
        public string ExeFileName { get; set; }

        /// <summary>
        /// Gets or sets the is for all vessel.
        /// </summary>
        /// <value>
        /// The is for all vessel.
        /// </value>
        public bool? IsForAllVessel { get; set; }

        /// <summary>
        /// Gets or sets the display name of the file.
        /// </summary>
        /// <value>
        /// The display name of the file.
        /// </value>
        public string DisplayFileName { get; set; }

        /// <summary>
        /// Gets or sets the required base version.
        /// </summary>
        /// <value>
        /// The required base version.
        /// </value>
        public List<string> RequiredBaseVersion { get; set; }

        /// <summary>
        /// Gets or sets the required base versions.
        /// </summary>
        /// <value>
        /// The required base versions.
        /// </value>
        public string RequiredBaseVersions { get; set; }

    }
}
