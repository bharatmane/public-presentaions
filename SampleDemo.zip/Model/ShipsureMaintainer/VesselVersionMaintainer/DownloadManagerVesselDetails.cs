﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.VesselVersionMaintainer
{
    public class DownloadManagerVesselDetails : IDragData
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        public string DragTitle
        {
            get { return ""; }
        }

        public INavigationContext NavigationContext
        {
            get
            {
                throw new NotImplementedException();
            }
        }
    }
}
