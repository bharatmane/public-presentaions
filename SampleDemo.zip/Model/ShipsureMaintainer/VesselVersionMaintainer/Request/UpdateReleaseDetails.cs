﻿using System;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.VesselVersionMaintainer.Request
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateReleaseDetails
    {
        /// <summary>
        /// The version number
        /// </summary>
        public string VersionNumber;

        /// <summary>
        /// The release on
        /// </summary>
        public DateTime ReleaseOn;

        /// <summary>
        /// The checksum value
        /// </summary>
        public string ChecksumValue;

        /// <summary>
        /// The total file count
        /// </summary>
        public int TotalFileCount;

        /// <summary>
        /// The release notes
        /// </summary>
        public string ReleaseNotes;

        /// <summary>
        /// The file size
        /// </summary>
        public decimal FileSize;

        /// <summary>
        /// The release file name
        /// </summary>
        public string ReleaseFileName;

        /// <summary>
        /// The file path
        /// </summary>
        public string FilePath;
    }
}
