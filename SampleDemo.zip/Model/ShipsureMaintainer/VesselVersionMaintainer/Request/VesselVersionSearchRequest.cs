﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.ShipsureMaintainer.VesselVersionMaintainer.Request
{
    public class VesselVersionSearchRequest
    {
        /// <summary>
        /// Gets or sets the application identifier.
        /// </summary>
        /// <value>
        /// The application identifier.
        /// </value>
        public List<string> ApplicationId { get; set; }

        /// <summary>
        /// Gets or sets the version number.
        /// </summary>
        /// <value>
        /// The version number.
        /// </value>
        public string VersionNumber { get; set; }
    }
}
