﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.VesselVersionMaintainer.Request
{
    /// <summary>
    /// VesselListSearchRequest
    /// </summary>
    public class VesselListSearchRequest
    {
        /// <summary>
        /// Gets or sets the type of the transport.
        /// </summary>
        /// <value>
        /// The type of the transport.
        /// </value>
        public int TransportType { get; set; }

        /// <summary>
        /// Gets or sets the is download manager installed.
        /// </summary>
        /// <value>
        /// The is download manager installed.
        /// </value>
        public int IsDownloadManagerInstalled { get; set; }

        /// <summary>
        /// Gets or sets the logged in user identifier.
        /// </summary>
        /// <value>
        /// The logged in user identifier.
        /// </value>
        public string LoggedInUserId { get; set; }
    }
}
