﻿namespace VShips.Framework.Common.Model.ShipsureMaintainer.VesselVersionMaintainer
{
    /// <summary>
    /// 
    /// </summary>
    public class ApplicationDetails
    {
        /// <summary>
        /// Gets or sets the application identifier.
        /// </summary>
        /// <value>
        /// The application identifier.
        /// </value>
        public string ApplicationId { get; set; }

        /// <summary>
        /// Gets or sets the application identifier.
        /// </summary>
        /// <value>
        /// The application identifier.
        /// </value>
        public string ApplicationIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the name of the application.
        /// </summary>
        /// <value>
        /// The name of the application.
        /// </value>
        public string ApplicationName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is check version for download.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is check version for download; otherwise, <c>false</c>.
        /// </value>
        public bool? IsCheckVersionForDownload { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is applicable for document upload.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is applicable for document upload; otherwise, <c>false</c>.
        /// </value>
        public bool? IsApplicableForDocumentUpload { get; set; }
    }
}
