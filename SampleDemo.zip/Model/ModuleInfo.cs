﻿using VShips.Framework.Common.Model.Icons;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Information used to pass between modules and the <see cref="IModuleService"/>
    /// </summary>
    public struct ModuleInfo
    {
        private readonly string _name;
        /// <summary>
        /// the name of the module.
        /// </summary>
        public string Name
        {
            get { return _name; }
        }

        private readonly BaseIconViewModel _icon;
        /// <summary>
        /// An icon representing the module.
        /// </summary>
        public BaseIconViewModel Icon
        {
            get { return _icon; }
        }

        private readonly bool _isRequired;
        /// <summary>
        /// True if the module is part of the framework.
        /// </summary>
        public bool IsRequired
        {
            get { return _isRequired; }
        }

        /// <summary>
        /// The default contructor for ModuleInfo.
        /// </summary>
        /// <param name="name">The name of the module.</param>
        /// <param name="icon">The icon for the module.</param>
        /// <param name="isRequired">True if the module is part of the framework.</param>
        public ModuleInfo(string name, BaseIconViewModel icon, bool isRequired = false)
            : this()
        {
            _name = name;
            _icon = icon;
            _isRequired = isRequired;
        }

        /// <summary>
        /// Override for the ToString method.
        /// </summary>
        /// <returns>Returns the name of the module.</returns>
        public override string ToString()
        {
            return Name;
        }
    }

}
