﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// A class for setting permission on a control.
    /// </summary>
    public class ModuleControlPermission
    {
        /// <summary>
        /// The name of the module.
        /// </summary>
        public string ModuleName { get; set; }

        /// <summary>
        /// The Id for the control.
        /// </summary>
        public string ControlId { get; set; }
    }
}
