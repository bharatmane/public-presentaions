﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An enum representing the current state of the <see cref="INavigationContext"/>.
    /// </summary>
    public enum NavigationContextStates
    {
        /// <summary>
        /// A view within the context has triggered the editing state.
        /// </summary>
        Editing,

        /// <summary>
        /// A view within the context has triggered the adding state.
        /// </summary>
        Adding
    }
}
