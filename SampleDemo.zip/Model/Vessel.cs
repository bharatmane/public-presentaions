﻿namespace VShips.Framework.Common.Model
{
    public class Vessel
    {
        public System.String Imo { get; set; }
        public System.String VesId { get; set; }
        public System.String VesselName { get; set; }
    }
}