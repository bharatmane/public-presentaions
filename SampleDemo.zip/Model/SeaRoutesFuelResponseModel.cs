﻿using System.Collections.Generic;
using Newtonsoft.Json;

// ReSharper disable InconsistentNaming
#pragma warning disable 1591


namespace VShips.Framework.Common.Model
{
    public class SeaRoutesFuelResponseModel
    {
        [JsonProperty("w")]
        public SeaRoutesFuelResponseModelOuter WeatherInfluenced { get; set; }

        [JsonProperty("p")]
        public SeaRoutesFuelResponseModelOuter CalmWaterInfluenced { get; set; }
    }

    
    public class SeaRoutesFuelResponseModelOuter
    {
        [JsonProperty("2to4")]
        public List<SeaRoutesFuelResponseModelInner> TwoToFourTEU { get; set; }

        [JsonProperty("4to6")]
        public List<SeaRoutesFuelResponseModelInner> FourToSixTEU { get; set; }

        [JsonProperty("6to8")]
        public List<SeaRoutesFuelResponseModelInner> SixToEightTEU { get; set; }

        [JsonProperty("8to10")]
        public List<SeaRoutesFuelResponseModelInner> EightToTenTEU { get; set; }

        [JsonProperty("10plus")]
        public List<SeaRoutesFuelResponseModelInner> TenPlusTEU { get; set; }
    }

    
    public class SeaRoutesFuelResponseModelInner
    {
        [JsonProperty("v")]
        public double SpeedKnots { get; set; }

        [JsonProperty("dur")]
        public double DurationSecs { get; set; }

        [JsonProperty("lon")]
        public double Longitude { get; set; }

        [JsonProperty("lat")]
        public double Latitude { get; set; }

        [JsonProperty("trackDistance")]
        public double TrackDistanceKM { get; set; }

        [JsonProperty("ts")]
        public double AbsoluteSeconds { get; set; }

        [JsonProperty("fuel")]
        public double FuelGrams { get; set; }

        [JsonProperty("total")]
        public double TotalFuelGrams { get; set; }

        [JsonProperty("seca")]
        public bool SECA { get; set; }
    }
}