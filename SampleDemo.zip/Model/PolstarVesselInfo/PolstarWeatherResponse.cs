﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.PolstarVesselInfo
{
    /// <summary>
    /// Polstar Weather Response
    /// </summary>
    public class PolstarWeatherResponse
    {
        /// <summary>
        /// Gets or sets the meta.
        /// </summary>
        /// <value>
        /// The meta.
        /// </value>
        [JsonProperty("meta")]
        public PolstarWeatherMeta meta { get; set; }

        /// <summary>
        /// Gets or sets the objects.
        /// </summary>
        /// <value>
        /// The objects.
        /// </value>
        [JsonProperty("objects")]
        public List<PolstarWeatherObject> objects { get; set; }
    }
}