﻿namespace VShips.Framework.Common.Model.PolstarVesselInfo
{
    /// <summary>
    /// Polstar Weather Coordinates
    /// </summary>
    public class PolstarWeatherCoord
    {
        /// <summary>
        /// Gets or sets the lat.
        /// </summary>
        /// <value>
        /// The lat.
        /// </value>
        public string lat { get; set; }

        /// <summary>
        /// Gets or sets the lon.
        /// </summary>
        /// <value>
        /// The lon.
        /// </value>
        public string lon { get; set; }
    }
}