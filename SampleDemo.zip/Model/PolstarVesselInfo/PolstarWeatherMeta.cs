﻿namespace VShips.Framework.Common.Model.PolstarVesselInfo
{
    /// <summary>
    /// Polstar Weather Metadata
    /// </summary>
    public class PolstarWeatherMeta
    {
        /// <summary>
        /// Gets or sets the nearest time.
        /// </summary>
        /// <value>
        /// The nearest time.
        /// </value>
        public string nearest_time { get; set; }

        /// <summary>
        /// Gets or sets the nearest coord.
        /// </summary>
        /// <value>
        /// The nearest coord.
        /// </value>
        public PolstarWeatherCoord nearest_coord { get; set; }
    }
}