﻿namespace VShips.Framework.Common.Model.PolstarVesselInfo
{
    /// <summary>
    /// Class to hold the Vessel Insight Info
    /// </summary>
    public class VesselInsightInfo
    {
        /// <summary>
        /// Gets or sets the subscription identifier.
        /// </summary>
        /// <value>
        /// The subscription identifier.
        /// </value>
        public int SubscriptionId { get; set; }

        /// <summary>
        /// Gets or sets the imo.
        /// </summary>
        /// <value>
        /// The imo.
        /// </value>
        public string Imo { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public Coordinate Location { get; set; }

        /// <summary>
        /// Gets or sets the cog.
        /// </summary>
        /// <value>
        /// The cog.
        /// </value>
        public double Cog { get; set; }

        /// <summary>
        /// Gets or sets the sog.
        /// </summary>
        /// <value>
        /// The sog.
        /// </value>
        public double Sog { get; set; }

        /// <summary>
        /// Gets or sets the date reported.
        /// </summary>
        /// <value>
        /// The date reported.
        /// </value>
        public string DateReported { get; set; }

        /// <summary>
        /// Gets or sets the weather.
        /// </summary>
        /// <value>
        /// The weather.
        /// </value>
        public PolstarWeatherResponse Weather { get; set; }
    }

    /// <summary>
    /// Struct to hold Geographical coordinates
    /// </summary>
    public struct Coordinate
    {
        /// <summary>
        /// Gets or sets the latitude.
        /// </summary>
        /// <value>
        /// The latitude.
        /// </value>
        public double Latitude { get; set; }

        /// <summary>
        /// Gets or sets the longitude.
        /// </summary>
        /// <value>
        /// The longitude.
        /// </value>
        public double Longitude { get; set; }
    }
}