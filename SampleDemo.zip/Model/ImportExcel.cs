﻿using Microsoft.Practices.ServiceLocation;
using Spire.Xls;
using System;
using System.Data;
using System.IO;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Import excel.
    /// </summary>
    public class ImportExcel
    {
        #region Properties

        /// <summary>
        /// The error
        /// </summary>
        private string error = string.Empty;

        #endregion

        #region Method

        /// <summary>
        /// Converts the excel to data table.
        /// </summary>
        /// <param name="errorsInImport">The errors in import.</param>
        /// <returns>Object of type Datatable</returns>
        /// <exception cref="FileNotFoundException"></exception>
        /// <exception cref="Exception"></exception>
        public DataTable ConvertExcelToDataTable(out string errorsInImport)
        {
            string inputFile = ValidateOpenFileDialog();
            errorsInImport = null;
            if (!string.IsNullOrWhiteSpace(inputFile))
            {
                try
                {
                    //Check if file exists
                    if (File.Exists(inputFile))
                    {
                        //Create a new workbook
                        Workbook workbook = new Workbook();
                        //Load a file and imports its data
                        workbook.LoadFromFile(inputFile);
                        //Initialize worksheet
                        Worksheet sheet = workbook.Worksheets[0];
                        // get the data source that the grid is displaying data for
                        return sheet.ExportDataTable();
                    }
                    else
                    {
                        errorsInImport = Path.GetFileName(inputFile) + " not found.";
                        //This should not happen ever, because user can not select file which dose not exists
                        throw new FileNotFoundException(errorsInImport);
                    }
                }
                catch (Exception ex)
                {
                    //Check if exception if for File in use then give specific message. Else give generic message
                    //-2147024864 is for File in use exception.
                    if (ex != null && ex.HResult == -2147024864)
                    {
                        errorsInImport = Messages.CanNotImportFileBecauseItIsBeingUsedByAnotherProcess;
                        ServiceLocator.Current.GetInstance<ILoggerService>().Error(Messages.CanNotImportFileBecauseItIsBeingUsedByAnotherProcess, ex.Message, ex);
                    }
                    else
                    {
                        errorsInImport = Messages.ImportFailed;
                        ServiceLocator.Current.GetInstance<ILoggerService>().Error(Messages.ImportFailed, ex.Message, ex);
                    }
                }
            }

            return null;

        }

        /// <summary>
        /// Validates the open file dialog.
        /// </summary>
        /// <returns></returns>
        public string ValidateOpenFileDialog()
        {
            string fileName = null;

            ServiceLocator.Current.GetInstance<IDialogService>().OpenFileDialog(GetDialogParameters(), (b, result) =>
            {
                if (b == true && !string.IsNullOrWhiteSpace(result.FileName))
                {
                    fileName = result.FileName;
                }
            });

            if (!string.IsNullOrWhiteSpace(fileName))
            {
                var fileSize = new FileInfo(fileName).Length;
                if (fileSize > Constant.MaxFileSizeForImportInBytes)
                {
                    error = string.Format(Messages.FileIsLargeMultiple, Path.GetFileName(fileName));
                    ServiceLocator.Current.GetInstance<ILoggerService>().Error(error, "",null);
                    return null;
                }
                else if (fileSize == 0)
                {
                    error = string.Format(Messages.FileIs0SizeMultiple, Path.GetFileName(fileName));
                    ServiceLocator.Current.GetInstance<ILoggerService>().Error(error, "", null);
                    return null;
                }
                else if (Path.GetFileName(fileName).Length > 50)
                {
                    error = Messages.MaximumExcelFileNameMessage;
                    ServiceLocator.Current.GetInstance<ILoggerService>().Error(error, "", null);
                    return null;                    
                }
                else if (!File.Exists(fileName))
                {
                    error = Messages.InvalidFileMessage;
                    ServiceLocator.Current.GetInstance<ILoggerService>().Error(error, "", null);
                    return null;                    
                }
            }
            else
            {
                return null;
            }
            return fileName;
        }

        /// <summary>
        /// Gets the dialog parameters.
        /// </summary>  
        /// <returns>Single object of type FileDialogParameters</returns>
        public FileDialogParameters GetDialogParameters()
        {
            var fileParameters = new FileDialogParameters
            {
                //Todo: karan - make this filter common.
                Filter = "Excel Files (.xlsx)|*.xlsx|Excel Files (.xls)|*.xls |All Files|*.xlsx;*.xls;",
                Title = Messages.ExcelSelectionMessage,
                Multiselect = false
            };
            fileParameters.FilterIndex = ((fileParameters.Filter.Split('|').Length) / 2);//this gets the last item in the filter
            return fileParameters;
        }

        #endregion


    }
}
