﻿using System;
using GalaSoft.MvvmLight.Command;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// <para>
    /// An interface used in the <see cref="IDialogService"/>.
    /// </para>
    /// <para>
    /// Can be used on a viewmodel that is the datacontext of a dialog.
    /// Allows more control of the dialog from the viewmodel.
    /// </para> 
    /// </summary>
    public interface IDialogAware
    {
        /// <summary>
        /// Raised whenever the dialog is closed.
        /// </summary>
        event EventHandler Closed;

        /// <summary>
        /// Gets or sets a title for the dialog.
        /// </summary>
        string Title { get; set; }

        /// <summary>
        /// Can be used to prevent the close of a context dialog.
        /// </summary>
        bool CanClose();
    }
}
