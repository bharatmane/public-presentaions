﻿#pragma warning disable 1591
namespace VShips.Framework.Common.Model
{
    public class ComponentIdName
    {
        public string ComponentId { get; set; }
        public string ComponentName { get; set; }
    }
}
