﻿#pragma warning disable 1591
namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Represents a type of message to display on the UI.
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// Operation succesful.
        /// </summary>
        Success,

        /// <summary>
        /// Operation failed.
        /// </summary>
        Failure,

        /// <summary>
        /// Operation warning.
        /// </summary>
        Warning,

        /// <summary>The vessel alert</summary>
        VesselAlert,

        /// <summary>The information</summary>
        Information
    }
}
