﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Classes defining simple structures and classes used throughout the framework.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
