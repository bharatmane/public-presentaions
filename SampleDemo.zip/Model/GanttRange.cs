using System.ComponentModel;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Defines the ranges for the Gantt Chart.
    /// </summary>
    public enum GanttRange
    {
        /// <summary>
        /// A year range.
        /// </summary>
        [Description("Year")]
        Year = 12,

        /// <summary>
        /// Eleven months range.
        /// </summary>
        [Description("Eleven Months")]
        ElevenMonths = 11,

        /// <summary>
        /// Ten months range.
        /// </summary>
        [Description("Ten Months")]
        TenMonths = 10,

        /// <summary>
        /// A year range.
        /// </summary>
        [Description("Nine Months")]
        NineMonths = 9,

        /// <summary>
        /// Eight months range.
        /// </summary>
        [Description("Eight Months")]
        EightMonths = 8,

        /// <summary>
        /// Seven months range.
        /// </summary>
        [Description("Seven Months")]
        SevenMonths = 7,

        /// <summary>
        /// 6 months range.
        /// </summary>
        [Description("6 Months")]
        HalfYear = 6,

        /// <summary>
        /// Five months range.
        /// </summary>
        [Description("Five Months")]
        FiveMonths = 5,

        /// <summary>
        /// Four months range.
        /// </summary>
        [Description("Four Months")]
        FourMonths = 4,

        /// <summary>
        /// Three months range.
        /// </summary>
        [Description("Three Months")]
        Quarter = 3,

        /// <summary>
        /// Two months range.
        /// </summary>
        [Description("Two Months")]
        TwoMonths = 2,

        /// <summary>
        /// Months range.
        /// </summary>
        [Description("Month")]
        Month = 1
    }
}