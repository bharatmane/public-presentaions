﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// This class is used to make Custom queue request.
    /// </summary>
    public class CustomQueueRequest
    {
        /// <summary>
        /// Gets or sets the request identifier.
        /// </summary>
        /// <value>
        /// The request identifier.
        /// </value>
        public string RequestId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [hide downloaded document on UI].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [hide downloaded document on UI]; otherwise, <c>false</c>.
        /// </value>
        public bool HideDownloadedDocumentOnUI { get; set; }

        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>
        /// The file path.
        /// </value>
        public string FilePath { get; set; }

        /// <summary>
        /// Gets or sets the short name of the file.
        /// </summary>
        /// <value>
        /// The short name of the file.
        /// </value>
        public string ShortFileName { get; set; }

        /// <summary>
        /// Gets or sets the additional information.
        /// </summary>
        /// <value>
        /// The additional information.
        /// </value>
        public object AdditionalInformation { get; set; }

        /// <summary>
        /// Gets or sets the refresh required.
        /// </summary>
        /// <value>
        /// The refresh required.
        /// </value>
        public bool RefreshRequired { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [show file downloaded message].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show file downloaded message]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowFileDownloadedMessage { get; set; }

        /// <summary>
        /// Gets or sets the success message.
        /// </summary>
        /// <value>
        /// The success message.
        /// </value>
        public string SuccessMessage { get; set; }

        /// <summary>
        /// Gets or sets the failure message.
        /// </summary>
        /// <value>
        /// The failure message.
        /// </value>
        public string FailureMessage { get; set; }


        /// <summary>
        /// Gets or sets a value indicating whether [open downloaded file].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [open downloaded file]; otherwise, <c>false</c>.
        /// </value>
        public bool OpenDownloadedFile { get; set; }

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomQueueRequest"/> class.
        /// </summary>
        public CustomQueueRequest()
        {
            SuccessMessage = "Report generated.";
            FailureMessage = "Failed to generated report.";
        }
        #endregion
    }
}
