﻿using System;

namespace VShips.Framework.Common.Model.DocumentAPI
{
	/// <summary>
	/// DocumentDetailsDTO
	/// </summary>
	public class DocumentDetailsDTO
	{
        /// <summary>
        /// Gets or sets the document type identifier.
        /// </summary>
        /// <value>
        /// The document type identifier.
        /// </value>
        public string DocumentTypeId { get; set; }

        /// <summary>
        /// Gets or sets the document type description.
        /// </summary>
        /// <value>
        /// The document type description.
        /// </value>
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the document meta data identifier.
        /// </summary>
        /// <value>
        /// The document meta data identifier.
        /// </value>
        public string DocumentMetaDataId { get; set; }

        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>
        /// The source.
        /// </value>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the issue date.
        /// </summary>
        /// <value>
        /// The issue date.
        /// </value>
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the vetting status.
        /// </summary>
        /// <value>
        /// The vetting status.
        /// </value>
        public string VettingStatus { get; set; }

        ///// <summary>
        ///// Gets or sets a value indicating whether this instance is edit allowed.
        ///// </summary>
        ///// <value>
        /////   <c>true</c> if this instance is edit allowed; otherwise, <c>false</c>.
        ///// </value>
        //public bool IsEditAllowed { get; set; }

        /// <summary>
        /// Gets or sets the failure message.
        /// </summary>
        /// <value>
        /// The failure message.
        /// </value>
        public string FailureMessage { get; set; }

        /// <summary>
        /// Gets or sets the document title.
        /// </summary>
        /// <value>
        /// The document title.
        /// </value>
        public string DocumentTitle { get; set; }

        /// <summary>
        /// Gets or sets the document status.
        /// </summary>
        /// <value>
        /// The document status.
        /// </value>
        public string DocumentStatus { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the vix identifier.
        /// </summary>
        /// <value>
        /// The vix identifier.
        /// </value>
        public string Vix_ID { get; set; }

		/// <summary>
		/// Gets or sets the size of the file.
		/// </summary>
		/// <value>
		/// The size of the file.
		/// </value>
		public int FileSize { get; set; }

		/// <summary>
		/// Gets or sets the file nam.
		/// </summary>
		/// <value>
		/// The file nam.
		/// </value>
		public string FileName { get; set; }
    }
}
