﻿namespace VShips.Framework.Common.Model.DocumentAPI
{
	/// <summary>
	/// DocumentCountResponse
	/// </summary>
	public class DocumentCountResponse
	{
		/// <summary>
		/// Gets or sets the active document count.
		/// </summary>
		/// <value>
		/// The active document count.
		/// </value>
		public int ActiveDocumentCount { get; set; }

		/// <summary>
		/// Gets or sets the archived document count.
		/// </summary>
		/// <value>
		/// The archived document count.
		/// </value>
		public int ArchivedDocumentCount { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="DocumentCountResponse"/> class.
		/// </summary>
		public DocumentCountResponse()
		{

		}
	}
}
