﻿namespace VShips.Framework.Common.Model.DocumentAPI
{
	/// <summary>
	/// ApplicableDocumentTypeRequest
	/// </summary>
	public class ApplicableDocumentTypeRequest
	{
        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>
        /// The source.
        /// </value>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId { get; set; }
    }
}
