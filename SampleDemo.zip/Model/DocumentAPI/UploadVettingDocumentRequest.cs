﻿using System;

namespace VShips.Framework.Common.Model.DocumentAPI
{
    /// <summary>
    /// 
    /// </summary>
    public class UploadDocumentRequest
    {

        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>
        /// The source.
        /// </value>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets the document type identifier.
        /// </summary>
        /// <value>
        /// The document type identifier.
        /// </value>
        public string DocumentTypeId { get; set; }

        /// <summary>
        /// Gets or sets the issue date.
        /// </summary>
        /// <value>
        /// The issue date.
        /// </value>
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the company vetting title identifier.
        /// </summary>
        /// <value>
        /// The company vetting title identifier.
        /// </value>
        public string CompanyVettingTitleId { get; set; }

        /// <summary>
        /// Gets or sets the document stream.
        /// </summary>
        /// <value>
        /// The document stream.
        /// </value>
        public byte[] DocumentStream { get; set; }

        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>
        /// The name of the file.
        /// </value>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets the name of the login user.
        /// </summary>
        /// <value>
        /// The name of the login user.
        /// </value>
        public string LoginUserName { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.Model.DocumentAPI.UploadDocumentRequest" />
    public class EditDocumentRequest : UploadDocumentRequest
    {
        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the document meta data identifier.
        /// </summary>
        /// <value>
        /// The document meta data identifier.
        /// </value>
        public string DocumentMetaDataId { get; set; }

    }
}
