﻿namespace VShips.Framework.Common.Model.DocumentAPI
{
	/// <summary>
	/// ApplicableDocumentTypeResponseDTO
	/// </summary>
	public class ApplicableDocumentTypeResponseDTO
	{
        /// <summary>
        /// Gets or sets the document type identifier.
        /// </summary>
        /// <value>
        /// The document type identifier.
        /// </value>
        public string DocumentTypeId { get; set; }

        /// <summary>
        /// Gets or sets the document type description.
        /// </summary>
        /// <value>
        /// The document type description.
        /// </value>
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is document required.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is document required; otherwise, <c>false</c>.
        /// </value>
        public bool IsDocumentRequired { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is issue date mandatory.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is issue date mandatory; otherwise, <c>false</c>.
        /// </value>
        public bool IsIssueDateMandatory { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is expiry date mandatory.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is expiry date mandatory; otherwise, <c>false</c>.
        /// </value>
        public bool IsExpiryDateMandatory { get; set; }
    }
}
