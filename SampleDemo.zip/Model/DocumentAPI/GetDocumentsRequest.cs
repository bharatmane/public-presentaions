﻿namespace VShips.Framework.Common.Model.DocumentAPI
{
	/// <summary>
	/// GetDocumentsRequest
	/// </summary>
	public class GetDocumentsRequest
	{
        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>
        /// The source.
        /// </value>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>
        /// The company identifier.
        /// </value>
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets the document status.
        /// 0 - All, 1 - Active, 2 - Archived, 3 - Deleted
        /// </summary>
        /// <value>
        /// The document status.
        /// </value>
        public int DocumentStatus { get; set; }

        /// <summary>
        /// Gets or sets the vi x identifier.
        /// </summary>
        /// <value>
        /// The vi x identifier.
        /// </value>
        public string ViXId { get; set; }

        /// <summary>
        /// Gets or sets the document meta data identifier.
        /// </summary>
        /// <value>
        /// The document meta data identifier.
        /// </value>
        public string DocumentMetaDataId { get; set; }
    }
}
