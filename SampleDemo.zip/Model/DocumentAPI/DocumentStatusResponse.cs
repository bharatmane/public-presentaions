﻿namespace VShips.Framework.Common.Model.DocumentAPI
{
	/// <summary>
	/// DocumentStatusResponse
	/// </summary>
	public class DocumentStatusResponse
	{
        /// <summary>
        /// Gets or sets the document status.
        /// </summary>
        /// <value>
        /// The document status.
        /// </value>
        public string DocumentStatus { get; set; }

        /// <summary>
        /// Gets or sets the document count.
        /// </summary>
        /// <value>
        /// The document count.
        /// </value>
        public int DocumentCount { get; set; }
    }
}
