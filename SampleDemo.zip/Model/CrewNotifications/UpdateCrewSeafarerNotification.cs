﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewNotifications
{
    /// <summary>
    /// This class contract for update
    /// </summary>
    public class UpdateCrewSeafarerNotification
    {

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        public CrewSeafarerDataAction Data { get; set; }

        /// <summary>
        /// Gets or sets the scheduled time stamp.
        /// </summary>
        /// <value>
        /// The scheduled time stamp.
        /// </value>
        public DateTime? ScheduledTimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the assigned delivery order.
        /// </summary>
        /// <value>
        /// The assigned delivery order.
        /// </value>
        public List<string> AssignedDeliveryOrder { get; set; }

        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId { get; set; }

        /// <summary>
        /// Gets or sets the webhook.
        /// </summary>
        /// <value>
        /// The webhook.
        /// </value>
        public string Webhook { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

    }
}