﻿using System;
using System.Collections.Generic;
using System.Windows.Media;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.CrewNotifications
{
    /// <summary>
    /// This class is for crew seafarer notifications
    /// </summary>
    public class CrewSeafarerNotification : BaseViewModel
    {
        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string Id { get; set; }

        /// <summary>
        /// The title
        /// </summary>
        private string _title;

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title
        {
            get { return _title; }
            set { Set(() => Title, ref _title, value); }
        }

        /// <summary>
        /// The message
        /// </summary>
        private string _message;

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message
        {
            get { return _message; }
            set { Set(() => Message, ref _message, value); }
        }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        public string Data { get; set; }

        /// <summary>
        /// The scheduled time stamp
        /// </summary>
        private DateTime? _scheduledTimeStamp;

        /// <summary>
        /// Gets or sets the scheduled time stamp.
        /// </summary>
        /// <value>
        /// The scheduled time stamp.
        /// </value>
        public DateTime? ScheduledTimeStamp
        {
            get { return _scheduledTimeStamp; }
            set { Set(() => ScheduledTimeStamp, ref _scheduledTimeStamp, value); }
        }

        /// <summary>
        /// Gets or sets the time stamp.
        /// </summary>
        /// <value>
        /// The time stamp.
        /// </value>
        public DateTime? TimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the assigned delivery order display.
        /// </summary>
        /// <value>
        /// The assigned delivery order display.
        /// </value>
        public List<string> AssignedDeliveryOrderDisplay { get; set; }

        /// <summary>
        /// The category identifier
        /// </summary>
        private string _categoryId;

        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public string CategoryId
        {
            get { return _categoryId; }
            set { Set(() => CategoryId, ref _categoryId, value); }
        }

        /// <summary>
        /// Gets or sets the name of the category.
        /// </summary>
        /// <value>
        /// The name of the category.
        /// </value>
        public string CategoryName { get; set; }

        /// <summary>
        /// Gets or sets the name of the status.
        /// </summary>
        /// <value>
        /// The name of the status.
        /// </value>
        public string StatusName { get; set; }

        /// <summary>
        /// Gets or sets the webhook.
        /// </summary>
        /// <value>
        /// The webhook.
        /// </value>
        public string Webhook { get; set; }

        /// <summary>
        /// Gets or sets the name of the delivery method.
        /// </summary>
        /// <value>
        /// The name of the delivery method.
        /// </value>
        public string DeliveryMethodName { get; set; }

        /// <summary>
        /// Gets or sets the delivery error message.
        /// </summary>
        /// <value>
        /// The delivery error message.
        /// </value>
        public string DeliveryErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the sent time.
        /// </summary>
        /// <value>
        /// The sent time.
        /// </value>
        public DateTime? SentTime { get; set; }

        /// <summary>
        /// Gets or sets the delivery value.
        /// </summary>
        /// <value>
        /// The delivery value.
        /// </value>
        public string DeliveryValue { get; set; }

        /// <summary>
        /// Gets or sets the read on time.
        /// </summary>
        /// <value>
        /// The read on time.
        /// </value>
        public DateTime? ReadOnTime { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the assigned delivery order.
        /// </summary>
        /// <value>
        /// The assigned delivery order.
        /// </value>
        public List<string> AssignedDeliveryOrder { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the display name of the updated by.
        /// </summary>
        /// <value>
        /// The display name of the updated by.
        /// </value>
        public string UpdatedByDisplayName { get; set; }

        /// <summary>
        /// The is schedule now
        /// </summary>
        private bool _isScheduleNow = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is schedule now.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is schedule now; otherwise, <c>false</c>.
        /// </value>
        public bool IsScheduleNow
        {
            get { return _isScheduleNow; }
            set { Set(() => IsScheduleNow, ref _isScheduleNow, value); }
        }

        /// <summary>
        /// The status short code
        /// </summary>
        private string _statusShortCode;

        /// <summary>
        /// Gets or sets a value indicating whether [status short code].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [status short code]; otherwise, <c>false</c>.
        /// </value>
        public string StatusShortCode
        {
            get { return _statusShortCode; }
            set { Set(() => StatusShortCode, ref _statusShortCode, value); }
        }

        /// <summary>
        /// The notification status color
        /// </summary>
        private Brush _notificationStatusColor;

        /// <summary>
        /// Gets or sets the color of the notification status.
        /// </summary>
        /// <value>
        /// The color of the notification status.
        /// </value>
        public Brush NotificationStatusColor
        {
            get { return _notificationStatusColor; }
            set { Set(() => NotificationStatusColor, ref _notificationStatusColor, value); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds the property validation.
        /// </summary>
        public void AddPropertyValidation()
        {
            AddPropertyValidation(() => CategoryId, () =>
            {
                return !string.IsNullOrWhiteSpace(CategoryId) ? string.Empty : "Category cannot be empty.";
            });

            AddPropertyValidation(() => Title, () =>
            {
                return !string.IsNullOrWhiteSpace(Title) ? string.Empty : "Title cannot be empty.";
            });

            AddPropertyValidation(() => Message, () =>
            {
                return !string.IsNullOrWhiteSpace(Message) ? string.Empty : "Body cannot be empty.";
            });

            AddPropertyValidation(() => ScheduledTimeStamp, () =>
            {
                if (!IsScheduleNow && !ScheduledTimeStamp.HasValue)
                {
                    return "Schedule On cannot be empty.";
                }

                if (!IsScheduleNow && ScheduledTimeStamp.HasValue)
                {
                    DateTime currentDateTime = DateTime.Now;
                    if (ScheduledTimeStamp.Value.AddSeconds(-ScheduledTimeStamp.Value.Second) < currentDateTime.AddSeconds(-currentDateTime.Second))
                    {
                        return "Schedule On cannot be less than Current time.";
                    }
                }
                return string.Empty;
            });
        }

        #endregion
    }
}