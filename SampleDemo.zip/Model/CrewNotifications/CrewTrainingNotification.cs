﻿using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.CrewNotifications
{
    /// <summary>
    /// Class for CrewTrainingNotification
    /// </summary>
    /// <seealso cref="VShips.Framework.Common.ViewModel.BaseViewModel" />
    public class CrewTrainingNotification
    {
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string message { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="CrewTrainingNotification"/> is success.
        /// </summary>
        /// <value>
        ///   <c>true</c> if success; otherwise, <c>false</c>.
        /// </value>
        public bool success { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public JsonResultCrewTemplate version { get; set; }
    }

    /// <summary>
    /// Class jsonResultCrewTemplate
    /// </summary>
    public class JsonResultCrewTemplate
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public string id { get; set; }

        /// <summary>
        /// Gets or sets the template identifier.
        /// </summary>
        /// <value>
        /// The template identifier.
        /// </value>
        public string template_id { get; set; }

        /// <summary>
        /// Gets or sets the content of the HTML.
        /// </summary>
        /// <value>
        /// The content of the HTML.
        /// </value>
        public string html_content { get; set; }

        /// <summary>
        /// Gets or sets the content of the plain.
        /// </summary>
        /// <value>
        /// The content of the plain.
        /// </value>
        public string plain_content { get; set; }

        /// <summary>
        /// Gets or sets the subject.
        /// </summary>
        /// <value>
        /// The subject.
        /// </value>
        public string subject { get; set; }
    }

    
}
