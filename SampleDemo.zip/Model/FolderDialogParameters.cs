﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// FolderDialogParameters Class
    /// </summary>
    public class FolderDialogParameters
    {
        /// <summary>
        /// Gets or sets the name of the folder.
        /// </summary>
        /// <value>
        /// The name of the folder.
        /// </value>
        public string FolderName { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [show new folder button].
        /// </summary>
        /// <value>
        /// <c>true</c> if [show new folder button]; otherwise, <c>false</c>.
        /// </value>
        public bool ShowNewFolderButton { get; set; }
    }
}