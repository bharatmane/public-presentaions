﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Expense Category Class
    /// </summary>
    public class CrewExpenseCategory : BaseViewModel
    {
        /// <summary>
        /// The identifier
        /// </summary>
        private int _id;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id
        {
            get { return _id; }
            set { Set(() => Id, ref _id, value); }
        }

        /// <summary>
        /// The name
        /// </summary>
        private string _name;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name
        {
            get { return _name; }
            set { Set(() => Name, ref _name, value); }
        }

        /// <summary>
        /// The seaferer category
        /// </summary>
        private bool _seafererCategory;

        /// <summary>
        /// Gets or sets a value indicating whether [seaferer category].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [seaferer category]; otherwise, <c>false</c>.
        /// </value>
        public bool SeafererCategory
        {
            get { return _seafererCategory; }
            set { Set(() => SeafererCategory, ref _seafererCategory, value); }
        }

        /// <summary>
        /// The office category
        /// </summary>
        private bool _officeCategory;

        /// <summary>
        /// Gets or sets a value indicating whether [office category].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [office category]; otherwise, <c>false</c>.
        /// </value>
        public bool OfficeCategory
        {
            get { return _officeCategory; }
            set { Set(() => OfficeCategory, ref _officeCategory, value); }
        }

        /// <summary>
        /// The created on
        /// </summary>
        private DateTime? _createdOn;

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn
        {
            get { return _createdOn; }
            set { Set(() => CreatedOn, ref _createdOn, value); }
        }

        /// <summary>
        /// The updated on
        /// </summary>
        private DateTime? _updatedOn;

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn
        {
            get { return _updatedOn; }
            set { Set(() => UpdatedOn, ref _updatedOn, value); }
        }

    }
}
