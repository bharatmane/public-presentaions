﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Detail Id Request
    /// </summary>
    public class DetailIdRequest
    {
        /// <summary>
        /// Gets or sets the detail identifier.
        /// </summary>
        /// <value>
        /// The detail identifier.
        /// </value>
        public int DetailId { get; set; }
    }
}
