﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Status type enum
    /// </summary>
    public enum StatusType
    {
        /// <summary>
        /// The type1
        /// </summary>
        Type1 = 0,

        /// <summary>
        /// The type2
        /// </summary>
        Type2 = 1
    }

    /// <summary>
    /// Media storage enum
    /// </summary>
    public enum MediaStorageType
    {
        /// <summary>
        /// The amazon s3
        /// </summary>
        AmazonS3 = 0,
        /// <summary>
        /// The azure BLOB
        /// </summary>
        AzureBlob = 1
    }

    /// <summary>
    /// 
    /// </summary>
    public enum ExpenseDocumentCloudUploadStatus
    {
        /// <summary>
        /// The processing
        /// </summary>
        Processing = 0,
        /// <summary>
        /// The in cloud
        /// </summary>
        InCloud = 1,
        /// <summary>
        /// The failed
        /// </summary>
        Failed = 2,
        /// <summary>
        /// The deleted
        /// </summary>
        Deleted = 4
    }
}
