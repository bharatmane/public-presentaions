﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// DTO for CrewExpenseHeaderRequest
    /// </summary>
    public class CrewExpenseHeaderRequest
    {
        /// <summary>
        /// Gets or sets the expense header identifier.
        /// </summary>
        /// <value>
        /// The expense header identifier.
        /// </value>
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public int ClientId { get; set; }
        /// <summary>
        /// Gets or sets the fullname.
        /// </summary>
        /// <value>
        /// The fullname.
        /// </value>
        public string Fullname { get; set; }
        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }
        /// <summary>
        /// Gets or sets the accounting identifier.
        /// </summary>
        /// <value>
        /// The accounting identifier.
        /// </value>
        public string AccountingId { get; set; }
        /// <summary>
        /// Gets or sets the servicerecord identifier.
        /// </summary>
        /// <value>
        /// The servicerecord identifier.
        /// </value>
        public string ServiceRecordId { get; set; }
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }
        /// <summary>
        /// Gets or sets the assignment description.
        /// </summary>
        /// <value>
        /// The assignment description.
        /// </value>
        public string AssignmentDescription { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the status identifier.
        /// </summary>
        /// <value>
        /// The status identifier.
        /// </value>
        public int? StatusId { get; set; }

        /// <summary>
        /// Gets or sets the status short code.
        /// </summary>
        /// <value>
        /// The status short code.
        /// </value>
        public string StatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the status description.
        /// </summary>
        /// <value>
        /// The status description.
        /// </value>
        public string StatusDescription { get; set; }

        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public int? CategoryId { get; set; }
        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>
        /// The comments.
        /// </value>
        public string Comments { get; set; }
        /// <summary>
        /// Gets or sets the total value.
        /// </summary>
        /// <value>
        /// The total value.
        /// </value>
        public decimal? TotalValue { get; set; }
        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        public string Currency { get; set; }
        /// <summary>
        /// Gets or sets the submitted date.
        /// </summary>
        /// <value>
        /// The submitted date.
        /// </value>
        public DateTime? SubmittedDate { get; set; }
        /// <summary>
        /// Gets or sets the processing date.
        /// </summary>
        /// <value>
        /// The processing date.
        /// </value>
        public DateTime? ProcessingDate { get; set; }
        /// <summary>
        /// Gets or sets the approval date.
        /// </summary>
        /// <value>
        /// The approval date.
        /// </value>
        public DateTime? ApprovalDate { get; set; }
        /// <summary>
        /// Gets or sets the paid date.
        /// </summary>
        /// <value>
        /// The paid date.
        /// </value>
        public DateTime? PaidDate { get; set; }
        /// <summary>
        /// Gets or sets the detail items.
        /// </summary>
        /// <value>
        /// The detail items.
        /// </value>
        public int DetailItems { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
        /// <summary>
        /// Gets or sets the expense details.
        /// </summary>
        /// <value>
        /// The expense details.
        /// </value>
        public List<CrewExpenseDetails> ExpenseDetails { get; set; }

        /// <summary>
        /// Gets or sets the type of the expense payment method.
        /// </summary>
        /// <value>
        /// The type of the expense payment method.
        /// </value>
        public int? PaymentType { get; set; }

        /// <summary>
        /// Gets or sets the payment method identifier.
        /// </summary>
        /// <value>
        /// The payment method identifier.
        /// </value>
        public string PaymentMethodId { get; set; }

        /// <summary>
        /// Gets or sets the PCN.
        /// </summary>
        /// <value>
        /// The PCN.
        /// </value>
        public string PCN { get; set; }

        /// <summary>
        /// Gets or sets the crew rank.
        /// </summary>
        /// <value>
        /// The crew rank.
        /// </value>
        public string CrewRank { get; set; }
    }
}
