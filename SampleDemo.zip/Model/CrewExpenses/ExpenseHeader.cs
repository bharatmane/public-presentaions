﻿using System;
using System.Collections.Generic;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Expense header Class
    /// </summary>
    public class ExpenseHeader 
    {

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public int ClientId { get; set; }

        /// <summary>
        /// Gets or sets the fullname.
        /// </summary>
        /// <value>
        /// The fullname.
        /// </value>
        public string Fullname { get; set; }

        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the accounting identifier.
        /// </summary>
        /// <value>
        /// The accounting identifier.
        /// </value>
        public string AccountingId { get; set; }

        /// <summary>
        /// Gets or sets the servicerecord identifier.
        /// </summary>
        /// <value>
        /// The servicerecord identifier.
        /// </value>
        public string ServicerecordId { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the status identifier.
        /// </summary>
        /// <value>
        /// The status identifier.
        /// </value>
        public int? StatusId { get; set; }

        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public int? CategoryId { get; set; }

        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>
        /// The comments.
        /// </value>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the total value.
        /// </summary>
        /// <value>
        /// The total value.
        /// </value>
        public decimal? TotalValue { get; set; }

        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets the submitted date.
        /// </summary>
        /// <value>
        /// The submitted date.
        /// </value>
        public DateTime? SubmittedDate { get; set; }

        /// <summary>
        /// Gets or sets the processing date.
        /// </summary>
        /// <value>
        /// The processing date.
        /// </value>
        public DateTime? ProcessingDate { get; set; }

        /// <summary>
        /// Gets or sets the approval date.
        /// </summary>
        /// <value>
        /// The approval date.
        /// </value>
        public DateTime? ApprovalDate { get; set; }

        /// <summary>
        /// Gets or sets the paid date.
        /// </summary>
        /// <value>
        /// The paid date.
        /// </value>
        public DateTime? PaidDate { get; set; }

        /// <summary>
        /// Gets the detail items.
        /// </summary>
        /// <value>
        /// The detail items.
        /// </value>
        public int DetailItems { get; set; }
        

        /// <summary>
        /// Gets or sets a value indicating whether this instance is cancelled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is cancelled; otherwise, <c>false</c>.
        /// </value>
        public bool IsCancelled { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the assignment description.
        /// </summary>
        /// <value>
        /// The assignment description.
        /// </value>
        public string AssignmentDescription { get; set; }

        /// <summary>
        /// Gets or sets the payment method identifier.
        /// </summary>
        /// <value>
        /// The payment method identifier.
        /// </value>
        public int? PaymentType { get; set; }

        /// <summary>
        /// Gets or sets the payment method identifier.
        /// </summary>
        /// <value>
        /// The payment method identifier.
        /// </value>
        public string PaymentMethodId { get; set; }
    }
}
