﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Header Id List Request Class
    /// </summary>
    public class HeaderIdListRequest
    {
        /// <summary>
        /// Gets or sets the header ids.
        /// </summary>
        /// <value>
        /// The header ids.
        /// </value>
        public List<int> HeaderIds { get; set; }
    }
}
