﻿using System;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Approved Crew Expense Line Detail Request
    /// </summary>
    public class ApprovedCrewExpenseLineDetailRequest
    {
        /// <summary>
        /// Gets or sets the header identifier.
        /// </summary>
        /// <value>
        /// The header identifier.
        /// </value>
        public int HeaderId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public int? CategoryId { get; set; }

        /// <summary>
        /// Gets or sets the account identifier.
        /// </summary>
        /// <value>
        /// The account identifier.
        /// </value>
        public string AccountId { get; set; }

        /// <summary>
        /// Gets or sets the account description.
        /// </summary>
        /// <value>
        /// The account description.
        /// </value>
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets the expense date.
        /// </summary>
        /// <value>
        /// The expense date.
        /// </value>
        public DateTime? ExpenseDate { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value.
        /// </value>
        public decimal? Value { get; set; }

        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets the user notes.
        /// </summary>
        /// <value>
        /// The user notes.
        /// </value>
        public string UserNotes { get; set; }
    }
}
