﻿using Newtonsoft.Json;
using System;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// 
    /// </summary>
    public class ExpenseClient
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the type of the media storage.
        /// </summary>
        /// <value>
        /// The type of the media storage.
        /// </value>
        [JsonIgnore]
        public MediaStorageType MediaStorageType { get; set; }

        /// <summary>
        /// Gets or sets the media storage configuration.
        /// </summary>
        /// <value>
        /// The media storage configuration.
        /// </value>
        [JsonIgnore]
        public string MediaStorageConfiguration { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
    }
}
