﻿using System;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Crew expense status class
    /// </summary>
    public class CrewExpenseStatus
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public StatusType Type { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="CrewExpenseStatus"/> is validating.
        /// </summary>
        /// <value>
        ///   <c>true</c> if validating; otherwise, <c>false</c>.
        /// </value>
        public bool Validating { get; set; }

        /// <summary>
        /// Gets or sets the order.
        /// </summary>
        /// <value>
        /// The order.
        /// </value>
        public int Order { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
    }
}
