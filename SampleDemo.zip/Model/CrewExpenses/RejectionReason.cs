﻿using System;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Class For Rejection Reasons
    /// </summary>
    public class RejectionReason
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [allow resubmission].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [allow resubmission]; otherwise, <c>false</c>.
        /// </value>
        public bool AllowResubmission { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [rejection type].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [rejection type]; otherwise, <c>false</c>.
        /// </value>
        public bool RejectionType { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
    }
}
