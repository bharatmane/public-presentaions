﻿using System.IO;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Crew Expense Document Download Response
    /// </summary>
    public class CrewExpenseDocumentDownloadResponse
    {

        /// <summary>
        /// Gets or sets the byte stream.
        /// </summary>
        /// <value>
        /// The byte stream.
        /// </value>
        public Stream ByteStream { get; set; }

        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>
        /// The name of the file.
        /// </value>
        public string FileName { get; set; }
    }
}
