﻿using System;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Crew Expense Details Attachments
    /// </summary>
    public class CrewExpenseDetailsAttachments
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the expense detail identifier.
        /// </summary>
        /// <value>
        /// The expense detail identifier.
        /// </value>
        public int ExpenseDetailId { get; set; }
        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public int ClientId { get; set; }
        /// <summary>
        /// Gets or sets the image sequence.
        /// </summary>
        /// <value>
        /// The image sequence.
        /// </value>
        public int? ImageSequence { get; set; }
        /// <summary>
        /// Gets or sets the size of the file.
        /// </summary>
        /// <value>
        /// The size of the file.
        /// </value>
        public long? FileSize { get; set; }
        /// <summary>
        /// Gets or sets the file key.
        /// </summary>
        /// <value>
        /// The file key.
        /// </value>
        public string FileKey { get; set; }
        /// <summary>
        /// Gets or sets the display filename.
        /// </summary>
        /// <value>
        /// The display filename.
        /// </value>
        public string DisplayFilename { get; set; }
        /// <summary>
        /// Gets or sets the type of the file.
        /// </summary>
        /// <value>
        /// The type of the file.
        /// </value>
        public string FileType { get; set; }
        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }
        /// <summary>
        /// Gets or sets the version identifier.
        /// </summary>
        /// <value>
        /// The version identifier.
        /// </value>
        public string VersionId { get; set; }
        /// <summary>
        /// Gets or sets the cloud status.
        /// </summary>
        /// <value>
        /// The cloud status.
        /// </value>
        public ExpenseDocumentCloudUploadStatus? CloudStatus { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the uploaded on.
        /// </summary>
        /// <value>
        /// The uploaded on.
        /// </value>
        public DateTime? UploadedOn { get; set; }
        /// <summary>
        /// Gets or sets the base64 file.
        /// </summary>
        /// <value>
        /// The base64 file.
        /// </value>
        public string Base64File { get; set; }
        /// <summary>
        /// Gets or sets the filename.
        /// </summary>
        /// <value>
        /// The filename.
        /// </value>
        public string Filename { get; set; }

        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>
        /// The file path.
        /// </value>
        public string FilePath { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is cancelled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is cancelled; otherwise, <c>false</c>.
        /// </value>
        public bool IsCancelled { get; set; }
    }
}
