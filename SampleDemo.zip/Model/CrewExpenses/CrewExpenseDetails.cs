﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    public class CrewExpenseDetails
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public int ClientId { get; set; }
        /// <summary>
        /// Gets or sets the expense header identifier.
        /// </summary>
        /// <value>
        /// The expense header identifier.
        /// </value>
        public int ExpenseHeaderId { get; set; }
        /// <summary>
        /// Gets or sets the category identifier.
        /// </summary>
        /// <value>
        /// The category identifier.
        /// </value>
        public int? CategoryId { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value.
        /// </value>
        public decimal Value { get; set; }
        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        public string Currency { get; set; }
        /// <summary>
        /// Gets or sets the country code.
        /// </summary>
        /// <value>
        /// The country code.
        /// </value>
        public string CountryCode { get; set; }
        /// <summary>
        /// Gets or sets the user notes.
        /// </summary>
        /// <value>
        /// The user notes.
        /// </value>
        public string UserNotes { get; set; }
        /// <summary>
        /// Gets or sets the office notes.
        /// </summary>
        /// <value>
        /// The office notes.
        /// </value>
        public string OfficeNotes { get; set; }
        /// <summary>
        /// Gets or sets the status identifier.
        /// </summary>
        /// <value>
        /// The status identifier.
        /// </value>
        public int? StatusId { get; set; }

        /// <summary>
        /// Gets or sets the status short code.
        /// </summary>
        /// <value>
        /// The status short code.
        /// </value>
        public string StatusShortCode { get; set; }

        /// <summary>
        /// Gets or sets the status description.
        /// </summary>
        /// <value>
        /// The status description.
        /// </value>
        public string StatusDescription { get; set; }

        /// <summary>
        /// Gets or sets the rejection identifier.
        /// </summary>
        /// <value>
        /// The rejection identifier.
        /// </value>
        public int? RejectionId { get; set; }
        /// <summary>
        /// Gets or sets the approved on.
        /// </summary>
        /// <value>
        /// The approved on.
        /// </value>
        public DateTime? ApprovedOn { get; set; }
        /// <summary>
        /// Gets or sets the rejected on.
        /// </summary>
        /// <value>
        /// The rejected on.
        /// </value>
        public DateTime? RejectedOn { get; set; }
        /// <summary>
        /// Gets or sets the expense images items.
        /// </summary>
        /// <value>
        /// The expense images items.
        /// </value>
        public int ExpenseImagesItems { get; set; }
        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is cancelled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is cancelled; otherwise, <c>false</c>.
        /// </value>
        public bool IsCancelled { get; set; }
        /// <summary>
        /// Gets or sets the expense date.
        /// </summary>
        /// <value>
        /// The expense date.
        /// </value>
        public DateTime? ExpenseDate { get; set; }
        /// <summary>
        /// Gets or sets the expense category desc.
        /// </summary>
        /// <value>
        /// The expense category desc.
        /// </value>
        public string ExpenseCategoryDesc { get; set; }
        /// <summary>
        /// Gets or sets the expense images.
        /// </summary>
        /// <value>
        /// The expense images.
        /// </value>
        public List<CrewExpenseDetailsAttachments> ExpenseImages { get; set; }
    }
}
