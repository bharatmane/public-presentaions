﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Line Detail Action Reason Request Class
    /// </summary>
    public class LineDetailActionReasonRequest
    {
        /// <summary>
        /// Gets or sets the expense detail ids.
        /// </summary>
        /// <value>
        /// The expense detail ids.
        /// </value>
        public List<int> ExpenseDetailIds { get; set; }
        /// <summary>
        /// Gets or sets the reason identifier.
        /// </summary>
        /// <value>
        /// The reason identifier.
        /// </value>
        public int ReasonId { get; set; }
        /// <summary>
        /// Gets or sets the remark.
        /// </summary>
        /// <value>
        /// The remark.
        /// </value>
        public string Remark { get; set; }
    }
}
