﻿using Newtonsoft.Json;
using System;
using System.Linq;
using System.Windows.Media;
using VShips.DataServices.Shared.Enumerations.Document;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.CrewExpenses
{
    /// <summary>
    /// Expense Image Class
    /// </summary>
    public class ExpenseImage : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the expense detail identifier.
        /// </summary>
        /// <value>
        /// The expense detail identifier.
        /// </value>
        public int ExpenseDetailId { get; set; }

        /// <summary>
        /// Gets or sets the client identifier.
        /// </summary>
        /// <value>
        /// The client identifier.
        /// </value>
        public int? ClientId { get; set; }

        /// <summary>
        /// Gets or sets the image sequence.
        /// </summary>
        /// <value>
        /// The image sequence.
        /// </value>
        public int? ImageSequence { get; set; }

        /// <summary>
        /// Gets or sets the size of the file.
        /// </summary>
        /// <value>
        /// The size of the file.
        /// </value>
        private long? _fileSize;

        /// <summary>
        /// Gets or sets the size of the file.
        /// </summary>
        /// <value>
        /// The size of the file.
        /// </value>
        public long? FileSize
        {
            get { return _fileSize; }
            set { Set(() => FileSize, ref _fileSize, value); }
        }


        /// <summary>
        /// Gets or sets the file key.
        /// </summary>
        /// <value>
        /// The file key.
        /// </value>
        public string FileKey { get; set; }

        /// <summary>
        /// Gets the display filename.
        /// </summary>
        /// <value>
        /// The display filename.
        /// </value>
        private string _displayFilename;

        /// <summary>
        /// Gets or sets the display name of the file.
        /// </summary>
        /// <value>
        /// The display name of the file.
        /// </value>
        public string DisplayFilename
        {
            get { return _displayFilename; }
            set { Set(() => DisplayFilename, ref _displayFilename, value); }
        }


        /// <summary>
        /// Gets or sets the type of the file.
        /// </summary>
        /// <value>
        /// The type of the file.
        /// </value>
        public string FileType { get; set; }

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the version identifier.
        /// </summary>
        /// <value>
        /// The version identifier.
        /// </value>
        public string VersionId { get; set; }

        /// <summary>
        /// Gets or sets the cloud status.
        /// </summary>
        /// <value>
        /// The cloud status.
        /// </value>
        public CloudUploadStatus? CloudStatus { get; set; }

        /// <summary>
        /// Gets or sets the uploaded on.
        /// </summary>
        /// <value>
        /// The uploaded on.
        /// </value>
        public DateTime? UploadedOn { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is cancelled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is cancelled; otherwise, <c>false</c>.
        /// </value>
        public bool IsCancelled { get; set; }

        /// <summary>
        /// Gets or sets the upload unique identifier.
        /// </summary>
        /// <value>
        /// The upload unique identifier.
        /// </value>
        [JsonIgnore]
        public Guid UploadGuid { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the client.
        /// </summary>
        /// <value>
        /// The client.
        /// </value>
        [JsonIgnore]
        public ExpenseClient Client { get; set; }

        /// <summary>
        /// The thumbnail.
        /// </summary>
        private ImageSource _thumbnail;

        /// <summary>
        /// Gets or sets the thumbnail.
        /// </summary>
        /// <value>
        /// The thumbnail.
        /// </value>
        public ImageSource Thumbnail
        {
            get { return _thumbnail; }
            set { Set(() => Thumbnail, ref _thumbnail, value); }
        }
    }
}
