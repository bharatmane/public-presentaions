﻿using System;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Represents a message to display on the UI as apposed to ma dialog.
    /// </summary>
    public interface IUIMessage
    {
        /// <summary>
        /// Shows the message on the UI.
        /// </summary>
        /// <param name="messageType">The type of message to show based on the operation.</param>
        /// <param name="message">The message to show.</param>
        void Show(MessageType messageType, object message);

        /// <summary>
        /// Shows the specified message type.
        /// </summary>
        /// <param name="messageType">Type of the message.</param>
        /// <param name="message">The message.</param>
        /// <param name="buttonContent">Content of the button.</param>
        /// <param name="relayCommand">The relay command.</param>
        void Show(MessageType messageType, object message, string buttonContent, Action relayCommand);
    }
}
