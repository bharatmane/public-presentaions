﻿#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class Wind
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double SpeedMs { get; set; }
        public int SpeedBeaufort { get; set; }
        public int Direction { get; set; }
    }
}