﻿using System;
using System.ComponentModel;
using System.Linq;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Parameters used to create an file dialog.
    /// </summary>
    public class FileDialogParameters
    {
        /// <summary>
        /// The title of the dialog.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// The directory shown when the dialog opens.
        /// </summary>
        public string InitialDirectory { get; set; }

        /// <summary>
        /// A file filter.
        /// </summary>
        public string Filter { get; set; }

        /// <summary>
        /// Gets or sets the index of the filter.
        /// </summary>
        /// <value>
        /// The index of the filter.
        /// </value>
        [DefaultValue(1)]
        public int FilterIndex { get; set; }

        /// <summary>
        /// Gets the applicable file extensions.
        /// </summary>
        /// <value>
        /// The applicable file extensions.
        /// </value>
        public string[] ApplicableFileExtensions
        {
            get
            {
                return Filter.Split('|').Where(x => x.StartsWith("*.")).Select(x => x.Replace("*", "").ToUpper().Trim()).ToArray();
            }
        }

        /// <summary>
        /// If multi file selection is allowed. 
        /// </summary>
        public bool Multiselect { get; set; }

        /// <summary>
        /// The return filename of the dialog. this is set when the dialog closes.
        /// Use this when <see cref="Multiselect"/> is set to false.
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// The returned filenames of the dialog set when the dialog closes.
        /// Use this when <see cref="Multiselect"/> is set to true.
        /// </summary>
        public string[] FileNames { get; set; }

        /// <summary>
        /// The default contructor for FileDialogParameters.
        /// </summary>
        /// <param name="isSetInitialDirectory">if set to <c>true</c> [is initial directory not set].</param>
        public FileDialogParameters(bool isSetInitialDirectory = true)
        {
            if (isSetInitialDirectory)
            {
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            }
        }

    }
}
