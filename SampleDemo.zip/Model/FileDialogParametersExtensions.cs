﻿using System;
using System.IO;
using System.Linq;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Extension methods to validate a file based on a dialogs filters.
    /// </summary>
    public static class FileDialogParametersExtensions
    {
        /// <summary>
        /// Validates the selected file.
        /// </summary>
        /// <param name="param">The filename.</param>
        /// <returns>Single value to type bool</returns>
        public static bool ValidateSelectedFileForExtension(this FileDialogParameters param)
        {
            var applicableFileExtensions = param.ApplicableFileExtensions;
            if (applicableFileExtensions != null && applicableFileExtensions.Any())
            {
                return !String.IsNullOrWhiteSpace(param.FileName) && applicableFileExtensions.Contains(Path.GetExtension(param.FileName).ToUpper());
            }
            return true;
        }

        /// <summary>
        /// Validates the selected files.
        /// </summary>
        /// <param name="param">The filenames.</param>
        /// <returns>Single value to type bool</returns>
        public static bool ValidateSelectedFilesForExtension(this FileDialogParameters param)
        {
            var result = true;
            var applicableFileExtensions = param.ApplicableFileExtensions;
            if (applicableFileExtensions != null && applicableFileExtensions.Any())
            {
                result = param.FileNames.All(x =>
                {
                    var extension = Path.GetExtension(x);
                    return extension != null && applicableFileExtensions.Contains(extension.ToUpper());
                });
            }
            return result;
        }

        /// <summary>
        /// Determines whether [is filein use].
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns>Single string message.</returns>
        public static string IsFileinUse(this FileDialogParameters param)
        {
            string message = "";
            if (param != null && !string.IsNullOrWhiteSpace(param.FileName))
            {
                if (File.Exists(param.FileName))
                {
                    FileStream stream = null;
                    FileInfo file = new FileInfo(param.FileName);
                    try
                    {
                        stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
                    }
                    catch (IOException iox)
                    {
                        var loggerService = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<Services.ILoggerService>();
                        if (loggerService != null)
                        {
                            loggerService.ErrorWithoutAlert(iox.Message, iox);
                        }
                        if (iox.Message.Contains(Messages.UsedByAnotherProcessMessage))
                        {
                            message = message + string.Format(Messages.FileAlreaduInUseMessage, param.FileName);
                        }
                        else
                        {
                            message = message + string.Format(Messages.FileNotAccessibleMessage, param.FileName);
                        }
                    }
                    catch (Exception ex)
                    {
                        //the file is unavailable because it is:
                        //still being written to
                        //or being processed by another thread
                        //or does not exist (has already been processed)
                        var loggerService = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<Services.ILoggerService>();
                        if (loggerService != null)
                        {
                            loggerService.ErrorWithoutAlert(ex.Message, ex);
                        }
                        message = message + string.Format(Messages.FileNotAccessibleMessage, param.FileName);
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                    }
                }
                else
                {
                    message = message + string.Format(Messages.FileDoesNotExistsMessage, param.FileName);
                }
            }
            return message;
        }

    }
}