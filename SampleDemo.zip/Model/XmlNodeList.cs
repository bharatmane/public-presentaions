﻿using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Use to deserialise navigation items.
    /// </summary>
    [XmlRoot(ElementName = "Groups")]
    public class XmlNodeItemList : ObservableCollection<NavigationGroup>
    {
    }
}
