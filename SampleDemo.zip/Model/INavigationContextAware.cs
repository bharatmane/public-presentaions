﻿using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// <para>
    /// An interface used in the <see cref="INavigationService"/>.
    /// </para>
    /// <para>
    /// Can be used on a viewmodel that participates in navigation allowing 
    /// the navigation service to communicate to it during the navigation sequence. 
    /// </para>
    /// </summary>
    public interface INavigationContextAware
    {
        /// <summary>
        /// Called when navigation occurs on the viewmodel
        /// </summary>
        /// <remarks>
        /// Can be used to provide hooks to any services or resources
        /// and to initialise any code
        /// </remarks>
        /// <param name="naviagtionInfo">Infomation concerning navigation.</param>
        /// <param name="parameter">A parameter passed during navigation</param>        
        void NavigateTo(INavigationInfo naviagtionInfo, object parameter);

        /// <summary>
        /// Called whenever the viewmodel is navigating away
        /// </summary>
        /// <remarks>
        /// Can be used to clean up any registrations, event hooks or un-managed resources
        /// </remarks>
        void NavigateFrom();
        
    }
}
