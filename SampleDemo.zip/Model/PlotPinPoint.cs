﻿using System.Windows.Media;
using Telerik.Windows.Controls.Map;
using VShips.Contracts.DtoClasses.NoonReportNavigationTypes.PoslistTypes;
using VShips.DataServices.Shared.Contracts.Common;

#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class PlotPinPoint
    {
        public Location Location { get; set; }
        public double BaseZoomLevel { get; set; }
        public ZoomRange ZoomRange { get; set; }
        public string ToolTip { get; set; }
        public string FillColour { get; set; }
        public string NoonReportConsumptionColour { get; set; }
        public string NoonReportSpeedColour { get; set; }
        public string NoonReportWeatherColour { get; set; }
        public object Tag { get; set; }
    }
}