﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media.Imaging;
#pragma warning disable 1591


namespace VShips.Framework.Common.Model
{
    public class CachedWeatherTile
    {
        public string Id { get; set; }
        public WeatherTypeOpenWeather RequestedWeatherType { get; set; }
        public DateTime WeatherTime { get; set; }
        public int ZoomLevel { get; set; }
        public Point TileRef { get; set; }
        public BitmapImage WeatherBitmapImage { get; set; }
    }


    public enum WeatherTypeOpenWeather
    {
        [Description("None")]
        None,

        [Description("Wind Speed")]
        WS10,

        [Description("Wind Speed Dir")]
        WND,

        [Description("Atmospheric Pressure")]
        APM,

        [Description("Air Temperature")]
        TA2,

        [Description("CloudCover")]
        CL,
    }

}
