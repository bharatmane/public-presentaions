﻿using System.Collections.Generic;
using Microsoft.Practices.Prism.Modularity;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An extended version of the prism module catalogue.
    /// </summary>
    public class ModuleCatologExtended : ModuleCatalog, IModuleCatologExtended
    {
        private readonly Dictionary<string, ModuleInfoExtended> _extendedModules;
        /// <summary>
        /// Gets all the modules including framework required modules which don't need to be loaded.
        /// </summary>
        public Dictionary<string, ModuleInfoExtended> ExtendedModules
        {
            get { return _extendedModules; }
        }

        /// <summary>
        /// The default constructor.
        /// </summary>
        public ModuleCatologExtended() 
        {
            _extendedModules = new Dictionary<string, ModuleInfoExtended>();
        }

        public override void AddModule(Microsoft.Practices.Prism.Modularity.ModuleInfo moduleInfo)
        {
            var extInfo = moduleInfo as ModuleInfoExtended;
            if (extInfo != null)
            {
                if (!extInfo.IsRequired)
                {
                    base.AddModule(moduleInfo);
                }
                _extendedModules.Add(moduleInfo.ModuleName, extInfo);
            }
        }
    }

    /// <summary>
    /// Represents an extended version of the prism module catalogue.
    /// </summary>
    public interface IModuleCatologExtended : IModuleCatalog
    {
        /// <summary>
        /// A collection of frmaework modules that are alread loaded by the catalogue.
        /// </summary>
        Dictionary<string, ModuleInfoExtended> ExtendedModules { get; }
    }
}
