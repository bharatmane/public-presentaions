﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Types of debug messages that can be sent.
    /// </summary>
    public enum DebugMessageType
    {
        /// <summary>
        /// Information.
        /// </summary>
        DebugInfo = 0,

        /// <summary>
        /// Warning.
        /// </summary>
        DebugWarning = 1,

        /// <summary>
        /// Error.
        /// </summary>
        DebugError = 2
    }
}
