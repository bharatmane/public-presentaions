﻿using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Represents navigation within a module.
    /// </summary>
    [XmlType(TypeName = "Module")]
    public class NavigationItem
    {
        /// <summary>
        /// The default constructor for naviagtion item.
        /// </summary>
        public NavigationItem()
        {
            Items = new ObservableCollection<NavigationItem>();
            CanNavigateNew = false;
            IsItemClickable = true;
            IsNavigateInPopup = false;
            IsNavigateNew = true;
            IsParameterPresent = false;
        }

        /// <summary>
        /// Thge name of the item.
        /// </summary>
        [XmlElement("ModuleName")]
        public string ModuleName
        {
            get;
            set;
        }

        /// <summary>
        /// The name of the view the item represents.
        /// </summary>
        [XmlElement("DefaultViewName")]
        public string DefaultViewName
        {
            get;
            set;
        }

        /// <summary>
        /// The tooltip of the item.
        /// </summary>
        [XmlElement("ButtonTooltip")]
        public string Tooltip
        {
            get;
            set;
        }

        /// <summary>
        /// The image of the item.
        /// </summary>
        [XmlElement("ButtonImage")]
        public string ImageSource
        {
            get;
            set;
        }

        /// <summary>
        /// The display text of the item.
        /// </summary>
        [XmlElement("ButtonText")]
        public string Text
        {
            get;
            set;
        }

        /// <summary>
        /// If the item should be displayed.
        /// </summary>
        [XmlElement("IsShown")]
        public bool IsShown
        {
            get;
            set;
        }

        /// <summary>
        /// If the item should be displayed in popup.
        /// </summary>
        [XmlElement("IsNavigateInPopup")]
        public bool IsNavigateInPopup
        {
            get;
            set;
        }

        /// <summary>
        /// If the item should be displayed in new tab.
        /// </summary>
        [XmlElement("IsNavigateNew")]
        public bool IsNavigateNew
        {
            get;
            set;
        }

        /// <summary>
        /// If the item should be displayed.
        /// </summary>
        [XmlElement("CanNavigateNew")]
        public bool CanNavigateNew
        {
            get;
            set;
        }

        /// <summary>
        /// If the item has parameters.
        /// </summary>
        [XmlElement("IsParameterPresent")]
        public bool IsParameterPresent
        {
            get;
            set;
        }

        /// <summary>
        /// If the item command parameter.
        /// </summary>
        [XmlElement("CommandParameter")]
        public object CommandParameter
        {
            get;
            set;
        }

        /// <summary>
        /// If the item is clickable.
        /// </summary>
        [XmlElement("IsItemClickable")]
        public bool IsItemClickable
        {
            get;
            set;
        }

        /// <summary>
        /// The sub navigation items.
        /// </summary>
        [XmlElement("Items")]
        public ObservableCollection<NavigationItem> Items
        {
            get;
            set;
        }
    }
}
