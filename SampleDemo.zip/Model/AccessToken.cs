﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Return type for the Token of a Web Api service. 
    /// </summary>
    public class AccessToken
    {
        public string Url { get; set; }
        public string Token { get; set; }
        public string TokenType { get; set; }
        public int ExpiresIn { get; set; }
        public string RefreshToken { get; set; }
        public DateTime Issued { get; set; }

        public bool IsExpired
        {
            get { return ExpiresIn > 0 && !string.IsNullOrEmpty(RefreshToken) ? Issued.AddSeconds(ExpiresIn) < DateTime.Now : false; }
        }
    }
}
