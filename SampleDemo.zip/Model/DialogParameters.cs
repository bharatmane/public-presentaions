﻿using System;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Structure that holds all parameters for customizing dialog window. 
    /// Used in the <see cref="IDialogService"/>.
    /// </summary>
    public class DialogParameters
    {
        /// <summary>
        /// Gets or sets the content to be displayed. 
        /// </summary> 
        /// <value>
        /// The content to be displayed.
        /// </value>
        public object Content { get; set; }

        /// <summary>
        /// Gets or sets the object to appear in the title bar. 
        /// </summary> 
        /// <value>
        /// The object to appear in the title bar.
        /// </value>
        public object Header { get; set; }
        
        /// <summary>
        /// Gets or sets the method that will be called when the Closed event of the Window is fired. 
        /// </summary> 
        /// <value>
        /// The method that will be called when the Closed event of the Window is fired.
        /// </value> 
        public Action<bool?> Closed { get; set; }

        /// <summary>
        /// Gets or sets the method that will be called when the Opened event of the Window is fired.
        /// </summary>
        /// <value>
        /// The method that will be called when the Opened event of the Window is fired.
        /// </value>
        public Action Opened { get; set; }

        /// <summary>
        /// Gets or sets the content in the OK button.
        /// </summary>
        /// <value>
        /// The content in the OK button.
        /// </value>
        public object OkButtonContent { get; set; }

        /// <summary>
        /// Gets or sets the content in the Cancel button.
        /// </summary>
        /// <value>
        /// The content in the Cancel button.
        /// </value>
        public object CancelButtonContent { get; set; }

        /// <summary>
        /// Gets or sets the content of the icon area in the title bar.
        /// </summary>
        /// <value>
        /// The content of the icon area in the title bar.
        /// </value>
        public object IconContent { get; set; }
        
        /// <summary>
        /// Gets or sets the default prompt result value shown in the Prompt dialog window.
        /// </summary>
        /// <value>
        /// The default prompt result value shown in the Prompt dialog window.
        /// </value>
        public string DefaultPromptResultValue { get; set; }

        /// <summary>
        /// Gets or sets the Owner of the Dialog. 
        /// </summary>
        public ContentControl Owner { get; set; }

        /// <summary>
        /// Gets the default parameters for confirm type dialogs.
        /// </summary>
        /// <returns>A new instance of DialogParameters with the appropriate defaults set.</returns>
        public static DialogParameters ConfirmDefault()
        {
            return new DialogParameters
            {
                OkButtonContent = "Yes",
                CancelButtonContent = "No"
            };
        }

        /// <summary>
        /// The default contructor for DialogParameters. 
        /// </summary>
        public DialogParameters()
        {
            Closed = delegate { };
            Opened = delegate { };
            OkButtonContent = "Ok";
            CancelButtonContent = "Cancel";
            Application.Current.Dispatcher.Invoke(() =>
            {
                Owner = Application.Current.MainWindow;
            });
        }
    }
}
