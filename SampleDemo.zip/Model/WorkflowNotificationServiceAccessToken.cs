﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Return type for the Token of the Workflow Notification Service. 
    /// </summary>
    public class WorkflowNotificationServiceToken
    {
        public string Token { get; set; }
        public string TokenType { get; set; }
        public int ExpiresIn { get; set; }
        public string RefreshToken { get; set; }
    }
}
