﻿using VShips.DataServices.Shared.DataAttributes;

namespace VShips.Framework.Common.Model
{

    /// <summary>
    /// Enum for the tree filter drop down.
    /// </summary>
    public enum TreeFilterNodeType
    {
        /// <summary>
        /// The department
        /// </summary>
        [EnumValueData(Name = "Department", KeyValue = "Department")]
        Department,

        /// <summary>
        /// The responsibility
        /// </summary>
        [EnumValueData(Name = "Responsibility", KeyValue = "Responsibility")]
        Responsibility,

        /// <summary>
        /// The order stage
        /// </summary>
        [EnumValueData(Name = "OrderStage", KeyValue = "OrderStage")]
        OrderStage,

        /// <summary>
        /// The order status
        /// </summary>
        [EnumValueData(Name = "OrderStatus", KeyValue = "OrderStatus")]
        OrderStatus,

        /// <summary>
        /// The group .
        /// </summary>
        [EnumValueData(Name = "Group", KeyValue = "Group")]
        Group
    }


    /// <summary>
    /// A generic way to indicate Key Performance Indicators.
    /// </summary>
    public enum KPI
    {
        /// <summary>
        /// Normal performance.
        /// </summary>
        Normal,

        /// <summary>
        /// Good performance.
        /// </summary>
        Good,

        /// <summary>
        /// Better performance
        /// </summary>
        Better,

        /// <summary>
        /// Best performance
        /// </summary>
        Best,

        /// <summary>
        /// Excellent performance
        /// </summary>
        Excellent,

        /// <summary>
        /// Pre warning.
        /// </summary>
        PreWarning,

        /// <summary>
        /// Warning.
        /// </summary>
        Warning,

        /// <summary>
        /// Critical.
        /// </summary>
        Critical,

        /// <summary>
        /// Defines Poor state
        /// </summary>
        Poor
    }

    /// <summary>
    /// Enum for Comparison operator
    /// </summary>
    public enum ComparisonOperator
    {
        /// <summary>
        /// The greater than
        /// </summary>
        GreaterThan = 1,
        /// <summary>
        /// The greater than or equals to
        /// </summary>
        GreaterThanOrEqualsTo = 2,
        /// <summary>
        /// The less than
        /// </summary>
        LessThan = 3,
        /// <summary>
        /// The less than or equals to
        /// </summary>
        LessThanOrEqualsTo = 4,

        /// <summary>
        /// The equals
        /// </summary>
        Equals = 5

    }

    /// <summary>
    /// Enum used to check a page which call the user login form(User authentication form)
    /// </summary>
    public enum ModulesForAdhocAuthentication
    {
        /// <summary>
        /// The authorise model
        /// </summary>
        [EnumValueData(Name = "Authorise", KeyValue = "Authorise")]
        Authorise = 0
    }

    /// <summary>
    /// Enum used to select the type of entity required from Hierarchy Explorer.
    /// </summary>
    public enum HierarchySelection
    {
        /// <summary>
        /// Hierarchy.
        /// </summary>
        [EnumValueData(Name = "Hierarchy", KeyValue = "0")]
        Hierarchy,

        /// <summary>
        /// The Component.
        /// </summary>
        [EnumValueData(Name = "Component", KeyValue = "1")]
        Component,

        /// <summary>
        /// The OneOfBoth.
        /// </summary>
        [EnumValueData(Name = "Hierarchy / Component", KeyValue = "2")]
        OneOfBoth,

        /// <summary>
        /// The MultipleComponent.
        /// </summary>
        [EnumValueData(Name = "Components", KeyValue = "3")]
        MultipleComponent
    }

    /// <summary>
    /// Enums to identify the method to download document(s).
    /// </summary>
    public enum DocumentDownloadServiceMethod
    {
        /// <summary>
        /// The get inv document by coy identifier and voucher
        /// </summary>
        [EnumValueData(Name = "GetInvDocByCoyIdAndVoucher", KeyValue = "GetInvDocByCoyIdAndVoucher")]
        GetInvDocByCoyIdAndVoucher,

        /// <summary>
        /// Custom cloud document download service
        /// </summary>
        [EnumValueData(Name = "GetCustomCloudDocument", KeyValue = "GetCustomCloudDocument")]
        GetCustomCloudDocument,

        /// <summary>
        /// The get photograhs to download.
        /// </summary>
        [EnumValueData(Name = "GetPhotograhsToDownload", KeyValue = "GetPhotograhsToDownload")]
        GetPhotograhsToDownload,

        /// <summary>
        /// The get inspection section rating document paged.
        /// </summary>
        [EnumValueData(Name = "GetInspectionSectionRatingDocumentPaged", KeyValue = "GetInspectionSectionRatingDocumentPaged")]
        GetInspectionSectionRatingDocumentPaged
    }

    public enum ReportLocationFolderType
    {
        [EnumValueData(Name = "Old Path", KeyValue = "OldPath")]
        OldPath = 0,
        [EnumValueData(Name = "New Path", KeyValue = "NewPath")]
        NewPath = 1,
        [EnumValueData(Name = "My Computer", KeyValue = "MyComputer")]
        MyComputer = 2,
    }

    /// <summary>
    /// VettingStatusKPI.
    /// </summary>
    public enum VettingStatusKPI
    {
        /// <summary>
        /// The requested
        /// </summary>
        Requested,
        /// <summary>
        /// The ready for vetting
        /// </summary>
        ReadyForVetting,
        /// <summary>
        /// The vetting in progress
        /// </summary>
        VettingInProgress,
        /// <summary>
        /// The pending sign off
        /// </summary>
        PendingSignOff,
        /// <summary>
        /// The approved
        /// </summary>
        Approved,
        /// <summary>
        /// The rejected
        /// </summary>
        Rejected,

        /// <summary>
        /// The cancelled
        /// </summary>
        Cancelled,

		/// <summary>
		/// The request incomplete
		/// </summary>
		RequestIncomplete
	}

}