﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Structure that holds all parameters for displaying a custom dialog.
    /// Used in the <see cref="IDialogService"/> when you need further control over the buttons to display. 
    /// </summary>
    public class DialogParametersExtended
    {
        private readonly object _content;
        private readonly object _header;
        private readonly ObservableCollection<ButtonCommand> _buttons;
        private readonly string _icon;

        /// <summary>
        /// Gets the content to be displayed. 
        /// </summary> 
        public object Content
        {
            get { return _content; }
        }

        /// <summary>
        /// Gets the object to appear in the title bar. 
        /// </summary> 
        public object Header
        {
            get { return _header; }
        }

        /// <summary>
        /// Gets the buttons that appear in the dialog. 
        /// </summary> 
        public ObservableCollection<ButtonCommand> Buttons
        {
            get { return _buttons; }
        }

        /// <summary>
        /// Gets or sets the Owner of the Dialog. 
        /// </summary>
        public ContentControl Owner { get; set; }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>
        /// The icon.
        /// </value>
        public string Icon
        {
            get { return _icon; }
        }

        /// <summary>
        /// The can close
        /// </summary>
        private bool _canClose = true;

        /// <summary>
        /// Gets or sets a value indicating whether this instance can close.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance can close; otherwise, <c>false</c>.
        /// </value>
        public bool CanClose
        {
            get { return _canClose; }
            set { _canClose = value; }
        }

        /// <summary>
        /// The default contructor for DialogParametersExtended.
        /// </summary>
        /// <param name="header">The text displayed in the dialogs header.</param>
        /// <param name="content">The text displayed in the dialogs content.</param>
        /// <param name="icon">The icon.</param>
        /// <param name="buttons">the buttons displayed.</param>
        public DialogParametersExtended(string header, string content, string icon, params ButtonCommand[] buttons)
        {
            _header = header;
            _content = content;
            _buttons = new ObservableCollection<ButtonCommand>(buttons);
            _icon = icon;
            Owner = Application.Current.MainWindow;
        }

    }
}
