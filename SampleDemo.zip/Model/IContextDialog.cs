﻿using System.Windows;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An abstract class defining the methods needed to open 
    /// a contextual view.
    /// 
    /// This should be implemented on a view and not a viewmodel.
    /// </summary>
    public interface IContextDialog
    {
        /// <summary>
        /// Opens the current view on the context.
        /// </summary>
        /// <param name="parent">The parent to overlay.</param>
        /// <param name="view">The view to open.</param>
        void Show(FrameworkElement parent, FrameworkElement view);
        
    }
}
