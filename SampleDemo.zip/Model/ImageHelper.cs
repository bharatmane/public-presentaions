﻿using GalaSoft.MvvmLight;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Resources;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// A class for dealing with images.
    /// </summary>
    public static class ImageHelper
    {
        /// <summary>
        /// Downloads an image from a url and converts it to a bindable bitmap image.
        /// </summary>
        /// <param name="url">The url of the image.</param>
        /// <returns>A bitmap image.</returns>
        public static async Task<BitmapImage> GetImageFromUrl(string url)
        {
            var client = new WebClient();
            var result = await client.DownloadDataTaskAsync(new Uri(url, UriKind.Absolute));
            BitmapImage image;
            using (var ms = new MemoryStream(result))
            {
                image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = ms;
                image.EndInit();
                ms.Close();
            }

            return image;
        }

        /// <summary>
        /// The default image property
        /// </summary>
        public static readonly DependencyProperty DefaultImageProperty =
            DependencyProperty.RegisterAttached("DefaultImage", typeof(string), typeof(ImageHelper), new PropertyMetadata(null));

        /// <summary>
        /// Sets the default image.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetDefaultImage(UIElement element, string value)
        {
            element.SetValue(DefaultImageProperty, value);
        }

        /// <summary>
        /// Gets the default image.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>String object</returns>
        public static string GetDefaultImage(UIElement element)
        {
            return (string)element.GetValue(DefaultImageProperty);
        }

        /// <summary>
        /// The image location property
        /// </summary>
        public static readonly DependencyProperty ImageLocationProperty =
            DependencyProperty.RegisterAttached("ImageLocation", typeof(string), typeof(ImageHelper), new PropertyMetadata(null));

        /// <summary>
        /// Sets the image location.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetImageLocation(UIElement element, string value)
        {
            element.SetValue(ImageLocationProperty, value);
        }

        /// <summary>
        /// Gets the image location.
        /// Note: Provide relative project paths like "/VShips.Framework.Resource;component/Images/Flags"
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>String object</returns>
        public static string GetImageLocation(UIElement element)
        {
            return (string)element.GetValue(ImageLocationProperty);
        }

        /// <summary>
        /// The image extension property
        /// </summary>
        public static readonly DependencyProperty ImageExtensionProperty =
            DependencyProperty.RegisterAttached("ImageExtension", typeof(string), typeof(ImageHelper), new PropertyMetadata(null));

        /// <summary>
        /// Sets the image extension.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetImageExtension(UIElement element, string value)
        {
            element.SetValue(ImageExtensionProperty, value);
        }

        /// <summary>
        /// Gets the image extension.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>string object</returns>
        public static string GetImageExtension(UIElement element)
        {
            return (string)element.GetValue(ImageExtensionProperty);
        }

        /// <summary>
        /// The image name property
        /// </summary>
        public static readonly DependencyProperty ImageNameProperty =
            DependencyProperty.RegisterAttached("ImageName", typeof(string), typeof(ImageHelper), new PropertyMetadata(null, OnImageNameChanged));

        /// <summary>
        /// Sets the name of the image.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetImageName(UIElement element, string value)
        {
            element.SetValue(ImageNameProperty, value);
        }
        /// <summary>
        /// Gets the name of the image.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>String object</returns>
        public static string GetImageName(UIElement element)
        {
            return (string)element.GetValue(ImageNameProperty);
        }

        /// <summary>
        /// Called when [image name changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.</param>
        private static void OnImageNameChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (!ViewModelBase.IsInDesignModeStatic)
            {
                var image = d as Image;

                if (image != null)
                {
                    StreamResourceInfo imageInfo = null;
                    var imageExtension = (string)image.GetValue(ImageExtensionProperty);
                    var imageLocation = (string)image.GetValue(ImageLocationProperty);
                    var defaultImageName = (string)image.GetValue(DefaultImageProperty);

                    if (e.NewValue != null && !string.IsNullOrWhiteSpace(e.NewValue.ToString()))
                    {
                       
                        if (!string.IsNullOrWhiteSpace(imageExtension) && !string.IsNullOrWhiteSpace(imageLocation) &&
                            !string.IsNullOrWhiteSpace(defaultImageName))
                        {
                            imageInfo = GetImageStreamResourceInfo(imageLocation, imageExtension, e.NewValue.ToString());
                          
                            if (imageInfo != null)
                            {
                                SetImageSource(image, imageInfo.Stream);
                            }
                            else
                            {
                                //Image not found. Show default image.
                                imageInfo = GetImageStreamResourceInfo(imageLocation, imageExtension, defaultImageName);

                                if (imageInfo != null)
                                {
                                    SetImageSource(image, imageInfo.Stream);
                                }
                            }
                        }
                    }
                    else if(e.OldValue != null && !String.IsNullOrWhiteSpace((e.OldValue.ToString())))
                    {
                        //Dispose the image source, so there are no leaks
                        image.Source = null;
                        GC.Collect();
                    }
                    else
                    {
                        //Null binding provided, show default image
                        imageInfo = GetImageStreamResourceInfo(imageLocation, imageExtension, defaultImageName);

                        if (imageInfo != null)
                        {
                            SetImageSource(image, imageInfo.Stream);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Sets the image source.
        /// </summary>
        /// <param name="image">The image.</param>
        /// <param name="imageStream">The image stream.</param>
        private static void SetImageSource(Image image, Stream imageStream)
        {
            var bitmapImage = new BitmapImage();

            using (imageStream)
            {
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = imageStream;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad; //Cache the image
                bitmapImage.EndInit();
            }

            bitmapImage.Freeze(); //Important to freeze it, otherwise it will have minor leaks

            image.Source = bitmapImage;
        }

        /// <summary>
        /// Gets the image stream resource information.
        /// </summary>
        /// <param name="imageLocation">The image location.</param>
        /// <param name="imageExtension">The image extension.</param>
        /// <param name="imageName">Name of the image.</param>
        /// <returns>Single StreamResourceInfo object</returns>
        private static StreamResourceInfo GetImageStreamResourceInfo(string imageLocation, string imageExtension, string imageName)
        {
            string packPath = string.Format("{0}/{1}.{2}", imageLocation, imageName, imageExtension);
            var uri = new Uri(packPath, UriKind.RelativeOrAbsolute);

            StreamResourceInfo imageInfo = null;
            try
            {
                imageInfo = Application.GetResourceStream(uri); //Get the stream of the image
                return imageInfo;
            }
            catch (IOException)
            {
                return null;
            }
        }
    }
}
