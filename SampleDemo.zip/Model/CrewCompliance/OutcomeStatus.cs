﻿using System;

namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// This class is for compliance outcome status
    /// </summary>
    public class OutcomeStatus
    {
        /// <summary>
        /// Gets or sets the sign on status.
        /// </summary>
        /// <value>
        /// The sign on status.
        /// </value>
        public string SignOnStatus { get; set; }

        /// <summary>
        /// Gets or sets the sign off status.
        /// </summary>
        /// <value>
        /// The sign off status.
        /// </value>
        public string SignOffStatus { get; set; }

        /// <summary>
        /// Gets or sets the sign on status description.
        /// </summary>
        /// <value>
        /// The sign on status description.
        /// </value>
        public string SignOnStatusDescription { get; set; }

        /// <summary>
        /// Gets or sets the sign off status description.
        /// </summary>
        /// <value>
        /// The sign off status description.
        /// </value>
        public string SignOffStatusDescription { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is effective.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is effective; otherwise, <c>false</c>.
        /// </value>
        public bool IsEffective { get; set; }

        /// <summary>
        /// Gets or sets the effective date.
        /// </summary>
        /// <value>
        /// The effective date.
        /// </value>
        public DateTime? EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is waiver.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is waiver; otherwise, <c>false</c>.
        /// </value>
        public bool IsWaiver { get; set; }

        /// <summary>
        /// Gets or sets the waiver expiry date.
        /// </summary>
        /// <value>
        /// The waiver expiry date.
        /// </value>
        public DateTime? WaiverExpiryDate { get; set; }
    }
}