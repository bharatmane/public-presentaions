﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// Class used for getting all the documents of all the crew on a vessel.
    /// </summary>
    public class ComplianceVesselDetails
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the responsible office.
        /// </summary>
        /// <value>
        /// The responsible office.
        /// </value>
        public string ResponsibleOffice { get; set; }

        /// <summary>
        /// Gets or sets the management office.
        /// </summary>
        /// <value>
        /// The management office.
        /// </value>
        public string ManagementOffice { get; set; }

        /// <summary>
        /// Gets or sets the crew.
        /// </summary>
        /// <value>
        /// The crew.
        /// </value>
        public List<VesselCrewComplianceDetails> Crew { get; set; }

    }
}
