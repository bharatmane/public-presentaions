﻿namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// This class is for Applied matrix
    /// </summary>
    public class AppliedMatrix
    {
        /// <summary>
        /// Gets or sets the matrix header template identifier.
        /// </summary>
        /// <value>
        /// The matrix header template identifier.
        /// </value>
        public string MatrixHeaderTemplateId { get; set; }

        /// <summary>
        /// Gets or sets the name of the matrix header template.
        /// </summary>
        /// <value>
        /// The name of the matrix header template.
        /// </value>
        public string MatrixHeaderTemplateName { get; set; }

        /// <summary>
        /// Gets or sets the matrix template identifier.
        /// </summary>
        /// <value>
        /// The matrix template identifier.
        /// </value>
        public string MatrixTemplateId { get; set; }

        /// <summary>
        /// Gets or sets the matrix compliance identifier.
        /// </summary>
        /// <value>
        /// The matrix compliance identifier.
        /// </value>
        public string MatrixComplianceId { get; set; }

        /// <summary>
        /// Gets or sets the compliance description.
        /// </summary>
        /// <value>
        /// The compliance description.
        /// </value>
        public string ComplianceDescription { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is flag specific.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is flag specific; otherwise, <c>false</c>.
        /// </value>
        public bool IsFlagSpecific { get; set; }
    }
}