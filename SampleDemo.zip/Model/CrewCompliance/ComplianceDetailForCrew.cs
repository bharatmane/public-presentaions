﻿using System;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// The Compliance Details For Crew
    /// </summary>
    public class ComplianceDetailForCrew :BaseViewModel
    {
        /// <summary>
        /// Gets or sets the CRW identifier.
        /// </summary>
        /// <value>
        /// The CRW identifier.
        /// </value>
        public string CrwId { get; set; }

        /// <summary>
        /// Gets or sets the CRW pid.
        /// </summary>
        /// <value>
        /// The CRW pid.
        /// </value>
        public string CrwPid { get; set; }

        /// <summary>
        /// Gets or sets the first name of the CRW.
        /// </summary>
        /// <value>
        /// The first name of the CRW.
        /// </value>
        public string CrwFirstName { get; set; }
        /// <summary>
        /// Gets or sets the name of the CRW middle.
        /// </summary>
        /// <value>
        /// The name of the CRW middle.
        /// </value>
        public string CrwMiddleName { get; set; }
        /// <summary>
        /// Gets or sets the name of the CRW sur.
        /// </summary>
        /// <value>
        /// The name of the CRW sur.
        /// </value>
        public string CrwSurName { get; set; }
        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }
        /// <summary>
        /// Gets or sets the owner.
        /// </summary>
        /// <value>
        /// The owner.
        /// </value>
        public string Owner { get; set; }
        /// <summary>
        /// Gets or sets the planning cell.
        /// </summary>
        /// <value>
        /// The planning cell.
        /// </value>
        public string PlanningCell { get; set; }
        /// <summary>
        /// Gets or sets the mobilisation cell.
        /// </summary>
        /// <value>
        /// The mobilisation cell.
        /// </value>
        public string MobilisationCell { get; set; }
        /// <summary>
        /// Gets or sets the set start date.
        /// </summary>
        /// <value>
        /// The set start date.
        /// </value>
        public DateTime? SetStartDate { get; set; }
        /// <summary>
        /// Gets or sets the set end date.
        /// </summary>
        /// <value>
        /// The set end date.
        /// </value>
        public DateTime? SetEndDate { get; set; }
        /// <summary>
        /// Gets or sets the resp for mobilisation.
        /// </summary>
        /// <value>
        /// The resp for mobilisation.
        /// </value>
        public string Resp_for_Mobilisation { get; set; }
        /// <summary>
        /// Gets or sets the name of the document.
        /// </summary>
        /// <value>
        /// The name of the document.
        /// </value>
        public string DocumentName { get; set; }
        /// <summary>
        /// Gets or sets the template.
        /// </summary>
        /// <value>
        /// The template.
        /// </value>
        public string Template { get; set; }
        /// <summary>
        /// Gets or sets the requirement.
        /// </summary>
        /// <value>
        /// The requirement.
        /// </value>
        public string Requirement { get; set; }
        /// <summary>
        /// Gets or sets the mandatory.
        /// </summary>
        /// <value>
        /// The mandatory.
        /// </value>
        public int Mandatory { get; set; }
        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }
        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country { get; set; }
        /// <summary>
        /// Gets or sets the issued.
        /// </summary>
        /// <value>
        /// The issued.
        /// </value>
        public DateTime? Issued { get; set; }
        /// <summary>
        /// Gets or sets the expiry.
        /// </summary>
        /// <value>
        /// The expiry.
        /// </value>
        public DateTime? Expiry { get; set; }
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the ves identifier.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }

        /// <summary>
        /// Gets or sets the set identifier.
        /// </summary>
        /// <value>
        /// The set identifier.
        /// </value>
        public string SetId { get; set; }

        /// <summary>
        /// Gets or sets the rank identifier.
        /// </summary>
        /// <value>
        /// The rank identifier.
        /// </value>
        public string RankId { get; set; }

        /// <summary>
        /// Gets or sets the rank description.
        /// </summary>
        /// <value>
        /// The rank description.
        /// </value>
        public string RankDescription { get; set; }

        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the status description.
        /// </summary>
        /// <value>
        /// The status description.
        /// </value>
        public string StatusDescription { get; set; }
        /// <summary>
        /// Gets or sets the sas identifier.
        /// </summary>
        /// <value>
        /// The sas identifier.
        /// </value>
        public int? SasId { get; set; }

        /// <summary>
        /// Gets or sets the sign on status.
        /// </summary>
        /// <value>
        /// The sign on status.
        /// </value>
        public string SignOnStatus { get; set; }
        /// <summary>
        /// Gets or sets the sign off status.
        /// </summary>
        /// <value>
        /// The sign off status.
        /// </value>
        public string SignOffStatus { get; set; }

        /// <summary>
        /// Gets or sets the grace period weeks.
        /// </summary>
        /// <value>
        /// The grace period weeks.
        /// </value>
        public int? GracePeriodWeeks { get; set; }

        /// <summary>
        /// Gets the full name of the crew.
        /// </summary>
        /// <value>
        /// The full name of the crew.
        /// </value>
        public string CrewFullName
        {
            get
            {
                return string.Join(" ", CrwSurName, ",", CrwFirstName, CrwMiddleName);
            }
        }


        /// <summary>
        /// The mandatory count
        /// </summary>
        private int _mandatoryCount;

        /// <summary>
        /// Gets or sets the mandatory count.
        /// </summary>
        /// <value>
        /// The mandatory count.
        /// </value>
        public int MandatoryCount
        {
            get { return _mandatoryCount; }
            set { Set(() => MandatoryCount, ref _mandatoryCount, value); }
        }

        /// <summary>
        /// The non mandatory count
        /// </summary>
        private int _nonMandatoryCount;

        /// <summary>
        /// Gets or sets the non mandatory count.
        /// </summary>
        /// <value>
        /// The non mandatory count.
        /// </value>
        public int NonMandatoryCount
        {
            get { return _nonMandatoryCount; }
            set { Set(() => NonMandatoryCount, ref _nonMandatoryCount, value); }
        }

        /// <summary>
        /// The mandatory partial count
        /// </summary>
        private int _mandatoryPartialCount;

        /// <summary>
        /// Gets or sets the mandatory partial count.
        /// </summary>
        /// <value>
        /// The mandatory partial count.
        /// </value>
        public int MandatoryPartialCount
        {
            get { return _mandatoryPartialCount; }
            set { Set(() => MandatoryPartialCount, ref _mandatoryPartialCount, value); }
        }

        /// <summary>
        /// The mandatory non compliance count
        /// </summary>
        private int _mandatoryNonComplianceCount;

        /// <summary>
        /// Gets or sets the mandatory non compliance count.
        /// </summary>
        /// <value>
        /// The mandatory non compliance count.
        /// </value>
        public int MandatoryNonComplianceCount
        {
            get { return _mandatoryNonComplianceCount; }
            set { Set(() => MandatoryNonComplianceCount, ref _mandatoryNonComplianceCount, value); }
        }

        /// <summary>
        /// The non manadatory partial count
        /// </summary>
        private int _nonManadatoryPartialCount;

        /// <summary>
        /// Gets or sets the non manadatory partial count.
        /// </summary>
        /// <value>
        /// The non manadatory partial count.
        /// </value>
        public int NonManadatoryPartialCount
        {
            get { return _nonManadatoryPartialCount; }
            set { Set(() => NonManadatoryPartialCount, ref _nonManadatoryPartialCount, value); }
        }

        /// <summary>
        /// The non manadatory non compliance count
        /// </summary>
        private int _nonManadatoryNonComplianceCount;

        /// <summary>
        /// Gets or sets the non manadatory non compliance count.
        /// </summary>
        /// <value>
        /// The non manadatory non compliance count.
        /// </value>
        public int NonManadatoryNonComplianceCount
        {
            get { return _nonManadatoryNonComplianceCount; }
            set { Set(() => NonManadatoryNonComplianceCount, ref _nonManadatoryNonComplianceCount, value); }
        }

        /// <summary>
        /// The group descriptor name
        /// </summary>
        private string _groupDescriptorName;

        /// <summary>
        /// Gets or sets the name of the group descriptor.
        /// </summary>
        /// <value>
        /// The name of the group descriptor.
        /// </value>
        public string GroupDescriptorName
        {
            get { return _groupDescriptorName; }
            set { Set(() => GroupDescriptorName, ref _groupDescriptorName, value); }
        }

        /// <summary>
        /// The _PCN foreground color
        /// </summary>
        private KPI _pcnForegroundColor;

        /// <summary>
        /// Gets or sets the color of the PCN foreground.
        /// </summary>
        /// <value>
        /// The color of the PCN foreground.
        /// </value>
        public KPI PcnForegroundColor
        {
            get { return _pcnForegroundColor; }
            set { Set(() => PcnForegroundColor, ref _pcnForegroundColor, value); }
        }
    }
}
