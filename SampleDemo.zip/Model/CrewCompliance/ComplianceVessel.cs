﻿namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// Class used for getting all the documents of all the crew on a vessel.
    /// </summary>
    public class ComplianceVessel
    {
        /// <summary>
        /// Gets or sets the total outcomes found.
        /// </summary>
        /// <value>
        /// The total outcomes found.
        /// </value>
        public int TotalOutcomesFound { get; set; }

        /// <summary>
        /// Gets or sets the time to complete request milli seconds.
        /// </summary>
        /// <value>
        /// The time to complete request milli seconds.
        /// </value>
        public int TimeToCompleteRequestMilliSeconds { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="CrewComplianceDetails"/> is success.
        /// </summary>
        /// <value>
        ///   <c>true</c> if success; otherwise, <c>false</c>.
        /// </value>
        public bool Success { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public object Message { get; set; }

        /// <summary>
        /// Gets or sets the vessel.
        /// </summary>
        /// <value>
        /// The vessel.
        /// </value>
        public ComplianceVesselDetails Vessel { get; set; }

    }
}
