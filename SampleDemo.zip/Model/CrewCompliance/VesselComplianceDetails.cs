﻿namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// This class is for vessel details of compliance
    /// </summary>
    public class VesselComplianceDetails
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string VesselName { get; set; }

        /// <summary>
        /// Gets or sets the responsible office.
        /// </summary>
        /// <value>
        /// The responsible office.
        /// </value>
        public string ResponsibleOffice { get; set; }

        /// <summary>
        /// Gets or sets the management office.
        /// </summary>
        /// <value>
        /// The management office.
        /// </value>
        public string ManagementOffice { get; set; }
    }
}