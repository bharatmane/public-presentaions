﻿namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// The class is for crew details of compliance
    /// </summary>
    public class CrewComplianceDetails
    {
        /// <summary>
        /// Gets or sets the crew identifier.
        /// </summary>
        /// <value>
        /// The crew identifier.
        /// </value>
        public string CrewId { get; set; }

        /// <summary>
        /// Gets or sets the forename.
        /// </summary>
        /// <value>
        /// The forename.
        /// </value>
        public string Forename { get; set; }

        /// <summary>
        /// Gets or sets the surname.
        /// </summary>
        /// <value>
        /// The surname.
        /// </value>
        public string Surname { get; set; }

        /// <summary>
        /// Gets or sets the nationality identifier.
        /// </summary>
        /// <value>
        /// The nationality identifier.
        /// </value>
        public string NationalityId { get; set; }

        /// <summary>
        /// Gets or sets the rank identifier.
        /// </summary>
        /// <value>
        /// The rank identifier.
        /// </value>
        public string RankId { get; set; }

        /// <summary>
        /// Gets or sets the rank description.
        /// </summary>
        /// <value>
        /// The rank description.
        /// </value>
        public string RankDescription { get; set; }

        /// <summary>
        /// Gets or sets the crew management office.
        /// </summary>
        /// <value>
        /// The crew management office.
        /// </value>
        public string CrewManagementOffice { get; set; }

        /// <summary>
        /// Gets or sets the crew pool identifier.
        /// </summary>
        /// <value>
        /// The crew pool identifier.
        /// </value>
        public string CrewPoolId { get; set; }

        /// <summary>
        /// Gets or sets the crew pool description.
        /// </summary>
        /// <value>
        /// The crew pool description.
        /// </value>
        public string CrewPoolDescription { get; set; }
    }
}