﻿namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// This class id for compliance outcome
    /// </summary>
    public class ComplianceOutcome
    {
        /// <summary>
        /// Gets or sets the crew document record.
        /// </summary>
        /// <value>
        /// The crew document record.
        /// </value>
        public CrewDocumentRecord CrewDocumentRecord { get; set; }

        /// <summary>
        /// Gets or sets the type of the document.
        /// </summary>
        /// <value>
        /// The type of the document.
        /// </value>
        public DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets the outcome status.
        /// </summary>
        /// <value>
        /// The outcome status.
        /// </value>
        public OutcomeStatus OutcomeStatus { get; set; }

        /// <summary>
        /// Gets or sets the applied matrix.
        /// </summary>
        /// <value>
        /// The applied matrix.
        /// </value>
        public AppliedMatrix AppliedMatrix { get; set; }
    }
}