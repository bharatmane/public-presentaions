﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewCompliance
{
    /// <summary>
    /// The compliance Result
    /// </summary>
    public class CrewComplianceResult
    {
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="CrewComplianceResult"/> is success.
        /// </summary>
        /// <value>
        ///   <c>true</c> if success; otherwise, <c>false</c>.
        /// </value>
        public bool Success { get; set; }
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }
        /// <summary>
        /// Gets or sets the result.
        /// </summary>
        /// <value>
        /// The result.
        /// </value>
        public List<ComplianceDetailForCrew> Result { get; set; }
    }
}
