﻿using System.Threading.Tasks;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An interface for helping with file uploads.
    /// </summary>
    public interface IDocumentUpload
    {
        /// <summary>
        /// The name of the document.
        /// </summary>
        string FileName { get; }

        /// <summary>
        /// The short name of the document.
        /// </summary>
        string ShortFileName { get; }

        /// <summary>
        /// The progress of the current upload.
        /// </summary>
        ProgressIndicator Progress { get; }
        
        /// <summary>
        /// The state of the current file for upload.
        /// </summary>
        UploadStates UploadState { get; }

        /// <summary>
        /// The thumbnail for document.
        /// </summary>
        BaseImageViewModel Thumbnail { get; }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        /// <returns>Single object of type Task</returns>
        Task Save();

        /// <summary>
        /// Validates this instance.
        /// </summary>
        /// <returns>Single bool value</returns>
        bool Validate();  
    }

    /// <summary>
    /// The various states a file can be in.
    /// </summary>
    public enum UploadStates
    {
        /// <summary>
        /// Valid for upload. All fields are filled in correctly.
        /// </summary>
        Valid,
        /// <summary>
        /// Not valid for upload. Required fields maybe missing.
        /// </summary>
        Invalid,
        /// <summary>
        /// The document is currently uploading.
        /// </summary>
        Uploading,
        /// <summary>
        /// The document has completed successfully.
        /// </summary>
        Uploaded,
        /// <summary>
        /// There was an error during the upload operation.
        /// </summary>
        Error
    }
}
