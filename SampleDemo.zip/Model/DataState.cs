﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Used to determine the state of data retreival in an async operation.
    /// </summary>
    public enum DataState
    {
        /// <summary>
        /// Not data has been received.
        /// </summary>
        NotReceived,

        /// <summary>
        /// The data has been requested.
        /// </summary>
        Requested,

        /// <summary>
        /// The data has been received.
        /// </summary>
        Received,

        /// <summary>
        /// The data failed to return.
        /// </summary>
        Failed
    }
}
