﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

#pragma warning disable CS1591
#pragma warning disable CS1591

namespace VShips.Framework.Common.Model
{
    public class SeaRoutesRouteResponse
    {
        [JsonProperty("type")]
        public string type { get; set; }

        [JsonProperty("features")]
        public List<SeaRoutesRouteFeatures> features { get; set; }

        [JsonProperty("properties")]
        public SeaRoutesProperties properties { get; set; }
    }


    public class SeaRoutesRouteFeatures
    {
        [JsonProperty("type")]
        public string type { get; set; }

        [JsonProperty("properties")]
        public SeaRoutesProperties properties { get; set; }

        [JsonProperty("geometry")]
        public SeaRoutesGeometry geometry { get; set; }
    }


    public class SeaRoutesProperties
    {
        [JsonProperty("distance")]
        public int distance { get; set; }

        [JsonProperty("mode")]
        public string mode { get; set; }

        [JsonProperty("departure")]
        public double departure { get; set; }

        [JsonProperty("arrival")]
        public double arrival { get; set; }

        [JsonProperty("duration")]
        public double duration { get; set; }

        [JsonProperty("speed")]
        public decimal speed { get; set; }

        [JsonProperty("areas")]
        public JObject areas { get; set; }

        [JsonProperty("details")]
        public JArray details { get; set; }

        [JsonProperty("secaIntersection")]
        public int secaIntersection { get; set; }

        [JsonProperty("speedInKts")]
        public decimal speedInKts { get; set; }

        [JsonProperty("vessel")]
        public SeaRoutesVessel vessel { get; set; }
    }


    public class SeaRoutesVessel
    {
        [JsonProperty("imo")]
        public int imo { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("length")]
        public decimal length { get; set; }

        [JsonProperty("width")]
        public decimal width { get; set; }

        [JsonProperty("maxDraft")]
        public decimal maxDraft { get; set; }

        [JsonProperty("draft")]
        public decimal draft { get; set; }
    }

    public class SeaRoutesGeometry
    {
        [JsonProperty("type")]
        public string type { get; set; }

        [JsonProperty("coordinates")]
        public List<List<double>> coordinates { get; set; }
    }

    public class SeaRoutesCoordinates
    {
        [JsonProperty("Latitude")]
        public decimal Latitude { get; set; }

        [JsonProperty("Longitude")]
        public decimal Longitude { get; set; }
    }
}