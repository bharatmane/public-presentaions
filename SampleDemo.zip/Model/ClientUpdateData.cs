﻿#pragma warning disable CS1591

using System;

namespace VShips.Framework.Common.Model
{
    public class ClientUpdateData
    {
        public string CduApiCall { get; set; }
        public string BaseUri { get; set; }
        public string CduApiCallType { get; set; }
        public DateTime CduCreatedDate { get; set; }
        public DateTime CduExpiry { get; set; }
        public string CduId { get; set; }
        public string CduParameters { get; set; }
        public bool CduTokenRequired { get; set; }
        public string ClientId { get; set; }
        public string UserId { get; set; }
    }
}
