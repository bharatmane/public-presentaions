﻿using System;
using VShips.Contracts.DtoClasses;
// ReSharper disable MergeConditionalExpression
// ReSharper disable ArrangeAccessorOwnerBody
#pragma warning disable 1591

namespace VShips.Framework.Common.Model
{
    public class NoonReportModel
    {
        public NoonReport Entity { get; set; }

        public double Consumption
        {
            get
            {
                return Math.Round((Entity.MainEngineConsumptionFuelOil.HasValue ? Entity.MainEngineConsumptionFuelOil.Value : 0)
                    + (Entity.MainEngineConsumptionGasOil.HasValue ? Entity.MainEngineConsumptionGasOil.Value : 0), 1);
            }
        }

        public double RemainingFuel
        {
            get
            {
                return Math.Round((Entity.RemainingOnBoardFuelOil.HasValue ? Entity.RemainingOnBoardFuelOil.Value : 0)
                + (Entity.RemainingOnBoardGasOil.HasValue ? Entity.RemainingOnBoardGasOil.Value : 0), 1);
            }
        }

        public string LatLong
        {
            get
            {
                var latitude = Entity.LatitudeDegrees + "° " + Entity.LatitudeMinutes + "'" + Entity.RelationToEquator;
                var longitude = Entity.LongitudeDegrees + "° " + Entity.LongitudeMinutes + "'" + Entity.RelationToMeridian;
                return latitude + " " + longitude;
            }
        }

        public NoonReportModel(NoonReport noonReport)
        {
            Entity = noonReport;
        }
    }
}