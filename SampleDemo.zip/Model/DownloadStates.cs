﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// The various states of a document download.
    /// </summary>
    public enum DownloadStates
    {
        /// <summary>
        /// The download has not started.
        /// </summary>
        NotStarted,

        /// <summary>
        /// The download is in progress.
        /// </summary>
        InProgress,

        /// <summary>
        /// The download failed.
        /// </summary>
        Failed,

        /// <summary>
        /// The download was succesful.
        /// </summary>
        Completed
    }
}
