﻿using VShips.Framework.Common.Model.Icons;
using VShips.Framework.Common.Services;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// <para>
    /// An interface used in the <see cref="INavigationService"/>.
    /// </para>
    /// <para>
    /// Can be used on a viewmodel that participates in navigation allowing 
    /// the navigation service determine further information about the view model.
    /// </para>
    /// </summary>
    public interface INavigationTitle
    {
        /// <summary>
        /// The title of the current view
        /// </summary>
        string Title { get; }

        /// <summary>
        /// The description of the current view
        /// </summary>
        string Description { get; }

        /// <summary>
        /// A reference to the icon of the current view
        /// </summary>
        BaseIconViewModel Icon { get; }
    }
}
