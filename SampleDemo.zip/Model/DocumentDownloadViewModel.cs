﻿using GalaSoft.MvvmLight.Command;
using System;
using System.Diagnostics;
using System.Windows;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// The Document Download ViewModel.
    /// </summary>
    public class DocumentDownloadViewModel : BaseViewModel
    {
        /// <summary>
        /// Gets or sets a value indicating whether [show on UI after download].
        /// </summary>
        /// <value>
        /// <c>true</c> if [show on UI after download]; otherwise, <c>false</c>.
        /// </value>
        public bool HideOnUiAfterDownload { get; set; }

        /// <summary>
        /// Occurs when [close requested].
        /// </summary>
        public event EventHandler<EventArgs> CloseRequested = delegate {};

        /// <summary>
        /// The progress
        /// </summary>
        private ProgressIndicator _progress;

        /// <summary>
        /// Gets or sets the progress.
        /// </summary>
        /// <value>
        /// The progress.
        /// </value>
        public ProgressIndicator Progress
        {
            get { return _progress; }
            set { Set(() => Progress, ref _progress, value); }
        }

        /// <summary>
        /// The filename
        /// </summary>
        private string _filename;

        /// <summary>
        /// Gets or sets the filename.
        /// </summary>
        /// <value>
        /// The filename.
        /// </value>
        public string Filename
        {
            get { return _filename; }
            set { Set(() => Filename, ref _filename, value); }
        }

        /// <summary>
        /// The short filename
        /// </summary>
        private string _shortFilename;

        /// <summary>
        /// Gets or sets the short filename.
        /// </summary>
        /// <value>
        /// The short filename.
        /// </value>
        public string ShortFilename
        {
            get { return _shortFilename; }
            set { Set(() => ShortFilename, ref _shortFilename, value); }
        }

        /// <summary>
        /// The state
        /// </summary>
        private DownloadStates _state;
        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>
        /// The state.
        /// </value>
        public DownloadStates State
        {
            get { return _state; }
            set
            {
                if (Set(() => State, ref _state, value))
                {
                    OnStateChanged();
                }
            }
        }

        /// <summary>
        /// The open file command
        /// </summary>
        private RelayCommand _openFileCommand;

        /// <summary>
        /// Gets the open file command.
        /// </summary>
        /// <value>
        /// The open file command.
        /// </value>
        public RelayCommand OpenFileCommand
        {
            get { return _openFileCommand ?? (_openFileCommand = new RelayCommand(OpenFile, CanOpenFile)); }
        }

        /// <summary>
        /// The close command
        /// </summary>
        private RelayCommand _closeCommand;

        /// <summary>
        /// Gets the close command.
        /// </summary>
        /// <value>
        /// The close command.
        /// </value>
        public RelayCommand CloseCommand
        {
            get { return _closeCommand ?? (_closeCommand = new RelayCommand(Close)); }
        }

        /// <summary>
        /// The show in folder command
        /// </summary>
        private RelayCommand _showInFolderCommand;

        /// <summary>
        /// Gets the show in folder command.
        /// </summary>
        /// <value>
        /// The show in folder command.
        /// </value>
        public RelayCommand ShowInFolderCommand
        {
            get { return _showInFolderCommand ?? (_showInFolderCommand = new RelayCommand(ShowInFolder)); }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentDownloadViewModel"/> class.
        /// </summary>
        /// <param name="filename">The filename.</param>
        /// <param name="shortFilename">The short filename.</param>
        /// <param name="progress">The progress.</param>
        public DocumentDownloadViewModel(string filename, string shortFilename, ProgressIndicator progress)
            :this()
        {
            _filename = filename;
            _shortFilename = shortFilename;
            _progress = progress;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentDownloadViewModel"/> class.
        /// </summary>
        public DocumentDownloadViewModel()
        {
            _state = DownloadStates.NotStarted;
        }

        /// <summary>
        /// Determines whether this instance [can open file].
        /// </summary>
        /// <returns>Single bool value.</returns>
        private bool CanOpenFile()
        {
            return State == DownloadStates.Completed && !string.IsNullOrWhiteSpace(Filename);
        }

        /// <summary>
        /// Opens the file.
        /// </summary>
        private void OpenFile()
        {
            if (CanOpenFile())
            {
                try
                {
                    Process.Start(Filename);
                }
                catch (Exception ex)
                {
                    VMService.LoggerService.Error("An error occurred opening the file", ex.Message, ex);
                }
            }
        }

        /// <summary>
        /// Closes this instance.
        /// </summary>
        private void Close()
        {
            CloseRequested(this, EventArgs.Empty);
        }

        /// <summary>
        /// Shows the in folder.
        /// </summary>
        private void ShowInFolder()
        {
            VMService.DataService.DocumentService.OpenDownloadDirectory();
        }

        /// <summary>
        /// Called when [state changed].
        /// </summary>
        private void OnStateChanged()
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                OpenFileCommand.RaiseCanExecuteChanged();
            });
        }

        /// <summary>
        /// Cleans up the instance resources.
        /// <para>
        /// To cleanup additional resources, override this method, clean up and then call base.Cleanup().
        /// </para>
        /// </summary>
        public override void Cleanup()
        {
            _progress = null;
            base.Cleanup();
        }
    }
}
