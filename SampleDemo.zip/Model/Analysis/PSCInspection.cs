﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class PSCInspection
    {
        public string  vesId{ get; set; }
        public string  vesName{ get; set; }
        public string  vtyDesc{ get; set; }
        public string  vgtDesc{ get; set; }
        public string  cmpName{ get; set; }
        public string  vesHeadOff{ get; set; }
        public string  vesFlagCnt{ get; set; }
        public string  vstId{ get; set; }
        public string  vstFrom{ get; set; }
        public string  vstTo{ get; set; }
        public string  vstWhere{ get; set; }
        public decimal  vstRepReq{ get; set; }
        public string  vstRepIss{ get; set; }
        public string  vstNextVisDue{ get; set; }
        public string  vstReport{ get; set; }
        public decimal  vstRec{ get; set; }
        public decimal  vstDef{ get; set; }
        public decimal  vstObs{ get; set; }
        public string  vstInspName{ get; set; }
        public string  inspCmp{ get; set; }
        public decimal  vstVesRating2{ get; set; }
        public decimal  vstDetained{ get; set; }
        public decimal  vstDetainedDays{ get; set; }
        public string  vtyDesc_{ get; set; }
        public string  vtyGenType{ get; set; }
        public decimal  vstRefAcc{ get; set; }
        public string  areaCnt{ get; set; }
        public decimal  defTot{ get; set; }
        public decimal  defOverDue{ get; set; }
        public decimal   defout  { get; set; }
        public string  client { get; set; }
        public string classSociety { get; set; }
        public string masterNat { get; set; }
        public string coNat { get; set; }
    }
}
