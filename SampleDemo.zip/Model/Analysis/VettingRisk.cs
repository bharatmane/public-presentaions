﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    /// <summary>
    /// A class used for representing the details of OMV risk analyzer.
    /// </summary>
    /// <seealso cref="InspRisk" />
    public class VettingRisk:InspRisk
    {
        public	int?	lastVettingDef	{ get; set; }
        public	int?	lastVirdef	{ get; set; }
        public	int?	lastPscdef	{ get; set; }
        public	int?	lastSsadef	{ get; set; }
        public	int?	lastNaddef	{ get; set; }
        public	int?	lastPacdef	{ get; set; }
        public	int?	lastIsmdef	{ get; set; }
        public	int?	lastEismdef	{ get; set; }
        public	int?	lastCardef	{ get; set; }
        public	int?	lastPrvdef	{ get; set; }
        public	string	vettinginsprating	{ get; set; }
        public	int?	lastVettingAllDef	{ get; set; }
        public	int?	vettingRiskProfile	{ get; set; }
        public	int?	vettingRepeats	{ get; set; }
        public	int?	vettingCmpRisk	{ get; set; }
        public	int?	lastPrevettingAllDef	{ get; set; }
        public	int?	preVettingRepeats	{ get; set; }
        public	int?	lastPrevettingOverDueDef	{ get; set; }
        public	DateTime	clsCertExpireDt	{ get; set; }
        public	int	clsCertWindow	{ get; set; }
        public	int	totalCritJobsOverdue	{ get; set; }
        public	int	totalCritJobs	{ get; set; }
        public	int?	overdueDefects	{ get; set; }
        public	int?	condClassInsp	{ get; set; }
        public	int?	virmonthsSince	{ get; set; }

        public string Ops3TypeId { get; set; }

        public bool LastOmvnoGo { get; set; }
        public bool CertNoGo { get; set; }
        public bool DefectNoGo { get; set; }

        public bool PmsnoGo { get; set; }
        /// <summary>
        /// Gets or sets the PMS perc.
        /// </summary>
        /// <value>
        /// The PMS perc.
        /// </value>
        public decimal? PmsPerc { get; set; }
    }
}
