﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    /// <summary>
    /// The contract for client underfunding detail
    /// </summary>
    public class ClientUnderfundingDetail
    {
        /// <summary>
        /// The coy identifier
        /// </summary>
        public string CoyId { get; set; }

        /// <summary>
        /// The supplier
        /// </summary>
        public string Supplier { get; set; }

        /// <summary>
        /// The invoice order
        /// </summary>
        public string InhOrder { get; set; }

        /// <summary>
        /// The invoice number
        /// </summary>
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// The currency id
        /// </summary>
        public string CurId { get; set; }

        /// <summary>
        /// The invoice total currency
        /// </summary>
        public decimal? InhTotalCurr { get; set; }

        /// <summary>
        /// The invoice total USD
        /// </summary>
        public decimal? InhTotalusd { get; set; }

        /// <summary>
        /// The invoice date
        /// </summary>
        public DateTime? InvoiceDate { get; set; }

        /// <summary>
        /// The invoice text
        /// </summary>
        public string InhText { get; set; }

    }
}
