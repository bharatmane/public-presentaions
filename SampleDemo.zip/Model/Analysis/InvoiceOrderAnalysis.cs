﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
	/// <summary>
	/// The class InvoiceOrderAnalysis
	/// </summary>
	public class DummyInvoiceOrderAnalysis
	{
		/// <summary>
		/// Gets or sets the coy identifier.
		/// </summary>
		/// <value>
		/// The coy identifier.
		/// </value>
		public string CoyId { get; set; }
		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }
		/// <summary>
		/// Gets or sets the name of the supplier.
		/// </summary>
		/// <value>
		/// The name of the supplier.
		/// </value>
		public string SupplierName { get; set; }
		/// <summary>
		/// Gets or sets the po number.
		/// </summary>
		/// <value>
		/// The po number.
		/// </value>
		public string PONumber { get; set; }
		/// <summary>
		/// Gets or sets the invoice date.
		/// </summary>
		/// <value>
		/// The invoice date.
		/// </value>
		public DateTime? InvoiceDate { get; set; }
		/// <summary>
		/// Gets or sets the invoice number.
		/// </summary>
		/// <value>
		/// The invoice number.
		/// </value>
		public string InvoiceNumber { get; set; }
		/// <summary>
		/// Gets or sets the invoice due date.
		/// </summary>
		/// <value>
		/// The invoice due date.
		/// </value>
		public DateTime? InvoiceDueDate { get; set; }
		/// <summary>
		/// Gets or sets the office.
		/// </summary>
		/// <value>
		/// The office.
		/// </value>
		public string Office { get; set; }
		/// <summary>
		/// Gets or sets the fleet description.
		/// </summary>
		/// <value>
		/// The fleet description.
		/// </value>
		public string FleetDescription { get; set; }
		/// <summary>
		/// Gets or sets the total base.
		/// </summary>
		/// <value>
		/// The total base.
		/// </value>
		public decimal? TotalBase { get; set; }
		/// <summary>
		/// Gets or sets the total usd.
		/// </summary>
		/// <value>
		/// The total usd.
		/// </value>
		public decimal? TotalUSD { get; set; }
		/// <summary>
		/// Gets or sets the total local.
		/// </summary>
		/// <value>
		/// The total local.
		/// </value>
		public decimal? TotalLocal { get; set; }
		/// <summary>
		/// Gets or sets the status code.
		/// </summary>
		/// <value>
		/// The status code.
		/// </value>
		public string StatusCode { get; set; }
		/// <summary>
		/// Gets or sets the status.
		/// </summary>
		/// <value>
		/// The status.
		/// </value>
		public string Status { get; set; }
		/// <summary>
		/// Gets or sets the voucher number.
		/// </summary>
		/// <value>
		/// The voucher number.
		/// </value>
		public string VoucherNumber { get; set; }
		/// <summary>
		/// Gets or sets the current identifier.
		/// </summary>
		/// <value>
		/// The current identifier.
		/// </value>
		public string CurId { get; set; }

	}
}
