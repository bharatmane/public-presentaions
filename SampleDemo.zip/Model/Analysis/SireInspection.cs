﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class SireInspection
    {
        public string	documentKey	{ get; set; }	
        public string	documentType	{ get; set; }	
        public string	chapter	{ get; set; }	
        public string	questionNumWhole { get; set; }	
        public string dwt {get;set; }
        public string	version	{ get; set; }	
        public DateTime	inspectionDate	{ get; set; }
        public string	chapterEight { get; set; }	
        public string	questionNumFull	{ get; set; }	
        public string	questionNo	{ get; set; }	
        public string	questionPartFull { get; set; }	
        public string	questionPart	{ get; set; }	
        public string	responseData	{ get; set; }	
        public string	response	{ get; set; }	
        public string	office	{ get; set; }	
        public string	inspectingCompany	{ get; set; }	
        public string	client	{ get; set; }	
        public string	type	{ get; set; }	
        public string	port	{ get; set; }	
        public string	status	{ get; set; }	
        public string	classification	{ get; set; }	
        public string	master	{ get; set; }	
        public string	vesselName { get; set; }
        public string	created	{ get; set; }	
        public string	uploadedOn	{ get; set; }	
        public string	nationality2ndOfficer { get; set; }	
        public string	nationalityChiefOfficer	{ get; set; }	
        public string	nationalityChiefEngineer	{ get; set; }	
        public string	quarterCreated { get; set; }	
        public string	inspDateQuarter { get; set; }	
        public string	inspectionDateYear { get; set; }	
        public string	acceptStatus	{ get; set; }	
        public string	quarterInspection { get; set; }	
        public string	sireYesNoNotSeen { get; set; }	
        public int      yearbuilt { get; set; }	
        public string	incidentID	{ get; set; }	     
        public int      chapterNo {get;set; }
        public decimal      dwtNo {get;set; }
        public string   currentQuarter {get;set; }
        public string   vestype {get;set; }
        public string   vesgentype {get;set; }
        public string  actualRisk{get;set; }
        public string  processind{get;set; }
        public string  defActriskrating {get;set; }
        public string  inspDateMonthYear {get;set; }

    }
}
