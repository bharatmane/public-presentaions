﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    /// <summary>
    /// A partial class used for binding the Operational Risk Analyzer PSC detail grid.
    /// </summary>
    public partial class PSCRisk
    {
        #region Properties

        /// <summary>
        /// Gets the icon high risk port.
        /// </summary>
        /// <value>
        /// The icon high risk port.
        /// </value>
        public int IconHighRiskPort
        {  
            get
            {
                if(nextPort.ToUpper() ==  "NZL"  || nextPort.ToUpper() ==  "AUS" || nextPort.ToUpper() ==  "CHN" || nextPort.ToUpper() ==  "RUS" || nextPort.ToUpper() ==  "ROM" || nextPort.ToUpper() == "ITA"  ||nextPort.ToUpper() == "CYP" || nextPort.ToUpper() == "GRC")
                {
                    return 5;
                }
                else if(nextPort.ToUpper() == "USA")
                {
                    return 1;
                }
                else if(nextPort == string.Empty)
                {
                    return -1;
                }
                else
                {
                    return 0;
                }
              
            }
        }

        /// <summary>
        /// Gets the icon age profile.
        /// </summary>
        /// <value>
        /// The icon age profile.
        /// </value>
        public int IconAgeProfile
        {
            get
            {
                if (age >= 13)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }

        /// <summary>
        /// Gets the icon pmou ves risk.
        /// </summary>
        /// <value>
        /// The icon pmou ves risk.
        /// </value>
        public int IconPmouVesRisk
        {
            get
            {
                if(risk.ToUpper() == "HRS")
                {
                    return 5;
                }
                else
                {
                    return 0;
                }
            }
        }

        /// <summary>
        /// Gets the icon PSC deficiencies.
        /// </summary>
        /// <value>
        /// The icon PSC deficiencies.
        /// </value>
        public int IconPSCDeficiencies
        {
            get
            {
                if(lastInsp > 7) { return 10; }
                else if(lastInsp >5 ) { return 5; }
                else if(lastInsp > 3) { return 1; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon PSC detentions.
        /// </summary>
        /// <value>
        /// The icon PSC detentions.
        /// </value>
        public int IconPSCDetentions
        {
            get
            {
                if (dententions > 1) { return 10; }
                else { return 0 ; }
            }
        }

        /// <summary>
        /// Gets the icon ops3.
        /// </summary>
        /// <value>
        /// The icon ops3.
        /// </value>
        public int IconOps3
        {
            get
            {
                if (op3MonthsSince == 5) { return 5; }
                else if (op3MonthsSince == 6) { return 7; }
                else if (op3MonthsSince > 6) { return 10; }
                else { return 0 ; }
            }
        }

        /// <summary>
        /// Gets the icon ops3 definition.
        /// </summary>
        /// <value>
        /// The icon ops3 definition.
        /// </value>
        public int IconOps3Def
        {
            get
            {
                if (op3LastDef == 0) { return 10; }
                else if (op3LastDef  < 5) { return 5; }
                else { return 0 ; }
            }
        }

        /// <summary>
        /// Gets the icon omd.
        /// </summary>
        /// <value>
        /// The icon omd.
        /// </value>
        public string IconOMD
        {
            get
            {
                if (type.ToUpper() == "DRY") { return "-"; }
                else { return noObservations.ToString(); }
            }
        }

        /// <summary>
        /// Gets the icon omd observations.
        /// </summary>
        /// <value>
        /// The icon omd observations.
        /// </value>
        public int IconOMDObservations
        {
            get
            {
                if (type.ToUpper() == "DRY") { return -1; }
                else if (noObservations > 3) { return 1; }
                else if (noObservations > 5) { return 5; }
                else if (noObservations > 7) { return 10; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon VMS.
        /// </summary>
        /// <value>
        /// The icon VMS.
        /// </value>
        public int IconVMS
        {
            get
            {
                if (noOfficersLessThan4Months > 0) { return 1; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon clu.
        /// </summary>
        /// <value>
        /// The icon clu.
        /// </value>
        public string IconCLU
        {
            get
            {
                if (underfunded == 1) { return "High"; }
                else { return "-"; }
            }
        }

        /// <summary>
        /// Gets the icon client underfunding.
        /// </summary>
        /// <value>
        /// The icon client underfunding.
        /// </value>
        public int IconClientUnderfunding
        {
            get
            {
                if (underfunded == 1) { return 5; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon env.
        /// </summary>
        /// <value>
        /// The icon env.
        /// </value>
        public int IconENV
        {
            get
            {
                if (envcMonthsSince > 6 ) { return 5; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon class cert exp.
        /// </summary>
        /// <value>
        /// The icon class cert exp.
        /// </value>
        public int IconClassCertExp
        {
            get
            {
                if (clsCertExpireDt == null || clsCertExpireDt.Year < 1900) { return 0; }
                else if ((clsCertExpireDt - DateTime.Now).TotalDays > 0) { return 10; }
                else if (clsCertWindow < 1) { return 0; }
                else if ((clsCertExpireDt.AddMonths(clsCertWindow).AddDays(-30) - DateTime.Now).TotalDays > 0) { return 5; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon lo t.
        /// </summary>
        /// <value>
        /// The icon lo t.
        /// </value>
        public int IconLoT
        {
            get
            {
                if (loTmonthsSince > 18) { return 10; }
                else if (loTmonthsSince > 12) { return 5; }
                else if (loTmonthsSince > 11) { return 1; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon PMS.
        /// </summary>
        /// <value>
        /// The icon PMS.
        /// </value>
        public decimal IconPMS
        {
            get
            {
                return totalCritJobs + totalCritJobsOverdue > 0 ? Math.Round(Convert.ToDecimal(totalCritJobsOverdue / (totalCritJobs + totalCritJobsOverdue) * 100), 2) : 0;
            }
        }

        /// <summary>
        /// Gets the icon PMS score.
        /// </summary>
        /// <value>
        /// The icon PMS score.
        /// </value>
        public int IconPMSScore
        {
            get
            {
                if (IconPMS > 3) { return 10; }
                else if (IconPMS > 2) { return 5; }
                else if (IconPMS > 1) { return 1; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon ssa definition.
        /// </summary>
        /// <value>
        /// The icon ssa definition.
        /// </value>
        public int IconSSADef
        {
            get
            {
                if (SsalastDef == 0) { return 10; }
                else if (SsalastDef < 5) { return 5; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon omd score.
        /// </summary>
        /// <value>
        /// The icon omd score.
        /// </value>
        public int IconOMDScore
        {
            get
            {
                if (type.ToUpper() == "DRY") { return 0; }
                else if (noObservations > 7) { return 10; }
                else if (noObservations > 5) { return 5; }
                else if (noObservations > 3) { return 1; }
                else { return 0; }
            }
        }

        /// <summary>
        /// Gets the icon score.
        /// </summary>
        /// <value>
        /// The icon score.
        /// </value>
        public int IconScore
        {
            get
            {
                return IconAgeProfile + IconPSCDeficiencies + IconPSCDetentions + IconOps3 + IconOMDScore + IconVMS + Tpa + IconPmouVesRisk + IconClientUnderfunding + PortScore + IconENV + IconClassCertExp + IconLoT + IconPMSScore + IconOps3Def + IconSSADef;
            }
        }

        #endregion
    }
}
