﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class PSCCausations
    {
        public string vesId { get; set; }
        public string vesName { get; set; }
        public string vtyDesc { get; set; }
        public string vgtDesc { get; set; }
        public string cmpName { get; set; }
        public string vesHeadOff { get; set; }
        public string vesFlagCnt { get; set; }
        public string vstId { get; set; }
        public string cmpId { get; set; }
        public string vrpId { get; set; }
        public string vstFrom { get; set; }
        public string vstTo { get; set; }
        public string vstWhere { get; set; }
        public decimal vstRepReq { get; set; }
        public string vstRepIss { get; set; }
        public string vstNextVisDue { get; set; }
        public string vstReport { get; set; }
        public decimal vstRec { get; set; }
        public decimal vstDef { get; set; }
        public decimal vstObs { get; set; }
        public string vstInspName { get; set; }
        public string vstUpdatedBy { get; set; }
        public string vstUpdatedOn { get; set; }
        public string vstUserId { get; set; }
        public string vstDepId { get; set; }
        public string inspCmp { get; set; }
        public string vrpType { get; set; }
        public decimal vstVesRating2 { get; set; }
        public decimal vstDetained { get; set; }
        public decimal vstDetainedDays { get; set; }
        public string vtyDesc_ { get; set; }
        public string vtyGenType { get; set; }
        public string vstCntId { get; set; }
        public decimal vstRefAcc { get; set; }
        public string defId { get; set; }
        public string defPscAction { get; set; }
        public string defPscGroupCode { get; set; }
        public string defIsmId { get; set; }
        public string ntyId { get; set; }
        public string defDatClear { get; set; }
        public string defDueDate { get; set; }
        public string defDirSubAct { get; set; }
        public string defDirSubCond { get; set; }
        public string defRootHumFact { get; set; }
        public string defRootJobFact { get; set; }
        public string defRootConManFail { get; set; }
        public string client { get; set; }
        public string classSociety { get; set; }
        public string masterNat { get; set; }
        public string coNat { get; set; }
        public string iadId { get; set; }
        public string iadDescr { get; set; }
        public string iadAbbr { get; set; }
        public string iadDevision { get; set; }
        public string iadOrder { get; set; }
        public decimal total { get; set; }
        public string areaCnt { get; set; }
    }
}