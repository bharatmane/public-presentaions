﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
	/// <summary>
	/// Model class for dashboard Fleet Visitation Summary for Leisure Vessels 
	/// </summary>
	public class InsFleetVisitationSummaryForLeisureVessel
	{
		/// <summary>
		/// Gets or sets the vessel identifier.
		/// </summary>
		/// <value>
		/// The vessel identifier.
		/// </value>
		public string VesselId { get; set; }

		/// <summary>
		/// Gets or sets the name of the vessel.
		/// </summary>
		/// <value>
		/// The name of the vessel.
		/// </value>
		public string VesselName { get; set; }

		/// <summary>
		/// Gets or sets the type of the vessel.
		/// </summary>
		/// <value>
		/// The type of the vessel.
		/// </value>
		public string VesselType { get; set; }

		/// <summary>
		/// Gets or sets the built year.
		/// </summary>
		/// <value>
		/// The built year.
		/// </value>
		public DateTime? BuiltYear { get; set; }

		/// <summary>
		/// Gets or sets the last any inspection.
		/// </summary>
		/// <value>
		/// The last any inspection.
		/// </value>
		public DateTime? LastAnyInspection { get; set; }

		/// <summary>
		/// Gets or sets the type of the inspection.
		/// </summary>
		/// <value>
		/// The type of the inspection.
		/// </value>
		public string InspectionType { get; set; }

		/// <summary>
		/// Gets or sets the last office inspection.
		/// </summary>
		/// <value>
		/// The last office inspection.
		/// </value>
		public DateTime? LastOfficeInspection { get; set; }

		/// <summary>
		/// Gets or sets the person or where.
		/// </summary>
		/// <value>
		/// The person or where.
		/// </value>
		public string PersonOrWhere { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether [rep issued].
		/// </summary>
		/// <value>
		///   <c>true</c> if [rep issued]; otherwise, <c>false</c>.
		/// </value>
		public DateTime RepIssued { get; set; }

		/// <summary>
		/// Gets or sets the no od office inspections.
		/// </summary>
		/// <value>
		/// The no od office inspections.
		/// </value>
		public int NoOdOfficeInspections { get; set; }

		/// <summary>
		/// Gets or sets the days.
		/// </summary>
		/// <value>
		/// The days.
		/// </value>
		public int Days { get; set; }

		/// <summary>
		/// Gets or sets the next office inspection due.
		/// </summary>
		/// <value>
		/// The next office inspection due.
		/// </value>
		public DateTime? NextOfficeInspectionDue { get; set; }
    }
}
