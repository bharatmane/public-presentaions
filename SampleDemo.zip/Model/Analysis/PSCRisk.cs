﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    public partial class PSCRisk : InspRisk
    {
        //Below properties shifted to parent class.
        // dententions , op3MonthsSince , loTmonthsSince

        public DateTime dataUploadedOn { get; set; }
        public int officePerf { get; set; }
        public string cmpName { get; set; }
        public int? lastInsp { get; set; }
        public string rating { get; set; }
        public int? noObservations { get; set; }
        public int noTpaofficers { get; set; }
        public int noOfficersLessThan4Months { get; set; }
        public int? monthsSince { get; set; }
        public int? totalInsp { get; set; }
        public int? totalDetInsp { get; set; }
        public int? totalDetDys { get; set; }
        public int? lastRefAcc { get; set; }
        public int? totalDef { get; set; }
        public int? totalDefIsm { get; set; }
        public int? totalDefOut { get; set; }
        public int underfunded { get; set; }
        public string nextPort { get; set; }
        public int? envcMonthsSince { get; set; }
        public DateTime clsCertExpireDt { get; set; }
        public int clsCertWindow { get; set; }
        public int classCert { get; set; }

        public int? op3LastDef { get; set; }
        public int totalCritJobsOverdue { get; set; }
        public int totalCritJobs { get; set; }
        public int? SsalastDef { get; set; }

        public string portId { get; set; }

        public string coyId { get; set; }

        public string Ops3TypeId { get; set; }

        public string EnvcTypeId { get; set; }


        /// <summary>
        /// Gets or sets the class cert score.
        /// </summary>
        /// <value>
        /// The class cert score.
        /// </value>
        public int ClassCertScore { get; set; }

        /// <summary>
        /// Gets or sets the PMS perc.
        /// </summary>
        /// <value>
        /// The PMS perc.
        /// </value>
        public decimal? PmsPerc { get; set; }

        //Properties used for Operational Risk Analyzer binding.

        public string SsacrewId { get; set; }


        #region Properties

        /// <summary>
        /// Gets or sets the icon pscdef score is greater than one.
        /// </summary>
        /// <value>
        /// The icon pscdef score is greater than one.
        /// </value>
        public bool IconPscdefScoreIsGreaterThanOne
        {
            get
            {
                return PscdefScore >= 1 ? true : false;
            }
        }

        /// <summary>
        /// Gets the icon clu.
        /// </summary>
        /// <value>
        /// The icon clu.
        /// </value>
        public string IconCLU
        {
            get
            {
                if (underfunded >= 1) { return "High"; }
                else { return ""; }
            }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is vessel wet.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is vessel wet; otherwise, <c>false</c>.
        /// </value>
        public bool IsVesselWet
        {
            get { return !string.IsNullOrWhiteSpace(vesWetDry) && vesWetDry.ToUpper() == "WET" ? true : false; }
        }

        #endregion      
    }
}