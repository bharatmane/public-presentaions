﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class PSCSystemAreas
    {
        public	string	vesId	{ get; set; }
        public	string	vesName	{ get; set; }
        public	string	vtyDesc	{ get; set; }
        public	string	vgtDesc	{ get; set; }
        public	string	cmpName	{ get; set; }
        public	string	veS_HeadOff	{ get; set; }
        public	string	vesFlagCnt	{ get; set; }
        public	string	vsT_ID	{ get; set; }
        public	string	cmP_ID	{ get; set; }
        public	string	vrP_ID	{ get; set; }
        public	string	vsT_From	{ get; set; }
        public	string	vsT_To	{ get; set; }
        public	string	vsT_Where	{ get; set; }
        public	int	vsT_RepReq	{ get; set; }
        public	string	vsT_RepIs	{ get; set; }
        public	string	vsT_NextVisDue	{ get; set; }
        public	string	vsT_Report	{ get; set; }
        public	string	vsT_Rec	{ get; set; }
        public	string	vsT_Def	{ get; set; }
        public	string	vsT_Obs	{ get; set; }
        public	string	vsT_InspName	{ get; set; }
        public	string	vsT_UpdatedBy	{ get; set; }
        public	string	vsT_UpdatedOn	{ get; set; }
        public	string	vsT_UserID	{ get; set; }
        public	string	vsT_DepID	{ get; set; }
        public	string	inspCmp	{ get; set; }
        public	string	vrP_Type	{ get; set; }
        public	string	vsT_VesRating2	{ get; set; }
        public	int	vsT_Detained	{ get; set; }
        public	int	vsT_DetainedDays	{ get; set; }
        public	string	vtY_GenType	{ get; set; }
        public	string	vsT_CNT_ID	{ get; set; }
        public	int	vsT_RefAcc	{ get; set; }
        public	string	deF_ID	{ get; set; }
        public	string	deF_PSC_Action	{ get; set; }
        public	string	deF_PSC_GroupCode	{ get; set; }
        public	string	deF_ISM_ID	{ get; set; }
        public	string	ntY_ID	{ get; set; }
        public	string	deF_DatClear	{ get; set; }
        public	string	def_DueDate	{ get; set; }
        public	string	client	{ get; set; }
        public	string	id	{ get; set; }
        public	string	descr	{ get; set; }
        public	string	abbr	{ get; set; }
        public	string	devision	{ get; set; }
        public	string	order	{ get; set; }
        public	int	defTot	{ get; set; }
        public	int	defOut	{ get; set; }
        public	int	defOverDue	{ get; set; }
        public	string	devisionName	{ get; set; }


    }
}
