﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class HazOccRpts
    {
        public string  imcClass { get; set; } 
        public string imcId	{ get; set; } 
        public string imrIncDate	{ get; set; } 
        public string imrRepDate	{ get; set; } 
        public string imsStatus	{ get; set; } 
        public string imsId	{ get; set; } 
        public string imdRepType { get; set; } 	
        public string imdId	{ get; set; } 
        public string vesId	{ get; set; } 
        public string vesName	{ get; set; } 
        public string vtyDesc	{ get; set; } 
        public string vgtDesc	{ get; set; } 
        public string imrId	{ get; set; } 
        public string imrShipRefNo	{ get; set; } 
        public string imrCloseDate	{ get; set; } 
        public string imvId	{ get; set; } 
        public string imvSeverity	{ get; set; } 
        public string iadDescr	{ get; set; } 
        public string cmpName	{ get; set; } 
        public string injType	{ get; set; } 
        public string accPlace	{ get; set; } 
        public string accType	{ get; set; } 
        public string bodyArea	{ get; set; } 
        public string dutyStatus	{ get; set; } 
        public string accDept	{ get; set; } 
        public string shipOp	{ get; set; }
        public string primEquip { get; set; } 
        public string PossConq { get; set; } 
        public string DirCausesSubAct { get; set; } 
        public string DirCausesSubCond { get; set; }
        public string VSSID { get; set; }
        public string client { get; set; }
        public string createdByRnk { get; set; }
        public string injPersonNat { get; set; }
        public string injPersonRnk { get; set; }

        //public string Identifier { get; set; }        
        //public string VesselId { get; set; }       
        //public string VesselName { get; set; }      
        //public string VesselType { get; set; }      
        //public string VesselMaster { get; set; }        
        //public string Status { get; set; }        
        //public string StatusId { get; set; }        
        //public string Type { get; set; }        
        //public string Class { get; set; }        
        //public string ClassID { get; set; }        
        //public DateTime ReportDate { get; set; }        
        //public DateTime IncidentDate { get; set; }        
        //public int ActionsOverdueCount { get; set; }        
        //public string ShipReferenceNumber { get; set; }        
        //public DateTime ReportCloseDate { get; set; }        
        //public string TypeID { get; set; }        
        //public string Severity { get; set; }        
        //public string SeverityDesc { get; set; }        
        //public string SubstandardActsComment { get; set; }        
        //public string SubstandardCondsComment { get; set; }        
        //public bool Deleted { get; set; }        
        //public bool ClosurePending { get; set; } //Fld for showing Closure awaiting sign-off        
        //public bool IsParentReport { get; set; } //Fld for showing whether other reports linked to this one        
        //public bool IsChildReport { get; set; } //Fld for showing whether linked to other report        
        //public string ShipOperation { get; set; }        
        //public string VesGenType { get; set; }        
        //public string TechOffice { get; set; } 
        ////Accident Data
        //public string InjuryType { get; set; }
        //public string AccPlace { get; set; }
        //public string AccType { get; set; } 
        //public string AccBodyArea { get; set; }
        //public string AccDept { get; set; } 
        ////Incident
        //public string DutyStatus { get; set; }
        //public string ShipOper { get; set; }
        //public string PrimEquipDm { get; set; }

        //Causations
        //public int SbActs { get; set; }
        //public int SbCons { get; set; }
        //public int RcHums { get; set; }
        //public int RcJobs { get; set; }
        //public int RcMans { get; set; } 


    }
}
