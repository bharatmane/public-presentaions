﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    /// <summary>
    /// The contract for Fleet visitaion summary
    /// </summary>
    public class FleetVisitationSummary
    {

        /// <summary>
        /// Gets or sets the VstId field.
        /// </summary>
        /// <value>
        /// The VST identifier.
        /// </value>
		public string VstId { get; set; }
        /// <summary>
        /// Gets or sets the VrpId field.
        /// </summary>
        /// <value>
        /// The VRP identifier.
        /// </value>
        public string VrpId { get; set; }
        /// <summary>
        /// Gets or sets the VstFrom field.
        /// </summary>
        /// <value>
        /// The VST from.
        /// </value>
        public DateTime? VstFrom { get; set; }
        /// <summary>
        /// Gets or sets the VstTo field.
        /// </summary>
        /// <value>
        /// The VST to.
        /// </value>
        public DateTime? VstTo { get; set; }
        /// <summary>
        /// Gets or sets the VstWhere field.
        /// </summary>
        /// <value>
        /// The VST where.
        /// </value>
        public string VstWhere { get; set; }
        /// <summary>
        /// Gets or sets the VstNextVisDue field.
        /// </summary>
        /// <value>
        /// The VST next vis due.
        /// </value>
        public DateTime? VstNextVisDue { get; set; }
        /// <summary>
        /// Gets or sets the VstInspName field.
        /// </summary>
        /// <value>
        /// The name of the VST insp.
        /// </value>
        public string VstInspName { get; set; }
        /// <summary>
        /// Gets or sets the VrpType field.
        /// </summary>
        /// <value>
        /// The type of the VRP.
        /// </value>
        public string VrpType { get; set; }
        /// <summary>
        /// Gets or sets the AttDays field.
        /// </summary>
        /// <value>
        /// The att days.
        /// </value>
        public int AttDays { get; set; }
        /// <summary>
        /// Gets or sets the Deftot field.
        /// </summary>
        /// <value>
        /// The deftot.
        /// </value>
        public int? Deftot { get; set; }
        /// <summary>
        /// Gets or sets the DefOverDue field.
        /// </summary>
        /// <value>
        /// The definition over due.
        /// </value>
        public int? DefOverDue { get; set; }
        /// <summary>
        /// Gets or sets the Defout field.
        /// </summary>
        /// <value>
        /// The defout.
        /// </value>
        public int? Defout { get; set; }
        /// <summary>
        /// Gets or sets the VesId field.
        /// </summary>
        /// <value>
        /// The ves identifier.
        /// </value>
        public string VesId { get; set; }
        /// <summary>
        /// Gets or sets the VesName field.
        /// </summary>
        /// <value>
        /// The name of the ves.
        /// </value>
        public string VesName { get; set; }
        /// <summary>
        /// Gets or sets the VesManageStart field.
        /// </summary>
        /// <value>
        /// The ves manage start.
        /// </value>
        public DateTime? VesManageStart { get; set; }
        /// <summary>
        /// Gets or sets the TechOff field.
        /// </summary>
        /// <value>
        /// The tech off.
        /// </value>
        public string TechOff { get; set; }
    }
}
