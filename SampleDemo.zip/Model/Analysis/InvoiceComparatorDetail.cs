﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
	/// <summary>
	/// THe class InvoiceComparatorDetail
	/// </summary>
	public class InvoiceComparatorDetail
	{
		/// <summary>Gets or sets the InvoiceNumber field.</summary>
		public string InvoiceNumber { get; set; }
		/// <summary>Gets or sets the CoyId field.</summary>
		public string CoyId { get; set; }
		/// <summary>Gets or sets the SitName field.</summary>
		public string SitName { get; set; }
		/// <summary>Gets or sets the FltDesc field.</summary>
		public string FltDesc { get; set; }
		/// <summary>Gets or sets the InvoiceSupplier field.</summary>
		public string InvoiceSupplier { get; set; }
		/// <summary>Gets or sets the Posupplier field.</summary>
		public string Posupplier { get; set; }
		/// <summary>Gets or sets the OrdOrderNo field.</summary>
		public string OrdOrderNo { get; set; }
		/// <summary>Gets or sets the SupplierId field.</summary>
		public string SupplierId { get; set; }
		/// <summary>Gets or sets the InvoiceAmount field.</summary>
		public decimal? InvoiceAmount { get; set; }
		/// <summary>Gets or sets the InvoiceAmountUsd field.</summary>
		public decimal? InvoiceAmountUsd { get; set; }
		/// <summary>Gets or sets the Currency field.</summary>
		public string Currency { get; set; }
		/// <summary>Gets or sets the Poamount field.</summary>
		public decimal? Poamount { get; set; }
		/// <summary>Gets or sets the CurId field.</summary>
		public string CurId { get; set; }
		/// <summary>Gets or sets the OrdOrderStatus field.</summary>
		public string OrdOrderStatus { get; set; }
		/// <summary>Gets or sets the OrdId field.</summary>
		public string OrdId { get; set; }
		/// <summary>Gets or sets the OrdStatus field.</summary>
		public string OrdStatus { get; set; }
		/// <summary>Gets or sets the IncId field.</summary>
		public string IncId { get; set; }
		/// <summary>Gets or sets the AuthStatus field.</summary>
		public int AuthStatus { get; set; }
		/// <summary>Gets or sets the IncAuthLevel field.</summary>
		public int? IncAuthLevel { get; set; }
		/// <summary>Gets or sets the OrdNotes field.</summary>
		public string OrdNotes { get; set; }
		/// <summary>Gets or sets the VesName field.</summary>
		public string VesName { get; set; }
		/// <summary>Gets or sets the FltType field.</summary>
		public string FltType { get; set; }

		/// <summary>
		/// Gets or sets the status.
		/// </summary>
		/// <value>
		/// The status.
		/// </value>
		public string Status { get; set; }

		/// <summary>
		/// Gets or sets the po no.
		/// </summary>
		/// <value>
		/// The po no.
		/// </value>
		public string PONo { get; set; }

		/// <summary>
		/// Gets or sets the invoice date.
		/// </summary>
		/// <value>
		/// The invoice date.
		/// </value>
		public DateTime InvoiceDate { get; set; }

		/// <summary>
		/// Gets or sets the invoice due date.
		/// </summary>
		/// <value>
		/// The invoice due date.
		/// </value>
		public DateTime InvoiceDueDate { get; set; }

		/// <summary>
		/// Gets or sets the total local.
		/// </summary>
		/// <value>
		/// The total local.
		/// </value>
		public decimal TotalLocal { get; set; }

		/// <summary>
		/// Gets or sets the total usd.
		/// </summary>
		/// <value>
		/// The total usd.
		/// </value>
		public decimal TotalUSD { get; set; }

		/// <summary>
		/// Gets or sets the CMP identifier.
		/// </summary>
		/// <value>
		/// The CMP identifier.
		/// </value>
		public string CmpId { get; set; }
		/// <summary>Gets or sets the InhId field.</summary>
		public string InhId { get; set; }
		/// <summary>Gets or sets the VesId field.</summary>
		public string VesId { get; set; }
		/// <summary>Gets or sets the Coyid field.</summary>
		public string Coyid { get; set; }
		/// <summary>Gets or sets the VesselName field.</summary>
		public string VesselName { get; set; }
		/// <summary>Gets or sets the SupplierName field.</summary>
		public string SupplierName { get; set; }
		/// <summary>Gets or sets the Ponumber field.</summary>
		public string Ponumber { get; set; }
		
		/// <summary>Gets or sets the Office field.</summary>
		public string Office { get; set; }
		/// <summary>Gets or sets the FleetDescription field.</summary>
		public string FleetDescription { get; set; }
		/// <summary>Gets or sets the TotalBase field.</summary>
		public decimal? TotalBase { get; set; }
		/// <summary>Gets or sets the TotalUsd field.</summary>
		public decimal? TotalUsd { get; set; }
		/// <summary>Gets or sets the StatusCode field.</summary>
		public System.Int16 StatusCode { get; set; }
		/// <summary>Gets or sets the VoucherNumber field.</summary>
		public string VoucherNumber { get; set; }

		/// <summary>
		/// Gets or sets the with user.
		/// </summary>
		/// <value>
		/// The with user.
		/// </value>
		public string WithUser { get; set; }

		/// <summary>
		/// Gets or sets the due date.
		/// </summary>
		/// <value>
		/// The due date.
		/// </value>
		public DateTime DueDate { get; set; }
	}
}
