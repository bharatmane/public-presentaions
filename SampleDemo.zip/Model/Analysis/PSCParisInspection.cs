﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class PSCParisInspection
    {
        public string vesId	{ get; set; }
        public string vesName	{ get; set; }
        public string vtyDesc	{ get; set; }
        public string vgtDesc	{ get; set; }
        public string cmpName	{ get; set; }
        public string vesHeadOff	{ get; set; }
        public string vesFlagCnt	{ get; set; }
        public string vesFlag	{ get; set; }
        public int built	{ get; set; }
        public string VesDateBuilt	{ get; set; }
        public int age	{ get; set; }
        public string vesImonumber	{ get; set; }
        public string vesIntGrossTon	{ get; set; }
        public string @class	{ get; set; }
        public string risk	{ get; set; }
        public string vstID	{ get; set; }
        public string vstFrom	{ get; set; }
        public string vstTo	{ get; set; }
        public string vstWhere	{ get; set; }
        public int vstRepReq	{ get; set; }
        public string vstRepIss	{ get; set; }
        public string vstNextVisDue	{ get; set; }
        public int vstRefAcc	{ get; set; }
        public string vstPscType	{ get; set; }
        public string vstReport	{ get; set; }
        public int vstRec	{ get; set; }
        public int vstDef	{ get; set; }
        public int vstObs	{ get; set; }
        public string vstInspName	{ get; set; }
        public string inspCmp	{ get; set; }
        public int vstVesRating2	{ get; set; }
        public int vstDetained	{ get; set; }
        public int vstDetainedDays	{ get; set; }
        public string vstDesc	{ get; set; }
        public string vtyGenType	{ get; set; }
        public string areaCnt	{ get; set; }
        public string weight	{ get; set; }
        public int officePerf	{ get; set; }
        public string client	{ get; set; }
        public int defTot	{ get; set; }
        public int totDefISM	{ get; set; }
        public int defout	{ get; set; }
        public int totDetInsp	{ get; set; }
       
    }
}
