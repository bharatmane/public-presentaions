﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    /// <summary>
    /// Model class for Fleet Visitation Summary For Cargo Vessel
    /// </summary>
    public class InsFleetVisitationSummaryForCargoVessel
    {
		/// <summary>
		/// Gets or sets the VST identifier.
		/// </summary>
		/// <value>
		/// The VST identifier.
		/// </value>
		public string VstId { get; set; }
		/// <summary>
		/// Gets or sets the VRP identifier.
		/// </summary>
		/// <value>
		/// The VRP identifier.
		/// </value>
		public string VrpId { get; set; }
		/// <summary>
		/// Gets or sets the VST from.
		/// </summary>
		/// <value>
		/// The VST from.
		/// </value>
		public DateTime? VstFrom { get; set; }
		/// <summary>
		/// Gets or sets the VST to.
		/// </summary>
		/// <value>
		/// The VST to.
		/// </value>
		public DateTime? VstTo { get; set; }
		/// <summary>
		/// Gets or sets the VST where.
		/// </summary>
		/// <value>
		/// The VST where.
		/// </value>
		public string VstWhere { get; set; }
		/// <summary>
		/// Gets or sets the VST next vis due.
		/// </summary>
		/// <value>
		/// The VST next vis due.
		/// </value>
		public DateTime? VstNextVisDue { get; set; }
		/// <summary>
		/// Gets or sets the name of the VST insp.
		/// </summary>
		/// <value>
		/// The name of the VST insp.
		/// </value>
		public string VstInspName { get; set; }
		/// <summary>
		/// Gets or sets the type of the VRP.
		/// </summary>
		/// <value>
		/// The type of the VRP.
		/// </value>
		public string VrpType { get; set; }
		/// <summary>
		/// Gets or sets the deftot.
		/// </summary>
		/// <value>
		/// The deftot.
		/// </value>
		public int? Deftot { get; set; }
		/// <summary>
		/// Gets or sets the defout.
		/// </summary>
		/// <value>
		/// The defout.
		/// </value>
		public int? Defout { get; set; }
		/// <summary>
		/// Gets or sets the ves identifier.
		/// </summary>
		/// <value>
		/// The ves identifier.
		/// </value>
		public string VesId { get; set; }
		/// <summary>
		/// Gets or sets the name of the ves.
		/// </summary>
		/// <value>
		/// The name of the ves.
		/// </value>
		public string VesName { get; set; }
		/// <summary>
		/// Gets or sets the ves manage start.
		/// </summary>
		/// <value>
		/// The ves manage start.
		/// </value>
		public DateTime? VesManageStart { get; set; }
		/// <summary>
		/// Gets or sets the att days.
		/// </summary>
		/// <value>
		/// The att days.
		/// </value>
		public int AttDays { get; set; }
		/// <summary>
		/// Gets or sets the tech off.
		/// </summary>
		/// <value>
		/// The tech off.
		/// </value>
		public string TechOff { get; set; }
		/// <summary>
		/// Gets or sets the definition over due.
		/// </summary>
		/// <value>
		/// The definition over due.
		/// </value>
		public int DefOverDue { get; set; }
	}
}
