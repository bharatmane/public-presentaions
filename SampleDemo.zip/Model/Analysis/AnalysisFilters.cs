﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.DataServices.Shared.DataAttributes;
using VShips.DataServices.Shared.Enumerations;

namespace VShips.Framework.Common.Model.Analysis
{
    public static class AnalysisFilters
    {
        /// <summary>
        /// QuarterList Enum
        /// </summary>
        public enum QuarterListDefs
        {
            /// <summary>
            /// The quarter1
            /// </summary>
            [EnumValueData(Name = "Quarter 1", KeyValue = "1")]
            Quarter1= 0,

            /// <summary>
            /// The quarter2
            /// </summary>
            [EnumValueData(Name = "Quarter 2", KeyValue = "2")]
            Quarter2 = 1,
            
            /// <summary>
            /// The quarter3
            /// </summary>
            [EnumValueData(Name = "Quarter 3", KeyValue = "3")]
            Quarter3 = 2,

            /// <summary>
            /// The quarter4
            /// </summary>
            [EnumValueData(Name = "Quarter 4", KeyValue = "4")]
            Quarter4 = 3,
        }

        //Quarter Lookup
        public static List<Lookup> QuarterList
        {
            get
            {
                return new List<Lookup>
                {
                   
                    new Lookup()
                    {
                        Identifier = EnumsHelper.GetKeyValue( QuarterListDefs.Quarter1),
                        Description = EnumsHelper.GetDescription(QuarterListDefs.Quarter1)
                    },
                    new Lookup()
                    {
                        Identifier = EnumsHelper.GetKeyValue(QuarterListDefs.Quarter2),
                        Description = EnumsHelper.GetDescription(QuarterListDefs.Quarter2)
                    },
                    new Lookup()
                    {
                        Identifier = EnumsHelper.GetKeyValue(QuarterListDefs.Quarter3),
                        Description = EnumsHelper.GetDescription(QuarterListDefs.Quarter3)
                    },
                    new Lookup()
                    {
                        Identifier = EnumsHelper.GetKeyValue(QuarterListDefs.Quarter4),
                        Description = EnumsHelper.GetDescription(QuarterListDefs.Quarter4)
                    },
                    new Lookup()
                    {
                        Identifier = "5",
                        Description = "Year to Date"
                    }
                };
            }
        }

        //Cal Start & End dates based on selected quarter/year
        public static void SelectedQuarterDates(string quarterSelected,int year,out DateTime from, out DateTime to)
        {
            Lookup SelectedQuarter = QuarterList.Find(x => x.Identifier == quarterSelected);
            from = DateTime.Now.AddMonths(-3);
            to = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 23:59:59.000")); //defaults

            if (int.Parse(SelectedQuarter.Identifier)>0){
            switch (Convert.ToInt32(SelectedQuarter.Identifier))
            {
                case 1:
                    from = new DateTime(year , 1, 1, 0, 0, 0);
                    to = new DateTime(year, 3, 31, 23, 59, 59);
                    break;
                case 2:
                    from = new DateTime(year , 4, 1, 0, 0, 0);
                    to = new DateTime(year, 6, 30, 23, 59, 59);
                    break;
                case 3:
                    from = new DateTime(year , 7, 1, 0, 0, 0);
                    to = new DateTime(year, 9, 30, 23, 59, 59);
                    break;
                case 4:
                    from = new DateTime(year , 10, 1, 0, 0, 0);
                    to = new DateTime(year, 12, 31, 23, 59, 59);
                    break;

                default: //YTD
                    from = new DateTime(DateTime.Now.Year, 1, 1, 0, 0, 0);
                    to = DateTime.Now;
                    break;
            }

            }
        }
      


        public static Lookup CurrentQuarter
        {
            get
            {
                int _currentQ = (int) (DateTime.Now.Month + 2) / 3;
                return QuarterList[_currentQ - 1];
                }
        }

       
    }
}
