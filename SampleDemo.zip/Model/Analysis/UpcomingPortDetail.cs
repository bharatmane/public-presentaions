﻿using System;

namespace VShips.Framework.Common.Model.Analysis
{
    /// <summary>
    /// The contract for upcoming port detail
    /// </summary>
    public class UpcomingPortDetail
    {
        /// <summary>
        /// The arrival
        /// </summary>
        public DateTime? Arrival { get; set; }

        /// <summary>
        /// The departure
        /// </summary>
        public DateTime? Departure { get; set; }

        /// <summary>
        /// The country
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// The berth
        /// </summary>
        public string Berth { get; set; }

        /// <summary>
        /// The from port
        /// </summary>
        public string FromPort { get; set; }

        /// <summary>
        /// The row number
        /// </summary>
        public int RowNumber { get; set; }

        /// <summary>
        /// The PlaName
        /// </summary>
        public string PlaName { get; set; }

        /// <summary>
        /// The is high risk port
        /// </summary>
        public bool? IsHighRiskPort { get; set; }
    }
}
