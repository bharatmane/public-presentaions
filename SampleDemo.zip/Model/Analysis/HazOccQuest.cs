﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class HazOccQuest
    {
        public string imdId { get; set; }
        public string imrId { get; set; } 
        public string vesId { get; set; }
        public string vesName { get; set; }
        public string vgtDesc { get; set; }
        public string vtyDesc { get; set; } 
        public string cmpName { get; set; }        
        public string imsStatus { get; set; }
       
        //Questions
        public string ans { get; set; }
        public string iadDescr { get; set; }
        public string iadDevision { get; set; }
        public string iadOrder { get; set; }
        public string question { get; set; }

    }
}
