﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class HazOccIncClass
    {


        public string imcClass { get; set; }
        public string imsStatus { get; set; }
        public string imsId { get; set; }
        public string imdRepType { get; set; }
        public string imdId { get; set; }
        public string vesId { get; set; }
        public string vesName { get; set; }
        public string vtyDesc { get; set; }
        public string vgtDesc { get; set; }
        public string vssId { get; set; }
        public string cmpName { get; set; }
        public string imrId { get; set; }
        public string imvSeverity { get; set; }
        public string imrPolutionSea { get; set; }
        public string imrPolutionDeck { get; set; }
        public string polutionSea { get; set; }
        public string polutionDeck { get; set; }
        public decimal oilLtrsSea { get; set; }
        public decimal imrOilLtrsDeck { get; set; }
        public string client { get; set; }

    }
}
