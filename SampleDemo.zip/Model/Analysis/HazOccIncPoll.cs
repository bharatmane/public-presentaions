﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model.Analysis
{
    public class HazOccIncPoll
    {

        public string vesId { get; set; }
        public string vesName { get; set; }
        public string cmpName { get; set; }
        public string vgtDesc { get; set; }
        public string imsStatus { get; set; }

        public string Class { get; set; }        
        public decimal TotalInc { get; set; }       
        public decimal OilLtsSea { get; set; }      
        public decimal OilLtsDeck { get; set; }      
      


    }
}
