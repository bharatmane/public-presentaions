﻿using System;
using VShips.Framework.Common.ModuleNavigation.Inspection;


namespace VShips.Framework.Common.Model.Analysis
{
    public class InspRisk
    {

        public string vesId { get; set; }
        public string vesselname { get; set; }
        public string status { get; set; }
        public string fleet { get; set; }
        public string office { get; set; }
        public int age { get; set; }
        public string type { get; set; }
        public int overallriskclr { get; set; }



        //PSC
        public int pscriskclr { get; set; }

        public string risk { get; set; }
        public int PortScore { get; set; }
        public int PortClr { get; set; }
        public int AgeScore { get; set; }
        public int AgeClr { get; set; }

        public int RiskScore { get; set; }
        public int RiskClr { get; set; }

        public int PscdefScore { get; set; }
        public int PscdefClr { get; set; }
        public int PscdetScore { get; set; }
        public int PscdetClr { get; set; }

        public int Virscore { get; set; }
        public int VirClr { get; set; }
        public int VirdefScore { get; set; }
        public int VirdefClr { get; set; }
        public int SsadefScore { get; set; }
        public int SsadefClr { get; set; }
        public int OmdobsScore { get; set; }
        public int OmdobsClr { get; set; }
        public int Vmsscore { get; set; }
        public int VmsClr { get; set; }
        public int Tpa { get; set; }
        public int TpaClr { get; set; }
        public int UnderfundedScore { get; set; }
        public int UnderfundedClr { get; set; }
        public int Envscore { get; set; }
        public int EnvClr { get; set; }
        public int ClassCertScore { get; set; }
        public int ClassCertClr { get; set; }
        public int Lotscore { get; set; }
        public int LotClr { get; set; }
        public int Pmsscore { get; set; }
        public int PmsClr { get; set; }
        public string vesWetDry { get; set; }
        //Vetting
        public int vettingriskclr { get; set; }
        public int? VettingMonthsSince { get; set; }
        public int virmonthsSinceScore { get; set; }
        public int virmonthsSinceClr { get; set; }
        public int CondtClsScore { get; set; }
        public int CondtClsClr { get; set; }

        public int OverDueDefScore { get; set; }
        public int OverDueDefClr { get; set; }
        public int LastVettingDefScore { get; set; }
        public int LastVettingDefClr { get; set; }
        public int LastVirdefScore { get; set; }
        public int LastVirdefClr { get; set; }
        public int LastPscdefScore { get; set; }
        public int LastPscdefClr { get; set; }
        public int LastIsmdefScore { get; set; }
        public int LastIsmdefClr { get; set; }
        public int LastEismdefScore { get; set; }
        public int LastEismdefClr { get; set; }
        public int LastPrevettingOverDueDefScore { get; set; }
        public int LastPrevettingOverDueDefClr { get; set; }
        public int LastVettingAllDefScore { get; set; }
        public int LastVettingAllDefClr { get; set; }

        public int? loTmonthsSince { get; set; }
        public int dententions { get; set; }
        public int? op3MonthsSince { get; set; }

        public int CertScore { get; set; }
        public int CertClr { get; set; }
        public int CertsOutstanding { get; set; }

        public int PmsPerc { get; set; }

        public string Ops3TypeId { get; set; }

        public string EnvcTypeId { get; set; }

        public bool VettingNoGo { get; set; }

        public int PSCRiskScore { get; set; }

        public int VettingRiskScore { get; set; }

        public int VettingClr { get; set; }

        private DateTime? _lastVettingInsp;
        public DateTime? lastVettingInsp
        {
            get { return _lastVettingInsp; }
            set
            {
                if (value != null)
                {
                    _lastVettingInsp = value;
                    VettingMonthsSince = (DateTime.Now.Month + DateTime.Now.Year * 12) - (((DateTime)value).Month + ((DateTime)value).Year * 12);
                }
            }
        }

        /// <summary>
        /// Gets or sets the chief engineer shipsure experience.
        /// </summary>
        /// <value>
        /// The chief engineer shipsure experience.
        /// </value>
        public int ChiefEngShipsureExperience { get; set; }

        /// <summary>
        /// Gets or sets the chief engineer total experience.
        /// </summary>
        /// <value>
        /// The chief engineer total experience.
        /// </value>
        public int ChiefEngTotalExperience { get; set; }

        /// <summary>
        /// Gets or sets the master shipsure experience.
        /// </summary>
        /// <value>
        /// The master shipsure experience.
        /// </value>
        public int MasterShipsureExperience { get; set; }

        /// <summary>
        /// Gets or sets the master total experience.
        /// </summary>
        /// <value>
        /// The master total experience.
        /// </value>
        public int MasterTotalExperience { get; set; }


        //score markers

        public InspectionAnalysisScoring ageMarker
        {
            get { return AgeScore >= 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring SsalastDefMarker
        {
            get { return SsadefScore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }


        public InspectionAnalysisScoring PscdefMarker
        {
            get { return PscdefScore > 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring PscdetMarker
        {
            get { return PscdetScore > 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring VirMarker
        {
            get { return Virscore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }


        public InspectionAnalysisScoring VirdefMarker
        {
            get { return VirdefScore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring SsadefMarker
        {
            get { return SsadefScore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring OmdobsMarker
        {

            get { return OmdobsScore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring VmsMarker
        {
            get { return Vmsscore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring TpaMarker
        {
            get { return Tpa > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring UnderfundedMarker
        {
            get
            {
                return UnderfundedScore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable;
            }
        }

        public InspectionAnalysisScoring EnvMarker
        {
            get { return Envscore >= 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring ClassCertMarker
        {
            get
            {
                return ClassCertScore > 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable;
            }
        }

        public InspectionAnalysisScoring LotMarker
        {
            get { return Lotscore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring PmsMarker
        {
            get { return Pmsscore > 0 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring RiskMarker
        {
            get { return RiskScore >= 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring PortMarker
        {
            get { return PortScore >= 1 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable; }
        }

        public InspectionAnalysisScoring LastVIRMarker
        {
            get
            {
                return VettingMonthsSince > 4 ? InspectionAnalysisScoring.Warning : InspectionAnalysisScoring.Acceptable;
            }

        }
        //Master Scores
        public int PSCScoreTotal
        {
            get
            {
                int _portScore = PortScore < 0
                    ? 0
                    : PortScore;
                int _omdobsScore = OmdobsScore < 0 ? 0 : OmdobsScore;

                return _portScore +
                        +AgeScore + PscdefScore + PscdetScore + Virscore +
                        VirdefScore + SsadefScore + _omdobsScore + Vmsscore + Tpa + UnderfundedScore + Envscore +
                        ClassCertScore + Lotscore + Pmsscore + RiskScore;
            }
        }
        public int VettingScoreTotal
        {
            get
            {
                return vesWetDry =="Dry" || vesWetDry == "Pas" ? 0 : CertScore + CondtClsScore + OverDueDefScore + Pmsscore + LastVettingDefScore + LastVirdefScore +
                       LastPscdefScore + LastIsmdefScore + LastEismdefScore + Virscore + LastPrevettingOverDueDefScore + LastVettingAllDefScore;
            }
        }

        public int PSCRiskTotal
        {
            get
            {
                //Get number of warning flags 
                //However if both a high risk Port and HighRisk Ops3 then mark as Red(5 pts)
                return Vmsscore >= 5 && PortScore >= 1 ? 5 :
                    ConvertMarker(ageMarker) +
                    ConvertMarker(SsalastDefMarker) +
                    ConvertMarker(PscdefMarker) +
                    ConvertMarker(PscdetMarker) +
                    ConvertMarker(VirMarker) +
                    ConvertMarker(VirdefMarker) +
                    ConvertMarker(SsadefMarker) +
                    ConvertMarker(OmdobsMarker) +
                    ConvertMarker(VmsMarker) +
                    ConvertMarker(TpaMarker) +
                    ConvertMarker(UnderfundedMarker) +
                    ConvertMarker(EnvMarker) +
                    ConvertMarker(ClassCertMarker) +
                    ConvertMarker(LotMarker) +
                    ConvertMarker(PmsMarker) +
                    ConvertMarker(RiskMarker) +
                    ConvertMarker(PortMarker);
            }
        }

        public int VettingRiskTotal
        {
            get
            {

                //Get number of warning flags 
                //However if both a high risk Port and HighRisk Ops3 then mark as Red(5 pts)
                return
                    IsRiskScored(ClassCertScore) +
                    IsRiskScored(CondtClsScore) +
                    IsRiskScored(OverDueDefScore) +
                    IsRiskScored(Pmsscore) +
                    IsRiskScored(LastVettingDefScore) +
                    IsRiskScored(LastVirdefScore) +
                    IsRiskScored(LastPscdefScore) +
                    IsRiskScored(LastIsmdefScore) +
                    IsRiskScored(LastEismdefScore) +
                    IsRiskScored(Virscore) +
                    IsRiskScored(LastPrevettingOverDueDefScore) +
                    IsRiskScored(LastVettingAllDefScore)
                  ;
            }
        }

        private int ConvertMarker(InspectionAnalysisScoring scr)
        {
            return scr == InspectionAnalysisScoring.Warning ? 1 : 0;
        }

        private int IsRiskScored(int scr)
        {
            return scr > 0 ? 1 : 0;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is age exceeded.
        /// </summary>
        public bool IsAgeExceeded
        {
            get { return age >= 14 ? true : false; }
        }

        /// <summary>
        /// Gets the color of the PSC risk score.
        /// </summary>
        /// <value>
        /// The color of the PSC risk score.
        /// </value>
        public string PscRiskScoreColor
        {
            get { return GetPscRiskScoreColor(); }
        }

        /// <summary>
        /// Gets the color of the omv risk score.
        /// </summary>
        /// <value>
        /// The color of the omv risk score.
        /// </value>
        public string OmvRiskScoreColor
        {
            get { return GetOmvRiskScoreColor(); }
        }

        /// <summary>
        /// Gets the color of the PSC risk score.
        /// </summary>
        /// <returns>
        /// A string value.
        /// </returns>
        private string GetPscRiskScoreColor()
        {
            int redIconCounter = 0;
            string result;
            if (PortScore > 0)
            { redIconCounter++; }
            if (AgeScore > 0)
            { redIconCounter++; }
            if (RiskScore > 0)
            { redIconCounter++; }
            if (PscdefScore >= 1)
            { redIconCounter++; }
            if (DetentionIndicator == Constant.Red)
            { redIconCounter++; }
            if (Op3MonthsSinceIndicator == Constant.Red)
            { redIconCounter++; }
            if (VirdefScore > 0)
            { redIconCounter++; }
            if (OmdobsScore > 0)
            { redIconCounter++; }
            if (Envscore > 0)
            { redIconCounter++; }
            if (Op3MonthsSinceIndicator == Constant.Red)
            { redIconCounter++; }
            if (Tpa > 0)
            { redIconCounter++; }
            if (UnderfundedScore > 0)
            { redIconCounter++; }
            if (ClassCertScore > 0)
            { redIconCounter++; }
            if (Pmsscore > 0)
            { redIconCounter++; }

            if (redIconCounter == 0)
            {
                result = "GREEN";
            }
            else if (redIconCounter > 0 && redIconCounter < 4)
            {
                result = "AMBER";
            }
            else
            {
                result = "RED";
            }

            // Override the above rule if
            // PSC Risk Score should change to RED if individual Vessel has NOT had Vessel Inspection Report in the last 5 Months (See excel - row 10) AND the vessel is going to one of the HIGH RISK ports
            if (PortScore > 0 && Op3MonthsSinceIndicator == Constant.Red)
            {
                result = "RED";
            }
            return result;
        }

        /// <summary>
        /// Gets the color of the omv risk score.
        /// </summary>
        /// <returns>
        /// A string value.
        /// </returns>
        private string GetOmvRiskScoreColor()
        {

            int? days = null;
            if (lastVettingInsp.HasValue)
            {
                days = (DateTime.Now - lastVettingInsp.Value).Days;
            }

            if (VettingRiskTotal > 0 || IsClassCertScoreExceeded || Pmsscore > 0 || LastVettingAllDefScore > 0 || LastPscdefScore > 0 || LastEismdefScore > 0 || days < 30)
            {
                return Constant.Red;
            }
            else
            {
                return Constant.Green;
            }
        }

        #region Exceeded Properties

        /// <summary>
        /// Gets a value indicating whether this instance is class cert score exceeded.
        /// </summary>
        public bool IsClassCertScoreExceeded
        {
            get { return ClassCertScore > 1 ? true : false; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is lot score exceeded.
        /// </summary>
        public bool IsLotScoreExceeded
        {
            get { return Lotscore > 0 ? true : false; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is vir score exceeded.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is vir score exceeded; otherwise, <c>false</c>.
        /// </value>
        public bool IsVirScoreExceeded
        {
            get { return Virscore > 6 ? true : false; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is pscdet score exceeded.
        /// </summary>
        public bool IsPscdetScoreExceeded
        {
            get
            {
                return PscdetScore > 0 ? true : false;
            }
        }

        #endregion

        #region Indicator Properties

        /// <summary>
        /// Gets the lot months since indicator.
        /// </summary>
        /// <value>
        /// The lot months since indicator.
        /// </value>
        public string LotMonthsSinceIndicator
        {
            get { return (IsLotScoreExceeded || loTmonthsSince == null) ? Constant.Red : Constant.Green; }
        }

        /// <summary>
        /// Gets the op3 months since indicator.
        /// </summary>
        /// <value>
        /// The op3 months since indicator.
        /// </value>
        public string Op3MonthsSinceIndicator
        {
            get { return (IsVirScoreExceeded || op3MonthsSince == null) ? Constant.Red : Constant.Green; }
        }

        /// <summary>
        /// Gets the detention indicator.
        /// </summary>
        /// <value>
        /// The detention indicator.
        /// </value>
        public string DetentionIndicator
        {
            get { return (IsPscdetScoreExceeded || dententions > 0) ? Constant.Red : Constant.Green; }
        }

        #endregion

    }
}
