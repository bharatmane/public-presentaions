﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using VShips.Framework.Common.ViewModel;
using VShips.Framework.Common.ViewModel.Menu;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An abstraction of a menu item for viewmodel binding.
    /// </summary>
    public interface IMenuItem : ICleanup
    {
        /// <summary>
        /// Gets or sets the label displayed on the menu.
        /// </summary>
        string Label { get; set; }

        /// <summary>
        /// Gets or sets the tooltip shown on the menu.
        /// </summary>
        string ToolTip { get; set; }

        /// <summary>
        /// Gets or sets the icon displayed on the menu.
        /// </summary>
        object Icon { get; set; }

        /// <summary>
        /// Gets or sets the command executed when the menu item is clicked.
        /// </summary>
        RelayCommand Command { get; set; }

        /// <summary>
        /// Gets or sets a value that determines if the menuitem can be checked using the <see cref="IsChecked"/> property.
        /// </summary>
        bool IsCheckable { get; set; }

        /// <summary>
        /// True if the item is currrently checked.
        /// This property is enabled when the <see cref="IsCheckable"/> is set to true.
        /// </summary>
        bool IsChecked { get; set; }

        /// <summary>
        /// Gets the sub items of the menu item. Menu items are hierarchical in structure. 
        /// This allows for that structure where menu items can contain sub menu items. 
        /// </summary>
        SpecialisedObservableCollection<MenuItem> Items { get; }
    }
}
