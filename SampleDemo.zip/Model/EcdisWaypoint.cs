﻿#pragma warning disable 1591
namespace VShips.Framework.Common.Model
{
    public class EcdisWaypoint
    {
        public string PosId { get; set; }
        public int WaypointNumber { get; set; }
        public bool IntermediateWaypoint { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Speed { get; set; }
        public double WaypointDistance { get; set; }
        public double CumulativeDistance { get; set; }
        public double WaypointTimeHours { get; set; }
        public double CumulativeTimeHours { get; set; }
    }
}