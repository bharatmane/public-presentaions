﻿using System;
using VShips.Framework.Common.Services;

namespace BM.Framework.Common.Model
{
    /// <summary>
    /// Used in the <see cref="INavigationContext"/> to record a history of any navigation.
    /// </summary>
    public class NavigationHistoryInfo 
    {
        private readonly string _moduleName;
        /// <summary>
        /// The name of the module.
        /// </summary>
        public string ModuleName
        {
            get { return _moduleName; }
        }

        private readonly string _viewName;
        /// <summary>
        /// The name of the view.
        /// </summary>
        public string ViewName
        {
            get { return _viewName; }
        }

        /// <summary>
        /// The parameter passed during navigation.
        /// </summary>
        public object Parameter { get;  internal set; }

        /// <summary>
        /// An action to run during navigation.
        /// </summary>
        public Action Action { get; internal set; }

        /// <summary>
        /// The default contructor for NavigationHistoryInfo.
        /// </summary>
        /// <param name="moduleName">The name of the module.</param>
        /// <param name="viewName">The name of the view.</param>
        /// <param name="parameter">The parameter passed during navigation.</param>
        /// <param name="action">An optional action to run during navigation.</param>
        internal NavigationHistoryInfo(string moduleName, string viewName, object parameter, Action action = null)
        {
            _moduleName = moduleName;
            _viewName = viewName;
            Parameter = parameter;
            Action = action;
        }

        /// <summary>
        /// Overrides the ToString method.
        /// </summary>
        /// <returns>The module and view names.</returns>
        public override string ToString()
        {
            return ModuleName + " - " + ViewName;
        }

        /// <summary>
        /// Sets the parameter.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void SetParameter(object parameter)
        {
            Parameter = parameter;
        }
    }
}
