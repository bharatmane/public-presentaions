﻿using System;
using System.Collections.Generic;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An interface that can be added on a collection.
    /// The RadGridView attached property uses this to persist and create data.
    /// </summary>
    public interface IEditableCollection
    {
        /// <summary>
        /// Gets or sets the add method action.
        /// </summary>
        /// <value>
        /// The add method action.
        /// </value>
        Action AddMethodAction
        {
            get;
            set;
        }

        /// <summary>
        /// Called when the RadGridView is deletes a row.
        /// </summary>
        /// <param name="item">The item to delete.</param>
        void Delete(object item);

        /// <summary>
        /// Called when the RadGridView begins an edit.
        /// </summary>
        /// <param name="item">The item to edit.</param>
        /// <param name="cancel">Allows the edit to be cancelled by setting cancel to true.</param>
        void BeginEdit(object item, ref bool cancel);

        /// <summary>
        /// Called when the RadGridView ends an edit. This can be called during either a commit or update.
        /// </summary>
        /// <param name="item">The item to edit.</param>
        void EndEdit(object item);

        /// <summary>
        /// Called when the RadGridView updates a row.
        /// </summary>
        /// <param name="item">The item to update.</param>
        void Update(object item);

        /// <summary>
        /// Called when the RadGridView validates a row.
        /// </summary>
        /// <param name="item">The item to validate.</param>
        /// <param name="oldValues">The old values.</param>
        /// <returns>
        /// True if the item is valid.
        /// The old values come from the DataMemberBinding property of the Grid View collection.
        /// The old values can be used only in case where the Data Member Binding is an object or is a nested object hierarchy
        /// </returns>
        bool Validate(object item, IDictionary<string, object> oldValues);

        /// <summary>
        /// Called when the RadGridView creates a row.
        /// </summary>
        /// <returns>The object to add to the RadGridView.</returns>
        object Create();
        
        /// <summary>
        /// Cancels the edit.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <param name="oldValues">The old values.</param>
        /// The old values come from the DataMemberBinding property of the Grid View collection.
        /// The old values can be used only in case where the Data Member Binding is an object or is a nested object hierarchy
        void CancelEdit(object item, IDictionary<string, object> oldValues);
    }
}
