﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

#pragma warning disable CS1591
#pragma warning disable CS1591

namespace VShips.Framework.Common.Model
{
    public class SeaRoutesWeatherResponse
    {
        public string type { get; set; }
        public List<SeaRoutesWeatherFeatures> features { get; set; }
        public JObject properties { get; set; }
    }


    public class SeaRoutesWeatherFeatures
    {
        private const double TOLERANCE = 0.0001;

        public double latitude { get; set; }
        public double longitude { get; set; }
        public long distance { get; set; }
        public long duration { get; set; }
        public long timestamp { get; set; }
        public string type { get; set; }
        public JObject properties { get; set; }
        public SeaRoutesWeatherGeometry geometry { get; set; }
        public int direction { get; set; }
        public SeaRoutesWeather weather { get; set; }

        public string VesselTrackDirection
        {
            get { return direction + "°"; }
        }

        public string VesselTrackDistance
        {
            get { return Math.Round((double)distance / 1852, 1) + "NM"; }
        }


        public double PenaltyCurrent
        {
            get
            {
                if (!weather.current.direction.HasValue || !weather.current.speed.HasValue) return 0;

                var differential = direction - weather.current.direction.Value;
                if (differential < -180) differential += 360;
                if (differential > 180) differential -= 360;
                return Math.Abs(differential) / 180 * (Math.Log10(weather.current.speed.Value + 1) * 10);
            }
        }
        public string CurrentSeverityColour
        {
            get { return PenaltyCurrent < TOLERANCE ? "black" : PenaltyCurrent > 1.5 ? "red" : PenaltyCurrent > 1 ? "orange" : PenaltyCurrent > 0.5 ? "yellow" : "green"; }
        }


        public double PenaltyWind
        {
            get
            {
                var differential = direction - weather.wind.direction;
                if (differential < -180) differential += 360;
                if (differential > 180) differential -= 360;
                return Math.Abs(differential) / 180 * (Math.Log10(weather.wind.speed + 1) * 10);
            }
        }
        public string WindSeverityColour
        {
            get { return PenaltyWind < TOLERANCE ? "black" : PenaltyWind > 15 ? "red" : PenaltyWind > 10 ? "orange" : PenaltyWind > 5 ? "yellow" : "green"; }
        }


        public double PenaltyWaves
        {
            get
            {
                if (!weather.wave.direction.HasValue || !weather.wave.speed.HasValue) return 0;

                var differential = direction - weather.wave.direction.Value;
                if (differential < -180) differential += 360;
                if (differential > 180) differential -= 360;
                return Math.Abs(differential) / 180 * (Math.Log10(weather.wave.speed.Value + 1) * 10 * (weather.wave.height.Value + 0.5));
            }
        }
        public string WaveSeverityColour
        {
            get { return PenaltyWaves < TOLERANCE ? "black" : PenaltyWaves > 35 ? "red" : PenaltyWaves > 25 ? "orange" : PenaltyWaves > 15 ? "yellow" : "green"; }
        }


        public string WeatherSeverityColour
        {
            get
            {
                if (CurrentSeverityColour == "red" || WaveSeverityColour == "red" || WindSeverityColour == "red") return "red";
                if (CurrentSeverityColour == "orange" || WaveSeverityColour == "orange" || WindSeverityColour == "orange") return "orange";
                if (CurrentSeverityColour == "yellow" || WaveSeverityColour == "yellow" || WindSeverityColour == "yellow") return "yellow";
                return "green";
            }
        }
    }


    public class SeaRoutesWeatherGeometry
    {
        public string type { get; set; }
        public List<double> coordinates { get; set; }
    }


    public class SeaRoutesWeather
    {
        private const double TOLERANCE = 0.0001;

        public double latitude { get; set; }
        public double longitude { get; set; }
        public double timestamp { get; set; }
        public SeaRoutesAir air { get; set; }
        public JObject precipitation { get; set; }
        public SeaRoutesWave wave { get; set; }
        public SeaRoutesWater water { get; set; }
        public SeaRoutesCurrent current { get; set; }
        public SeaRoutesWind wind { get; set; }
        public JObject condition { get; set; }
        public double cloudCoverage { get; set; }
        public double iceCoverage { get; set; }
        public bool isLand { get; set; }


        public string RequestedLatLong
        {
            get
            {
                var latitudeStr = Math.Abs(Math.Round(latitude, 4)) + (latitude >= 0 ? "°N" : "°S");
                var longitudeStr = Math.Abs(Math.Round(longitude, 4)) + (longitude >= 0 ? "°E" : "°W");
                return latitudeStr + " " + longitudeStr;
            }
        }

        public string TimeOfWeather
        {
            get
            {
                var dt = new DateTime(1970, 1, 1).AddMilliseconds(timestamp);
                return dt.ToShortDateString() + " " + dt.ToShortTimeString() + " [UTC]";
            }
        }

        public string Temperature
        {
            get
            {
                return (air != null && air.temperature != null ? air.temperature.value + "°C" : "No data")
                    + " / " + (water != null && water.temperature != null ? water.temperature.value + "°C" : "No data");
            }
        }

        public string Current
        {
            get
            {
                return ((!current.speed.HasValue && !current.direction.HasValue) || (Math.Abs(current.speed.Value) < TOLERANCE && Math.Abs(current.direction.Value) < TOLERANCE)) ? "No data"
                    : Math.Round(current.speed.Value, 1) + "m/s  " + current.direction.Value + "°";
            }
        }

        public string Wind
        {
            get
            {
                return (Math.Abs(wind.speed) < TOLERANCE && wind.direction == 0) ? "No data"
                    : Math.Round(wind.speed, 1) + "m/s  F" + wind.beaufort + "  " + wind.direction + "°";
            }
        }

        public string Wave
        {
            get
            {
                return ((!wave.height.HasValue && !wave.direction.HasValue && !wave.speed.HasValue) || (Math.Abs(wave.height.Value) < TOLERANCE && Math.Abs(wave.speed.Value) < TOLERANCE && Math.Abs(wave.direction.Value) < TOLERANCE)) ? "No data"
                    : Math.Round(wave.height.Value, 1) + "m  " + Math.Round(wave.speed.Value) + "m/s  " + Math.Round(wave.direction.Value, 1) + "°";
            }
        }

    }


    public class SeaRoutesAir
    {
        public SeaRoutesTemperature temperature { get; set; }
        public double humidity { get; set; }
        public double pressure { get; set; }
    }


    public class SeaRoutesWave
    {
        public double? height { get; set; }
        public double? period { get; set; }
        public double? length { get; set; }
        public SeaRoutesVector vector { get; set; }
        public double? speed { get; set; }

        private double? _direction;
        public double? direction
        {
            get { return _direction; }
            set
            {
                if (!value.HasValue)
                {
                    _direction = value;
                    return;
                }
                _direction = value.Value < 180 ? value + 180 : value - 180;
            }
        }
    }


    public class SeaRoutesWater
    {
        public SeaRoutesTemperature temperature { get; set; }
        public double? salinity { get; set; }
    }


    public class SeaRoutesTemperature
    {
        public double value { get; set; }
        public SeaRoutesDailyTemperature last3Hours { get; set; }
        public SeaRoutesDailyTemperature daily { get; set; }
    }


    public class SeaRoutesDailyTemperature
    {
        public double max { get; set; }
        public double min { get; set; }
    }


    public class SeaRoutesCurrent
    {
        public SeaRoutesVector vector { get; set; }
        public double? speed { get; set; }

        private double? _direction;
        public double? direction
        {
            get { return _direction; }
            set
            {
                if (!value.HasValue)
                {
                    _direction = value;
                    return;
                }
                _direction = value.Value < 180 ? value + 180 : value - 180;
            }
        }
    }


    public class SeaRoutesWind
    {
        public SeaRoutesVector vector { get; set; }
        public double gust { get; set; }
        public double speed { get; set; }
        public int beaufort { get; set; }

        private double _direction;
        public double direction
        {
            get { return _direction; }
            set
            {
                _direction = value < 180 ? value + 180 : value - 180;
            }
        }
    }

    public class SeaRoutesVector
    {
        public double? u { get; set; }
        public double? v { get; set; }
    }
}
