﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using System.Windows.Interop;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// This class is a common static method collection
    /// </summary>
    public static class SharedFunctions
    {
        private static string _path = null;
        /// <summary>
        /// Captures the screen.
        /// </summary>
        /// <param name="targetPath">The target path.</param>
        /// <param name="targetFileName">Name of the target file.</param>
        /// <returns>Single string</returns>
        public static string CaptureScreen(string targetPath, string targetFileName)
        {
            try
            {
                //Get the handle of application.
                var _applicationHandle = new WindowInteropHelper(System.Windows.Application.Current.MainWindow).Handle;

                //Creating a new Bitmap object
                Bitmap captureBitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

                //Creating a Rectangle object which will  
                //capture our Current Screen where application is placed.
                Rectangle captureRectangle = Screen.FromHandle(_applicationHandle).Bounds;

                //Creating a New Graphics Object
                Graphics captureGraphics = Graphics.FromImage(captureBitmap);

                //Copying Image from The Screen
                captureGraphics.CopyFromScreen(captureRectangle.Left, captureRectangle.Top, 0, 0, captureRectangle.Size);

                //Combine the path and file name to create full path for saving screen shot.
                var screenShotFilePath = Path.Combine(targetPath, targetFileName);

                //Saving the Image File.
                captureBitmap.Save(screenShotFilePath, ImageFormat.Jpeg);

                //Dispose object after saving file.
                captureBitmap.Dispose();

                return screenShotFilePath;
            }
            catch (Exception)
            {
                return "";
            }

        }


        /// <summary>
        /// Gets the application error log path.
        /// </summary>
        /// <returns></returns>
        public static string GetApplicationErrorLogPath()
        {
            if (!string.IsNullOrWhiteSpace(_path))
            {
                if (!Directory.Exists(_path))
                {
                    Directory.CreateDirectory(_path);
                }
                return _path;
            }

            if (Convert.ToBoolean(ConfigurationManager.AppSettings.Get(Constant.IsVesselApplication)))
            {
                _path = ConfigurationManager.AppSettings.Get("VesselShipsureApplicationLogFolder");
            }
            else
            {
                _path = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                if (
                    !string.IsNullOrWhiteSpace(_path)
                    &&
                    !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings.Get("StorageFolderName"))
                    &&
                    !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings.Get("ErrorLogFolderName"))
                )
                {


                    _path = Path.Combine(_path, ConfigurationManager.AppSettings.Get("StorageFolderName"), ConfigurationManager.AppSettings.Get("ErrorLogFolderName"));



                    //try
                    //{
                    //    var stream = File.CreateText(Path.Combine(_path, "test_log_file.txt"));
                    //    stream.Dispose();
                    //    File.Delete(Path.Combine(_path, "test_log_file.txt"));
                    //}
                    //catch (Exception)
                    //{
                    //    _path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                    //    if (
                    //        !string.IsNullOrWhiteSpace(_path)
                    //        &&
                    //        !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings.Get("StorageFolderName"))
                    //        &&
                    //        !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings.Get("ErrorLogFolderName"))
                    //    )
                    //    {
                    //        _path = Path.Combine(_path, ConfigurationManager.AppSettings.Get("StorageFolderName"), ConfigurationManager.AppSettings.Get("ErrorLogFolderName"));
                    //        if (!Directory.Exists(_path))
                    //        {
                    //            Directory.CreateDirectory(_path);
                    //        }
                    //        try
                    //        {
                    //            var stream = File.CreateText(Path.Combine(_path, "test_log_file.txt"));
                    //            stream.Dispose();
                    //            File.Delete(Path.Combine(_path, "test_log_file.txt"));
                    //        }
                    //        catch (Exception)
                    //        {
                    //        }
                    //    }
                    //}
                }
            }

            if (!Directory.Exists(_path))
            {
                Directory.CreateDirectory(_path);
            }

            if (ConfigurationManager.AppSettings.Get("Environment") != null)
            {
                _path = Path.Combine(_path, ConfigurationManager.AppSettings.Get("Environment"));
            }

            return _path;
        }

        /// <summary>
        /// Temporary fix : Method is used to fetch user preference for crew module.
        /// </summary>
        /// <returns>Single object of type <see cref="string"/></returns>
        public static string GetCrewingUserPreferences()
        {
            string _userPreferenceDirectoryPath = null;

            if (!string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings.Get("StorageFolderName")))
            {
                _userPreferenceDirectoryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                                                            ConfigurationManager.AppSettings.Get("StorageFolderName"),
                                                            "UserPreferences");
                if (!Directory.Exists(_userPreferenceDirectoryPath))
                {
                    Directory.CreateDirectory(_userPreferenceDirectoryPath);
                }
            }
            return _userPreferenceDirectoryPath;
        }

        /// <summary>
        /// Gets the file size in bytes.
        /// </summary>
        /// <param name="size">The size.</param>
        /// <returns></returns>
        public static string GetFileSizeInBytes(int size)
        {
            string sizeInBytes = string.Empty;
            if (size != 0)
            {
                decimal _size = Math.Round((decimal)size / (1024 * 1024), 2);
                sizeInBytes = _size.ToString() + " MB";
            }
            return sizeInBytes;
        }

        /// <summary>
        /// Gets the image extension list.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetImageExtensionList()
        {
            return new List<string>() { ".jpg", ".jpeg", ".bmp", ".gif", ".png" };
        }

        /// <summary>
        /// Gets the allowed document extension to view list.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetAllowedDocumentExtensionToViewList()
        {
            return new List<string>() { ".jpg", ".jpeg", ".bmp", ".gif", ".png", ".pdf" };
        }
    }
}
