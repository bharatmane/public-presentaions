﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// This clas is used to store the response after queue is created.
    /// </summary>
    public class CustomQueueResponse
    {
        /// <summary>
        /// Gets or sets the response identifier.
        /// </summary>
        /// <value>
        /// The response identifier.
        /// </value>
        public string ResponseId { get; set; }

        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>
        /// The file path.
        /// </value>
        public string FilePath { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is success.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is success; otherwise, <c>false</c>.
        /// </value>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// Gets or sets the additional information.
        /// </summary>
        /// <value>
        /// The additional information.
        /// </value>
        public object AdditionalInformation { get; set; }

        /// <summary>
        /// Gets or sets the refresh required.
        /// </summary>
        /// <value>
        /// The refresh required.
        /// </value>
        public bool RefreshRequired { get; set; }

        /// <summary>
        /// Gets or sets the content of the message.
        /// </summary>
        /// <value>
        /// The content of the message.
        /// </value>
        public string MessageContent { get; set; }
    }
}
