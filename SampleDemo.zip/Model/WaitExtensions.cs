﻿using System;
using System.ServiceModel;
using System.Threading;
using System.Threading.Tasks;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// A set of extension methods for waiting tasks.
    /// </summary>
    public static class WaitExtensions
    {
        /// <summary>
        /// An extension method that makes it easy to provide a task cancelation token.
        /// </summary>
        /// <typeparam name="T">The type of task.</typeparam>
        /// <param name="task">The task.</param>
        /// <param name="cancellationToken">A cancellation token.</param>
        /// <returns>An async Task.</returns>
        public static async Task<T> WithWaitCancellation<T>(this Task<T> task, CancellationToken cancellationToken)
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                // The task completion source. 
                var tcs = new TaskCompletionSource<bool>();

                // Register with the cancellation token.
                using (cancellationToken.Register(s => ((TaskCompletionSource<bool>) s).TrySetResult(true), tcs))
                {
                    // If the task waited on is the cancellation token...
                    if (task != await Task.WhenAny(task, tcs.Task))
                    {
                        throw new OperationCanceledException(cancellationToken);
                    }
                }

                // Wait for one or the other to complete.
                return await task;
            }
            throw new OperationCanceledException(cancellationToken);
        }

        /// <summary>
        /// An extension method that makes it easy to provide a task cancelation token.
        /// </summary>
        /// <param name="task">The task.</param>
        /// <param name="cancellationToken">A cancellation token.</param>
        /// <returns>An async Task.</returns>
        public static async Task WithWaitCancellation(this Task task, CancellationToken cancellationToken)
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                // The task completion source. 
                var tcs = new TaskCompletionSource<bool>();

                // Register with the cancellation token.
                using (cancellationToken.Register(s => ((TaskCompletionSource<bool>)s).TrySetResult(true), tcs))
                {
                    // If the task waited on is the cancellation token...
                    if (task != await Task.WhenAny(task, tcs.Task))
                    {
                        throw new OperationCanceledException(cancellationToken);
                    }
                }

                // Wait for one or the other to complete.
                await task;
            }
            //throw new OperationCanceledException(cancellationToken);
        }

        /// <summary>
        /// An extension method that makes it easy to provide a task cancelation token.
        /// This also cancels the IClientChannel.
        /// </summary>
        /// <param name="task">The task.</param>
        /// <param name="cancellationToken">A cancellation token.</param>
        /// <param name="proxy"></param>
        /// <returns>An async Task.</returns>
        public static async Task WithWaitCancellation(this Task task, CancellationToken cancellationToken, IClientChannel proxy)
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                // The task completion source. 
                var tcs = new TaskCompletionSource<bool>();

                // Register with the cancellation token.
                using (cancellationToken.Register(s => ((TaskCompletionSource<bool>)s).TrySetResult(true), tcs))
                {
                    // If the task waited on is the cancellation token...
                    if (task != await Task.WhenAny(task, tcs.Task))
                    {
                        proxy.Abort();
                        throw new OperationCanceledException(cancellationToken);
                    }
                }

                // Wait for one or the other to complete.
                await task;
            }
        }

        /// <summary>
        /// Wraps a task with a try catch for an OperationCanceledException.
        /// </summary>
        public static async Task WithCatchCancellation(this Task task)
        {
            try
            {
                await task;
            }
            catch (OperationCanceledException)
            {
            }
        }

        /// <summary>
        /// Wraps a task with a try catch for an OperationCanceledException.
        /// </summary>
        public static async Task<T> WithCatchCancellation<T>(this Task<T> task)
        {
            try
            {
                return await task;
            }
            catch (OperationCanceledException)
            {
            }
            return await Task.FromResult(default(T));
        }
    }
}
