﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An object used to define a mail message.
    /// </summary>
    public class Message
    {
        /// <summary>
        /// The subject of the message.
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// The body of the message.
        /// </summary>
        public string Body { get; set; }

        private readonly List<string> _toRecipients;
        /// <summary>
        /// Who the message is sent to.
        /// </summary>
        public List<string> ToRecipients
        {
            get { return _toRecipients; }
        }

        private readonly List<string> _ccRecipients;
        /// <summary>
        /// Who to copy in on the message.
        /// </summary>
        public List<string> CCRecipients
        {
            get { return _ccRecipients; }
        }

        private readonly List<string> _bccRecipients;
        /// <summary>
        /// Who to blind copy in on the message.
        /// </summary>
        public List<string> BCCRecipients
        {
            get { return _bccRecipients; }
        }

        private readonly List<string> _attachements;
        /// <summary>
        /// A list of filenames representing the message attachments.
        /// </summary>
        public List<string> Attachements
        {
            get { return _attachements; }
        }

        /// <summary>
        /// Gets or sets a value indicating how the body of the message is formatted. The default is text.
        /// </summary>
        public MessageBodyTypes BodyType { get; set; }

        /// <summary>
        /// The default contructor for the message.
        /// </summary>
        public Message()
        {
            _toRecipients = new List<string>();
            _ccRecipients = new List<string>();
            _bccRecipients = new List<string>();
            _attachements = new List<string>();
            BodyType = MessageBodyTypes.Text;
        }
    }

    /// <summary>
    /// Defines how the body of the message is formatted.
    /// </summary>
    public enum MessageBodyTypes
    {
        /// <summary>
        /// Formatted as Text(Default).
        /// </summary>
        Text,

        /// <summary>
        /// Formatted as HTML.
        /// </summary>
        HTML
    }
}
