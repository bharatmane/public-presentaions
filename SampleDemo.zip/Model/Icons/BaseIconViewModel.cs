﻿using GalaSoft.MvvmLight;

namespace VShips.Framework.Common.Model.Icons
{
    /// <summary>
    /// An abstract class for defining viewmodel based icons.
    /// </summary>
    public abstract class BaseIconViewModel : ObservableObject
    {
        private readonly object _value;
        /// <summary>
        /// The bindable value for the icon.
        /// </summary>
        public object Value
        {
            get { return _value; }
        }

        /// <summary>
        /// The default contructor for BaseIconViewModel.
        /// </summary>
        /// <param name="value">The value for the icon.</param>
        protected BaseIconViewModel(object value)
        {
            _value = value;
        }
    }
}
