﻿namespace VShips.Framework.Common.Model.Icons
{
    /// <summary> 
    /// <para>
    /// A way to create an icon based on an application resource. 
    /// </para>
    /// <para>
    /// A datatemplate is provided in the resources assembly for this type. It creates a path,
    /// binds its data to the Value property and uses a converter to look up the resource.
    /// </para>
    /// </summary>
    public class ResourceIcon : BaseIconViewModel
    {
        /// <summary>
        /// The default contructor for the ResourceIcon.
        /// </summary>
        /// <param name="resourcePath">The name or path of the resource referencing a path geometry.</param>
        public ResourceIcon(string resourcePath)
            : base(resourcePath)
        {
        }
    }
}
