﻿namespace VShips.Framework.Common.Model.Icons
{
    /// <summary>
    /// Classes that allow you define icons in the view model.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
