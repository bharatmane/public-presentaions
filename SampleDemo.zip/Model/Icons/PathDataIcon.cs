﻿namespace VShips.Framework.Common.Model.Icons
{
    /// <summary>
    /// <para>
    /// A way to create an icon based on path data or geometry definitions.
    /// </para>
    /// <para>
    /// A datatemplate is provided in the resources assembly for this type. It creates a path
    /// and binds its data to the Value property.
    /// </para>
    /// </summary>
    public class PathDataIcon : BaseIconViewModel
    {
        /// <summary>
        /// The default constructor for the icon which expects the data as string.
        /// </summary>
        /// <param name="data">The string definition for the path geometry.</param>
        public PathDataIcon(string data)
            : base(data)
        {
        }
    }
}
