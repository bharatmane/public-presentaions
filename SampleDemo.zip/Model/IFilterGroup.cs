﻿using System.Collections;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An interface representing a class that groups filters.
    /// </summary>
    public interface IFilterGroup : IFilterItem, IList
    {
        /// <summary>
        /// If the group is currently expanded.
        /// </summary>
        bool IsExpanded { get; set; }
    }
}
