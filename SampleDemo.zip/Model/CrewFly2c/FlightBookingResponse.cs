﻿namespace VShips.Framework.Common.Model.CrewFly2c
{
    /// <summary>
    /// BookingResponse Class
    /// </summary>
    public class FlightBookingResponse
    {
        /// <summary>
        /// Gets or sets the URL.
        /// </summary>
        /// <value>
        /// The URL.
        /// </value>
        public string URL { get; set; }
    }
}