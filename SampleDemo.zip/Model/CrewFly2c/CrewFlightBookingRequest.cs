﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewFly2c
{
    /// <summary>
    /// CrewFlightBookingRequest Class
    /// </summary>
    public class CrewFlightBookingRequest
    {
        /// <summary>
        /// Gets or sets the tri ids.
        /// </summary>
        /// <value>
        /// The tri ids.
        /// </value>
        public List<string> TriIds { get; set; }
    }
}