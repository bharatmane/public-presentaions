﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model.CrewFly2c
{
    /// <summary>
    /// FlightBookingRequest Class
    /// </summary>
    public class FlightBookingRequest
    {
        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public string VesselId { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the tri ids.
        /// </summary>
        /// <value>
        /// The tri ids.
        /// </value>
        public List<string> TriIds { get; set; }
    }
}