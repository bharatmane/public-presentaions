﻿using System;

namespace VShips.Framework.Common.Model.CrewFly2c
{
    /// <summary>
    /// CrewFlightBookingDetails Class
    /// </summary>
    public class CrewFlightBookingDetails
    {
        /// <summary>
        /// Gets or sets the tri identifier.
        /// </summary>
        /// <value>
        /// The tri identifier.
        /// </value>
        public string TriId { get; set; }

        /// <summary>
        /// Gets or sets the booking status.
        /// </summary>
        /// <value>
        /// The booking status.
        /// </value>
        public int? BookingStatus { get; set; }

        /// <summary>
        /// Gets or sets from.
        /// </summary>
        /// <value>
        /// From.
        /// </value>
        public string From { get; set; }

        /// <summary>
        /// Gets or sets from desc.
        /// </summary>
        /// <value>
        /// From desc.
        /// </value>
        public string FromDesc { get; set; }

        /// <summary>
        /// Gets or sets to.
        /// </summary>
        /// <value>
        /// To.
        /// </value>
        public string To { get; set; }

        /// <summary>
        /// Gets or sets to desc.
        /// </summary>
        /// <value>
        /// To desc.
        /// </value>
        public string ToDesc { get; set; }

        /// <summary>
        /// Gets or sets the departure date time.
        /// </summary>
        /// <value>
        /// The departure date time.
        /// </value>
        public DateTime? DepartureDateTime { get; set; }

        /// <summary>
        /// Gets or sets the arrival date time.
        /// </summary>
        /// <value>
        /// The arrival date time.
        /// </value>
        public DateTime? ArrivalDateTime { get; set; }

        /// <summary>
        /// Gets or sets the PNR.
        /// </summary>
        /// <value>
        /// The PNR.
        /// </value>
        public string PNR { get; set; }

        /// <summary>
        /// Gets or sets the flight details.
        /// </summary>
        /// <value>
        /// The flight details.
        /// </value>
        public string FlightDetails { get; set; }

        /// <summary>
        /// Gets or sets the duration of the flight.
        /// </summary>
        /// <value>
        /// The duration of the flight.
        /// </value>
        public int? FlightDuration { get; set; }
    }
}