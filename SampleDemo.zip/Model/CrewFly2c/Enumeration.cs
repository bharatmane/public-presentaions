﻿namespace VShips.Framework.Common.Model.CrewFly2c.Enumeration
{
    /// <summary>
    /// CrewStatusEnum Class
    /// </summary>
    public enum CrewStatusEnum
    {
        /// <summary>
        /// The offsigner
        /// </summary>
        Offsigner = 0,

        /// <summary>
        /// The onsigner
        /// </summary>
        Onsigner = 1

    }
}