﻿using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using VShips.Contracts.DtoClasses.ReportGroupLightTypes;
using VShips.DataServices.Shared.Contracts.Common;
using VShips.Framework.Common.DataServices;
using VShips.Framework.Common.Model.Icons;
using VShips.Framework.Common.Services;
using VShips.Framework.Common.ViewModel;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An extended verson of the module catalogue allowing modules to be removed.
    /// </summary>
    public class ModuleInfoExtended : Microsoft.Practices.Prism.Modularity.ModuleInfo
    {
        private readonly IUnityContainer _container;
        private readonly ILoggerService _loggerService;

        /// <summary>
        /// Gets or sets if the user has rights.
        /// </summary>
        internal bool HasRights { get; set; }

        /// <summary>
        /// If the module is required by the framework.
        /// </summary>
        public bool IsRequired { get; set; }

        /// <summary>
        /// The icon used by the module.
        /// </summary>
        public BaseIconViewModel Icon { get; private set; }

        /// <summary>
        /// If the module is loaded.
        /// </summary>
        public bool IsLoaded { get; private set; }

        /// <summary>
        /// If the module is loaded.
        /// </summary>
        public bool IsLoading { get; private set; }

        private readonly List<string> _registeredViews;
        /// <summary>
        /// Any views registered against the module.
        /// </summary>
        public List<string> RegisteredViews
        {
            get { return _registeredViews; }
        }

        private readonly List<string> _registeredViewModels;
        /// <summary>
        /// The viewmodels registered with the view as its datacontexts.
        /// </summary>
        public List<string> RegisteredViewModels
        {
            get { return _registeredViewModels; }
        }

        private List<ControlPermission> _security;
        /// <summary>
        /// The security keys for the loaded module.
        /// </summary>
        public List<ControlPermission> Security
        {
            get { return _security; }
        }

        /// <summary>
        /// The mapped reports
        /// </summary>
        private List<Report> _mappedReports;

        /// <summary>
        /// Gets the mapped reports.
        /// </summary>
        /// <value>
        /// The mapped reports.
        /// </value>
        public List<Report> MappedReports
        {
            get { return _mappedReports; }
        }

        /// <summary>
        /// The default constructor for module info.
        /// </summary>
        public ModuleInfoExtended(IUnityContainer container, ILoggerService loggerService)
        {
            _container = container;
            _loggerService = loggerService;
            _registeredViews = new List<string>();
            _registeredViewModels = new List<string>();
        }

        internal void UnLoad()
        {
            HasRights = false;
            IsLoaded = false;
            IsLoading = false;
        }

        internal async Task Load(IModuleManager moduleManager)
        {
            IsLoading = true;
            _loggerService.Info(String.Format("{0} module loading!", ModuleName));
            if (!IsRequired)
            {
                moduleManager.LoadModule(ModuleName);
            }
            await InitialiseSecurity();
            await InitialiseReports();
        }

        internal void Loaded(ModuleInfo info)
        {
            IsLoaded = true;
            IsRequired = info.IsRequired;
            Icon = info.Icon;
            _loggerService.Info(String.Format("{0} module loaded!", ModuleName));
            IsLoading = false;
        }

        internal void RegisterView<T>(string viewName) where T : FrameworkElement
        {
            var regName = viewName.ToUpper();
            Debug.Assert(!_registeredViews.Contains(regName), "The view is already registered with the module!");

            _container.RegisterType<FrameworkElement, T>(regName);
            _registeredViews.Add(regName);
        }

        internal void RegisterView<T, TViewModel>(string viewName)
            where T : FrameworkElement
            where TViewModel : BaseNavigationViewModel
        {
            var regName = viewName.ToUpper();
            var vmRegName = regName + "VIEWMODEL";
            Debug.Assert(!_registeredViews.Contains(regName), "The view is already registered with the module!");

            _container.RegisterType<FrameworkElement, T>(regName);
            _container.RegisterType<BaseNavigationViewModel, TViewModel>(vmRegName);
            _registeredViews.Add(regName);
            _registeredViewModels.Add(vmRegName);
        }

        internal void RegisterView<T, TViewModel>(string viewName, InjectionConstructor constructor)
           where T : FrameworkElement
           where TViewModel : BaseNavigationViewModel
        {
            var regName = viewName.ToUpper();
            var vmRegName = regName + "VIEWMODEL";
            Debug.Assert(!_registeredViews.Contains(regName), "The view is already registered with the module!");

            _container.RegisterType<FrameworkElement, T>(regName);
            _container.RegisterType<BaseNavigationViewModel, TViewModel>(vmRegName, constructor);
            _registeredViews.Add(regName);
            _registeredViewModels.Add(vmRegName);
        }

        internal FrameworkElement GetView(string viewName)
        {
            var regName = viewName.ToUpper();
            var vmRegName = regName + "VIEWMODEL";
            Debug.Assert(_registeredViews.Contains(regName), "The view is not registered with the module!");

            FrameworkElement view = null;
            if (_registeredViews.Contains(regName))
            {
                view = _container.Resolve<FrameworkElement>(regName);
                if (_registeredViewModels.Contains(vmRegName))
                {
                    view.DataContext = _container.Resolve<BaseNavigationViewModel>(vmRegName);
                }
            }

            return view;
        }

        // Override of the GetView Method that accepts parameters for the viewmodel constructor
        internal FrameworkElement GetView(string viewName, ParameterOverrides parameters)
        {
            var regName = viewName.ToUpper();
            var vmRegName = regName + "VIEWMODEL";
            Debug.Assert(_registeredViews.Contains(regName), "The view is not registered with the module!");

            FrameworkElement view = null;
            if (_registeredViews.Contains(regName))
            {
                view = _container.Resolve<FrameworkElement>(regName);
                if (_registeredViewModels.Contains(vmRegName))
                {
                    view.DataContext = _container.Resolve<BaseNavigationViewModel>(vmRegName, parameters);
                }
            }

            return view;
        }

        internal bool ContainsView(string viewName)
        {
            var regName = viewName.ToUpper();

            return _registeredViews.Contains(regName);
        }
        /// <summary>
        /// Initialises security
        /// </summary>
        /// <returns>Single Task object</returns>
        public async Task InitialiseSecurity()
        {
            var service = ServiceLocator.Current.GetInstance<IDataService>().SecurityDataService;
            _security = await service.GetModuleSecurity(ModuleName);
        }

        /// <summary>
        /// Initialises the reports.
        /// </summary>
        public async Task InitialiseReports()
        {
            var service = ServiceLocator.Current.GetInstance<IDataService>().Shared;
            _mappedReports = await service.GetUserReportsByModuleName(ModuleName, new System.Threading.CancellationToken());
        }
    }
}
