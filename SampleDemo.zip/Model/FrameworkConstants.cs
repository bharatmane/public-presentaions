﻿namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Constant strings that can be used to display consistant information to the user.
    /// </summary>
    public static class FrameworkConstants
    {
        /// <summary>
        /// Prompt for discarding changes.
        /// </summary>
        public const string AppConstDiscardChanges = "Do you wish to discard changes?";

        /// <summary>
        /// Alert showing the feature is not ready.
        /// </summary>
        public const string AppConstFeatureNotReady = "This feature is not yet available";

        /// <summary>
        /// Prompt before shutting down the app.
        /// </summary>
        public const string AppConstConfirmShutdown = "Are you sure you wish to close the application?";

        /// <summary>
        /// Alert for a specific view being busy.
        /// </summary>
        public const string AppConstViewBusyName = "{0} module is currently busy";

        /// <summary>
        /// Alert for a specific view having changes.
        /// </summary>
        public const string AppConstViewUnsavedChanges = "{0} module has unsaved changes.";

    }
}
