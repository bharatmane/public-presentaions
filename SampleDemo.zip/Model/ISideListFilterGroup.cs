﻿using System;
using GalaSoft.MvvmLight;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// An interface representing a class that groups filters.
    /// </summary>
    public interface ISideListFilterGroup : ICleanup
    {
        /// <summary>
        /// Raised when the is checked changes.
        /// </summary>
        event EventHandler<EventArgs> IsCheckedChanged;

        /// <summary>
        /// The title for the group.
        /// </summary>
        string Title { get; set; }
    }
}
