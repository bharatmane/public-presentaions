﻿using System.Collections.Generic;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Represents a modules security.
    /// </summary>
    public class ModuleSecurity
    {
        private readonly string _moduleName;
        /// <summary>
        /// The name of the module.
        /// </summary>
        public string ModuleName
        {
            get { return _moduleName; }
        }

        private readonly Dictionary<string, ModuleSecurityKey> _keys;
        /// <summary>
        /// Its associated keys.
        /// </summary>
        public Dictionary<string, ModuleSecurityKey> Keys
        {
            get { return _keys; }    
        }

        /// <summary>
        /// The default constructor.
        /// </summary>     
        public ModuleSecurity(string moduleName, IEnumerable<ModuleSecurityKey> keys)
        {
            _moduleName = moduleName;
            _keys = new Dictionary<string, ModuleSecurityKey>();
            foreach (var item in keys)
            {
                _keys.Add(item.Key, item);
            }
        }

        /// <summary>
        /// Gets a module security key for a control.
        /// </summary>
        public ModuleSecurityKey GetSecurityKey(string key)
        {
            return Keys.ContainsKey(key) ? Keys[key] : new ModuleSecurityKey(key, false);
        }
    }

    /// <summary>
    /// Represents the accesebility of controls within a view.
    /// </summary>
    public class ModuleSecurityKey
    {
        private readonly string _key;
        /// <summary>
        /// The key for the control.
        /// </summary>
        public string Key
        {
            get { return _key; }            
        }

        private readonly bool _hasAccess;
        /// <summary>
        /// Returns true if that particular control is accesable by the current logged in user.
        /// </summary>
        public bool HasAccess
        {
            get { return _hasAccess; }            
        }

        /// <summary>
        /// The default constructor.
        /// </summary> 
        public ModuleSecurityKey(string key, bool hasAccess)
        {
            _key = key;
            _hasAccess = hasAccess;
        }
    }
}
