﻿using System.ComponentModel;
namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Defines the Risk Severity Categories
    /// </summary>
    public enum RiskSeverity
    {

        [Description("Minor")]
        Minor = 1,
        [Description("Moderate")]
        Moderate = 2,
        [Description("Severe")]
        Severe = 3,
        [Description("Major")]
        Major = 4,
        [Description("Critical")]
        Critical = 5,
        [Description("Disastrous")]
        Disastrous = 6
    }
}