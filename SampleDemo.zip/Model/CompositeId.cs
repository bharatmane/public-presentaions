﻿using System;
using System.Diagnostics;

namespace VShips.Framework.Common.Model
{
    /// <summary>
    /// Used to manage entities that have multiple Ids.
    /// </summary>
    public class CompositeId
    {
        #region Private Variables

        /// <summary>
        /// The seperator
        /// </summary>
        private const string Seperator = "|-x-x-|";

        #endregion

        #region Properties

        /// <summary>
        /// The id1
        /// </summary>
        private readonly string _id1;

        /// <summary>
        /// The primary Id.
        /// </summary>
        public string Id1
        {
            get { return _id1; }
        }

        /// <summary>
        /// The id2
        /// </summary>
        private readonly string _id2;

        /// <summary>
        /// The secondary Id.
        /// </summary>
        public string Id2
        {
            get { return _id2; }
        }

        /// <summary>
        /// The is memo tab selected
        /// </summary>
        private bool _isMemoTabSelected;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is memo tab selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is memo tab selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsMemoTabSelected
        {
            get { return _isMemoTabSelected; }
        }

        #endregion

        #region Constructors
        
        /// <summary>
        /// The contructor for the CompositeId.
        /// </summary>
        /// <param name="id1">The primary Id.</param>
        /// <param name="id2">The secondary Id.</param>
        public CompositeId(string id1, string id2)
        {
            _id1 = id1;
            _id2 = id2;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CompositeId"/> class.
        /// </summary>
        /// <param name="id1">The id1.</param>
        /// <param name="id2">The id2.</param>
        /// <param name="isMemoTabSelected">if set to <c>true</c> [is memo tab selected].</param>
        public CompositeId(string id1, string id2, bool isMemoTabSelected)
        {
            _id1 = id1;
            _id2 = id2;
            _isMemoTabSelected = isMemoTabSelected;
        }

        #endregion

        #region Overridden Methods
        
        /// <summary>
        /// Composes the Ids into a single string.
        /// </summary>
        /// <returns>A string representing both <see cref="Id1"/> and <see cref="Id2"/>.</returns>
        public override string ToString()
        {
            return Id1 + Seperator + Id2;
        }

        /// <summary>
        /// Returns true if the comparison object is a <see cref="CompositeId"/>
        /// and both id1 and id2 values match.
        /// </summary>
        /// <param name="obj">The object to compare.</param>
        /// <returns>True if the object are deemed equal.</returns>
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is CompositeId && Equals((CompositeId)obj);
        }


        /// <summary>
        /// Gets the object hash code.
        /// </summary>
        /// <returns>The object hash code.</returns>
        public override int GetHashCode()
        {
            unchecked
            {
                return ((_id1 != null ? _id1.GetHashCode() : 0) * 397) ^ (_id2 != null ? _id2.GetHashCode() : 0);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Creates a CompositeId from its string representation.
        /// </summary>
        /// <param name="id">The string composite id.</param>
        /// <returns>A composite Id.</returns>
        public CompositeId FromString(string id)
        {
            var ids = id.Split(new[] { Seperator }, StringSplitOptions.RemoveEmptyEntries);
            Debug.Assert(ids.Length == 2);
            return new CompositeId(ids[0], ids[1]);
        }

        /// <summary>
        /// Returns true if both id1 and id2 values match.
        /// </summary>
        /// <param name="other">The object to compare.</param>
        /// <returns>True if the object are deemed equal.</returns>
        public bool Equals(CompositeId other)
        {
            return string.Equals(_id1, other._id1) && string.Equals(_id2, other._id2);
        }

        #endregion
    }
}
